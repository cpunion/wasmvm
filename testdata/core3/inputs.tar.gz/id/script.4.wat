(func $"a
b") 