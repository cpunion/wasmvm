use crate::store::{Ctx, MyWasiCtx};
use std::path::{Path, PathBuf};
use test_programs_artifacts::*;
use wasmtime::component::{Component, Linker};
use wasmtime::{Result, error::Context as _, format_err};
use wasmtime_wasi::p3::bindings::Command;
use wasmtime_wasi::{FsPerms, WasiCtxBuilder};

async fn run(path: &str) -> Result<()> {
    run_allow_blocking_current_thread(path, false).await
}

async fn run_allow_blocking_current_thread(
    path: &str,
    allow_blocking_current_thread: bool,
) -> Result<()> {
    run_with_builder(path, allow_blocking_current_thread, |_| {}).await
}

async fn run_with_builder(
    path: &str,
    allow_blocking_current_thread: bool,
    configure: impl FnOnce(&mut WasiCtxBuilder),
) -> Result<()> {
    let path = Path::new(path);
    let name = path.file_stem().unwrap().to_str().unwrap();
    let engine = test_programs_artifacts::engine(|config| {
        config.wasm_component_model_async(true);
    });
    let mut linker = Linker::new(&engine);
    // TODO: Remove once test components are not built for `wasm32-wasip1`
    wasmtime_wasi::p2::add_to_linker_async(&mut linker)
        .context("failed to link `wasi:cli@0.2.x`")?;
    wasmtime_wasi::p3::add_to_linker(&mut linker).context("failed to link `wasi:cli@0.3.x`")?;

    let (mut store, _td) = Ctx::new(&engine, name, |builder| {
        configure(builder);
        MyWasiCtx::new(
            builder
                .allow_blocking_current_thread(allow_blocking_current_thread)
                .build(),
        )
    })?;
    let component = Component::from_file(&engine, path)?;
    let command = Command::instantiate_async(&mut store, &component, &linker)
        .await
        .context("failed to instantiate `wasi:cli/command`")?;
    store
        .run_concurrent(async move |store| command.wasi_cli_run().call_run(store).await)
        .await
        .context("failed to call `wasi:cli/run#run`")?
        .context("guest trapped")?
        .map_err(|()| format_err!("`wasi:cli/run#run` failed"))
}

foreach_p3!(assert_test_exists);

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_big_random_buf() -> wasmtime::Result<()> {
    run(P3_BIG_RANDOM_BUF_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_cli() -> wasmtime::Result<()> {
    run(P3_CLI_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_clocks_sleep() -> wasmtime::Result<()> {
    run(P3_CLOCKS_SLEEP_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_filesystem_file_read_write() -> wasmtime::Result<()> {
    run(P3_FILESYSTEM_FILE_READ_WRITE_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_filesystem_file_read_write_blocking() -> wasmtime::Result<()> {
    run_allow_blocking_current_thread(P3_FILESYSTEM_FILE_READ_WRITE_COMPONENT, true).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_random_imports() -> wasmtime::Result<()> {
    run(P3_RANDOM_IMPORTS_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_ip_name_lookup() -> wasmtime::Result<()> {
    run(P3_SOCKETS_IP_NAME_LOOKUP_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_bind() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_BIND_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_connect() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_CONNECT_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_listen() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_LISTEN_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_sample_application() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_SAMPLE_APPLICATION_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_sockopts() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_SOCKOPTS_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_states() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_STATES_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_streams() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_STREAMS_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_tcp_busy_poll() -> wasmtime::Result<()> {
    run(P3_SOCKETS_TCP_BUSY_POLL_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_bind() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_BIND_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_connect() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_CONNECT_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_receive() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_RECEIVE_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_sample_application() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_SAMPLE_APPLICATION_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_send() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_SEND_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_sockopts() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_SOCKOPTS_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_sockets_udp_states() -> wasmtime::Result<()> {
    run(P3_SOCKETS_UDP_STATES_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_readdir() -> wasmtime::Result<()> {
    run(P3_READDIR_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_readdir_blocking() -> wasmtime::Result<()> {
    run_allow_blocking_current_thread(P3_READDIR_COMPONENT, true).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_file_write() -> wasmtime::Result<()> {
    run(P3_FILE_WRITE_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_file_write_blocking() -> wasmtime::Result<()> {
    run_allow_blocking_current_thread(P3_FILE_WRITE_COMPONENT, true).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_file_write_chunked() -> wasmtime::Result<()> {
    run(P3_FILE_WRITE_CHUNKED_COMPONENT).await
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_file_truncation_readonly() -> wasmtime::Result<()> {
    run_with_readonly_testfile(P3_FILE_TRUNCATION_READONLY_COMPONENT).await
}
async fn run_with_readonly_testfile(component_path: &str) -> wasmtime::Result<()> {
    let prefix = "wasi_components_p3_ro_";
    let tempdir = tempfile::Builder::new()
        .prefix(prefix)
        .tempdir()
        .expect("create readonly tempdir");
    const FILENAME: &str = "test.txt";
    const EXPECTED_CONTENTS: &[u8] = b"read only test file\n";
    let mut file = PathBuf::from(tempdir.path());
    file.push(FILENAME);
    std::fs::write(&file, EXPECTED_CONTENTS).expect("write read only test file");

    run_with_builder(component_path, false, |builder| {
        builder
            .preopened_dir(tempdir.path(), "readonly", FsPerms::ReadOnly)
            .unwrap();
    })
    .await?;

    let contents = std::fs::read(&file).expect("read read only test file");
    assert_eq!(EXPECTED_CONTENTS, contents);
    Ok(())
}

#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_file_hardlink_across_perms() -> wasmtime::Result<()> {
    run_with_readonly_testfile(P3_FILE_HARDLINK_ACROSS_PERMS_COMPONENT).await
}
#[test_log::test(tokio::test(flavor = "multi_thread"))]
async fn p3_file_rename_across_perms() -> wasmtime::Result<()> {
    run_with_readonly_testfile(P3_FILE_RENAME_ACROSS_PERMS_COMPONENT).await
}
