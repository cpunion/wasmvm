# Canonical ABI Explainer

This document defines the Canonical ABI used to convert between the values and
functions of components in the Component Model and the values and functions
of modules in Core WebAssembly. See the [AST explainer](Explainer.md) for a
walkthrough of the static structure of a component and the [concurrency
explainer] for a high-level description of the concurrency concepts being
specified here.

* [Introduction](#introduction)
* [Component Instances](#component-instances)
* [Concurrency](#concurrency)
  * [Stack Switching](#stack-switching)
  * [Threads](#threads)
  * [Tasks](#tasks)
* [Embedding](#embedding)
* [Canonical ABI Options](#canonical-abi-options)
* [Lifting and Lowering Context](#lifting-and-lowering-context)
* [Runtime State](#runtime-state)
  * [Table State](#table-state)
  * [Resource State](#resource-state)
  * [Waitable State](#waitable-state)
  * [Subtask State](#subtask-state)
  * [Buffer State](#buffer-state)
  * [Stream and Future State](#stream-and-future-state)
* [Despecialization](#despecialization)
* [Type Predicates](#type-predicates)
* [Alignment](#alignment)
* [Element Size](#element-size)
* [Loading](#loading)
* [Storing](#storing)
* [Flattening](#flattening)
* [Flat Lifting](#flat-lifting)
* [Flat Lowering](#flat-lowering)
* [Lifting and Lowering Values](#lifting-and-lowering-values)
* [Canonical definitions](#canonical-definitions)
  * [`canonopt` Validation](#canonopt-validation)
  * [`canon lift`](#canon-lift)
  * [`canon lower`](#canon-lower)
  * [`canon resource.new`](#canon-resourcenew)
  * [`canon resource.drop`](#canon-resourcedrop)
  * [`canon resource.rep`](#canon-resourcerep)
  * [`canon context.get`](#-canon-contextget) 🔀
  * [`canon context.set`](#-canon-contextset) 🔀
  * [`canon backpressure.{inc,dec}`](#-canon-backpressureincdec) 🔀
  * [`canon task.return`](#-canon-taskreturn) 🔀
  * [`canon task.cancel`](#-canon-taskcancel) 🔀
  * [`canon waitable-set.new`](#-canon-waitable-setnew) 🔀
  * [`canon waitable-set.wait`](#-canon-waitable-setwait) 🔀
  * [`canon waitable-set.poll`](#-canon-waitable-setpoll) 🔀
  * [`canon waitable-set.drop`](#-canon-waitable-setdrop) 🔀
  * [`canon waitable.join`](#-canon-waitablejoin) 🔀
  * [`canon subtask.cancel`](#-canon-subtaskcancel) 🔀
  * [`canon subtask.drop`](#-canon-subtaskdrop) 🔀
  * [`canon {stream,future}.new`](#-canon-streamfuturenew) 🔀
  * [`canon {stream,future}.{read,write}`](#-canon-streamfuturereadwrite) 🔀
  * [`canon {stream,future}.cancel-{read,write}`](#-canon-streamfuturecancel-readwrite) 🔀
  * [`canon {stream,future}.drop-{readable,writable}`](#-canon-streamfuturedrop-readablewritable) 🔀
  * [`canon {stream,future}.forward`](#-canon-streamfutureforward) ➡️
  * [`canon thread.index`](#-canon-threadindex) 🧵
  * [`canon thread.new-indirect`](#-canon-threadnew-indirect) 🧵
  * [`canon thread.resume-later`](#-canon-threadresume-later) 🧵
  * [`canon thread.suspend`](#-canon-threadsuspend) 🧵
  * [`canon thread.yield`](#-canon-threadyield) 🔀
  * [`canon thread.suspend-then-resume`](#-canon-threadsuspend-then-resume) 🧵
  * [`canon thread.yield-then-resume`](#-canon-threadyield-then-resume) 🧵
  * [`canon thread.suspend-then-promote`](#-canon-threadsuspend-then-promote) 🧵
  * [`canon thread.yield-then-promote`](#-canon-threadyield-then-promote) 🧵
  * [`canon error-context.new`](#-canon-error-contextnew) 📝
  * [`canon error-context.debug-message`](#-canon-error-contextdebug-message) 📝
  * [`canon error-context.drop`](#-canon-error-contextdrop) 📝
  * [`canon thread.spawn-ref`](#-canon-threadspawn-ref) 🧵②
  * [`canon thread.spawn-indirect`](#-canon-threadspawn-indirect) 🧵②
  * [`canon thread.available-parallelism`](#-canon-threadavailable-parallelism) 🧵②


## Introduction

The Canonical ABI specifies, for each component function signature, a
corresponding core function signature and the process for reading
component-level values into and out of linear memory. While a full formal
specification would specify the Canonical ABI in terms of macro-expansion into
Core WebAssembly instructions augmented with a new set of (spec-internal)
[administrative instructions], the informal presentation here instead specifies
the process in terms of Python code that would be logically executed at
validation- and run-time by a component model implementation. The Python code
is presented by interleaving definitions with descriptions and eliding some
boilerplate. For a complete listing of all Python definitions in a single
executable file with a small unit test suite, see the
[`canonical-abi`](canonical-abi/) directory.

The convention followed by the Python code below is that all traps are raised by
explicit `trap()`/`trap_if()` calls. Python `assert()` statements should never
fire; their conditions are maintained either by the internal rules of the
Component Model or by the host following the rules of the Embedding API.

As required by [Component Invariant] #1, any trap must lock down the entire
containing store as defined in the `Store` class below:
```python
def trap():
  current_instance().store.lock_down()
  raise Trap()

def trap_if(cond):
  if cond:
    trap()
```

While the Python code for lifting and lowering values appears to create an
intermediate copy when lifting linear memory into high-level Python values, a
real implementation should be able to fuse lifting and lowering into a single
direct copy from the source linear memory into the destination linear memory.

Lastly, independently of Python, the Canonical ABI defined below assumes that
out-of-memory conditions (such as `memory.grow` returning `-1` from within
`realloc`) will trap (via `unreachable`). This significantly simplifies the
Canonical ABI by avoiding the need to support the complicated protocols
necessary to support recovery in the middle of nested allocations. (Note: by
nature of eliminating `realloc`, switching to [lazy lowering] would obviate
this issue, allowing guest wasm code to handle failure by eagerly returning
some value of the declared return type to indicate failure.


## Component Instances

Once a `component` has been parsed/decoded and validated, it can be loaded at
runtime by *instantiating* it to produce a *component instance*. The
`ComponentInstance` class tracks all the spec-internal state that is used by the
definitions below to specify the Canonical ABI. For example, all `i32` handles
to resources, waitables, waitable sets, error contexts and threads will index
into the `handles` or `threads` fields of `ComponentInstance`.
```python
class ComponentInstance:
  store: Store
  handles: Table[ResourceHandle | Waitable | WaitableSet | ErrorContext]
  threads: Table[Thread]
  may_leave: bool
  backpressure: int
  num_waiting_to_enter: int
  exclusive_thread: Optional[Thread]

  def __init__(self, store):
    self.store = store
    self.handles = Table()
    self.threads = Table()
    self.may_leave = True
    self.backpressure = 0
    self.num_waiting_to_enter = 0
    self.exclusive_thread = None
```
Components are always instantiated in the context of a *store* (analogous to the
Core WebAssembly [`store`]) which is saved immutably in the instance's `store`
field. The `Store` class is defined below as part of the [Embedding](#embedding)
interface. The [JavaScript Embedding] defines each top-level component instance to go into
its own store. This allows them to have a separate lock down state.

The other fields of `ComponentInstance` are described below as they are used.


## Concurrency

The Component Model has native concurrency support as summarized by the
[concurrency explainer]. In the Canonical ABI, concurrency support is defined in
3 layers, defined in the next 3 subsections, resp.:
* The base layer is Core WebAssembly [stack-switching]'s `cont.new`,
  `suspend` and `resume` primitives, implemented here in terms of Python's
  standard `threading` library.
* The next layer up is `Thread`, which stores a mutable, nullable `contref`,
  updated over time as the thread suspends and resumes execution, along with
  some other thread-local state.
* The top layer is `Task`, which corresponds to a single cross-component
  concurrent function call, contains 1..N `Thread`s, and holds the state needed
  to define the ABI rules for the passing of parameters and results, the
  dropping of borrowed handles, cancellation and backpressure.


### Stack Switching

Component Model concurrency is defined in terms of the Core WebAssembly
[stack-switching] proposal's `cont.new`, `resume` and `suspend` instructions so
that there is a clear composition story between Component Model and Core
WebAssembly concurrency in the future. Since Python does not natively provide
algebraic effects, `cont.new`, `resume` and `suspend` are implemented in this
section in terms of other Python primitives. Thus, this section can be skimmed
since the semantics of stack-switching are already rigorously defined elsewhere;
it's only important to understand the Python function signatures and how they
correspond to the stack-switching instructions.

Since the Component Model only needs a subset of the full expressivity of
stack-switching, only that subset is implemented, which significantly simplifies
things. In particular, the Component Model uses stack-switching in the following
restricted manner:

First, there are only two global [control tags] used with `suspend`:
```wat
(tag $block (param (ref null $Thread)))
(tag $current-thread (result (ref $Thread)))
```
So instead of having a single generic Python `suspend` function, there are two
Python functions, `block` and `current_thread`, that implement `suspend $block`
and `suspend $current-thread`, resp.

The `$block` tag is used to suspend execution until some future event, with a
request to immediately resume the given `Thread` if non-null. (The next section
will define what a `Thread` is.)

The `$current-thread` tag is used to retrieve the [current thread], which is
semantically stored in the `resume` handler's local state (although an
optimizing implementation would instead maintain the current thread in the VM's
execution context (or a special Core WebAssembly `global`) so that it could be
cheaply loaded and/or kept in register state).

Second, there is only a single type of continuation passed to `resume` that
corresponds to the `$block` tag:
```wat
(type $ct (cont (func (result (ref null $Thread)))))
```
`$current-thread` continuations are immediately resumed and so never "escape"
and thus do not need a first-class continuation reference.

Third, every `resume` performed by the Canonical ABI always handles `$block` and
`$current-thread` and every Canonical ABI `suspend` is, by construction, always
scoped by a Canonical ABI `resume`. Thus, every Canonical ABI `suspend`
unconditionally transfers control flow directly to the innermost enclosing
Canonical ABI `resume` without a general handler/tag search.

Given this restricted usage, specialized versions of `cont.new`, `resume` and
`suspend` that are "monomorphized" to the above types and tags are implemented
in terms of Python's standard preemptive threading primitives, using
[`threading.Thread`] to provide a native stack, [`threading.Lock`] to only allow
a single `threading.Thread` to execute at a time, and [`threading.local`] to
maintain the dynamic handler scope using thread-local storage. This could have
been implemented more directly and efficiently using [fibers], but the Python
standard library doesn't have fibers. However, a realistic implementation is
expected to use (a pool of) fibers.

Starting with `cont.new`, the monomorphized version takes a function type
matching `$ct`, as defined above:
```python
class Continuation:
  lock: threading.Lock
  handler: Handler

class Handler:
  lock: threading.Lock
  current_thread: Thread
  cont: Optional[Continuation]
  result: Optional[Thread] | Trap

thread_local_handler = threading.local()

def new_already_acquired_lock() -> threading.Lock:
  lock = threading.Lock()
  lock.acquire()
  return lock

def cont_new(f: Callable[[], Optional[Thread]]) -> Continuation:
  cont = Continuation()
  cont.lock = new_already_acquired_lock()
  def thread_base():
    cont.lock.acquire()
    thread_local_handler.value = cont.handler
    try:
      result = f()
    except Trap as t:
      result = t
    handler = thread_local_handler.value
    handler.cont = None
    handler.result = result
    handler.lock.release()
  threading.Thread(target = thread_base).start()
  return cont
```
`Continuation.handler` is set by `resume` right before `resume` calls
`Continuation.lock.release()` to transfer control flow to the continuation.
After resuming the continuation, `resume` calls `Handler.lock.acquire()` to wait
until the continuation signals suspension, return or trap by calling
`Handler.lock.release()`. The `Handler` is stored in `thread_local_handler.value`
to implement the dynamic scoping that is required for `suspend`. Because the
thread created by `cont_new` can be suspended and resumed many times (each time
with a new `Continuation` and `Handler`, resp.), `Handler` must be re-loaded
from `thread_local_handler.value` after `f` returns since it may have changed
since the initial `resume`.

Next, `resume` is monomorphized to take a continuation of type `$ct` and the
`Thread` to use to implement the `(on $current-thread)` handler. The
`(on $block)` and "returned" cases join to produce a single return value, with
the `(on $block)` case returning a `Continuation` and the "returned" case
returning `None`. If the continuation traps, the trap propagates out of `resume`
to its caller.
```python
def resume(cont: Continuation, current_thread: Thread) -> \
           tuple[Optional[Continuation], Optional[Thread]]:
  handler = Handler()
  handler.lock = new_already_acquired_lock()
  handler.current_thread = current_thread
  cont.handler = handler
  cont.lock.release()
  handler.lock.acquire()
  if isinstance(handler.result, Trap):
    raise handler.result
  return (handler.cont, handler.result)
```

Next, the `block` function implements `suspend $block`. Following the locking
scheme already established by `cont_new` and `resume`, the implementation passes
control flow and event arguments back to the parent `resume` and then waits to
be unblocked by a future `resume`.
```python
def block(switch_to: Optional[Thread] = None):
  cont = Continuation()
  cont.lock = new_already_acquired_lock()
  handler = thread_local_handler.value
  handler.cont = cont
  handler.result = switch_to
  handler.lock.release()
  cont.lock.acquire()
  thread_local_handler.value = cont.handler
```

Lastly, the `current_thread` function implements `suspend $current-thread`,
taking its signature from the `$current-thread` tag defined above. As mentioned
above, the handler for `$current-thread` is hard-coded by the Component Model
to simply return the `Thread` passed to `resume` which is logically stored as
part of the handler's local state. Thus, the handler can be "inlined" at the
`suspend`-site by simply returning the `Thread` stored in thread-local storage
by `resume`. The other two functions are simply helpers for deriving the
current task and component instance from the current thread.
```python
def current_thread() -> Thread:
  return thread_local_handler.value.current_thread

def current_task() -> Task:
  return current_thread().task

def current_instance() -> ComponentInstance:
  return current_task().inst
```

Once Core WebAssembly gets stack-switching, the Component Model's `$block` and
`$current-thread` tags would *not* be exposed to Core WebAssembly. Thus, an
optimizing implementation would continue to be able to implement `block()` as a
direct control flow transfer and `current_thread()` with implicit execution
context, both without a general handler/tag search. In particular, this avoids
the pathological O(N<sup>2</sup>) behavior which would otherwise arise if
Component Model cooperative threads were used in conjunction with deeply-nested
Core WebAssembly handlers.

Additionally, once Core WebAssembly has stack switching, any unhandled events
that originate in Core WebAssembly would turn into traps if they reach a
component boundary (just like unhandled exceptions do now; see
`call_and_trap_on_throw` below). Thus, all cross-component/cross-language stack
switching would continue to be mediated by the Component Model's types and
Canonical ABI, with Core WebAssembly stack-switching used to implement
intra-component concurrency according to the language's own internal ABI.


### Threads

As described in the [concurrency explainer], threads are created both
*implicitly*, when calling a component export (in `canon_lift` below), and
*explicitly*, when core wasm code calls the `thread.new-indirect` built-in (in
`canon_thread_new_indirect` below). While threads are *logically* created for
each component export call, by design, non-`async` function calls and
non-`async`-lowered calls to non-`async`-lifted `async` function calls can be
implemented by the engine as a normal synchronous native function call.

Additionally, the engine can allocate the per-thread/task ABI state below
*lazily* to avoid overhead on small cross-component calls. To assist in this
optimization, threads are put into their own `ComponentInstance.threads` table
to reduce interference from the other kinds of handles.

Threads are represented in the Canonical ABI by the `Thread` class defined in
this section. The `Thread` class is implemented in terms of the stack-switching
primitives defined in the previous section and contains an optional mutable
continuation that is set and cleared whenever a thread is suspended and resumed,
resp. On top of the basic `suspend` and `resume` operations, `Thread` adds the
following higher-level concurrency concepts:
* [waiting on external I/O and yielding]
* [async call stack]
* [cancellation]
* [thread index]
* [thread-local storage]

The `Thread` class is introduced in chunks, starting with fields and
initialization, which leaves the thread in a `suspended` state with a
continuation that calls the given `thread_func`.
```python
class Thread:
  cont: Optional[Continuation] | Literal['running']
  ready_func: Optional[Callable[[], bool]]
  task: Task
  index: Optional[int]
  storage: tuple[int,int]
  cancellable: bool

  def __init__(self, task, thread_func):
    self.cont = cont_new(thread_func)
    self.ready_func = None
    self.task = task
    self.index = None
    self.storage = [0,0]
    self.cancellable = False
    assert(self.suspended())
```

Based on these fields, a `Thread` can be in one of the following top-level
states and sub-states:
* `running`: the continuation was `resume`d and has not yet `block`ed or
  returned
* `exited`: the continuation was `resume`d and then returned; the thread has
  been removed from the `threads` table and is unreachable
* `blocked`: the thread has a continuation
  * `suspended`: the continuation can only be `resume`d explicitly by someone
    else
  * `waiting`: the thread has a "readiness condition" which, once met, allows
    the runtime to `resume` the continuation
    * `ready`: the readiness condition is currently met

```python
  def running(self):
    return self.cont == 'running'

  def exited(self):
    return self.cont is None

  def blocked(self):
    return not (self.running() or self.exited())

  def suspended(self):
    return self.blocked() and self.ready_func is None

  def waiting(self):
    return self.blocked() and self.ready_func is not None

  def ready(self):
    return self.waiting() and self.ready_func()
```

The next two `Thread` methods are only called by `Thread` methods below to add
and remove a thread from the `Store.waiting` list at the same time as setting
and clearing, resp., the readiness function that `Store.tick` (defined below)
will test repeatedly to determine when the thread is ready to `resume`.
```python
  def start_waiting(self, ready_func):
    assert(self.ready_func is None)
    self.ready_func = ready_func
    self.task.inst.store.waiting.append(self)

  def stop_waiting(self):
    assert(self.waiting())
    self.ready_func = None
    self.task.inst.store.waiting.remove(self)
```

The `Thread.resume_later` method does not immediately `resume` the thread's
continuation but instead transitions the thread to the `ready` state, allowing
it to `resume` at some point in the future.
```python
  def resume_later(self):
    assert(self.suspended())
    self.start_waiting(ready_func = lambda: True)
    assert(self.ready())
```

The `Thread.resume` method is called on a `blocked` thread to `resume` the
thread's continuation. If the resumed continuation calls `block` with a non-null
`switch_to` argument, `Thread.resume` will `resume` *that* `Thread`'s
continuation, and so on, repeatedly in a loop, until the continuation either
returns or blocks with no thread to switch to.
```python
  def resume(self):
    assert(self.blocked())
    if self.waiting():
      self.stop_waiting()
    thread = self
    while thread is not None:
      cont = thread.cont
      thread.cont = 'running'
      (thread.cont, thread) = resume(cont, thread)
    assert(self.blocked() or self.exited())
```
Note that the `while` loop shown above is effectively implementing the `switch`
instruction of the [stack-switching] proposal since `switch` is just an
optimization of `suspend` followed by `resume`. The non-optimized version is
used here to simplify the storing of the new `Continuation` into `Thread.cont`.
However, an optimized implementation could do the direct switch.

The `Thread.suspend` method is called on a `running` thread to unconditionally
block with no readiness condition, leaving the thread `suspended`.
```python
  def suspend(self):
    assert(self.running())
    block()
    assert(self.running())
```

The `Thread.wait_until` method is a utility used to define multiple blocking
built-ins as well as auto-backpressure for `async` tasks and the `callback`
event loop. It sets a readiness condition before calling `block`, leaving the
thread in a `waiting` state.
```python
  def wait_until(self, ready_func):
    assert(self.running())
    if ready_func() and not DETERMINISTIC_PROFILE and random.randint(0,1):
      return
    self.start_waiting(ready_func)
    block()
    assert(self.running())
```
If `ready_func()` is already true on entry, the host can nondeterministically
decide whether to switch to another thread or keep running the current one. In
particular, when a caller makes an `async`-lowered call to a callee which
`wait_until`s a condition that's already met (including `thread.yield`), the
embedder can use scheduling heuristics to decide whether or not to `block` the
current thread to return control flow back to the caller.

The `Thread.yield_` method allows a thread to cooperatively yield execution
without having to block on external I/O.
```python
  def yield_(self):
    return self.wait_until(ready_func = lambda: True)
```

The `Thread.suspend_then_resume` and `Thread.yield_then_resume` methods
immediately `resume` some `other` `suspended` thread's continuation, leaving the
original thread `suspended` or `ready`, resp.
```python
  def suspend_then_resume(self, other: Thread):
    assert(self.running() and other.suspended())
    block(switch_to = other)
    assert(self.running())

  def yield_then_resume(self, other: Thread):
    assert(self.running() and other.suspended())
    self.start_waiting(ready_func = lambda: True)
    block(switch_to = other)
    assert(self.running())
```

Lastly, the `Thread.suspend_then_promote` and `Thread.yield_then_promote`
methods attempt to immediately `resume` some `other` thread's continuation if
the `other` thread is in a `ready` state. Otherwise, these methods fall back to
a plain `Thread.suspend` or `Thread.yield_`, resp. Either way, the original
thread is left `suspended` or `ready`, resp.
```python
  def suspend_then_promote(self, other: Thread):
    assert(self.running())
    if other.ready():
      other.stop_waiting()
      self.suspend_then_resume(other)
    else:
      self.suspend()
    assert(self.running())

  def yield_then_promote(self, other: Thread):
    assert(self.running())
    if other.ready():
      other.stop_waiting()
      self.yield_then_resume(other)
    else:
      self.yield_()
    assert(self.running())
```


### Tasks

As described in the [concurrency explainer], a "task" is created for each call
to a component export (in `canon_lift` below). Each task contains 1..N threads
that execute on behalf of the task, starting with the *implicit* thread that is
spawned by `canon_lift` and transitively including additional *explicit* threads
spawned by the implicit thread via `thread.new-indirect`. Tasks contain internal
state that is used to ensure (via trapping guards) that guest code obeys the
Canonical ABI rules.

At a high-level, all cross-component calls funnel through the same `FuncInst`
spec-level function type, where the host can be the caller, the callee or even
(in rare re-export cases) both:
```python
OnStart = Callable[[], list[any]]
OnResolve = Callable[[Optional[list[any]]], None]
OnCancel = Callable[[], None]
FuncInst = Callable[[OnStart, OnResolve], OnCancel]
```
The parameters of `FuncInst` are:
* an `OnStart` callback that is called by the callee when it is ready to
  receive its arguments after waiting for any [backpressure] to subside;
* an `OnResolve` callback that is called by the callee when it is ready to
  return its value or, if cancellation has been requested, `None`.

Critically, if the callee [blocks] at the wasm level, the spec-level `FuncInst`
returns immediately to the caller while continuing to execute the callee in a
separate `Thread`. The `OnStart` and `OnResolve` callbacks may be called at any
time before or after the callee returns. If the callee returns and the
`OnResolve` callback has *not* yet been called, the caller may invoke the
returned `OnCancel` callback *at most once* to cooperatively request that the
callee "hurry up" and call `OnResolve` (possibly, but not necessarily, passing
`None` and/or skipping the call to `OnStart`). The `OnCancel` callback may
transitively execute arbitrary guest code but must not block.

When `FuncInst` is implemented by wasm guest code (as opposed to the host), each
call creates a `Task` object to track the state of the call and ensure that the
wasm guest code adheres to the above `FuncInst` calling convention (or else
traps). `Task` is introduced in chunks, starting with fields and initialization:
```python
class Task:
  class State(Enum):
    INITIAL = 1
    STARTED = 2
    PENDING_CANCEL = 3
    CANCEL_DELIVERED = 4
    RESOLVED = 5

  ft: FuncType
  opts: CanonicalOptions
  inst: ComponentInstance
  on_start: OnStart
  on_resolve: OnResolve
  state: State
  num_borrows: int
  implicit_thread: Optional[Thread]
  threads: list[Thread]

  def __init__(self, ft, opts, inst, on_start, on_resolve):
    self.ft = ft
    self.opts = opts
    self.inst = inst
    self.on_start = on_start
    self.on_resolve = on_resolve
    self.state = Task.State.INITIAL
    self.num_borrows = 0
    self.implicit_thread = None
    self.threads = []
```

The `Task.needs_exclusive` predicate returns whether this task's implicit thread
(`Task.implicit_thread`) has *not* opted in to multiple concurrent linear memory
shadow stacks (via "stackful" lift) and thus, according to [Component Invariant]
#2, requires serialization with all the other implicit threads in the component
instance that have similarly not opted in. This question only applies to
`async`-typed functions, since synchronous functions can't block and thus can
always execute in a LIFO fashion using a single linear memory shadow stack. When
`needs_exclusive` is true, core wasm execution is gated on acquiring the
`ComponentInstance.exclusive_thread` lock. Due to cooperativity, the
`exclusive_thread` "lock" is simply a mutable field holding either `None`, when
unlocked, or, when locked, a reference to the `Task.implicit_thread` currently
holding the lock.
```python
  def needs_exclusive(self):
    assert(self.ft.async_)
    return not self.opts.async_ or self.opts.callback
```

The `Task.enter_implicit_thread` method implements [backpressure] between when
the caller of an `async`-typed function initiates the call and when the callee's
core wasm entry point is executed. This interstitial placement allows a
component instance that has been overloaded with concurrent function invocations
to avoid OOM. When backpressure is enabled, `enter_implicit_thread` will block
new `async`-typed calls until backpressure is disabled. There are three sources
of backpressure:
 1. *Explicit backpressure* is triggered by core wasm calling
    `backpressure.{inc,dec}` which modify the `ComponentInstance.backpressure`
    counter.
 2. *Implicit backpressure* triggered when `Task.needs_exclusive()` is true and
    the `ComponentInstance.exclusive_thread` lock is already held.
 3. *Residual backpressure* triggered by explicit or implicit backpressure
    having been enabled then disabled, but there still being tasks waiting to
    enter that need to be given the chance to start without getting starved
    by new tasks.

Note that, because non-`async`-typed functions ignore backpressure entirely,
they may reenter core wasm when an `async`-typed function would have been
blocked by implicit backpressure. Thus, export bindings generators must be
careful to handle this possibility (e.g., while maintaining the linear-memory
shadow stack pointer) for components with mixed `async`- and non-`async`- typed
exports.
```python
  def enter_implicit_thread(self):
    assert(self.state == Task.State.INITIAL)
    self.implicit_thread = current_thread()
    if self.ft.async_:
      def has_backpressure():
        return (self.inst.backpressure > 0 or
                (self.needs_exclusive() and self.inst.exclusive_thread is not None))
      if has_backpressure() or self.inst.num_waiting_to_enter > 0:
        self.inst.num_waiting_to_enter += 1
        self.implicit_thread.wait_until(lambda: not has_backpressure())
        self.inst.num_waiting_to_enter -= 1
        if self.deliver_pending_cancel():
          self.cancel()
          return False
      if self.needs_exclusive():
        assert(self.inst.exclusive_thread is None)
        self.inst.exclusive_thread = self.implicit_thread
    self.register_thread(self.implicit_thread)
    return True

  def register_thread(self, thread):
    assert(thread not in self.threads and thread.task is self)
    self.threads.append(thread)
    assert(thread.index is None)
    thread.index = self.inst.threads.add(thread)
```
Since the order in which suspended threads are resumed is nondeterministic (see
`Store.tick` below), once `Task.enter_implicit_thread` suspends the task's
implicit thread due to backpressure, the above definition allows the host to
arbitrarily select which threads to resume in which order. Additionally, the
above definition ensures the following properties:
* While a callee is waiting to enter, if the caller requests cancellation,
  the callee is immediately cancelled.
* When backpressure is disabled then reenabled, no new tasks start, even
  tasks that were blocked and then unblocked by the first occurrence of
  backpressure (i.e., disabling backpressure never unleashes an unstoppable
  thundering herd of pending tasks).

Once a task's implicit thread has cleared the backpressure gate, it is added to
the lists of threads running inside the current task and component instance by
`Task.register_thread()` (which is also called by `thread.new-indirect`, below).

Symmetrically, the `Task.exit_implicit_thread` method is called before a task's
implicit thread returns to reverse the effects of `Task.enter_implicit_thread`.
In particular, if the `exclusive_thread` lock was acquired, it is released.
`Task.unregister_thread` (which is also called by `thread.new-indirect`, below)
traps if the task's last thread is unregistered and the task has not yet
returned a value to its caller.
```python
  def exit_implicit_thread(self):
    assert(current_thread() is self.implicit_thread)
    self.unregister_thread(self.implicit_thread)
    if self.ft.async_ and self.needs_exclusive():
      assert(self.inst.exclusive_thread is self.implicit_thread)
      self.inst.exclusive_thread = None

  def unregister_thread(self, thread):
    assert(thread in self.threads and thread.task is self)
    self.threads.remove(thread)
    if len(self.threads) == 0:
      trap_if(self.state != Task.State.RESOLVED)
      assert(self.num_borrows == 0)
    assert(thread.index is not None)
    self.inst.threads.remove(thread.index)
```

The `Task.request_cancellation` method implements the `OnCancel` callback that
is called by the `subtask.cancel` built-in. If a task's implicit thread is
waiting to start (in `Task.enter_implicit_thread`, defined above) due to
backpressure, then it is immediately cancelled without running any guest code.
Otherwise, if the task's implicit thread is `cancellable` and `ready`, it is
resumed, allowing it to execute until returning or blocking. Currently, only
`callback` threads that have returned to their event loop are `cancellable`.
When resumed, the `callback` thread will call `Task.deliver_pending_cancel`,
which will return `True`, leading to the `TASK_CANCELLED` event code being
passed to the `callback` function. The `Thread.resume` call will return as soon
as the `callback` function returns or blocks, whether or not the subtask called
`task.{cancel,return}`, and thus the caller of `OnCancel` must handle both the
resolved and not-resolved cases after `OnCancel` returns.
```python
  def request_cancellation(self):
    if self.state == Task.State.INITIAL:
      self.state = Task.State.PENDING_CANCEL
      self.implicit_thread.resume()
      assert(self.state == Task.State.RESOLVED)
    else:
      assert(self.state == Task.State.STARTED)
      self.state = Task.State.PENDING_CANCEL
      if self.implicit_thread.cancellable and self.implicit_thread.ready():
        self.implicit_thread.resume()

  def has_pending_cancel(self):
    return self.state == Task.State.PENDING_CANCEL

  def deliver_pending_cancel(self) -> bool:
    if self.has_pending_cancel():
      self.state = Task.State.CANCEL_DELIVERED
      return True
    else:
      return False
```

The `Task.start` method is called by `canon_lift` to get the list of
component-level values that will be subsequently lowered into the callee
component's memory. Since it is called involuntarily after backpressure, before
guest code runs, the definition can assert that it is called correctly.
```python
  def start(self) -> list[any]:
    assert(self.state == Task.State.INITIAL)
    self.state = Task.State.STARTED
    return self.on_start()
```

The `Task.return_` method is called by `canon_task_return` and `canon_lift` to
return a list of lifted values to the task's caller via the `OnResolve`
callback. There is a dynamic error if the callee has not dropped all borrowed
handles by the time `task.return` is called which means that the caller can
assume that all its lent handles have been returned to it when it receives the
`SUBTASK` `RETURNED` event. Note that the initial `trap_if` allows a task to
return a value even after cancellation has been requested.
```python
  def return_(self, result):
    trap_if(self.state == Task.State.RESOLVED)
    trap_if(self.num_borrows > 0)
    assert(result is not None)
    self.on_resolve(result)
    self.state = Task.State.RESOLVED
```

Lastly, the `Task.cancel` method is called by `canon_task_cancel` and
enforces the same `num_borrows` condition as `return_`, ensuring that when
the caller's `OnResolve` callback is called, the caller knows all borrows
have been returned. The initial `trap_if` only allows cancellation after
cancellation has been *delivered* to core wasm. In particular, if
`request_cancellation` sets `Task.state` to `PENDING_CANCEL`, core wasm will
still trap if it tries to call `task.cancel`.
```python
  def cancel(self):
    trap_if(self.state != Task.State.CANCEL_DELIVERED)
    trap_if(self.num_borrows > 0)
    self.on_resolve(None)
    self.state = Task.State.RESOLVED
```


## Embedding

A WebAssembly Component Model implementation will typically be *embedded* into a
*host* environment. An *embedder* implements the connection between such a host
environment and the Component Model semantics defined here. A full Embedding
interface would contain functions for decoding, validating, instantiating and
interrogating components, just like the [Core WebAssembly Embedding]. However,
the Embedding interface here just covers the subset that is necessary to define
the behavior of the Canonical ABI.

The Embedding interface is defined as the methods of the `Store` class, which is
the Component Model's version of a Core WebAssembly [`store`]. The `Store` class
is introduced in chunks, starting with fields and initialization:
```python
class Store:
  waiting: list[Thread]
  nesting_depth: int
  lockdown: bool

  def __init__(self):
    self.waiting = []
    self.nesting_depth = 0
    self.lockdown = False
```
The `waiting` field is populated by `Thread` methods, as defined above, and the
`nesting_depth` field is purely a specification device used by `Store` methods
below to define the valid host call interleavings (and, in particular, when it
is valid to call `Store.tick`).

The `Store.lockdown` flag is used to specify [Component Invariant] #1. This flag
can be queried and set directly by the host through the Embedding API:
```python
  def is_locked_down(self):
    return self.lockdown

  def lock_down(self):
    self.lockdown = True
```

The `Store.invoke` method is analogous to Core WebAssembly's [`func_invoke`] and
takes a `FuncInst` (analogous to a Core WebAssembly [`funcinst`]) along with its
runtime `OnStart` and `OnResolve` arguments (which are described above alongside
their definitions). The `not lockdown` assertions require the host not to start
any new calls or cancel any existing calls (which may execute guest code) once
the store has been locked down.
```python
  def invoke(self, f: FuncInst, on_start: OnStart, on_resolve: OnResolve) -> OnCancel:
    assert(not self.lockdown)
    self.nesting_depth += 1
    request_cancellation = f(on_start, on_resolve)
    self.nesting_depth -= 1
    def on_cancel():
      assert(not self.lockdown)
      self.nesting_depth += 1
      request_cancellation()
      self.nesting_depth -= 1
    return on_cancel
```
The `FuncInst` passed to `Store.invoke` can be either a guest function (produced
by `Store.lift`, defined next) or (in the special case of component re-exports)
a host function. Symmetrically, `FuncInst`s can be called either from the host
(via `Store.invoke`) or core wasm code (via `Store.lower`).

The `Store.lift` method is called for each `canon lift` definition in a
component to wrap a core wasm `CoreFuncInst` into a component-level `FuncInst`,
passing `canon lift`'s immediate arguments as well as the containing component
instance. Similarly, `Store.lower` is called for each `canon lower` definition
in a component to wrap a component-level `FuncInst` into a core wasm
`CoreFuncInst`. (In a complete Embedding API, `Store.lift` and `Store.lower`
would be replaced by a single, higher-level `Store.instantiate` method of type
`Component -> ComponentInstance`, analogous to the Core WebAssembly's
[`module_instantiate`]. But for the Canonical ABI, just `lift` and `lower` are
sufficient to define relevant ABI behavior.) `canon_lift` and `canon_lower` are
defined below, combining all the intervening supporting definitions to specify
the full runtime behavior of calls into and out of Core WebAssembly code.
```python
  CoreFuncInst = Callable[[list[CoreValType]], list[CoreValType]]

  def lift(self, f: CoreFuncInst, ft: FuncType, opts: CanonicalOptions, inst: ComponentInstance) -> FuncInst:
    def func_inst(on_start: OnStart, on_resolve: OnResolve) -> OnCancel:
      assert(self.nesting_depth > 0)
      on_cancel = canon_lift(f, ft, opts, inst, on_start, on_resolve)
      assert(self.nesting_depth > 0)
      return on_cancel
    return func_inst

  def lower(self, f: FuncInst, ft: FuncType, opts: CanonicalOptions, inst: ComponentInstance) -> CoreFuncInst:
    def core_func_inst(args: list[CoreValType]) -> list[CoreValType]:
      assert(inst is current_instance())
      assert(self.nesting_depth > 0)
      flat_results = canon_lower(f, ft, opts, args)
      assert(self.nesting_depth > 0)
      return flat_results
    return core_func_inst
```

Lastly, the `Store.tick` method does not have an analogue in Core WebAssembly
but is necessary to enable native concurrency support in the Component Model.
`Store.tick` allows the runtime to nondeterministically resume a thread that
previously [blocked] but is now ready. As defined above, `Thread.resume` will
execute the thread until it either returns or [blocks] again. Thus, each call to
`Store.tick` just allows a single thread to make a single quantum of cooperative
progress and the expectation is that the host heuristically interleaves calls to
`Store.invoke` with calls to `Store.tick` so that concurrent tasks can complete
while new tasks are being started.
```python
  def tick(self):
    assert(not self.lockdown)
    assert(self.nesting_depth == 0)
    self.nesting_depth += 1
    candidates = { thread for thread in self.waiting if thread.ready() }
    if candidates:
      thread = random.choice(list(candidates))
      thread.resume()
    self.nesting_depth -= 1
```
The `not lockdown` assertion complements those in `Store.invoke` and prohibits
the host from resuming concurrent tasks in a locked-down store. Since
`Store.nesting_depth` is greater than zero while calling `Store.invoke` or
`on_cancel`, the `nesting_depth == 0` assertion further prohibits the host from
scheduling arbitrary cooperative threads until all active core wasm calls in the
store have [blocked] or returned.


## Canonical ABI Options

The following classes list the various Canonical ABI options ([`canonopt`])
that can be set on various Canonical ABI definitions. The default values of
the Python fields are the default values when the associated `canonopt` is
not present in the binary or text format definition.

The `MemInst` class represents a core WebAssembly [`memory` instance], with
`bytes` corresponding to the memory's bytes and `addrtype` coming from the
[`memtype`].
```python
def ptr_size(ptr_type):
  match ptr_type:
    case 'i32':
      return 4
    case 'i64':
      return 8

@dataclass
class MemInst:
  bytes: bytearray
  addrtype: Literal['i32', 'i64']

  def __getitem__(self, i):
    return self.bytes[i]

  def __setitem__(self, i, v):
    self.bytes[i] = v

  def __len__(self):
    return len(self.bytes)

  def ptr_type(self):
    return self.addrtype

  def ptr_size(self):
    return ptr_size(self.ptr_type())
```
The `ptr_type` and `ptr_size` methods return the core value type and byte
size of memory pointers.

The `LiftOptions` class contains the subset of [`canonopt`] which are needed
when lifting individual parameters and results:
```python
@dataclass
class LiftOptions:
  string_encoding: str = 'utf8'
  memory: Optional[MemInst] = None

  def equal(lhs, rhs):
    return lhs.string_encoding == rhs.string_encoding and \
           lhs.memory is rhs.memory
```
The `equal` static method is used by `task.return` below to dynamically
compare equality of just this subset of `canonopt`.

The `LiftLowerOptions` class contains the subset of [`canonopt`] which are
needed when lifting *or* lowering individual parameters and results:
```python
@dataclass
class LiftLowerOptions(LiftOptions):
  realloc: Optional[Callable] = None
```

The `CanonicalOptions` class contains the rest of the [`canonopt`]
options that affect how an overall function is lifted/lowered:
```python
@dataclass
class CanonicalOptions(LiftLowerOptions):
  post_return: Optional[Callable] = None
  async_: bool = False
  callback: Optional[Callable] = None
```


## Lifting and Lowering Context

Most Canonical ABI definitions depend on some ambient information which is
established by the `canon lift`- or `canon lower`-defined function that is
being called:
* whether values are being lifted out of or lowered into core wasm
* the ABI options supplied via [`canonopt`]
* the containing component instance
* the `Task` or `Subtask` used to lower or lift, resp., `borrow` handles

These four pieces of ambient information are stored in an `LiftLowerContext`
object that is threaded through all the Python functions below as the `cx`
parameter/field.
```python
class LiftLowerContext:
  direction: Literal['lift', 'lower']
  opts: LiftLowerOptions
  inst: ComponentInstance
  borrow_scope: Optional[Task|Subtask]

  def __init__(self, direction, opts, inst, borrow_scope = None):
    self.direction = direction
    self.opts = opts
    self.inst = inst
    self.borrow_scope = borrow_scope
```
The `borrow_scope` field may be `None` if the types being lifted/lowered are
known to not contain `borrow`.

The `direction` field indicates which of lifting or lowering (of values or whole
functions) is being performed. The `reverse_direction` method flips the
direction, which is used to specify how the parameters/arguments of a function
are to be lifted or lowered relative to the function as a whole:
```python
  def reverse_direction(self):
    new_direction = 'lift' if self.direction == 'lower' else 'lower'
    return LiftLowerContext(new_direction, self.opts, self.inst, self.borrow_scope)
```

The `LiftLowerContext.reallocate` and `LiftLowerContext.allocate` methods define
how to dynamically allocate linear memory using the `realloc` `canonopt` when
lowering non-flattened values. The definition below specifies this call as-if
`realloc` were a component export being (potentially recursively) invoked by the
host:
```python
  def reallocate(self, old, old_byte_length, alignment, new_byte_length):
    ptrt = U32Type() if self.opts.memory.ptr_type() == 'i32' else U64Type()
    ft = FuncType([ptrt, ptrt, ptrt, ptrt], [ptrt], async_ = False)
    opts = CanonicalOptions(async_ = False)
    realloc = self.inst.store.lift(self.opts.realloc, ft, opts, self.inst)
    def on_start():
      return [old, old_byte_length, alignment, new_byte_length]
    ptr = None
    def on_resolve(result):
      nonlocal ptr
      [ptr] = result
    assert(self.inst.may_leave)
    self.inst.may_leave = False
    self.inst.store.invoke(realloc, on_start, on_resolve)
    self.inst.may_leave = True
    assert(ptr is not None)
    trap_if(ptr != align_to(ptr, alignment))
    trap_if(ptr + new_byte_length > len(self.opts.memory))
    return ptr

  def allocate(self, alignment, byte_length):
    return self.reallocate(0, 0, alignment, byte_length)
```
As a consequence of the above definitions, calls to `realloc` semantically
execute in a new `Thread` with zero-initialized `Thread.storage` (so that
`context.get` returns `0` on entry to `realloc`). However, because the call is
fully synchronous and because all "interesting" threading built-ins that might
observably require a proper thread are guarded by `may_leave` traps, an
optimizing implementation may compile `realloc` calls to synchronous calls on
whatever internal thread structure is handy (being careful to set and restore
thread-local storage and the current component instance if necessary).


## Runtime State

The following Python classes define spec-internal state and utility methods
that are used to define the externally-visible behavior of Canonical ABI's
lifting, lowering and built-in definitions below. These fields are chosen for
simplicity over performance and thus an optimizing implementation is expected
to use a more optimized representations as long as it preserves the same
externally-visible behavior. Some specific examples of expected optimizations
are noted below.


### Table State

The `Table` class encapsulates a mutable, growable array of opaque elements
that are represented in Core WebAssembly as `i32` indices into the array.
Currently, every component instance contains two tables: a `threads` table
containing all the component's [threads](#threads) and a `handles`
table containing everything else ([resource handles](#resource-state),
[waitables and waitable sets](#waitable-state) and
[error contexts](#-canon-error-contextnew)).
```python
class Table:
  array: list[any]
  free: list[int]

  MAX_LENGTH = 2**28 - 1

  def __init__(self):
    self.array = [None]
    self.free = []

  def __iter__(self):
    for e in self.array:
      if e is not None:
        yield e

  def get(self, i):
    trap_if(i >= len(self.array))
    trap_if(self.array[i] is None)
    return self.array[i]

  def add(self, e):
    if self.free:
      i = self.free.pop()
      assert(self.array[i] is None)
      self.array[i] = e
    else:
      i = len(self.array)
      trap_if(i > Table.MAX_LENGTH)
      self.array.append(e)
    return i

  def remove(self, i):
    e = self.get(i)
    self.array[i] = None
    self.free.append(i)
    return e
```
`Table` maintains a dense array of elements that can contain holes created by
the `remove` method (defined above). When table elements are accessed (e.g., by
`canon_lift` and `resource.rep`, below), there are thus both a bounds check and
hole check necessary. Upon initialization, table element `0` is allocated and
set to `None`, effectively reserving index `0` which is both useful for
catching null/uninitialized accesses and allowing `0` to serve as a sentinel
value.

The `add` and `remove` methods work together to maintain a free list of holes
that are used in preference to growing the table. The free list is represented
as a Python list here, but an optimizing implementation could instead store the
free list in the free elements of `array`.

The limit of `2**28` ensures that the high 4 bits of table indices are unset
and available for other use in guest code (e.g., for tagging, packed words or
sentinel values).


### Resource State

The `ResourceHandle` class defines the elements of the component instance's
`handles` table used to represent handles to resources:
```python
class ResourceHandle:
  rt: ResourceType
  rep: int
  own: bool
  borrow_scope: Optional[Task]
  num_lends: int

  def __init__(self, rt, rep, own, borrow_scope = None):
    self.rt = rt
    self.rep = rep
    self.own = own
    self.borrow_scope = borrow_scope
    self.num_lends = 0
```
The `rt` and `rep` fields of `ResourceHandle` store the resource type and
representation of the resource, where `rep` is a core value of type `rt.rep`
(defined below).

The `own` field indicates whether this element was created from an `own` type
(or, if false, a `borrow` type).

The `borrow_scope` field stores the `Task` that lowered the borrowed handle as a
parameter since there can be multiple tasks live in a component instance at a
time (even when only synchronous functions are used, due to reentrance).

The `num_lends` field maintains a conservative approximation of the number of
live handles that were lent from this handle (by calls to `borrow`-taking
functions). This count is maintained by the `Subtask` bookkeeping functions
(below) and is ensured to be zero when an `own` handle is dropped.

The `ResourceType` class represents a runtime instance of a resource type that
has been created either by the host or a component instance (where multiple
component instances of the same static component create multiple `ResourceType`
instances). `ResourceType` Python object identity is used by trapping guards on
the `rt` field of `ResourceHandle` (above) and thus resource type equality is
*not* defined structurally (on the contents of `ResourceType`).
```python
class ResourceType(Type):
  impl: ComponentInstance
  rep: Literal['i32', 'i64']
  dtor: Optional[Callable]

  def __init__(self, impl, rep, dtor = None):
    self.impl = impl
    self.rep = rep
    self.dtor = dtor
```
The `rep` field stores the core value type given by the `(rep ...)` immediate
of the `resource` type definition.


### Waitable State

A "waitable" is a concurrent activity that can be waited on by the built-ins
`waitable-set.wait` and `waitable-set.poll`. Currently, there are 5 different
kinds of waitables: [subtasks] and the 4 combinations of the [readable and
writable ends] of futures and streams.

Waitables deliver "events" which are values of the following `EventTuple` type.
The two `int` "payload" fields of `EventTuple` store core wasm `i32`s and are
to be interpreted based on the `EventCode`. The meaning of the different
`EventCode`s and their payloads will be introduced incrementally below by the
code that produces the events (specifically, in `subtask_event`, `stream_event`
or `future_event`).
```python
class EventCode(IntEnum):
  NONE = 0
  SUBTASK = 1
  STREAM_READ = 2
  STREAM_WRITE = 3
  FUTURE_READ = 4
  FUTURE_WRITE = 5
  TASK_CANCELLED = 6

EventTuple = tuple[EventCode, int, int]
```

The `Waitable` class factors out the state and behavior common to all 5 kinds
of waitables, which are each defined as subclasses of `Waitable` below.

Every `Waitable` can store at most one pending event in its `pending_event`
field which will be delivered to core wasm as soon as the core wasm code
explicitly waits on this `Waitable` (which may take an arbitrarily long time).
A `pending_event` is represented in the Python code below as a *closure* so
that the closure can specify behaviors that trigger *right before* events are
delivered to core wasm and so that the closure can compute the event based on
the state of the world at delivery time (as opposed to when `pending_event` was
first set). Currently, `pending_event` holds a closure of the `subtask_event`,
`stream_event` or `future_event` functions defined below. An optimizing
implementation would avoid closure allocation by inlining a union containing
the closure fields directly in the component instance table.

A waitable can belong to at most one "waitable set" (defined next) which is
referred to by the `wset` field. A `Waitable`'s `pending_event` is delivered
(via `get_pending_event`) when core wasm code waits on its waitable set (via
`waitable-set.wait` or, when using the `async callback` ABI, by returning to the
event loop).

Lastly, a waitable cannot be waited on *both* by a waitable set and one of
`subtask.cancel` or a synchronous `{stream,future}.{,cancel-}{read,write}` since
this raises the possibility that the waitable set "steals" events from the other
built-in, leaving the built-in forever waiting. This condition is asserted by
the `Waitable` methods here and guarded via traps by the relevant built-ins
below.
```python
class Waitable:
  pending_event: Optional[Callable[[], EventTuple]]
  wset: Optional[WaitableSet]
  has_sync_waiter: bool

  def __init__(self):
    self.pending_event = None
    self.wset = None
    self.has_sync_waiter = False

  def set_pending_event(self, pending_event):
    self.pending_event = pending_event

  def has_pending_event(self):
    return bool(self.pending_event)

  def in_waitable_set(self):
    return self.wset is not None

  def wait_for_pending_event(self):
    assert(not self.in_waitable_set() and not self.has_sync_waiter)
    self.has_sync_waiter = True
    current_thread().wait_until(self.has_pending_event)
    self.has_sync_waiter = False

  def get_pending_event(self) -> EventTuple:
    pending_event = self.pending_event
    self.pending_event = None
    return pending_event()

  def join(self, wset):
    assert(not self.has_sync_waiter)
    if self.wset:
      self.wset.elems.remove(self)
    self.wset = wset
    if wset:
      wset.elems.append(self)

  def drop(self):
    assert(not self.has_sync_waiter)
    self.join(None)
```

A "waitable set" contains a collection of waitables that can be waited on or
polled for *any* element to make progress. Although the `WaitableSet` class
below represents `elems` as a `list` and implements `{has,get}_pending_event`
with an O(n) search, because a waitable can be associated with at most one set
and can contain at most one pending event, a real implementation could instead
store a list of waitables-with-pending-events as a linked list embedded
directly in the component instance's table element to avoid the separate
allocation while providing O(1) polling. The `random.shuffle` in
`get_pending_event` gives embedders the semantic freedom to schedule delivery of
events nondeterministically (e.g., taking into account priorities); runtimes do
not have to literally randomize event delivery.
```python
class WaitableSet:
  elems: list[Waitable]
  num_waiting: int

  def __init__(self):
    self.elems = []
    self.num_waiting = 0

  def has_pending_event(self):
    return any(w.has_pending_event() for w in self.elems)

  def get_pending_event(self) -> EventTuple:
    assert(self.has_pending_event())
    random.shuffle(self.elems)
    for w in self.elems:
      assert(self is w.wset)
      if w.has_pending_event():
        return w.get_pending_event()
```

Given the above helper methods, the `waitable-set.wait` and `waitable-set.poll`
built-ins can wait on or poll `has_pending_event`, resp. The `num_waiting` count
is used to trap in `WaitableSet.drop`, below, if guest code attempts to destroy
a waitable set that is in use.
```python
  def wait(self) -> EventTuple:
    self.num_waiting += 1
    current_thread().wait_until(self.has_pending_event)
    self.num_waiting -= 1
    return self.get_pending_event()

  def poll(self) -> EventTuple:
    if not self.has_pending_event():
      return (EventCode.NONE, 0, 0)
    else:
      return self.get_pending_event()
```

When the `async callback` ABI is used and core wasm code returns `WAIT`, there
are two extra wrinkles beyond the plain `WaitableSet.wait` shown above. First,
to ensure the run-to-completion semantics required by [Component Invariant] #2,
the readiness condition passed to `Thread.wait_until` requires that there is no
`needs_exclusive` thread on the stack (holding the `exclusive_thread` lock).
Second, in addition to delivering normal waitable events, pending cancellation
on the current task is also delivered as a `TASK_CANCELLED` event.
```python
  def wait_from_callback(self) -> EventTuple:
    thread = current_thread()
    def ready():
      return (thread.task.inst.exclusive_thread is None
              and (self.has_pending_event() or thread.task.has_pending_cancel()))
    self.num_waiting += 1
    thread.wait_until(ready)
    self.num_waiting -= 1
    if thread.task.deliver_pending_cancel():
      return (EventCode.TASK_CANCELLED, 0, 0)
    else:
      return self.get_pending_event()
```

The `WaitableSet.drop` method traps if dropped while it still contains elements
(whose `Waitable.wset` field would become dangling) or if it is being
waited-upon by another thread (as indicated by a non-zero `num_waiting`).
```python
  def drop(self):
    trap_if(len(self.elems) > 0)
    trap_if(self.num_waiting > 0)
```


### Subtask State

While `canon_lift` creates `Task` objects, `canon_lower` creates `Subtask`
objects, using `Subtask` to contain all the state relevant to the caller. See
the [structured concurrency] section for a summary of how `Task` and `Subtask`
relate with respect to component- and host-defined callers and callees. This
section introduces `Subtask` incrementally, starting with its fields and
initialization:
```python
class Subtask(Waitable):
  class State(IntEnum):
    STARTING = 0
    STARTED = 1
    RETURNED = 2
    CANCELLED_BEFORE_STARTED = 3
    CANCELLED_BEFORE_RETURNED = 4

  state: State
  on_cancel: Optional[OnCancel]
  lenders: Optional[list[ResourceHandle]]
  cancellation_requested: bool
  flat_results: list[CoreValType]

  def __init__(self):
    Waitable.__init__(self)
    self.state = Subtask.State.STARTING
    self.on_cancel = None
    self.lenders = []
    self.cancellation_requested = False
    self.flat_results = []
```

The `state` field of `Subtask` tracks the callee's progression from the initial
[`STARTING`][Backpressure] state along the [subtask state machine].
A `Subtask` is considered "resolved" if it has returned a value or if, after
having had cancellation requested by the caller, called `task.cancel` (either
before or after calling `OnStart`):
```python
  def resolved(self):
    match self.state:
      case (Subtask.State.STARTING |
            Subtask.State.STARTED):
        return False
      case (Subtask.State.RETURNED |
            Subtask.State.CANCELLED_BEFORE_STARTED |
            Subtask.State.CANCELLED_BEFORE_RETURNED):
        return True
```

The `Subtask.add_lender` method is called by `lift_borrow` (below). This method
increments the `num_lends` counter on the handle being lifted, which is guarded
to be zero by `canon_resource_drop` (below). The `Subtask.deliver_resolve`
method is called right before the `SUBTASK` resolve event is delivered to
wasm (for any of the `RETURNED`, `CANCELLED_BEFORE_STARTED` or
`CANCELLED_BEFORE_RETURNED` states), at which point all the borrowed handles
are logically returned to the caller by decrementing all the `num_lend` counts
that were initially incremented.
```python
  def add_lender(self, lending_handle):
    assert(not self.resolve_delivered() and not self.resolved())
    lending_handle.num_lends += 1
    self.lenders.append(lending_handle)

  def resolve(self, state, flat_results):
    assert(state == Subtask.State.RETURNED or flat_results == [])
    assert(not self.resolved())
    self.state = state
    self.flat_results = flat_results
    assert(self.resolved())

  def deliver_resolve(self):
    assert(not self.resolve_delivered() and self.resolved())
    for h in self.lenders:
      h.num_lends -= 1
    self.lenders = None

  def resolve_delivered(self):
    assert(self.lenders is not None or self.resolved())
    return self.lenders is None
```
Note, the `lenders` list usually has a fixed size (in all cases except when a
function signature has `borrow`s in `list`s or `stream`s) and thus can be
stored inline in the native stack frame.

The `Subtask.drop` method is only called for `Subtask`s that have been added to
the current component instance's `handles` table and checks that the callee has
been allowed to resolve and explicitly relinquish any borrowed handles.
```python
  def drop(self):
    trap_if(not self.resolve_delivered())
    Waitable.drop(self)
```


### Buffer State

A "buffer" is an abstract region of memory that can either be read-from or
written-to. This region of memory can either be owned by the host or by wasm.
Currently wasm memory is always 32-bit or 64-bit linear memory, but soon GC
memory will be added. Thus, buffers provide an abstraction over at least 4
different "kinds" of memory.

(Currently, buffers are only created implicitly as part of stream and future
built-ins such as `stream.read`. However, in the
[future](https://github.com/WebAssembly/component-model/issues/369#issuecomment-2248574765),
explicit component-level buffer types and canonical built-ins may be added to
allow explicitly creating buffers and passing them between components.)

A "readable buffer" allows reading `t` values *from* the buffer's memory. A
"writable buffer" allows writing `t` values *into* the buffer's memory. All
buffers have an associated component-level value type `t` and a `remain` method
that returns how many `t` values may still be read or written. Buffers mostly
hide their original/complete size. However, zero-length buffers need to be
treated specially (particularly when a zero-length read rendezvous with a
zero-length write), so there is a special query for detecting whether a buffer
is zero-length. Internally, buffers do have a maximum length of `2^28 - 1` which
is independent of the type of memory backing the buffer. Based on this, buffers
are represented by the following 3 abstract Python classes:
```python
class Buffer:
  MAX_LENGTH = 2**28 - 1
  t: ValType
  remain: Callable[[], int]

class ReadableBuffer(Buffer):
  read: Callable[[int], list[any]]

class WritableBuffer(Buffer):
  write: Callable[[list[any]]]
```
As preconditions (internally ensured by the Canonical ABI code below):
* `read` may only be passed a positive number less than or equal to `remain`
* `write` may only be passed a non-empty list of length less than or equal to
  `remain` containing values of type `t`

Since `read` and `write` are synchronous Python functions, buffers inherently
guarantee synchronous access to a fixed-size backing memory and are thus
distinguished from streams (which provide *asynchronous* operations for reading
and writing an unbounded number of values to potentially-different regions of
memory over time).

The `ReadableBuffer` and `WritableBuffer` abstract classes may either be
implemented by the host or by another wasm component. In the latter case, these
abstract classes are implemented by the concrete `ReadableGuestBuffer` and
`WritableGuestBuffer` classes which eagerly check alignment and range when the
buffer is constructed so that `read` and `write` are infallible operations
(modulo traps):
```python
class GuestBuffer(Buffer):
  cx: LiftLowerContext
  t: ValType
  ptr: int
  progress: int
  length: int

  def __init__(self, t, cx, ptr, length):
    trap_if(length > Buffer.MAX_LENGTH)
    if t is not None:
      trap_if(ptr != align_to(ptr, alignment(cx, t)))
      trap_if(ptr + length * elem_size(cx, t) > len(cx.opts.memory))
    self.cx = cx
    self.t = t
    self.ptr = ptr
    self.progress = 0
    self.length = length

  def remain(self):
    return self.length - self.progress

class ReadableGuestBuffer(GuestBuffer, ReadableBuffer):
  def read(self, n):
    assert(n <= self.remain())
    if self.t:
      vs = load_list_from_valid_range(self.cx, self.ptr, n, self.t)
      self.ptr += n * elem_size(self.cx, self.t)
    else:
      vs = n * [()]
    self.progress += n
    return vs

class WritableGuestBuffer(GuestBuffer, WritableBuffer):
  def write(self, vs):
    assert(len(vs) <= self.remain())
    if self.t:
      store_list_into_valid_range(self.cx, vs, self.ptr, self.t)
      self.ptr += len(vs) * elem_size(self.cx, self.t)
    else:
      assert(all(v == () for v in vs))
    self.progress += len(vs)
```
As with `load_list_from_range` below, the alignment and range checks are
performed even when `length` is `0`. When `t` is `None` (arising from `stream`
and `future` with empty element types), the core-wasm-supplied `ptr` is
entirely ignored, while the `length` and `progress` are still semantically
meaningful. Source bindings may represent this case with a generic
stream/future of [unit] type or a distinct type that conveys events without
values.

The `load_list_from_valid_range` and `store_list_into_valid_range` functions
that do all the heavy lifting are shared with function parameter/result lifting
and lowering and defined below.


### Stream and Future State

`stream` and `future` types used in function parameters and results are
represented in the Canonical ABI as `i32` indices into the component instance's
`handles` table that refer to the *readable* [end] of a stream or future.
*Writable* ends are never passed across component boundaries and are instead
added directly to the `handles` table, along with a paired readable end, via the
`{stream,future}.new` built-ins. Stream and future readable and writable ends
are represented by 4 concrete classes: `{Readable,Writable}{Stream,Future}End`.
These 4 classes derive from 2 common `{Stream,Future}End` base classes which
themselves derive from a common `End` base class.

The `End` base class derives from `Waitable`, which means that stream and future
ends can be added to waitable sets and waited on via `waitable-set.wait` or the
`callback` event loop. Each `End` maintains its own independent state that
reflects what *that end* is currently doing or has done and is used to enforce
that each end upholds its respective end of the stream/future control-flow
communication protocol.
```python
class End(Waitable):
  class State(Enum):
    IDLE = 1
    COPYING = 2
    CANCELLING_COPY = 3
    DONE = 4

  t: ValType
  state: State
  other: Optional[End]
  buffer: Optional[Buffer]
  owner: Optional[ComponentInstance]
  index: Optional[int]
  event_code: EventCode

  def __init__(self, t, owner, event_code):
    Waitable.__init__(self)
    self.t = t
    self.state = End.State.IDLE
    self.other = None
    self.buffer = None
    self.owner = owner
    self.index = None
    self.event_code = event_code
```
Going through each of these fields:
* `t`: the (immutable) `t` in `stream<t>` or `future<t>`; needed for the dynamic
  type checks performed when dereferencing untyped `i32` indices.
* `state`: one of 4 states enumerated above whose meaning is described below.
* `other`: the readable/writable end paired with this writable/readable end;
  if `None`, the other end has been dropped.
* `buffer`: while a `{stream,future}.{read,write}` is in progress, the
  linear-memory buffer region passed by the call; `buffer.remain() == 0` means a
  pending [zero-length read or write][Stream Readiness].
* `owner`: each stream/future end must be uniquely owned by either the host or a
  single component instance; `owner` tracks which one, with `None` meaning "the
  host".
* `index`: if `owner` is non-`None`, the `i32` index of this end in the
  component instance's `handles` table; only needed to deliver progress events
  returned from `waitable-set.wait` et al.
* `event_code`: (immutably) one of `EventCode.{STREAM,FUTURE}_{READ,WRITE}`;
  only needed to deliver progress events.

The `End.copy` method is called by `{Readable,Writable}{Stream,Future}End.copy`
below given their `{Writable,Readable}Buffer` and a boolean `is_read` flag
indicating which one is calling. As shown in the code below, there are 5
relevant cases that need to be handled. Because the `future.{read,write}`
built-ins have no explicit length parameter and thus always implicitly create a
buffer of length `1`, the second half of case `3` and cases `4` and `5` do not
apply to futures. Enumerating the cases in the order that they are handled in
the code below:
1. The other end was racily dropped before this end could be notified, in which
   case `End.drop` already left a pending event and so there's nothing to do.
2. The other end has not currently provided a buffer, in which case this end
   must block until the other end shows up with a buffer.
3. Both this and the other end have provided buffers that can copy at least 1
   element, in which case the maximal amount is copied, notifying both sides of
   the progress and leaving the other end's buffer pending if it has more
   remaining.
4. The other end is performing a zero-length `stream.{read,write}`, in which
   case the other end is notified if this end's buffer is non-zero-length *or*
   this end is performing a `read` (since, as part of how [stream readiness]
   works, writes are always asymmetrically notified in a both-zero-length
   rendezvous).
5. Otherwise, this end must be doing a zero-length `stream.{read,write}` (where,
   in the case of a `read`, the corresponding `write` buffer is
   non-zero-length), in which case the call immediately returns `COMPLETED` with
   no elements copied.

```python
  def copy(self, buffer: Buffer, is_read: bool):
    assert(self.buffer is None)
    self.state = End.State.COPYING
    if self.other is None:
      assert(self.has_pending_event())
    elif self.other.buffer is None:
      self.buffer = buffer
    else:
      trap_if(self.owner and self.owner is self.other.owner and not none_or_number_type(self.t))
      if buffer.remain() > 0 and self.other.buffer.remain() > 0:
        n = min(buffer.remain(), self.other.buffer.remain())
        if is_read:
          buffer.write(self.other.buffer.read(n))
        else:
          self.other.buffer.write(buffer.read(n))
        self.notify(buffer.progress)
        self.other.notify(self.other.buffer.progress)
        if self.other.buffer.remain() == 0:
          self.other.buffer = None
      elif buffer.remain() > 0 or (is_read and self.other.buffer.remain() == 0):
        self.other.notify(progress = 0)
        self.other.buffer = None
        self.buffer = buffer
      else:
        self.notify(progress = 0)
```
As a temporary measure (until [lazy lowering] obviates the problem), there is
also a trap when both the `read` and `write` come from the same component
instance and there is a non-empty, non-number element type. The reason for this
trap is that when lifting and lowering can alias the same memory, the eager
interleaving semantics of copying compound values would otherwise be complex to
precisely specify and implement. The trap is checked whenever both ends have
provided a buffer (cases 3, 4 and 5), even if no elements end up being copied,
so that whether a trap occurs doesn't depend on the buffer lengths.

The `End.cancel` method is called by `{stream,future}.cancel-{read,write}` to
transition an end from `COPYING` (set by `End.copy` above) to `CANCELLING_COPY`.
The pending event conditionally set by `notify` is immediately delivered by
`canon_{stream,future}_cancel_{read,write}` below and prevents the built-in from
returning `BLOCKED`. If there is already a pending event, it is not overwritten,
as this might lose the previous `progress` argument. As reflected in the second
conjunct of the condition: (currently) only a host-owned end has the
nondeterministic option to block copy cancellation. When cancellation blocks,
the host takes responsibility for manually calling `notify` if and when the host
determines that the cancellation has completed. This enables the host to
efficiently use [completion-based][OIO] [APIs][io_uring] with asynchronous
cancellation. In the future, guest components may be given the same capability.
```python
  def cancel(self):
    assert(self.state == End.State.COPYING)
    self.state = End.State.CANCELLING_COPY
    if (not self.has_pending_event()
        and (self.other.owner is not None
             or DETERMINISTIC_PROFILE
             or random.randint(0,1))):
      self.notify(progress = 0)
```

The `End.forward` function is called by `{stream,future}.forward` to efficiently
forward all the values from a given readable end into a given writable end,
propagating `DROPPED` results in both directions. This causes the given readable
end and writable end to disappear, leaving only the `other` writable and
readable ends, which are now linked together directly to form a single stream or
future. If *both* of these formerly-separate ends have pending copy operations
with pending `buffer`s, the forwarding operation performs a synchronous copy,
leaving at most one pending buffer (the bigger of the two) and notifying one or
both sides of the progress made. In the corner case where a stream or future's
readable end is forwarded to its own writable end (creating a trivial recursive
loop), there is no trap since the whole thing simply disappears.
```python
  def forward(src: End, dst: End):
    if src.other is dst or src.other is None or dst.other is None:
      src.drop()
      dst.drop()
    else:
      writable_end = src.other
      readable_end = dst.other
      writable_end.other = readable_end
      readable_end.other = writable_end
      if writable_end.buffer is not None and readable_end.buffer is not None:
        if readable_end.buffer.remain() > writable_end.buffer.remain():
          bigger_end, smaller_end = readable_end, writable_end
        else:
          bigger_end, smaller_end = writable_end, readable_end
        buffer = smaller_end.buffer
        smaller_end.buffer = None
        smaller_end.copy(buffer)
```

The `End.drop` method is called by `{stream,future}.drop-{readable,writable}`
and `End.forward` to update the `other` end's state and possibly set a pending
notification for the other end, if the other end isn't already `DONE` and doing
so wouldn't clobber an already-pending notification.
```python
  def drop(self):
    assert(not self.copying_or_cancelling())
    if self.other is not None:
      assert(self is self.other.other)
      self.other.other = None
      if self.other.state != End.State.DONE and not self.other.has_pending_event():
        self.other.notify(progress = 0)
      self.other = None
    Waitable.drop(self)

  def copying_or_cancelling(self):
    return self.state in { End.State.COPYING, End.State.CANCELLING_COPY }
```

Next, the intermediate `{Stream,Future}End` base classes are defined to implement
the `notify` method that is called by the `End.{copy,cancel,drop}` methods
above. `notify`'s behavior does not exhibit the same symmetry as the other `End`
methods above, which is why it is pushed down into stream- and future-specific
classes. `{Stream,Future}End.notify` both define closures that return a
`CopyResult` code saying what happened:
```python
class CopyResult(IntEnum):
  COMPLETED = 0
  DROPPED = 1
  CANCELLED = 2
```
The `DROPPED` code indicates that the `other` end has since been dropped and
thus no more reads/writes are possible. The `CANCELLED` code is only possible
after *this* end has performed a `{stream,future}.{read,write}` followed by a
`{stream,future}.cancel-{read,write}`; `CANCELLED` notifies the wasm code that
the cancellation finished and so ownership of the memory buffer has been
returned to the wasm code. Lastly, `COMPLETED` indicates that the copy is done
and neither `DROPPED` nor `CANCELLED` apply.

`StreamEnd.notify` sets a pending `stream_event` closure on the current `End`
(which is a `Waitable`) that may be delivered either synchronously (calling
`stream_event` during `stream.{cancel-,}{read,write}`) or asynchronously
(calling `stream_event` from `waitable-set.{wait,poll}` or the `callback` event
loop). In either case, the call to `stream_event` happens "right before" wasm
code runs and thus defines state transitions that are only observable once an
event is *delivered* to core wasm (not just *set pending*). In particular, a
stream end doesn't officially transition to the `DONE` or `IDLE` states (as used
to gate various `stream.*` built-in calls) until wasm code is notified of the
corresponding result. In computing the `CopyResult` returned to wasm code,
`CANCELLED` takes precedence over `COMPLETED` and `DROPPED` takes precedence
over the other two. Finally, `CopyResult` is packed into an `i32` along with the
total number of elements that have been copied to/from the supplied `buffer`.
```python
class StreamEnd(End):
  def notify(self, progress):
    def stream_event():
      self.buffer = None
      if self.other is None:
        assert(self.state != End.State.DONE)
        result = CopyResult.DROPPED
        self.state = End.State.DONE
      elif self.state == End.State.CANCELLING_COPY:
        result = CopyResult.CANCELLED
        self.state = End.State.IDLE
      else:
        assert(self.state == End.State.COPYING)
        result = CopyResult.COMPLETED
        self.state = End.State.IDLE
      assert(0 <= result < 2**4)
      assert(progress <= Buffer.MAX_LENGTH < 2**28)
      packed_result = result | (progress << 4)
      return (self.event_code, self.index, packed_result)
    Waitable.set_pending_event(self, stream_event)
```

`FutureEnd.notify` is similar to `StreamEnd.notify`, but with two key
differences. First, the number of elements copied (which is either `0` or `1`)
is not packed into the high bits since it's always implied by the `CopyResult`.
Second, future ends immediately transition to the `DONE` state (where the only
valid operation is to call `future.drop-{readable,writable}`) when delivering
*both* `DROPPED` and `COMPLETED` results (unlike streams, which only transition
to `DONE` after delivering a `DROPPED` result).
```python
class FutureEnd(End):
  def notify(self, progress):
    assert(0 <= progress <= 1)
    def future_event():
      if progress == 1:
        assert(self.copying_or_cancelling())
        assert(self.buffer is None)
        self.state = End.State.DONE
        result = CopyResult.COMPLETED
      elif self.other is None:
        assert(self.state != End.State.DONE)
        self.buffer = None
        self.state = End.State.DONE
        result = CopyResult.DROPPED
      else:
        assert(self.state == End.State.CANCELLING_COPY)
        self.buffer = None
        self.state = End.State.IDLE
        result = CopyResult.CANCELLED
      return (self.event_code, self.index, result)
    Waitable.set_pending_event(self, future_event)
```
Juxtaposing the two `{stream,future}_event` functions, we can see that the
"precedence" of `CopyResult`s for streams is `DROPPED` > `CANCELLED` >
`COMPLETED` whereas for futures the precedence is `COMPLETED` > `DROPPED` >
`CANCELLED`. This priority of `COMPLETED` reflects the fact that, for futures,
`COMPLETED` conveys more essential information.

Lastly, the 4 concrete `{Readable,Writable}{Stream,Future}End` classes are
trivially defined by fixing the `is_read` argument of `copy`. Given these 4
classes, the top-level `new_{stream,future}` functions (that are called by the
`{stream,future}.new` built-ins as well as by the host to create host streams
and futures) show that "streams" and "futures" are really just pairs of readable
and writable ends linked together.
```python
class ReadableStreamEnd(StreamEnd):
  def copy(self, dst: WritableBuffer):
    End.copy(self, dst, is_read = True)

class WritableStreamEnd(StreamEnd):
  def copy(self, src: ReadableBuffer):
    End.copy(self, src, is_read = False)

class ReadableFutureEnd(FutureEnd):
  def copy(self, dst: WritableBuffer):
    End.copy(self, dst, is_read = True)

class WritableFutureEnd(FutureEnd):
  def copy(self, src: ReadableBuffer):
    End.copy(self, src, is_read = False)

def new_stream(t: ValType, owner: Optional[ComponentInstance]):
  reader = ReadableStreamEnd(t, owner, EventCode.STREAM_READ)
  writer = WritableStreamEnd(t, owner, EventCode.STREAM_WRITE)
  reader.other = writer
  writer.other = reader
  return (reader, writer)

def new_future(t, owner: Optional[ComponentInstance]):
  reader = ReadableFutureEnd(t, owner, EventCode.FUTURE_READ)
  writer = WritableFutureEnd(t, owner, EventCode.FUTURE_WRITE)
  reader.other = writer
  writer.other = reader
  return (reader, writer)
```


## Despecialization

[In the explainer][Type Definitions], component value types are classified as
either *fundamental* or *specialized*, where the specialized value types are
defined by expansion into fundamental value types. In most cases, the canonical
ABI of a specialized value type is the same as its expansion so, to avoid
repetition, the other definitions below use the following `despecialize`
function to replace specialized value types with their expansion:
```python
def despecialize(t):
  match t:
    case TupleType(ts)       : return RecordType([ FieldType(str(i), t) for i,t in enumerate(ts) ])
    case EnumType(labels)    : return VariantType([ CaseType(l, None) for l in labels ])
    case OptionType(t)       : return VariantType([ CaseType("none", None), CaseType("some", t) ])
    case ResultType(ok, err) : return VariantType([ CaseType("ok", ok), CaseType("error", err) ])
    case MapType(k, v)       : return ListType(despecialize(TupleType([k, v])))
    case _                   : return t
```
The specialized value types `string` and `flags` are missing from this list
because they are given specialized canonical ABI representations distinct from
their respective expansions.


## Type Predicates

The `contains_borrow` and `contains_async_value` predicates return whether the
given type contains a `borrow` or `future`/`stream`, respectively.
```python
def contains_borrow(t):
  return contains(t, lambda u: isinstance(u, BorrowType))

def contains_async_value(t):
  return contains(t, lambda u: isinstance(u, StreamType | FutureType))

def contains(t, p):
  t = despecialize(t)
  match t:
    case None:
      return False
    case PrimValType() | OwnType() | BorrowType():
      return p(t)
    case ListType(u) | StreamType(u) | FutureType(u):
      return p(t) or contains(u, p)
    case RecordType(fields):
      return p(t) or any(contains(f.t, p) for f in fields)
    case VariantType(cases):
      return p(t) or any(contains(c.t, p) for c in cases)
    case FuncType():
      return any(p(u) for u in t.param_types() + t.result_type())
    case _:
      assert(False)
```

The `none_or_number_type` predicate is used above for the temporary
same-instance stream/future copy restriction:
```python
def none_or_number_type(t):
  return t is None or isinstance(t, U8Type | U16Type | U32Type | U64Type |
                                    S8Type | S16Type | S32Type | S64Type |
                                    F32Type | F64Type)
```

## Alignment

Each value type is assigned an [alignment] which is used by subsequent
Canonical ABI definitions. Presenting the definition of `alignment` piecewise,
we start with the top-level case analysis:
```python
def alignment(cx, t):
  match despecialize(t):
    case BoolType()                  : return 1
    case S8Type() | U8Type()         : return 1
    case S16Type() | U16Type()       : return 2
    case S32Type() | U32Type()       : return 4
    case S64Type() | U64Type()       : return 8
    case F32Type()                   : return 4
    case F64Type()                   : return 8
    case CharType()                  : return 4
    case StringType()                : return cx.opts.memory.ptr_size()
    case ErrorContextType()          : return 4
    case ListType(t, l)              : return alignment_list(cx, t, l)
    case RecordType(fields)          : return alignment_record(cx, fields)
    case VariantType(cases)          : return alignment_variant(cx, cases)
    case FlagsType(labels)           : return alignment_flags(labels)
    case OwnType()                   : return 4
    case BorrowType()                : return alignment_borrow(cx, t)
    case StreamType() | FutureType() : return 4
```

List alignment is the same as tuple alignment when the length is fixed and
otherwise uses the alignment of pointers.
```python
def alignment_list(cx, elem_type, maybe_length):
  if maybe_length is not None:
    return alignment(cx, elem_type)
  else:
    return cx.opts.memory.ptr_size()
```

Record alignment is tuple alignment, with the definitions split for reuse below:
```python
def alignment_record(cx, fields):
  a = 1
  for f in fields:
    a = max(a, alignment(cx, f.t))
  return a
```

As an optimization, `variant` discriminants are represented by the smallest integer
covering the number of cases in the variant (with cases numbered in order from
`0` to `len(cases)-1`). Depending on the payload type, this can allow more
compact representations of variants in memory. This smallest integer type is
selected by the following function, used above and below:
```python
def alignment_variant(cx, cases):
  return max(alignment(cx, discriminant_type(cases)), max_case_alignment(cx, cases))

def discriminant_type(cases):
  n = len(cases)
  assert(0 < n < (1 << 32))
  match math.ceil(math.log2(n)/8):
    case 0: return U8Type()
    case 1: return U8Type()
    case 2: return U16Type()
    case 3: return U32Type()

def max_case_alignment(cx, cases):
  a = 1
  for c in cases:
    if c.t is not None:
      a = max(a, alignment(cx, c.t))
  return a
```

As an optimization, `flags` are represented as packed bit-vectors. Like variant
discriminants, `flags` use the smallest integer that fits all the bits.
```python
def alignment_flags(labels):
  n = len(labels)
  assert(0 < n <= 32)
  if n <= 8: return 1
  if n <= 16: return 2
  return 4
```

As an optimization in `store_borrow` and `lower_flat_borrow` (defined below),
when a `(borrow $R)` handle is lowered into the component that defined `$R`, the
resource's representation value is passed instead of the `i32` handle index and
thus alignment depends on the resource's `(rep $t)`.
```python
def alignment_borrow(cx, t):
  if cx.inst is t.rt.impl and cx.direction == 'lower':
    return ptr_size(t.rt.rep)
  else:
    return 4
```


## Element Size

Each value type is also assigned an `elem_size` which is the number of bytes
used when values of the type are stored as elements of a `list`. Having this
byte size be a static property of the type instead of attempting to use a
variable-length element-encoding scheme both simplifies the implementation and
maps well to languages which represent `list`s as random-access arrays. Empty
types, such as records with no fields, are not permitted, to avoid
complications in source languages. To prevent integer overflow in obscure corner
cases, component validation rules require that for every value type `t` defined
by a component and every possible `cx`, `elem_size(cx, t)` is less than
2<sup>28</sup> (the same upper bound as `MAX_LIST_BYTE_LENGTH`).
```python
def elem_size(cx, t):
  match despecialize(t):
    case BoolType()                  : return 1
    case S8Type() | U8Type()         : return 1
    case S16Type() | U16Type()       : return 2
    case S32Type() | U32Type()       : return 4
    case S64Type() | U64Type()       : return 8
    case F32Type()                   : return 4
    case F64Type()                   : return 8
    case CharType()                  : return 4
    case StringType()                : return 2 * cx.opts.memory.ptr_size()
    case ErrorContextType()          : return 4
    case ListType(t, l)              : return elem_size_list(cx, t, l)
    case RecordType(fields)          : return elem_size_record(cx, fields)
    case VariantType(cases)          : return elem_size_variant(cx, cases)
    case FlagsType(labels)           : return elem_size_flags(labels)
    case OwnType()                   : return 4
    case BorrowType()                : return elem_size_borrow(cx, t)
    case StreamType() | FutureType() : return 4

def elem_size_list(cx, elem_type, maybe_length):
  if maybe_length is not None:
    return maybe_length * elem_size(cx, elem_type)
  else:
    return 2 * cx.opts.memory.ptr_size()

def elem_size_record(cx, fields):
  s = 0
  for f in fields:
    s = align_to(s, alignment(cx, f.t))
    s += elem_size(cx, f.t)
  assert(s > 0)
  return align_to(s, alignment_record(cx, fields))

def align_to(ptr, alignment):
  return math.ceil(ptr / alignment) * alignment

def elem_size_variant(cx, cases):
  s = elem_size(cx, discriminant_type(cases))
  s = align_to(s, max_case_alignment(cx, cases))
  cs = 0
  for c in cases:
    if c.t is not None:
      cs = max(cs, elem_size(cx, c.t))
  s += cs
  return align_to(s, alignment_variant(cx, cases))

def elem_size_flags(labels):
  n = len(labels)
  assert(0 < n <= 32)
  if n <= 8: return 1
  if n <= 16: return 2
  return 4

def elem_size_borrow(cx, t):
  if cx.inst is t.rt.impl and cx.direction == 'lower':
    return ptr_size(t.rt.rep)
  else:
    return 4
```

## Loading

The `load` function defines how to read a value of a given value type `t`
out of linear memory starting at offset `ptr`, returning the value represented
as a Python value. Presenting the definition of `load` piecewise, we start with
the top-level case analysis:
```python
def load(cx, ptr, t):
  assert(ptr == align_to(ptr, alignment(cx, t)))
  assert(ptr + elem_size(cx, t) <= len(cx.opts.memory))
  match despecialize(t):
    case BoolType()         : return convert_int_to_bool(load_int(cx, ptr, 1))
    case U8Type()           : return load_int(cx, ptr, 1)
    case U16Type()          : return load_int(cx, ptr, 2)
    case U32Type()          : return load_int(cx, ptr, 4)
    case U64Type()          : return load_int(cx, ptr, 8)
    case S8Type()           : return load_int(cx, ptr, 1, signed = True)
    case S16Type()          : return load_int(cx, ptr, 2, signed = True)
    case S32Type()          : return load_int(cx, ptr, 4, signed = True)
    case S64Type()          : return load_int(cx, ptr, 8, signed = True)
    case F32Type()          : return decode_i32_as_float(load_int(cx, ptr, 4))
    case F64Type()          : return decode_i64_as_float(load_int(cx, ptr, 8))
    case CharType()         : return convert_i32_to_char(cx, load_int(cx, ptr, 4))
    case StringType()       : return load_string(cx, ptr)
    case ErrorContextType() : return lift_error_context(cx, load_int(cx, ptr, 4))
    case ListType(t, l)     : return load_list(cx, ptr, t, l)
    case RecordType(fields) : return load_record(cx, ptr, fields)
    case VariantType(cases) : return load_variant(cx, ptr, cases)
    case FlagsType(labels)  : return load_flags(cx, ptr, labels)
    case OwnType()          : return lift_own(cx, load_int(cx, ptr, 4), t)
    case BorrowType()       : return lift_borrow(cx, load_int(cx, ptr, 4), t)
    case StreamType(t)      : return lift_stream(cx, load_int(cx, ptr, 4), t)
    case FutureType(t)      : return lift_future(cx, load_int(cx, ptr, 4), t)
```

Integers are loaded directly from memory, with their high-order bit interpreted
according to the signedness of the type.
```python
def load_int(cx, ptr, nbytes, signed = False):
  return int.from_bytes(cx.opts.memory[ptr : ptr+nbytes], 'little', signed = signed)
```

Integer-to-boolean conversions treats `0` as `false` and all other bit-patterns
as `true`:
```python
def convert_int_to_bool(i):
  assert(i >= 0)
  return bool(i)
```

Floats are loaded directly from memory, with the sign and payload information
of NaN values discarded. Consequently, there is only one unique NaN value per
floating-point type. This reflects the practical reality that some languages
and protocols do not preserve these bits. In the Python code below, this is
expressed as canonicalizing NaNs to a particular bit pattern.

See the comments about lowering of float values for a discussion of possible
optimizations.
```python
DETERMINISTIC_PROFILE = False # or True
CANONICAL_FLOAT32_NAN = 0x7fc00000
CANONICAL_FLOAT64_NAN = 0x7ff8000000000000

def canonicalize_nan32(f):
  if math.isnan(f):
    f = core_f32_reinterpret_i32(CANONICAL_FLOAT32_NAN)
    assert(math.isnan(f))
  return f

def canonicalize_nan64(f):
  if math.isnan(f):
    f = core_f64_reinterpret_i64(CANONICAL_FLOAT64_NAN)
    assert(math.isnan(f))
  return f

def decode_i32_as_float(i):
  return canonicalize_nan32(core_f32_reinterpret_i32(i))

def decode_i64_as_float(i):
  return canonicalize_nan64(core_f64_reinterpret_i64(i))

def core_f32_reinterpret_i32(i):
  return struct.unpack('<f', struct.pack('<I', i))[0] # f32.reinterpret_i32

def core_f64_reinterpret_i64(i):
  return struct.unpack('<d', struct.pack('<Q', i))[0] # f64.reinterpret_i64
```

An `i32` is converted to a `char` (a [Unicode Scalar Value]) by dynamically
testing that its unsigned integral value is in the valid [Unicode Code Point]
range and not a [Surrogate]:
```python
def convert_i32_to_char(cx, i):
  assert(i >= 0)
  trap_if(i >= 0x110000)
  trap_if(0xD800 <= i <= 0xDFFF)
  return chr(i)
```

Strings are loaded from two pointer-sized values: a pointer (offset in linear
memory) and a number of [code units]. There are three supported string encodings
in [`canonopt`]: [UTF-8], [UTF-16] and `latin1+utf16`. This last option allows a
*dynamic* choice between [Latin-1] and UTF-16, indicated by the high bit of the
second pointer-sized value (32nd bit on 32-bit memories, 64th bit on 64-bit
memories). String values include their original encoding and length in tagged
code units as a "hint" that enables `store_string` (defined below) to make
better up-front allocation size choices in many cases. Thus, the value produced
by `load_string` isn't simply a Python `str`, but a *tuple* containing a `str`,
the original encoding and the number of source code units.

The `MAX_STRING_BYTE_LENGTH` constant limits the byte length of a string when
loading. This limit is low enough to ensure that when storing the string via
`store_string`, the number of bytes allocated stays below `REALLOC_I32_MAX` even
when converting to other encodings. This means that any loaded string will be
short enough to be stored in 32-bit components. The worst case inflation in
string byte length is by a factor of 2 (e.g. this could occur when converting
from [UTF-8] to [UTF-16]).
```python
String = tuple[str, str, int]

def load_string(cx, ptr) -> String:
  ptr_size = cx.opts.memory.ptr_size()
  begin = load_int(cx, ptr, ptr_size)
  tagged_code_units = load_int(cx, ptr + ptr_size, ptr_size)
  return load_string_from_range(cx, begin, tagged_code_units)

def utf16_tag(cx):
  return 1 << (cx.opts.memory.ptr_size() * 8 - 1)

REALLOC_I32_MAX = 2**32 - 1
MAX_STRING_BYTE_LENGTH = (1 << 28) - 1
assert(REALLOC_I32_MAX > 2 * MAX_STRING_BYTE_LENGTH)

def load_string_from_range(cx, ptr, tagged_code_units) -> String:
  tag = utf16_tag(cx)
  match cx.opts.string_encoding:
    case 'utf8':
      alignment = 1
      byte_length = tagged_code_units
      encoding = 'utf-8'
    case 'utf16':
      alignment = 2
      byte_length = 2 * tagged_code_units
      encoding = 'utf-16-le'
    case 'latin1+utf16':
      alignment = 2
      if bool(tagged_code_units & tag):
        byte_length = 2 * (tagged_code_units ^ tag)
        encoding = 'utf-16-le'
      else:
        byte_length = tagged_code_units
        encoding = 'latin-1'

  trap_if(byte_length > MAX_STRING_BYTE_LENGTH)
  trap_if(ptr != align_to(ptr, alignment))
  trap_if(ptr + byte_length > len(cx.opts.memory))
  try:
    s = cx.opts.memory[ptr : ptr+byte_length].decode(encoding)
  except UnicodeError:
    trap()

  return (s, cx.opts.string_encoding, tagged_code_units)
```

Error context values are lifted directly from the current component instance's
`handles` table:
```python
def lift_error_context(cx, i):
  errctx = cx.inst.handles.get(i)
  trap_if(not isinstance(errctx, ErrorContext))
  return errctx
```

Lists and records are loaded by recursively loading their elements/fields. The
byte length of a list is limited to `MAX_LIST_BYTE_LENGTH` which, similar to
`MAX_STRING_BYTE_LENGTH`, keeps list lengths well below the 32-bit address space
limit. The worst case inflation of a list length in bytes is by a factor of 2
(which could occur when pointer sizes increase from 4 to 8 bytes) so
`MAX_LIST_BYTE_LENGTH` is small enough that the byte length passed to `realloc`
stays below `REALLOC_I32_MAX` even when doubled.
```python
MAX_LIST_BYTE_LENGTH = (1 << 28) - 1
assert(REALLOC_I32_MAX > 2 * MAX_LIST_BYTE_LENGTH)

def load_list(cx, ptr, elem_type, maybe_length):
  if maybe_length is not None:
    return load_list_from_valid_range(cx, ptr, maybe_length, elem_type)
  ptr_size = cx.opts.memory.ptr_size()
  begin = load_int(cx, ptr, ptr_size)
  length = load_int(cx, ptr + ptr_size, ptr_size)
  return load_list_from_range(cx, begin, length, elem_type)

def load_list_from_range(cx, ptr, length, elem_type):
  trap_if(length * elem_size(cx, elem_type) > MAX_LIST_BYTE_LENGTH)
  trap_if(ptr != align_to(ptr, alignment(cx, elem_type)))
  trap_if(ptr + length * elem_size(cx, elem_type) > len(cx.opts.memory))
  return load_list_from_valid_range(cx, ptr, length, elem_type)

def load_list_from_valid_range(cx, ptr, length, elem_type):
  a = []
  for i in range(length):
    a.append(load(cx, ptr + i * elem_size(cx, elem_type), elem_type))
  return a

def load_record(cx, ptr, fields):
  record = {}
  for field in fields:
    ptr = align_to(ptr, alignment(cx, field.t))
    record[field.label] = load(cx, ptr, field.t)
    ptr += elem_size(cx, field.t)
  return record
```
As a technical detail: the `align_to` in the loop in `load_record` is
guaranteed to be a no-op on the first iteration because the record as
a whole starts out aligned (as asserted at the top of `load`).

Variants are loaded using the order of the cases in the type to determine the
case index, assigning `0` to the first case, `1` to the next case, etc.
While the code below appears to perform case-label lookup at runtime, a normal
implementation can build the appropriate index tables at compile-time so that
variant-passing is always O(1) and not involving string operations.
```python
def load_variant(cx, ptr, cases):
  disc_size = elem_size(cx, discriminant_type(cases))
  case_index = load_int(cx, ptr, disc_size)
  ptr += disc_size
  trap_if(case_index >= len(cases))
  c = cases[case_index]
  ptr = align_to(ptr, max_case_alignment(cx, cases))
  if c.t is None:
    return { c.label: None }
  return { c.label: load(cx, ptr, c.t) }
```

Flags are converted from a bit-vector to a dictionary whose keys are
derived from the ordered labels of the `flags` type. The code here takes
advantage of Python's support for integers of arbitrary width.
```python
def load_flags(cx, ptr, labels):
  i = load_int(cx, ptr, elem_size_flags(labels))
  return unpack_flags_from_int(i, labels)

def unpack_flags_from_int(i, labels):
  record = {}
  for l in labels:
    record[l] = bool(i & 1)
    i >>= 1
  return record
```

`own` handles are lifted by removing the handle from the current component
instance's `handles` table so that ownership is *transferred* to the lowering
component.  The lifting operation fails if unique ownership of the handle isn't
possible, for example if the index was actually a `borrow` or if the `own`
handle is currently being lent out as borrows.
```python
def lift_own(cx, i, t):
  h = cx.inst.handles.remove(i)
  trap_if(not isinstance(h, ResourceHandle))
  trap_if(h.rt is not t.rt)
  trap_if(h.num_lends != 0)
  trap_if(not h.own)
  return h.rep
```
The abstract lifted value for handle types is currently just the internal
resource representation `i32`, which is kept opaque from the receiving
component (it's stored in the `handles` table and only accessed indirectly via
index). (This assumes that resource representations are immutable. If
representations were to become mutable, the address of the mutable cell would
be passed as the lifted value instead.)

In contrast to `own`, `borrow` handles are lifted by reading the representation
from the source handle, leaving the source handle intact in the current
component instance's `handles` table:
```python
def lift_borrow(cx, i, t):
  assert(isinstance(cx.borrow_scope, Subtask))
  h = cx.inst.handles.get(i)
  trap_if(not isinstance(h, ResourceHandle))
  trap_if(h.rt is not t.rt)
  cx.borrow_scope.add_lender(h)
  return h.rep
```
The `Subtask.add_lender` participates in the enforcement of the dynamic borrow
rules, which keep the source handle alive until the end of the call (as a
conservative upper bound on how long the `borrow` handle can be held). Note
that `add_lender` is called for borrowed source handles so that they must be
kept alive until the subtask completes, which in turn prevents the [current task]
from `task.return`ing while its non-returned subtask still holds a
transitively-borrowed handle.

Streams and futures are entirely symmetric, transferring ownership of the
readable end from the lifting component to the host or lowering component and
trapping if the readable end is in the middle of copying (which would create a
dangling-pointer situation) or is in the `DONE` state (in which case the only
valid operation is `{stream,future}.drop-{readable,writable}`) or in a waitable
set (in which case it must be removed first via `waitable.join(0)`). By clearing
the `owner` and `index` fields, the end becomes officially owned by the host. If
the lifted `End` is then passed into another component, `lower_async_value` will
transition ownership from the host into the receiving component instance.
```python
def lift_stream(cx, i, t):
  return lift_async_value(ReadableStreamEnd, cx, i, t)

def lift_future(cx, i, t):
  return lift_async_value(ReadableFutureEnd, cx, i, t)

def lift_async_value(ReadableEndT, cx, i, t):
  assert(not contains_borrow(t))
  end = cx.inst.handles.remove(i)
  trap_if(not isinstance(end, ReadableEndT))
  trap_if(end.t != t)
  trap_if(end.state != End.State.IDLE)
  trap_if(end.in_waitable_set())
  assert(end.owner is cx.inst and end.index == i)
  end.owner = None
  end.index = None
  return end
```


## Storing

The `store` function defines how to write a value `v` of a given value type
`t` into linear memory starting at offset `ptr`. Presenting the definition of
`store` piecewise, we start with the top-level case analysis:
```python
def store(cx, v, t, ptr):
  assert(ptr == align_to(ptr, alignment(cx, t)))
  assert(ptr + elem_size(cx, t) <= len(cx.opts.memory))
  match despecialize(t):
    case BoolType()         : store_int(cx, int(bool(v)), ptr, 1)
    case U8Type()           : store_int(cx, v, ptr, 1)
    case U16Type()          : store_int(cx, v, ptr, 2)
    case U32Type()          : store_int(cx, v, ptr, 4)
    case U64Type()          : store_int(cx, v, ptr, 8)
    case S8Type()           : store_int(cx, v, ptr, 1, signed = True)
    case S16Type()          : store_int(cx, v, ptr, 2, signed = True)
    case S32Type()          : store_int(cx, v, ptr, 4, signed = True)
    case S64Type()          : store_int(cx, v, ptr, 8, signed = True)
    case F32Type()          : store_int(cx, encode_float_as_i32(v), ptr, 4)
    case F64Type()          : store_int(cx, encode_float_as_i64(v), ptr, 8)
    case CharType()         : store_int(cx, char_to_i32(v), ptr, 4)
    case StringType()       : store_string(cx, v, ptr)
    case ErrorContextType() : store_int(cx, lower_error_context(cx, v), ptr, 4)
    case ListType(t, l)     : store_list(cx, v, ptr, t, l)
    case RecordType(fields) : store_record(cx, v, ptr, fields)
    case VariantType(cases) : store_variant(cx, v, ptr, cases)
    case FlagsType(labels)  : store_flags(cx, v, ptr, labels)
    case OwnType()          : store_int(cx, lower_own(cx, v, t), ptr, 4)
    case BorrowType()       : store_borrow(cx, v, ptr, t)
    case StreamType(t)      : store_int(cx, lower_stream(cx, v, t), ptr, 4)
    case FutureType(t)      : store_int(cx, lower_future(cx, v, t), ptr, 4)
```

Integers are stored directly into memory. Because the input domain is exactly
the integers in range for the given type, no extra range checks are necessary;
the `signed` parameter is only present to ensure that the internal range checks
of `int.to_bytes` are satisfied.
```python
def store_int(cx, v, ptr, nbytes, signed = False):
  cx.opts.memory[ptr : ptr+nbytes] = int.to_bytes(v, nbytes, 'little', signed = signed)
```

Floats are stored directly into memory, with the sign and payload bits of NaN
values modified nondeterministically. This reflects the practical reality that
different languages, protocols and CPUs have different effects on NaNs.

Although this nondeterminism is expressed in the Python code below as
generating a "random" NaN bit-pattern, native implementations do not need to
use the same "random" algorithm, or even any random algorithm at all. Hosts
may instead chose to canonicalize to an arbitrary fixed NaN value, or even to
the original value of the NaN before lifting, allowing them to optimize away
both the canonicalization of lifting and the randomization of lowering.

When a host implements the [deterministic profile], NaNs are canonicalized to
a particular NaN bit-pattern.
```python
def maybe_scramble_nan32(f):
  if math.isnan(f):
    if DETERMINISTIC_PROFILE:
      f = core_f32_reinterpret_i32(CANONICAL_FLOAT32_NAN)
    else:
      f = core_f32_reinterpret_i32(random_nan_bits(32, 8))
    assert(math.isnan(f))
  return f

def maybe_scramble_nan64(f):
  if math.isnan(f):
    if DETERMINISTIC_PROFILE:
      f = core_f64_reinterpret_i64(CANONICAL_FLOAT64_NAN)
    else:
      f = core_f64_reinterpret_i64(random_nan_bits(64, 11))
    assert(math.isnan(f))
  return f

def random_nan_bits(total_bits, exponent_bits):
  fraction_bits = total_bits - exponent_bits - 1
  bits = random.getrandbits(total_bits)
  bits |= ((1 << exponent_bits) - 1) << fraction_bits
  bits |= 1 << random.randrange(fraction_bits - 1)
  return bits

def encode_float_as_i32(f):
  return core_i32_reinterpret_f32(maybe_scramble_nan32(f))

def encode_float_as_i64(f):
  return core_i64_reinterpret_f64(maybe_scramble_nan64(f))

def core_i32_reinterpret_f32(f):
  return struct.unpack('<I', struct.pack('<f', f))[0] # i32.reinterpret_f32

def core_i64_reinterpret_f64(f):
  return struct.unpack('<Q', struct.pack('<d', f))[0] # i64.reinterpret_f64
```

The integral value of a `char` (a [Unicode Scalar Value]) is a valid unsigned
`i32` and thus no runtime conversion or checking is necessary:
```python
def char_to_i32(c):
  i = ord(c)
  assert(0 <= i <= 0xD7FF or 0xE000 <= i <= 0x10FFFF)
  return i
```

Storing strings is complicated by the goal of attempting to optimize the
different transcoding cases. In particular, one challenge is choosing the
linear memory allocation size *before* examining the contents of the string.
The reason for this constraint is that, in some settings where single-pass
iterators are involved (host calls and post-MVP [adapter functions]), examining
the contents of a string more than once would require making an engine-internal
temporary copy of the whole string, which the component model specifically aims
not to do. To avoid multiple passes, the canonical ABI instead uses a `realloc`
approach to update the allocation size during the single copy. A blind
`realloc` approach would normally suffer from multiple reallocations per string
(e.g., using the standard doubling-growth strategy). However, as already shown
in `load_string` above, string values come with two useful hints: their
original encoding and number of source [code units]. From this hint data,
`store_string` can do a much better job minimizing the number of reallocations.

We start with a case analysis to enumerate all the meaningful encoding
combinations, subdividing the `latin1+utf16` encoding into either `latin1` or
`utf16` based on the `utf16_tag` flag set by `load_string`:
```python
def store_string(cx, v: String, ptr):
  begin, tagged_code_units = store_string_into_range(cx, v)
  ptr_size = cx.opts.memory.ptr_size()
  store_int(cx, begin, ptr, ptr_size)
  store_int(cx, tagged_code_units, ptr + ptr_size, ptr_size)

def store_string_into_range(cx, v: String):
  src, src_encoding, src_tagged_code_units = v
  tag = utf16_tag(cx)

  if src_encoding == 'latin1+utf16':
    if bool(src_tagged_code_units & tag):
      src_simple_encoding = 'utf16'
      src_code_units = src_tagged_code_units ^ tag
    else:
      src_simple_encoding = 'latin1'
      src_code_units = src_tagged_code_units
  else:
    src_simple_encoding = src_encoding
    src_code_units = src_tagged_code_units

  match cx.opts.string_encoding:
    case 'utf8':
      match src_simple_encoding:
        case 'utf8'         : return store_string_copy(cx, src, src_code_units, 1, 1, 'utf-8')
        case 'utf16'        : return store_utf16_to_utf8(cx, src, src_code_units)
        case 'latin1'       : return store_latin1_to_utf8(cx, src, src_code_units)
    case 'utf16':
      match src_simple_encoding:
        case 'utf8'         : return store_utf8_to_utf16(cx, src, src_code_units)
        case 'utf16'        : return store_string_copy(cx, src, src_code_units, 2, 2, 'utf-16-le')
        case 'latin1'       : return store_string_copy(cx, src, src_code_units, 2, 2, 'utf-16-le')
    case 'latin1+utf16':
      match src_encoding:
        case 'utf8'         : return store_string_to_latin1_or_utf16(cx, src, src_code_units)
        case 'utf16'        : return store_string_to_latin1_or_utf16(cx, src, src_code_units)
        case 'latin1+utf16' :
          match src_simple_encoding:
            case 'latin1'   : return store_string_copy(cx, src, src_code_units, 1, 2, 'latin-1')
            case 'utf16'    : return store_probably_utf16_to_latin1_or_utf16(cx, src, src_code_units)
```

The simplest 4 cases above can compute the exact destination size and then copy
with a simply loop (that possibly inflates Latin-1 to UTF-16 by injecting a 0
byte after every Latin-1 byte).
```python
def store_string_copy(cx, src, src_code_units, dst_code_unit_size, dst_alignment, dst_encoding):
  dst_byte_length = dst_code_unit_size * src_code_units
  assert(dst_byte_length <= REALLOC_I32_MAX)
  ptr = cx.allocate(dst_alignment, dst_byte_length)
  encoded = src.encode(dst_encoding)
  assert(dst_byte_length == len(encoded))
  cx.opts.memory[ptr : ptr+len(encoded)] = encoded
  return (ptr, src_code_units)
```
The 2 cases of transcoding into UTF-8 share an algorithm that starts by
optimistically assuming that each code unit of the source string fits in a
single UTF-8 byte and then, failing that, reallocates to a worst-case size,
finishes the copy, and then finishes with a shrinking reallocation.
```python
def store_utf16_to_utf8(cx, src, src_code_units):
  worst_case_size = src_code_units * 3
  return store_string_to_utf8(cx, src, src_code_units, worst_case_size)

def store_latin1_to_utf8(cx, src, src_code_units):
  worst_case_size = src_code_units * 2
  return store_string_to_utf8(cx, src, src_code_units, worst_case_size)

def store_string_to_utf8(cx, src, src_code_units, worst_case_size):
  assert(src_code_units <= REALLOC_I32_MAX)
  ptr = cx.allocate(1, src_code_units)
  for i,code_point in enumerate(src):
    if ord(code_point) < 2**7:
      cx.opts.memory[ptr + i] = ord(code_point)
    else:
      assert(worst_case_size <= REALLOC_I32_MAX)
      ptr = cx.reallocate(ptr, src_code_units, 1, worst_case_size)
      encoded = src.encode('utf-8')
      cx.opts.memory[ptr+i : ptr+len(encoded)] = encoded[i : ]
      if worst_case_size > len(encoded):
        ptr = cx.reallocate(ptr, worst_case_size, 1, len(encoded))
      return (ptr, len(encoded))
  return (ptr, src_code_units)
```

Converting from UTF-8 to UTF-16 performs an initial worst-case size allocation
(assuming each UTF-8 byte encodes a whole code point that inflates into a
two-byte UTF-16 code unit) and then does a shrinking reallocation at the end
if multiple UTF-8 bytes were collapsed into a single 2-byte UTF-16 code unit:
```python
def store_utf8_to_utf16(cx, src, src_code_units):
  worst_case_size = 2 * src_code_units
  assert(worst_case_size <= REALLOC_I32_MAX)
  ptr = cx.allocate(2, worst_case_size)
  encoded = src.encode('utf-16-le')
  cx.opts.memory[ptr : ptr+len(encoded)] = encoded
  if len(encoded) < worst_case_size:
    ptr = cx.reallocate(ptr, worst_case_size, 2, len(encoded))
  code_units = int(len(encoded) / 2)
  return (ptr, code_units)
```

The next transcoding case handles `latin1+utf16` encoding, where there general
goal is to fit the incoming string into Latin-1 if possible based on the code
points of the incoming string. The algorithm speculates that all code points
*do* fit into Latin-1 and then falls back to a worst-case allocation size when
a code point is found outside Latin-1. In this fallback case, the
previously-copied Latin-1 bytes are inflated *in place*, inserting a 0 byte
after every Latin-1 byte (iterating in reverse to avoid clobbering later
bytes):
```python
def store_string_to_latin1_or_utf16(cx, src, src_code_units):
  assert(src_code_units <= REALLOC_I32_MAX)
  ptr = cx.allocate(2, src_code_units)
  dst_byte_length = 0
  for usv in src:
    if ord(usv) < (1 << 8):
      cx.opts.memory[ptr + dst_byte_length] = ord(usv)
      dst_byte_length += 1
    else:
      worst_case_size = 2 * src_code_units
      assert(worst_case_size <= REALLOC_I32_MAX)
      ptr = cx.reallocate(ptr, src_code_units, 2, worst_case_size)
      for j in range(dst_byte_length-1, -1, -1):
        cx.opts.memory[ptr + 2*j] = cx.opts.memory[ptr + j]
        cx.opts.memory[ptr + 2*j + 1] = 0
      encoded = src.encode('utf-16-le')
      cx.opts.memory[ptr+2*dst_byte_length : ptr+len(encoded)] = encoded[2*dst_byte_length : ]
      if worst_case_size > len(encoded):
        ptr = cx.reallocate(ptr, worst_case_size, 2, len(encoded))
      tagged_code_units = int(len(encoded) / 2) | utf16_tag(cx)
      return (ptr, tagged_code_units)
  if dst_byte_length < src_code_units:
    ptr = cx.reallocate(ptr, src_code_units, 2, dst_byte_length)
  return (ptr, dst_byte_length)
```

The final transcoding case takes advantage of the extra heuristic
information that the incoming UTF-16 bytes were intentionally chosen over
Latin-1 by the producer, indicating that they *probably* contain code points
outside Latin-1 and thus *probably* require inflation. Based on this
information, the transcoding algorithm pessimistically allocates storage for
UTF-16, deflating at the end if indeed no non-Latin-1 code points were
encountered. This Latin-1 deflation ensures that if a group of components
are all using `latin1+utf16` and *one* component over-uses UTF-16, other
components can recover the Latin-1 compression. (The Latin-1 check can be
inexpensively fused with the UTF-16 validate+copy loop.)
```python
def store_probably_utf16_to_latin1_or_utf16(cx, src, src_code_units):
  src_byte_length = 2 * src_code_units
  assert(src_byte_length <= REALLOC_I32_MAX)
  ptr = cx.allocate(2, src_byte_length)
  encoded = src.encode('utf-16-le')
  cx.opts.memory[ptr : ptr+len(encoded)] = encoded
  if any(ord(c) >= (1 << 8) for c in src):
    tagged_code_units = int(len(encoded) / 2) | utf16_tag(cx)
    return (ptr, tagged_code_units)
  latin1_size = int(len(encoded) / 2)
  for i in range(latin1_size):
    cx.opts.memory[ptr + i] = cx.opts.memory[ptr + 2*i]
  ptr = cx.reallocate(ptr, src_byte_length, 2, latin1_size)
  return (ptr, latin1_size)
```

Error context values are lowered by storing them directly into the current
component instance's `handles` table and passing the `i32` index to wasm:
```python
def lower_error_context(cx, v):
  return cx.inst.handles.add(v)
```

Lists and records are stored by recursively storing their elements and
are symmetric to the loading functions. Unlike strings, lists can
simply allocate based on the up-front knowledge of length and static
element size. Storing a list that exceeds the size of a 32-bit memory traps even
when storing on 64-bit platform to avoid having interfaces that 32-bit
components can't use.
```python
def store_list(cx, v, ptr, elem_type, maybe_length):
  if maybe_length is not None:
    assert(maybe_length == len(v))
    store_list_into_valid_range(cx, v, ptr, elem_type)
    return
  begin, length = store_list_into_range(cx, v, elem_type)
  ptr_size = cx.opts.memory.ptr_size()
  store_int(cx, begin, ptr, ptr_size)
  store_int(cx, length, ptr + ptr_size, ptr_size)

def store_list_into_range(cx, v, elem_type):
  byte_length = len(v) * elem_size(cx, elem_type)
  assert(byte_length <= REALLOC_I32_MAX)
  ptr = cx.allocate(alignment(cx, elem_type), byte_length)
  store_list_into_valid_range(cx, v, ptr, elem_type)
  return (ptr, len(v))

def store_list_into_valid_range(cx, v, ptr, elem_type):
  for i,e in enumerate(v):
    store(cx, e, elem_type, ptr + i * elem_size(cx, elem_type))

def store_record(cx, v, ptr, fields):
  for f in fields:
    ptr = align_to(ptr, alignment(cx, f.t))
    store(cx, v[f.label], f.t, ptr)
    ptr += elem_size(cx, f.t)
```

Variant values are represented as Python dictionaries containing exactly one
entry whose key is the label of the lifted case and whose value is the
(optional) case payload. While this code appears to do an O(n) search of the
`variant` type for a matching case label, a normal implementation can
statically fuse `store_variant` with its matching `load_variant` to ultimately
build a dense array that maps producer's case indices to the consumer's case
indices.
```python
def store_variant(cx, v, ptr, cases):
  case_index, case_value = match_case(v, cases)
  disc_size = elem_size(cx, discriminant_type(cases))
  store_int(cx, case_index, ptr, disc_size)
  ptr += disc_size
  ptr = align_to(ptr, max_case_alignment(cx, cases))
  c = cases[case_index]
  if c.t is not None:
    store(cx, case_value, c.t, ptr)

def match_case(v, cases):
  [label] = v.keys()
  [index] = [i for i,c in enumerate(cases) if c.label == label]
  [value] = v.values()
  return (index, value)
```

Flags are converted from a dictionary to a bit-vector by iterating
through the labels of the flags type in the order they were listed in the
type definition and OR-ing all the bits together. Flag lifting/lowering can be
statically fused into array/integer operations (with a simple byte copy when
the case lists are the same) to avoid any string operations in a similar manner
to variants.
```python
def store_flags(cx, v, ptr, labels):
  i = pack_flags_into_int(v, labels)
  store_int(cx, i, ptr, elem_size_flags(labels))

def pack_flags_into_int(v, labels):
  i = 0
  shift = 0
  for l in labels:
    i |= (int(bool(v[l])) << shift)
    shift += 1
  return i
```

Finally, `own` and `borrow` handles are lowered by initializing new handle
elements in the current component instance's `handles` table. The increment of
`num_borrows` is complemented by a decrement in `canon_resource_drop` and
ensures that all borrowed handles are dropped before the end of the task.
```python
def lower_own(cx, rep, t):
  h = ResourceHandle(t.rt, rep, own = True)
  return cx.inst.handles.add(h)

def store_borrow(cx, rep, ptr, t):
  if cx.inst is t.rt.impl:
    store_int(cx, rep, ptr, ptr_size(t.rt.rep))
  else:
    store_int(cx, add_borrow(cx, rep, t), ptr, 4)

def add_borrow(cx, rep, t):
  assert(isinstance(cx.borrow_scope, Task))
  h = ResourceHandle(t.rt, rep, own = False, borrow_scope = cx.borrow_scope)
  h.borrow_scope.num_borrows += 1
  return cx.inst.handles.add(h)
```
The special case in `store_borrow` is an optimization, recognizing that, when
a borrowed handle is passed to the component that implemented the resource
type, the only thing the borrowed handle is good for is calling
`resource.rep`, so lowering might as well avoid the overhead of creating an
intermediate borrow handle and instead pass the `rep` directly, using the size
of the resource's representation type.

Lowering a `stream` or `future` simply adds the given readable end to the
current component instance's `handles` table, establishing unique ownership of
the end and passing the newly-allocated `handles`-table index to wasm code:
```python
def lower_stream(cx, end, t):
  return lower_async_value(ReadableStreamEnd, cx, end, t)

def lower_future(cx, end, t):
  return lower_async_value(ReadableFutureEnd, cx, end, t)

def lower_async_value(ReadableEndT, cx, end, t):
  assert(not contains_borrow(t))
  assert(isinstance(end, ReadableEndT))
  assert(end.t == t)
  assert(end.state == End.State.IDLE)
  end.owner = cx.inst
  end.index = cx.inst.handles.add(end)
  return end.index
```


## Flattening

With only the definitions above, the Canonical ABI would be forced to place all
parameters and results in linear memory. While this is necessary in the general
case, in many cases performance can be improved by passing small-enough values
in registers by using core function parameters and results. To support this
optimization, the Canonical ABI defines `flatten_functype` to map component
function types to core function types by attempting to decompose all the
non-dynamically-sized component value types into core value types.

For a variety of [practical][Implementation Limits] reasons, we need to limit
the total number of flattened parameters and results, falling back to storing
everything in linear memory. The number of flattened results is currently
limited to 1 due to various parts of the toolchain (notably the C ABI) not yet
being able to express [multi-value] returns. Hopefully this limitation is
temporary and can be lifted before the Component Model is fully standardized.

When there are too many flat values, in general, a single `i32` pointer can be
passed instead (pointing to a tuple in linear memory). When lowering *into*
linear memory, this requires the Canonical ABI to call `realloc` (in `lower`
below) to allocate space to put the tuple. As an optimization, when lowering
the return value of an imported function (via `canon lower`), the caller can
have already allocated space for the return value (e.g., efficiently on the
stack), passing in an `i32` pointer as an parameter instead of returning an
`i32` as a return value.

Given all this, the top-level definition of `flatten_functype` is as follows,
where `cx.direction` indicates whether `ft` is being lifted (by `canon lift`) or
lowered (by `canon lower`):
```python
MAX_FLAT_PARAMS = 16
MAX_FLAT_ASYNC_PARAMS = 4
MAX_FLAT_RESULTS = 1

def flatten_functype(cx, ft):
  flat_params = flatten_types(cx.reverse_direction(), ft.param_types())
  flat_results = flatten_types(cx, ft.result_type())
  if not cx.opts.async_:
    if len(flat_params) > MAX_FLAT_PARAMS:
      flat_params = [cx.opts.memory.ptr_type()]
    if len(flat_results) > MAX_FLAT_RESULTS:
      match cx.direction:
        case 'lift':
          flat_results = [cx.opts.memory.ptr_type()]
        case 'lower':
          flat_params += [cx.opts.memory.ptr_type()]
          flat_results = []
    return CoreFuncType(flat_params, flat_results)
  else:
    match cx.direction:
      case 'lift':
        if len(flat_params) > MAX_FLAT_PARAMS:
          flat_params = [cx.opts.memory.ptr_type()]
        if cx.opts.callback:
          flat_results = ['i32']
        else:
          flat_results = []
      case 'lower':
        if len(flat_params) > MAX_FLAT_ASYNC_PARAMS:
          flat_params = [cx.opts.memory.ptr_type()]
        if len(flat_results) > 0:
          flat_params += [cx.opts.memory.ptr_type()]
        flat_results = ['i32']
    return CoreFuncType(flat_params, flat_results)

def flatten_types(cx, ts):
  return [ft for t in ts for ft in flatten_type(cx, t)]
```
As shown here, the core signatures of `async`-lowered functions use a lower
limit on the maximum number of parameters (4) and results (0) passed as scalars
before falling back to passing through memory.

Presenting the definition of `flatten_type` piecewise, we start with the
top-level case analysis:
```python
def flatten_type(cx, t):
  match despecialize(t):
    case BoolType()                       : return ['i32']
    case U8Type() | U16Type() | U32Type() : return ['i32']
    case S8Type() | S16Type() | S32Type() : return ['i32']
    case S64Type() | U64Type()            : return ['i64']
    case F32Type()                        : return ['f32']
    case F64Type()                        : return ['f64']
    case CharType()                       : return ['i32']
    case StringType()                     : return 2 * [cx.opts.memory.ptr_type()]
    case ErrorContextType()               : return ['i32']
    case ListType(t, l)                   : return flatten_list(cx, t, l)
    case RecordType(fields)               : return flatten_record(cx, fields)
    case VariantType(cases)               : return flatten_variant(cx, cases)
    case FlagsType(labels)                : return ['i32']
    case OwnType()                        : return ['i32']
    case BorrowType()                     : return flatten_borrow(cx, t)
    case StreamType() | FutureType()      : return ['i32']
```

List flattening of a fixed-length list uses the same flattening as a tuple
(via `flatten_record` below).
```python
def flatten_list(cx, elem_type, maybe_length):
  if maybe_length is not None:
    return flatten_type(cx, elem_type) * maybe_length
  return 2 * [cx.opts.memory.ptr_type()]
```

Record flattening simply flattens each field in sequence.
```python
def flatten_record(cx, fields):
  flat = []
  for f in fields:
    flat += flatten_type(cx, f.t)
  return flat
```

Variant flattening is more involved due to the fact that each case payload can
have a totally different flattening. Rather than giving up when there is a type
mismatch, the Canonical ABI relies on the fact that the 4 core value types can
be easily bit-cast between each other and defines a `join` operator to pick the
tightest approximation. What this means is that, regardless of the dynamic
case, all flattened variants are passed with the same static set of core types,
which may involve, e.g., reinterpreting an `f32` as an `i32` or zero-extending
an `i32` into an `i64`.
```python
def flatten_variant(cx, cases):
  flat = []
  for c in cases:
    if c.t is not None:
      for i,ft in enumerate(flatten_type(cx, c.t)):
        if i < len(flat):
          flat[i] = join(flat[i], ft)
        else:
          flat.append(ft)
  return flatten_type(cx, discriminant_type(cases)) + flat

def join(a, b):
  if a == b: return a
  if (a == 'i32' and b == 'f32') or (a == 'f32' and b == 'i32'): return 'i32'
  return 'i64'
```

Lastly, matching `store_borrow` above, a `borrow` lowered into the component
that defined its resource type is passed as its `rep`:
```python
def flatten_borrow(cx, t):
  if cx.inst is t.rt.impl and cx.direction == 'lower':
    return [t.rt.rep]
  else:
    return ['i32']
```

## Flat Lifting

Values are lifted by iterating over a list of parameter or result Core
WebAssembly values:
```python
class CoreValueIter:
  values: list[int|float]
  i: int

  def __init__(self, vs):
    self.values = vs
    self.i = 0

  def next(self, t):
    v = self.values[self.i]
    self.i += 1
    match t:
      case 'i32': assert(isinstance(v, int) and 0 <= v < 2**32)
      case 'i64': assert(isinstance(v, int) and 0 <= v < 2**64)
      case 'f32': assert(isinstance(v, (int,float)))
      case 'f64': assert(isinstance(v, (int,float)))
      case _    : assert(False)
    return v
```
The `match` is only used for spec-level assertions; no runtime typecase is
required.

The `lift_flat` function defines how to convert a list of core values into a
single high-level value of type `t`. Presenting the definition of `lift_flat`
piecewise, we start with the top-level case analysis:
```python
def lift_flat(cx, vi, t):
  match despecialize(t):
    case BoolType()         : return convert_int_to_bool(vi.next('i32'))
    case U8Type()           : return lift_flat_unsigned(vi, 32, 8)
    case U16Type()          : return lift_flat_unsigned(vi, 32, 16)
    case U32Type()          : return lift_flat_unsigned(vi, 32, 32)
    case U64Type()          : return lift_flat_unsigned(vi, 64, 64)
    case S8Type()           : return lift_flat_signed(vi, 32, 8)
    case S16Type()          : return lift_flat_signed(vi, 32, 16)
    case S32Type()          : return lift_flat_signed(vi, 32, 32)
    case S64Type()          : return lift_flat_signed(vi, 64, 64)
    case F32Type()          : return canonicalize_nan32(vi.next('f32'))
    case F64Type()          : return canonicalize_nan64(vi.next('f64'))
    case CharType()         : return convert_i32_to_char(cx, vi.next('i32'))
    case StringType()       : return lift_flat_string(cx, vi)
    case ErrorContextType() : return lift_error_context(cx, vi.next('i32'))
    case ListType(t, l)     : return lift_flat_list(cx, vi, t, l)
    case RecordType(fields) : return lift_flat_record(cx, vi, fields)
    case VariantType(cases) : return lift_flat_variant(cx, vi, cases)
    case FlagsType(labels)  : return lift_flat_flags(vi, labels)
    case OwnType()          : return lift_own(cx, vi.next('i32'), t)
    case BorrowType()       : return lift_borrow(cx, vi.next('i32'), t)
    case StreamType(t)      : return lift_stream(cx, vi.next('i32'), t)
    case FutureType(t)      : return lift_future(cx, vi.next('i32'), t)
```

Integers are lifted from core `i32` or `i64` values using the signedness of the
target type to interpret the high-order bit. When the target type is narrower
than an `i32`, the Canonical ABI ignores the unused high bits (like `load_int`).
The conversion logic here assumes that `i32` values are always represented as
unsigned Python `int`s and thus lifting to a signed type performs a manual 2s
complement conversion in the Python (which would be a no-op in hardware).
```python
def lift_flat_unsigned(vi, core_width, t_width):
  i = vi.next('i' + str(core_width))
  assert(0 <= i < (1 << core_width))
  return i % (1 << t_width)

def lift_flat_signed(vi, core_width, t_width):
  i = vi.next('i' + str(core_width))
  assert(0 <= i < (1 << core_width))
  i %= (1 << t_width)
  if i >= (1 << (t_width - 1)):
    return i - (1 << t_width)
  return i
```

The contents of strings and variable-length lists are stored in memory so
lifting these types is essentially the same as loading them from memory; the
only difference is that the pointer and length come from ptr-sized values
instead of from linear memory. Fixed-length lists are lifted the same way as a
tuple.
```python
def lift_flat_string(cx, vi):
  ptr = vi.next(cx.opts.memory.ptr_type())
  packed_length = vi.next(cx.opts.memory.ptr_type())
  return load_string_from_range(cx, ptr, packed_length)

def lift_flat_list(cx, vi, elem_type, maybe_length):
  if maybe_length is not None:
    a = []
    for i in range(maybe_length):
      a.append(lift_flat(cx, vi, elem_type))
    return a
  ptr = vi.next(cx.opts.memory.ptr_type())
  length = vi.next(cx.opts.memory.ptr_type())
  return load_list_from_range(cx, ptr, length, elem_type)
```

Records are lifted by recursively lifting their fields:
```python
def lift_flat_record(cx, vi, fields):
  record = {}
  for f in fields:
    record[f.label] = lift_flat(cx, vi, f.t)
  return record
```

Variants are also lifted recursively. Lifting a variant must carefully follow
the definition of `flatten_variant` above, consuming the exact same core types
regardless of the dynamic case payload being lifted. Because of the `join`
performed by `flatten_variant`, we need a more-permissive value iterator that
reinterprets between the different types appropriately and also wraps
`i64` values to 32-bit when needed:
```python
def lift_flat_variant(cx, vi, cases):
  flat_types = flatten_variant(cx, cases)
  assert(flat_types.pop(0) == 'i32')
  case_index = vi.next('i32')
  trap_if(case_index >= len(cases))
  class CoerceValueIter:
    def next(self, want):
      have = flat_types.pop(0)
      x = vi.next(have)
      match (have, want):
        case ('i32', 'f32') : return decode_i32_as_float(x)
        case ('i64', 'i32') : return wrap_i64_to_i32(x)
        case ('i64', 'f32') : return decode_i32_as_float(wrap_i64_to_i32(x))
        case ('i64', 'f64') : return decode_i64_as_float(x)
        case _              : assert(have == want); return x
  c = cases[case_index]
  if c.t is None:
    v = None
  else:
    v = lift_flat(cx, CoerceValueIter(), c.t)
  for have in flat_types:
    _ = vi.next(have)
  return { c.label: v }

def wrap_i64_to_i32(i):
  assert(0 <= i < (1 << 64))
  return i % (1 << 32)
```

Finally, flags are lifted by lifting to a record the same way as when loading
flags from linear memory.
```python
def lift_flat_flags(vi, labels):
  assert(0 < len(labels) <= 32)
  i = vi.next('i32')
  return unpack_flags_from_int(i, labels)
```

## Flat Lowering

The `lower_flat` function defines how to convert a value `v` of a given type
`t` into zero or more core values. Presenting the definition of `lower_flat`
piecewise, we start with the top-level case analysis:
```python
def lower_flat(cx, v, t):
  match despecialize(t):
    case BoolType()         : return [int(v)]
    case U8Type()           : return [v]
    case U16Type()          : return [v]
    case U32Type()          : return [v]
    case U64Type()          : return [v]
    case S8Type()           : return lower_flat_signed(v, 32)
    case S16Type()          : return lower_flat_signed(v, 32)
    case S32Type()          : return lower_flat_signed(v, 32)
    case S64Type()          : return lower_flat_signed(v, 64)
    case F32Type()          : return [maybe_scramble_nan32(v)]
    case F64Type()          : return [maybe_scramble_nan64(v)]
    case CharType()         : return [char_to_i32(v)]
    case StringType()       : return lower_flat_string(cx, v)
    case ErrorContextType() : return [lower_error_context(cx, v)]
    case ListType(t, l)     : return lower_flat_list(cx, v, t, l)
    case RecordType(fields) : return lower_flat_record(cx, v, fields)
    case VariantType(cases) : return lower_flat_variant(cx, v, cases)
    case FlagsType(labels)  : return lower_flat_flags(v, labels)
    case OwnType()          : return [lower_own(cx, v, t)]
    case BorrowType()       : return lower_flat_borrow(cx, v, t)
    case StreamType(t)      : return [lower_stream(cx, v, t)]
    case FutureType(t)      : return [lower_future(cx, v, t)]
```

Since component-level values are assumed in-range and, as previously stated,
core `i32` values are always internally represented as unsigned `int`s,
unsigned integer values need no extra conversion. Signed integer values are
converted to unsigned core `i32` or `i64` values by 2s complement arithmetic
(which again would be a no-op in hardware):
```python
def lower_flat_signed(i, core_bits):
  if i < 0:
    i += (1 << core_bits)
  return [i]
```

Since strings and variable-length lists are stored in linear memory, lowering
can reuse the previous definitions; only the resulting pointers are returned
differently (as flat values instead of as a pair in linear memory).
Fixed-length lists are lowered the same way as tuples.
```python
def lower_flat_string(cx, v):
  ptr, packed_length = store_string_into_range(cx, v)
  return [ptr, packed_length]

def lower_flat_list(cx, v, elem_type, maybe_length):
  if maybe_length is not None:
    assert(maybe_length == len(v))
    flat = []
    for e in v:
      flat += lower_flat(cx, e, elem_type)
    return flat
  (ptr, length) = store_list_into_range(cx, v, elem_type)
  return [ptr, length]
```

Records are lowered by recursively lowering their fields:
```python
def lower_flat_record(cx, v, fields):
  flat = []
  for f in fields:
    flat += lower_flat(cx, v[f.label], f.t)
  return flat
```

Variants are also lowered recursively. Symmetric to `lift_flat_variant` above,
`lower_flat_variant` must consume all flattened types of `flatten_variant`,
manually coercing the otherwise-incompatible type pairings allowed by `join`:
```python
def lower_flat_variant(cx, v, cases):
  case_index, case_value = match_case(v, cases)
  flat_types = flatten_variant(cx, cases)
  assert(flat_types.pop(0) == 'i32')
  c = cases[case_index]
  if c.t is None:
    payload = []
  else:
    payload = lower_flat(cx, case_value, c.t)
    for i,(fv,have) in enumerate(zip(payload, flatten_type(cx, c.t))):
      want = flat_types.pop(0)
      match (have, want):
        case ('f32', 'i32') : payload[i] = encode_float_as_i32(fv)
        case ('i32', 'i64') : payload[i] = fv
        case ('f32', 'i64') : payload[i] = encode_float_as_i32(fv)
        case ('f64', 'i64') : payload[i] = encode_float_as_i64(fv)
        case _              : assert(have == want)
  for _ in flat_types:
    payload.append(0)
  return [case_index] + payload
```

Flags are lowered by packing the flags into an `i32` bitvector.
```python
def lower_flat_flags(v, labels):
  assert(0 < len(labels) <= 32)
  return [pack_flags_into_int(v, labels)]
```

Finally, `borrow` handles are lowered with the same optimization as
`store_borrow` above:
```python
def lower_flat_borrow(cx, rep, t):
  if cx.inst is t.rt.impl:
    return [rep]
  else:
    return [add_borrow(cx, rep, t)]
```

## Lifting and Lowering Values

The `lift_flat_values` function defines how to lift a list of core
parameters or results (given by the `CoreValueIter` `vi`) into a tuple
of component-level values with types `ts`.
```python
def lift_flat_values(cx, max_flat, vi, ts):
  flat_types = flatten_types(cx, ts)
  if len(flat_types) > max_flat:
    ptr = vi.next(cx.opts.memory.ptr_type())
    tuple_type = TupleType(ts)
    trap_if(ptr != align_to(ptr, alignment(cx, tuple_type)))
    trap_if(ptr + elem_size(cx, tuple_type) > len(cx.opts.memory))
    return list(load(cx, ptr, tuple_type).values())
  else:
    return [ lift_flat(cx, vi, t) for t in ts ]
```

Symmetrically, the `lower_flat_values` function defines how to lower a
list of component-level values `vs` of types `ts` into a list of core
values. As already described for [`flatten_functype`](#flattening) above,
lowering handles the greater-than-`max_flat` case by either allocating
storage with `realloc` or accepting a caller-allocated buffer as an
out-param:
```python
def lower_flat_values(cx, max_flat, vs, ts, out_param = None):
  flat_types = flatten_types(cx, ts)
  if len(flat_types) > max_flat:
    tuple_type = TupleType(ts)
    tuple_value = {str(i): v for i,v in enumerate(vs)}
    if out_param is None:
      ptr = cx.allocate(alignment(cx, tuple_type), elem_size(cx, tuple_type))
      flat_vals = [ptr]
    else:
      ptr = out_param.next(cx.opts.memory.ptr_type())
      trap_if(ptr != align_to(ptr, alignment(cx, tuple_type)))
      trap_if(ptr + elem_size(cx, tuple_type) > len(cx.opts.memory))
      flat_vals = []
    store(cx, tuple_value, tuple_type, ptr)
  else:
    flat_vals = []
    for i in range(len(vs)):
      flat_vals += lower_flat(cx, vs[i], ts[i])
  return flat_vals
```


## Canonical Definitions

Using the above supporting definitions, we can describe the static and dynamic
semantics of component-level [`canon`] definitions. The following subsections
cover each of these `canon` cases.

### `canonopt` Validation

Canonical options, often referred to as `$opts` in the definitions below,
can be specified at most once in any particular list of options. For example
specifying `string-encoding=utf8` twice is an error. Each individual option, if
present, is validated as such:

* `string-encoding=N` - can be passed at most once, regardless of `N`.
* `memory` - this is a subtype of `(memory 0)`
  * 🐘 `memory` may also be a subtype of `(memory i64 0)`
* `realloc` - the function has type `(func (param addr addr addr addr) (result addr))`
  where `addr` is the address type coming from the [`memtype`] of the `memory`
  canonopt (restricted to `i32`, but with 🐘 may also be `i64`).
* if `realloc` is present then `memory` must be present
* `post-return` - only allowed on [`canon lift`](#canon-lift), which has rules
  for validation
* 🔀 `async` - is only allowed when used with an `async` function type in
  [`canon lift`](#canon-lift) or [`canon lower`](#canon-lower) and cannot be
  present with `post-return`
* 🔀,not(🚟) `async` - `callback` must also be present. Note that with the 🚟
  feature (the "stackful" ABI), this restriction is lifted.
* 🔀 `callback` - the function has type `(func (param i32 i32 i32) (result i32))`
  and cannot be present without `async` and is only allowed with
  [`canon lift`](#canon-lift)

Additionally some options are required depending on lift/lower operations
performed for a component. These are defined as:

* `lower(T)`
  * requires `memory` if `T` contains a `list` or `string`

* `lift(T)`
  * requires `realloc` if `T` contains a `list` or `string`

Value types used by `lift`/`lower` are already rejected at `defvaltype`
definition if they exceed the [Element Size](#element-size) bound.

### `canon lift`

For a canonical definition:
```wat
(canon lift $callee $opts (func $f (type $ft)))
```

In addition to [general validation of `$opts`](#canonopt-validation) the additional
validation is performed with `cx = LiftLowerContext('lift', $opts, inst)` where
`inst` is the component instance containing this lifting definition:

* `$callee` must have type `flatten_functype(cx, $ft)`
* `$f` is given type `$ft`
* if a `post-return` is present, it has type `(func (param flatten_functype(cx, $ft).results))`
* requires options based on [`lift(param)`](#canonopt-validation) for all parameters in `ft`
* requires options based on [`lower(result)`](#canonopt-validation) if `ft` has a result
* if `len(flatten_types(ft.param_types())) > MAX_FLAT_PARAMS`, `realloc` is required
* if `len(flatten_types(ft.result_type())) > max` (where `max = MAX_FLAT_RESULTS` for sync lifts, and `max = MAX_FLAT_PARAMS` for async lifts), `memory` is required

Note that an `async`-lifted function whose result type requires a memory to lift
(either because it contains lists or strings or because the number of flattened
types exceeds `MAX_FLAT_PARAMS`) must include a `memory` option, and that option
must exactly match that of the `task.return` built-in called at runtime.

When instantiating a component instance, the runtime calls `Store.lift` (defined
above) to capture the `$callee`, `$ft` and `$opts` immediates of `canon lift`
along with the component instance being instantiated. These are then passed into
`canon_lift` every time the generated `FuncInst` is called, along with the
runtime `on_start` and `on_resolve` arguments.

Based on this, `canon_lift` is defined in chunks as follows. The whole call
executes in a new *implicit thread* defined here by `thread_func`. The first
thing this implicit thread does is to wait for any backpressure, as defined by
`Task.enter_implicit_thread` above:
```python
def canon_lift(callee, ft, opts, inst, on_start, on_resolve) -> OnCancel:
  def thread_func():
    if not task.enter_implicit_thread():
      return
```

Once the backpressure gate is cleared, the arguments are lowered into core wasm
values and memory according to the `canonopt` immediates of `canon lift` (as
defined by `lower_flat_values` above). Note that if the caller cancels a task
while the task is still waiting on backpressure, the call will be aborted
*before* the arguments are lowered and thus owned handles are *not* transferred
to the callee. The `CANCELLED_BEFORE_{STARTED,RETURNED}` return codes from
`subtask.cancel` are thus necessary for the caller to distinguish whether
their arguments were lowered or not.
```python
    cx = LiftLowerContext('lift', opts, inst, task)
    flat_ft = flatten_functype(cx, ft)
    args = task.start()
    flat_args = lower_flat_values(cx.reverse_direction(), MAX_FLAT_PARAMS, args, ft.param_types())
    assert(types_match_values(flat_ft.params, flat_args))
```

If the `async` `canonopt` is *not* specified, a `lift`ed function then calls
the core wasm callee, passing the lowered arguments in core function parameters
and receiving the return value as core function results. Once the core results
are lifted according to `lift_flat_values` above, the optional `post-return`
function (specified as a `canonopt` immediate of `canon lift`) is called,
passing the same core wasm results as parameters so that the `post-return`
function can free any associated allocations.
```python
    if not opts.async_:
      flat_results = call_and_trap_on_throw(callee, flat_args)
      assert(types_match_values(flat_ft.results, flat_results))
      result = lift_flat_values(cx, MAX_FLAT_RESULTS, CoreValueIter(flat_results), ft.result_type())
      task.return_(result)
      if opts.post_return is not None:
        assert(cx.inst.may_leave)
        inst.may_leave = False
        [] = call_and_trap_on_throw(opts.post_return, flat_results)
        inst.may_leave = True
      task.exit_implicit_thread()
      return
```
By clearing `may_leave` for the duration of the `post-return` call, the
Canonical ABI ensures that synchronously-lowered calls to synchronously-lifted
functions can always be implemented by a plain synchronous function call
without the need for fibers which would otherwise be necessary if the
`post-return` function performed a blocking operation.

In both of the `async` cases below (with or without `callback`), the
`task.return` built-in must be called, providing the return value as core wasm
*parameters* to the `task.return` built-in (rather than as core function
results as in the synchronous case). If `task.return` is *not* called by the
time the `Task`'s last `Thread` exits, there is a trap (in `Task.unregister_thread`).

In the `async` non-`callback` ("stackful async") case, there is a single call
to the core wasm callee which must return empty core results. Waiting for async
I/O happens by the callee synchronously calling built-ins like
`waitable-set.wait`. Note that, since `Task.enter_implicit_thread` does *not*
acquire the `exclusive_thread` lock for stackful async functions, calls to
`waitable-set.wait` made by a stackful async function do not prevent any other
threads from starting or resuming in the same component instance.
```python
    if not opts.callback:
      [] = call_and_trap_on_throw(callee, flat_args)
      assert(types_match_values(flat_ft.results, []))
      task.exit_implicit_thread()
      return
```

Lastly, in the `async callback` ("stackless async") case, waiting happens by
first calling the core wasm callee and then repeatedly calling the `callback`
function (specified as a `funcidx` immediate in `canon lift`) until the
`EXIT` code (`0`) is returned:
```python
    [packed] = call_and_trap_on_throw(callee, flat_args)
    code,si = unpack_callback_result(packed)
    while code != CallbackCode.EXIT:
      if thread.task.deliver_pending_cancel():
        event = (EventCode.TASK_CANCELLED, 0, 0)
      else:
        assert(inst.exclusive_thread is task.implicit_thread)
        inst.exclusive_thread = None
        thread.cancellable = True
        match code:
          case CallbackCode.YIELD:
            thread.wait_until(lambda: inst.exclusive_thread is None)
            if thread.task.deliver_pending_cancel():
              event = (EventCode.TASK_CANCELLED, 0, 0)
            else:
              event = (EventCode.NONE, 0, 0)
          case CallbackCode.WAIT:
            wset = inst.handles.get(si)
            trap_if(not isinstance(wset, WaitableSet))
            event = wset.wait_from_callback()
          case _:
            trap()
        assert(inst.exclusive_thread is None)
        thread.cancellable = False
        inst.exclusive_thread = task.implicit_thread
      event_code, p1, p2 = event
      [packed] = call_and_trap_on_throw(opts.callback, [event_code, p1, p2])
      code,si = unpack_callback_result(packed)
    task.exit_implicit_thread()
    return
```
The event loop releases `ComponentInstance.exclusive_thread` (which was acquired
by `Task.enter_implicit_thread`) before potentially blocking the thread to allow
other `needs_exclusive` tasks to execute in the interim. To ensure the
run-to-completion semantics required by [Component Invariant] #2, the
`exclusive_thread` is continuously held for the duration of each turn of the
event loop. Thus, `async callback`-lifted tasks allow *more* concurrency than
synchronously-lifted tasks (which only release the `exclusive_thread` lock after
they've returned) but *less* concurrency than (stackful) non-`callback`
`async`-lifted tasks, which entirely ignore `exclusive_thread`.

Because `YIELD` waits for `exclusive_thread` to be `None`, which is trivially
true when `Thread.wait_until` is called, the host is *allowed*, but not
*required* to schedule another thread. If another thread is scheduled and that
thread acquires `exclusive_thread`, the `YIELD`ed thread cannot run until the
`exclusive_thread` is released. `WaitableSet.wait_from_callback` similarly waits
until `exclusive_thread` is not held, thereby ensuring [Component Invariant] #2
in either case.

Another important property of the event loop as defined above is that it
delivers pending cancellation requests as soon as possible: before waiting,
after waiting, and while waiting. In particular, setting `Thread.cancellable`
for the duration of the wait allows `subtask.cancel` to synchronously deliver a
`TASK_CANCELLED` event.

The end of `canon_lift` creates a new task/thread pair for the call and then
calls `Thread.resume` on the new thread to synchronously transfer control flow
to it (jumping to the top of `thread_func` above). The new thread executes until
it either returns from `thread_func` or [blocks]. If a non-`async`-typed call
blocks before the implicit thread has returned a value and there are no other
`ready` threads in the same component instance, `canon_lift` traps, since
non-`async`-typed calls may not block. Otherwise, `canon_lift` switches to a
thread (nondeterministically, if multiple are `ready`), as if the guest code had
done so itself using a built-in like `thread.suspend-then-promote`. This allows
fully-synchronous components to still use cooperative pthreads that interleave
via threading built-ins (e.g., `thread.yield`) and *even perform blocking I/O*
as long as the blocking I/O does not transitively block returning a value to the
caller (as would also be expressible with a CPS transform like [Asyncify]).
Lastly, `canon_lift` returns `Task.request_cancellation`, bound to the call's
new task, as the `OnCancel` return value of `FuncInst`.
```python
  task = Task(ft, opts, inst, on_start, on_resolve)
  thread = Thread(task, thread_func)
  thread.resume()
  if not ft.async_:
    while task.state != Task.State.RESOLVED:
      candidates = { t for t in inst.threads if t.ready() }
      trap_if(not candidates)
      random.choice(list(candidates)).resume()
  return task.request_cancellation
```

Note that, because non-`async`-typed functions can't block, they do not actually
require a separate thread/fiber/stack to implement the above specified behavior
and a normal synchronous native function call can be used instead. Even if the
non-`async`-typed callee uses cooperative threads, since control flow must
inevitably make its way back to the implicit thread to return a value
(`task.return` is not allowed), the caller's stack can always be used for the
callee's implicit thread, knowing that control flow must switch back before
returning to the caller (or else trap and tear down the whole store).

The bit-packing scheme used for the `i32` `packed` return value is defined as
follows:
```python
class CallbackCode(IntEnum):
  EXIT = 0
  YIELD = 1
  WAIT = 2
  MAX = 2

def unpack_callback_result(packed):
  code = packed & 0xf
  trap_if(code > CallbackCode.MAX)
  assert(packed < 2**32)
  assert(Table.MAX_LENGTH < 2**28)
  waitable_set_index = packed >> 4
  return (CallbackCode(code), waitable_set_index)
```
The ability to asynchronously wait, yield and exit is thus available to
both the `callback` and non-`callback` cases, making `callback` just an
optimization to avoid allocating stacks for async languages that have avoided
the need for stackful coroutines by design (e.g., `async`/`await` in JS,
Python, C# and Rust).

Uncaught Core WebAssembly [exceptions] or, in a future with [stack-switching],
unhandled events, result in a trap at component boundaries. Thus, if a component
wishes to signal an error, it must use some sort of explicit type such as
`result` (whose `error` case particular language bindings may choose to map to
and from exceptions):
```python
def call_and_trap_on_throw(callee, args):
  try:
    return callee(args)
  except CoreWebAssemblyException:
    trap()
```


### `canon lower`

For a canonical definition:
```wat
(canon lower $callee:<funcidx> $opts:<canonopt>* (core func $f))
```

In addition to [general validation of `$opts`](#canonopt-validation), additional
validation is performed where `$callee` has type `ft`,
`cx = LiftLowerContext('lower', $opts, inst)`, and `inst` is the component
instance containing this lowering definition:

* `$f` is given type `flatten_functype(cx, ft)`
* requires options [based on `lower(param)`](#canonopt-validation) for all parameters in `ft`
* requires options [based on `lift(result)`](#canonopt-validation) if `ft` has a result
* if `len(flatten_types(ft.param_types())) > max_flat_params`, `memory` is required
* if `len(flatten_types(ft.result_type())) > max_flat_results`, `memory` is required

When instantiating a component instance, the runtime calls `Store.lower` (defined
above) to capture the `$callee` and `$opts` immediates of `canon lower` along
with `ft` (the type of `$callee`) and the component instance being instantiated.
These are then passed into `canon_lower` every time the generated `CoreFuncInst`
is called, along with the runtime Core WebAssembly arguments.

Based on this, `canon_lower` is defined in chunks as follows. First, like most
Canonical ABI functions callable from Core WebAssembly, lowered imports may not
be called during `post-return` or `realloc`:
```python
def canon_lower(callee, ft, opts, flat_args: list[CoreValType]) -> list[CoreValType]:
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
```

After creating the `Subtask` and `LiftLowerContext` for the call, the
component-level function type maps to a Core WebAssembly function type using
different flattening constants based on whether the sync or async ABI is used.
The values of `max_flat_{params,results}` mirror the flattening logic in
`flatten_functype` above:
```python
  subtask = Subtask()
  cx = LiftLowerContext('lower', opts, thread.task.inst, subtask)
  flat_ft = flatten_functype(cx, ft)
  assert(types_match_values(flat_ft.params, flat_args))
  flat_args = CoreValueIter(flat_args)

  if not opts.async_:
    max_flat_params = MAX_FLAT_PARAMS
    max_flat_results = MAX_FLAT_RESULTS
  else:
    max_flat_params = MAX_FLAT_ASYNC_PARAMS
    max_flat_results = 0
```

Next, the call is officially started by calling `callee` with the required
`OnStart` and `OnResolve` callbacks (described above) that lift arguments and
lower results if not cancelled. The `maybe_on_progress` callback starts as a
no-op but is switched to `on_progress` (defined below) in the `async` case if
`callee` [blocks], so that progress updates are asynchronously delivered to the
caller.
```python
  maybe_on_progress = lambda:()

  def on_start():
    maybe_on_progress()
    assert(subtask.state == Subtask.State.STARTING)
    subtask.state = Subtask.State.STARTED
    return lift_flat_values(cx.reverse_direction(), max_flat_params, flat_args, ft.param_types())

  def on_resolve(result):
    maybe_on_progress()
    if result is None:
      assert(subtask.cancellation_requested)
      if subtask.state == Subtask.State.STARTING:
        subtask.resolve(Subtask.State.CANCELLED_BEFORE_STARTED, [])
      else:
        assert(subtask.state == Subtask.State.STARTED)
        subtask.resolve(Subtask.State.CANCELLED_BEFORE_RETURNED, [])
    else:
      assert(subtask.state == Subtask.State.STARTED)
      flat_results = lower_flat_values(cx, max_flat_results, result, ft.result_type(), flat_args)
      subtask.resolve(Subtask.State.RETURNED, flat_results)

  subtask.on_cancel = callee(on_start, on_resolve)
  assert(ft.async_ or subtask.state == Subtask.State.RETURNED)
```
According to the `FuncInst` calling contract, if `callee` [blocks], it must
immediately return an `OnCancel` callback which the code above stores in the
`Subtask` to enable subsequent requests for cancellation. As asserted above, if
the `callee`'s function type does not declare the `async` effect, `callee` must
not block before returning a value.

In the synchronous case (when the `async` `canonopt` is not set), if the
`callee` blocked before calling `on_resolve`, the synchronous caller's thread
is non-cancellably suspended until the callee calls `on_resolve` to return a
value. Note that just because the `callee` called `on_resolve` doesn't mean
that the `callee` has finished execution: `async` functions are allowed to keep
executing after returning their value. However, if the `callee` is also
synchronous then (since `post-return` is prevented from blocking via
`may_leave`) the `callee` cannot keep executing concurrently after returning a
value and thus the implementation can avoid the creation of any `Thread` and
use a plain synchronous function call instead, as expected.
```python
  if not opts.async_:
    if not subtask.resolved():
      thread.wait_until(subtask.resolved)
    subtask.deliver_resolve()
    assert(types_match_values(flat_ft.results, subtask.flat_results))
    return subtask.flat_results
```
The call to `Subtask.deliver_resolve` decrements the counters on handles that
were lent for `borrow`ed parameters during the call. These counters are
necessary even during a synchronous call to prevent a concurrent `async` task
from dropping lent handles while the synchronous call is blocked.

In the `async` case, if the `callee` already called `on_resolve`, then the
`RETURNED` code is eagerly returned to the core wasm caller without needing to
add a `Subtask` to the current component instance's `handles` table. Otherwise,
the index of a new `Subtask` is returned, bit-packed with the current state of
the `Subtask` (which will either be `STARTING` or `STARTED`). `STARTING` tells
the caller that they need to keep the memory for both the arguments and results
allocated; `STARTED` tells the caller that the arguments have been read and
thus any argument memory can be reused, but the result buffer has to be kept
reserved.
```python
  else:
    if subtask.resolved():
      subtask.deliver_resolve()
      assert(subtask.flat_results == [])
      return [Subtask.State.RETURNED]
    else:
      subtaski = thread.task.inst.handles.add(subtask)
      def on_progress():
        def subtask_event():
          if subtask.resolved():
            subtask.deliver_resolve()
          return (EventCode.SUBTASK, subtaski, subtask.state)
        subtask.set_pending_event(subtask_event)
      maybe_on_progress = on_progress
      assert(0 < subtaski <= Table.MAX_LENGTH < 2**28)
      assert(0 <= subtask.state < 2**4)
      return [subtask.state | (subtaski << 4)]
```
When `on_start` and `on_resolve` are called after this initial `async`-lowered
call returns, the `on_progress` callback (called by `on_start` and `on_resolve`
above) will set a pending event on the `Subtask` (which derives `Waitable`) so
that it can be waited on via `waitable-set.{wait,poll}` or, if a `callback` is
used, by returning to the event loop. If `on_start` is called followed by
`on_resolve` before core wasm receives the first event, core wasm will only
receive the second event, not two events. Note `Subtask.drop` prevents (via
trap) a `Subtask` from being dropped before `on_resolve` is called and the event
is delivered to core wasm to ensure that `Subtask.deliver_resolve` always
performs its lend-count accounting.


### `canon resource.new`

For a canonical definition:
```wat
(canon resource.new $rt (core func $f))
```
validation specifies:
* `$rt` must refer to locally-defined (not imported) resource type
* `$f` is given type `(func (param $rt.rep) (result i32))`, where `$rt.rep` is
  fixed to be `i32`
  * 🐘 - `$rt.rep` may be `i32` or `i64`

Calling `$f` invokes the following function, which adds an owning handle
containing the given resource representation to the current component
instance's `handles` table:
```python
def canon_resource_new(rt, rep):
  inst = current_instance()
  trap_if(not inst.may_leave)
  h = ResourceHandle(rt, rep, own = True)
  i = inst.handles.add(h)
  return [i]
```


### `canon resource.drop`

For a canonical definition:
```wat
(canon resource.drop $rt (core func $f))
```
validation specifies:
* `$rt` must refer to resource type
* `$f` is given type `(func (param i32))`

Calling `$f` invokes the following function, which removes the handle from the
current component instance's `handles` table and, if the handle was owning,
calls the resource's destructor.
```python
def canon_resource_drop(rt, i):
  inst = current_instance()
  trap_if(not inst.may_leave)
  h = inst.handles.remove(i)
  trap_if(not isinstance(h, ResourceHandle))
  trap_if(h.rt is not rt)
  trap_if(h.num_lends != 0)
  if h.own:
    assert(h.borrow_scope is None)
    opts = CanonicalOptions(async_ = False)
    rep_type = U32Type() if rt.rep == 'i32' else U64Type()
    ft = FuncType([rep_type], [], async_ = False)
    dtor = rt.dtor or (lambda rep: [])
    callee = inst.store.lift(dtor, ft, opts, rt.impl)
    caller = inst.store.lower(callee, ft, opts, inst)
    caller([h.rep])
  else:
    h.borrow_scope.num_borrows -= 1
  return []
```
The call to a resource's destructor passes the representation value that
was previously supplied to `resource.new`. The call works like a normal
non-`async` cross-component call which means that destructors may not block.
However, the destructor may spawn an explicit thread that blocks as long as
this explicit thread doesn't transitively block the destructor's implicit thread
from returning.


### `canon resource.rep`

For a canonical definition:
```wat
(canon resource.rep $rt (core func $f))
```
validation specifies:
* `$rt` must refer to a locally-defined (not imported) resource type
* `$f` is given type `(func (param i32) (result $rt.rep))`, where `$rt.rep` is
  fixed to be `i32`
  * 🐘 - `$rt.rep` may be `i32` or `i64`

Calling `$f` invokes the following function, which extracts the resource
representation from the handle in the current component instance's `handles`
table:
```python
def canon_resource_rep(rt, i):
  h = current_instance().handles.get(i)
  trap_if(not isinstance(h, ResourceHandle))
  trap_if(h.rt is not rt)
  return [h.rep]
```
Note that the "locally-defined" requirement above ensures that only the
component instance defining a resource can access its representation.


### 🔀 `canon context.get`

For a canonical definition:
```wat
(canon context.get $t $i (core func $f))
```
validation specifies:
* `$t` must be `i32` (see [here][thread-local storage]).
  * 🐘 - `$t` may also be `i64`. All `context.get` and `context.set` built-ins
    defined in a single component must specify the same `$t`.
* `$i` must be `0`
  * 🧵 - `$i` may also be `1`
* `$f` is given type `(func (result $t))`

Calling `$f` invokes the following function, which reads the [thread-local
storage] of the [current thread].
```python
def canon_context_get(t, i):
  thread = current_thread()
  assert(t == 'i32' or t == 'i64')
  assert(i < len(thread.storage))
  result = thread.storage[i]
  assert(result < (2 ** (ptr_size(t) * 8)))
  return [result]
```


### 🔀 `canon context.set`

For a canonical definition:
```wat
(canon context.set $t $i (core func $f))
```
validation specifies:
* `$t` must be `i32` (see [here][thread-local storage])
  * 🐘 - `$t` may also be `i64`. All `context.get` and `context.set` built-ins
    defined in a single component must specify the same `$t`.
* `$i` must be `0`
  * 🧵 - `$i` may also be `1`
* `$f` is given type `(func (param $v $t))`

Calling `$f` invokes the following function, which writes to the [thread-local
storage] of the [current thread]:
```python
def canon_context_set(t, i, v):
  thread = current_thread()
  assert(t == 'i32' or t == 'i64')
  assert(i < len(thread.storage))
  assert(v < (2 ** (ptr_size(t) * 8)))
  thread.storage[i] = v
  return []
```


### 🔀 `canon backpressure.{inc,dec}`

For a canonical definition:
```wat
(canon backpressure.inc (core func $inc))
(canon backpressure.dec (core func $dec))
```
validation specifies:
* `$inc`/`$dec` are given type `(func)`

Calling `$inc` or `$dec` invokes one of the following functions:
```python
def canon_backpressure_inc():
  inst = current_instance()
  assert(0 <= inst.backpressure < 2**16)
  inst.backpressure += 1
  trap_if(inst.backpressure == 2**16)
  return []

def canon_backpressure_dec():
  inst = current_instance()
  assert(0 <= inst.backpressure < 2**16)
  inst.backpressure -= 1
  trap_if(inst.backpressure < 0)
  return []
```
`Task.enter_implicit_thread` waits for `backpressure` to return to `0` before
allowing new `async`-typed tasks to start, implementing [backpressure].


### 🔀 `canon task.return`

For a canonical definition:
```wat
(canon task.return (result $t)? $opts (core func $f))
```

In addition to [general validation of `$opts`](#canonopt-validation) validation
specifies:

* `$f` is given type `flatten_functype(('lower', $opts), (func (param $t)?))`
* `$t` must not transitively contain `borrow`
* `$opts` may only contain `memory` and `string-encoding`
* [`lift($f.result)` above](#canonopt-validation) defines required options

Calling `$f` invokes the following function which lifts the results from core
wasm state and passes them to the [current task]'s caller via `Task.return_`:
```python
def canon_task_return(result_type, opts: LiftOptions, flat_args):
  task = current_task()
  trap_if(not task.inst.may_leave)
  trap_if(not task.opts.async_)
  trap_if(result_type != task.ft.result)
  trap_if(not LiftOptions.equal(opts, task.opts))
  cx = LiftLowerContext('lift', opts, task.inst, task)
  result = lift_flat_values(cx, MAX_FLAT_PARAMS, CoreValueIter(flat_args), task.ft.result_type())
  task.return_(result)
  return []
```
The `trap_if(not task.opts.async_)` prevents `task.return` from being called by
synchronously-lifted functions (which return their value by returning from the
lifted core function).

The `trap_if(result_type != task.ft.result)` guard ensures that, in a
component with multiple exported functions of different types, `task.return` is
not called with a mismatched result type (which, due to indirect control flow,
can in general only be caught dynamically).

The `trap_if(not LiftOptions.equal(opts, task.opts))` guard ensures that the
return value is lifted the same way as the `canon lift` from which this
`task.return` is returning. This ensures that AOT fusion of `canon lift` and
`canon lower` can generate a thunk that is indirectly called by `task.return`
after these guards. Inside `LiftOptions.equal`, `opts.memory` is compared with
`task.opts.memory` via object identity of the mutable memory instance. Since
`memory` refers to a mutable *instance* of memory, this comparison is not
concerned with the static memory indices (in `canon lift` and `canon
task.return`), only the identity of the memories created
at instantiation-/ run-time. In Core WebAssembly spec terms, the test is on the
equality of the [`memaddr`] values stored in the instance's [`memaddrs` table]
which is indexed by the static [`memidx`].


### 🔀 `canon task.cancel`

For a canonical definition:
```wat
(canon task.cancel (core func $f))
```
validation specifies:
* `$f` is given type `(func)`

Calling `$f` cancels the [current task], confirming a previous `subtask.cancel`
request made by a supertask and claiming that all `borrow` handles lent to the
[current task] have already been dropped (and trapping in `Task.cancel` if not).
```python
def canon_task_cancel():
  task = current_task()
  trap_if(not task.inst.may_leave)
  trap_if(not task.opts.async_)
  task.cancel()
  return []
```
The `trap_if(not task.opts.async_)` prevents `task.cancel` from being called by
synchronously-lifted functions (which must always return a value by returning
from the lifted core function).

`Task.cancel` also traps if the cancellation has not been delivered to the task
(in which case the callee should not yet know to cancel) or if the task has
already returned a value or already called `task.cancel`.


### 🔀 `canon waitable-set.new`

For a canonical definition:
```wat
(canon waitable-set.new (core func $f))
```
validation specifies:
* `$f` is given type `(func (result i32))`

Calling `$f` invokes the following function, which adds an empty waitable set
to the current component instance's `handles` table:
```python
def canon_waitable_set_new():
  inst = current_instance()
  trap_if(not inst.may_leave)
  i = inst.handles.add(WaitableSet())
  return [i]
```


### 🔀 `canon waitable-set.wait`

For a canonical definition:
```wat
(canon waitable-set.wait (memory $mem) (core func $f))
```
validation specifies:
* `$f` is given type `(func (param $si i32) (param $ptr T) (result i32))` where
  `T` is `i32`
  * 🐘 - `T` is `i32` or `i64` as determined by the address type of `$mem`

Calling `$f` invokes the following function which waits for progress to be made
on a `Waitable` in the given waitable set (indicated by index `$si`) and then
returning its `EventCode` and writing the payload values into linear memory:
```python
def canon_waitable_set_wait(mem, si, ptr):
  inst = current_instance()
  trap_if(not inst.may_leave)
  wset = inst.handles.get(si)
  trap_if(not isinstance(wset, WaitableSet))
  event = wset.wait()
  return unpack_event(mem, inst, ptr, event)

def unpack_event(mem, inst, ptr, e: EventTuple):
  event, p1, p2 = e
  cx = LiftLowerContext('lower', LiftLowerOptions(memory = mem), inst)
  trap_if(ptr != align_to(ptr, 4))
  trap_if(ptr + 8 > len(cx.opts.memory))
  store(cx, p1, U32Type(), ptr)
  store(cx, p2, U32Type(), ptr + 4)
  return [event]
```
Note that `ptr` points to an 8-byte region of memory into which the two
`i32` payloads of the event are stored. `ptr` must be 4-byte-aligned and the
whole region must be in bounds, trapping otherwise.


### 🔀 `canon waitable-set.poll`

For a canonical definition:
```wat
(canon waitable-set.poll (memory $mem) (core func $f))
```
validation specifies:
* `$f` is given type `(func (param $si i32) (param $ptr T) (result i32))` where
  `T` is `i32`
  * 🐘 - `T` is `i32` or `i64` as determined by the address type of `$mem`

Calling `$f` invokes the following function, which either returns an event that
was pending on one of the waitables in the given waitable set (the same way as
`waitable-set.wait`) or, if there is none, returns `0`.
```python
def canon_waitable_set_poll(mem, si, ptr):
  inst = current_instance()
  trap_if(not inst.may_leave)
  wset = inst.handles.get(si)
  trap_if(not isinstance(wset, WaitableSet))
  event = wset.poll()
  return unpack_event(mem, inst, ptr, event)
```


### 🔀 `canon waitable-set.drop`

For a canonical definition:
```wat
(canon waitable-set.drop (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32))`

Calling `$f` invokes the following function, which removes the indicated
waitable set from the current component instance's `handles` table, performing
the guards defined by `WaitableSet.drop` above:
```python
def canon_waitable_set_drop(i):
  inst = current_instance()
  trap_if(not inst.may_leave)
  wset = inst.handles.remove(i)
  trap_if(not isinstance(wset, WaitableSet))
  wset.drop()
  return []
```
Note that `WaitableSet.drop` will trap if it is non-empty or there is a
concurrent `waitable-set.wait` or `async callback` currently using this
waitable set.


### 🔀 `canon waitable.join`

For a canonical definition:
```wat
(canon waitable.join (core func $f))
```
validation specifies:
* `$f` is given type `(func (param $wi i32) (param $si i32))`

Calling `$f` invokes the following function which adds the waitable indicated
by the index `wi` to the waitable set indicated by the index `si`, removing the
waitable from any waitable set that it is currently a member of.
```python
def canon_waitable_join(wi, si):
  inst = current_instance()
  trap_if(not inst.may_leave)
  w = inst.handles.get(wi)
  trap_if(not isinstance(w, Waitable))
  trap_if(w.has_sync_waiter)
  if si == 0:
    w.join(None)
  else:
    wset = inst.handles.get(si)
    trap_if(not isinstance(wset, WaitableSet))
    w.join(wset)
  return []
```
As described with the definition of `Waitable` above, to prevent surprising
deadlocks, a waitable that is currently being waited on by another built-in
traps if added to a waitable set.

Note that tables do not allow elements at index `0`, so `0` is a valid sentinel
that tells `join` to remove the given waitable from any set that it is
currently a part of. Waitables can be a member of at most one set, so if the
given waitable is already in one set, it will be transferred.


### 🔀 `canon subtask.cancel`

For a canonical definition:
```wat
(canon subtask.cancel async? (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32) (result i32))`
* 🚝 - `async` is allowed (otherwise it must be absent)

Calling `$f` invokes the following function which cooperatively requests
cancellation of the given subtask:
```python
BLOCKED = 0xffff_ffff

def canon_subtask_cancel(async_, i):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  subtask = thread.task.inst.handles.get(i)
  trap_if(not isinstance(subtask, Subtask))
  trap_if(subtask.resolve_delivered())
  trap_if(subtask.cancellation_requested)
  trap_if(subtask.in_waitable_set())
  if not subtask.resolved():
    subtask.cancellation_requested = True
    subtask.has_sync_waiter = True
    subtask.on_cancel()
    if not async_ and not subtask.resolved():
      thread.wait_until(subtask.resolved)
    subtask.has_sync_waiter = False
    if not subtask.resolved():
      return [BLOCKED]
  code,index,payload = subtask.get_pending_event()
  assert(code == EventCode.SUBTASK and index == i and payload == subtask.state)
  assert(subtask.resolve_delivered())
  return [subtask.state]
```
`subtask.cancel` starts by trapping if called twice for the same subtask or if
the supertask has already been notified that the subtask has returned or if the
subtask is already in a waitable set.

A race condition handled by the first `if not subtask.resolved()` test is that
it's possible for a subtask to have already resolved and updated the `state`
stored in the `Subtask` (such that `Subtask.resolved()` is true) but this fact
has not yet been *delivered* to the caller. This distinction is captured by
`Subtask.resolved` vs. `Subtask.resolve_delivered` with only the *latter*
trapping on entry to `subtask.cancel`.

Otherwise, if the subtask is *not* already resolved, the subtask's `OnCancel`
callback is called to officially request cancellation. If the callee is another
component, `OnCancel` is implemented by `Task.request_cancellation` (defined
above), which may execute arbitrary guest code in the callee before returning,
but may not block.

If the subtask is *not* eagerly resolved before `OnCancel` returns and
`subtask.cancel` is called with the `async` immediate, then `subtask.cancel`
immediately returns the sentinel `BLOCKED` (`-1`) value. Otherwise, if called
without `async`, `subtask.cancel` blocks until the subtask *is* resolved. Once
the subtask is resolved, the return value is the subtask's final `State` value
which is one of:
* `RETURNED`, if the subtask successfully returned a value via `task.return`;
* `CANCELLED_BEFORE_STARTED`, if the subtask was cancelled before receiving its
  arguments (and thus no `own` handles were transferred); or
* `CANCELLED_BEFORE_RETURNED`, if the subtask called `task.cancel` instead of
  `task.return`.

Lastly, a subtle race condition guarded by the above code is that during the
calls to `on_cancel` and `wait_until`, arbitrary code may run which can reenter
the caller's component instance. By setting `has_sync_waiter` to true for the
duration of these calls, `subtask.cancel` prevents other threads in the same
component instance from "stealing" an event or otherwise invalidating the
conditions guarded at the beginning of `subtask.cancel`.


### 🔀 `canon subtask.drop`

For a canonical definition:
```wat
(canon subtask.drop (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32))`

Calling `$f` removes the subtask at the given index from the current component
instance's `handles` table, performing the guards and bookkeeping defined by
`Subtask.drop()`.
```python
def canon_subtask_drop(i):
  inst = current_instance()
  trap_if(not inst.may_leave)
  s = inst.handles.remove(i)
  trap_if(not isinstance(s, Subtask))
  s.drop()
  return []
```


### 🔀 `canon {stream,future}.new`

For canonical definitions:
```wat
(canon stream.new $stream_t (core func $f))
(canon future.new $future_t (core func $f))
```
validation specifies:
* `$f` is given type `(func (result i64))`
* `$stream_t`/`$future_t` must be a type of the form `(stream $t?)`/`(future $t?)`

Calling `$f` calls `canon_{stream,future}_new` which adds two elements to the
current component instance's `handles` table and returns their indices packed
into a single `i64`. The first element (in the low 32 bits) is the readable end
(of the new {stream, future}) and the second element (in the high 32 bits) is
the writable end. The expectation is that, after calling `{stream,future}.new`,
the readable end is subsequently transferred to another component (or the host)
via `stream` or `future` parameter/result type (see `lift_{stream,future}`
above).
```python
def canon_stream_new(stream_t):
  inst = current_instance()
  trap_if(not inst.may_leave)
  (readable_end, writable_end) = new_stream(stream_t.t, owner = inst)
  readable_end.index = inst.handles.add(readable_end)
  writable_end.index = inst.handles.add(writable_end)
  return [ readable_end.index | (writable_end.index << 32) ]

def canon_future_new(future_t):
  inst = current_instance()
  trap_if(not inst.may_leave)
  (readable_end, writable_end) = new_future(future_t.t, owner = inst)
  readable_end.index = inst.handles.add(readable_end)
  writable_end.index = inst.handles.add(writable_end)
  return [ readable_end.index | (writable_end.index << 32) ]
```


### 🔀 `canon {stream,future}.{read,write}`

For canonical definitions:
```wat
(canon stream.read $stream_t $opts (core func $stream_copy))
(canon stream.write $stream_t $opts (core func $stream_copy))
(canon future.read $future_t $opts (core func $future_copy))
(canon future.write $future_t $opts (core func $future_copy))
```
In addition to [general validation of `$opts`](#canonopt-validation) validation
specifies:
* `$stream_copy` is given type `(func (param i32 T T) (result T))` where `T` is `i32`
* `$future_copy` is given type `(func (param i32 T) (result i32))` where `T` is `i32`
  * 🐘 - `T` is `i32` or `i64` as determined by the address type of `memory` from
    `$opts` (or `i32` by default if no `memory` is present)
* `$stream_t`/`$future_t` must be a type of the form `(stream $t?)`/`(future $t?)`
* If `$t` is present:
  * [`lower($t)` above](#canonopt-validation) defines required options for `write`
  * [`lift($t)` above](#canonopt-validation) defines required options for `read`
  * `memory` is required to be present
* 🚝 - `async` is allowed to be omitted, otherwise it must be present

The implementations of these 4 built-ins all funnel down to a single
parameterized `copy` function:
```python
def canon_stream_read(stream_t, opts, i, ptr, length):
  return copy(ReadableStreamEnd, WritableGuestBuffer, 'lower', stream_t, opts, i, ptr, length)

def canon_stream_write(stream_t, opts, i, ptr, length):
  return copy(WritableStreamEnd, ReadableGuestBuffer, 'lift', stream_t, opts, i, ptr, length)

def canon_future_read(future_t, opts, i, ptr):
  return copy(ReadableFutureEnd, WritableGuestBuffer, 'lower', future_t, opts, i, ptr, 1)

def canon_future_write(future_t, opts, i, ptr):
  return copy(WritableFutureEnd, ReadableGuestBuffer, 'lift', future_t, opts, i, ptr, 1)

def copy(EndT, BufferT, direction, stream_or_future_t, opts, i, ptr, length):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  end = thread.task.inst.handles.get(i)
  trap_if(not isinstance(end, EndT))
  trap_if(end.t != stream_or_future_t.t)
  trap_if(end.state != End.State.IDLE)
  trap_if(end.in_waitable_set() and not opts.async_)
  cx = LiftLowerContext(direction, opts, thread.task.inst, borrow_scope = None)
  buffer = BufferT(end.t, cx, ptr, length)
  end.copy(buffer)
  if not end.has_pending_event():
    if not opts.async_:
      end.wait_for_pending_event()
    else:
      return [BLOCKED]
  code,index,payload = end.get_pending_event()
  assert(code == end.event_code and index == i and payload != BLOCKED)
  return [payload]
```
First, the `i`th handle is checked to have the right type and to be in the
`IDLE` state. There is also a trap if attempting to synchronously read or write
from a stream or future end that is already being asynchronously waited on via
waitable set, as this might result in the waitable set "stealing" an event from
the synchronous operation, leaving it hung. After these, a readable or writable
buffer is created which (in `GuestBuffer`'s constructor) also eagerly guards the
alignment and bounds of (`ptr`, `length`). The `Buffer` object captures the
`$opts` immediate passed to `{stream,future}.{read,write}` so that subsequent
lifting and lowering of elements is well-defined to use these same `$opts`.

Next, `end.copy(buffer)` is called to actually perform the copy. The `End.copy`
method never blocks: if it's able to make some progress without blocking, it
returns with `end.has_pending_event()` set to true, otherwise it returns
immediately without blocking with `end.has_pending_event()` set to false. In the
latter case, the copy operation will execute in the background until either
progress is made, which will set `end.has_pending_event()`, or wasm code calls
`{stream,future}.cancel-{read,write}` to cancel the copy operation. While the
copy is executing, wasm code must keep the (`ptr`, `length`) region stored in
`buffer` available, since it will be concurrently read from or written into.
Once `end.has_pending_event()` is true and `end.get_pending_event()` is called,
ownership of (`ptr`, `length`) will be returned. (This "ownership" is conceptual
and not enforced; if wasm code uses a buffer region that is conceptually "owned"
by a copy operation, it will just result in racy loads/stores, not a trap.)

If `end.has_pending_event()` is true before returning, the event is
synchronously "delivered" and the `i32` event `payload` (containing a
`CopyResult` code packed with, for streams, the number of elements copied) is
the return value of `{stream,future}.{read,write}`. This `payload` value is
computed by the `{stream,future}_event` functions, defined above, which may also
transition `end.state` to `DONE` based on the `CopyResult`.

If `{stream,future}.{read,write}` is called without `async` set in `$opts`, the
call blocks until `end.has_pending_event()` is true and thus always returns the
event `payload`. Otherwise, if `end.has_pending_event()` is false, the call
immediately returns the sentinel `BLOCKED` code (`-1`) and the caller must add
`end` to a waitable set and call `waitable-set.{wait,poll}` or return to a
`callback` event loop to be notified of progress.


### 🔀 `canon {stream,future}.cancel-{read,write}`

For canonical definitions:
```wat
(canon stream.cancel-read $stream_t $async? (core func $f))
(canon stream.cancel-write $stream_t $async? (core func $f))
(canon future.cancel-read $future_t $async? (core func $f))
(canon future.cancel-write $future_t $async? (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32) (result i32))`
* `$stream_t`/`$future_t` must be a type of the form `(stream $t?)`/`(future $t?)`
* 🚝 - `async` is allowed (otherwise it must be absent)

The implementations of these 4 built-ins all funnel down to a single
parameterized `cancel_copy` function:
```python
def canon_stream_cancel_read(stream_t, async_, i):
  return cancel_copy(ReadableStreamEnd, stream_t, async_, i)

def canon_stream_cancel_write(stream_t, async_, i):
  return cancel_copy(WritableStreamEnd, stream_t, async_, i)

def canon_future_cancel_read(future_t, async_, i):
  return cancel_copy(ReadableFutureEnd, future_t, async_, i)

def canon_future_cancel_write(future_t, async_, i):
  return cancel_copy(WritableFutureEnd, future_t, async_, i)

def cancel_copy(EndT, stream_or_future_t, async_, i):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  end = thread.task.inst.handles.get(i)
  trap_if(not isinstance(end, EndT))
  trap_if(end.t != stream_or_future_t.t)
  trap_if(end.state != End.State.COPYING)
  trap_if(end.has_sync_waiter)
  trap_if(end.in_waitable_set() and not async_)
  end.cancel()
  if not end.has_pending_event():
    if not async_:
      end.wait_for_pending_event()
    else:
      return [BLOCKED]
  code,index,payload = end.get_pending_event()
  assert(not end.copying_or_cancelling())
  assert(code == end.event_code and index == i)
  return [payload]
```
Cancellation traps if the given index `i` has the wrong type or if there is not
an asynchronous copy in progress (sync copies do not expect or check for
cancellation and thus cannot be cancelled). Repeatedly cancelling the same async
copy (after the first call blocks) also traps. Lastly, there is a trap if
attempting to synchronously cancel a stream or future operation when the end is
already being asynchronously waited on by a waitable set.

After these guards, `end.cancel()` is called to request the cancellation. Like
`End.copy`, the `End.cancel` method never blocks: if it's able to make some
progress without blocking, it returns with `end.has_pending_event()` set to
true, otherwise it returns immediately without blocking with
`end.has_pending_event()` set to false. If `{stream,future}.cancel-{read,write}`
is called without the `$async` immediate set, the call blocks until
`end.has_pending_event()` is true and thus always returns an event `payload`.
Otherwise, if `end.has_pending_event()` is false, the call immediately returns
the sentinel `BLOCKED` code (`-1`) and the caller must add `end` to a waitable
set and call `waitable-set.{wait,poll}` or return to a `callback` event loop to
be notified of progress.

See `stream_event` and `future_event` definitions above for how the returned
`payload` is computed.


### 🔀 `canon {stream,future}.drop-{readable,writable}`

For canonical definitions:
```wat
(canon stream.drop-readable $stream_t (core func $f))
(canon stream.drop-writable $stream_t (core func $f))
(canon future.drop-readable $future_t (core func $f))
(canon future.drop-writable $future_t (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32))`
* `$stream_t`/`$future_t` must be a type of the form `(stream $t?)`/`(future $t?)`

Calling `$f` drops the readable or writable end of a stream or future at the
given index from the current component instance's `handles` table after checking
that the index is valid, has the right type, and the end is not in the middle of
a copy operation. Additionally, dropping the writable end of a future traps if a
value has not been written and the writable end hasn't already been notified that
the readable end was dropped. Lastly, the `End.drop` method is called to notify
the other end of the stream or future and also perform the waitable set
bookkeeping updates in `Waitable.drop`.
```python
def canon_stream_drop_readable(stream_t, i):
  return drop(ReadableStreamEnd, stream_t, i)

def canon_stream_drop_writable(stream_t, i):
  return drop(WritableStreamEnd, stream_t, i)

def canon_future_drop_readable(future_t, i):
  return drop(ReadableFutureEnd, future_t, i)

def canon_future_drop_writable(future_t, i):
  return drop(WritableFutureEnd, future_t, i)

def drop(EndT, stream_or_future_t, i):
  inst = current_instance()
  trap_if(not inst.may_leave)
  end = inst.handles.remove(i)
  trap_if(not isinstance(end, EndT))
  trap_if(end.t != stream_or_future_t.t)
  trap_if(end.copying_or_cancelling())
  trap_if(isinstance(end, WritableFutureEnd) and end.state != End.State.DONE)
  end.drop()
  return []
```


### ➡️ `canon {stream,future}.forward`

For canonical definitions:
```wat
(canon stream.forward $stream_t (core func $forward))
(canon future.forward $future_t (core func $forward))
```
validation specifies:
* `$forward` is given type `(func (param $ri i32) (param $wi i32))`
* `$stream_t`/`$future_t` must be a type of the form `(stream $t?)`/`(future $t?)`

Calling `$forward` removes the readable and writable ends at the given indices,
after checking that all the types match, the ends are in the `IDLE` state, and
the ends are not currently part of a waitable set. Then the readable end is
forwarded into the writable end as defined by `End.forward` above.
```python
def canon_stream_forward(stream_t, ri, wi):
  return forward(ReadableStreamEnd, WritableStreamEnd, stream_t, ri, wi)

def canon_future_forward(future_t, ri, wi):
  return forward(ReadableFutureEnd, WritableFutureEnd, future_t, ri, wi)

def forward(ReadableEndT, WritableEndT, stream_or_future_t, ri, wi):
  inst = current_instance()
  trap_if(not inst.may_leave)
  readable_end = inst.handles.remove(ri)
  trap_if(not isinstance(readable_end, ReadableEndT))
  trap_if(readable_end.t != stream_or_future_t.t)
  trap_if(readable_end.state != End.State.IDLE)
  trap_if(readable_end.in_waitable_set())
  writable_end = inst.handles.remove(wi)
  trap_if(not isinstance(writable_end, WritableEndT))
  trap_if(writable_end.t != stream_or_future_t.t)
  trap_if(writable_end.state != End.State.IDLE)
  trap_if(writable_end.in_waitable_set())
  End.forward(readable_end, writable_end)
  return []
```


### 🧵 `canon thread.index`

For a canonical definition:
```wat
(canon thread.index (core func $index))
```
validation specifies:
* `$index` is given type `(func (result i32))`

Calling `$index` invokes the following function, which extracts the index
of the [current thread]:
```python
def canon_thread_index():
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  assert(thread.index is not None)
  return [thread.index]
```


### 🧵 `canon thread.new-indirect`

For a canonical definition:
```wat
(canon thread.new-indirect $ft $ftbl (core func $new_indirect))
```
validation specifies
* `$ft` must refer to the type `(func (param $c T))` where `T` is `i32`
  * 🐘 - `T` may be `i32` or `i64`
* `$ftbl` must refer to a table whose element type is `funcref`
* `$new_indirect` is given type `(func (param $fi U) (param $c T) (result i32))`
  where `T` comes from `$ft`, as described above, and `U` is `i32`
  * 🐘 - `U` is `i32` or `i64` as determined by `$ftbl`'s address type

Calling `$new_indirect` invokes the following function which reads a `funcref`
from `$ftbl` (trapping if out-of-bounds, null or the wrong type), creates a new
suspended thread that will call the `funcref` passing the closure parameter `$c`
when resumed, and returns the index of the new thread in the current component
instance's `threads` table.
```python
@dataclass
class CoreFuncRef:
  t: CoreFuncType
  callee: Callable[[list[CoreValType]], list[CoreValType]]

def canon_thread_new_indirect(ft, ftbl: Table[CoreFuncRef], fi, c):
  task = current_task()
  trap_if(not task.inst.may_leave)
  f = ftbl.get(fi)
  assert(ft == CoreFuncType(['i32'], []) or ft == CoreFuncType(['i64'], []))
  trap_if(f.t != ft)
  def thread_func():
    [] = call_and_trap_on_throw(f.callee, [c])
    task.unregister_thread(new_thread)
  new_thread = Thread(task, thread_func)
  assert(new_thread.suspended())
  task.register_thread(new_thread)
  return [new_thread.index]
```
The newly-created thread starts out in a "suspended" state and so, to
actually start executing, Core WebAssembly code must call one of the other
`thread.*` built-ins defined below.


### 🧵 `canon thread.resume-later`

For a canonical definition:
```wat
(canon thread.resume-later (core func $resume-later))
```
validation specifies:
* `$resume-later` is given type `(func (param $i i32))`

Calling `$resume-later` invokes the following function which loads a thread at
index `$i` from the current component instance's `threads` table, traps if it's
not [suspended], and then marks that thread as ready to run at some
nondeterministic point in the future chosen by the embedder.
```python
def canon_thread_resume_later(i):
  inst = current_instance()
  trap_if(not inst.may_leave)
  other_thread = inst.threads.get(i)
  trap_if(not other_thread.suspended())
  assert(current_thread() is not other_thread)
  other_thread.resume_later()
  return []
```


### 🧵 `canon thread.suspend`

For a canonical definition:
```wat
(canon thread.suspend (core func $suspend))
```
validation specifies:
* `$suspend` is given type `(func (result i32))`

Calling `$suspend` invokes the following function which suspends the [current
thread], immediately returning control flow to any transitive `async`-lowered
calling component.
```python
def canon_thread_suspend():
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  thread.suspend()
  return [0]
```


### 🔀 `canon thread.yield`

For a canonical definition:
```wat
(canon thread.yield (core func $yield))
```
validation specifies:
* `$yield` is given type `(func (result i32))`

Calling `$yield` invokes the following function which yields execution so that
other threads can execute, leaving the current thread ready to run at some
nondeterministic point in the future chosen by the embedder. This allows a
long-running computation that is not otherwise performing I/O to avoid starving
other threads in a cooperative setting.
```python
def canon_thread_yield():
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  thread.yield_()
  return [0]
```


### 🧵 `canon thread.suspend-then-resume`

For a canonical definition:
```wat
(canon thread.suspend-then-resume (core func $suspend-then-resume))
```
validation specifies:
* `$suspend-then-resume` is given type `(func (param $i i32) (result i32))`

Calling `$suspend-then-resume` invokes the following function which loads a
thread at index `$i` from the current component instance's `threads` table,
traps if it's not [suspended], and then switches to that thread, leaving the
[current thread] suspended.
```python
def canon_thread_suspend_then_resume(i):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  other_thread = thread.task.inst.threads.get(i)
  trap_if(not other_thread.suspended())
  assert(current_thread() is not other_thread)
  thread.suspend_then_resume(other_thread)
  return [0]
```


### 🧵 `canon thread.yield-then-resume`

For a canonical definition:
```wat
(canon thread.yield-then-resume (core func $yield-then-resume))
```
validation specifies:
* `$yield-then-resume` is given type `(func (param $i i32) (result i32))`

Calling `$yield-then-resume` invokes the following function which loads a thread
at index `$i` from the current component instance's `threads` table, traps if
it's not [suspended], and then switches to that thread, leaving the [current
thread] ready to run at some nondeterministic point in the future chosen by the
embedder.
```python
def canon_thread_yield_then_resume(i):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  other_thread = thread.task.inst.threads.get(i)
  trap_if(not other_thread.suspended())
  assert(current_thread() is not other_thread)
  thread.yield_then_resume(other_thread)
  return [0]
```


### 🧵 `canon thread.suspend-then-promote`

For a canonical definition:
```wat
(canon thread.suspend-then-promote (core func $suspend-then-promote))
```
validation specifies:
* `$suspend-then-promote` is given type `(func (param $i i32) (result i32))`

Calling `$suspend-then-promote` invokes the following function which loads a
thread at index `$i` from the current component instance's `threads` table,
trapping on out-of-bounds or if the index of the current thread is passed, and
then calls `Thread.suspend_then_promote` to resume the `other_thread` if it's
`ready` and, in any case, leave the [current thread] suspended.
```python
def canon_thread_suspend_then_promote(i):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  trap_if(i == thread.index)
  other_thread = thread.task.inst.threads.get(i)
  thread.suspend_then_promote(other_thread)
  return [0]
```


### 🧵 `canon thread.yield-then-promote`

For a canonical definition:
```wat
(canon thread.yield-then-promote (core func $yield-then-promote))
```
validation specifies:
* `$yield-then-promote` is given type `(func (param $i i32) (result i32))`

Calling `$yield-then-promote` invokes the following function which loads a
thread at index `$i` from the current component instance's `threads` table,
trapping on out-of-bounds or if the index of the current thread is passed, and
then calls `Thread.yield_then_promote` to resume the `other_thread` if it's
`ready` and, in any case, leave the [current thread] ready to run at some
nondeterministic point in the future chosen by the embedder.
```python
def canon_thread_yield_then_promote(i):
  thread = current_thread()
  trap_if(not thread.task.inst.may_leave)
  trap_if(i == thread.index)
  other_thread = thread.task.inst.threads.get(i)
  thread.yield_then_promote(other_thread)
  return [0]
```


### 📝 `canon error-context.new`

For a canonical definition:
```wat
(canon error-context.new $opts (core func $f))
```
validation specifies:
* `$f` is given type `(func (param $ptr T) (param $units T) (result i32))` where
  `T` is `i32`
  * 🐘 - `T` is `i32` or `i64` as determined by the `memory` field of `$opts`
* `async` is not present
* `memory` must be present

Calling `$f` calls the following function which uses the `$opts` immediate to
(nondeterministically) lift the debug message, create a new `ErrorContext`
value, store it in the current component instance's `handles` table and returns
its index.
```python
@dataclass
class ErrorContext:
  debug_message: String

def canon_error_context_new(opts, ptr, tagged_code_units):
  inst = current_instance()
  trap_if(not inst.may_leave)
  if DETERMINISTIC_PROFILE or random.randint(0,1):
    s = String(('', 'utf8', 0))
  else:
    cx = LiftLowerContext('lift', opts, inst)
    s = load_string_from_range(cx, ptr, tagged_code_units)
    s = host_defined_transformation(s)
  i = inst.handles.add(ErrorContext(s))
  return [i]
```
Supporting the requirement (introduced in the
[explainer](Explainer.md#error-context-type)) that wasm code does not depend on
the contents of `error-context` values for behavioral correctness, the debug
message is completely discarded nondeterministically or, in the deterministic
profile, always. Importantly (for performance), when the debug message is
discarded, it is not even lifted and thus the O(N) well-formedness conditions
are not checked. (Note that `host_defined_transformation` is not defined by the
Canonical ABI and stands for an arbitrary host-defined function.)


### 📝 `canon error-context.debug-message`

For a canonical definition:
```wat
(canon error-context.debug-message $opts (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32) (param $ptr T))` where `T` is `i32`
  * 🐘 - `T` is `i32` or `i64` as determined by the address type of
    `memory` from `$opts`
* `async` is not present
* `memory` must be present
* `realloc` must be present

Calling `$f` calls the following function which uses the `$opts` immediate to
lowers the `ErrorContext`'s debug message. While *producing* an `error-context`
value may nondeterministically discard or transform the debug message, a
single `error-context` value must return the same debug message from
`error-context.debug-message` over time.
```python
def canon_error_context_debug_message(opts, i, ptr):
  inst = current_instance()
  trap_if(not inst.may_leave)
  errctx = inst.handles.get(i)
  trap_if(not isinstance(errctx, ErrorContext))
  cx = LiftLowerContext('lower', opts, inst)
  trap_if(ptr != align_to(ptr, alignment(cx, StringType())))
  trap_if(ptr + elem_size(cx, StringType()) > len(cx.opts.memory))
  store(cx, errctx.debug_message, StringType(), ptr)
  return []
```
Note that `ptr` points to a region of memory (8 bytes for memory32, 16 bytes
for memory64) into which will be stored the pointer and length of the debug
string (allocated via `opts.realloc`). As with any `string` stored in linear
memory, `ptr` must be aligned to the pointer size (4 bytes for memory32, 8 bytes
for memory64) and the whole region must be in bounds, which is checked
(trapping otherwise) before `opts.realloc` is called.


### 📝 `canon error-context.drop`

For a canonical definition:
```wat
(canon error-context.drop (core func $f))
```
validation specifies:
* `$f` is given type `(func (param i32))`

Calling `$f` calls the following function, which drops the error context value
at the given index from the current component instance's `handles` table:
```python
def canon_error_context_drop(i):
  inst = current_instance()
  trap_if(not inst.may_leave)
  errctx = inst.handles.remove(i)
  trap_if(not isinstance(errctx, ErrorContext))
  return []
```


### 🧵② `canon thread.spawn-ref`

For a canonical definition:
```wat
(canon thread.spawn-ref shared? $ft (core func $spawn_ref))
```
validation specifies:
* `$ft` must refer to the type `(shared? (func (param $c T)))` where `T` is `i32`
  * 🐘 - `T` may be `i32` or `i64`.
* `$spawn_ref` is given type
  `(shared? (func (param $f (ref null $ft)) (param $c T) (result $e i32)))`
  where `T` comes from `$ft` as defined above

When the `shared` immediate is not present, the spawned thread is
*cooperative*, only switching at specific program points. When the `shared`
immediate is present, the spawned thread is *preemptive* and able to execute in
parallel with all other threads.

> Note: ideally, a thread could be spawned with [arbitrary thread parameters].
> Currently, that would require additional work in the toolchain to support so,
> for simplicity, the current proposal simply fixes a single `i32` or `i64` parameter
> type. However, `thread.spawn-ref` could be extended to allow arbitrary thread
> parameters in the future, once it's concretely beneficial to the toolchain.
> The inclusion of `$ft` ensures backwards compatibility for when arbitrary
> parameters are allowed.

Calling `$spawn_ref` invokes the following function which simply fuses the
`thread.new-ref` and `thread.resume-later` built-ins, allowing
thread-creation to skip the intermediate "suspended" state transition.
```python
def canon_thread_spawn_ref(shared, ft, f, c):
  trap_if(not current_instance().may_leave)
  if DETERMINISTIC_PROFILE:
    return [0]
  [new_thread_index] = canon_thread_new_ref(shared, ft, f, c)
  [] = canon_thread_resume_later(shared, new_thread_index)
  return [new_thread_index]
```
Note: `canon_thread_new_ref` has not yet been defined, but will be added as
part of adding a [GC ABI option] to the Canonical ABI and would work
like `canon_thread_new_indirect` minus the table access and type check.


### 🧵② `canon thread.spawn-indirect`

For a canonical definition:
```wat
(canon thread.spawn-indirect shared? $ft $tbl (core func $spawn_indirect))
```
validation specifies:
* `$ft` must refer to the type `(shared? (func (param $c T)))` where `T` is `i32`
  * 🐘 - `T` may be `i32` or `i64`
* `$tbl` must refer to a shared table whose element type matches
  `(ref null (shared? func))`
* `$spawn_indirect` is given type `(shared? (func (param $i U) (param $c T) (result $e i32)))`
  where `T` comes from `$ft` as defined above and `U` is `i32`
  * 🐘 - `U` is `i32` or `i64` as determined by `$tbl`'s address type

When the `shared` immediate is not present, the spawned thread is
*cooperative*, only switching at specific program points. When the `shared`
immediate is present, the spawned thread is *preemptive* and able to execute in
parallel with all other threads.

Calling `$spawn_indirect` invokes the following function which simply fuses
the `thread.new-indirect` and `thread.resume-later` built-ins, allowing
thread-creation to skip the intermediate "suspended" state transition.
```python
def canon_thread_spawn_indirect(shared, ft, ftbl: Table[CoreFuncRef], fi, c):
  trap_if(not current_instance().may_leave)
  if DETERMINISTIC_PROFILE:
    return [0]
  [new_thread_index] = canon_thread_new_indirect(shared, ft, ftbl, fi, c)
  [] = canon_thread_resume_later(shared, new_thread_index)
  return [new_thread_index]
```
Note: `canon_thread_new_indirect` has not yet been extended to take a
`shared` parameter, but will be as [shared-everything-threads] progresses.


### 🧵② `canon thread.available-parallelism`

For a canonical definition:
```wat
(canon thread.available-parallelism shared? (core func $f))
```
validation specifies:
* `$f` is given type `(func shared? (result i32))`.

Calling `$f` returns the number of threads the underlying hardware can be
expected to execute in parallel. This value can be artificially limited by
engine configuration and is not allowed to change over the lifetime of a
component instance.

```python
def canon_thread_available_parallelism():
  if DETERMINISTIC_PROFILE:
    return [1]
  else:
    return [NUM_ALLOWED_THREADS]
```


[Virtualization Goals]: Goals.md
[Canonical Definitions]: Explainer.md#canonical-definitions
[`canonopt`]: Explainer.md#canonical-definitions
[`canon`]: Explainer.md#canonical-definitions
[Type Definitions]: Explainer.md#type-definitions
[Component Invariant]: Explainer.md#component-invariants
[JavaScript Embedding]: Explainer.md#JavaScript-embedding
[Adapter Functions]: FutureFeatures.md#custom-abis-via-adapter-functions
[Shared-Everything Dynamic Linking]: examples/SharedEverythingDynamicLinking.md
[Concurrency Explainer]: Concurrency.md
[Suspended]: Concurrency.md#thread-built-ins
[Thread Index]: Concurrency.md#thread-built-ins
[Async Call Stack]: Concurrency.md#subtasks-and-supertasks
[Structured Concurrency]: Concurrency.md#subtasks-and-supertasks
[Backpressure]: Concurrency.md#backpressure
[Thread]: Concurrency.md#threads-and-tasks
[Current Thread]: Concurrency.md#current-thread-and-task
[Current Task]: Concurrency.md#current-thread-and-task
[Blocks]: Concurrency.md#blocking
[Blocked]: Concurrency.md#blocking
[Waiting On External I/O And Yielding]: Concurrency.md#blocking
[Subtasks]: Concurrency.md#subtasks-and-supertasks
[End]: Concurrency.md#streams-and-futures
[Readable and Writable Ends]: Concurrency.md#streams-and-futures
[Thread-Local Storage]: Concurrency.md#thread-local-storage
[Cancellation]: Concurrency.md#cancellation
[Subtask State Machine]: Concurrency.md#cancellation
[Stream Readiness]: Concurrency.md#stream-readiness

[Lazy Lowering]: https://github.com/WebAssembly/component-model/issues/383
[GC ABI Option]: https://github.com/WebAssembly/component-model/issues/525

[Core WebAssembly Embedding]: https://webassembly.github.io/spec/core/appendix/embedding.html
[`store`]: https://webassembly.github.io/spec/core/exec/runtime.html#syntax-store
[`module_instantiate`]: https://webassembly.github.io/spec/core/appendix/embedding.html#modules
[`func_invoke`]: https://webassembly.github.io/spec/core/appendix/embedding.html#functions
[`funcinst`]: https://webassembly.github.io/spec/core/exec/runtime.html#syntax-funcinst

[Administrative Instructions]: https://webassembly.github.io/spec/core/exec/runtime.html#syntax-instr-admin
[Implementation Limits]: https://webassembly.github.io/spec/core/appendix/implementation.html
[Function Instance]: https://webassembly.github.io/spec/core/exec/runtime.html#function-instances
[Two-level]: https://webassembly.github.io/spec/core/syntax/modules.html#syntax-import

[Multi-value]: https://github.com/WebAssembly/multi-value/blob/master/proposals/multi-value/Overview.md
[Exceptions]: https://github.com/WebAssembly/exception-handling/blob/main/proposals/exception-handling/Exceptions.md
[WASI]: https://github.com/webassembly/wasi
[Deterministic Profile]: https://github.com/WebAssembly/profiles/blob/main/proposals/profiles/Overview.md
[stack-switching]: https://github.com/WebAssembly/stack-switching
[Control Tags]: https://github.com/WebAssembly/stack-switching/blob/main/proposals/stack-switching/Explainer.md#declaring-control-tags
[`memaddr`]: https://webassembly.github.io/spec/core/exec/runtime.html#syntax-memaddr
[`memaddrs` table]: https://webassembly.github.io/spec/core/exec/runtime.html#syntax-moduleinst
[`memidx`]: https://webassembly.github.io/spec/core/syntax/modules.html#syntax-memidx
[`memory` instance]: https://webassembly.github.io/spec/core/exec/runtime.html#memory-instances
[`memtype`]: https://webassembly.github.io/spec/core/syntax/types.html#memory-types

[Alignment]: https://en.wikipedia.org/wiki/Data_structure_alignment
[UTF-8]: https://en.wikipedia.org/wiki/UTF-8
[UTF-16]: https://en.wikipedia.org/wiki/UTF-16
[Latin-1]: https://en.wikipedia.org/wiki/ISO/IEC_8859-1
[Unicode Scalar Value]: https://unicode.org/glossary/#unicode_scalar_value
[Unicode Code Point]: https://unicode.org/glossary/#code_point
[Code Units]: https://www.unicode.org/glossary/#code_unit
[Surrogate]: https://unicode.org/faq/utf_bom.html#utf16-2
[Name Mangling]: https://en.wikipedia.org/wiki/Name_mangling
[Fibers]: https://en.wikipedia.org/wiki/Fiber_(computer_science)
[Asyncify]: https://emscripten.org/docs/porting/asyncify.html

[`import_name`]: https://clang.llvm.org/docs/AttributeReference.html#import-name
[`export_name`]: https://clang.llvm.org/docs/AttributeReference.html#export-name

[shared-everything-threads]: https://github.com/WebAssembly/shared-everything-threads
[Arbitrary Thread Parameters]: https://github.com/WebAssembly/shared-everything-threads/discussions/3

[`threading`]: https://docs.python.org/3/library/threading.html
[`threading.Thread`]: https://docs.python.org/3/library/threading.html#thread-objects
[`threading.Lock`]: https://docs.python.org/3/library/threading.html#lock-objects
[`threading.local`]: https://docs.python.org/3/library/threading.html#thread-local-data

[OIO]: https://en.wikipedia.org/wiki/Overlapped_I/O
[io_uring]: https://en.wikipedia.org/wiki/Io_uring
