"""Temporary, fixed native Linux entry diagnostic; not a release gate."""
from pathlib import Path
import hashlib, json, os, random, statistics, subprocess, time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "fp-entry-results"
OUT.mkdir(exist_ok=True)
BASE = "207278fe59c7280c87bc23d64f14ca23319a9fbc"
HEADER = "internal/platform/native/adapter.h"
SOURCE = "internal/platform/native/adapter.c"

MAIN = r'''
#define _GNU_SOURCE
#include "adapter.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
extern uint32_t base_enter(const void *, struct wasmvm_record *);
extern uint32_t guest(struct wasmvm_record *);
typedef uint32_t (*entry_fn)(const void *, struct wasmvm_record *);
static entry_fn volatile selected;
static uint32_t direct(const void *entry, struct wasmvm_record *ctx) {
    return ((uint32_t (*)(struct wasmvm_record *))entry)(ctx);
}
static uint64_t ns(clockid_t clock) {
    struct timespec t;
    if (clock_gettime(clock, &t)) abort();
    return (uint64_t)t.tv_sec * 1000000000 + t.tv_nsec;
}
static void run(struct wasmvm_record *ctx, unsigned count) {
    entry_fn fn = selected;
    uint64_t expected = ctx->result_lo + count;
    for (unsigned i = 0; i < count; ++i)
        if (fn(guest, ctx) != 1) abort();
    if (ctx->result_lo != expected) abort();
}
int main(int argc, char **argv) {
    if (argc != 2) return 1;
    selected = !strcmp(argv[1], "base") ? base_enter :
               !strcmp(argv[1], "head") ? wasmvm_enter : direct;
    struct wasmvm_record ctx = {.version = 2, .max_depth = 1};
    setvbuf(stdout, NULL, _IOLBF, 0);
    puts("ready");
    char line[16];
    if (!fgets(line, sizeof(line), stdin)) return 2;
    for (int i = 0; i < 3; ++i) run(&ctx, 250000);
    puts("warm");
    for (int i = 0; i < 7; ++i) {
        if (!fgets(line, sizeof(line), stdin)) return 3;
        uint64_t w = ns(CLOCK_MONOTONIC), c = ns(CLOCK_PROCESS_CPUTIME_ID);
        run(&ctx, 250000);
        c = ns(CLOCK_PROCESS_CPUTIME_ID) - c;
        w = ns(CLOCK_MONOTONIC) - w;
        printf("{\"wallNs\":%llu,\"cpuNs\":%llu,\"result\":%llu}\n",
               (unsigned long long)w, (unsigned long long)c,
               (unsigned long long)ctx.result_lo);
    }
    return 0;
}
'''
GUEST = '.text\n.globl guest\n.type guest,@function\nguest:\n addq $1,96(%rdi)\n movl $1,%eax\n ret\n.section .note.GNU-stack,"",@progbits\n'
def capture(command):
    return subprocess.check_output(command, cwd=ROOT, text=True)
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
base = capture(["git", "show", BASE + ":" + SOURCE])
header = (ROOT / HEADER).read_text()
head = (ROOT / SOURCE).read_text()
for name, data in [("base.c", base.replace("wasmvm_", "base_")),
                   ("base.h", header.replace("wasmvm_", "base_")),
                   ("adapter.h", header), ("head.c", head),
                   ("main.c", MAIN), ("guest.s", GUEST)]:
    (OUT / name).write_text(data)
# The baseline include must resolve its separately renamed record declarations.
(OUT / "base.c").write_text((OUT / "base.c").read_text().replace('"adapter.h"', '"base.h"'))
clang = "/usr/lib/llvm-22/bin/clang"
profiles = {"O2": ["-O2"], "O3-full-LTO": ["-O3", "-flto=full", "-fuse-ld=lld"]}
builds = {}
for profile, flags in profiles.items():
    binary = OUT / ("probe-" + profile)
    command = [clang, *flags, "-march=x86-64", "-mtune=generic", "-o", str(binary),
               *[str(OUT / f) for f in ["main.c", "base.c", "head.c", "guest.s"]], "-lm"]
    subprocess.run(command, check=True, timeout=120)
    builds[profile] = {"command": command, "binary": str(binary), "sha256": digest(binary)}
    (OUT / (profile + ".asm")).write_text(capture(["/usr/lib/llvm-22/bin/llvm-objdump", "-d", str(binary)]))
plan = {"blocks": 20, "samples": 7, "entriesPerCall": 250000, "warmups": 3,
        "seed": 202611131661, "base": BASE, "head": capture(["git", "rev-parse", "HEAD"]).strip(),
        "sourceSHA256": {"base": hashlib.sha256(base.encode()).hexdigest(), "head": hashlib.sha256(head.encode()).hexdigest()},
        "compiler": capture([clang, "--version"]), "host": capture(["lscpu"]), "builds": builds,
        "scope": "Native Linux physical runner. Same binary contains exact base/head adapters, chosen through a volatile pointer; identical-binary aliases. Three unmeasured batches then seven individually interleaved checked calls. Native arithmetic control omits VM admission/FP isolation, and is not an equivalent VM. C boundary diagnostic, not Go/LLGo/P3 throughput or full-profile acceptance. Fixed 20 blocks, no extension or pruning. No concurrent owned build/test/profile during measurement."}
(OUT / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")
rng = random.Random(plan["seed"])
rows = []
for block in range(plan["blocks"]):
    order = list(profiles)
    rng.shuffle(order)
    for profile in order:
        children = []
        roles = [(role, alias) for role in ["base", "head", "direct"] for alias in ["", "-aa"]]
        rng.shuffle(roles)
        try:
            for role, alias in roles:
                p = subprocess.Popen([builds[profile]["binary"], role], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
                child = {"id": role + alias, "process": p, "calls": []}
                children.append(child)
                assert p.stdout.readline() == "ready\n"
                p.stdin.write("run\n"); p.stdin.flush()
                assert p.stdout.readline() == "warm\n"
            orders = []
            for sample in range(plan["samples"]):
                order = list(children); rng.shuffle(order)
                orders.append([c["id"] for c in order])
                for c in order:
                    p = c["process"]; p.stdin.write("sample\n"); p.stdin.flush()
                    value = json.loads(p.stdout.readline())
                    assert value["result"] == (sample + 4) * 250000
                    c["calls"].append(value)
            for c in children:
                p = c["process"]; p.stdin.close()
                assert p.stdout.read() == "" and p.wait(timeout=10) == 0
                row = {"block": block, "profile": profile, "id": c["id"], "calls": c["calls"], "orders": orders,
                       "cpuNsPerEntry": statistics.median(v["cpuNs"] for v in c["calls"]) / 250000,
                       "wallNsPerEntry": statistics.median(v["wallNs"] for v in c["calls"]) / 250000}
                rows.append(row)
                with (OUT / "rows.jsonl").open("a") as f: f.write(json.dumps(row) + "\n")
        finally:
            for c in children:
                p = c["process"]
                if p.poll() is None: p.kill(); p.wait()
    print("block", block, "checked", flush=True)
summary = {profile: {role: {metric: statistics.median(r[metric] for r in rows if r["profile"] == profile and r["id"] == role)
                         for metric in ["cpuNsPerEntry", "wallNsPerEntry"]}
                     for role in ["base", "base-aa", "head", "head-aa", "direct", "direct-aa"]} for profile in profiles}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
