(module (import "wasi_snapshot_preview1" "args_sizes_get" (func $host (param i32 i32) (result i32)))
 (memory (export "memory") 1 1)
 (func (export "run") (param $seed i32) (param $n i32) (result i32) (local $i i32) (local $x i32)
 local.get $seed local.set $x
 loop $again
 i32.const 0 i32.const 4 call $host if unreachable end
 local.get $x i32.const 0 i32.load i32.const 4 i32.load i32.add i32.add local.set $x
 local.get $i i32.const 1 i32.add local.tee $i local.get $n i32.lt_u br_if $again
 end local.get $x))
