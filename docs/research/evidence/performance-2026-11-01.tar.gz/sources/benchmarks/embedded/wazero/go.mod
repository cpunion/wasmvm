module github.com/cpunion/wasmvm/benchmarks/embedded/wazero

go 1.25.0

require github.com/tetratelabs/wazero v1.12.0

require golang.org/x/sys v0.44.0 // indirect
