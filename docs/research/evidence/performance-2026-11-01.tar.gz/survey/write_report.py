from pathlib import Path
import json,statistics,math,re,csv
ROOT=Path.cwd();P=ROOT/'artifacts/survey-20261101';D=ROOT/'docs/research';C=P/'components'
core=json.loads((P/'results.json').read_text());rows=json.loads((P/'summary.json').read_text());modern=json.loads((P/'modern/results.json').read_text());mr=json.loads((P/'modern/summary.json').read_text());idx={(x['runtime'],x['workload']):x for x in rows};mi={(x['runtime'],x['workload']):x for x in mr}
def num(n):return f'{n:.3f}' if n<10 else f'{n:.2f}' if n<1000 else f'{n:.0f}'
def table(headers,items):return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join('---' for _ in headers)+' |']+['| '+' | '.join(map(str,row))+' |' for row in items])+'\n'
def gm(a):return math.exp(statistics.mean(math.log(v) for v in a))
family=[]
for f in sorted({x['family'] for x in rows}):
 cases=[x['workload'] for x in rows if x['family']==f and x['runtime']=='wasmvm-llgo-native' and x['unit']!='ns/call']
 family.append([f,len(cases)]+[f'{gm([idx[("wasmvm-llgo-native",w)]["warm"]/idx[(ref,w)]["warm"] for w in cases]):.3f}x' for ref in ['wazero-compiler','wasmtime-cranelift','wasmer-cranelift']]+[f'{gm([idx[("wasmvm-llgo-interpreter",w)]["warm"]/idx[(ref,w)]["warm"] for w in cases]):.3f}x' for ref in ['wazero-interpreter','wasmedge-interpreter']])
selected=['core/integer-sustained','core/memory-sustained','core/function-calls','runtime/indirect-calls','memory/narrow-unaligned','runtime/bulk-overlap','table/table-roundtrip','vector-integer/shuffle','vector-float/rounding-f32x4']
maincases=[[w]+[num(idx[(r,w)]['warm']) for r in ['wasmvm-go-native','wasmvm-llgo-native','wazero-compiler','wasmtime-cranelift','wasmer-cranelift']] for w in selected]
moderncases=[]
for w in dict.fromkeys(x['workload'] for x in mr):
 moderncases.append([w]+[num(mi[(r,w)]['warm']) if (r,w) in mi else 'unsupported' for r in ['wasmvm-go-native','wasmvm-llgo-native','wazero-compiler','wasmtime-cranelift','wasmer-cranelift','wasmedge-interpreter']])
comp={};ownmetrics={}
for f in C.glob('*.log'):
 if f.name.startswith(('component-','wasi-','network-')):
  compiler='llgo' if '-llgo-' in f.name else 'go'
  for line in f.read_text().splitlines():
   m=re.match(r'^(Benchmark\S+?)(?:-\d+)?\s+(\d+)\s+([0-9.]+)\s+ns/op(.*)',line)
   if m:
    comp.setdefault(m[1],{}).setdefault(compiler,[]).append(float(m[3]));metrics={'ns/op':float(m[3])};tail=m[4].split()
    for i in range(0,len(tail)-1,2):
     try:metrics[tail[i+1]]=float(tail[i])
     except ValueError:pass
    ownmetrics.setdefault((m[1],compiler),[]).append(metrics)
paired_seen=set()
for f in (C/'paired').glob('*.log'):
 if '-reference-' in f.name or f.name.startswith('async-'):continue
 compiler='llgo' if '-llgo-' in f.name else 'go'
 for line in f.read_text().splitlines():
  m=re.match(r'^(Benchmark\S+?)(?:-\d+)?\s+(\d+)\s+([0-9.]+)\s+ns/op(.*)',line)
  if m:
   key=(m[1],compiler)
   if key not in paired_seen:comp.setdefault(m[1],{})[compiler]=[];paired_seen.add(key)
   comp[m[1]][compiler].append(float(m[3]))
comp={k:{c:statistics.median(a) for c,a in d.items()} for k,d in comp.items()}
def ref_values(name,key):
 return [json.loads(((C/'paired'/f'{name}-reference-{i}.log') if (C/'paired'/f'{name}-reference-{i}.log').exists() else C/f'reference-{name}-{i}.log').read_text())[key] for i in range(3)]
def ref(name,key):return statistics.median(ref_values(name,key))
comparisons=[
 ('Component scalar API','BenchmarkComponentRuntime/native/PublicWarm','scalar','warm_ns_per_call',1),
 ('Guest resource new/rep/drop','BenchmarkResourceInstructions/native','resource-loop','warm_ns_per_call',128),
 ('Owned resource, four public calls','BenchmarkOwnedResourceLifetime/native','ownership','warm_ns_per_lifetime',1),
 ('Packed 16 KiB bytes, typed reference','BenchmarkByteListTransfer/native/packed','bytes-typed','warm_call_and_result_drop_ns',1),
 ('P2 arguments','BenchmarkEnvironmentArgumentCount/native','environment','warm_ns_per_call',1),
 ('P2 secure random, 16 KiB','BenchmarkRandomBytes/native','random','warm_ns_per_call',1),
 ('P2 wall clock','BenchmarkWallClockNow/native','wall_clock','warm_ns_per_call',1),
 ('P2 expired clock subscription','BenchmarkPollClockSubscriptions/native','poll_clock','warm_ns_per_call',128),
 ('P2 output-stream write, 4 KiB','BenchmarkIOWriteBatch/native','io_streams','warm_ns_per_call',128),
 ('P2 filesystem stat','BenchmarkFileSystemStatBatch/native','filesystem','warm_call_ns',128),
 ('P2 numeric-IP lookup/resource lifetime','BenchmarkNetworkLiteralBatch/native','network','warm_call_ns',128),
 ('P2 TCP round trip, 4 KiB each way','BenchmarkTCPRoundtripBatch/native','tcp','warm_ns_per_call',128),
 ('P2 UDP round trip, 4 KiB each way','BenchmarkUDPRoundtripBatch/native','udp','warm_ns_per_call',128),
 ('P2 HTTP fields lifetime','BenchmarkHTTPFields/native','http-fields','warm_ns_per_call',128),
 ('P2 HTTP 4 KiB body lifetime','BenchmarkHTTPBodyTransfer/native','http-body','warm_ns_per_call',128),
 ('P2 C command, warm reusable instance','BenchmarkWASICommand/world-c-command/native','command-c','warm_command_ns',1),
 ('P2 composed Rust command, warm instance','BenchmarkWASICommand/world-composed-command/native','command-rust','warm_command_ns',1)]
compt=[]
for label,name,reference,key,n in comparisons:
 own=comp[name];rv=ref(reference,key);compt.append([label,num(own['go']/n),num(own['llgo']/n),num(rv/n),f'{own["llgo"]/rv:.2f}x',num(min(ref_values(reference,key))/n)+'–'+num(max(ref_values(reference,key))/n)])
for entry in ['direct','run']:
 vals={}
 for compiler in ['go','llgo']:
  vals[compiler]=statistics.median(json.loads((C/'paired'/f'async-{entry}-{compiler}-{i}.log').read_text())['warm_call_ns'] for i in range(3))
 rv=ref('async-'+entry,'warm_call_ns');compt.append(['Async '+entry+(' (129 callbacks/call)' if entry=='run' else ' (0 callbacks/call)'),num(vals['go']),num(vals['llgo']),num(rv),f'{vals["llgo"]/rv:.2f}x',num(min(ref_values('async-'+entry,'warm_call_ns')))+'–'+num(max(ref_values('async-'+entry,'warm_call_ns')))])
p1=json.loads((P/'preview1/summary.json').read_text());p1table=[]
for w in ['args-sizes','environ-sizes','args-copy']:
 p1table.append([w]+[num(p1[w][r]['warmNsPerSourceIteration']) for r in ['head-go-native','head-llgo-native','wazero-compiler','wasmtime','wasmer']])
phases=[]
for runtime in core['runtimes']:
 x=idx[(runtime,'core/integer-sustained')];p=x['phasesNs'];phases.append([runtime,num(x['processReadyNs']/1000)]+[num(p[k]/1000) for k in ['load','engineSetup','compileValidate','instantiate','exportLookup','firstCall']]+[num(x['warm']*5000000/1000),num(p['cleanup']/1000)])
body='''# Performance gap audit: 2026-11-01

The owned engine is functionally broad, but **performance parity is not achieved**.
LLGo native scalar loops are competitive in this local portfolio; GC, shared
memory, bulk-memory and several component/WASI paths have large deficits.
A favorable overall average would conceal these failures and is not an
acceptance verdict. The [standards audit](status-2026-11-01.md) independently
records implementation scope and conformance evidence.

## Snapshot and measurement boundaries

- Engine: `4ad69c24de32a96310799ad76bd10af118afed42` (merged PR #84), archived
  unchanged for both host compilers. Harness-only modern-feature/P1 adapters are
  retained separately, with engine source hashes checked unchanged.
- Host: Apple M4 Max, macOS arm64, shared workstation. Core starting/ending load
  averages and full platform identity are retained. No CPU affinity, isolation,
  frequency lock or controlled A/A calibration is claimed.
- Go 1.27.3; LLGo `8e45ed5e8bbd080995b0516ef40ec1f5218d2e1f`, `-O3 -lto=full`.
- References: wazero 1.12.0 interpreter/native; Wasmtime 48.0.1 Cranelift speed;
  Wasmer 7.3.0 Cranelift; WasmEdge 0.17.1 **interpreter**. SDK pins, linked library
  hashes, commands, compiler identities and notices are retained. The system's
  older Wasmer CLI was not used. WasmEdge AOT/JIT was not timed.
- Core: 68 existing fixtures, eight source-manifest families, nine configurations,
  three fresh processes per pair, first call + two warmups + seven warm samples:
  **1,836 processes / 18,360 checked guest calls**. Warm calls are serially
  randomized/interleaved; setup never runs concurrently with a timed call.
- Modern: four GC and six private/shared/atomic/wait fixtures; three process
  blocks plus alternate-seed checks. Twelve actual GC validation rejections
  from wazero/Wasmer are retained as unsupported, without synthetic timings.
- P1: three actual WASI host-call loops plus a compute control, eight
  configurations, three processes: 96 successful process records and 1,280
  checked calls including alternate inputs. Components/P2/async use three fresh
  processes per reported configuration. Final native comparisons randomize
  Go/LLGo/reference process order within each workload/block; initial whole-suite
  rounds are retained separately. Existing Go benchmark and C/Rust adapters
  retain their explicit boundary differences.

Core tables use public embedding API calls, including unavoidable admission,
marshalling and result handling. Every compute call executes the same binary,
seed and iteration count and checks its output. Stateful fixtures reset inside
the timed call. Preparation, instantiation, first use, warm execution and cleanup
are measured independently; no startup/control median is subtracted.

**Units:** core/modern rows are ns per source iteration, not per Wasm/native
instruction. Source-call loops may be inlined. Component/WASI units are identified
per row; batch values are divided by the actual batch count. Small call controls
are clock-resolution limited, particularly the C clock on this macOS host.
Near-parity differences do not establish statistically calibrated parity.

## Core families and named competitors

Ratios are wasmvm LLGo / named reference; **lower is better**, 2x means twice the
elapsed time. Each cell is a geometric mean within that existing source-manifest
family. Empty-call and growth-only controls are excluded from family aggregates.
These diagnostic families are not the still-unaccepted application-weighted M2
portfolio; there is deliberately no synthetic fastest-engine aggregate.

'''+table(['Family','Cases','Native / wazero','Native / Wasmtime','Native / Wasmer','Interpreter / wazero','Interpreter / WasmEdge'],family)+'''
Native scalar arithmetic is close to Cranelift and often ahead of wazero. SIMD
still has systematic gaps. Fast table cases coexist with a severe bulk-memory
outlier in the runtime family; averages must not excuse that outlier. The LLGo
interpreter trails WasmEdge across many cases and also loses individual cases
to wazero. All 68 cases and both own compilers/backends are retained in the
[complete Core table](performance-2026-11-01-core.md).

Representative native rows, ns/source iteration:

'''+table(['Workload','Go native','LLGo native','wazero native','Wasmtime','Wasmer'],maincases)+'''
The bulk case performs an 8 KiB fill and overlapping 8 KiB copy on every source
iteration. Its deficit is not explained by process startup or first use.
The corresponding LLGo interpreter result is also slow; switching backend alone
is not a solution.

## GC and Core Threads

The WasmEdge column remains an interpreter comparison. Unsupported GC is not a
competitive speed result. All own native cases actually select the owned native
backend; runtime helpers execute individual operations without interpreting a
whole guest function. Nonetheless, native helper traffic can make a compiled
function slower than the interpreter.

'''+table(['Workload','Go native','LLGo native','wazero native','Wasmtime','Wasmer','WasmEdge interp'],moderncases)+'''
The mutable-field and indirect GC cases expose deficits approaching three orders
of magnitude against Wasmtime. Linked allocation is a different workload with
a smaller, but still substantial, gap. It does not measure full-GC pause times
or memory reclamation under sustained pressure. Shared ordinary accesses and
uncontended atomics likewise have large per-operation overhead. Wait mismatch,
zero timeout and empty notify are separate operations; none establishes
contended scaling, wakeup tail latency or thread-creation throughput.

## WASI P1 host-call boundary

Each iteration calls the actual provider, checks errno, reads the guest-memory
result and updates a checksum. Args are `[guest,arg]`, environment is
`KEY=VALUE`; no ambient environment is inherited. Times are ns/source iteration,
with compile/instantiate/first-call/close retained separately.

'''+table(['Workload','Go native','LLGo native','wazero native','Wasmtime','Wasmer'],p1table)+'''
This confirms substantial P1 call-boundary/provider overhead, particularly under
LLGo, even for in-memory argument/environment operations. It is not a filesystem
or network benchmark. The first Wasmer compute-control adapter incorrectly
created an uninitialized WASI environment; its cleanup aborted. That harness
failure is retained. The corrected adapter creates the environment only for
importing modules; the entire final matrix, including the control, passed.
No engine crash is classified as an unsupported capability or successful sample.

## Component, WASI P2 and async

Times below are ns per named operation, or per complete API call where indicated.
The reference is Wasmtime 48.0.1. The byte transfer uses its **typed Rust API**,
not the much slower dynamic C byte-list expansion. TCP/UDP/HTTP and composed
commands use the Rust reference with actual providers; simple operations use
the pinned C component API. Go and LLGo results use the public owned API.

'''+table(['Operation / unit','Go native','LLGo native','Wasmtime','LLGo / reference','Reference min–max'],compt)+'''
The generic per-element 16 KiB byte API is additionally much slower than the
packed API; both raw results are retained. Different entropy algorithms/provider
policies apply to random generation, so that row does not rank cryptographic
primitive speed. TCP/UDP use loopback, 128 round trips/batch and 4 KiB in each
direction; connection setup/teardown is excluded. HTTP field/body lifetimes are
not full network requests. Warm command rows reuse instances; they are not cold
CLI startup. Async `run` includes 129 callbacks/call and the public/task boundary;
no empty-call subtraction is used to invent a pure callback latency.

Go and LLGo have different host costs; the measured native guest arithmetic
does not predict the speed of a provider or component call. Resource, poll, numeric-IP lookup, canonical transfer and
HTTP lifetime paths still fail the desired across-family parity target. Reference sample ranges remain visible: workstation/process scheduling makes
some rows noisy, and three processes do not calibrate small differences. These
are selected boundary measurements, not exhaustive P2/P3 performance coverage.

## Startup, preparation, first use and cleanup

The sustained integer fixture below executes 5,000,000 iterations in each call.
All entries are **microseconds**; the warm column is one complete API call, not
ns/iteration. Preparation is the actual combined validate/compile API interval;
no second standalone validator call is added. Cleanup includes explicit owned
Store reclamation. A first call is measured separately from warm execution.

'''+table(['Configuration','Ready','Load','Engine/store','Prepare','Instantiate','Lookup','First','Warm call','Cleanup'],phases)+'''
Internal dispatch diagnostics separately retain decode, validate, lower, slot
allocation and native compilation/publication groups. They reuse frames and
bypass public admission/marshalling, so they cannot replace public-API results.
Native optimization/emission/publication are not individually observable through
all peer APIs in this audit; those finer costs remain unmeasured rather than
being inferred by subtracting totals. OS file/executable caches are not flushed.

## Why the gaps are architectural

The following source observations explain plausible causes; they are not a
profile-based attribution of every measured nanosecond.

1. **Per-operation native exits.** The owned
   [native execution loop](../../internal/engine/nativeexec/execution.go)
   publishes state, enters generated code, reads state and returns a runtime
   helper request for many GC/shared/bulk operations. The common execution loop
   executes that operation and reenters native code. Repeating this for cheap
   field loads or atomics magnifies ABI/state/cancellation costs. Go-to-LLGo
   differences on the same guest instruction selection show that host helpers
   and transitions also matter.
2. **Shared-memory synchronization.**
   [Shared-access lowering](../../internal/compiler/codegen/threads.go) marks
   each shared memory access for a helper; one Engine domain lock orders all
   shared access. This is a deliberate conservative memory-model contract, but
   is expensive even without contention. Wasmtime lowers normal accesses and
   atomics directly through its compiler IR; it calls runtime support for waits
   and other operations that actually need it.
3. **GC field access.** Wasmtime's
   [GC lowering](https://github.com/bytecodealliance/wasmtime/blob/v48.0.1/crates/cranelift/src/func_environ/gc.rs)
   derives field offsets, emits checked heap addresses and machine loads/stores,
   with barriers where required. It does not return to a host dispatcher for
   every scalar struct field. The indirect fixture prevents explaining the
   entire deficit solely as elimination of a single nonescaping struct.
4. **Bulk primitives.** The owned
   [bulk implementation](../../internal/engine/execute/bulk.go) preserves bounds,
   overlap and bounded cancellation through 4 KiB chunks and polls. Reference
   engines can lower copy/fill to efficient native primitives. The measured
   deficit includes these different interruption policies; optimizing it must
   preserve the declared cancellation/overlap behavior.
5. **Canonical/host paths and LLGo.** Resource ownership, marshalled Values,
   per-call admission, lifecycle and readiness/provider boundaries are visible
   in the component results. Their amplification under LLGo warrants profiles
   and allocation/transition diagnostics, not an assumption that native guest
   instructions alone determine end-to-end throughput.

## Priority and remaining measurements

1. Implement direct native GC field/array fast paths and precise root/barrier
   contracts; reduce helper exits and repeated state traffic.
2. Replace per-access shared-memory host exits with a correct native memory-model
   strategy, including mixed widths, grow, atomics and cancellation; then measure
   contention/scaling and wait/notify tails on both ISAs.
3. Improve overlap-safe bulk copy/fill and P1 host boundaries without weakening
   resource limits, cancellation or errno/trap semantics.
4. Reduce Canonical ABI/resource/poll/lookup overhead, profile LLGo helper/runtime
   costs and compare the same signatures/ownership policies. Optimize SIMD
   selection/register allocation and interpreter dispatch with the complete
   affected family visible.
5. Close performance acceptance with realistic compute applications from at least
   two pinned guest toolchains, broader large/small compile portfolios, GC pressure,
   cold CLI/application startup, RSS/code size, scaling and cancellation latency.
   The current C/Rust command consumers are integration workloads, not a substitute
   for those compute/scaling portfolios.

Wago, WAMR, browser engines, Wasmer's other compilers and WasmEdge AOT/JIT are
not timed here. Neither their published speed claims nor missing samples are
substituted into the measured matrix. Linux amd64 results must be kept separate
from this Mac table; the opt-in CI survey produces a fresh platform-specific
artifact. Controlled acceptance and calibrated parity on both accepted platforms
remain open. No performance requirement is relaxed by this audit.

## Reproduce and inspect evidence

The existing Runtime benchmarks workflow accepts `suite=survey`: it reuses its
pinned Go/LLGo and SDK setup, runs the 68-case Core and 10-case modern matrix,
and uploads phase records and complete Markdown tables. It does not run the
unrelated sustained integer acceptance gate. Existing PR and full scopes remain
available. This broad survey is opt-in, not an additional default semantic job.

Locally, use the SDK roots from the checksum-pinned tool manifests:

```sh
export WASMVM_LLGO=/path/to/pinned/llgo
export WASMVM_LLGO_REVISION=8e45ed5e8bbd080995b0516ef40ec1f5218d2e1f
python3 benchmarks/survey.py --output artifacts/survey \\
  --wasmtime-sdk "$WASMTIME_SDK" --wasmer-sdk "$WASMER_SDK" \\
  --wasmedge-sdk "$WASMEDGE_SDK"
python3 benchmarks/survey_modern.py --core-output artifacts/survey
python3 benchmarks/modern/verify.py
```

Component/P2/async probe sources and boundaries are documented in
[the component benchmark guide](../../benchmarks/components/README.md).
The compressed [evidence bundle](evidence/performance-2026-11-01.tar.gz) retains
raw Core/modern/P1/dispatch samples, all component logs, build/source/library
identities, protocol orders, manifests, reproduction drivers and failed initial
harness diagnostics. It excludes executable binaries and credentials. Its
adjacent checksum manifest records the archive identity. Every complete matrix
and checksum is audited before publication; no passing timing is inferred from
an incomplete run.
'''
(D/'performance-2026-11-01.md').write_text(body)
headers=['Workload','Unit']+list(core['runtimes']);allrows=[]
for c in core['cases']:
 f=c['fixture'];allrows.append([f['id'],f['unit']]+[num(idx[(r,f['id'])]['warm']) for r in core['runtimes']])
(D/'performance-2026-11-01-core.md').write_text('# Complete Core warm-call table: 2026-11-01\n\nSee the [audit](performance-2026-11-01.md) for units, policies, identities, phases and limitations. Values are medians of three fresh process medians, each with seven warm samples. These descriptive results do not establish calibrated parity.\n\n'+table(headers,allrows))
summary={'engineRevision':core['sourceRevision'],'core':rows,'modern':mr,'componentOwn':comp,'componentComparison':{'headers':['operation','goNativeNs','llgoNativeNs','wasmtimeNs','llgoRatio','referenceMinMaxNs'],'rows':compt},'preview1':p1}
(P/'combined-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('Wrote performance report, complete 68-case table and combined summary')
