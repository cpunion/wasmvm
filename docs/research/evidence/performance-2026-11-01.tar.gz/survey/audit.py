from pathlib import Path
import json,hashlib,re,statistics
P=Path('artifacts/survey-20261101');core=json.loads((P/'results.json').read_text());modern=json.loads((P/'modern/results.json').read_text());dispatch=json.loads((P/'dispatch.json').read_text());build=json.loads((P/'build.json').read_text());p1=json.loads((P/'preview1/results.json').read_text());paired=json.loads((P/'components/paired/metadata.json').read_text())
assert core['status']==modern['status']==dispatch['status']==paired['status']=='complete'
assert len(core['cases'])==68 and len(core['runtimes'])==9
assert sum(len(c['observations']) for c in core['cases'])==1836
assert len(modern['cases'])==10 and len(modern['unsupported'])==12
assert sum(len(c['observations']) for c in modern['cases'])==234
assert len(modern['checks'])==78
assert len(p1['observations'])==96 and not p1['failed'] and p1['oracleChecks']==1280
assert len(paired['rows'])==171 and all(r['exitCode']==0 for r in paired['rows'])
assert build['builds']['go']['sourceDigest']==build['builds']['llgo']['sourceDigest']==p1['build']['head-go']['sourceDigest']==p1['build']['head-llgo']['sourceDigest']
for report in [core,modern,dispatch]:
 for c in report['cases']:
  for row in c['observations']:
   record=row['record'];expected=c['fixture']['expectedChecksum']
   assert record['result']==expected and record['warmResults']==[expected]*7 and record['warmupResults']==[expected]*2
   if record.get('engine')=='wasmvm':
    assert record['sourceRevision']=='4ad69c24de32a96310799ad76bd10af118afed42'
    assert record['backend'] in ('native','interpreter') and record['compiler'] in ('gc','llgo')
for row in paired['rows']:
 name=row['workload']+'-'+row['config']+'-'+str(row['block'])+'.log'
 assert hashlib.sha256((P/'components/paired'/name).read_bytes()).hexdigest()==row['logSha256']
for path in [Path('docs/research/status-2026-11-01.md'),Path('docs/research/performance-2026-11-01.md'),Path('docs/research/performance-2026-11-01-core.md')]:
 for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
  if target.startswith(('https:','http:','#')) or 'evidence/performance-' in target:continue
  assert (path.parent/target.split('#')[0]).exists(),(path,target)
print('Verified complete Core/modern/P1/paired-component matrices, all outputs, exact source identity, both compilers/backends and report links')
(P/'verified.json').write_text(json.dumps({'complete':True,'engineRevision':core['sourceRevision'],'engineSourceDigest':build['builds']['go']['sourceDigest'],'coreProcesses':1836,'coreCheckedCalls':18360,'modernProcesses':234,'modernAlternateProcesses':78,'modernUnsupportedRejections':12,'preview1Processes':96,'preview1CheckedCalls':1280,'pairedComponentProcesses':171,'dispatchProcesses':72},indent=2)+'\n')
