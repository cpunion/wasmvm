from pathlib import Path
import runpy,json,random,subprocess,os,hashlib,time
ROOT=Path.cwd();P=ROOT/'artifacts/survey-20261101';C=P/'components';OUT=C/'paired';OUT.mkdir(exist_ok=True)
scope=runpy.run_path(str(P/'write_report.py'));spec=scope['comparisons'];metadata=json.loads((C/'metadata.json').read_text());known={m['name']:m for m in metadata['measurements']}
rng=random.Random(20261101);rows=[];env=dict(os.environ,WASMVM_COMMAND_BENCH_PREOPEN=str(C/'preopen'));start=time.time()
for label,name,ref,key,n in spec:
 package='component' if name.startswith(('BenchmarkComponent','BenchmarkResource','BenchmarkOwned','BenchmarkByte')) else 'wasi/preview2';cases={}
 for compiler in ['go','llgo']:
  binary=C/(package.replace('/','-')+'-'+compiler+'.test');selector='/'.join('^'+s+'$' for s in name.split('/'));args=[str(binary),'-test.run=^$','-test.bench='+selector,'-test.benchtime=100ms','-test.count=1']
  if name.startswith(('BenchmarkTCP','BenchmarkUDP')):args[-2]='-test.benchtime=20x'
  cases[compiler]=(args,P/'build'/compiler/'pkg'/package)
 cases['reference']=(known['reference-'+ref+'-0']['args'],ROOT)
 for block in range(3):
  names=list(cases);rng.shuffle(names)
  for compiler in names:
   args,cwd=cases[compiler];path=OUT/(ref+'-'+compiler+'-'+str(block)+'.log')
   with path.open('w') as stream:r=subprocess.run(args,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
   rows.append(dict(workload=ref,backend='native',config=compiler,block=block,order=names,args=args,cwd=str(cwd),exitCode=r.returncode,logSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
   (OUT/'metadata.json').write_text(json.dumps(dict(status='running',hostLoad=os.getloadavg(),rows=rows),indent=2)+'\n')
   if r.returncode:raise RuntimeError(str(path))
 print('paired',ref,'checked',flush=True)
for entry in ['direct','run']:
 cases={compiler:[str(C/('async-'+compiler)),str(ROOT/'pkg/component/testdata/async-lift.wasm'),'native','1000','128',entry] for compiler in ['go','llgo']}
 cases['reference']=known['reference-async-'+entry+'-0']['args']
 for block in range(3):
  names=list(cases);rng.shuffle(names)
  for compiler in names:
   path=OUT/('async-'+entry+'-'+compiler+'-'+str(block)+'.log')
   with path.open('w') as stream:r=subprocess.run(cases[compiler],cwd=ROOT,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
   rows.append(dict(workload='async-'+entry,config=compiler,block=block,order=names,args=cases[compiler],exitCode=r.returncode,logSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
   if r.returncode:raise RuntimeError(str(path))
print('Paired component/P2/async survey complete',flush=True)
(OUT/'metadata.json').write_text(json.dumps(dict(status='complete',hostLoad=os.getloadavg(),wallSeconds=time.time()-start,rows=rows),indent=2)+'\n')
