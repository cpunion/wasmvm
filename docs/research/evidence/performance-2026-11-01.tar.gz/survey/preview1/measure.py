import sys,json,statistics,random,hashlib
from pathlib import Path
sys.path.insert(0,str(Path('benchmarks').resolve()))
import phase_ci
root=Path('artifacts/survey-20261101/preview1');build=json.loads((root/'build/build.json').read_text());workloads=json.loads((Path('artifacts/preview1/bench-fixtures/manifest.json')).read_text())['workloads']
configs=[]
for ref in ['head']:
 for compiler in ['go','llgo']:
  for backend in ['interpreter','native']:
   configs.append((ref+'-'+compiler+'-'+backend,build[ref+'-'+compiler]['binary'],backend))
configs += [('wazero-interpreter',build['wazero']['binary'],'interpreter'),('wazero-compiler',build['wazero']['binary'],'compiler'),('wasmtime',build['wasmtime']['binary'],'compiler'),('wasmer',build['wasmer']['binary'],'compiler')]
records=[];failed=[];unsupported=set();oracles=0
for block in range(3):
 pairs=[(c,w) for c in configs for w in workloads]
 random.Random(2919+block).shuffle(pairs)
 for (name,binary,backend),w in pairs:
  if (name,w['name']) in unsupported: continue
  command=[binary,'--wasm',w['wasm'],'--backend',backend,'--iterations',str(w['iterations']),'--seed',str(w['seed']),'--expected',str(w['expected']),'--samples','7','--warmups','2']
  try:
   result=phase_ci.invoke(command,120);r=result['record']
   assert r['result']==w['expected'] and all(n==w['expected'] for n in r['warmResults']+r['warmupResults'])
   records.append(dict(config=name,workload=w['name'],block=block,**result));oracles+=10
   if block==0:
    x=w['alternateExpected']
    alternate=[binary,'--wasm',w['wasm'],'--backend',backend,'--iterations','17','--seed','4294967295','--expected',str(x),'--samples','7','--warmups','2']
    a=phase_ci.invoke(alternate,120);assert a['record']['result']==x;oracles+=10
  except Exception as e:
   failed.append({'config':name,'workload':w['name'],'block':block,'error':str(e)})
   if name.startswith('head-') or name.startswith('base-') and not w['requiresP1']:raise
   unsupported.add((name,w['name']))
 report=dict(build=build,workloads=workloads,blocks=3,samples=7,warmups=2,policy='Local shared-host arm64 diagnostic. Exact committed head engine sources; public API, unmetered checked execution. Head and references install P1; Wasmer constructs its WASI environment only for importing modules, with args [guest,arg] and env KEY=VALUE; no ambient environment. Each feature workload performs one P1 call per source iteration. WASI setup is included in engineSetup, import resolution in instantiate; startup, compile, instantiate, first, warm and cleanup remain separate without timing subtraction. These are small in-memory ABI loops, not filesystem/network or full M4 performance acceptance',observations=records,failed=failed,oracleChecks=oracles)
 (root/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print('block',block,'observations',len(records),'oracles',oracles,'failures',len(failed),flush=True)
summary={}
for w in workloads:
 summary[w['name']]={}
 for name,_,_ in configs:
  rows=[x['record'] for x in records if x['config']==name and x['workload']==w['name']]
  if rows:summary[w['name']][name]={'warmNsPerSourceIteration':statistics.median(statistics.median(r['warmCallNs'])/w['iterations'] for r in rows),**{phase+'Us':statistics.median(r['phasesNs'][phase] for r in rows)/1000 for phase in ['compileValidate','instantiate','firstCall','cleanup']}}
assert not failed, failed
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print('P1 phase survey complete')
