import os,sys,json,subprocess,shutil
from pathlib import Path
sys.path.insert(0,str(Path('benchmarks').resolve()))
import own_build
root=Path.cwd();out=root/'artifacts/survey-20261101/preview1/build';out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,LLGO_ROOT='/Users/lijie/source/goplus/llgo-wt-wasm-math-bitcasts-20261028',CGO_ENABLED='1',GOWORK='off',GOTOOLCHAIN='local')
records={};head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for name,rev in [('head',head)]:
 target=out/name;own_build.archive(root,rev,target);sources=own_build.hashes(target,own_build.ENGINE_PATHS,own_build.HARNESS)
 p=target/'internal/bench/phase/phase.go';s=p.read_text()
 begin=s.index('\tinfo, err := compiled.Info()');end=s.index('\tstart = time.Now()\n\tinstance, err := linker.Instantiate',begin)
 s=s[:begin]+('' if name=='head' else '\tlinker := vm.NewLinker(store)\n')+s[end:]
 if name=='head':
  s=s.replace('"github.com/cpunion/wasmvm/pkg/vm"','"github.com/cpunion/wasmvm/pkg/vm"\n"github.com/cpunion/wasmvm/pkg/wasi/preview1"',1)
  s=s.replace('\tout.Phases.EngineSetup = time.Since(start).Nanoseconds()', '''
 var process *preview1.Process
 linker:=vm.NewLinker(store)
 if err==nil {
  pcfg:=preview1.DefaultConfig();pcfg.Args=[]string{"guest","arg"};pcfg.Env=[]string{"KEY=VALUE"}
  process,err=preview1.NewProcess(pcfg);if err==nil{err=process.Install(store,linker)}
 }
 out.Phases.EngineSetup = time.Since(start).Nanoseconds()''',1)
  s=s.replace('\t\tif store != nil {','\t\tif process!=nil{process.Close();process.WaitClosed(context.Background())}\n\t\tif store != nil {',1)
 p.write_text(s)
 for compiler,command in [('go',['go','build']),('llgo',['/Users/lijie/source/goplus/wasmvm/artifacts/components/llgo-8e45ed5','build','-O3','-lto=full'])]:
  binary=out/(name+'-'+compiler)
  (target/'internal/bench/phase/provenance_gen.go').write_text('package phase\nfunc init(){sourceRevision='+json.dumps(rev)+';compilerRevision='+json.dumps('go1.27.3' if compiler=='go' else own_build.LLGO_REVISION)+'}\n')
  subprocess.run([*command,'-o',str(binary),'./benchmarks/embedded/wasmvm'],cwd=target,env=env,check=True,timeout=600)
  assert own_build.hashes(target,own_build.ENGINE_PATHS,own_build.HARNESS)==sources
  records[name+'-'+compiler]=dict(sourceRevision=rev,sourceDigest=own_build.source_digest(sources),binary=str(binary),binarySHA256=own_build.digest(binary),harnessSHA256=own_build.digest(p),compilerFlags=command[2:] if compiler=='llgo' else [])
 print(name,'built',flush=True)
target=out/'wazero';shutil.copytree(root/'benchmarks/embedded/wazero',target,dirs_exist_ok=True)
p=target/'main.go';s=p.read_text().replace('"github.com/tetratelabs/wazero/api"','"github.com/tetratelabs/wazero/api"\n"github.com/tetratelabs/wazero/imports/wasi_snapshot_preview1"')
s=s.replace('runtime := wazero.NewRuntimeWithConfig(ctx, config)','runtime := wazero.NewRuntimeWithConfig(ctx, config)\n if _,err:=wasi_snapshot_preview1.Instantiate(ctx,runtime);err!=nil{return result,err}')
s=s.replace('if err = pureModule(wasm); err != nil {\n\t\treturn result, err\n\t}','')
s=s.replace('wazero.NewModuleConfig().WithName("benchmark").WithStartFunctions()','wazero.NewModuleConfig().WithName("benchmark").WithStartFunctions().WithArgs("guest","arg").WithEnv("KEY","VALUE")');p.write_text(s)
binary=out/'wazero-phase';subprocess.run(['go','build','-o',str(binary),'.'],cwd=target,env=env,check=True)
records['wazero']=dict(version='1.12.0',binary=str(binary),binarySHA256=own_build.digest(binary),harnessSHA256=own_build.digest(p))
shutil.copy2(root/'benchmarks/embedded/c/common.h',out/'common.h')
for name,sdk in [('wasmtime',Path('artifacts/components/runtime-benchmark/sdk/wasmtime-c-api/wasmtime-v48.0.1-aarch64-macos-c-api').resolve()),('wasmer',Path('/tmp/wasmvm-native-sdks/wasmer-minimal'))]:
 p=out/(name+'.c');s=(root/('benchmarks/embedded/c/'+name+'.c')).read_text().replace('  require_pure_module(bytes, size);','')
 if name=='wasmtime':
  s=s.replace('#include <wasmtime.h>','#include <wasmtime.h>\n#include <wasi.h>')
  s=s.replace('wasmtime_context_t *context = wasmtime_store_context(store);','''wasmtime_context_t *context = wasmtime_store_context(store);
 wasi_config_t *wasi=wasi_config_new();const char *args[]={"guest","arg"};const char *keys[]={"KEY"};const char *values[]={"VALUE"};
 if(!wasi_config_set_argv(wasi,2,args)||!wasi_config_set_env(wasi,1,keys,values))fail("WASI configuration");
 check(wasmtime_context_set_wasi(context,wasi),NULL);
 wasmtime_linker_t *linker=wasmtime_linker_new(engine);check(wasmtime_linker_define_wasi(linker),NULL);
 result.engine_setup=now_ns()-start;''')
  s=s.replace('wasmtime_instance_new(context, module, NULL, 0, &instance, &trap)','wasmtime_linker_instantiate(linker, context, module, &instance, &trap)')
  s=s.replace('wasmtime_store_delete(store);','wasmtime_linker_delete(linker);\n  wasmtime_store_delete(store);')
 else:
  s=s.replace('if (!store) last_error("create store");','''if (!store) last_error("create store");
 wasi_config_t *wasi=wasi_config_new("guest");wasi_config_arg(wasi,"arg");wasi_config_env(wasi,"KEY","VALUE");
 wasi_env_t *wasi_env=wasi_env_new(store,wasi);if(!wasi_env)last_error("WASI environment");result.engine_setup=now_ns()-start;''')
  s=s.replace('wasm_instance_t *instance = wasm_instance_new','wasm_importtype_vec_t imported_types;wasm_module_imports(module,&imported_types);bool has_imports=imported_types.size!=0;wasm_importtype_vec_delete(&imported_types);if(has_imports&&!wasi_get_imports(store,wasi_env,module,&imports))last_error("WASI imports");\n  wasm_instance_t *instance = wasm_instance_new')
  s=s.replace('result.instantiate = now_ns() - start;','''if(instance){wasm_importtype_vec_t types;wasm_module_imports(module,&types);bool needs_wasi=types.size!=0;wasm_importtype_vec_delete(&types);if(needs_wasi&&!wasi_env_initialize_instance(wasi_env,store,instance))last_error("WASI memory");}
 result.instantiate = now_ns() - start;''')
  s=s.replace('wasm_store_delete(store);','wasm_extern_vec_delete(&imports);wasi_env_delete(wasi_env);\n  wasm_store_delete(store);')
 if name=='wasmer':
  old='wasi_config_t *wasi=wasi_config_new("guest");wasi_config_arg(wasi,"arg");wasi_config_env(wasi,"KEY","VALUE");\n wasi_env_t *wasi_env=wasi_env_new(store,wasi);if(!wasi_env)last_error("WASI environment");result.engine_setup=now_ns()-start;'
  s=s.replace(old,'wasi_env_t *wasi_env=NULL;')
  s=s.replace('if(has_imports&&!wasi_get_imports(store,wasi_env,module,&imports))last_error("WASI imports");','if(has_imports){uint64_t provider_start=now_ns();wasi_config_t *wasi=wasi_config_new("guest");wasi_config_arg(wasi,"arg");wasi_config_env(wasi,"KEY","VALUE");wasi_env=wasi_env_new(store,wasi);if(!wasi_env)last_error("WASI environment");result.engine_setup+=now_ns()-provider_start;}start=now_ns();if(has_imports&&!wasi_get_imports(store,wasi_env,module,&imports))last_error("WASI imports");').replace('wasi_env_delete(wasi_env);','if(wasi_env)wasi_env_delete(wasi_env);')
 p.write_text(s);binary=out/(name+'-phase')
 subprocess.run(['clang','-O2','-std=c11','-I'+str(sdk/'include'),str(p),'-L'+str(sdk/'lib'),'-l'+name,'-Wl,-rpath,'+str(sdk/'lib'),'-o',str(binary)],check=True)
 records[name]=dict(version='48.0.1' if name=='wasmtime' else '7.3.0',binary=str(binary),binarySHA256=own_build.digest(binary),harnessSHA256=own_build.digest(p),compiler='Cranelift')
(out/'build.json').write_text(json.dumps(records,indent=2)+'\n')
