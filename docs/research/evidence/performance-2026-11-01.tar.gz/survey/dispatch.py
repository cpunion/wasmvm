from pathlib import Path
import json,sys,random
sys.path.insert(0,str(Path('benchmarks').resolve()))
import phase_ci,interleaved
p=Path('artifacts/survey-20261101');build=json.loads((p/'build.json').read_text());core=json.loads((p/'results.json').read_text());rng=random.Random(20261101)
runtimes={name:dict(r,mode='dispatch',command=[r['command'][0],'--mode','dispatch']) for name,r in core['runtimes'].items() if name.startswith('wasmvm-')}
report=dict(sourceRevision=build['revision'],runtimes=runtimes,status='running',acceptance='internal dispatch diagnostics, not public API or acceptance',cases=[])
try:
 for c in core['cases']:
  f=c['fixture']
  if f['family']!='core':continue
  case=dict(fixture=f,observations=[],sampleOrders=[]);report['cases'].append(case)
  commands={name:r['command']+['--backend',r['backend'],'--wasm',f['path'],'--iterations',str(f['iterations']),'--seed',str(f['seed']),'--expected',str(f['expectedChecksum']),'--samples','7','--warmups','2'] for name,r in runtimes.items()}
  for block in range(3):
   rows,order=interleaved.invoke(commands,180,rng);case['sampleOrders'].append(order)
   for name,row in rows.items():
    row=dict(row,wasmSha256=f['wasmSha256']);phase_ci.validate_observation(row,runtimes[name],f);case['observations'].append(dict(row,runtime=name,block=block))
  print(f['id'],'dispatch checked',flush=True)
 report['status']='complete'
finally:(p/'dispatch.json').write_text(json.dumps(report,indent=2)+'\n')
