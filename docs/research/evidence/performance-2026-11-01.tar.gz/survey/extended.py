import os,json,subprocess,time,hashlib,random
from pathlib import Path
ROOT=Path.cwd(); OUT=ROOT/'artifacts/survey-20261101'; P=ROOT/'artifacts/components'
while True:
 try: state=json.loads((OUT/'results.json').read_text())['status']
 except (FileNotFoundError,json.JSONDecodeError): state='running'
 if state=='complete': break
 if state=='failed': raise RuntimeError('Core survey failed; do not run or hide later measurements')
 time.sleep(5)
env=dict(os.environ,LLGO_ROOT='/Users/lijie/source/goplus/llgo-wt-wasm-math-bitcasts-20261028',CGO_ENABLED='1',GOWORK='off',GOTOOLCHAIN='local')
if json.loads((OUT/'modern/results.json').read_text())['status']!='complete': raise RuntimeError('modern measurements incomplete')
print('Modern survey complete; building component and WASI probes',flush=True)
metadata={'engineRevision':state if False else json.loads((OUT/'build.json').read_text())['revision'],'builds':{},'measurements':[]}
COMP=OUT/'components';COMP.mkdir(exist_ok=True)
metadata=json.loads((COMP/'metadata.json').read_text())
def execute(name,args,cwd=ROOT):
 if name.startswith('build-') and any(x['name']==name and x['exitCode']==0 for x in metadata['measurements']):return
 log=COMP/(name+'.log')
 with log.open('w') as stream:
  r=subprocess.run([str(x) for x in args],cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=900)
 metadata['measurements'].append(dict(name=name,args=[str(x) for x in args],cwd=str(cwd),exitCode=r.returncode,logSha256=hashlib.sha256(log.read_bytes()).hexdigest()))
 (COMP/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
 if r.returncode: raise RuntimeError(name+' failed; see '+str(log))
 print(name,'complete',flush=True)
for compiler,command in [('go',['go']),('llgo',[str(P/'llgo-8e45ed5')])]:
 target=OUT/'build'/compiler
 flags=[] if compiler=='go' else ['-O3','-lto=full']
 for package in ['component','wasi/preview2']:
  name=package.replace('/','-')+'-'+compiler;binary=COMP/(name+'.test')
  execute('build-'+name,[*command,'test',*flags,'-c','-o',binary,'./pkg/'+package],target)
  metadata['builds'][name]=dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
 binary=COMP/('async-'+compiler)
 execute('build-async-'+compiler,[*command,'build',*flags,'-o',binary,'./benchmarks/components/async_lift.go'],target)
 metadata['builds']['async-'+compiler]=dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
sdk=P/'runtime-benchmark/sdk/wasmtime-c-api/wasmtime-v48.0.1-aarch64-macos-c-api'
for name in ['wasmtime','resources','environment','random','wall_clock','poll_clock','io_streams','filesystem','network']:
 binary=COMP/('reference-'+name)
 execute('build-reference-'+name,['cc','-O3','-I',sdk/'include','-L',sdk/'lib','-Wl,-rpath,'+str(sdk/'lib'),ROOT/'benchmarks/components/c'/(name+'.c'),'-lwasmtime','-o',binary])
 metadata['builds']['reference-'+name]=dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
execute('build-reference-rust',['cargo','+1.98.0','build','--release','--locked','--manifest-path','benchmarks/components/rust/Cargo.toml','--target-dir',P/'wasmtime-typed-target'])
execute('build-reference-async',['cargo','+1.98.0','build','--release','--locked','--manifest-path','benchmarks/components/rust/Cargo.toml','--bin','async_lift','--features','async-lift','--target-dir',P/'wasmtime-error-context-target'])
# Check identical bytes produced by the adjacent source with the declared tool.
execute('modern-fixture-reproduce',['python3','-c',"from pathlib import Path;import subprocess; d=Path('benchmarks/modern'); out=Path('artifacts/survey-20261101/reproduced');out.mkdir(exist_ok=True);[(subprocess.run(['wasm-tools','parse',str(p),'-o',str(out/p.with_suffix('.wasm').name)],check=True),(None if (out/p.with_suffix('.wasm').name).read_bytes()==p.with_suffix('.wasm').read_bytes() else (_ for _ in ()).throw(ValueError(str(p))))) for p in d.glob('*.wat')]"])
print('All compilation finished; measurements begin without competing builds',flush=True)
preopen=COMP/'preopen';preopen.mkdir(exist_ok=True);(preopen/'bench.bin').write_bytes(b'0123456789abcdef')
env['WASMVM_COMMAND_BENCH_PREOPEN']=str(preopen)
# Alternate compiler order per fresh test process; count=1 avoids treating in-process repeats as processes.
for block in range(3):
 for compiler in (['go','llgo'] if block%2==0 else ['llgo','go']):
  target=OUT/'build'/compiler
  execute('component-'+compiler+'-'+str(block),[COMP/('component-'+compiler+'.test'),'-test.run=^$','-test.bench=^(BenchmarkComponentRuntime|BenchmarkResourceInstructions|BenchmarkOwnedResourceLifetime|BenchmarkByteListTransfer)$','-test.benchtime=100ms','-test.count=1'],target/'pkg/component')
  execute('wasi-'+compiler+'-'+str(block),[COMP/('wasi-preview2-'+compiler+'.test'),'-test.run=^$','-test.bench=^(BenchmarkEnvironmentArgumentCount|BenchmarkRandomBytes|BenchmarkPollClockSubscriptions|BenchmarkIOWriteBatch|BenchmarkFileSystemStatBatch|BenchmarkNetworkLiteralBatch|BenchmarkWallClockNow|BenchmarkHTTPFields|BenchmarkHTTPBodyTransfer|BenchmarkWASICommand)$','-test.benchtime=100ms','-test.count=1'],target/'pkg/wasi/preview2')
  execute('network-'+compiler+'-'+str(block),[COMP/('wasi-preview2-'+compiler+'.test'),'-test.run=^$','-test.bench=^(BenchmarkTCPRoundtripBatch|BenchmarkUDPRoundtripBatch)$','-test.benchtime=20x','-test.count=1'],target/'pkg/wasi/preview2')
 refs=[('scalar',COMP/'reference-wasmtime',[ROOT/'internal/component/decode/testdata/composition.wasm',100000]),('resource-loop',COMP/'reference-wasmtime',[ROOT/'pkg/component/testdata/resources.wasm',1000,128]),('ownership',COMP/'reference-resources',[ROOT/'pkg/component/testdata/ownership.wasm',10000])]
 for name,fixture in [('environment','environment'),('random','random'),('wall_clock','wall-clock'),('poll_clock','poll-clock'),('io_streams','io-streams'),('network','network-common')]:refs.append((name,COMP/('reference-'+name),[ROOT/'pkg/wasi/preview2/testdata'/(fixture+'.wasm'),1000]))
 refs.append(('filesystem',COMP/'reference-filesystem',[ROOT/'pkg/wasi/preview2/testdata/filesystem.wasm',preopen,1000]))
 refs += [('bytes-typed',P/'wasmtime-typed-target/release/wasmvm-component-reference',[ROOT/'pkg/component/testdata/bytes.wasm',10000]),('command-c',P/'wasmtime-typed-target/release/command',[ROOT/'pkg/wasi/preview2/testdata/world-c-command.wasm',preopen,1000,'c']),('command-rust',P/'wasmtime-typed-target/release/command',[ROOT/'pkg/wasi/preview2/testdata/world-composed-command.wasm',preopen,1000,'rust'])]
 for name in ['tcp','udp']:refs.append((name,P/'wasmtime-typed-target/release'/name,[ROOT/'pkg/wasi/preview2/testdata'/(name+'-common.wasm'),20]))
 for name,extra in [('http-fields',[]),('http-body',['body'])]:refs.append((name,P/'wasmtime-typed-target/release/http_fields',[ROOT/'pkg/wasi/preview2/testdata/http-fields.wasm',1000,*extra]))
 for name,binary,arguments in refs:
  metadata['builds'].setdefault('reference-'+name,dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest()))
  execute('reference-'+name+'-'+str(block),[binary,*arguments])
 for entry in ['direct','run']:
  for compiler in ['go','llgo']:
   for backend in ['interpreter','native']:execute('async-'+entry+'-'+compiler+'-'+backend+'-'+str(block),[COMP/('async-'+compiler),ROOT/'pkg/component/testdata/async-lift.wasm',backend,1000,128,entry])
  execute('reference-async-'+entry+'-'+str(block),[P/'wasmtime-error-context-target/release/async_lift',ROOT/'pkg/component/testdata/async-lift.wasm',1000,128,entry])
metadata['status']='complete';(COMP/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print('Component and WASI survey complete',flush=True)
