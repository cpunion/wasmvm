from pathlib import Path
import json,statistics,math,random
p=Path('/Users/lijie/source/goplus/wasmvm/artifacts/p3-mechanism-costs-20261116');rng=random.Random(2026111602)
def gm(x):return math.exp(statistics.mean(map(math.log,x)))
def summary(x):
 draws=sorted(gm(rng.choices(x,k=len(x)))for _ in range(20000));return {'ratio':gm(x),'ci95':[draws[499],draws[19499]]}
output={}
for case in ['core-loop','core-host','component-loop','component-host']:
 blocks=[json.loads((p/'timing'/f'{case}-{b}.json').read_text())for b in range(6)];names=['go','llgo','wasmtime']+(['wasmtime-dynamic']if case=='component-host'else[]);costs={};controls={};vals={}
 for name in names:
  vals[name]=[];aa=[];allocs=[];sizes=[];cold={k:[]for k in ['load','prepare','cleanup','firstCallNs']}
  for block in blocks:
   a,b=[block['observations'][name+'-'+alias]['record']for alias in ['A','B']];av,bv=[statistics.median(row['warmCallNs'])/block['iterations']for row in [a,b]];vals[name].append(math.sqrt(av*bv));aa.append(bv/av)
   if a['mallocs']is not None:allocs.extend([statistics.median(row['mallocs'])/block['iterations']for row in[a,b]]);sizes.extend([statistics.median(row['allocatedBytes'])/block['iterations']for row in[a,b]])
   for row in[a,b]:
    for k in cold:cold[k].append(row[k]if k=='firstCallNs'else row['phasesNs'][k])
  costs[name]={'medianNsPerIteration':statistics.median(vals[name]),'blockRangeNsPerIteration':[min(vals[name]),max(vals[name])],'mallocsPerIteration':statistics.median(allocs)if allocs else None,'accountedBytesPerIteration':statistics.median(sizes)if sizes else None,'coldMedianNs':{k:statistics.median(v)for k,v in cold.items()}}
  controls[name]=summary(aa);controls[name]['resolved']=controls[name]['ci95'][0]>=.975 and controls[name]['ci95'][1]<=1.025
 comparisons={}
 for a,b in [('go','wasmtime'),('llgo','wasmtime'),('llgo','go')]+([('wasmtime-dynamic','wasmtime')]if case=='component-host'else[]):
  s=summary([x/y for x,y in zip(vals[a],vals[b])]);s['controlsResolve']=controls[a]['resolved']and controls[b]['resolved'];comparisons[a+'/'+b]=s
 output[case]={'costs':costs,'sameBinaryControls':controls,'comparisons':comparisons}
(p/'micro-summary.json').write_text(json.dumps(output,indent=2)+'\n')
for case,data in output.items():
 print(case)
 for name,row in data['costs'].items():print(name,round(row['medianNsPerIteration'],3),row['mallocsPerIteration'])
 for name,s in data['comparisons'].items():print(name,round(s['ratio'],3),[round(x,3)for x in s['ci95']],s['controlsResolve'])
 print('AA',[(n,s['resolved'],[round(x,3)for x in s['ci95']])for n,s in data['sameBinaryControls'].items()])
