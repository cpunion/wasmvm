from pathlib import Path
import os,subprocess,json
r=Path('/Users/lijie/source/goplus/wasmvm');w=r.parent/'wasmvm-source-cleanup';p=r/'artifacts/p3-mechanism-costs-20261116';m=p/'micro';d=p/'allocation-stacks';d.mkdir(exist_ok=True)
s=(m/'main.go').read_text().replace('"runtime"','"runtime"\n"runtime/pprof"')
s=s.replace('kind, path := os.Args[1], os.Args[2]','runtime.MemProfileRate = 1\nkind, path := os.Args[1], os.Args[2]')
s=s.replace('phases["prepare"] = time.Since(start).Nanoseconds()','phases["prepare"] = time.Since(start).Nanoseconds()\nif dir:=os.Getenv("P3_ALLOC_PROFILE");dir!=""{defer func(){runtime.GC();f,e:=os.Create(dir);fail(e);fail(pprof.Lookup("allocs").WriteTo(f,0));fail(f.Close())}()}')
(d/'main.go').write_text(s)
module=(w/'internal/engine/nativeexec/module.go').read_text().replace('"context"','"context"\n"os"\n"encoding/json"')
needle='out.code, err = publish(code, entries, limits.MaxCodeBytes)';assert module.count(needle)==1
module=module.replace(needle,'''if dir:=os.Getenv("P3_JIT_DUMP");dir!=""{file,failed:=os.CreateTemp(dir,"wasmvm-*.bin");if failed!=nil{panic(failed)};if _,failed=file.Write(code);failed!=nil{panic(failed)};file.Close();metadata:=[]map[string]any{};for _,entry:=range out.entries{metadata=append(metadata,map[string]any{"ordinary":entry.ordinary,"metered":entry.metered,"expanded":entry.expanded,"slots":len(entry.function.Slots),"instructions":entry.function.Code})};data,_:=json.MarshalIndent(metadata,"","  ");if failed=os.WriteFile(file.Name()+".json",data,0600);failed!=nil{panic(failed)}}
'''+needle)
(d/'module.go').write_text(module)
replace={str(w/'benchmarks/embedded/wasmvm/main.go'):str(d/'main.go'),str(w/'internal/engine/nativeexec/module.go'):str(d/'module.go')}
(d/'overlay.json').write_text(json.dumps({'Replace':replace},indent=2)+'\n')
e=dict(os.environ,PATH='/opt/homebrew/Cellar/go/1.27.3/libexec/bin:/opt/homebrew/opt/llvm@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly',GOMAXPROCS='4',CGO_ENABLED='1',CC='/opt/homebrew/opt/llvm@22/bin/clang')
with(d/'build.log').open('w')as f:subprocess.run(['go','build','-overlay',str(d/'overlay.json'),'-o',str(d/'go'),'.'],cwd=w/'benchmarks/embedded/wasmvm',env=e,stdout=f,stderr=subprocess.STDOUT,check=True)
for kind in ['core-loop','core-host','component-loop','component-host']:
 out=d/kind;out.mkdir(exist_ok=True)
 env=dict(e,P3_ALLOC_PROFILE=str(out/'allocs.pb.gz'),P3_JIT_DUMP=str(out))
 run=subprocess.run([str(d/'go'),kind,str(m/(kind+'.wasm')),'4096','7'],input='run\n'+'sample\n'*7,text=True,capture_output=True,env=env,timeout=30,check=True);(out/'execution.log').write_text(run.stdout+run.stderr)
 cmd=['go','tool','pprof','-top','-alloc_objects',str(d/'go'),str(out/'allocs.pb.gz')];x=subprocess.run(cmd,env=e,text=True,capture_output=True,check=True);(out/'top.txt').write_text(x.stdout+x.stderr)
 print(kind,flush=True)
