package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"context"
"github.com/tetratelabs/wazero"
	"github.com/tetratelabs/wazero/api"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"
)

func fail(err error) {
	if err != nil {
		panic(err)
	}
}
func main() {
	if len(os.Args) != 5 {
		panic("kind fixture iterations seed")
	}
	kind, path := os.Args[1], os.Args[2]
	nv, err := strconv.ParseUint(os.Args[3], 10, 32)
	fail(err)
	sv, err := strconv.ParseUint(os.Args[4], 10, 32)
	fail(err)
	n, seed := uint32(nv), uint32(sv)
	want := seed
	for range n {
		want = want*17 + 5
	}
	phases := map[string]int64{}
	start := time.Now()
	data, err := os.ReadFile(path)
	fail(err)
	phases["load"] = time.Since(start).Nanoseconds()
	var calls uint64
	var invoke func() (uint32, error)
	var cleanup func()
	start = time.Now()
ctx:=context.Background()
 engine:=wazero.NewRuntimeWithConfig(ctx,wazero.NewRuntimeConfigCompiler())
 if strings.HasSuffix(kind,"host") {_,err:=engine.NewHostModuleBuilder("env").NewFunctionBuilder().WithGoFunction(api.GoFunc(func(_ context.Context,words []uint64){calls++;words[0]=uint64(uint32(words[0])*17+5)}),[]api.ValueType{api.ValueTypeI32},[]api.ValueType{api.ValueTypeI32}).Export("step").Instantiate(ctx);fail(err)}
 compiled,err:=engine.CompileModule(ctx,data);fail(err);instance,err:=engine.InstantiateModule(ctx,compiled,wazero.NewModuleConfig().WithStartFunctions());fail(err);f:=instance.ExportedFunction("run");stack:=make([]uint64,2)
 invoke=func()(uint32,error){stack[0],stack[1]=uint64(n),uint64(seed);err:=f.CallWithStack(ctx,stack);return uint32(stack[0]),err}
 cleanup=func(){fail(engine.Close(ctx))}
	phases["prepare"] = time.Since(start).Nanoseconds()
	in := bufio.NewScanner(os.Stdin)
	emit := func(x any) { fail(json.NewEncoder(os.Stdout).Encode(x)) }
	emit(map[string]bool{"ready": true})
	if !in.Scan() || in.Text() != "run" {
		panic("run handshake")
	}
	one := func() (int64, uint64, uint64) {
		calls = 0
		var before, after runtime.MemStats
		runtime.ReadMemStats(&before)
		t := time.Now()
		got, err := invoke()
		ns := time.Since(t).Nanoseconds()
		runtime.ReadMemStats(&after)
		fail(err)
		if got != want {
			panic(fmt.Sprintf("result %d want %d", got, want))
		}
		expectedCalls := uint64(0)
		if strings.HasSuffix(kind, "host") {
			expectedCalls = uint64(n)
		}
		if calls != expectedCalls {
			panic(fmt.Sprintf("calls %d want %d", calls, expectedCalls))
		}
		return ns, after.Mallocs - before.Mallocs, after.TotalAlloc - before.TotalAlloc
	}
	first, _, _ := one()
	warmup := make([]int64, 2)
	for i := range warmup {
		warmup[i], _, _ = one()
	}
	times := make([]int64, 7)
	allocs := make([]uint64, 7)
	bytes := make([]uint64, 7)
	for i := range times {
		emit(map[string]int{"sampleReady": i})
		if !in.Scan() || in.Text() != "sample" {
			panic("sample handshake")
		}
		times[i], allocs[i], bytes[i] = one()
	}
	start = time.Now()
	cleanup()
	phases["cleanup"] = time.Since(start).Nanoseconds()
	emit(map[string]any{"kind": kind, "hostCompiler": runtime.Compiler, "iterations": n, "seed": seed, "result": want, "hostCallsPerRun": calls, "firstCallNs": first, "warmupNs": warmup, "warmCallNs": times, "mallocs": allocs, "allocatedBytes": bytes, "phasesNs": phases})
}
