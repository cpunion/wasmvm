(module
(func (export "run") (param $n i32) (param $seed i32) (result i32)
(local $i i32) (local $x i32)
local.get $seed local.set $x
block $done loop $again
 local.get $i local.get $n i32.ge_u br_if $done
 local.get $x i32.const 17 i32.mul i32.const 5 i32.add local.set $x
 local.get $i i32.const 1 i32.add local.set $i
 br $again
end end
local.get $x)
)