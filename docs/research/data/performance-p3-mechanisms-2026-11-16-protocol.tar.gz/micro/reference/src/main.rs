use std::{io::{self,BufRead,Write},time::Instant};
use wasmtime::{Config,Engine,Store};
#[cfg(feature="allocation-counts")]
mod allocation {
 use std::alloc::{GlobalAlloc,Layout,System};use std::sync::atomic::{AtomicBool,AtomicU64,Ordering};
 pub static ACTIVE:AtomicBool=AtomicBool::new(false);pub static COUNT:AtomicU64=AtomicU64::new(0);pub static BYTES:AtomicU64=AtomicU64::new(0);
 pub struct Counter;
 unsafe impl GlobalAlloc for Counter{
  unsafe fn alloc(&self,l:Layout)->*mut u8{if ACTIVE.load(Ordering::Relaxed){COUNT.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);}unsafe{System.alloc(l)}}
  unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8{if ACTIVE.load(Ordering::Relaxed){COUNT.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);}unsafe{System.alloc_zeroed(l)}}
  unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8{if ACTIVE.load(Ordering::Relaxed){COUNT.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n as u64,Ordering::Relaxed);}unsafe{System.realloc(p,l,n)}}
  unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{System.dealloc(p,l)}}
 }
}
#[cfg(feature="allocation-counts")]
#[global_allocator]static ALLOCATOR:allocation::Counter=allocation::Counter;
#[derive(Default)]struct State{calls:u64}
fn now_ns(t:Instant)->u64{t.elapsed().as_nanos().try_into().unwrap()}
fn begin_alloc(){#[cfg(feature="allocation-counts")]{use allocation::*;use std::sync::atomic::Ordering;COUNT.store(0,Ordering::Relaxed);BYTES.store(0,Ordering::Relaxed);ACTIVE.store(true,Ordering::Relaxed);}}
fn end_alloc()->(u64,u64){#[cfg(feature="allocation-counts")]{use allocation::*;use std::sync::atomic::Ordering;ACTIVE.store(false,Ordering::Relaxed);return(COUNT.load(Ordering::Relaxed),BYTES.load(Ordering::Relaxed));}#[cfg(not(feature="allocation-counts"))]{(0,0)}}
fn main(){
 let args:Vec<_>=std::env::args().collect();assert_eq!(args.len(),5);let kind=&args[1];let path=&args[2];let n:u32=args[3].parse().unwrap();let seed:u32=args[4].parse().unwrap();let host=kind.ends_with("host");let core=kind.starts_with("core");let dynamic=kind.starts_with("dynamic");
 let mut want=seed;for _ in 0..n{want=want.wrapping_mul(17).wrapping_add(5)}
 let load=Instant::now();let bytes=std::fs::read(path).unwrap();let load_ns=now_ns(load);let prep=Instant::now();let mut config=Config::new();config.cranelift_opt_level(wasmtime::OptLevel::Speed).wasm_component_model_async(true).wasm_component_model_async_stackful(true).wasm_component_model_more_async_builtins(true).wasm_component_model_threading(true).concurrency_support(true);let engine=Engine::new(&config).unwrap();let mut store=Store::new(&engine,State::default());
 let mut invoke:Box<dyn FnMut()->(u32,u64)>=if core{
  let module=wasmtime::Module::new(&engine,&bytes).unwrap();let mut linker=wasmtime::Linker::new(&engine);
  if host{linker.func_wrap("env","step",|mut c:wasmtime::Caller<'_,State>,x:i32|->i32{c.data_mut().calls+=1;(x as u32).wrapping_mul(17).wrapping_add(5) as i32}).unwrap();}
  let instance=linker.instantiate(&mut store,&module).unwrap();let f=instance.get_typed_func::<(i32,i32),i32>(&mut store,"run").unwrap();
  Box::new(move||{store.data_mut().calls=0;let r=f.call(&mut store,(n as i32,seed as i32)).unwrap();(r as u32,store.data().calls)})
 }else{
  let component=wasmtime::component::Component::new(&engine,&bytes).unwrap();let mut linker=wasmtime::component::Linker::<State>::new(&engine);
  if host{
   if dynamic{linker.root().func_new("step",|mut c,_ty,params,results|{c.data_mut().calls+=1;let wasmtime::component::Val::U32(x)=params[0]else{panic!("parameter type")};results[0]=wasmtime::component::Val::U32(x.wrapping_mul(17).wrapping_add(5));Ok(())}).unwrap();}
   else{linker.root().func_wrap("step",|mut c:wasmtime::StoreContextMut<'_,State>,(x,):(u32,)|{c.data_mut().calls+=1;Ok((x.wrapping_mul(17).wrapping_add(5),))}).unwrap();}
  }
  let instance=linker.instantiate(&mut store,&component).unwrap();let f=instance.get_typed_func::<(u32,u32),(u32,)>(&mut store,"run").unwrap();
  if let Ok(dir)=std::env::var("P3_MICRO_DUMP"){std::fs::write(std::path::Path::new(&dir).join(format!("{kind}.cwasm")),component.serialize().unwrap()).unwrap();}
  Box::new(move||{store.data_mut().calls=0;let (r,)=f.call(&mut store,(n,seed)).unwrap();f.post_return(&mut store).unwrap();(r,store.data().calls)})
 };
 let prepare_ns=now_ns(prep);println!("{{\"ready\":true}}");io::stdout().flush().unwrap();let stdin=io::stdin();let mut lines=stdin.lock().lines();assert_eq!(lines.next().unwrap().unwrap(),"run");
 let mut one=||{begin_alloc();let start=Instant::now();let(got,calls)=invoke();let ns=now_ns(start);let(a,b)=end_alloc();assert_eq!(got,want);assert_eq!(calls,if host{n as u64}else{0});(ns,a,b)};
 let first=one().0;let warmup=[one().0,one().0];let mut times=[0u64;7];let mut allocs=[0u64;7];let mut sizes=[0u64;7];
 for i in 0..7{println!("{{\"sampleReady\":{i}}}");io::stdout().flush().unwrap();assert_eq!(lines.next().unwrap().unwrap(),"sample");(times[i],allocs[i],sizes[i])=one();}
 let cleanup=Instant::now();drop(invoke);drop(engine);let cleanup_ns=now_ns(cleanup);let a=if cfg!(feature="allocation-counts"){format!("{allocs:?}")}else{"null".into()};let b=if cfg!(feature="allocation-counts"){format!("{sizes:?}")}else{"null".into()};
 println!("{{\"kind\":\"{kind}\",\"hostCompiler\":\"rust1.98.0\",\"iterations\":{n},\"seed\":{seed},\"result\":{want},\"hostCallsPerRun\":{},\"firstCallNs\":{first},\"warmupNs\":{warmup:?},\"warmCallNs\":{times:?},\"mallocs\":{a},\"allocatedBytes\":{b},\"allocationInstrumented\":{},\"phasesNs\":{{\"load\":{load_ns},\"prepare\":{prepare_ns},\"cleanup\":{cleanup_ns}}}}}",if host{n as u64}else{0},cfg!(feature="allocation-counts"));
}
