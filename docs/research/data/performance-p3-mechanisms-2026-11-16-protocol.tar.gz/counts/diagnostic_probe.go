package wasm
import("sync";"sync/atomic";"strconv")
var diagnosticP3Active atomic.Bool
var diagnosticP3Mu sync.Mutex
var diagnosticP3Counts=map[string]uint64{}
func DiagnosticP3Count(key string,n uint64){if !diagnosticP3Active.Load(){return};diagnosticP3Mu.Lock();diagnosticP3Counts[key]+=n;diagnosticP3Mu.Unlock()}
func DiagnosticP3Kind(key string,kind uint32){if diagnosticP3Active.Load(){DiagnosticP3Count(key+"/"+strconv.FormatUint(uint64(kind),10),1)}}
func DiagnosticP3Start(){diagnosticP3Mu.Lock();clear(diagnosticP3Counts);diagnosticP3Mu.Unlock();diagnosticP3Active.Store(true)}
func DiagnosticP3Stop()map[string]uint64{diagnosticP3Active.Store(false);diagnosticP3Mu.Lock();defer diagnosticP3Mu.Unlock();out:=make(map[string]uint64,len(diagnosticP3Counts));for k,v:=range diagnosticP3Counts{out[k]=v};return out}
