package main

import (
	"bufio"
	"encoding/json"
	"fmt"
	"github.com/cpunion/wasmvm/pkg/component"
	"github.com/cpunion/wasmvm/pkg/vm"
	"github.com/cpunion/wasmvm/pkg/wasm"
	"os"
	"runtime"
	"strconv"
	"strings"
	"time"
)

func fail(err error) {
	if err != nil {
		panic(err)
	}
}
func main() {
	if len(os.Args) != 5 {
		panic("kind fixture iterations seed")
	}
	kind, path := os.Args[1], os.Args[2]
	nv, err := strconv.ParseUint(os.Args[3], 10, 32)
	fail(err)
	sv, err := strconv.ParseUint(os.Args[4], 10, 32)
	fail(err)
	n, seed := uint32(nv), uint32(sv)
	want := seed
	for range n {
		want = want*17 + 5
	}
	phases := map[string]int64{}
	start := time.Now()
	data, err := os.ReadFile(path)
	fail(err)
	phases["load"] = time.Since(start).Nanoseconds()
	var calls uint64
	var invoke func() (uint32, error)
	var cleanup func()
	start = time.Now()
	if strings.HasPrefix(kind, "core") {
		config := vm.DefaultEngineConfig()
		config.Backend = "native"
		e, err := vm.NewEngineWithConfig(config)
		fail(err)
		s, err := e.NewStore(vm.DefaultStoreConfig())
		fail(err)
		linker := vm.NewLinker(s)
		if strings.HasSuffix(kind, "host") {
			sig := vm.FunctionType{Params: []wasm.ValueType{wasm.I32}, Results: []wasm.ValueType{wasm.I32}}
			host, err := s.NewScalarFunction(sig, func(_ *vm.Caller, words []uint64) error {
				calls++
				words[0] = uint64(uint32(words[0])*17 + 5)
				return nil
			})
			fail(err)
			fail(linker.Define("env", "step", host))
		}
		m, err := e.Compile(nil, data)
		fail(err)
		in, err := linker.Instantiate(nil, m, vm.CallOptions{})
		fail(err)
		f, err := in.Export("run")
		fail(err)
		args := []vm.Value{vm.I32(n), vm.I32(seed)}
		invoke = func() (uint32, error) {
			r, err := f.Call(nil, args, vm.CallOptions{})
			if err != nil {
				return 0, err
			}
			bits, _, err := r.Values[0].Bits()
			for _, v := range r.Values {
				v.Release()
			}
			return uint32(bits), err
		}
		cleanup = func() { s.Close(); fail(s.WaitClosed(nil)); m.Close(); e.Close() }
	} else {
		config := component.DefaultConfig()
		config.Core.Backend = "native"
		e, err := component.NewEngine(config)
		fail(err)
		m, err := e.Compile(nil, data)
		fail(err)
		imports := component.Imports{}
		if strings.HasSuffix(kind, "host") {
			result := component.Value{}
			imports.Functions = map[string]component.HostFunction{"step": func(_ *component.Caller, args []component.Value) (*component.Value, error) {
				calls++
				result.Bits = uint64(uint32(args[0].Bits)*17 + 5)
				return &result, nil
			}}
		}
		in, err := m.Instantiate(nil, imports, component.CallOptions{})
		fail(err)
		f, err := in.Function("run")
		fail(err)
		args := []component.Value{{Bits: uint64(n)}, {Bits: uint64(seed)}}
		invoke = func() (uint32, error) {
			r, err := f.Call(nil, args, component.CallOptions{})
			if err != nil {
				return 0, err
			}
			if r.Value == nil {
				return 0, fmt.Errorf("missing result")
			}
			return uint32(r.Value.Bits), nil
		}
		cleanup = func() { in.Close(); fail(in.WaitClosed(nil)); m.Close(); e.Close() }
	}
	phases["prepare"] = time.Since(start).Nanoseconds()
	in := bufio.NewScanner(os.Stdin)
	emit := func(x any) { fail(json.NewEncoder(os.Stdout).Encode(x)) }
	emit(map[string]bool{"ready": true})
	if !in.Scan() || in.Text() != "run" {
		panic("run handshake")
	}
	one := func() (int64, uint64, uint64) {
		calls = 0
		var before, after runtime.MemStats
		runtime.ReadMemStats(&before)
		wasm.DiagnosticP3Start()
		t := time.Now()
		got, err := invoke()
		ns := time.Since(t).Nanoseconds()
counts:=wasm.DiagnosticP3Stop()
if file:=os.Getenv("P3_MICRO_COUNTS");file!=""{data,e:=json.Marshal(counts);fail(e);fail(os.WriteFile(file,data,0600))}
		runtime.ReadMemStats(&after)
		fail(err)
		if got != want {
			panic(fmt.Sprintf("result %d want %d", got, want))
		}
		expectedCalls := uint64(0)
		if strings.HasSuffix(kind, "host") {
			expectedCalls = uint64(n)
		}
		if calls != expectedCalls {
			panic(fmt.Sprintf("calls %d want %d", calls, expectedCalls))
		}
		return ns, after.Mallocs - before.Mallocs, after.TotalAlloc - before.TotalAlloc
	}
	first, _, _ := one()
	warmup := make([]int64, 2)
	for i := range warmup {
		warmup[i], _, _ = one()
	}
	times := make([]int64, 7)
	allocs := make([]uint64, 7)
	bytes := make([]uint64, 7)
	for i := range times {
		emit(map[string]int{"sampleReady": i})
		if !in.Scan() || in.Text() != "sample" {
			panic("sample handshake")
		}
		times[i], allocs[i], bytes[i] = one()
	}
	start = time.Now()
	cleanup()
	phases["cleanup"] = time.Since(start).Nanoseconds()
	emit(map[string]any{"kind": kind, "hostCompiler": runtime.Compiler, "iterations": n, "seed": seed, "result": want, "hostCallsPerRun": calls, "firstCallNs": first, "warmupNs": warmup, "warmCallNs": times, "mallocs": allocs, "allocatedBytes": bytes, "phasesNs": phases})
}
