from pathlib import Path
import sys,json,os,time,random,subprocess,traceback
r=Path('/Users/lijie/source/goplus/wasmvm');w=r.parent/'wasmvm-source-cleanup';p=r/'artifacts/p3-mechanism-costs-20261116';m=p/'micro';sys.path.insert(0,str(w/'benchmarks'));import interleaved
plan=json.loads((p/'micro-timing-plan.json').read_text());d=p/'timing';d.mkdir(exist_ok=False);rng=random.Random(plan['rngSeed']);os.environ['GOMAXPROCS']='4'
def load():
 x=subprocess.run(['ps','-axo','pid,ppid,etime,%cpu,command'],capture_output=True,text=True,check=True).stdout
 return {'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadAverage':os.getloadavg(),'processes':x}
(d/'load-before.json').write_text(json.dumps(load(),indent=2)+'\n')
try:
 for case,n in plan['cases'].items():
  for block,seed in enumerate(plan['seeds']):
   commands={}
   for participant in plan['participants']+([plan['extraParticipant'][case]]if case in plan['extraParticipant']else[]):
    binary=m/({'go':'own-go','llgo':'own-llgo','wasmtime':'wasmtime','wasmtime-dynamic':'wasmtime'}[participant]);kind='dynamic-host'if participant=='wasmtime-dynamic'else case
    for alias in ['A','B']:commands[participant+'-'+alias]=[str(binary),kind,str(m/(case+'.wasm')),str(n),str(seed)]
   started=time.monotonic();observations,orders=interleaved.invoke(commands,timeout=90,rng=rng)
   record={'case':case,'block':block,'seed':seed,'iterations':n,'observations':observations,'orders':orders,'seconds':time.monotonic()-started,'loadAverage':os.getloadavg()}
   (d/(case+'-'+str(block)+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(case,block,'complete',round(record['seconds'],2),flush=True)
 (d/'status.json').write_text(json.dumps({'complete':True,'blocks':24},indent=2)+'\n')
except BaseException:
 (d/'failure.txt').write_text(traceback.format_exc());raise
finally:(d/'load-after.json').write_text(json.dumps(load(),indent=2)+'\n')
