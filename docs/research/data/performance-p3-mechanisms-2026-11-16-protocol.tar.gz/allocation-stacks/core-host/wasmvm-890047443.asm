
/Users/lijie/source/goplus/wasmvm/artifacts/p3-mechanism-costs-20261116/allocation-stacks/core-host/wasmvm-890047443.elf:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start>:
       0:      	stp	x29, x30, [sp, #-0x10]!
       4:      	mov	x29, sp
       8:      	stp	x19, x20, [sp, #-0x10]!
       c:      	stp	x21, x22, [sp, #-0x10]!
      10:      	stp	x23, x24, [sp, #-0x10]!
      14:      	stp	x25, x26, [sp, #-0x10]!
      18:      	stp	x27, x28, [sp, #-0x10]!
      1c:      	stp	q8, q9, [sp, #-0x20]!
      20:      	stp	q10, q11, [sp, #-0x20]!
      24:      	stp	q12, q13, [sp, #-0x20]!
      28:      	stp	q14, q15, [sp, #-0x20]!
      2c:      	ldr	x12, [x0, #0x8]
      30:      	ldr	x13, [x0, #0x20]
      34:      	ldr	x9, [x0, #0x10]
      38:      	sub	x9, x9, x13
      3c:      	mov	w10, #0x60              // =96
      40:      	cmp	x9, x10
      44:      	b.lo	0x3c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x3c0>
      48:      	and	x9, x13, #0xf
      4c:      	cmp	x9, #0x0
      50:      	b.ne	0x3c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x3c0>
      54:      	add	x12, x12, x13
      58:      	mov	w9, #0x0                // =0
      5c:      	str	x9, [x0, #0x48]
      60:      	ldr	x9, [x0, #0x38]
      64:      	mov	w10, #0x13              // =19
      68:      	cmp	x9, x10
      6c:      	b.hs	0x3c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x3c0>
      70:      	ldr	x19, [x12, #0x50]
      74:      	ldr	x20, [x12, #0x30]
      78:      	ldr	x21, [x12, #0x20]
      7c:      	ldr	x22, [x12, #0x40]
      80:      	ldr	x23, [x12]
      84:      	ldr	x24, [x12, #0x10]
      88:      	ldr	x9, [x0, #0x88]
      8c:      	cmp	x9, #0x0
      90:      	b.ne	0x3c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x3c0>
      94:      	ldr	x9, [x0, #0x38]
      98:      	adr	x13, 0xa8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xa8>
      9c:      	ldrsw	x14, [x13, x9, lsl #2]
      a0:      	add	x13, x13, x14
      a4:      	br	x13
      a8:      	udf	#0x4c
      ac:      	udf	#0x54
      b0:      	udf	#0x58
      b4:      	udf	#0x64
      b8:      	udf	#0x9c
      bc:      	udf	#0xa8
      c0:      	udf	#0xa8
      c4:      	udf	#0xb8
      c8:      	udf	#0xb8
      cc:      	udf	#0xb8
      d0:      	udf	#0x124
      d4:      	udf	#0xcc
      d8:      	udf	#0xcc
      dc:      	udf	#0x10c
      e0:      	udf	#0x110
      e4:      	udf	#0x110
      e8:      	udf	#0x134
      ec:      	udf	#0x13c
      f0:      	udf	#0x118
      f4:      	ldr	x9, [x0, #0x90]
      f8:      	cbnz	x9, 0x1ec <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x1ec>
      fc:      	mov	x20, x24
     100:      	ldr	x9, [x0, #0x90]
     104:      	cbnz	x9, 0x220 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x220>
     108:      	b	0x144 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x144>
     10c:      	ldr	x9, [x0, #0x90]
     110:      	cbnz	x9, 0x254 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x254>
     114:      	mov	w9, #0x3                // =3
     118:      	str	x9, [x0, #0x38]
     11c:      	mov	w9, #0x3                // =3
     120:      	str	x9, [x0, #0x70]
     124:      	str	x19, [x12, #0x50]
     128:      	str	x20, [x12, #0x30]
     12c:      	str	x21, [x12, #0x20]
     130:      	str	x22, [x12, #0x40]
     134:      	str	x23, [x12]
     138:      	str	x24, [x12, #0x10]
     13c:      	mov	w0, #0x1                // =1
     140:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     144:      	ldr	x9, [x0, #0x90]
     148:      	cbnz	x9, 0x288 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x288>
     14c:      	b	0x160 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x160>
     150:      	ldr	x9, [x0, #0x90]
     154:      	cbnz	x9, 0x2bc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x2bc>
     158:      	mov	x22, x20
     15c:      	b	0x10c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x10c>
     160:      	cmp	w21, w23
     164:      	cset	w19, hs
     168:      	ldr	x9, [x0, #0x90]
     16c:      	cbnz	x9, 0x2f0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x2f0>
     170:      	b.hs	0x150 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x150>
     174:      	ldr	x9, [x0, #0x90]
     178:      	cbnz	x9, 0x324 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x324>
     17c:      	mov	w9, #0x49               // =73
     180:      	str	x9, [x0, #0x40]
     184:      	mov	w9, #0xd                // =13
     188:      	str	x9, [x0, #0x38]
     18c:      	mov	w9, #0xc                // =12
     190:      	str	x9, [x0, #0x70]
     194:      	str	x19, [x12, #0x50]
     198:      	str	x20, [x12, #0x30]
     19c:      	str	x21, [x12, #0x20]
     1a0:      	str	x22, [x12, #0x40]
     1a4:      	str	x23, [x12]
     1a8:      	str	x24, [x12, #0x10]
     1ac:      	mov	w0, #0xa                // =10
     1b0:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     1b4:      	mov	x20, x19
     1b8:      	add	w21, w21, #0x1
     1bc:      	mov	x19, x21
     1c0:      	ldr	x9, [x0, #0x90]
     1c4:      	cbnz	x9, 0x358 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x358>
     1c8:      	b	0x160 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x160>
     1cc:      	ldr	x9, [x0, #0x90]
     1d0:      	cbnz	x9, 0x38c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x38c>
     1d4:      	cbnz	w19, 0x150 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x150>
     1d8:      	b	0x174 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x174>
     1dc:      	add	w19, w21, w19
     1e0:      	b	0x1e4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x1e4>
     1e4:      	mov	x21, x19
     1e8:      	b	0x1c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x1c0>
     1ec:      	dmb	ishld
     1f0:      	mov	w9, #0x0                // =0
     1f4:      	str	x9, [x0, #0x38]
     1f8:      	mov	w9, #0x0                // =0
     1fc:      	str	x9, [x0, #0x70]
     200:      	str	x19, [x12, #0x50]
     204:      	str	x20, [x12, #0x30]
     208:      	str	x21, [x12, #0x20]
     20c:      	str	x22, [x12, #0x40]
     210:      	str	x23, [x12]
     214:      	str	x24, [x12, #0x10]
     218:      	mov	w0, #0x6                // =6
     21c:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     220:      	dmb	ishld
     224:      	mov	w9, #0x2                // =2
     228:      	str	x9, [x0, #0x38]
     22c:      	mov	w9, #0x0                // =0
     230:      	str	x9, [x0, #0x70]
     234:      	str	x19, [x12, #0x50]
     238:      	str	x20, [x12, #0x30]
     23c:      	str	x21, [x12, #0x20]
     240:      	str	x22, [x12, #0x40]
     244:      	str	x23, [x12]
     248:      	str	x24, [x12, #0x10]
     24c:      	mov	w0, #0x6                // =6
     250:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     254:      	dmb	ishld
     258:      	mov	w9, #0x3                // =3
     25c:      	str	x9, [x0, #0x38]
     260:      	mov	w9, #0x0                // =0
     264:      	str	x9, [x0, #0x70]
     268:      	str	x19, [x12, #0x50]
     26c:      	str	x20, [x12, #0x30]
     270:      	str	x21, [x12, #0x20]
     274:      	str	x22, [x12, #0x40]
     278:      	str	x23, [x12]
     27c:      	str	x24, [x12, #0x10]
     280:      	mov	w0, #0x6                // =6
     284:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     288:      	dmb	ishld
     28c:      	mov	w9, #0x4                // =4
     290:      	str	x9, [x0, #0x38]
     294:      	mov	w9, #0x0                // =0
     298:      	str	x9, [x0, #0x70]
     29c:      	str	x19, [x12, #0x50]
     2a0:      	str	x20, [x12, #0x30]
     2a4:      	str	x21, [x12, #0x20]
     2a8:      	str	x22, [x12, #0x40]
     2ac:      	str	x23, [x12]
     2b0:      	str	x24, [x12, #0x10]
     2b4:      	mov	w0, #0x6                // =6
     2b8:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     2bc:      	dmb	ishld
     2c0:      	mov	w9, #0x6                // =6
     2c4:      	str	x9, [x0, #0x38]
     2c8:      	mov	w9, #0x0                // =0
     2cc:      	str	x9, [x0, #0x70]
     2d0:      	str	x19, [x12, #0x50]
     2d4:      	str	x20, [x12, #0x30]
     2d8:      	str	x21, [x12, #0x20]
     2dc:      	str	x22, [x12, #0x40]
     2e0:      	str	x23, [x12]
     2e4:      	str	x24, [x12, #0x10]
     2e8:      	mov	w0, #0x6                // =6
     2ec:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     2f0:      	dmb	ishld
     2f4:      	mov	w9, #0xa                // =10
     2f8:      	str	x9, [x0, #0x38]
     2fc:      	mov	w9, #0x0                // =0
     300:      	str	x9, [x0, #0x70]
     304:      	str	x19, [x12, #0x50]
     308:      	str	x20, [x12, #0x30]
     30c:      	str	x21, [x12, #0x20]
     310:      	str	x22, [x12, #0x40]
     314:      	str	x23, [x12]
     318:      	str	x24, [x12, #0x10]
     31c:      	mov	w0, #0x6                // =6
     320:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     324:      	dmb	ishld
     328:      	mov	w9, #0xc                // =12
     32c:      	str	x9, [x0, #0x38]
     330:      	mov	w9, #0x0                // =0
     334:      	str	x9, [x0, #0x70]
     338:      	str	x19, [x12, #0x50]
     33c:      	str	x20, [x12, #0x30]
     340:      	str	x21, [x12, #0x20]
     344:      	str	x22, [x12, #0x40]
     348:      	str	x23, [x12]
     34c:      	str	x24, [x12, #0x10]
     350:      	mov	w0, #0x6                // =6
     354:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     358:      	dmb	ishld
     35c:      	mov	w9, #0x12               // =18
     360:      	str	x9, [x0, #0x38]
     364:      	mov	w9, #0x0                // =0
     368:      	str	x9, [x0, #0x70]
     36c:      	str	x19, [x12, #0x50]
     370:      	str	x20, [x12, #0x30]
     374:      	str	x21, [x12, #0x20]
     378:      	str	x22, [x12, #0x40]
     37c:      	str	x23, [x12]
     380:      	str	x24, [x12, #0x10]
     384:      	mov	w0, #0x6                // =6
     388:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     38c:      	dmb	ishld
     390:      	mov	w9, #0xa                // =10
     394:      	str	x9, [x0, #0x38]
     398:      	mov	w9, #0x0                // =0
     39c:      	str	x9, [x0, #0x70]
     3a0:      	str	x19, [x12, #0x50]
     3a4:      	str	x20, [x12, #0x30]
     3a8:      	str	x21, [x12, #0x20]
     3ac:      	str	x22, [x12, #0x40]
     3b0:      	str	x23, [x12]
     3b4:      	str	x24, [x12, #0x10]
     3b8:      	mov	w0, #0x6                // =6
     3bc:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     3c0:      	mov	w0, #0xb                // =11
     3c4:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     3c8:      	mov	w9, #0x7                // =7
     3cc:      	str	x9, [x0, #0x70]
     3d0:      	str	x19, [x12, #0x50]
     3d4:      	str	x20, [x12, #0x30]
     3d8:      	str	x21, [x12, #0x20]
     3dc:      	str	x22, [x12, #0x40]
     3e0:      	str	x23, [x12]
     3e4:      	str	x24, [x12, #0x10]
     3e8:      	mov	w0, #0x2                // =2
     3ec:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     3f0:      	mov	w9, #0x6                // =6
     3f4:      	str	x9, [x0, #0x70]
     3f8:      	str	x19, [x12, #0x50]
     3fc:      	str	x20, [x12, #0x30]
     400:      	str	x21, [x12, #0x20]
     404:      	str	x22, [x12, #0x40]
     408:      	str	x23, [x12]
     40c:      	str	x24, [x12, #0x10]
     410:      	mov	w0, #0x2                // =2
     414:      	b	0x418 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x418>
     418:      	ldp	q14, q15, [sp], #0x20
     41c:      	ldp	q12, q13, [sp], #0x20
     420:      	ldp	q10, q11, [sp], #0x20
     424:      	ldp	q8, q9, [sp], #0x20
     428:      	ldp	x27, x28, [sp], #0x10
     42c:      	ldp	x25, x26, [sp], #0x10
     430:      	ldp	x23, x24, [sp], #0x10
     434:      	ldp	x21, x22, [sp], #0x10
     438:      	ldp	x19, x20, [sp], #0x10
     43c:      	ldp	x29, x30, [sp], #0x10
     440:      	ret
     444:      	stp	x29, x30, [sp, #-0x10]!
     448:      	mov	x29, sp
     44c:      	stp	x19, x20, [sp, #-0x10]!
     450:      	stp	x21, x22, [sp, #-0x10]!
     454:      	stp	x23, x24, [sp, #-0x10]!
     458:      	stp	x25, x26, [sp, #-0x10]!
     45c:      	stp	x27, x28, [sp, #-0x10]!
     460:      	stp	q8, q9, [sp, #-0x20]!
     464:      	stp	q10, q11, [sp, #-0x20]!
     468:      	stp	q12, q13, [sp, #-0x20]!
     46c:      	stp	q14, q15, [sp, #-0x20]!
     470:      	ldr	x12, [x0, #0x8]
     474:      	ldr	x13, [x0, #0x20]
     478:      	ldr	x9, [x0, #0x10]
     47c:      	sub	x9, x9, x13
     480:      	mov	w10, #0x60              // =96
     484:      	cmp	x9, x10
     488:      	b.lo	0xddc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xddc>
     48c:      	and	x9, x13, #0xf
     490:      	cmp	x9, #0x0
     494:      	b.ne	0xddc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xddc>
     498:      	add	x12, x12, x13
     49c:      	mov	w9, #0x0                // =0
     4a0:      	str	x9, [x0, #0x48]
     4a4:      	ldr	x9, [x0, #0x38]
     4a8:      	mov	w10, #0x13              // =19
     4ac:      	cmp	x9, x10
     4b0:      	b.hs	0xddc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xddc>
     4b4:      	adr	x13, 0x4c4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x4c4>
     4b8:      	ldrsw	x14, [x13, x9, lsl #2]
     4bc:      	add	x13, x13, x14
     4c0:      	br	x13
     4c4:      	udf	#0x4c
     4c8:      	udf	#0xb0
     4cc:      	udf	#0x124
     4d0:      	udf	#0x194
     4d4:      	udf	#0x1e0
     4d8:      	udf	#0x250
     4dc:      	udf	#0x2b4
     4e0:      	udf	#0x2fc
     4e4:      	udf	#0x360
     4e8:      	udf	#0x3c4
     4ec:      	udf	#0x444
     4f0:      	udf	#0x4b8
     4f4:      	udf	#0x51c
     4f8:      	udf	#0x5a8
     4fc:      	udf	#0x61c
     500:      	udf	#0x680
     504:      	udf	#0x6f4
     508:      	udf	#0x770
     50c:      	udf	#0x7e4
     510:      	ldr	x9, [x0, #0x58]
     514:      	cmp	x9, #0x0
     518:      	b.ne	0x534 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x534>
     51c:      	mov	w9, #0x0                // =0
     520:      	str	x9, [x0, #0x38]
     524:      	mov	w9, #0x0                // =0
     528:      	str	x9, [x0, #0x70]
     52c:      	mov	w0, #0x6                // =6
     530:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     534:      	sub	x9, x9, #0x1
     538:      	str	x9, [x0, #0x58]
     53c:      	ldr	x9, [x0, #0x88]
     540:      	cmp	x9, #0x0
     544:      	b.eq	0x574 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x574>
     548:      	mov	w9, #0x38               // =56
     54c:      	str	x9, [x0, #0x40]
     550:      	ldr	x9, [x0, #0x50]
     554:      	cmp	x9, #0x0
     558:      	b.ne	0x56c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x56c>
     55c:      	mov	w9, #0x0                // =0
     560:      	str	x9, [x0, #0x38]
     564:      	mov	w0, #0x7                // =7
     568:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     56c:      	sub	x9, x9, #0x1
     570:      	str	x9, [x0, #0x50]
     574:      	ldr	x9, [x0, #0x58]
     578:      	cmp	x9, #0x0
     57c:      	b.ne	0x598 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x598>
     580:      	mov	w9, #0x1                // =1
     584:      	str	x9, [x0, #0x38]
     588:      	mov	w9, #0x0                // =0
     58c:      	str	x9, [x0, #0x70]
     590:      	mov	w0, #0x6                // =6
     594:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     598:      	sub	x9, x9, #0x1
     59c:      	str	x9, [x0, #0x58]
     5a0:      	ldr	x9, [x0, #0x88]
     5a4:      	cmp	x9, #0x0
     5a8:      	b.eq	0x5d8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x5d8>
     5ac:      	mov	w9, #0x3a               // =58
     5b0:      	str	x9, [x0, #0x40]
     5b4:      	ldr	x9, [x0, #0x50]
     5b8:      	cmp	x9, #0x0
     5bc:      	b.ne	0x5d0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x5d0>
     5c0:      	mov	w9, #0x1                // =1
     5c4:      	str	x9, [x0, #0x38]
     5c8:      	mov	w0, #0x7                // =7
     5cc:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     5d0:      	sub	x9, x9, #0x1
     5d4:      	str	x9, [x0, #0x50]
     5d8:      	ldr	x9, [x12, #0x10]
     5dc:      	ldr	x10, [x12, #0x18]
     5e0:      	str	x9, [x12, #0x30]
     5e4:      	str	x10, [x12, #0x38]
     5e8:      	ldr	x9, [x0, #0x58]
     5ec:      	cmp	x9, #0x0
     5f0:      	b.ne	0x60c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x60c>
     5f4:      	mov	w9, #0x2                // =2
     5f8:      	str	x9, [x0, #0x38]
     5fc:      	mov	w9, #0x0                // =0
     600:      	str	x9, [x0, #0x70]
     604:      	mov	w0, #0x6                // =6
     608:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     60c:      	sub	x9, x9, #0x1
     610:      	str	x9, [x0, #0x58]
     614:      	ldr	x9, [x0, #0x90]
     618:      	cbnz	x9, 0xd18 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd18>
     61c:      	ldr	x9, [x0, #0x88]
     620:      	cmp	x9, #0x0
     624:      	b.eq	0x654 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x654>
     628:      	mov	w9, #0x3c               // =60
     62c:      	str	x9, [x0, #0x40]
     630:      	ldr	x9, [x0, #0x50]
     634:      	cmp	x9, #0x0
     638:      	b.ne	0x64c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x64c>
     63c:      	mov	w9, #0x2                // =2
     640:      	str	x9, [x0, #0x38]
     644:      	mov	w0, #0x7                // =7
     648:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     64c:      	sub	x9, x9, #0x1
     650:      	str	x9, [x0, #0x50]
     654:      	b	0x6a4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x6a4>
     658:      	ldr	x9, [x0, #0x58]
     65c:      	cmp	x9, #0x0
     660:      	b.ne	0x67c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x67c>
     664:      	mov	w9, #0x3                // =3
     668:      	str	x9, [x0, #0x38]
     66c:      	mov	w9, #0x0                // =0
     670:      	str	x9, [x0, #0x70]
     674:      	mov	w0, #0x6                // =6
     678:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     67c:      	sub	x9, x9, #0x1
     680:      	str	x9, [x0, #0x58]
     684:      	ldr	x9, [x0, #0x90]
     688:      	cbnz	x9, 0xd34 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd34>
     68c:      	mov	w9, #0x3                // =3
     690:      	str	x9, [x0, #0x38]
     694:      	mov	w9, #0x3                // =3
     698:      	str	x9, [x0, #0x70]
     69c:      	mov	w0, #0x1                // =1
     6a0:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     6a4:      	ldr	x9, [x0, #0x58]
     6a8:      	cmp	x9, #0x0
     6ac:      	b.ne	0x6c8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x6c8>
     6b0:      	mov	w9, #0x4                // =4
     6b4:      	str	x9, [x0, #0x38]
     6b8:      	mov	w9, #0x0                // =0
     6bc:      	str	x9, [x0, #0x70]
     6c0:      	mov	w0, #0x6                // =6
     6c4:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     6c8:      	sub	x9, x9, #0x1
     6cc:      	str	x9, [x0, #0x58]
     6d0:      	ldr	x9, [x0, #0x90]
     6d4:      	cbnz	x9, 0xd50 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd50>
     6d8:      	ldr	x9, [x0, #0x88]
     6dc:      	cmp	x9, #0x0
     6e0:      	b.eq	0x710 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x710>
     6e4:      	mov	w9, #0x3e               // =62
     6e8:      	str	x9, [x0, #0x40]
     6ec:      	ldr	x9, [x0, #0x50]
     6f0:      	cmp	x9, #0x0
     6f4:      	b.ne	0x708 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x708>
     6f8:      	mov	w9, #0x4                // =4
     6fc:      	str	x9, [x0, #0x38]
     700:      	mov	w0, #0x7                // =7
     704:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     708:      	sub	x9, x9, #0x1
     70c:      	str	x9, [x0, #0x50]
     710:      	b	0x7c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x7c0>
     714:      	ldr	x9, [x0, #0x58]
     718:      	cmp	x9, #0x0
     71c:      	b.ne	0x738 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x738>
     720:      	mov	w9, #0x5                // =5
     724:      	str	x9, [x0, #0x38]
     728:      	mov	w9, #0x0                // =0
     72c:      	str	x9, [x0, #0x70]
     730:      	mov	w0, #0x6                // =6
     734:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     738:      	sub	x9, x9, #0x1
     73c:      	str	x9, [x0, #0x58]
     740:      	ldr	x9, [x0, #0x88]
     744:      	cmp	x9, #0x0
     748:      	b.eq	0x778 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x778>
     74c:      	mov	w9, #0x58               // =88
     750:      	str	x9, [x0, #0x40]
     754:      	ldr	x9, [x0, #0x50]
     758:      	cmp	x9, #0x0
     75c:      	b.ne	0x770 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x770>
     760:      	mov	w9, #0x5                // =5
     764:      	str	x9, [x0, #0x38]
     768:      	mov	w0, #0x7                // =7
     76c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     770:      	sub	x9, x9, #0x1
     774:      	str	x9, [x0, #0x50]
     778:      	ldr	x9, [x0, #0x58]
     77c:      	cmp	x9, #0x0
     780:      	b.ne	0x79c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x79c>
     784:      	mov	w9, #0x6                // =6
     788:      	str	x9, [x0, #0x38]
     78c:      	mov	w9, #0x0                // =0
     790:      	str	x9, [x0, #0x70]
     794:      	mov	w0, #0x6                // =6
     798:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     79c:      	sub	x9, x9, #0x1
     7a0:      	str	x9, [x0, #0x58]
     7a4:      	ldr	x9, [x0, #0x90]
     7a8:      	cbnz	x9, 0xd6c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd6c>
     7ac:      	ldr	x9, [x12, #0x30]
     7b0:      	ldr	x10, [x12, #0x38]
     7b4:      	str	x9, [x12, #0x40]
     7b8:      	str	x10, [x12, #0x48]
     7bc:      	b	0x658 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x658>
     7c0:      	ldr	x9, [x0, #0x58]
     7c4:      	cmp	x9, #0x0
     7c8:      	b.ne	0x7e4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x7e4>
     7cc:      	mov	w9, #0x7                // =7
     7d0:      	str	x9, [x0, #0x38]
     7d4:      	mov	w9, #0x0                // =0
     7d8:      	str	x9, [x0, #0x70]
     7dc:      	mov	w0, #0x6                // =6
     7e0:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     7e4:      	sub	x9, x9, #0x1
     7e8:      	str	x9, [x0, #0x58]
     7ec:      	ldr	x9, [x0, #0x88]
     7f0:      	cmp	x9, #0x0
     7f4:      	b.eq	0x824 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x824>
     7f8:      	mov	w9, #0x40               // =64
     7fc:      	str	x9, [x0, #0x40]
     800:      	ldr	x9, [x0, #0x50]
     804:      	cmp	x9, #0x0
     808:      	b.ne	0x81c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x81c>
     80c:      	mov	w9, #0x7                // =7
     810:      	str	x9, [x0, #0x38]
     814:      	mov	w0, #0x7                // =7
     818:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     81c:      	sub	x9, x9, #0x1
     820:      	str	x9, [x0, #0x50]
     824:      	ldr	x9, [x0, #0x58]
     828:      	cmp	x9, #0x0
     82c:      	b.ne	0x848 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x848>
     830:      	mov	w9, #0x8                // =8
     834:      	str	x9, [x0, #0x38]
     838:      	mov	w9, #0x0                // =0
     83c:      	str	x9, [x0, #0x70]
     840:      	mov	w0, #0x6                // =6
     844:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     848:      	sub	x9, x9, #0x1
     84c:      	str	x9, [x0, #0x58]
     850:      	ldr	x9, [x0, #0x88]
     854:      	cmp	x9, #0x0
     858:      	b.eq	0x888 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x888>
     85c:      	mov	w9, #0x42               // =66
     860:      	str	x9, [x0, #0x40]
     864:      	ldr	x9, [x0, #0x50]
     868:      	cmp	x9, #0x0
     86c:      	b.ne	0x880 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x880>
     870:      	mov	w9, #0x8                // =8
     874:      	str	x9, [x0, #0x38]
     878:      	mov	w0, #0x7                // =7
     87c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     880:      	sub	x9, x9, #0x1
     884:      	str	x9, [x0, #0x50]
     888:      	ldr	x9, [x0, #0x58]
     88c:      	cmp	x9, #0x0
     890:      	b.ne	0x8ac <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x8ac>
     894:      	mov	w9, #0x9                // =9
     898:      	str	x9, [x0, #0x38]
     89c:      	mov	w9, #0x0                // =0
     8a0:      	str	x9, [x0, #0x70]
     8a4:      	mov	w0, #0x6                // =6
     8a8:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     8ac:      	sub	x9, x9, #0x1
     8b0:      	str	x9, [x0, #0x58]
     8b4:      	ldr	x9, [x0, #0x88]
     8b8:      	cmp	x9, #0x0
     8bc:      	b.eq	0x8ec <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x8ec>
     8c0:      	mov	w9, #0x44               // =68
     8c4:      	str	x9, [x0, #0x40]
     8c8:      	ldr	x9, [x0, #0x50]
     8cc:      	cmp	x9, #0x0
     8d0:      	b.ne	0x8e4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x8e4>
     8d4:      	mov	w9, #0x9                // =9
     8d8:      	str	x9, [x0, #0x38]
     8dc:      	mov	w0, #0x7                // =7
     8e0:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     8e4:      	sub	x9, x9, #0x1
     8e8:      	str	x9, [x0, #0x50]
     8ec:      	ldr	w9, [x12, #0x20]
     8f0:      	ldr	w10, [x12]
     8f4:      	cmp	w9, w10
     8f8:      	cset	w9, hs
     8fc:      	str	x9, [x12, #0x50]
     900:      	mov	w9, #0x0                // =0
     904:      	str	x9, [x12, #0x58]
     908:      	ldr	x9, [x0, #0x58]
     90c:      	cmp	x9, #0x0
     910:      	b.ne	0x92c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x92c>
     914:      	mov	w9, #0xa                // =10
     918:      	str	x9, [x0, #0x38]
     91c:      	mov	w9, #0x0                // =0
     920:      	str	x9, [x0, #0x70]
     924:      	mov	w0, #0x6                // =6
     928:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     92c:      	sub	x9, x9, #0x1
     930:      	str	x9, [x0, #0x58]
     934:      	ldr	x9, [x0, #0x90]
     938:      	cbnz	x9, 0xd88 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd88>
     93c:      	ldr	x9, [x0, #0x88]
     940:      	cmp	x9, #0x0
     944:      	b.eq	0x974 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x974>
     948:      	mov	w9, #0x45               // =69
     94c:      	str	x9, [x0, #0x40]
     950:      	ldr	x9, [x0, #0x50]
     954:      	cmp	x9, #0x0
     958:      	b.ne	0x96c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x96c>
     95c:      	mov	w9, #0xa                // =10
     960:      	str	x9, [x0, #0x38]
     964:      	mov	w0, #0x7                // =7
     968:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     96c:      	sub	x9, x9, #0x1
     970:      	str	x9, [x0, #0x50]
     974:      	ldr	w9, [x12, #0x50]
     978:      	cbnz	w9, 0x714 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x714>
     97c:      	ldr	x9, [x0, #0x58]
     980:      	cmp	x9, #0x0
     984:      	b.ne	0x9a0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x9a0>
     988:      	mov	w9, #0xb                // =11
     98c:      	str	x9, [x0, #0x38]
     990:      	mov	w9, #0x0                // =0
     994:      	str	x9, [x0, #0x70]
     998:      	mov	w0, #0x6                // =6
     99c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     9a0:      	sub	x9, x9, #0x1
     9a4:      	str	x9, [x0, #0x58]
     9a8:      	ldr	x9, [x0, #0x88]
     9ac:      	cmp	x9, #0x0
     9b0:      	b.eq	0x9e0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x9e0>
     9b4:      	mov	w9, #0x47               // =71
     9b8:      	str	x9, [x0, #0x40]
     9bc:      	ldr	x9, [x0, #0x50]
     9c0:      	cmp	x9, #0x0
     9c4:      	b.ne	0x9d8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x9d8>
     9c8:      	mov	w9, #0xb                // =11
     9cc:      	str	x9, [x0, #0x38]
     9d0:      	mov	w0, #0x7                // =7
     9d4:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     9d8:      	sub	x9, x9, #0x1
     9dc:      	str	x9, [x0, #0x50]
     9e0:      	ldr	x9, [x0, #0x58]
     9e4:      	cmp	x9, #0x0
     9e8:      	b.ne	0xa04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xa04>
     9ec:      	mov	w9, #0xc                // =12
     9f0:      	str	x9, [x0, #0x38]
     9f4:      	mov	w9, #0x0                // =0
     9f8:      	str	x9, [x0, #0x70]
     9fc:      	mov	w0, #0x6                // =6
     a00:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     a04:      	sub	x9, x9, #0x1
     a08:      	str	x9, [x0, #0x58]
     a0c:      	ldr	x9, [x0, #0x90]
     a10:      	cbnz	x9, 0xda4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xda4>
     a14:      	ldr	x9, [x0, #0x88]
     a18:      	cmp	x9, #0x0
     a1c:      	b.eq	0xa4c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xa4c>
     a20:      	mov	w9, #0x49               // =73
     a24:      	str	x9, [x0, #0x40]
     a28:      	ldr	x9, [x0, #0x50]
     a2c:      	cmp	x9, #0x0
     a30:      	b.ne	0xa44 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xa44>
     a34:      	mov	w9, #0xc                // =12
     a38:      	str	x9, [x0, #0x38]
     a3c:      	mov	w0, #0x7                // =7
     a40:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     a44:      	sub	x9, x9, #0x1
     a48:      	str	x9, [x0, #0x50]
     a4c:      	mov	w9, #0x49               // =73
     a50:      	str	x9, [x0, #0x40]
     a54:      	mov	w9, #0xd                // =13
     a58:      	str	x9, [x0, #0x38]
     a5c:      	mov	w9, #0xc                // =12
     a60:      	str	x9, [x0, #0x70]
     a64:      	mov	w0, #0xa                // =10
     a68:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     a6c:      	ldr	x9, [x0, #0x58]
     a70:      	cmp	x9, #0x0
     a74:      	b.ne	0xa90 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xa90>
     a78:      	mov	w9, #0xd                // =13
     a7c:      	str	x9, [x0, #0x38]
     a80:      	mov	w9, #0x0                // =0
     a84:      	str	x9, [x0, #0x70]
     a88:      	mov	w0, #0x6                // =6
     a8c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     a90:      	sub	x9, x9, #0x1
     a94:      	str	x9, [x0, #0x58]
     a98:      	ldr	x9, [x0, #0x88]
     a9c:      	cmp	x9, #0x0
     aa0:      	b.eq	0xad0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xad0>
     aa4:      	mov	w9, #0x4b               // =75
     aa8:      	str	x9, [x0, #0x40]
     aac:      	ldr	x9, [x0, #0x50]
     ab0:      	cmp	x9, #0x0
     ab4:      	b.ne	0xac8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xac8>
     ab8:      	mov	w9, #0xd                // =13
     abc:      	str	x9, [x0, #0x38]
     ac0:      	mov	w0, #0x7                // =7
     ac4:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     ac8:      	sub	x9, x9, #0x1
     acc:      	str	x9, [x0, #0x50]
     ad0:      	ldr	x9, [x12, #0x50]
     ad4:      	ldr	x10, [x12, #0x58]
     ad8:      	str	x9, [x12, #0x30]
     adc:      	str	x10, [x12, #0x38]
     ae0:      	ldr	x9, [x0, #0x58]
     ae4:      	cmp	x9, #0x0
     ae8:      	b.ne	0xb04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xb04>
     aec:      	mov	w9, #0xe                // =14
     af0:      	str	x9, [x0, #0x38]
     af4:      	mov	w9, #0x0                // =0
     af8:      	str	x9, [x0, #0x70]
     afc:      	mov	w0, #0x6                // =6
     b00:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     b04:      	sub	x9, x9, #0x1
     b08:      	str	x9, [x0, #0x58]
     b0c:      	ldr	x9, [x0, #0x88]
     b10:      	cmp	x9, #0x0
     b14:      	b.eq	0xb44 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xb44>
     b18:      	mov	w9, #0x4d               // =77
     b1c:      	str	x9, [x0, #0x40]
     b20:      	ldr	x9, [x0, #0x50]
     b24:      	cmp	x9, #0x0
     b28:      	b.ne	0xb3c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xb3c>
     b2c:      	mov	w9, #0xe                // =14
     b30:      	str	x9, [x0, #0x38]
     b34:      	mov	w0, #0x7                // =7
     b38:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     b3c:      	sub	x9, x9, #0x1
     b40:      	str	x9, [x0, #0x50]
     b44:      	ldr	x9, [x0, #0x58]
     b48:      	cmp	x9, #0x0
     b4c:      	b.ne	0xb68 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xb68>
     b50:      	mov	w9, #0xf                // =15
     b54:      	str	x9, [x0, #0x38]
     b58:      	mov	w9, #0x0                // =0
     b5c:      	str	x9, [x0, #0x70]
     b60:      	mov	w0, #0x6                // =6
     b64:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     b68:      	sub	x9, x9, #0x1
     b6c:      	str	x9, [x0, #0x58]
     b70:      	ldr	x9, [x0, #0x88]
     b74:      	cmp	x9, #0x0
     b78:      	b.eq	0xba8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xba8>
     b7c:      	mov	w9, #0x4f               // =79
     b80:      	str	x9, [x0, #0x40]
     b84:      	ldr	x9, [x0, #0x50]
     b88:      	cmp	x9, #0x0
     b8c:      	b.ne	0xba0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xba0>
     b90:      	mov	w9, #0xf                // =15
     b94:      	str	x9, [x0, #0x38]
     b98:      	mov	w0, #0x7                // =7
     b9c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     ba0:      	sub	x9, x9, #0x1
     ba4:      	str	x9, [x0, #0x50]
     ba8:      	mov	w9, #0x1                // =1
     bac:      	str	x9, [x12, #0x50]
     bb0:      	mov	w9, #0x0                // =0
     bb4:      	str	x9, [x12, #0x58]
     bb8:      	ldr	x9, [x0, #0x58]
     bbc:      	cmp	x9, #0x0
     bc0:      	b.ne	0xbdc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xbdc>
     bc4:      	mov	w9, #0x10               // =16
     bc8:      	str	x9, [x0, #0x38]
     bcc:      	mov	w9, #0x0                // =0
     bd0:      	str	x9, [x0, #0x70]
     bd4:      	mov	w0, #0x6                // =6
     bd8:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     bdc:      	sub	x9, x9, #0x1
     be0:      	str	x9, [x0, #0x58]
     be4:      	ldr	x9, [x0, #0x88]
     be8:      	cmp	x9, #0x0
     bec:      	b.eq	0xc1c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xc1c>
     bf0:      	mov	w9, #0x51               // =81
     bf4:      	str	x9, [x0, #0x40]
     bf8:      	ldr	x9, [x0, #0x50]
     bfc:      	cmp	x9, #0x0
     c00:      	b.ne	0xc14 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xc14>
     c04:      	mov	w9, #0x10               // =16
     c08:      	str	x9, [x0, #0x38]
     c0c:      	mov	w0, #0x7                // =7
     c10:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     c14:      	sub	x9, x9, #0x1
     c18:      	str	x9, [x0, #0x50]
     c1c:      	ldr	w9, [x12, #0x20]
     c20:      	ldr	w10, [x12, #0x50]
     c24:      	add	w9, w9, w10
     c28:      	str	x9, [x12, #0x50]
     c2c:      	mov	w9, #0x0                // =0
     c30:      	str	x9, [x12, #0x58]
     c34:      	ldr	x9, [x0, #0x58]
     c38:      	cmp	x9, #0x0
     c3c:      	b.ne	0xc58 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xc58>
     c40:      	mov	w9, #0x11               // =17
     c44:      	str	x9, [x0, #0x38]
     c48:      	mov	w9, #0x0                // =0
     c4c:      	str	x9, [x0, #0x70]
     c50:      	mov	w0, #0x6                // =6
     c54:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     c58:      	sub	x9, x9, #0x1
     c5c:      	str	x9, [x0, #0x58]
     c60:      	ldr	x9, [x0, #0x88]
     c64:      	cmp	x9, #0x0
     c68:      	b.eq	0xc98 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xc98>
     c6c:      	mov	w9, #0x52               // =82
     c70:      	str	x9, [x0, #0x40]
     c74:      	ldr	x9, [x0, #0x50]
     c78:      	cmp	x9, #0x0
     c7c:      	b.ne	0xc90 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xc90>
     c80:      	mov	w9, #0x11               // =17
     c84:      	str	x9, [x0, #0x38]
     c88:      	mov	w0, #0x7                // =7
     c8c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     c90:      	sub	x9, x9, #0x1
     c94:      	str	x9, [x0, #0x50]
     c98:      	ldr	x9, [x12, #0x50]
     c9c:      	ldr	x10, [x12, #0x58]
     ca0:      	str	x9, [x12, #0x20]
     ca4:      	str	x10, [x12, #0x28]
     ca8:      	ldr	x9, [x0, #0x58]
     cac:      	cmp	x9, #0x0
     cb0:      	b.ne	0xccc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xccc>
     cb4:      	mov	w9, #0x12               // =18
     cb8:      	str	x9, [x0, #0x38]
     cbc:      	mov	w9, #0x0                // =0
     cc0:      	str	x9, [x0, #0x70]
     cc4:      	mov	w0, #0x6                // =6
     cc8:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     ccc:      	sub	x9, x9, #0x1
     cd0:      	str	x9, [x0, #0x58]
     cd4:      	ldr	x9, [x0, #0x90]
     cd8:      	cbnz	x9, 0xdc0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xdc0>
     cdc:      	ldr	x9, [x0, #0x88]
     ce0:      	cmp	x9, #0x0
     ce4:      	b.eq	0xd14 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd14>
     ce8:      	mov	w9, #0x54               // =84
     cec:      	str	x9, [x0, #0x40]
     cf0:      	ldr	x9, [x0, #0x50]
     cf4:      	cmp	x9, #0x0
     cf8:      	b.ne	0xd0c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xd0c>
     cfc:      	mov	w9, #0x12               // =18
     d00:      	str	x9, [x0, #0x38]
     d04:      	mov	w0, #0x7                // =7
     d08:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     d0c:      	sub	x9, x9, #0x1
     d10:      	str	x9, [x0, #0x50]
     d14:      	b	0x7c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0x7c0>
     d18:      	dmb	ishld
     d1c:      	mov	w9, #0x2                // =2
     d20:      	str	x9, [x0, #0x38]
     d24:      	mov	w9, #0x0                // =0
     d28:      	str	x9, [x0, #0x70]
     d2c:      	mov	w0, #0x6                // =6
     d30:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     d34:      	dmb	ishld
     d38:      	mov	w9, #0x3                // =3
     d3c:      	str	x9, [x0, #0x38]
     d40:      	mov	w9, #0x0                // =0
     d44:      	str	x9, [x0, #0x70]
     d48:      	mov	w0, #0x6                // =6
     d4c:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     d50:      	dmb	ishld
     d54:      	mov	w9, #0x4                // =4
     d58:      	str	x9, [x0, #0x38]
     d5c:      	mov	w9, #0x0                // =0
     d60:      	str	x9, [x0, #0x70]
     d64:      	mov	w0, #0x6                // =6
     d68:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     d6c:      	dmb	ishld
     d70:      	mov	w9, #0x6                // =6
     d74:      	str	x9, [x0, #0x38]
     d78:      	mov	w9, #0x0                // =0
     d7c:      	str	x9, [x0, #0x70]
     d80:      	mov	w0, #0x6                // =6
     d84:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     d88:      	dmb	ishld
     d8c:      	mov	w9, #0xa                // =10
     d90:      	str	x9, [x0, #0x38]
     d94:      	mov	w9, #0x0                // =0
     d98:      	str	x9, [x0, #0x70]
     d9c:      	mov	w0, #0x6                // =6
     da0:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     da4:      	dmb	ishld
     da8:      	mov	w9, #0xc                // =12
     dac:      	str	x9, [x0, #0x38]
     db0:      	mov	w9, #0x0                // =0
     db4:      	str	x9, [x0, #0x70]
     db8:      	mov	w0, #0x6                // =6
     dbc:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     dc0:      	dmb	ishld
     dc4:      	mov	w9, #0x12               // =18
     dc8:      	str	x9, [x0, #0x38]
     dcc:      	mov	w9, #0x0                // =0
     dd0:      	str	x9, [x0, #0x70]
     dd4:      	mov	w0, #0x6                // =6
     dd8:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     ddc:      	mov	w0, #0xb                // =11
     de0:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     de4:      	mov	w9, #0x7                // =7
     de8:      	str	x9, [x0, #0x70]
     dec:      	mov	w0, #0x2                // =2
     df0:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     df4:      	mov	w9, #0x6                // =6
     df8:      	str	x9, [x0, #0x70]
     dfc:      	mov	w0, #0x2                // =2
     e00:      	b	0xe04 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_host_wasmvm_890047443_bin_start+0xe04>
     e04:      	ldp	q14, q15, [sp], #0x20
     e08:      	ldp	q12, q13, [sp], #0x20
     e0c:      	ldp	q10, q11, [sp], #0x20
     e10:      	ldp	q8, q9, [sp], #0x20
     e14:      	ldp	x27, x28, [sp], #0x10
     e18:      	ldp	x25, x26, [sp], #0x10
     e1c:      	ldp	x23, x24, [sp], #0x10
     e20:      	ldp	x21, x22, [sp], #0x10
     e24:      	ldp	x19, x20, [sp], #0x10
     e28:      	ldp	x29, x30, [sp], #0x10
     e2c:      	ret
