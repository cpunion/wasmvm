
/Users/lijie/source/goplus/wasmvm/artifacts/p3-mechanism-costs-20261116/allocation-stacks/core-loop/wasmvm-2274881109.elf:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start>:
       0:      	stp	x29, x30, [sp, #-0x10]!
       4:      	mov	x29, sp
       8:      	stp	x19, x20, [sp, #-0x10]!
       c:      	stp	x21, x22, [sp, #-0x10]!
      10:      	stp	x23, x24, [sp, #-0x10]!
      14:      	stp	x25, x26, [sp, #-0x10]!
      18:      	stp	x27, x28, [sp, #-0x10]!
      1c:      	stp	q8, q9, [sp, #-0x20]!
      20:      	stp	q10, q11, [sp, #-0x20]!
      24:      	stp	q12, q13, [sp, #-0x20]!
      28:      	stp	q14, q15, [sp, #-0x20]!
      2c:      	ldr	x12, [x0, #0x8]
      30:      	ldr	x13, [x0, #0x20]
      34:      	ldr	x9, [x0, #0x10]
      38:      	sub	x9, x9, x13
      3c:      	mov	w10, #0x70              // =112
      40:      	cmp	x9, x10
      44:      	b.lo	0x3a0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x3a0>
      48:      	and	x9, x13, #0xf
      4c:      	cmp	x9, #0x0
      50:      	b.ne	0x3a0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x3a0>
      54:      	add	x12, x12, x13
      58:      	mov	w9, #0x0                // =0
      5c:      	str	x9, [x0, #0x48]
      60:      	ldr	x9, [x0, #0x38]
      64:      	mov	w10, #0x16              // =22
      68:      	cmp	x9, x10
      6c:      	b.hs	0x3a0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x3a0>
      70:      	ldr	x19, [x12, #0x50]
      74:      	ldr	x20, [x12, #0x30]
      78:      	ldr	x21, [x12, #0x20]
      7c:      	ldr	x22, [x12, #0x40]
      80:      	ldr	x23, [x12]
      84:      	ldr	x24, [x12, #0x60]
      88:      	ldr	x25, [x12, #0x10]
      8c:      	ldr	x9, [x0, #0x88]
      90:      	cmp	x9, #0x0
      94:      	b.ne	0x3a0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x3a0>
      98:      	ldr	x9, [x0, #0x38]
      9c:      	adr	x13, 0xac <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xac>
      a0:      	ldrsw	x14, [x13, x9, lsl #2]
      a4:      	add	x13, x13, x14
      a8:      	br	x13
      ac:      	udf	#0x58
      b0:      	udf	#0x60
      b4:      	udf	#0x64
      b8:      	udf	#0x70
      bc:      	udf	#0xac
      c0:      	udf	#0xb8
      c4:      	udf	#0xb8
      c8:      	udf	#0xc8
      cc:      	udf	#0xc8
      d0:      	udf	#0xc8
      d4:      	udf	#0xfc
      d8:      	udf	#0xdc
      dc:      	udf	#0xdc
      e0:      	udf	#0x10c
      e4:      	udf	#0xe0
      e8:      	udf	#0x114
      ec:      	udf	#0x11c
      f0:      	udf	#0xe8
      f4:      	udf	#0xe8
      f8:      	udf	#0x124
      fc:      	udf	#0x12c
     100:      	udf	#0xf0
     104:      	ldr	x9, [x0, #0x90]
     108:      	cbnz	x9, 0x1e0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x1e0>
     10c:      	mov	x20, x25
     110:      	ldr	x9, [x0, #0x90]
     114:      	cbnz	x9, 0x218 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x218>
     118:      	b	0x158 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x158>
     11c:      	ldr	x9, [x0, #0x90]
     120:      	cbnz	x9, 0x250 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x250>
     124:      	mov	w9, #0x3                // =3
     128:      	str	x9, [x0, #0x38]
     12c:      	mov	w9, #0x3                // =3
     130:      	str	x9, [x0, #0x70]
     134:      	str	x19, [x12, #0x50]
     138:      	str	x20, [x12, #0x30]
     13c:      	str	x21, [x12, #0x20]
     140:      	str	x22, [x12, #0x40]
     144:      	str	x23, [x12]
     148:      	str	x24, [x12, #0x60]
     14c:      	str	x25, [x12, #0x10]
     150:      	mov	w0, #0x1                // =1
     154:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     158:      	ldr	x9, [x0, #0x90]
     15c:      	cbnz	x9, 0x288 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x288>
     160:      	b	0x174 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x174>
     164:      	ldr	x9, [x0, #0x90]
     168:      	cbnz	x9, 0x2c0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x2c0>
     16c:      	mov	x22, x20
     170:      	b	0x11c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x11c>
     174:      	cmp	w21, w23
     178:      	cset	w19, hs
     17c:      	ldr	x9, [x0, #0x90]
     180:      	cbnz	x9, 0x2f8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x2f8>
     184:      	b.hs	0x164 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x164>
     188:      	add	w19, w20, w20, lsl #4
     18c:      	mov	w24, #0x5               // =5
     190:      	add	w20, w19, #0x5
     194:      	add	w21, w21, #0x1
     198:      	mov	x19, x21
     19c:      	ldr	x9, [x0, #0x90]
     1a0:      	cbnz	x9, 0x330 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x330>
     1a4:      	b	0x174 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x174>
     1a8:      	ldr	x9, [x0, #0x90]
     1ac:      	cbnz	x9, 0x368 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x368>
     1b0:      	cbnz	w19, 0x164 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x164>
     1b4:      	b	0x188 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x188>
     1b8:      	mul	w19, w20, w19
     1bc:      	b	0x18c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x18c>
     1c0:      	add	w19, w19, w24
     1c4:      	b	0x1c8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x1c8>
     1c8:      	mov	x20, x19
     1cc:      	b	0x194 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x194>
     1d0:      	add	w19, w21, w19
     1d4:      	b	0x1d8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x1d8>
     1d8:      	mov	x21, x19
     1dc:      	b	0x19c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x19c>
     1e0:      	dmb	ishld
     1e4:      	mov	w9, #0x0                // =0
     1e8:      	str	x9, [x0, #0x38]
     1ec:      	mov	w9, #0x0                // =0
     1f0:      	str	x9, [x0, #0x70]
     1f4:      	str	x19, [x12, #0x50]
     1f8:      	str	x20, [x12, #0x30]
     1fc:      	str	x21, [x12, #0x20]
     200:      	str	x22, [x12, #0x40]
     204:      	str	x23, [x12]
     208:      	str	x24, [x12, #0x60]
     20c:      	str	x25, [x12, #0x10]
     210:      	mov	w0, #0x6                // =6
     214:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     218:      	dmb	ishld
     21c:      	mov	w9, #0x2                // =2
     220:      	str	x9, [x0, #0x38]
     224:      	mov	w9, #0x0                // =0
     228:      	str	x9, [x0, #0x70]
     22c:      	str	x19, [x12, #0x50]
     230:      	str	x20, [x12, #0x30]
     234:      	str	x21, [x12, #0x20]
     238:      	str	x22, [x12, #0x40]
     23c:      	str	x23, [x12]
     240:      	str	x24, [x12, #0x60]
     244:      	str	x25, [x12, #0x10]
     248:      	mov	w0, #0x6                // =6
     24c:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     250:      	dmb	ishld
     254:      	mov	w9, #0x3                // =3
     258:      	str	x9, [x0, #0x38]
     25c:      	mov	w9, #0x0                // =0
     260:      	str	x9, [x0, #0x70]
     264:      	str	x19, [x12, #0x50]
     268:      	str	x20, [x12, #0x30]
     26c:      	str	x21, [x12, #0x20]
     270:      	str	x22, [x12, #0x40]
     274:      	str	x23, [x12]
     278:      	str	x24, [x12, #0x60]
     27c:      	str	x25, [x12, #0x10]
     280:      	mov	w0, #0x6                // =6
     284:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     288:      	dmb	ishld
     28c:      	mov	w9, #0x4                // =4
     290:      	str	x9, [x0, #0x38]
     294:      	mov	w9, #0x0                // =0
     298:      	str	x9, [x0, #0x70]
     29c:      	str	x19, [x12, #0x50]
     2a0:      	str	x20, [x12, #0x30]
     2a4:      	str	x21, [x12, #0x20]
     2a8:      	str	x22, [x12, #0x40]
     2ac:      	str	x23, [x12]
     2b0:      	str	x24, [x12, #0x60]
     2b4:      	str	x25, [x12, #0x10]
     2b8:      	mov	w0, #0x6                // =6
     2bc:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     2c0:      	dmb	ishld
     2c4:      	mov	w9, #0x6                // =6
     2c8:      	str	x9, [x0, #0x38]
     2cc:      	mov	w9, #0x0                // =0
     2d0:      	str	x9, [x0, #0x70]
     2d4:      	str	x19, [x12, #0x50]
     2d8:      	str	x20, [x12, #0x30]
     2dc:      	str	x21, [x12, #0x20]
     2e0:      	str	x22, [x12, #0x40]
     2e4:      	str	x23, [x12]
     2e8:      	str	x24, [x12, #0x60]
     2ec:      	str	x25, [x12, #0x10]
     2f0:      	mov	w0, #0x6                // =6
     2f4:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     2f8:      	dmb	ishld
     2fc:      	mov	w9, #0xa                // =10
     300:      	str	x9, [x0, #0x38]
     304:      	mov	w9, #0x0                // =0
     308:      	str	x9, [x0, #0x70]
     30c:      	str	x19, [x12, #0x50]
     310:      	str	x20, [x12, #0x30]
     314:      	str	x21, [x12, #0x20]
     318:      	str	x22, [x12, #0x40]
     31c:      	str	x23, [x12]
     320:      	str	x24, [x12, #0x60]
     324:      	str	x25, [x12, #0x10]
     328:      	mov	w0, #0x6                // =6
     32c:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     330:      	dmb	ishld
     334:      	mov	w9, #0x15               // =21
     338:      	str	x9, [x0, #0x38]
     33c:      	mov	w9, #0x0                // =0
     340:      	str	x9, [x0, #0x70]
     344:      	str	x19, [x12, #0x50]
     348:      	str	x20, [x12, #0x30]
     34c:      	str	x21, [x12, #0x20]
     350:      	str	x22, [x12, #0x40]
     354:      	str	x23, [x12]
     358:      	str	x24, [x12, #0x60]
     35c:      	str	x25, [x12, #0x10]
     360:      	mov	w0, #0x6                // =6
     364:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     368:      	dmb	ishld
     36c:      	mov	w9, #0xa                // =10
     370:      	str	x9, [x0, #0x38]
     374:      	mov	w9, #0x0                // =0
     378:      	str	x9, [x0, #0x70]
     37c:      	str	x19, [x12, #0x50]
     380:      	str	x20, [x12, #0x30]
     384:      	str	x21, [x12, #0x20]
     388:      	str	x22, [x12, #0x40]
     38c:      	str	x23, [x12]
     390:      	str	x24, [x12, #0x60]
     394:      	str	x25, [x12, #0x10]
     398:      	mov	w0, #0x6                // =6
     39c:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     3a0:      	mov	w0, #0xb                // =11
     3a4:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     3a8:      	mov	w9, #0x7                // =7
     3ac:      	str	x9, [x0, #0x70]
     3b0:      	str	x19, [x12, #0x50]
     3b4:      	str	x20, [x12, #0x30]
     3b8:      	str	x21, [x12, #0x20]
     3bc:      	str	x22, [x12, #0x40]
     3c0:      	str	x23, [x12]
     3c4:      	str	x24, [x12, #0x60]
     3c8:      	str	x25, [x12, #0x10]
     3cc:      	mov	w0, #0x2                // =2
     3d0:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     3d4:      	mov	w9, #0x6                // =6
     3d8:      	str	x9, [x0, #0x70]
     3dc:      	str	x19, [x12, #0x50]
     3e0:      	str	x20, [x12, #0x30]
     3e4:      	str	x21, [x12, #0x20]
     3e8:      	str	x22, [x12, #0x40]
     3ec:      	str	x23, [x12]
     3f0:      	str	x24, [x12, #0x60]
     3f4:      	str	x25, [x12, #0x10]
     3f8:      	mov	w0, #0x2                // =2
     3fc:      	b	0x400 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x400>
     400:      	ldp	q14, q15, [sp], #0x20
     404:      	ldp	q12, q13, [sp], #0x20
     408:      	ldp	q10, q11, [sp], #0x20
     40c:      	ldp	q8, q9, [sp], #0x20
     410:      	ldp	x27, x28, [sp], #0x10
     414:      	ldp	x25, x26, [sp], #0x10
     418:      	ldp	x23, x24, [sp], #0x10
     41c:      	ldp	x21, x22, [sp], #0x10
     420:      	ldp	x19, x20, [sp], #0x10
     424:      	ldp	x29, x30, [sp], #0x10
     428:      	ret
     42c:      	stp	x29, x30, [sp, #-0x10]!
     430:      	mov	x29, sp
     434:      	stp	x19, x20, [sp, #-0x10]!
     438:      	stp	x21, x22, [sp, #-0x10]!
     43c:      	stp	x23, x24, [sp, #-0x10]!
     440:      	stp	x25, x26, [sp, #-0x10]!
     444:      	stp	x27, x28, [sp, #-0x10]!
     448:      	stp	q8, q9, [sp, #-0x20]!
     44c:      	stp	q10, q11, [sp, #-0x20]!
     450:      	stp	q12, q13, [sp, #-0x20]!
     454:      	stp	q14, q15, [sp, #-0x20]!
     458:      	ldr	x12, [x0, #0x8]
     45c:      	ldr	x13, [x0, #0x20]
     460:      	ldr	x9, [x0, #0x10]
     464:      	sub	x9, x9, x13
     468:      	mov	w10, #0x70              // =112
     46c:      	cmp	x9, x10
     470:      	b.lo	0xf08 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf08>
     474:      	and	x9, x13, #0xf
     478:      	cmp	x9, #0x0
     47c:      	b.ne	0xf08 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf08>
     480:      	add	x12, x12, x13
     484:      	mov	w9, #0x0                // =0
     488:      	str	x9, [x0, #0x48]
     48c:      	ldr	x9, [x0, #0x38]
     490:      	mov	w10, #0x16              // =22
     494:      	cmp	x9, x10
     498:      	b.hs	0xf08 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf08>
     49c:      	adr	x13, 0x4ac <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x4ac>
     4a0:      	ldrsw	x14, [x13, x9, lsl #2]
     4a4:      	add	x13, x13, x14
     4a8:      	br	x13
     4ac:      	udf	#0x58
     4b0:      	udf	#0xbc
     4b4:      	udf	#0x130
     4b8:      	udf	#0x1a0
     4bc:      	udf	#0x1ec
     4c0:      	udf	#0x25c
     4c4:      	udf	#0x2c0
     4c8:      	udf	#0x308
     4cc:      	udf	#0x36c
     4d0:      	udf	#0x3d0
     4d4:      	udf	#0x450
     4d8:      	udf	#0x4c4
     4dc:      	udf	#0x528
     4e0:      	udf	#0x59c
     4e4:      	udf	#0x618
     4e8:      	udf	#0x68c
     4ec:      	udf	#0x708
     4f0:      	udf	#0x77c
     4f4:      	udf	#0x7e0
     4f8:      	udf	#0x854
     4fc:      	udf	#0x8d0
     500:      	udf	#0x944
     504:      	ldr	x9, [x0, #0x58]
     508:      	cmp	x9, #0x0
     50c:      	b.ne	0x528 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x528>
     510:      	mov	w9, #0x0                // =0
     514:      	str	x9, [x0, #0x38]
     518:      	mov	w9, #0x0                // =0
     51c:      	str	x9, [x0, #0x70]
     520:      	mov	w0, #0x6                // =6
     524:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     528:      	sub	x9, x9, #0x1
     52c:      	str	x9, [x0, #0x58]
     530:      	ldr	x9, [x0, #0x88]
     534:      	cmp	x9, #0x0
     538:      	b.eq	0x568 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x568>
     53c:      	mov	w9, #0x25               // =37
     540:      	str	x9, [x0, #0x40]
     544:      	ldr	x9, [x0, #0x50]
     548:      	cmp	x9, #0x0
     54c:      	b.ne	0x560 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x560>
     550:      	mov	w9, #0x0                // =0
     554:      	str	x9, [x0, #0x38]
     558:      	mov	w0, #0x7                // =7
     55c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     560:      	sub	x9, x9, #0x1
     564:      	str	x9, [x0, #0x50]
     568:      	ldr	x9, [x0, #0x58]
     56c:      	cmp	x9, #0x0
     570:      	b.ne	0x58c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x58c>
     574:      	mov	w9, #0x1                // =1
     578:      	str	x9, [x0, #0x38]
     57c:      	mov	w9, #0x0                // =0
     580:      	str	x9, [x0, #0x70]
     584:      	mov	w0, #0x6                // =6
     588:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     58c:      	sub	x9, x9, #0x1
     590:      	str	x9, [x0, #0x58]
     594:      	ldr	x9, [x0, #0x88]
     598:      	cmp	x9, #0x0
     59c:      	b.eq	0x5cc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x5cc>
     5a0:      	mov	w9, #0x27               // =39
     5a4:      	str	x9, [x0, #0x40]
     5a8:      	ldr	x9, [x0, #0x50]
     5ac:      	cmp	x9, #0x0
     5b0:      	b.ne	0x5c4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x5c4>
     5b4:      	mov	w9, #0x1                // =1
     5b8:      	str	x9, [x0, #0x38]
     5bc:      	mov	w0, #0x7                // =7
     5c0:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     5c4:      	sub	x9, x9, #0x1
     5c8:      	str	x9, [x0, #0x50]
     5cc:      	ldr	x9, [x12, #0x10]
     5d0:      	ldr	x10, [x12, #0x18]
     5d4:      	str	x9, [x12, #0x30]
     5d8:      	str	x10, [x12, #0x38]
     5dc:      	ldr	x9, [x0, #0x58]
     5e0:      	cmp	x9, #0x0
     5e4:      	b.ne	0x600 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x600>
     5e8:      	mov	w9, #0x2                // =2
     5ec:      	str	x9, [x0, #0x38]
     5f0:      	mov	w9, #0x0                // =0
     5f4:      	str	x9, [x0, #0x70]
     5f8:      	mov	w0, #0x6                // =6
     5fc:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     600:      	sub	x9, x9, #0x1
     604:      	str	x9, [x0, #0x58]
     608:      	ldr	x9, [x0, #0x90]
     60c:      	cbnz	x9, 0xe60 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xe60>
     610:      	ldr	x9, [x0, #0x88]
     614:      	cmp	x9, #0x0
     618:      	b.eq	0x648 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x648>
     61c:      	mov	w9, #0x29               // =41
     620:      	str	x9, [x0, #0x40]
     624:      	ldr	x9, [x0, #0x50]
     628:      	cmp	x9, #0x0
     62c:      	b.ne	0x640 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x640>
     630:      	mov	w9, #0x2                // =2
     634:      	str	x9, [x0, #0x38]
     638:      	mov	w0, #0x7                // =7
     63c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     640:      	sub	x9, x9, #0x1
     644:      	str	x9, [x0, #0x50]
     648:      	b	0x698 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x698>
     64c:      	ldr	x9, [x0, #0x58]
     650:      	cmp	x9, #0x0
     654:      	b.ne	0x670 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x670>
     658:      	mov	w9, #0x3                // =3
     65c:      	str	x9, [x0, #0x38]
     660:      	mov	w9, #0x0                // =0
     664:      	str	x9, [x0, #0x70]
     668:      	mov	w0, #0x6                // =6
     66c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     670:      	sub	x9, x9, #0x1
     674:      	str	x9, [x0, #0x58]
     678:      	ldr	x9, [x0, #0x90]
     67c:      	cbnz	x9, 0xe7c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xe7c>
     680:      	mov	w9, #0x3                // =3
     684:      	str	x9, [x0, #0x38]
     688:      	mov	w9, #0x3                // =3
     68c:      	str	x9, [x0, #0x70]
     690:      	mov	w0, #0x1                // =1
     694:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     698:      	ldr	x9, [x0, #0x58]
     69c:      	cmp	x9, #0x0
     6a0:      	b.ne	0x6bc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x6bc>
     6a4:      	mov	w9, #0x4                // =4
     6a8:      	str	x9, [x0, #0x38]
     6ac:      	mov	w9, #0x0                // =0
     6b0:      	str	x9, [x0, #0x70]
     6b4:      	mov	w0, #0x6                // =6
     6b8:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     6bc:      	sub	x9, x9, #0x1
     6c0:      	str	x9, [x0, #0x58]
     6c4:      	ldr	x9, [x0, #0x90]
     6c8:      	cbnz	x9, 0xe98 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xe98>
     6cc:      	ldr	x9, [x0, #0x88]
     6d0:      	cmp	x9, #0x0
     6d4:      	b.eq	0x704 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x704>
     6d8:      	mov	w9, #0x2b               // =43
     6dc:      	str	x9, [x0, #0x40]
     6e0:      	ldr	x9, [x0, #0x50]
     6e4:      	cmp	x9, #0x0
     6e8:      	b.ne	0x6fc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x6fc>
     6ec:      	mov	w9, #0x4                // =4
     6f0:      	str	x9, [x0, #0x38]
     6f4:      	mov	w0, #0x7                // =7
     6f8:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     6fc:      	sub	x9, x9, #0x1
     700:      	str	x9, [x0, #0x50]
     704:      	b	0x7b4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x7b4>
     708:      	ldr	x9, [x0, #0x58]
     70c:      	cmp	x9, #0x0
     710:      	b.ne	0x72c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x72c>
     714:      	mov	w9, #0x5                // =5
     718:      	str	x9, [x0, #0x38]
     71c:      	mov	w9, #0x0                // =0
     720:      	str	x9, [x0, #0x70]
     724:      	mov	w0, #0x6                // =6
     728:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     72c:      	sub	x9, x9, #0x1
     730:      	str	x9, [x0, #0x58]
     734:      	ldr	x9, [x0, #0x88]
     738:      	cmp	x9, #0x0
     73c:      	b.eq	0x76c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x76c>
     740:      	mov	w9, #0x49               // =73
     744:      	str	x9, [x0, #0x40]
     748:      	ldr	x9, [x0, #0x50]
     74c:      	cmp	x9, #0x0
     750:      	b.ne	0x764 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x764>
     754:      	mov	w9, #0x5                // =5
     758:      	str	x9, [x0, #0x38]
     75c:      	mov	w0, #0x7                // =7
     760:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     764:      	sub	x9, x9, #0x1
     768:      	str	x9, [x0, #0x50]
     76c:      	ldr	x9, [x0, #0x58]
     770:      	cmp	x9, #0x0
     774:      	b.ne	0x790 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x790>
     778:      	mov	w9, #0x6                // =6
     77c:      	str	x9, [x0, #0x38]
     780:      	mov	w9, #0x0                // =0
     784:      	str	x9, [x0, #0x70]
     788:      	mov	w0, #0x6                // =6
     78c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     790:      	sub	x9, x9, #0x1
     794:      	str	x9, [x0, #0x58]
     798:      	ldr	x9, [x0, #0x90]
     79c:      	cbnz	x9, 0xeb4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xeb4>
     7a0:      	ldr	x9, [x12, #0x30]
     7a4:      	ldr	x10, [x12, #0x38]
     7a8:      	str	x9, [x12, #0x40]
     7ac:      	str	x10, [x12, #0x48]
     7b0:      	b	0x64c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x64c>
     7b4:      	ldr	x9, [x0, #0x58]
     7b8:      	cmp	x9, #0x0
     7bc:      	b.ne	0x7d8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x7d8>
     7c0:      	mov	w9, #0x7                // =7
     7c4:      	str	x9, [x0, #0x38]
     7c8:      	mov	w9, #0x0                // =0
     7cc:      	str	x9, [x0, #0x70]
     7d0:      	mov	w0, #0x6                // =6
     7d4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     7d8:      	sub	x9, x9, #0x1
     7dc:      	str	x9, [x0, #0x58]
     7e0:      	ldr	x9, [x0, #0x88]
     7e4:      	cmp	x9, #0x0
     7e8:      	b.eq	0x818 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x818>
     7ec:      	mov	w9, #0x2d               // =45
     7f0:      	str	x9, [x0, #0x40]
     7f4:      	ldr	x9, [x0, #0x50]
     7f8:      	cmp	x9, #0x0
     7fc:      	b.ne	0x810 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x810>
     800:      	mov	w9, #0x7                // =7
     804:      	str	x9, [x0, #0x38]
     808:      	mov	w0, #0x7                // =7
     80c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     810:      	sub	x9, x9, #0x1
     814:      	str	x9, [x0, #0x50]
     818:      	ldr	x9, [x0, #0x58]
     81c:      	cmp	x9, #0x0
     820:      	b.ne	0x83c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x83c>
     824:      	mov	w9, #0x8                // =8
     828:      	str	x9, [x0, #0x38]
     82c:      	mov	w9, #0x0                // =0
     830:      	str	x9, [x0, #0x70]
     834:      	mov	w0, #0x6                // =6
     838:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     83c:      	sub	x9, x9, #0x1
     840:      	str	x9, [x0, #0x58]
     844:      	ldr	x9, [x0, #0x88]
     848:      	cmp	x9, #0x0
     84c:      	b.eq	0x87c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x87c>
     850:      	mov	w9, #0x2f               // =47
     854:      	str	x9, [x0, #0x40]
     858:      	ldr	x9, [x0, #0x50]
     85c:      	cmp	x9, #0x0
     860:      	b.ne	0x874 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x874>
     864:      	mov	w9, #0x8                // =8
     868:      	str	x9, [x0, #0x38]
     86c:      	mov	w0, #0x7                // =7
     870:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     874:      	sub	x9, x9, #0x1
     878:      	str	x9, [x0, #0x50]
     87c:      	ldr	x9, [x0, #0x58]
     880:      	cmp	x9, #0x0
     884:      	b.ne	0x8a0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x8a0>
     888:      	mov	w9, #0x9                // =9
     88c:      	str	x9, [x0, #0x38]
     890:      	mov	w9, #0x0                // =0
     894:      	str	x9, [x0, #0x70]
     898:      	mov	w0, #0x6                // =6
     89c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     8a0:      	sub	x9, x9, #0x1
     8a4:      	str	x9, [x0, #0x58]
     8a8:      	ldr	x9, [x0, #0x88]
     8ac:      	cmp	x9, #0x0
     8b0:      	b.eq	0x8e0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x8e0>
     8b4:      	mov	w9, #0x31               // =49
     8b8:      	str	x9, [x0, #0x40]
     8bc:      	ldr	x9, [x0, #0x50]
     8c0:      	cmp	x9, #0x0
     8c4:      	b.ne	0x8d8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x8d8>
     8c8:      	mov	w9, #0x9                // =9
     8cc:      	str	x9, [x0, #0x38]
     8d0:      	mov	w0, #0x7                // =7
     8d4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     8d8:      	sub	x9, x9, #0x1
     8dc:      	str	x9, [x0, #0x50]
     8e0:      	ldr	w9, [x12, #0x20]
     8e4:      	ldr	w10, [x12]
     8e8:      	cmp	w9, w10
     8ec:      	cset	w9, hs
     8f0:      	str	x9, [x12, #0x50]
     8f4:      	mov	w9, #0x0                // =0
     8f8:      	str	x9, [x12, #0x58]
     8fc:      	ldr	x9, [x0, #0x58]
     900:      	cmp	x9, #0x0
     904:      	b.ne	0x920 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x920>
     908:      	mov	w9, #0xa                // =10
     90c:      	str	x9, [x0, #0x38]
     910:      	mov	w9, #0x0                // =0
     914:      	str	x9, [x0, #0x70]
     918:      	mov	w0, #0x6                // =6
     91c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     920:      	sub	x9, x9, #0x1
     924:      	str	x9, [x0, #0x58]
     928:      	ldr	x9, [x0, #0x90]
     92c:      	cbnz	x9, 0xed0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xed0>
     930:      	ldr	x9, [x0, #0x88]
     934:      	cmp	x9, #0x0
     938:      	b.eq	0x968 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x968>
     93c:      	mov	w9, #0x32               // =50
     940:      	str	x9, [x0, #0x40]
     944:      	ldr	x9, [x0, #0x50]
     948:      	cmp	x9, #0x0
     94c:      	b.ne	0x960 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x960>
     950:      	mov	w9, #0xa                // =10
     954:      	str	x9, [x0, #0x38]
     958:      	mov	w0, #0x7                // =7
     95c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     960:      	sub	x9, x9, #0x1
     964:      	str	x9, [x0, #0x50]
     968:      	ldr	w9, [x12, #0x50]
     96c:      	cbnz	w9, 0x708 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x708>
     970:      	ldr	x9, [x0, #0x58]
     974:      	cmp	x9, #0x0
     978:      	b.ne	0x994 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x994>
     97c:      	mov	w9, #0xb                // =11
     980:      	str	x9, [x0, #0x38]
     984:      	mov	w9, #0x0                // =0
     988:      	str	x9, [x0, #0x70]
     98c:      	mov	w0, #0x6                // =6
     990:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     994:      	sub	x9, x9, #0x1
     998:      	str	x9, [x0, #0x58]
     99c:      	ldr	x9, [x0, #0x88]
     9a0:      	cmp	x9, #0x0
     9a4:      	b.eq	0x9d4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x9d4>
     9a8:      	mov	w9, #0x34               // =52
     9ac:      	str	x9, [x0, #0x40]
     9b0:      	ldr	x9, [x0, #0x50]
     9b4:      	cmp	x9, #0x0
     9b8:      	b.ne	0x9cc <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x9cc>
     9bc:      	mov	w9, #0xb                // =11
     9c0:      	str	x9, [x0, #0x38]
     9c4:      	mov	w0, #0x7                // =7
     9c8:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     9cc:      	sub	x9, x9, #0x1
     9d0:      	str	x9, [x0, #0x50]
     9d4:      	ldr	x9, [x0, #0x58]
     9d8:      	cmp	x9, #0x0
     9dc:      	b.ne	0x9f8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x9f8>
     9e0:      	mov	w9, #0xc                // =12
     9e4:      	str	x9, [x0, #0x38]
     9e8:      	mov	w9, #0x0                // =0
     9ec:      	str	x9, [x0, #0x70]
     9f0:      	mov	w0, #0x6                // =6
     9f4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     9f8:      	sub	x9, x9, #0x1
     9fc:      	str	x9, [x0, #0x58]
     a00:      	ldr	x9, [x0, #0x88]
     a04:      	cmp	x9, #0x0
     a08:      	b.eq	0xa38 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xa38>
     a0c:      	mov	w9, #0x36               // =54
     a10:      	str	x9, [x0, #0x40]
     a14:      	ldr	x9, [x0, #0x50]
     a18:      	cmp	x9, #0x0
     a1c:      	b.ne	0xa30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xa30>
     a20:      	mov	w9, #0xc                // =12
     a24:      	str	x9, [x0, #0x38]
     a28:      	mov	w0, #0x7                // =7
     a2c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     a30:      	sub	x9, x9, #0x1
     a34:      	str	x9, [x0, #0x50]
     a38:      	mov	w9, #0x11               // =17
     a3c:      	str	x9, [x12, #0x50]
     a40:      	mov	w9, #0x0                // =0
     a44:      	str	x9, [x12, #0x58]
     a48:      	ldr	x9, [x0, #0x58]
     a4c:      	cmp	x9, #0x0
     a50:      	b.ne	0xa6c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xa6c>
     a54:      	mov	w9, #0xd                // =13
     a58:      	str	x9, [x0, #0x38]
     a5c:      	mov	w9, #0x0                // =0
     a60:      	str	x9, [x0, #0x70]
     a64:      	mov	w0, #0x6                // =6
     a68:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     a6c:      	sub	x9, x9, #0x1
     a70:      	str	x9, [x0, #0x58]
     a74:      	ldr	x9, [x0, #0x88]
     a78:      	cmp	x9, #0x0
     a7c:      	b.eq	0xaac <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xaac>
     a80:      	mov	w9, #0x38               // =56
     a84:      	str	x9, [x0, #0x40]
     a88:      	ldr	x9, [x0, #0x50]
     a8c:      	cmp	x9, #0x0
     a90:      	b.ne	0xaa4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xaa4>
     a94:      	mov	w9, #0xd                // =13
     a98:      	str	x9, [x0, #0x38]
     a9c:      	mov	w0, #0x7                // =7
     aa0:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     aa4:      	sub	x9, x9, #0x1
     aa8:      	str	x9, [x0, #0x50]
     aac:      	ldr	w9, [x12, #0x30]
     ab0:      	ldr	w10, [x12, #0x50]
     ab4:      	mul	w9, w9, w10
     ab8:      	str	x9, [x12, #0x50]
     abc:      	mov	w9, #0x0                // =0
     ac0:      	str	x9, [x12, #0x58]
     ac4:      	ldr	x9, [x0, #0x58]
     ac8:      	cmp	x9, #0x0
     acc:      	b.ne	0xae8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xae8>
     ad0:      	mov	w9, #0xe                // =14
     ad4:      	str	x9, [x0, #0x38]
     ad8:      	mov	w9, #0x0                // =0
     adc:      	str	x9, [x0, #0x70]
     ae0:      	mov	w0, #0x6                // =6
     ae4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     ae8:      	sub	x9, x9, #0x1
     aec:      	str	x9, [x0, #0x58]
     af0:      	ldr	x9, [x0, #0x88]
     af4:      	cmp	x9, #0x0
     af8:      	b.eq	0xb28 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xb28>
     afc:      	mov	w9, #0x39               // =57
     b00:      	str	x9, [x0, #0x40]
     b04:      	ldr	x9, [x0, #0x50]
     b08:      	cmp	x9, #0x0
     b0c:      	b.ne	0xb20 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xb20>
     b10:      	mov	w9, #0xe                // =14
     b14:      	str	x9, [x0, #0x38]
     b18:      	mov	w0, #0x7                // =7
     b1c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     b20:      	sub	x9, x9, #0x1
     b24:      	str	x9, [x0, #0x50]
     b28:      	mov	w9, #0x5                // =5
     b2c:      	str	x9, [x12, #0x60]
     b30:      	mov	w9, #0x0                // =0
     b34:      	str	x9, [x12, #0x68]
     b38:      	ldr	x9, [x0, #0x58]
     b3c:      	cmp	x9, #0x0
     b40:      	b.ne	0xb5c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xb5c>
     b44:      	mov	w9, #0xf                // =15
     b48:      	str	x9, [x0, #0x38]
     b4c:      	mov	w9, #0x0                // =0
     b50:      	str	x9, [x0, #0x70]
     b54:      	mov	w0, #0x6                // =6
     b58:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     b5c:      	sub	x9, x9, #0x1
     b60:      	str	x9, [x0, #0x58]
     b64:      	ldr	x9, [x0, #0x88]
     b68:      	cmp	x9, #0x0
     b6c:      	b.eq	0xb9c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xb9c>
     b70:      	mov	w9, #0x3b               // =59
     b74:      	str	x9, [x0, #0x40]
     b78:      	ldr	x9, [x0, #0x50]
     b7c:      	cmp	x9, #0x0
     b80:      	b.ne	0xb94 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xb94>
     b84:      	mov	w9, #0xf                // =15
     b88:      	str	x9, [x0, #0x38]
     b8c:      	mov	w0, #0x7                // =7
     b90:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     b94:      	sub	x9, x9, #0x1
     b98:      	str	x9, [x0, #0x50]
     b9c:      	ldr	w9, [x12, #0x50]
     ba0:      	ldr	w10, [x12, #0x60]
     ba4:      	add	w9, w9, w10
     ba8:      	str	x9, [x12, #0x50]
     bac:      	mov	w9, #0x0                // =0
     bb0:      	str	x9, [x12, #0x58]
     bb4:      	ldr	x9, [x0, #0x58]
     bb8:      	cmp	x9, #0x0
     bbc:      	b.ne	0xbd8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xbd8>
     bc0:      	mov	w9, #0x10               // =16
     bc4:      	str	x9, [x0, #0x38]
     bc8:      	mov	w9, #0x0                // =0
     bcc:      	str	x9, [x0, #0x70]
     bd0:      	mov	w0, #0x6                // =6
     bd4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     bd8:      	sub	x9, x9, #0x1
     bdc:      	str	x9, [x0, #0x58]
     be0:      	ldr	x9, [x0, #0x88]
     be4:      	cmp	x9, #0x0
     be8:      	b.eq	0xc18 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xc18>
     bec:      	mov	w9, #0x3c               // =60
     bf0:      	str	x9, [x0, #0x40]
     bf4:      	ldr	x9, [x0, #0x50]
     bf8:      	cmp	x9, #0x0
     bfc:      	b.ne	0xc10 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xc10>
     c00:      	mov	w9, #0x10               // =16
     c04:      	str	x9, [x0, #0x38]
     c08:      	mov	w0, #0x7                // =7
     c0c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     c10:      	sub	x9, x9, #0x1
     c14:      	str	x9, [x0, #0x50]
     c18:      	ldr	x9, [x12, #0x50]
     c1c:      	ldr	x10, [x12, #0x58]
     c20:      	str	x9, [x12, #0x30]
     c24:      	str	x10, [x12, #0x38]
     c28:      	ldr	x9, [x0, #0x58]
     c2c:      	cmp	x9, #0x0
     c30:      	b.ne	0xc4c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xc4c>
     c34:      	mov	w9, #0x11               // =17
     c38:      	str	x9, [x0, #0x38]
     c3c:      	mov	w9, #0x0                // =0
     c40:      	str	x9, [x0, #0x70]
     c44:      	mov	w0, #0x6                // =6
     c48:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     c4c:      	sub	x9, x9, #0x1
     c50:      	str	x9, [x0, #0x58]
     c54:      	ldr	x9, [x0, #0x88]
     c58:      	cmp	x9, #0x0
     c5c:      	b.eq	0xc8c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xc8c>
     c60:      	mov	w9, #0x3e               // =62
     c64:      	str	x9, [x0, #0x40]
     c68:      	ldr	x9, [x0, #0x50]
     c6c:      	cmp	x9, #0x0
     c70:      	b.ne	0xc84 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xc84>
     c74:      	mov	w9, #0x11               // =17
     c78:      	str	x9, [x0, #0x38]
     c7c:      	mov	w0, #0x7                // =7
     c80:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     c84:      	sub	x9, x9, #0x1
     c88:      	str	x9, [x0, #0x50]
     c8c:      	ldr	x9, [x0, #0x58]
     c90:      	cmp	x9, #0x0
     c94:      	b.ne	0xcb0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xcb0>
     c98:      	mov	w9, #0x12               // =18
     c9c:      	str	x9, [x0, #0x38]
     ca0:      	mov	w9, #0x0                // =0
     ca4:      	str	x9, [x0, #0x70]
     ca8:      	mov	w0, #0x6                // =6
     cac:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     cb0:      	sub	x9, x9, #0x1
     cb4:      	str	x9, [x0, #0x58]
     cb8:      	ldr	x9, [x0, #0x88]
     cbc:      	cmp	x9, #0x0
     cc0:      	b.eq	0xcf0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xcf0>
     cc4:      	mov	w9, #0x40               // =64
     cc8:      	str	x9, [x0, #0x40]
     ccc:      	ldr	x9, [x0, #0x50]
     cd0:      	cmp	x9, #0x0
     cd4:      	b.ne	0xce8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xce8>
     cd8:      	mov	w9, #0x12               // =18
     cdc:      	str	x9, [x0, #0x38]
     ce0:      	mov	w0, #0x7                // =7
     ce4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     ce8:      	sub	x9, x9, #0x1
     cec:      	str	x9, [x0, #0x50]
     cf0:      	mov	w9, #0x1                // =1
     cf4:      	str	x9, [x12, #0x50]
     cf8:      	mov	w9, #0x0                // =0
     cfc:      	str	x9, [x12, #0x58]
     d00:      	ldr	x9, [x0, #0x58]
     d04:      	cmp	x9, #0x0
     d08:      	b.ne	0xd24 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xd24>
     d0c:      	mov	w9, #0x13               // =19
     d10:      	str	x9, [x0, #0x38]
     d14:      	mov	w9, #0x0                // =0
     d18:      	str	x9, [x0, #0x70]
     d1c:      	mov	w0, #0x6                // =6
     d20:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     d24:      	sub	x9, x9, #0x1
     d28:      	str	x9, [x0, #0x58]
     d2c:      	ldr	x9, [x0, #0x88]
     d30:      	cmp	x9, #0x0
     d34:      	b.eq	0xd64 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xd64>
     d38:      	mov	w9, #0x42               // =66
     d3c:      	str	x9, [x0, #0x40]
     d40:      	ldr	x9, [x0, #0x50]
     d44:      	cmp	x9, #0x0
     d48:      	b.ne	0xd5c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xd5c>
     d4c:      	mov	w9, #0x13               // =19
     d50:      	str	x9, [x0, #0x38]
     d54:      	mov	w0, #0x7                // =7
     d58:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     d5c:      	sub	x9, x9, #0x1
     d60:      	str	x9, [x0, #0x50]
     d64:      	ldr	w9, [x12, #0x20]
     d68:      	ldr	w10, [x12, #0x50]
     d6c:      	add	w9, w9, w10
     d70:      	str	x9, [x12, #0x50]
     d74:      	mov	w9, #0x0                // =0
     d78:      	str	x9, [x12, #0x58]
     d7c:      	ldr	x9, [x0, #0x58]
     d80:      	cmp	x9, #0x0
     d84:      	b.ne	0xda0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xda0>
     d88:      	mov	w9, #0x14               // =20
     d8c:      	str	x9, [x0, #0x38]
     d90:      	mov	w9, #0x0                // =0
     d94:      	str	x9, [x0, #0x70]
     d98:      	mov	w0, #0x6                // =6
     d9c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     da0:      	sub	x9, x9, #0x1
     da4:      	str	x9, [x0, #0x58]
     da8:      	ldr	x9, [x0, #0x88]
     dac:      	cmp	x9, #0x0
     db0:      	b.eq	0xde0 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xde0>
     db4:      	mov	w9, #0x43               // =67
     db8:      	str	x9, [x0, #0x40]
     dbc:      	ldr	x9, [x0, #0x50]
     dc0:      	cmp	x9, #0x0
     dc4:      	b.ne	0xdd8 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xdd8>
     dc8:      	mov	w9, #0x14               // =20
     dcc:      	str	x9, [x0, #0x38]
     dd0:      	mov	w0, #0x7                // =7
     dd4:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     dd8:      	sub	x9, x9, #0x1
     ddc:      	str	x9, [x0, #0x50]
     de0:      	ldr	x9, [x12, #0x50]
     de4:      	ldr	x10, [x12, #0x58]
     de8:      	str	x9, [x12, #0x20]
     dec:      	str	x10, [x12, #0x28]
     df0:      	ldr	x9, [x0, #0x58]
     df4:      	cmp	x9, #0x0
     df8:      	b.ne	0xe14 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xe14>
     dfc:      	mov	w9, #0x15               // =21
     e00:      	str	x9, [x0, #0x38]
     e04:      	mov	w9, #0x0                // =0
     e08:      	str	x9, [x0, #0x70]
     e0c:      	mov	w0, #0x6                // =6
     e10:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     e14:      	sub	x9, x9, #0x1
     e18:      	str	x9, [x0, #0x58]
     e1c:      	ldr	x9, [x0, #0x90]
     e20:      	cbnz	x9, 0xeec <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xeec>
     e24:      	ldr	x9, [x0, #0x88]
     e28:      	cmp	x9, #0x0
     e2c:      	b.eq	0xe5c <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xe5c>
     e30:      	mov	w9, #0x45               // =69
     e34:      	str	x9, [x0, #0x40]
     e38:      	ldr	x9, [x0, #0x50]
     e3c:      	cmp	x9, #0x0
     e40:      	b.ne	0xe54 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xe54>
     e44:      	mov	w9, #0x15               // =21
     e48:      	str	x9, [x0, #0x38]
     e4c:      	mov	w0, #0x7                // =7
     e50:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     e54:      	sub	x9, x9, #0x1
     e58:      	str	x9, [x0, #0x50]
     e5c:      	b	0x7b4 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0x7b4>
     e60:      	dmb	ishld
     e64:      	mov	w9, #0x2                // =2
     e68:      	str	x9, [x0, #0x38]
     e6c:      	mov	w9, #0x0                // =0
     e70:      	str	x9, [x0, #0x70]
     e74:      	mov	w0, #0x6                // =6
     e78:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     e7c:      	dmb	ishld
     e80:      	mov	w9, #0x3                // =3
     e84:      	str	x9, [x0, #0x38]
     e88:      	mov	w9, #0x0                // =0
     e8c:      	str	x9, [x0, #0x70]
     e90:      	mov	w0, #0x6                // =6
     e94:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     e98:      	dmb	ishld
     e9c:      	mov	w9, #0x4                // =4
     ea0:      	str	x9, [x0, #0x38]
     ea4:      	mov	w9, #0x0                // =0
     ea8:      	str	x9, [x0, #0x70]
     eac:      	mov	w0, #0x6                // =6
     eb0:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     eb4:      	dmb	ishld
     eb8:      	mov	w9, #0x6                // =6
     ebc:      	str	x9, [x0, #0x38]
     ec0:      	mov	w9, #0x0                // =0
     ec4:      	str	x9, [x0, #0x70]
     ec8:      	mov	w0, #0x6                // =6
     ecc:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     ed0:      	dmb	ishld
     ed4:      	mov	w9, #0xa                // =10
     ed8:      	str	x9, [x0, #0x38]
     edc:      	mov	w9, #0x0                // =0
     ee0:      	str	x9, [x0, #0x70]
     ee4:      	mov	w0, #0x6                // =6
     ee8:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     eec:      	dmb	ishld
     ef0:      	mov	w9, #0x15               // =21
     ef4:      	str	x9, [x0, #0x38]
     ef8:      	mov	w9, #0x0                // =0
     efc:      	str	x9, [x0, #0x70]
     f00:      	mov	w0, #0x6                // =6
     f04:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     f08:      	mov	w0, #0xb                // =11
     f0c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     f10:      	mov	w9, #0x7                // =7
     f14:      	str	x9, [x0, #0x70]
     f18:      	mov	w0, #0x2                // =2
     f1c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     f20:      	mov	w9, #0x6                // =6
     f24:      	str	x9, [x0, #0x70]
     f28:      	mov	w0, #0x2                // =2
     f2c:      	b	0xf30 <_binary__Users_lijie_source_goplus_wasmvm_artifacts_p3_mechanism_costs_20261116_allocation_stacks_core_loop_wasmvm_2274881109_bin_start+0xf30>
     f30:      	ldp	q14, q15, [sp], #0x20
     f34:      	ldp	q12, q13, [sp], #0x20
     f38:      	ldp	q10, q11, [sp], #0x20
     f3c:      	ldp	q8, q9, [sp], #0x20
     f40:      	ldp	x27, x28, [sp], #0x10
     f44:      	ldp	x25, x26, [sp], #0x10
     f48:      	ldp	x23, x24, [sp], #0x10
     f4c:      	ldp	x21, x22, [sp], #0x10
     f50:      	ldp	x19, x20, [sp], #0x10
     f54:      	ldp	x29, x30, [sp], #0x10
     f58:      	ret
