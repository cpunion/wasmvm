package main
import("fmt";"runtime")
type Scalar func(uint64) uint64
var callback any = Scalar(step)
var interrupted uint64
var sink uint64
//go:noinline
func step(x uint64)uint64{return x*17+5}
//go:noinline
func direct(x uint64)uint64{return step(x)}
//go:noinline
func asserted(x uint64)uint64{f,ok:=callback.(Scalar);if !ok{panic("type")};return f(x)}
//go:noinline
func mutableDefer(x uint64)uint64{panicked:=true;defer func(){if panicked{interrupted++}}();r:=step(x);panicked=false;return r}
func measure(name string,f Scalar){var a,b runtime.MemStats;runtime.ReadMemStats(&a);x:=uint64(7);for i:=0;i<100000;i++{x=f(x)};runtime.ReadMemStats(&b);sink=x;fmt.Printf("%s result=%d mallocs=%d\n",name,x,b.Mallocs-a.Mallocs)}
func main(){measure("direct",direct);measure("asserted",asserted);measure("mutable-defer",mutableDefer)}
