package nativeexec

import (
	"context"
"reflect"
componentdecode "github.com/cpunion/wasmvm/internal/component/decode"
"github.com/cpunion/wasmvm/internal/component/model"
"os"
"github.com/cpunion/wasmvm/internal/core/decode"
"time"
	"errors"
	"runtime"
	"testing"

	"github.com/cpunion/wasmvm/internal/compiler/codegen"
	"github.com/cpunion/wasmvm/internal/compiler/ir"
	"github.com/cpunion/wasmvm/internal/compiler/lower"
	"github.com/cpunion/wasmvm/internal/compiler/slots"
	"github.com/cpunion/wasmvm/internal/core/module"
	"github.com/cpunion/wasmvm/internal/core/validate"
	"github.com/cpunion/wasmvm/internal/engine/state"
	"github.com/cpunion/wasmvm/internal/platform/native"
	"github.com/cpunion/wasmvm/pkg/wasm"
)

func fixture(t *testing.T, largeEdge bool) *slots.Module {
	t.Helper()
	d := &module.Module{Types: []module.FuncType{{Results: []wasm.ValueType{wasm.I32}}}, Functions: []module.Function{{Body: module.Expr{{Op: 0x41, Bits: 42}, {Op: 0xb}}}}}
	v, err := validate.Check(d, validate.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	i, err := lower.Compile(v, lower.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	m, err := slots.Compile(i, slots.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	if largeEdge {
		f := &slots.Function{Slots: []wasm.ValueType{wasm.I32, wasm.I32}, Args: []slots.Slot{1}, Sources: []ir.Source{{Wasm: module.Instr{Op: 0x41, Bits: 42}}},
			Code: []slots.Instruction{
				{Op: 0x41, Dst: 0, A: slots.NoSlot, B: slots.NoSlot, C: slots.NoSlot},
				{Op: slots.ControlBase + uint32(ir.Jump), Dst: slots.NoSlot, A: slots.NoSlot, B: slots.NoSlot, C: slots.NoSlot, Count: 1},
				{Op: slots.ControlBase + uint32(ir.Return), Dst: slots.NoSlot, A: slots.NoSlot, B: slots.NoSlot, C: slots.NoSlot, Count: 1},
			}, Edges: []slots.Edge{{PC: 2, Count: 300}}}
		for range 300 {
			f.Moves = append(f.Moves, slots.Move{Src: 0, Dst: 1})
		}
		m.Functions[0] = f
	}
	return m
}

func TestExpandedEntrySelectionAndAggregateBudget(t *testing.T) {
	if !native.Available {
		t.Skip("native platform unavailable")
	}
	d := &module.Module{Types: []module.FuncType{{Results: []wasm.ValueType{wasm.I32}}},
		Functions: []module.Function{
			{Body: module.Expr{{Op: 0x10, A: 1}, {Op: 0xb}}},
			{Body: module.Expr{{Op: 0x41, Bits: 42}, {Op: 0xb}}},
		}}
	v, err := validate.Check(d, validate.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	i, err := lower.Compile(v, lower.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	m, err := slots.Compile(i, slots.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	e, fn, lease := prepare(t, m)
	if !lease.entries[fn.Index-lease.first].hasExpansion {
		t.Fatalf("eligible leaf call was not expanded: caller=%+v callee=%+v", m.Functions[0], m.Functions[1])
	}
	returnPC := uint32(0)
	for pc, in := range fn.Code.Code {
		if in.Op == slots.ControlBase+uint32(ir.Return) {
			returnPC = uint32(pc)
			break
		}
	}
	for _, test := range []struct {
		frames, slots uint64
		metered       bool
		wantPC        uint32
	}{{2, 16, false, returnPC}, {1, 16, false, 0}, {2, 2, false, 0}, {2, 16, true, 0}} {
		for _, invocationLimits := range []bool{false, true} {
			e.maxFrames, e.maximum, e.metered = test.frames, test.slots*16, test.metered
			var pc uint32
			var fuel uint64
			var err error
			if invocationLimits {
				// The workspace can hold more than this invocation is allowed
				// to use. Expansion must obey the current shared stack budget.
				e.maxFrames, e.maximum = 64, 1024
				packet := state.NativeFrames{Function: fn, Depth: 1, Fuel: 10, Values: e.values,
					MaxFrames: uint32(test.frames), MaxSlots: uint32(test.slots)}
				err = e.RunFrames(&packet)
				pc, fuel = packet.PC, packet.Fuel
			} else {
				pc, fuel, err = e.Run(fn, 0, 1, 0, 10)
			}
			if err != nil || pc != test.wantPC {
				t.Fatal(test, invocationLimits, pc, err)
			}
			if !test.metered && fuel != 10 || test.metered && fuel != 9 {
				t.Fatal("fuel changed across tier selection", test, fuel)
			}
			if pc == returnPC {
				in := fn.Code.Code[pc]
				if e.values[fn.Code.Args[in.Extra]].Lo != 42 {
					t.Fatal(e.values)
				}
			}
		}
	}
	// The complete ordinary tiers must still fit when an optional expanded
	// copy would exceed the aggregate publication budget.
	limits := codegen.DefaultLimits()
	var ordinaryBytes uint64
	for _, f := range m.Functions {
		for _, unmetered := range []bool{true, false} {
			body, err := codegen.CompileFunctionWithConfig(runtime.GOARCH, f, limits, codegen.Config{Unmetered: unmetered})
			if err != nil {
				t.Fatal(err)
			}
			ordinaryBytes += uint64(len(body.Entry.Code))
		}
	}
	limits.MaxCodeBytes = ordinaryBytes
	compiled, err := Compile(context.Background(), m, limits)
	if err != nil {
		t.Fatal("optional expansion displaced an ordinary tier", err)
	}
	compiled.Close()
}

func prepare(t *testing.T, m *slots.Module) (*Execution, *state.Function, *Lease) {
	t.Helper()
	c, err := Compile(context.Background(), m, codegen.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	l, err := c.Acquire()
	if err != nil {
		t.Fatal(err)
	}
	c.Close()
	t.Cleanup(l.Close)
	s := state.NewNative(state.DefaultLimits())
	t.Cleanup(s.Close)
	in, err := s.Allocate(m, nil)
	if err != nil {
		t.Fatal(err)
	}
	f, _ := s.Function(in.Functions[0])
	e, err := New(context.Background(), map[*slots.Module]*Lease{m: l}, 16, 2, false)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(e.Close)
	if _, err = e.Resize(len(f.Code.Slots), len(f.Code.Slots)); err != nil {
		t.Fatal(err)
	}
	return e, f, l
}

func TestNativeFrameGrowthAndLargeEdges(t *testing.T) {
	if !native.Available {
		t.Skip("native platform unavailable")
	}
	m := fixture(t, true)
	e, fn, _ := prepare(t, m)
	for _, capacity := range []int{2, 8, 16} {
		if _, err := e.Resize(2, capacity); err != nil {
			t.Fatal(err)
		}
		pc, _, err := e.Run(fn, 0, 1, 0, 0)
		if err != nil || pc != 2 || e.values[1].Lo != 42 {
			t.Fatal(pc, e.values, err)
		}
	}
	for _, pair := range [][2]int{{-1, 1}, {2, 1}, {1, 17}} {
		if _, err := e.Resize(pair[0], pair[1]); !errors.Is(err, wasm.ErrLimit) {
			t.Fatal(err)
		}
	}
	e.Close()
	if _, err := e.Resize(1, 1); !errors.Is(err, native.ErrClosed) {
		t.Fatal(err)
	}
}

func TestNativeRejectsStaleOrMismatchedArtifacts(t *testing.T) {
	if !native.Available {
		t.Skip("native platform unavailable")
	}
	for _, kind := range []string{"module", "function", "function-index", "function-before-first", "lease", "arena", "frame", "pc", "exit", "edge", "go-memory", "retired-memory"} {
		t.Run(kind, func(t *testing.T) {
			m := fixture(t, true)
			e, fn, l := prepare(t, m)
			base, want := 0, error(wasm.ErrInvalid)
			switch kind {
			case "module":
				delete(e.modules, m)
				want = wasm.ErrUnsupported
			case "function":
				l.entries[fn.Index-l.first] = functionEntries{}
			case "function-index":
				fn.Index = ^uint32(0)
			case "function-before-first":
				l.first = fn.Index + 1
			case "lease":
				l.Close()
				want = native.ErrClosed
			case "arena":
				base = 3
				want = native.ErrLimit
			case "frame":
				base = 1
			case "pc":
				fn.Code.Code = fn.Code.Code[:1]
			case "exit":
				fn.Code.Code[2].Op = 0x41
			case "edge":
				fn.Code.Edges = nil
			case "go-memory", "retired-memory":
				s := state.New(state.DefaultLimits())
				if kind == "retired-memory" {
					s = state.NewNative(state.DefaultLimits())
				}
				defer s.Close()
				ex, err := s.NewMemory(module.Limits{Min: 1})
				if err != nil {
					t.Fatal(err)
				}
				fn.Instance.Memories = []*state.Memory{ex.Memory}
				if kind == "retired-memory" {
					ex.Memory.Native().Close()
					want = native.ErrClosed
				}
			}
			if _, _, err := e.Run(fn, base, 1, 0, 0); !errors.Is(err, want) {
				t.Fatal(err, want)
			}
		})
	}
}

func TestNativeCompileLimitsAndRetirement(t *testing.T) {
	m := fixture(t, false)
	if !native.Available {
		if _, err := Compile(context.Background(), m, codegen.DefaultLimits()); !errors.Is(err, wasm.ErrUnsupported) {
			t.Fatal(err)
		}
		if _, err := New(context.Background(), nil, 0, 0, false); !errors.Is(err, native.ErrUnavailable) {
			t.Fatal(err)
		}
		return
	}
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, err := Compile(ctx, m, codegen.DefaultLimits()); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	limits := codegen.DefaultLimits()
	limits.MaxCodeBytes = 0
	if _, err := Compile(context.Background(), m, limits); !errors.Is(err, wasm.ErrLimit) {
		t.Fatal(err)
	}
	c, err := Compile(context.Background(), m, codegen.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	c.Close()
	if _, err = c.Acquire(); !errors.Is(err, native.ErrClosed) {
		t.Fatal(err)
	}
}

func TestIndirectExpansionQuotasAndRuntimeView(t *testing.T) {
	if !native.Available {
		t.Skip("native platform unavailable")
	}
	typ := module.FuncType{Params: []wasm.ValueType{wasm.I32}, Results: []wasm.ValueType{wasm.I32}}
	d := &module.Module{Types: []module.FuncType{typ, typ},
		Tables: []module.TableType{{Element: wasm.FuncRef, Limits: module.Limits{Min: 1}}},
		Functions: []module.Function{
			{Body: module.Expr{{Op: 0x41, Bits: 42}, {Op: 0x20}, {Op: 0x11, A: 1}, {Op: 0xb}}},
			{Body: module.Expr{{Op: 0x20}, {Op: 0x41, Bits: 1}, {Op: 0x6a}, {Op: 0xb}}},
		}}
	v, err := validate.Check(d, validate.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	i, err := lower.Compile(v, lower.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	m, err := slots.Compile(i, slots.DefaultLimits())
	if err != nil {
		t.Fatal(err)
	}
	e, fn, lease := prepare(t, m)
	if !lease.entries[fn.Index-lease.first].usesRuntimeData {
		t.Fatal("canonical type alias not indexed")
	}
	fn.Instance.Tables[0].Values[0] = fn.Instance.Functions[1]
	for _, test := range []struct {
		frames, slots     uint64
		metered, expanded bool
	}{
		{2, 16, false, true}, {1, 16, false, false}, {2, uint64(len(fn.Code.Slots)), false, false}, {2, 16, true, false},
	} {
		e.maxFrames, e.maximum, e.metered = test.frames, test.slots*16, test.metered
		e.values[0].Lo = 0
		pc, _, err := e.Run(fn, 0, 1, 0, 20)
		if err != nil {
			t.Fatal(test, err)
		}
		if got := fn.Code.Code[pc].Op != 0x11; got != test.expanded {
			t.Fatal(test, pc)
		}
	}
	e.maxFrames, e.maximum, e.metered = 2, 16*16, false
	// Refresh a moved table and enlarge metadata when entering another instance.
	s := state.NewNative(state.DefaultLimits())
	defer s.Close()
	other, err := s.Allocate(m, nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, ok := s.GrowTable(other.Tables[0], 1, other.Functions[1]); !ok {
		t.Fatal("growth failed")
	}
	extra, err := s.NewTable(module.TableType{Element: wasm.FuncRef, Limits: module.Limits{Min: 1}})
	if err != nil {
		t.Fatal(err)
	}
	other.Tables = append(other.Tables, extra.Table)
	if _, err := e.bindRuntimeData(other); err != nil {
		t.Fatal(err)
	}
	if e.runtimeWords[2] != 2 || e.runtimeWords[3] != other.Tables[0].NativeAddress() {
		t.Fatal(e.runtimeWords)
	}
	// Returning to the smaller instance must replace identities and table pairs.
	if _, err := e.bindRuntimeData(fn.Instance); err != nil {
		t.Fatal(err)
	}
	if e.runtimeWords[2] != 1 || e.runtimeWords[3] != fn.Instance.Tables[0].NativeAddress() {
		t.Fatal(e.runtimeWords)
	}
	goStore := state.New(state.DefaultLimits())
	defer goStore.Close()
	goTable, _ := goStore.NewTable(module.TableType{Element: wasm.FuncRef, Limits: module.Limits{Min: 1}})
	fn.Instance.Tables[0] = goTable.Table
	if _, _, err := e.Run(fn, 0, 1, 0, 0); !errors.Is(err, wasm.ErrInvalid) {
		t.Fatal("Go storage entered native view", err)
	}
}

func TestDispatchSizeProbe(t *testing.T) {
 for _, count := range []int{16,64,128,256,512} {
  d := &module.Module{Types: []module.FuncType{{Results: []wasm.ValueType{wasm.I32}}}, Tables: []module.TableType{{Element: wasm.FuncRef, Limits: module.Limits{Min:1}}}}
  for i:=0;i<count;i++ {d.Functions=append(d.Functions,module.Function{Body:module.Expr{{Op:0x41},{Op:0x11},{Op:0xb}}})}
  m:=callSlots(t,d)
  start:=time.Now(); c,err:=Compile(context.Background(),m,codegen.DefaultLimits()); elapsed:=time.Since(start)
  if err!=nil {t.Fatal(err)}
  bytes:=reflect.ValueOf(c.code).Elem().FieldByName("size").Uint()
  t.Logf("count=%d bytes=%d compileNs=%d linked=%v",count,bytes,elapsed.Nanoseconds(),c.linked);c.Close()
 }
}

func TestRealDispatchSizeProbe(t *testing.T) {
 for _, path:= range []string{"../../../artifacts/preview1/fixtures/integration/go-guest.wasm"} {
  raw,err:=os.ReadFile(path); if err!=nil{t.Fatal(err)}
  d,err:=decode.DecodeWithFeatures(raw,decode.DefaultLimits(),wasm.SupportedFeatures);if err!=nil{t.Fatal(err)}
  m:=callSlots(t,d,wasm.SupportedFeatures)
  limits:=codegen.DefaultLimits();limits.MaxCodeBytes=512<<20
  start:=time.Now(); c,err:=compileModule(context.Background(),m,limits,true); elapsed:=time.Since(start); if err!=nil {t.Logf("linked compile error: %v after %d ns",err,elapsed.Nanoseconds());continue}
  bytes:=reflect.ValueOf(c.code).Elem().FieldByName("size").Uint()
  calls,callers:=0,0;for _,f:=range m.Functions{has:=false;for _,in:=range f.Code{if in.Op==0x11||in.Op==0x14{calls++;has=true}};if has{callers++}}
  t.Logf("path=%s count=%d indirectCallers=%d indirectSites=%d bytes=%d compileNs=%d linked=%v",path,len(m.Functions),callers,calls,bytes,elapsed.Nanoseconds(),c.linked);c.Close()
 }
}

func TestP3DispatchSizeProbe(t *testing.T) {
 raw,err:=os.ReadFile("../../../pkg/wasi/preview3/testdata/world-rust-http.wasm");if err!=nil{t.Fatal(err)}
 binary,err:=componentdecode.Decode(raw,componentdecode.DefaultLimits());if err!=nil{t.Fatal(err)}
 var visit func(*model.Binary)
 visit=func(b *model.Binary){for _,d:=range b.Definitions{if d.Component!=nil{visit(d.Component)};if d.CoreModule==nil{continue};m:=callSlots(t,d.CoreModule,wasm.SupportedFeatures);if len(m.Functions)==0{continue};limits:=codegen.DefaultLimits();limits.MaxCodeBytes=512<<20;start:=time.Now();c,err:=Compile(context.Background(),m,limits);elapsed:=time.Since(start);if err!=nil{t.Fatal(err)};bytes:=reflect.ValueOf(c.code).Elem().FieldByName("size").Uint();t.Logf("count=%d bytes=%d compileNs=%d linked=%v",len(m.Functions),bytes,elapsed.Nanoseconds(),c.linked);c.Close()}}
 visit(binary)
}
