from pathlib import Path
import subprocess,os,json,time,ctypes,hashlib,xml.etree.ElementTree as ET,collections
import sys,gzip,signal
from pathlib import Path
import ctypes,json,os,random,re,statistics,subprocess,threading

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/lijie/source/goplus/wasmvm')
header=Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sys/resource.h').read_text()
body=header.split('struct rusage_info_v4 {',1)[1].split('};',1)[0]
fields=re.findall(r'uint64_t\s+(ri_\w+);',body)
class Info(ctypes.Structure):_fields_=[('ri_uuid',ctypes.c_ubyte*16)]+[(n,ctypes.c_uint64)for n in fields]
rusageLib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
rusageLib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];rusageLib.proc_pid_rusage.restype=ctypes.c_int
names=['ri_user_time','ri_system_time','ri_instructions','ri_cycles','ri_pkg_idle_wkups','ri_interrupt_wkups','ri_phys_footprint','ri_lifetime_max_phys_footprint','ri_runnable_time']
def snapshot(pid):
 info=Info();result=rusageLib.proc_pid_rusage(pid,4,ctypes.byref(info))
 if result:raise OSError(ctypes.get_errno(),'proc_pid_rusage')
 return {n:int(getattr(info,n)) for n in names}
assert snapshot(os.getpid())['ri_user_time']>0
class Timebase(ctypes.Structure):
 _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
system=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
system.mach_timebase_info.argtypes=[ctypes.POINTER(Timebase)]
system.mach_timebase_info.restype=ctypes.c_int
clockbase=Timebase()
assert system.mach_timebase_info(ctypes.byref(clockbase))==0
tickNanoseconds=clockbase.numer/clockbase.denom




BASE=Path(__file__).resolve().parent;A=BASE.parent;R=A.parents[1];role=sys.argv[1];assert role in ["go","llgo","wasmtime"];D=BASE/(role+'-profile');D.mkdir(exist_ok=True);(D/"maps").mkdir(exist_ok=True)
cmd=['/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-parameter-initialization-20261115/head-go-runner-committed','--engine','wasmvm','--backend','native','--wasm',str(R/'pkg/wasi/preview3/testdata/world-rust-http.wasm'),'--response-mode','buffered','--request-mode','snapshot','--payload-bytes','16','--expected','1757737011','--workers','4','--clients','16','--requests','32','--samples','257','--warmups','2']
if role=='llgo':cmd[0]=str(BASE/'llgo-main-runner')
if role=='wasmtime':
 cmd[0]=str(A/'output-screen/wasmtime-go-runner');cmd[cmd.index('--engine')+1]='wasmtime';cmd[cmd.index('--backend')+1]='compiler'
 for option in ['--response-mode','--request-mode']:
  index=cmd.index(option);del cmd[index:index+2]
lib=ctypes.CDLL('/usr/lib/libSystem.B.dylib');token=ctypes.c_int();name=('cpunion.wasmvm.warmonly.'+str(os.getpid())).encode();assert lib.notify_register_check(name,ctypes.byref(token))==0
started=time.monotonic();trace=D/'cpu.trace';profiler=None
with(D/'stderr.log').open('w')as err:
 p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=dict(os.environ,GOMAXPROCS='4',WASMVM_INTERLEAVE='1',WASMVM_DIAGNOSTIC_JIT_MAP='' ))
 try:
  assert json.loads(p.stdout.readline())=={'ready':True};p.stdin.write('run\n');p.stdin.flush()
  assert json.loads(p.stdout.readline())=={'sampleReady':0}
  with (D/'vmmap.txt').open('w')as maps:subprocess.run(['vmmap','-wide',str(p.pid)],stdout=maps,stderr=subprocess.STDOUT,check=True)
  record=['xctrace','record','--template','CPU Profiler','--no-prompt','--time-limit','45s','--notify-tracing-started',name.decode(),'--output',str(trace),'--attach',str(p.pid)]
  with(D/'profiler.log').open('w')as log:profiler=subprocess.Popen(record,stdout=log,stderr=subprocess.STDOUT)
  changed=ctypes.c_int();lib.notify_check(token,ctypes.byref(changed));deadline=time.monotonic()+20
  while not changed.value:
   assert profiler.poll()is None and time.monotonic()<deadline;time.sleep(.02);assert lib.notify_check(token,ctypes.byref(changed))==0
  cpuBefore=snapshot(p.pid)
  for i in range(256):
   if i:assert json.loads(p.stdout.readline())=={'sampleReady':i}
   p.stdin.write('sample\n');p.stdin.flush()
  assert json.loads(p.stdout.readline())=={'sampleReady':256}
  cpuAfter=snapshot(p.pid)
  (D/'rusage.json').write_text(json.dumps(dict(before=cpuBefore,after=cpuAfter,requests=256*512,machTimebase=dict(numer=clockbase.numer,denom=clockbase.denom),profiledCPUUsPerRequest=((cpuAfter['ri_user_time']-cpuBefore['ri_user_time'])+(cpuAfter['ri_system_time']-cpuBefore['ri_system_time']))*tickNanoseconds/(256*512)/1000),indent=2)+'\n')
  profiler.send_signal(signal.SIGINT);assert profiler.wait(timeout=50)==0
  p.stdin.write('sample\n');p.stdin.flush()
  value=json.loads(p.stdout.readline());p.stdin.close();rest=p.stdout.read();assert p.wait(timeout=10)==0 and not rest and value['warmResults']==[1757737011]*257
  gzip.open(D/'record.json.gz','wt').write(json.dumps(value)+'\n');assert profiler.wait(timeout=50)==0
 finally:
  if p.poll()is None:p.kill();p.wait()
  if profiler is not None and profiler.poll()is None:profiler.kill();profiler.wait()
  lib.notify_cancel(token)

(D/'plan.json').write_text(json.dumps(dict(source='Exact production wasmvmec6396bf, reused Go55f3e93a with identical Go/module files; LLGo0539ea6e -O3 -lto=full. Unmodified independent Wasmtime48. Anonymous executable ranges are probable guest code, not named functions.',checkedWarmRequests=256*512,command=cmd,profilerCommand=record,binarySHA256=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest(),scope='Diagnostic CPU Profiler capture only. Attachafterfirst+2warmups atsampleReady0. All131072warmresponses checked, startup/setup outsidecapture. No ownedbuilds/tests/otherprofilers/pruning overlap. Stop profiler atsampleReady256 before final unprofiled flush/cleanup/output.131072 measuredwarmresponses and512additionalflushresponses checked. FourStores/sixteenclients; no timingacceptance.'),indent=2)+'\n')
subprocess.run(['xctrace','export','--input',str(trace),'--toc','--output',str(D/'toc.xml')],check=True)

subprocess.run(['xctrace','export','--input',str(trace),'--xpath','//run[@number="1"]/data/table[@schema="cpu-profile"]','--output',str(D/'samples.xml')],check=True)
