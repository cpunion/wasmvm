from pathlib import Path
import gzip,hashlib,json,statistics,subprocess,tarfile
D=Path(__file__).resolve().parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');name='performance-runtime-allocation-2026-11-15'
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def project(v):
 if isinstance(v,list):return[project(x)for x in v]
 if not isinstance(v,dict):return v
 return{k:(dict(count=len(x),minimum=min(x)if x else None,maximum=max(x)if x else None,canonicalJSONSHA256=hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest())if k in('RequestNs','PublicAPINs')and isinstance(x,list)else project(x))for k,x in v.items()}
folders=[]
for p in D.rglob('summary.json'):
 q=p.parent
 if(q/'rows.jsonl.gz').exists()or(q/'rows.jsonl').exists():folders.append(q)
folders.sort();counts={};observations={};evidence=W/'docs/research/evidence'/f'{name}.jsonl.gz'
with gzip.open(evidence,'wt',compresslevel=9)as output:
 for q in folders:
  folder=str(q.relative_to(D));path=q/'rows.jsonl.gz';rows=[json.loads(l)for l in(gzip.open(path,'rt')if path.exists()else(q/'rows.jsonl').open())];counts[folder]=len(rows)
  for row in rows:output.write(json.dumps(dict(cohort=folder,**project(row)),separators=(',',':'))+'\n')
  if 'service'not in rows[0].get('record',{}):continue
  end=8 if 'no-gc'in folder else 23;observations[folder]={}
  for role in sorted({r['id']for r in rows if not r['id'].endswith('-aa')}):
   rr=[r for r in rows if r['id']in(role,role+'-aa')];cc=[sum(b['GCAfter']-b['GCBefore']for b in r['record']['service']['Batches'][3:end])for r in rr]
   observations[folder][role]=dict(collectionsMedian=statistics.median(cc),collectionsRange=[min(cc),max(cc)])
assert len(counts)==22 and sum(counts.values())==1380,counts
profiles={}
for q in D.iterdir():
 if not q.is_dir()or not(q/'samples.xml').exists():continue
 summary=q/('time-summary.json'if q.name.endswith('-time-profile') else'stacks-summary.json');profiles[q.name]=dict(plan=read(q/'plan.json'),rusage=read(q/'rusage.json'),summary={k:v for k,v in read(summary).items()if k in('samples','cycleWeight','totalWeight','states')},fullSummaryFile=str(summary.relative_to(D)),samplesXMLSHA256=digest(q/'samples.xml'),rawTrace='Retained locally; full toc.xml excluded because it includes the process environment.')
protocol=W/'docs/research/data'/f'{name}-protocol.tar.gz'
with tarfile.open(protocol,'w:gz')as archive:
 for p in sorted(D.rglob('*')):
  if not p.is_file()or p.is_symlink()or p.name=='getg-patch.go':continue
  if p.suffix in('.go','.py','.json','.log','.txt','.patch','.stderr','.stdout','.asm','.h'):
   archive.add(p,arcname=str(p.relative_to(D)))
 archive.add(D.parent/'native-frame-deltas-20261114/generic-calls.wasm',arcname='fixtures/generic-calls.wasm')
 sdk=Path('/Users/lijie/source/goplus/llgo-external-link-options')
 for p in [sdk/'LICENSE',Path('/opt/homebrew/opt/bdw-gc/share/doc/gc/LICENSE')]:
  if p.is_file():archive.add(p,arcname='licenses/'+('llgo-'if p.parent==sdk else'bdwgc-')+p.name)
identity=read(D/'caller-batches/identity.json')
report=dict(base=identity['base'],source=identity['source'],sourceTree=subprocess.check_output(['git','rev-parse',identity['source']+'^{tree}'],cwd=W,text=True).strip(),host='Apple M4 Max/macOS arm64. Other user build/link/test/desktop activity observed; snapshots retained. No owned build/test/profile/analysis/edit/pruning overlaps timed cohorts. Fixed cohorts not extended or pooled.',toolchains=dict(Go='1.27.3',LLGoMain='0539ea6e2d23a94f8cbb1f9d408c909766ce133b',previousLLGo='6a482f7f6ad94e9f2d0a0fea97dd4cabd46b1130',LLVM='22.1.8',LLGoFlags=['-O3','-lto=full'],GC='Default production GC; independent bounded GC_DONT_GC=1 diagnostics assert zero measured collections.'),references=dict(wazero='1.12.0',wasmtime='48.0.1',wasmer='7.3.0',nativeC='Unchecked LLVM22 affine oracle, normalized2N steps; not a VM contract.'),identity=identity,compilerUpgrade=read(D/'analysis.json'),GCablation=read(D/'gc-ablation-16/analysis.json'),rejectedGetg=read(D/'getg-analysis.json'),rejectedCombinedHostState=read(D/'host-metadata/analysis.json'),sourceAblation=read(D/'host-bisect/analysis.json'),finalComparisons=read(D/'caller-batches/analysis.json'),GCobservations=observations,profiles=profiles,allocationSites=read(D/'host-metadata/allocation-sites/summary.json'),allocatorRouting=read(D/'host-bisect/code/bdwgc-identity.json'),validation=dict(Go='All32 root packages pass; all31 measured executable packages >=90% statement coverage. Affected vm/component/P3 race tests and both extra modules pass.',LLGo='vm/component/P3 execute on latest0539ea6e -O3 -lto=full. Complete final-head23check dual-platform semantic CI remains a merge prerequisite.',tests='Copied Caller headers across20callbacks/twoleases, GC, expired aliases/contexts, live independent transaction budgets, result ownership/context across successful and failed handoffs.'),interpretation='Allocator/GC and host canonical/lifetime setup are the largest coarse LLGo profile group, not an exact exclusive CPU decomposition. Compiler upgrade resolves lower allocation counts, not normalGC CPU gain. Final fresh Caller batching and immutable metadata lower allocations/bytes and instructions; CPU/throughput gains remain unproven. Reject host-state coallocation:408byte allocation crosses BDWGC tiny-list routing, unlike152+256byte base. Source ablation reproduces its adverse noGC point, exact layout/allocator cost shares unisolated. Getg outlines reduce instructions without CPU gain and are rejected. No competitive parity/release acceptance.',errata=['Original getg-no-gc-16 template removed GC_DONT_GC, stopped on nonzero collections before any row serialization; four process executions from that failed block are not recovered/countable. Independent corrected cohorts retained separately.','Initial host-metadata Go build used phase instead of P3 runner; wrong-flag preflight and failed startup block serialized no valid rows. Corrected independent Go cohorts are separate; no result inferred from failed startup.','Initial coallocation plain branch used a nil multiassignment LHS; Go tests caught it before timing and it was corrected.','A new result-handoff test initially tried reuse after a trapping callback, contrary to the instance failure contract; corrected test puts failure last.','Initial allocation-site diagnostic omitted the final flush and wrote no profile; corrected untimed run includes flush.','A first new Caller test referred to vm.ErrClosed rather than wasm.ErrClosed and failed to compile; fixed before timed work.','Go CPU Profiler produced one sample and is insufficient for a distribution claim. Time Profiler Running rows include kernel waits; CPU-cycle weights are not cross-runtime exclusive-cost units. Raw summaries and all adverse controls remain.'],evidence=dict(path='../evidence/'+evidence.name,records=sum(counts.values()),cohorts=counts,sha256=digest(evidence),projection='Only unused RequestNs/PublicAPINs vectors become count/extrema/canonical-JSON SHA256; full originals retained locally. Phases, outputs, GC/allocations, orders and rusage remain.'),protocol=dict(path=protocol.name,sha256=digest(protocol),contents='Plans/scripts/partial source snapshots and patches, compiler and binary identities, profiles summarized with raw XML hashes, allocator/generated assembly, load snapshots and test logs. No full repository source copies or raw environment-bearing toc.xml. Upstream patch/header licenses retained.'))
(W/'docs/research/data'/f'{name}.json').write_text(json.dumps(report,indent=2)+'\n');print(dict(cohorts=len(counts),records=sum(counts.values()),evidenceBytes=evidence.stat().st_size,protocolBytes=protocol.stat().st_size))
