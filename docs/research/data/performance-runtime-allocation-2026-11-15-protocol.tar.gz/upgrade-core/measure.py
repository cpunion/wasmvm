from pathlib import Path
import json,os,random,statistics,sys,hashlib,subprocess
D=Path(__file__).resolve().parent;A=D.parent.parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');P=A/'native-frame-deltas-20261114'
sys.path.insert(0,str(W/'benchmarks'));sys.path.insert(0,str(W/'benchmarks/native'))
import interleaved,runtime_fixtures
os.environ['GOMAXPROCS']='1';os.environ['GOGC']='100'
count=5000000;seed=17;expected=runtime_fixtures.checksum('nested-calls',seed,count*2)
refs=json.loads((A/'transitive-leaves/plan.json').read_text())['commands']
binaries={'base':'/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-parameter-initialization-20261115/head-llgo-phase-committed','head':str(D.parent/'llgo-main-phase'),'go':'/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-parameter-initialization-20261115/head-go-phase-committed',**{k:refs[k][0]for k in ('wazero','wasmtime','wasmer')},'native-llvm':str(A/'transitive-leaves/native-llvm-control')}
commands={}
for name,binary in binaries.items():
 if name=='native-llvm':
  cmd=[binary,str(count*2),str(seed),str(expected)];commands[name]=cmd;commands[name+'-aa']=cmd;continue
 cmd=[binary,'--backend','native'if name in ('base','head','go')else'compiler','--wasm',str(P/'generic-calls.wasm'),'--iterations',str(count),'--seed',str(seed),'--expected',str(expected),'--samples','7','--warmups','2']
 if name in ('base','head','go'):cmd+=['--mode','api']
 commands[name]=cmd;commands[name+'-aa']=cmd
plan=dict(blocks=10,samples=7,warmups=2,iterations=count,seed=seed,expected=expected,randomSeed=202611153109,commands=commands,binaryHashes={k:hashlib.sha256(Path(v).read_bytes()).hexdigest()for k,v in binaries.items()},scope='Separate fixed10block140process compiler-upgrade event, wasmvmec6396bf/reused55f3e93a identical Go/module files; LLGo6a482f7f versus0539ea6e, unchanged -O3 -lto=full/LLVM22.1.8/default GC, Go1.27.3 and three pinned runtimes/unchecked C2N anchors. Seven interleaved5M calls plus separate setup/first/warmups. All checks, aliases/load snapshots, no owned builds/tests/profiles/analysis/edits/pruning overlap; no extension or acceptance.')
assert not(D/'rows.jsonl').exists();(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rng=random.Random(plan['randomSeed']);rows=[]
for block in range(plan['blocks']):
 load=subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True);(D/f'load-{block}.txt').write_text('\n'.join(l for l in load.splitlines()[1:]if float(l.split(None,2)[1])>5)+'\n')
 observations,orders=interleaved.invoke(commands,180,rng,samples=7)
 for name,ob in observations.items():
  r=ob['record'];assert r['result']==expected and r['warmResults']==[expected]*7 and r['warmupResults']==[expected]*2
  role=name.removesuffix('-aa')
  if role in ('base','head','go'):
   expectedSource='ec6396bf21979bd8a89b6b4cbb558e44e7328a67'if role=='head'else'55f3e93a0a362c56b2fc285fe2aee9919582a38e'
   expectedCompiler='0539ea6e2d23a94f8cbb1f9d408c909766ce133b'if role=='head'else'go1.27.3'if role=='go'else'6a482f7f6ad94e9f2d0a0fea97dd4cabd46b1130'
   assert r['sourceRevision']==expectedSource and r['compilerRevision']==expectedCompiler

  row=dict(block=block,id=name,nsPerIteration=statistics.median(r['warmCallNs'])/count,observation=ob,orders=orders)
  with(D/'rows.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  rows.append(row)
 print('block',block,{n:round(rows[-len(commands)+i]['nsPerIteration'],4)for i,n in enumerate(observations)},flush=True)
summary={n:statistics.median(r['nsPerIteration']for r in rows if r['id']==n)for n in commands};(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
