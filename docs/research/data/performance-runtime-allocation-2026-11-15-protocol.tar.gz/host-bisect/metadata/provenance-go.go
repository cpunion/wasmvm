package phase
func init(){sourceRevision="08394fee5a1606471e5c9c3b9fb12a85b156e7e5";compilerRevision="go1.27.3"}
