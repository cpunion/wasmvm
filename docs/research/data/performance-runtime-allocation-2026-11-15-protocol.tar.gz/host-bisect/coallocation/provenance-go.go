package phase
func init(){sourceRevision="574a1dfea515b05562d48ae56053eb6732d73e82";compilerRevision="go1.27.3"}
