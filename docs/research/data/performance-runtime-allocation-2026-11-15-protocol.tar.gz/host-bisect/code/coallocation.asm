
/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/profile-gap-0539ea6e-20261115/host-bisect/coallocation/llgo-runner:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100312cd4 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec>:
100312cd4:     	stp	x24, x23, [sp, #-0x40]!
100312cd8:     	stp	x22, x21, [sp, #0x10]
100312cdc:     	stp	x20, x19, [sp, #0x20]
100312ce0:     	stp	x29, x30, [sp, #0x30]
100312ce4:     	add	x29, sp, #0x30
100312ce8:     	mov	x19, x3
100312cec:     	mov	x20, x2
100312cf0:     	mov	x21, x1
100312cf4:     	mov	x22, x0
100312cf8:     	cbz	x2, 0x100312d70 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x9c>
100312cfc:     	ldr	x8, [x20, #0x40]
100312d00:     	cbz	x8, 0x100312d0c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x38>
100312d04:     	ldr	x8, [x8]
100312d08:     	cbnz	x8, 0x100312d14 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x40>
100312d0c:     	ldr	x8, [x20, #0x50]
100312d10:     	cbz	x8, 0x100312d70 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x9c>
100312d14:     	mov	w0, #0x100              ; =256
100312d18:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
100312d1c:     	cbz	x0, 0x100312dbc <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0xe8>
100312d20:     	mov	x23, x0
100312d24:     	mov	w0, #0x100              ; =256
100312d28:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100312d2c:     	mov	x8, x23
100312d30:     	adrp	x9, 0x10085f000 <__llgo_struct$XUM6JFti7FbDy-nBoXf5uS_r5VXpqQlSkMJlzwrLrn0$fields+0x168>
100312d34:     	add	x9, x9, #0x620
100312d38:     	str	x22, [x8, #0x70]!
100312d3c:     	stp	xzr, xzr, [x8, #0x28]
100312d40:     	stp	xzr, xzr, [x8, #0x38]
100312d44:     	stp	xzr, xzr, [x8, #0x50]
100312d48:     	str	xzr, [x8, #0x48]
100312d4c:     	stp	xzr, xzr, [x8, #0x80]
100312d50:     	str	xzr, [x8, #0x78]
100312d54:     	str	wzr, [x8, #0x70]
100312d58:     	str	xzr, [x8, #0x68]
100312d5c:     	strb	wzr, [x8, #0x60]
100312d60:     	stp	xzr, xzr, [x8, #0x18]
100312d64:     	stp	x21, x20, [x8, #0x8]
100312d68:     	stp	x9, x8, [x8, #-0x10]
100312d6c:     	b	0x100312d88 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0xb4>
100312d70:     	mov	w0, #0x70               ; =112
100312d74:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
100312d78:     	cbz	x0, 0x100312dbc <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0xe8>
100312d7c:     	mov	x23, x0
100312d80:     	mov	w0, #0x70               ; =112
100312d84:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100312d88:     	mov	x0, x22
100312d8c:     	mov	x1, x23
100312d90:     	mov	x2, x21
100312d94:     	mov	x3, x20
100312d98:     	mov	x4, x19
100312d9c:     	mov	w5, #0x1                ; =1
100312da0:     	bl	0x1003133e0 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec>
100312da4:     	ldp	x29, x30, [sp, #0x30]
100312da8:     	mov	x0, x23
100312dac:     	ldp	x20, x19, [sp, #0x20]
100312db0:     	ldp	x22, x21, [sp, #0x10]
100312db4:     	ldp	x24, x23, [sp], #0x40
100312db8:     	ret
100312dbc:     	adrp	x0, 0x1008fe000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0xa8>
100312dc0:     	add	x0, x0, #0xb08
100312dc4:     	adrp	x1, 0x1008f5000 <__llgo_struct$RSTTp_pTKglBmcdy0CMmgLp9HSGRvgD8UwNIoMFFyOg$fields+0xc0>
100312dc8:     	add	x1, x1, #0x3c0
100312dcc:     	bl	0x100586f50 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100312dd0:     	brk	#0x1

00000001003133e0 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec>:
1003133e0:     	sub	sp, sp, #0x90
1003133e4:     	stp	x28, x27, [sp, #0x30]
1003133e8:     	stp	x26, x25, [sp, #0x40]
1003133ec:     	stp	x24, x23, [sp, #0x50]
1003133f0:     	stp	x22, x21, [sp, #0x60]
1003133f4:     	stp	x20, x19, [sp, #0x70]
1003133f8:     	stp	x29, x30, [sp, #0x80]
1003133fc:     	add	x29, sp, #0x80
100313400:     	cbz	x1, 0x1003135f0 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x210>
100313404:     	mov	x21, x0
100313408:     	mov	x0, x2
10031340c:     	mov	w24, w5
100313410:     	mov	x20, x4
100313414:     	mov	x22, x3
100313418:     	mov	x19, x1
10031341c:     	mov	x23, x2
100313420:     	bl	0x10033254c <_github.com/cpunion/wasmvm/pkg/vm.(*Caller).Context>
100313424:     	ldr	x8, [x21, #0x168]
100313428:     	stp	x0, x1, [x19]
10031342c:     	strh	wzr, [x19, #0x20]
100313430:     	stp	x8, xzr, [x19, #0x28]
100313434:     	stp	xzr, xzr, [x19, #0x38]
100313438:     	stp	xzr, xzr, [x19, #0x10]
10031343c:     	cbz	x20, 0x1003135b8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x1d8>
100313440:     	ldrb	w8, [x20, #0x78]
100313444:     	ldrb	w9, [x20, #0x50]
100313448:     	strb	w8, [x19, #0x20]
10031344c:     	strb	w9, [x19, #0x21]
100313450:     	ldr	x8, [x20, #0x58]
100313454:     	cbz	x8, 0x100313504 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x124>
100313458:     	ldr	x1, [x22, #0x58]
10031345c:     	mov	w8, #0x102              ; =258
100313460:     	adrp	x0, 0x100855000 <__llgo_func$axiTkraFkfe62TR5Udl5rnNUQkDfZOqA4NrWphySErU$in+0x8>
100313464:     	add	x0, x0, #0xde0
100313468:     	add	x2, sp, #0x2c
10031346c:     	stp	x23, x22, [sp, #0x18]
100313470:     	strh	w8, [sp, #0x2c]
100313474:     	bl	0x10058f808 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MapAccess1>
100313478:     	ldr	x9, [x20, #0x58]
10031347c:     	mov	x8, x0
100313480:     	ldr	x1, [x0, #0x8]
100313484:     	ldr	w0, [x9]
100313488:     	cmp	x1, x0
10031348c:     	b.ls	0x100313614 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x234>
100313490:     	mov	w9, #0x78               ; =120
100313494:     	ldr	x8, [x8]
100313498:     	umaddl	x8, w0, w9, x8
10031349c:     	mov	w0, #0x48               ; =72
1003134a0:     	ldp	x9, x10, [x8, #0x38]
1003134a4:     	ldr	x27, [x8, #0x20]
1003134a8:     	ldp	x23, x22, [x8, #0x8]
1003134ac:     	ldrb	w28, [x8, #0x18]
1003134b0:     	stp	x9, x10, [sp, #0x8]
1003134b4:     	ldp	x26, x9, [x8, #0x28]
1003134b8:     	str	x9, [sp]
1003134bc:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
1003134c0:     	cbz	x0, 0x100313618 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x238>
1003134c4:     	mov	x25, x0
1003134c8:     	mov	w0, #0x48               ; =72
1003134cc:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1003134d0:     	str	x22, [x25, #0x10]
1003134d4:     	ldp	x8, x22, [sp, #0x18]
1003134d8:     	strb	w28, [x25, #0x18]
1003134dc:     	stp	x8, x23, [x25]
1003134e0:     	mov	x23, x8
1003134e4:     	ldp	x9, x8, [sp]
1003134e8:     	stp	x27, x26, [x25, #0x20]
1003134ec:     	stp	x9, x8, [x25, #0x30]
1003134f0:     	ldr	x8, [sp, #0x10]
1003134f4:     	str	x8, [x25, #0x40]
1003134f8:     	adrp	x8, 0x10085f000 <__llgo_struct$XUM6JFti7FbDy-nBoXf5uS_r5VXpqQlSkMJlzwrLrn0$fields+0x168>
1003134fc:     	add	x8, x8, #0xa00
100313500:     	stp	x8, x25, [x19, #0x10]
100313504:     	tbz	w24, #0x0, 0x1003135b8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x1d8>
100313508:     	ldr	x8, [x20, #0x60]
10031350c:     	cbz	x8, 0x1003135b8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x1d8>
100313510:     	mov	w0, #0x40               ; =64
100313514:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
100313518:     	cbz	x0, 0x100313618 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x238>
10031351c:     	mov	x24, x0
100313520:     	mov	w0, #0x40               ; =64
100313524:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100313528:     	ldr	x1, [x22, #0x58]
10031352c:     	mov	w8, #0x100              ; =256
100313530:     	adrp	x0, 0x100855000 <__llgo_func$axiTkraFkfe62TR5Udl5rnNUQkDfZOqA4NrWphySErU$in+0x8>
100313534:     	add	x0, x0, #0xde0
100313538:     	add	x2, sp, #0x2e
10031353c:     	strh	w8, [sp, #0x2e]
100313540:     	bl	0x10058f808 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MapAccess1>
100313544:     	ldr	x9, [x20, #0x60]
100313548:     	mov	x8, x0
10031354c:     	ldr	x1, [x0, #0x8]
100313550:     	ldr	w0, [x9]
100313554:     	cmp	x1, x0
100313558:     	b.ls	0x100313614 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x234>
10031355c:     	mov	w9, #0x78               ; =120
100313560:     	ldr	x8, [x8]
100313564:     	umaddl	x8, w0, w9, x8
100313568:     	mov	w0, #0x20               ; =32
10031356c:     	ldp	q2, q0, [x8, #0x20]
100313570:     	ldr	x9, [x8, #0x40]
100313574:     	ldr	x10, [x8, #0x8]
100313578:     	ldr	q1, [x8, #0x10]
10031357c:     	str	x9, [x24, #0x38]
100313580:     	stur	q0, [x24, #0x28]
100313584:     	stur	q2, [x24, #0x18]
100313588:     	stur	q1, [x24, #0x8]
10031358c:     	str	x10, [x24]
100313590:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
100313594:     	cbz	x0, 0x100313618 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x238>
100313598:     	mov	x25, x0
10031359c:     	mov	w0, #0x20               ; =32
1003135a0:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1003135a4:     	adr	x8, 0x100313784 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1>
1003135a8:     	nop
1003135ac:     	stp	x22, x20, [x25]
1003135b0:     	stp	x23, x24, [x25, #0x10]
1003135b4:     	stp	x8, x25, [x19, #0x30]
1003135b8:     	mov	x0, x21
1003135bc:     	mov	x1, x22
1003135c0:     	mov	x2, x20
1003135c4:     	bl	0x100313630 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).canonicalLayouts>
1003135c8:     	ldr	x8, [x21, #0x160]
1003135cc:     	ldp	x29, x30, [sp, #0x80]
1003135d0:     	ldp	x22, x21, [sp, #0x60]
1003135d4:     	stp	x0, x8, [x19, #0x48]
1003135d8:     	ldp	x20, x19, [sp, #0x70]
1003135dc:     	ldp	x24, x23, [sp, #0x50]
1003135e0:     	ldp	x26, x25, [sp, #0x40]
1003135e4:     	ldp	x28, x27, [sp, #0x30]
1003135e8:     	add	sp, sp, #0x90
1003135ec:     	ret
1003135f0:     	ldp	x29, x30, [sp, #0x80]
1003135f4:     	mov	w0, #0x1                ; =1
1003135f8:     	ldp	x20, x19, [sp, #0x70]
1003135fc:     	ldp	x22, x21, [sp, #0x60]
100313600:     	ldp	x24, x23, [sp, #0x50]
100313604:     	ldp	x26, x25, [sp, #0x40]
100313608:     	ldp	x28, x27, [sp, #0x30]
10031360c:     	add	sp, sp, #0x90
100313610:     	b	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100313614:     	bl	0x100588810 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100313618:     	adrp	x0, 0x1008fe000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0xa8>
10031361c:     	add	x0, x0, #0xb08
100313620:     	adrp	x1, 0x1008f5000 <__llgo_struct$RSTTp_pTKglBmcdy0CMmgLp9HSGRvgD8UwNIoMFFyOg$fields+0xc0>
100313624:     	add	x1, x1, #0x3c0
100313628:     	bl	0x100586f50 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10031362c:     	brk	#0x1

0000000100313784 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1>:
100313784:     	stp	x28, x27, [sp, #-0x60]!
100313788:     	stp	x26, x25, [sp, #0x10]
10031378c:     	stp	x24, x23, [sp, #0x20]
100313790:     	stp	x22, x21, [sp, #0x30]
100313794:     	stp	x20, x19, [sp, #0x40]
100313798:     	stp	x29, x30, [sp, #0x50]
10031379c:     	add	x29, sp, #0x50
1003137a0:     	sub	sp, sp, #0x2d0
1003137a4:     	stp	x8, x3, [sp, #0x28]
1003137a8:     	ldr	x28, [x20, #0x18]
1003137ac:     	mov	x24, x2
1003137b0:     	str	xzr, [sp, #0x138]
1003137b4:     	mov	x27, x1
1003137b8:     	mov	x26, x0
1003137bc:     	str	xzr, [sp, #0x140]
1003137c0:     	str	xzr, [sp, #0x148]
1003137c4:     	str	xzr, [sp, #0x150]
1003137c8:     	ldr	x9, [x20]
1003137cc:     	ldr	x21, [x9, #0x20]
1003137d0:     	str	x21, [sp, #0x150]
1003137d4:     	ldrb	w22, [x9, #0x28]
1003137d8:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
1003137dc:     	add	x25, sp, #0x74
1003137e0:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
1003137e4:     	ldr	x9, [x0, #0x10]
1003137e8:     	stp	x25, xzr, [sp, #0x40]
1003137ec:     	ldr	x8, [x8, #0x558]
1003137f0:     	mov	x19, x9
1003137f4:     	stp	x9, x8, [sp, #0x50]
1003137f8:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
1003137fc:     	add	x8, sp, #0x40
100313800:     	mov	w1, wzr
100313804:     	str	x8, [x0, #0x10]
100313808:     	mov	x0, x25
10031380c:     	str	xzr, [sp, #0x68]
100313810:     	bl	0x1005a11f8 <dyld_stub_binder+0x1005a11f8>
100313814:     	adrp	x23, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313818:     	ldr	x23, [x23, #0x560]
10031381c:     	cbz	w0, 0x100313844 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0xc0>
100313820:     	ldr	x8, [sp, #0x58]
100313824:     	str	x23, [sp, #0x60]
100313828:     	br	x8
10031382c:     	adrp	x9, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313830:     	ldrb	w8, [sp, #0x48]
100313834:     	ldr	x9, [x9, #0x570]
100313838:     	str	x9, [sp, #0x58]
10031383c:     	tbnz	w8, #0x1, 0x100313b78 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3f4>
100313840:     	b	0x100313b90 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x40c>
100313844:     	stp	x27, x26, [sp, #0x18]
100313848:     	tbz	w22, #0x0, 0x100313874 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0xf0>
10031384c:     	mov	w8, #0x40               ; =64
100313850:     	ldr	x22, [x20]
100313854:     	mov	w0, w8
100313858:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
10031385c:     	cbz	x0, 0x100313c2c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x4a8>
100313860:     	mov	w8, #0x40               ; =64
100313864:     	mov	x23, x0
100313868:     	mov	w0, w8
10031386c:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100313870:     	str	x23, [x22, #0x20]
100313874:     	ldr	x10, [sp, #0x68]
100313878:     	ldr	x9, [x20]
10031387c:     	adr	x11, 0x100313c44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$1>
100313880:     	nop
100313884:     	str	x19, [sp, #0x38]
100313888:     	stp	x10, xzr, [sp, #0x168]
10031388c:     	mov	w10, #0x1               ; =1
100313890:     	stp	x9, x21, [sp, #0x158]
100313894:     	strb	w10, [x9, #0x69]
100313898:     	add	x9, sp, #0x158
10031389c:     	stp	x11, x9, [sp, #0x178]
1003138a0:     	ldp	x12, x11, [x20]
1003138a4:     	add	x9, sp, #0x168
1003138a8:     	stp	x12, x9, [sp, #0x188]
1003138ac:     	ldr	x12, [sp, #0x48]
1003138b0:     	adr	x9, 0x100313c50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$2>
1003138b4:     	nop
1003138b8:     	ldrb	w25, [x11, #0x78]
1003138bc:     	stp	x10, x9, [sp, #0x198]
1003138c0:     	add	x10, sp, #0x188
1003138c4:     	orr	x9, x12, #0x3
1003138c8:     	str	x10, [sp, #0x1a8]
1003138cc:     	add	x10, sp, #0x190
1003138d0:     	str	x9, [sp, #0x48]
1003138d4:     	str	x10, [sp, #0x68]
1003138d8:     	str	xzr, [sp, #0x1c8]
1003138dc:     	str	xzr, [sp, #0x1c0]
1003138e0:     	str	xzr, [sp, #0x1b8]
1003138e4:     	str	xzr, [sp, #0x1b0]
1003138e8:     	ldp	x8, x10, [x28, #0x30]
1003138ec:     	ldr	x20, [x20, #0x10]
1003138f0:     	ldp	x23, x26, [x28]
1003138f4:     	ldrb	w27, [x28, #0x10]
1003138f8:     	stp	x8, x10, [sp, #0x8]
1003138fc:     	ldp	x22, x8, [x28, #0x20]
100313900:     	ldr	x28, [x28, #0x18]
100313904:     	str	x8, [sp]
100313908:     	mov	w8, #0x40               ; =64
10031390c:     	mov	w0, w8
100313910:     	bl	0x1005a1288 <dyld_stub_binder+0x1005a1288>
100313914:     	cbz	x0, 0x100313c2c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x4a8>
100313918:     	mov	w8, #0x7e               ; =126
10031391c:     	cmp	w25, #0x0
100313920:     	mov	x25, x0
100313924:     	cinc	x21, x8, eq
100313928:     	sub	x19, x29, #0x100
10031392c:     	mov	w8, #0x40               ; =64
100313930:     	mov	w0, w8
100313934:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100313938:     	str	xzr, [sp, #0x1e8]
10031393c:     	sub	x0, x29, #0x100
100313940:     	mov	x1, x25
100313944:     	str	xzr, [sp, #0x1e0]
100313948:     	str	x21, [sp, #0x1e0]
10031394c:     	ldr	x9, [sp, #0x20]
100313950:     	str	x9, [sp, #0x1e8]
100313954:     	ldr	x9, [sp, #0x1e8]
100313958:     	ldr	x10, [sp, #0x1e0]
10031395c:     	stp	x10, x9, [x25]
100313960:     	str	xzr, [sp, #0x1f0]
100313964:     	str	xzr, [sp, #0x1f8]
100313968:     	str	x21, [sp, #0x1f0]
10031396c:     	ldr	x9, [sp, #0x18]
100313970:     	str	x9, [sp, #0x1f8]
100313974:     	ldr	x9, [sp, #0x1f8]
100313978:     	ldr	x10, [sp, #0x1f0]
10031397c:     	stp	x10, x9, [x25, #0x10]
100313980:     	str	xzr, [sp, #0x200]
100313984:     	str	xzr, [sp, #0x208]
100313988:     	str	x21, [sp, #0x200]
10031398c:     	str	x24, [sp, #0x208]
100313990:     	ldr	x9, [sp, #0x208]
100313994:     	ldr	x10, [sp, #0x200]
100313998:     	stp	x10, x9, [x25, #0x20]
10031399c:     	str	xzr, [sp, #0x210]
1003139a0:     	str	xzr, [sp, #0x218]
1003139a4:     	str	x21, [sp, #0x210]
1003139a8:     	ldr	x8, [sp, #0x30]
1003139ac:     	str	x8, [sp, #0x218]
1003139b0:     	ldr	x8, [sp, #0x218]
1003139b4:     	ldr	x9, [sp, #0x210]
1003139b8:     	stp	x9, x8, [x25, #0x30]
1003139bc:     	mov	w8, #0x4                ; =4
1003139c0:     	mov	w2, w8
1003139c4:     	bl	0x100309c04 <_github.com/cpunion/wasmvm/pkg/component.vmValues>
1003139c8:     	ldp	x8, x9, [sp]
1003139cc:     	sub	x1, x29, #0xa0
1003139d0:     	ldur	q0, [x19, #0x8]
1003139d4:     	sub	x2, x29, #0xb8
1003139d8:     	mov	x0, x20
1003139dc:     	stp	x23, x26, [x29, #-0xa0]
1003139e0:     	stp	x8, x9, [x29, #-0x78]
1003139e4:     	ldur	x8, [x29, #-0x100]
1003139e8:     	ldr	x9, [sp, #0x10]
1003139ec:     	sturb	w27, [x29, #-0x90]
1003139f0:     	stur	x8, [x29, #-0xb8]
1003139f4:     	sub	x8, x29, #0xe8
1003139f8:     	stp	x28, x22, [x29, #-0x88]
1003139fc:     	stur	x9, [x29, #-0x68]
100313a00:     	stur	q0, [x19, #0x50]
100313a04:     	bl	0x1003378e4 <_github.com/cpunion/wasmvm/pkg/vm.(*Caller).Call>
100313a08:     	ldp	x8, x9, [x29, #-0xe8]
100313a0c:     	ldur	q0, [x19, #0x38]
100313a10:     	ldp	x10, x11, [x29, #-0xd8]
100313a14:     	str	x8, [sp, #0x1b0]
100313a18:     	fmov	x8, d0
100313a1c:     	str	x9, [sp, #0x1b8]
100313a20:     	str	x10, [sp, #0x1c0]
100313a24:     	str	x11, [sp, #0x1c8]
100313a28:     	cbz	x8, 0x100313a50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x2cc>
100313a2c:     	ldr	x8, [x8, #0x8]
100313a30:     	cbz	x8, 0x100313a50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x2cc>
100313a34:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313a38:     	adrp	x23, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313a3c:     	mov	x0, xzr
100313a40:     	ldr	x8, [x8, #0x568]
100313a44:     	ldr	x19, [sp, #0x38]
100313a48:     	ldr	x23, [x23, #0x560]
100313a4c:     	b	0x100313b4c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c8>
100313a50:     	ldr	x8, [sp, #0x1c0]
100313a54:     	adrp	x23, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313a58:     	ldr	x9, [sp, #0x1b0]
100313a5c:     	ldr	x8, [sp, #0x1b8]
100313a60:     	ldr	x19, [sp, #0x38]
100313a64:     	ldr	x23, [x23, #0x560]
100313a68:     	cbz	x8, 0x100313c20 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x49c>
100313a6c:     	cbz	x9, 0x100313a9c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x318>
100313a70:     	ldp	x8, x0, [x9]
100313a74:     	sub	x9, x8, #0x7b
100313a78:     	cmp	x9, #0x5
100313a7c:     	sub	w9, w8, #0x68
100313a80:     	b.hs	0x100313aa8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x324>
100313a84:     	and	w8, w9, #0xff
100313a88:     	cmp	w8, #0xe
100313a8c:     	b.lo	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313a90:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313a94:     	movi.2d	v0, #0000000000000000
100313a98:     	b	0x100313b48 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c4>
100313a9c:     	mov	w0, #0x1                ; =1
100313aa0:     	bl	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100313aa4:     	b	0x100313c00 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x47c>
100313aa8:     	and	w10, w9, #0xff
100313aac:     	cmp	w10, #0xd
100313ab0:     	b.hi	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313ab4:     	cmp	x8, #0x100
100313ab8:     	b.lo	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313abc:     	mov	x10, #0xe100            ; =57600
100313ac0:     	movk	x10, #0xffff, lsl #48
100313ac4:     	and	x11, x8, x10
100313ac8:     	cmp	x11, #0x100
100313acc:     	b.ne	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313ad0:     	tbnz	w8, #0x9, 0x100313ae4 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x360>
100313ad4:     	and	x11, x8, #0xfffffffffc00
100313ad8:     	tst	x11, #0xffffffffffff1fff
100313adc:     	b.ne	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313ae0:     	b	0x100313afc <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x378>
100313ae4:     	and	w11, w9, #0xff
100313ae8:     	cmp	w11, #0x8
100313aec:     	b.hi	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313af0:     	mov	w12, #0x10d             ; =269
100313af4:     	lsr	w11, w12, w9
100313af8:     	tbz	w11, #0x0, 0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313afc:     	movi.2d	v0, #0000000000000000
100313b00:     	and	x10, x8, x10
100313b04:     	cmp	x10, #0x100
100313b08:     	b.ne	0x100313b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100313b0c:     	tbnz	w8, #0x9, 0x100313b20 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x39c>
100313b10:     	and	x8, x8, #0xfffffffffc00
100313b14:     	tst	x8, #0xffffffffffff1fff
100313b18:     	b.ne	0x100313b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100313b1c:     	b	0x100313b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100313b20:     	and	w8, w9, #0xff
100313b24:     	cmp	w8, #0x8
100313b28:     	b.hi	0x100313b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100313b2c:     	mov	w8, #0x10d              ; =269
100313b30:     	lsr	w8, w8, w9
100313b34:     	tbz	w8, #0x0, 0x100313b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100313b38:     	adrp	x8, 0x1029c5000 <__MergedGlobals.22838+0xa80>
100313b3c:     	mov	x0, xzr
100313b40:     	ldr	q0, [x8, #0x690]
100313b44:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313b48:     	ldr	x8, [x8, #0x578]
100313b4c:     	str	q0, [sp, #0x1d0]
100313b50:     	ldp	x10, x9, [sp, #0x1d0]
100313b54:     	str	x0, [sp, #0x138]
100313b58:     	str	x9, [sp, #0x148]
100313b5c:     	str	x10, [sp, #0x140]
100313b60:     	str	x8, [sp, #0x60]
100313b64:     	adrp	x9, 0x10076d000 <dyld_stub_binder+0x10076d000>
100313b68:     	ldrb	w8, [sp, #0x48]
100313b6c:     	ldr	x9, [x9, #0x570]
100313b70:     	str	x9, [sp, #0x58]
100313b74:     	tbz	w8, #0x1, 0x100313b90 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x40c>
100313b78:     	ldr	x8, [sp, #0x68]
100313b7c:     	cbz	x8, 0x100313b90 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x40c>
100313b80:     	ldp	x9, x20, [x8, #0x10]
100313b84:     	ldr	x10, [x8]
100313b88:     	str	x10, [sp, #0x68]
100313b8c:     	blr	x9
100313b90:     	ldr	w8, [sp, #0x48]
100313b94:     	str	x23, [sp, #0x58]
100313b98:     	tbz	w8, #0x0, 0x100313bc8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x444>
100313b9c:     	ldr	x8, [sp, #0x68]
100313ba0:     	cbz	x8, 0x100313bc8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x444>
100313ba4:     	ldp	x9, x20, [x8, #0x10]
100313ba8:     	ldr	x10, [x8]
100313bac:     	str	x10, [sp, #0x68]
100313bb0:     	blr	x9
100313bb4:     	ldr	x20, [sp, #0x50]
100313bb8:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100313bbc:     	str	x20, [x0, #0x10]
100313bc0:     	ldr	x8, [sp, #0x60]
100313bc4:     	br	x8
100313bc8:     	ldr	x20, [sp, #0x50]
100313bcc:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100313bd0:     	str	x20, [x0, #0x10]
100313bd4:     	ldr	x8, [sp, #0x60]
100313bd8:     	br	x8
100313bdc:     	mov	x0, x19
100313be0:     	bl	0x100588ea4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Rethrow>
100313be4:     	b	0x100313be8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x464>
100313be8:     	ldr	x8, [sp, #0x138]
100313bec:     	ldr	x9, [sp, #0x148]
100313bf0:     	ldr	x10, [sp, #0x140]
100313bf4:     	ldr	x11, [sp, #0x28]
100313bf8:     	stp	x8, x10, [x11]
100313bfc:     	str	x9, [x11, #0x10]
100313c00:     	add	sp, sp, #0x2d0
100313c04:     	ldp	x29, x30, [sp, #0x50]
100313c08:     	ldp	x20, x19, [sp, #0x40]
100313c0c:     	ldp	x22, x21, [sp, #0x30]
100313c10:     	ldp	x24, x23, [sp, #0x20]
100313c14:     	ldp	x26, x25, [sp, #0x10]
100313c18:     	ldp	x28, x27, [sp], #0x60
100313c1c:     	ret
100313c20:     	mov	x0, xzr
100313c24:     	mov	x1, xzr
100313c28:     	bl	0x10058725c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100313c2c:     	adrp	x0, 0x1008fe000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0xa8>
100313c30:     	add	x0, x0, #0xb08
100313c34:     	adrp	x1, 0x1008f5000 <__llgo_struct$RSTTp_pTKglBmcdy0CMmgLp9HSGRvgD8UwNIoMFFyOg$fields+0xc0>
100313c38:     	add	x1, x1, #0x3c0
100313c3c:     	bl	0x100586f50 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100313c40:     	brk	#0x1

0000000100313c44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$1>:
100313c44:     	ldp	x8, x9, [x20]
100313c48:     	str	x9, [x8, #0x20]
100313c4c:     	ret

0000000100313c50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$2>:
100313c50:     	ldr	x8, [x20]
100313c54:     	strb	wzr, [x8, #0x69]
100313c58:     	ret

0000000100314910 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall>:
100314910:     	stp	x28, x27, [sp, #-0x60]!
100314914:     	stp	x26, x25, [sp, #0x10]
100314918:     	stp	x24, x23, [sp, #0x20]
10031491c:     	stp	x22, x21, [sp, #0x30]
100314920:     	stp	x20, x19, [sp, #0x40]
100314924:     	stp	x29, x30, [sp, #0x50]
100314928:     	add	x29, sp, #0x50
10031492c:     	sub	sp, sp, #0x260
100314930:     	ldp	x27, x28, [x2]
100314934:     	mov	x20, x0
100314938:     	str	xzr, [sp, #0x120]
10031493c:     	mov	x24, x8
100314940:     	str	x1, [sp, #0x120]
100314944:     	str	xzr, [sp, #0x128]
100314948:     	str	xzr, [sp, #0x138]
10031494c:     	str	xzr, [sp, #0x130]
100314950:     	ldr	x21, [sp, #0x120]
100314954:     	mov	x1, x21
100314958:     	bl	0x100315110 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall>
10031495c:     	str	x0, [sp, #0x128]
100314960:     	ldr	x8, [x20, #0x8]
100314964:     	ldr	x19, [x8, #0x18]
100314968:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
10031496c:     	add	x22, sp, #0x5c
100314970:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314974:     	ldr	x25, [x0, #0x10]
100314978:     	stp	x22, xzr, [sp, #0x28]
10031497c:     	ldr	x8, [x8, #0x5f0]
100314980:     	stp	x25, x8, [sp, #0x38]
100314984:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100314988:     	add	x8, sp, #0x28
10031498c:     	mov	w1, wzr
100314990:     	str	x8, [x0, #0x10]
100314994:     	mov	x0, x22
100314998:     	str	xzr, [sp, #0x50]
10031499c:     	bl	0x1005a11f8 <dyld_stub_binder+0x1005a11f8>
1003149a0:     	adrp	x22, 0x10076d000 <dyld_stub_binder+0x10076d000>
1003149a4:     	ldr	x22, [x22, #0x5f8]
1003149a8:     	cbz	w0, 0x1003149c4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0xb4>
1003149ac:     	ldr	x8, [sp, #0x40]
1003149b0:     	str	x22, [sp, #0x48]
1003149b4:     	br	x8
1003149b8:     	mov	x0, x25
1003149bc:     	bl	0x100588ea4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Rethrow>
1003149c0:     	b	0x100314d74 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x464>
1003149c4:     	cmp	x28, x19
1003149c8:     	b.ne	0x100314a80 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x170>
1003149cc:     	mov	w8, #0x1                ; =1
1003149d0:     	mov	w0, w8
1003149d4:     	bl	0x1005a1288 <dyld_stub_binder+0x1005a1288>
1003149d8:     	cbz	x0, 0x100314de4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4d4>
1003149dc:     	mov	w8, #0x1                ; =1
1003149e0:     	mov	x22, x0
1003149e4:     	mov	w0, w8
1003149e8:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1003149ec:     	strb	wzr, [x22]
1003149f0:     	add	x10, sp, #0x130
1003149f4:     	add	x9, sp, #0x128
1003149f8:     	ldr	x8, [sp, #0x50]
1003149fc:     	stp	x10, x21, [sp, #0x150]
100314a00:     	add	x10, sp, #0x140
100314a04:     	stp	x9, x22, [sp, #0x140]
100314a08:     	add	x9, sp, #0x160
100314a0c:     	stp	x8, xzr, [sp, #0x160]
100314a10:     	adr	x8, 0x100315250 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1>
100314a14:     	nop
100314a18:     	stp	x8, x10, [sp, #0x170]
100314a1c:     	ldr	x8, [sp, #0x30]
100314a20:     	str	x9, [sp, #0x50]
100314a24:     	orr	x8, x8, #0x1
100314a28:     	str	x8, [sp, #0x30]
100314a2c:     	ldr	x8, [sp, #0x128]
100314a30:     	cbz	x8, 0x100314aa4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x194>
100314a34:     	ldp	x9, x10, [x8]
100314a38:     	ldr	x9, [x9]
100314a3c:     	ldr	x11, [x10, #0x58]
100314a40:     	ldr	x12, [x9, #0x160]
100314a44:     	ldr	x13, [x9, #0x1b8]
100314a48:     	add	x11, x12, x11
100314a4c:     	sub	x11, x11, x13
100314a50:     	str	x11, [x10, #0x50]
100314a54:     	ldr	x10, [x10, #0x40]
100314a58:     	ldr	x11, [x9, #0x168]
100314a5c:     	ldr	x9, [x9, #0x1c0]
100314a60:     	ldr	x8, [x8, #0x8]
100314a64:     	add	x10, x11, x10
100314a68:     	sub	x9, x10, x9
100314a6c:     	str	x9, [x8, #0x28]
100314a70:     	lsr	x8, x28, #58
100314a74:     	ldr	x19, [sp, #0x128]
100314a78:     	cbz	x8, 0x100314ab8 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x1a8>
100314a7c:     	b	0x100314dcc <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4bc>
100314a80:     	adrp	x9, 0x1029c5000 <__MergedGlobals.22838+0xa80>
100314a84:     	add	x9, x9, #0x690
100314a88:     	ldr	x8, [sp, #0x128]
100314a8c:     	ldp	x10, x0, [x9]
100314a90:     	adrp	x11, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314a94:     	ldr	x11, [x11, #0x608]
100314a98:     	mov	x9, x10
100314a9c:     	mov	x10, x0
100314aa0:     	b	0x100314d10 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x400>
100314aa4:     	mov	w0, #0x1                ; =1
100314aa8:     	bl	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100314aac:     	lsr	x8, x28, #58
100314ab0:     	ldr	x19, [sp, #0x128]
100314ab4:     	cbnz	x8, 0x100314dcc <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4bc>
100314ab8:     	lsl	x21, x28, #6
100314abc:     	mov	x8, #0x1                ; =1
100314ac0:     	movk	x8, #0x1, lsl #48
100314ac4:     	cmp	x21, x8
100314ac8:     	b.hs	0x100314dcc <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4bc>
100314acc:     	stp	x25, x24, [sp, #0x18]
100314ad0:     	str	x22, [sp, #0x10]
100314ad4:     	cbz	x21, 0x100314af8 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x1e8>
100314ad8:     	mov	x0, x21
100314adc:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
100314ae0:     	cbz	x0, 0x100314de4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4d4>
100314ae4:     	mov	x22, x0
100314ae8:     	mov	x0, x21
100314aec:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100314af0:     	mov	x8, x22
100314af4:     	b	0x100314b00 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x1f0>
100314af8:     	adrp	x8, 0x1029c4000 <__MergedGlobals.22837+0xa80>
100314afc:     	add	x8, x8, #0xb70
100314b00:     	dup.2d	v0, x28
100314b04:     	str	x8, [x19, #0x10]
100314b08:     	mov	x25, xzr
100314b0c:     	sub	x24, x29, #0xc8
100314b10:     	stur	q0, [x19, #0x18]
100314b14:     	ldr	x8, [x20, #0x8]
100314b18:     	ldp	x9, x22, [x8, #0x10]
100314b1c:     	bic	x26, x22, x22, asr #63
100314b20:     	add	x21, x9, #0x10
100314b24:     	stp	x22, x28, [sp]
100314b28:     	b	0x100314b34 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x224>
100314b2c:     	add	x21, x21, #0x18
100314b30:     	add	x25, x25, #0x1
100314b34:     	cmp	x26, x25
100314b38:     	b.eq	0x100314c44 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x334>
100314b3c:     	cmp	x22, x25
100314b40:     	b.eq	0x100314da8 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x498>
100314b44:     	ldp	x9, x10, [x21, #-0x10]
100314b48:     	ldr	x11, [x21]
100314b4c:     	str	xzr, [sp, #0x180]
100314b50:     	str	xzr, [sp, #0x188]
100314b54:     	str	xzr, [sp, #0x190]
100314b58:     	str	x9, [sp, #0x180]
100314b5c:     	str	x10, [sp, #0x188]
100314b60:     	str	x11, [sp, #0x190]
100314b64:     	ldr	x8, [sp, #0x128]
100314b68:     	ldp	x19, x23, [x8, #0x10]
100314b6c:     	ldr	x8, [sp, #0x128]
100314b70:     	cbz	x8, 0x100314ce4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x3d4>
100314b74:     	ldr	x0, [x8, #0x8]
100314b78:     	ldr	x1, [sp, #0x190]
100314b7c:     	cmp	x28, x25
100314b80:     	b.eq	0x100314db4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4a4>
100314b84:     	add	x8, x27, x25, lsl #6
100314b88:     	mov	x2, x24
100314b8c:     	ldp	q0, q1, [x8]
100314b90:     	ldr	w11, [x8, #0x30]
100314b94:     	ldp	x9, x10, [x8, #0x20]
100314b98:     	ldr	x8, [x8, #0x38]
100314b9c:     	stur	w11, [x29, #-0x98]
100314ba0:     	stur	x8, [x29, #-0x90]
100314ba4:     	add	x8, sp, #0x198
100314ba8:     	stur	q0, [x29, #-0xc8]
100314bac:     	stur	q1, [x29, #-0xb8]
100314bb0:     	stp	x9, x10, [x29, #-0xa8]
100314bb4:     	bl	0x10044b744 <_github.com/cpunion/wasmvm/internal/component/canonical.(*Codec).Clone>
100314bb8:     	cmp	x25, x23
100314bbc:     	b.hs	0x100314dc0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4b0>
100314bc0:     	ldr	x8, [sp, #0x1a8]
100314bc4:     	add	x9, x19, x25, lsl #6
100314bc8:     	add	x10, sp, #0x99
100314bcc:     	ldur	q0, [x10, #0xff]
100314bd0:     	add	x10, sp, #0x198
100314bd4:     	str	x8, [x9, #0x10]
100314bd8:     	ldr	w8, [sp, #0x1c8]
100314bdc:     	ldur	q1, [x10, #0x18]
100314be0:     	ldr	x10, [sp, #0x1c0]
100314be4:     	str	q0, [x9]
100314be8:     	str	w8, [x9, #0x30]
100314bec:     	ldp	x11, x8, [sp, #0x1d0]
100314bf0:     	str	x10, [x9, #0x28]
100314bf4:     	ldr	x10, [sp, #0x1e0]
100314bf8:     	stur	q1, [x9, #0x18]
100314bfc:     	str	x11, [x9, #0x38]
100314c00:     	str	x10, [sp, #0x138]
100314c04:     	str	x8, [sp, #0x130]
100314c08:     	ldr	x8, [sp, #0x138]
100314c0c:     	ldr	x8, [sp, #0x130]
100314c10:     	cbz	x8, 0x100314b2c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x21c>
100314c14:     	ldr	x8, [x8, #0x8]
100314c18:     	cbz	x8, 0x100314b2c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x21c>
100314c1c:     	adrp	x0, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314c20:     	ldr	x8, [sp, #0x128]
100314c24:     	adrp	x22, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314c28:     	ldr	x0, [x0, #0x618]
100314c2c:     	ldr	x10, [sp, #0x138]
100314c30:     	ldr	x9, [sp, #0x130]
100314c34:     	ldp	x25, x24, [sp, #0x18]
100314c38:     	ldr	x22, [x22, #0x5f8]
100314c3c:     	mov	x11, x0
100314c40:     	b	0x100314d10 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x400>
100314c44:     	ldr	x8, [sp, #0x128]
100314c48:     	ldp	x25, x24, [sp, #0x18]
100314c4c:     	adrp	x22, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314c50:     	ldr	x8, [x8, #0x8]
100314c54:     	ldr	x8, [x8, #0x60]
100314c58:     	ldr	x22, [x22, #0x5f8]
100314c5c:     	cbz	x8, 0x100314cf0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x3e0>
100314c60:     	ldr	x8, [x8, #0x8]
100314c64:     	cbz	x8, 0x100314cf0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x3e0>
100314c68:     	ldr	x8, [sp, #0x128]
100314c6c:     	cbz	x8, 0x100314ce4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x3d4>
100314c70:     	ldr	x9, [x20, #0x8]
100314c74:     	ldr	x0, [x8, #0x8]
100314c78:     	sub	x1, x29, #0x70
100314c7c:     	sub	x2, x29, #0x88
100314c80:     	ldr	x8, [x9, #0x10]
100314c84:     	ldr	x10, [sp, #0x128]
100314c88:     	ldur	q0, [x9, #0x18]
100314c8c:     	stur	x8, [x29, #-0x70]
100314c90:     	add	x8, sp, #0x198
100314c94:     	ldr	x9, [x10, #0x10]
100314c98:     	stur	q0, [x8, #0xb0]
100314c9c:     	ldur	q0, [x10, #0x18]
100314ca0:     	stur	x9, [x29, #-0x88]
100314ca4:     	stur	q0, [x8, #0x98]
100314ca8:     	bl	0x10044b478 <_github.com/cpunion/wasmvm/internal/component/canonical.(*Codec).AcceptParameters>
100314cac:     	str	x0, [sp, #0x130]
100314cb0:     	str	x1, [sp, #0x138]
100314cb4:     	ldr	x8, [sp, #0x138]
100314cb8:     	ldr	x8, [sp, #0x130]
100314cbc:     	cbz	x8, 0x100314cf0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x3e0>
100314cc0:     	ldr	x8, [x8, #0x8]
100314cc4:     	cbz	x8, 0x100314cf0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x3e0>
100314cc8:     	adrp	x0, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314ccc:     	ldr	x8, [sp, #0x128]
100314cd0:     	ldr	x0, [x0, #0x600]
100314cd4:     	ldr	x10, [sp, #0x138]
100314cd8:     	ldr	x9, [sp, #0x130]
100314cdc:     	mov	x11, x0
100314ce0:     	b	0x100314d10 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x400>
100314ce4:     	mov	w0, #0x1                ; =1
100314ce8:     	bl	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100314cec:     	b	0x100314d88 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x478>
100314cf0:     	ldr	x9, [sp, #0x10]
100314cf4:     	mov	w8, #0x1                ; =1
100314cf8:     	adrp	x11, 0x10076d000 <dyld_stub_binder+0x10076d000>
100314cfc:     	mov	x10, xzr
100314d00:     	strb	w8, [x9]
100314d04:     	mov	x9, xzr
100314d08:     	ldr	x8, [sp, #0x128]
100314d0c:     	ldr	x11, [x11, #0x610]
100314d10:     	str	x8, [sp, #0x128]
100314d14:     	str	x10, [sp, #0x138]
100314d18:     	str	x9, [sp, #0x130]
100314d1c:     	str	x11, [sp, #0x48]
100314d20:     	ldr	w8, [sp, #0x30]
100314d24:     	str	x22, [sp, #0x40]
100314d28:     	tbz	w8, #0x0, 0x100314d58 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x448>
100314d2c:     	ldr	x8, [sp, #0x50]
100314d30:     	cbz	x8, 0x100314d58 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x448>
100314d34:     	ldp	x9, x20, [x8, #0x10]
100314d38:     	ldr	x10, [x8]
100314d3c:     	str	x10, [sp, #0x50]
100314d40:     	blr	x9
100314d44:     	ldr	x19, [sp, #0x38]
100314d48:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100314d4c:     	str	x19, [x0, #0x10]
100314d50:     	ldr	x8, [sp, #0x48]
100314d54:     	br	x8
100314d58:     	ldr	x19, [sp, #0x38]
100314d5c:     	bl	0x10058babc <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100314d60:     	str	x19, [x0, #0x10]
100314d64:     	ldr	x8, [sp, #0x48]
100314d68:     	br	x8
100314d6c:     	b	0x100314d74 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x464>
100314d70:     	b	0x100314d74 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x464>
100314d74:     	ldr	x8, [sp, #0x128]
100314d78:     	ldr	x9, [sp, #0x138]
100314d7c:     	ldr	x10, [sp, #0x130]
100314d80:     	stp	x8, x10, [x24]
100314d84:     	str	x9, [x24, #0x10]
100314d88:     	add	sp, sp, #0x260
100314d8c:     	ldp	x29, x30, [sp, #0x50]
100314d90:     	ldp	x20, x19, [sp, #0x40]
100314d94:     	ldp	x22, x21, [sp, #0x30]
100314d98:     	ldp	x24, x23, [sp, #0x20]
100314d9c:     	ldp	x26, x25, [sp, #0x10]
100314da0:     	ldp	x28, x27, [sp], #0x60
100314da4:     	ret
100314da8:     	ldr	x0, [sp]
100314dac:     	mov	x1, x0
100314db0:     	bl	0x10058725c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100314db4:     	ldr	x0, [sp, #0x8]
100314db8:     	mov	x1, x0
100314dbc:     	bl	0x10058725c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100314dc0:     	mov	x0, x25
100314dc4:     	mov	x1, x23
100314dc8:     	bl	0x10058725c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100314dcc:     	mov	x8, #0x1                ; =1
100314dd0:     	movk	x8, #0x400, lsl #32
100314dd4:     	cmp	x28, x8
100314dd8:     	b.lo	0x100314de0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4d0>
100314ddc:     	bl	0x100597468 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicmakeslicelen>
100314de0:     	bl	0x1005987e8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicmakeslicecap>
100314de4:     	adrp	x0, 0x1008fe000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0xa8>
100314de8:     	add	x0, x0, #0xb08
100314dec:     	adrp	x1, 0x1008f5000 <__llgo_struct$RSTTp_pTKglBmcdy0CMmgLp9HSGRvgD8UwNIoMFFyOg$fields+0xc0>
100314df0:     	add	x1, x1, #0x3c0
100314df4:     	bl	0x100586f50 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100314df8:     	brk	#0x1

0000000100315110 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall>:
100315110:     	stp	x22, x21, [sp, #-0x30]!
100315114:     	stp	x20, x19, [sp, #0x10]
100315118:     	stp	x29, x30, [sp, #0x20]
10031511c:     	add	x29, sp, #0x20
100315120:     	ldr	x8, [x0, #0x30]
100315124:     	mov	x19, x0
100315128:     	mov	x20, x1
10031512c:     	cbz	x8, 0x1003151b4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0xa4>
100315130:     	ldr	x9, [x8, #0x40]
100315134:     	cbz	x9, 0x100315140 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0x30>
100315138:     	ldr	x9, [x9]
10031513c:     	cbnz	x9, 0x100315148 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0x38>
100315140:     	ldr	x8, [x8, #0x50]
100315144:     	cbz	x8, 0x1003151b4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0xa4>
100315148:     	mov	w0, #0x198              ; =408
10031514c:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
100315150:     	cbz	x0, 0x100315238 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0x128>
100315154:     	mov	x21, x0
100315158:     	mov	w0, #0x198              ; =408
10031515c:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100315160:     	cbz	x19, 0x10031521c <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0x10c>
100315164:     	ldr	x8, [x19]
100315168:     	ldr	x9, [x19, #0x30]
10031516c:     	add	x22, x21, #0x98
100315170:     	stp	xzr, xzr, [x21, #0x128]
100315174:     	stp	x9, xzr, [x21, #0x118]
100315178:     	add	x9, x21, #0x108
10031517c:     	stp	x8, x20, [x21, #0x108]
100315180:     	adrp	x8, 0x10085f000 <__llgo_struct$XUM6JFti7FbDy-nBoXf5uS_r5VXpqQlSkMJlzwrLrn0$fields+0x168>
100315184:     	add	x8, x8, #0x620
100315188:     	stp	xzr, xzr, [x21, #0x138]
10031518c:     	stp	xzr, xzr, [x21, #0x148]
100315190:     	stp	xzr, xzr, [x21, #0x158]
100315194:     	stp	xzr, xzr, [x21, #0x188]
100315198:     	str	xzr, [x21, #0x180]
10031519c:     	str	wzr, [x21, #0x178]
1003151a0:     	str	xzr, [x21, #0x170]
1003151a4:     	strb	wzr, [x21, #0x168]
1003151a8:     	stp	x8, x9, [x21, #0xf8]
1003151ac:     	stp	x19, x22, [x21]
1003151b0:     	b	0x1003151d8 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0xc8>
1003151b4:     	mov	w0, #0x108              ; =264
1003151b8:     	bl	0x1005a1270 <dyld_stub_binder+0x1005a1270>
1003151bc:     	cbz	x0, 0x100315238 <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0x128>
1003151c0:     	mov	x21, x0
1003151c4:     	mov	w0, #0x108              ; =264
1003151c8:     	bl	0x100587164 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1003151cc:     	add	x22, x21, #0x98
1003151d0:     	stp	x19, x22, [x21]
1003151d4:     	cbz	x19, 0x10031521c <_github.com/cpunion/wasmvm/pkg/component.(*Function).newHostCall+0x10c>
1003151d8:     	ldr	x19, [x19]
1003151dc:     	mov	x0, x20
1003151e0:     	bl	0x10033254c <_github.com/cpunion/wasmvm/pkg/vm.(*Caller).Context>
1003151e4:     	ldr	x8, [x19, #0x168]
1003151e8:     	stp	x0, x1, [x21, #0x98]
1003151ec:     	strh	wzr, [x21, #0xb8]
1003151f0:     	stp	x8, xzr, [x21, #0xc0]
1003151f4:     	stp	xzr, xzr, [x21, #0xd0]
1003151f8:     	stp	xzr, xzr, [x21, #0xa8]
1003151fc:     	ldr	x8, [x19, #0x188]
100315200:     	ldr	x9, [x19, #0x160]
100315204:     	stp	x8, x9, [x22, #0x48]
100315208:     	ldp	x29, x30, [sp, #0x20]
10031520c:     	mov	x0, x21
100315210:     	ldp	x20, x19, [sp, #0x10]
100315214:     	ldp	x22, x21, [sp], #0x30
100315218:     	ret
10031521c:     	mov	w0, #0x1                ; =1
100315220:     	bl	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100315224:     	ldp	x29, x30, [sp, #0x20]
100315228:     	mov	x0, x21
10031522c:     	ldp	x20, x19, [sp, #0x10]
100315230:     	ldp	x22, x21, [sp], #0x30
100315234:     	ret
100315238:     	adrp	x0, 0x1008fe000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0xa8>
10031523c:     	add	x0, x0, #0xb08
100315240:     	adrp	x1, 0x1008f5000 <__llgo_struct$RSTTp_pTKglBmcdy0CMmgLp9HSGRvgD8UwNIoMFFyOg$fields+0xc0>
100315244:     	add	x1, x1, #0x3c0
100315248:     	bl	0x100586f50 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10031524c:     	brk	#0x1

0000000100315250 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1>:
100315250:     	stp	x22, x21, [sp, #-0x30]!
100315254:     	stp	x20, x19, [sp, #0x10]
100315258:     	stp	x29, x30, [sp, #0x20]
10031525c:     	add	x29, sp, #0x20
100315260:     	ldr	x21, [x20]
100315264:     	cbz	x21, 0x100315290 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x40>
100315268:     	ldr	x8, [x21]
10031526c:     	ldp	x22, x19, [x20, #0x8]
100315270:     	ldrb	w9, [x8, #0x80]
100315274:     	tbz	w9, #0x0, 0x1003152a4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x54>
100315278:     	ldrb	w8, [x22]
10031527c:     	tbz	w8, #0x0, 0x1003152fc <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0xac>
100315280:     	ldp	x29, x30, [sp, #0x20]
100315284:     	ldp	x20, x19, [sp, #0x10]
100315288:     	ldp	x22, x21, [sp], #0x30
10031528c:     	ret
100315290:     	ldp	x29, x30, [sp, #0x20]
100315294:     	mov	w0, #0x1                ; =1
100315298:     	ldp	x20, x19, [sp, #0x10]
10031529c:     	ldp	x22, x21, [sp], #0x30
1003152a0:     	b	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1003152a4:     	cbz	x8, 0x1003152ec <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x9c>
1003152a8:     	ldp	x9, x10, [x8]
1003152ac:     	ldr	x11, [x8, #0x88]
1003152b0:     	ldr	x9, [x9]
1003152b4:     	ldr	x12, [x10, #0x58]
1003152b8:     	ldr	x10, [x10, #0x40]
1003152bc:     	ldp	x13, x14, [x9, #0x1b8]
1003152c0:     	sub	x11, x12, x11
1003152c4:     	add	x11, x11, x13
1003152c8:     	str	x11, [x9, #0x1b8]
1003152cc:     	ldr	x11, [x8, #0x90]
1003152d0:     	sub	x11, x10, x11
1003152d4:     	add	x11, x11, x14
1003152d8:     	str	x11, [x9, #0x1c0]
1003152dc:     	stp	x12, x10, [x8, #0x88]
1003152e0:     	ldrb	w8, [x22]
1003152e4:     	tbnz	w8, #0x0, 0x100315280 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x30>
1003152e8:     	b	0x1003152fc <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0xac>
1003152ec:     	mov	w0, #0x1                ; =1
1003152f0:     	bl	0x10058b834 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1003152f4:     	ldrb	w8, [x22]
1003152f8:     	tbnz	w8, #0x0, 0x100315280 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x30>
1003152fc:     	ldp	x3, x4, [x19]
100315300:     	mov	w2, wzr
100315304:     	ldr	x0, [x21]
100315308:     	ldr	x1, [x20, #0x18]
10031530c:     	bl	0x10030c11c <_github.com/cpunion/wasmvm/pkg/component.(*hostCall).finish>
100315310:     	stp	x0, x1, [x19]
100315314:     	ldp	x29, x30, [sp, #0x20]
100315318:     	ldp	x20, x19, [sp, #0x10]
10031531c:     	ldp	x22, x21, [sp], #0x30
100315320:     	ret
