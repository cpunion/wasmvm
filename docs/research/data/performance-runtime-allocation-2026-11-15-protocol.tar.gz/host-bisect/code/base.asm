
/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/profile-gap-0539ea6e-20261115/llgo-main-runner:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100314cd4 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec>:
100314cd4:     	stp	x24, x23, [sp, #-0x40]!
100314cd8:     	stp	x22, x21, [sp, #0x10]
100314cdc:     	stp	x20, x19, [sp, #0x20]
100314ce0:     	stp	x29, x30, [sp, #0x30]
100314ce4:     	add	x29, sp, #0x30
100314ce8:     	mov	x19, x3
100314cec:     	mov	x20, x2
100314cf0:     	mov	x21, x1
100314cf4:     	mov	x22, x0
100314cf8:     	cbz	x2, 0x100314d70 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x9c>
100314cfc:     	ldr	x8, [x20, #0x40]
100314d00:     	cbz	x8, 0x100314d0c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x38>
100314d04:     	ldr	x8, [x8]
100314d08:     	cbnz	x8, 0x100314d14 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x40>
100314d0c:     	ldr	x8, [x20, #0x50]
100314d10:     	cbz	x8, 0x100314d70 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0x9c>
100314d14:     	mov	w0, #0x100              ; =256
100314d18:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
100314d1c:     	cbz	x0, 0x100314dbc <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0xe8>
100314d20:     	mov	x23, x0
100314d24:     	mov	w0, #0x100              ; =256
100314d28:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100314d2c:     	mov	x8, x23
100314d30:     	adrp	x9, 0x10085f000 <__llgo_func$Gs_vYg-cM_0J7HLNMA_DM1mkoR-ayysUfsb_sMJpYgA+0x10>
100314d34:     	add	x9, x9, #0x348
100314d38:     	str	x22, [x8, #0x70]!
100314d3c:     	stp	xzr, xzr, [x8, #0x28]
100314d40:     	stp	xzr, xzr, [x8, #0x38]
100314d44:     	stp	xzr, xzr, [x8, #0x50]
100314d48:     	str	xzr, [x8, #0x48]
100314d4c:     	stp	xzr, xzr, [x8, #0x80]
100314d50:     	str	xzr, [x8, #0x78]
100314d54:     	str	wzr, [x8, #0x70]
100314d58:     	str	xzr, [x8, #0x68]
100314d5c:     	strb	wzr, [x8, #0x60]
100314d60:     	stp	xzr, xzr, [x8, #0x18]
100314d64:     	stp	x21, x20, [x8, #0x8]
100314d68:     	stp	x9, x8, [x8, #-0x10]
100314d6c:     	b	0x100314d88 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0xb4>
100314d70:     	mov	w0, #0x70               ; =112
100314d74:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
100314d78:     	cbz	x0, 0x100314dbc <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec+0xe8>
100314d7c:     	mov	x23, x0
100314d80:     	mov	w0, #0x70               ; =112
100314d84:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100314d88:     	mov	x0, x22
100314d8c:     	mov	x1, x23
100314d90:     	mov	x2, x21
100314d94:     	mov	x3, x20
100314d98:     	mov	x4, x19
100314d9c:     	mov	w5, #0x1                ; =1
100314da0:     	bl	0x1003153e0 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec>
100314da4:     	ldp	x29, x30, [sp, #0x30]
100314da8:     	mov	x0, x23
100314dac:     	ldp	x20, x19, [sp, #0x20]
100314db0:     	ldp	x22, x21, [sp, #0x10]
100314db4:     	ldp	x24, x23, [sp], #0x40
100314db8:     	ret
100314dbc:     	adrp	x0, 0x1008fe000 <_[8]_llgo_Pointer+0x20>
100314dc0:     	add	x0, x0, #0x828
100314dc4:     	adrp	x1, 0x1008f5000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.boundsErrorFmts+0x30>
100314dc8:     	add	x1, x1, #0xe0
100314dcc:     	bl	0x100586df8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100314dd0:     	brk	#0x1

00000001003153e0 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec>:
1003153e0:     	sub	sp, sp, #0x90
1003153e4:     	stp	x28, x27, [sp, #0x30]
1003153e8:     	stp	x26, x25, [sp, #0x40]
1003153ec:     	stp	x24, x23, [sp, #0x50]
1003153f0:     	stp	x22, x21, [sp, #0x60]
1003153f4:     	stp	x20, x19, [sp, #0x70]
1003153f8:     	stp	x29, x30, [sp, #0x80]
1003153fc:     	add	x29, sp, #0x80
100315400:     	cbz	x1, 0x1003155f0 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x210>
100315404:     	mov	x21, x0
100315408:     	mov	x0, x2
10031540c:     	mov	w24, w5
100315410:     	mov	x20, x4
100315414:     	mov	x22, x3
100315418:     	mov	x19, x1
10031541c:     	mov	x23, x2
100315420:     	bl	0x100332408 <_github.com/cpunion/wasmvm/pkg/vm.(*Caller).Context>
100315424:     	ldr	x8, [x21, #0x168]
100315428:     	stp	x0, x1, [x19]
10031542c:     	strh	wzr, [x19, #0x20]
100315430:     	stp	x8, xzr, [x19, #0x28]
100315434:     	stp	xzr, xzr, [x19, #0x38]
100315438:     	stp	xzr, xzr, [x19, #0x10]
10031543c:     	cbz	x20, 0x1003155b8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x1d8>
100315440:     	ldrb	w8, [x20, #0x78]
100315444:     	ldrb	w9, [x20, #0x50]
100315448:     	strb	w8, [x19, #0x20]
10031544c:     	strb	w9, [x19, #0x21]
100315450:     	ldr	x8, [x20, #0x58]
100315454:     	cbz	x8, 0x100315504 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x124>
100315458:     	ldr	x1, [x22, #0x58]
10031545c:     	mov	w8, #0x102              ; =258
100315460:     	adrp	x0, 0x100855000 <__llgo_func$0IU9SSI5Uk4AojYQVfrjYnhVUEUHGCxIYhE1I70gQSA+0x60>
100315464:     	add	x0, x0, #0xce8
100315468:     	add	x2, sp, #0x2c
10031546c:     	stp	x23, x22, [sp, #0x18]
100315470:     	strh	w8, [sp, #0x2c]
100315474:     	bl	0x10058f6b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MapAccess1>
100315478:     	ldr	x9, [x20, #0x58]
10031547c:     	mov	x8, x0
100315480:     	ldr	x1, [x0, #0x8]
100315484:     	ldr	w0, [x9]
100315488:     	cmp	x1, x0
10031548c:     	b.ls	0x100315614 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x234>
100315490:     	mov	w9, #0x78               ; =120
100315494:     	ldr	x8, [x8]
100315498:     	umaddl	x8, w0, w9, x8
10031549c:     	mov	w0, #0x48               ; =72
1003154a0:     	ldp	x9, x10, [x8, #0x38]
1003154a4:     	ldr	x27, [x8, #0x20]
1003154a8:     	ldp	x23, x22, [x8, #0x8]
1003154ac:     	ldrb	w28, [x8, #0x18]
1003154b0:     	stp	x9, x10, [sp, #0x8]
1003154b4:     	ldp	x26, x9, [x8, #0x28]
1003154b8:     	str	x9, [sp]
1003154bc:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
1003154c0:     	cbz	x0, 0x100315618 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x238>
1003154c4:     	mov	x25, x0
1003154c8:     	mov	w0, #0x48               ; =72
1003154cc:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1003154d0:     	str	x22, [x25, #0x10]
1003154d4:     	ldp	x8, x22, [sp, #0x18]
1003154d8:     	strb	w28, [x25, #0x18]
1003154dc:     	stp	x8, x23, [x25]
1003154e0:     	mov	x23, x8
1003154e4:     	ldp	x9, x8, [sp]
1003154e8:     	stp	x27, x26, [x25, #0x20]
1003154ec:     	stp	x9, x8, [x25, #0x30]
1003154f0:     	ldr	x8, [sp, #0x10]
1003154f4:     	str	x8, [x25, #0x40]
1003154f8:     	adrp	x8, 0x10085f000 <__llgo_func$Gs_vYg-cM_0J7HLNMA_DM1mkoR-ayysUfsb_sMJpYgA+0x10>
1003154fc:     	add	x8, x8, #0x728
100315500:     	stp	x8, x25, [x19, #0x10]
100315504:     	tbz	w24, #0x0, 0x1003155b8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x1d8>
100315508:     	ldr	x8, [x20, #0x60]
10031550c:     	cbz	x8, 0x1003155b8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x1d8>
100315510:     	mov	w0, #0x40               ; =64
100315514:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
100315518:     	cbz	x0, 0x100315618 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x238>
10031551c:     	mov	x24, x0
100315520:     	mov	w0, #0x40               ; =64
100315524:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100315528:     	ldr	x1, [x22, #0x58]
10031552c:     	mov	w8, #0x100              ; =256
100315530:     	adrp	x0, 0x100855000 <__llgo_func$0IU9SSI5Uk4AojYQVfrjYnhVUEUHGCxIYhE1I70gQSA+0x60>
100315534:     	add	x0, x0, #0xce8
100315538:     	add	x2, sp, #0x2e
10031553c:     	strh	w8, [sp, #0x2e]
100315540:     	bl	0x10058f6b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MapAccess1>
100315544:     	ldr	x9, [x20, #0x60]
100315548:     	mov	x8, x0
10031554c:     	ldr	x1, [x0, #0x8]
100315550:     	ldr	w0, [x9]
100315554:     	cmp	x1, x0
100315558:     	b.ls	0x100315614 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x234>
10031555c:     	mov	w9, #0x78               ; =120
100315560:     	ldr	x8, [x8]
100315564:     	umaddl	x8, w0, w9, x8
100315568:     	mov	w0, #0x20               ; =32
10031556c:     	ldp	q2, q0, [x8, #0x20]
100315570:     	ldr	x9, [x8, #0x40]
100315574:     	ldr	x10, [x8, #0x8]
100315578:     	ldr	q1, [x8, #0x10]
10031557c:     	str	x9, [x24, #0x38]
100315580:     	stur	q0, [x24, #0x28]
100315584:     	stur	q2, [x24, #0x18]
100315588:     	stur	q1, [x24, #0x8]
10031558c:     	str	x10, [x24]
100315590:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
100315594:     	cbz	x0, 0x100315618 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec+0x238>
100315598:     	mov	x25, x0
10031559c:     	mov	w0, #0x20               ; =32
1003155a0:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1003155a4:     	adr	x8, 0x100315784 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1>
1003155a8:     	nop
1003155ac:     	stp	x22, x20, [x25]
1003155b0:     	stp	x23, x24, [x25, #0x10]
1003155b4:     	stp	x8, x25, [x19, #0x30]
1003155b8:     	mov	x0, x21
1003155bc:     	mov	x1, x22
1003155c0:     	mov	x2, x20
1003155c4:     	bl	0x100315630 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).canonicalLayouts>
1003155c8:     	ldr	x8, [x21, #0x160]
1003155cc:     	ldp	x29, x30, [sp, #0x80]
1003155d0:     	ldp	x22, x21, [sp, #0x60]
1003155d4:     	stp	x0, x8, [x19, #0x48]
1003155d8:     	ldp	x20, x19, [sp, #0x70]
1003155dc:     	ldp	x24, x23, [sp, #0x50]
1003155e0:     	ldp	x26, x25, [sp, #0x40]
1003155e4:     	ldp	x28, x27, [sp, #0x30]
1003155e8:     	add	sp, sp, #0x90
1003155ec:     	ret
1003155f0:     	ldp	x29, x30, [sp, #0x80]
1003155f4:     	mov	w0, #0x1                ; =1
1003155f8:     	ldp	x20, x19, [sp, #0x70]
1003155fc:     	ldp	x22, x21, [sp, #0x60]
100315600:     	ldp	x24, x23, [sp, #0x50]
100315604:     	ldp	x26, x25, [sp, #0x40]
100315608:     	ldp	x28, x27, [sp, #0x30]
10031560c:     	add	sp, sp, #0x90
100315610:     	b	0x10058b6dc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100315614:     	bl	0x1005886b8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100315618:     	adrp	x0, 0x1008fe000 <_[8]_llgo_Pointer+0x20>
10031561c:     	add	x0, x0, #0x828
100315620:     	adrp	x1, 0x1008f5000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.boundsErrorFmts+0x30>
100315624:     	add	x1, x1, #0xe0
100315628:     	bl	0x100586df8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10031562c:     	brk	#0x1

0000000100315784 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1>:
100315784:     	stp	x28, x27, [sp, #-0x60]!
100315788:     	stp	x26, x25, [sp, #0x10]
10031578c:     	stp	x24, x23, [sp, #0x20]
100315790:     	stp	x22, x21, [sp, #0x30]
100315794:     	stp	x20, x19, [sp, #0x40]
100315798:     	stp	x29, x30, [sp, #0x50]
10031579c:     	add	x29, sp, #0x50
1003157a0:     	sub	sp, sp, #0x2d0
1003157a4:     	stp	x8, x3, [sp, #0x28]
1003157a8:     	ldr	x28, [x20, #0x18]
1003157ac:     	mov	x24, x2
1003157b0:     	str	xzr, [sp, #0x138]
1003157b4:     	mov	x27, x1
1003157b8:     	mov	x26, x0
1003157bc:     	str	xzr, [sp, #0x140]
1003157c0:     	str	xzr, [sp, #0x148]
1003157c4:     	str	xzr, [sp, #0x150]
1003157c8:     	ldr	x9, [x20]
1003157cc:     	ldr	x21, [x9, #0x20]
1003157d0:     	str	x21, [sp, #0x150]
1003157d4:     	ldrb	w22, [x9, #0x28]
1003157d8:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
1003157dc:     	add	x25, sp, #0x74
1003157e0:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
1003157e4:     	ldr	x9, [x0, #0x10]
1003157e8:     	stp	x25, xzr, [sp, #0x40]
1003157ec:     	ldr	x8, [x8, #0x558]
1003157f0:     	mov	x19, x9
1003157f4:     	stp	x9, x8, [sp, #0x50]
1003157f8:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
1003157fc:     	add	x8, sp, #0x40
100315800:     	mov	w1, wzr
100315804:     	str	x8, [x0, #0x10]
100315808:     	mov	x0, x25
10031580c:     	str	xzr, [sp, #0x68]
100315810:     	bl	0x1005a10a0 <dyld_stub_binder+0x1005a10a0>
100315814:     	adrp	x23, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315818:     	ldr	x23, [x23, #0x560]
10031581c:     	cbz	w0, 0x100315844 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0xc0>
100315820:     	ldr	x8, [sp, #0x58]
100315824:     	str	x23, [sp, #0x60]
100315828:     	br	x8
10031582c:     	adrp	x9, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315830:     	ldrb	w8, [sp, #0x48]
100315834:     	ldr	x9, [x9, #0x570]
100315838:     	str	x9, [sp, #0x58]
10031583c:     	tbnz	w8, #0x1, 0x100315b78 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3f4>
100315840:     	b	0x100315b90 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x40c>
100315844:     	stp	x27, x26, [sp, #0x18]
100315848:     	tbz	w22, #0x0, 0x100315874 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0xf0>
10031584c:     	mov	w8, #0x40               ; =64
100315850:     	ldr	x22, [x20]
100315854:     	mov	w0, w8
100315858:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
10031585c:     	cbz	x0, 0x100315c2c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x4a8>
100315860:     	mov	w8, #0x40               ; =64
100315864:     	mov	x23, x0
100315868:     	mov	w0, w8
10031586c:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100315870:     	str	x23, [x22, #0x20]
100315874:     	ldr	x10, [sp, #0x68]
100315878:     	ldr	x9, [x20]
10031587c:     	adr	x11, 0x100315c44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$1>
100315880:     	nop
100315884:     	str	x19, [sp, #0x38]
100315888:     	stp	x10, xzr, [sp, #0x168]
10031588c:     	mov	w10, #0x1               ; =1
100315890:     	stp	x9, x21, [sp, #0x158]
100315894:     	strb	w10, [x9, #0x69]
100315898:     	add	x9, sp, #0x158
10031589c:     	stp	x11, x9, [sp, #0x178]
1003158a0:     	ldp	x12, x11, [x20]
1003158a4:     	add	x9, sp, #0x168
1003158a8:     	stp	x12, x9, [sp, #0x188]
1003158ac:     	ldr	x12, [sp, #0x48]
1003158b0:     	adr	x9, 0x100315c50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$2>
1003158b4:     	nop
1003158b8:     	ldrb	w25, [x11, #0x78]
1003158bc:     	stp	x10, x9, [sp, #0x198]
1003158c0:     	add	x10, sp, #0x188
1003158c4:     	orr	x9, x12, #0x3
1003158c8:     	str	x10, [sp, #0x1a8]
1003158cc:     	add	x10, sp, #0x190
1003158d0:     	str	x9, [sp, #0x48]
1003158d4:     	str	x10, [sp, #0x68]
1003158d8:     	str	xzr, [sp, #0x1c8]
1003158dc:     	str	xzr, [sp, #0x1c0]
1003158e0:     	str	xzr, [sp, #0x1b8]
1003158e4:     	str	xzr, [sp, #0x1b0]
1003158e8:     	ldp	x8, x10, [x28, #0x30]
1003158ec:     	ldr	x20, [x20, #0x10]
1003158f0:     	ldp	x23, x26, [x28]
1003158f4:     	ldrb	w27, [x28, #0x10]
1003158f8:     	stp	x8, x10, [sp, #0x8]
1003158fc:     	ldp	x22, x8, [x28, #0x20]
100315900:     	ldr	x28, [x28, #0x18]
100315904:     	str	x8, [sp]
100315908:     	mov	w8, #0x40               ; =64
10031590c:     	mov	w0, w8
100315910:     	bl	0x1005a1130 <dyld_stub_binder+0x1005a1130>
100315914:     	cbz	x0, 0x100315c2c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x4a8>
100315918:     	mov	w8, #0x7e               ; =126
10031591c:     	cmp	w25, #0x0
100315920:     	mov	x25, x0
100315924:     	cinc	x21, x8, eq
100315928:     	sub	x19, x29, #0x100
10031592c:     	mov	w8, #0x40               ; =64
100315930:     	mov	w0, w8
100315934:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100315938:     	str	xzr, [sp, #0x1e8]
10031593c:     	sub	x0, x29, #0x100
100315940:     	mov	x1, x25
100315944:     	str	xzr, [sp, #0x1e0]
100315948:     	str	x21, [sp, #0x1e0]
10031594c:     	ldr	x9, [sp, #0x20]
100315950:     	str	x9, [sp, #0x1e8]
100315954:     	ldr	x9, [sp, #0x1e8]
100315958:     	ldr	x10, [sp, #0x1e0]
10031595c:     	stp	x10, x9, [x25]
100315960:     	str	xzr, [sp, #0x1f0]
100315964:     	str	xzr, [sp, #0x1f8]
100315968:     	str	x21, [sp, #0x1f0]
10031596c:     	ldr	x9, [sp, #0x18]
100315970:     	str	x9, [sp, #0x1f8]
100315974:     	ldr	x9, [sp, #0x1f8]
100315978:     	ldr	x10, [sp, #0x1f0]
10031597c:     	stp	x10, x9, [x25, #0x10]
100315980:     	str	xzr, [sp, #0x200]
100315984:     	str	xzr, [sp, #0x208]
100315988:     	str	x21, [sp, #0x200]
10031598c:     	str	x24, [sp, #0x208]
100315990:     	ldr	x9, [sp, #0x208]
100315994:     	ldr	x10, [sp, #0x200]
100315998:     	stp	x10, x9, [x25, #0x20]
10031599c:     	str	xzr, [sp, #0x210]
1003159a0:     	str	xzr, [sp, #0x218]
1003159a4:     	str	x21, [sp, #0x210]
1003159a8:     	ldr	x8, [sp, #0x30]
1003159ac:     	str	x8, [sp, #0x218]
1003159b0:     	ldr	x8, [sp, #0x218]
1003159b4:     	ldr	x9, [sp, #0x210]
1003159b8:     	stp	x9, x8, [x25, #0x30]
1003159bc:     	mov	w8, #0x4                ; =4
1003159c0:     	mov	w2, w8
1003159c4:     	bl	0x100309c04 <_github.com/cpunion/wasmvm/pkg/component.vmValues>
1003159c8:     	ldp	x8, x9, [sp]
1003159cc:     	sub	x1, x29, #0xa0
1003159d0:     	ldur	q0, [x19, #0x8]
1003159d4:     	sub	x2, x29, #0xb8
1003159d8:     	mov	x0, x20
1003159dc:     	stp	x23, x26, [x29, #-0xa0]
1003159e0:     	stp	x8, x9, [x29, #-0x78]
1003159e4:     	ldur	x8, [x29, #-0x100]
1003159e8:     	ldr	x9, [sp, #0x10]
1003159ec:     	sturb	w27, [x29, #-0x90]
1003159f0:     	stur	x8, [x29, #-0xb8]
1003159f4:     	sub	x8, x29, #0xe8
1003159f8:     	stp	x28, x22, [x29, #-0x88]
1003159fc:     	stur	x9, [x29, #-0x68]
100315a00:     	stur	q0, [x19, #0x50]
100315a04:     	bl	0x1003377a0 <_github.com/cpunion/wasmvm/pkg/vm.(*Caller).Call>
100315a08:     	ldp	x8, x9, [x29, #-0xe8]
100315a0c:     	ldur	q0, [x19, #0x38]
100315a10:     	ldp	x10, x11, [x29, #-0xd8]
100315a14:     	str	x8, [sp, #0x1b0]
100315a18:     	fmov	x8, d0
100315a1c:     	str	x9, [sp, #0x1b8]
100315a20:     	str	x10, [sp, #0x1c0]
100315a24:     	str	x11, [sp, #0x1c8]
100315a28:     	cbz	x8, 0x100315a50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x2cc>
100315a2c:     	ldr	x8, [x8, #0x8]
100315a30:     	cbz	x8, 0x100315a50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x2cc>
100315a34:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315a38:     	adrp	x23, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315a3c:     	mov	x0, xzr
100315a40:     	ldr	x8, [x8, #0x568]
100315a44:     	ldr	x19, [sp, #0x38]
100315a48:     	ldr	x23, [x23, #0x560]
100315a4c:     	b	0x100315b4c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c8>
100315a50:     	ldr	x8, [sp, #0x1c0]
100315a54:     	adrp	x23, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315a58:     	ldr	x9, [sp, #0x1b0]
100315a5c:     	ldr	x8, [sp, #0x1b8]
100315a60:     	ldr	x19, [sp, #0x38]
100315a64:     	ldr	x23, [x23, #0x560]
100315a68:     	cbz	x8, 0x100315c20 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x49c>
100315a6c:     	cbz	x9, 0x100315a9c <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x318>
100315a70:     	ldp	x8, x0, [x9]
100315a74:     	sub	x9, x8, #0x7b
100315a78:     	cmp	x9, #0x5
100315a7c:     	sub	w9, w8, #0x68
100315a80:     	b.hs	0x100315aa8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x324>
100315a84:     	and	w8, w9, #0xff
100315a88:     	cmp	w8, #0xe
100315a8c:     	b.lo	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315a90:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315a94:     	movi.2d	v0, #0000000000000000
100315a98:     	b	0x100315b48 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c4>
100315a9c:     	mov	w0, #0x1                ; =1
100315aa0:     	bl	0x10058b6dc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100315aa4:     	b	0x100315c00 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x47c>
100315aa8:     	and	w10, w9, #0xff
100315aac:     	cmp	w10, #0xd
100315ab0:     	b.hi	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315ab4:     	cmp	x8, #0x100
100315ab8:     	b.lo	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315abc:     	mov	x10, #0xe100            ; =57600
100315ac0:     	movk	x10, #0xffff, lsl #48
100315ac4:     	and	x11, x8, x10
100315ac8:     	cmp	x11, #0x100
100315acc:     	b.ne	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315ad0:     	tbnz	w8, #0x9, 0x100315ae4 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x360>
100315ad4:     	and	x11, x8, #0xfffffffffc00
100315ad8:     	tst	x11, #0xffffffffffff1fff
100315adc:     	b.ne	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315ae0:     	b	0x100315afc <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x378>
100315ae4:     	and	w11, w9, #0xff
100315ae8:     	cmp	w11, #0x8
100315aec:     	b.hi	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315af0:     	mov	w12, #0x10d             ; =269
100315af4:     	lsr	w11, w12, w9
100315af8:     	tbz	w11, #0x0, 0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315afc:     	movi.2d	v0, #0000000000000000
100315b00:     	and	x10, x8, x10
100315b04:     	cmp	x10, #0x100
100315b08:     	b.ne	0x100315b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100315b0c:     	tbnz	w8, #0x9, 0x100315b20 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x39c>
100315b10:     	and	x8, x8, #0xfffffffffc00
100315b14:     	tst	x8, #0xffffffffffff1fff
100315b18:     	b.ne	0x100315b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100315b1c:     	b	0x100315b38 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3b4>
100315b20:     	and	w8, w9, #0xff
100315b24:     	cmp	w8, #0x8
100315b28:     	b.hi	0x100315b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100315b2c:     	mov	w8, #0x10d              ; =269
100315b30:     	lsr	w8, w8, w9
100315b34:     	tbz	w8, #0x0, 0x100315b44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x3c0>
100315b38:     	adrp	x8, 0x1029c5000 <__MergedGlobals.22800+0xa80>
100315b3c:     	mov	x0, xzr
100315b40:     	ldr	q0, [x8, #0x690]
100315b44:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315b48:     	ldr	x8, [x8, #0x578]
100315b4c:     	str	q0, [sp, #0x1d0]
100315b50:     	ldp	x10, x9, [sp, #0x1d0]
100315b54:     	str	x0, [sp, #0x138]
100315b58:     	str	x9, [sp, #0x148]
100315b5c:     	str	x10, [sp, #0x140]
100315b60:     	str	x8, [sp, #0x60]
100315b64:     	adrp	x9, 0x10076d000 <dyld_stub_binder+0x10076d000>
100315b68:     	ldrb	w8, [sp, #0x48]
100315b6c:     	ldr	x9, [x9, #0x570]
100315b70:     	str	x9, [sp, #0x58]
100315b74:     	tbz	w8, #0x1, 0x100315b90 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x40c>
100315b78:     	ldr	x8, [sp, #0x68]
100315b7c:     	cbz	x8, 0x100315b90 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x40c>
100315b80:     	ldp	x9, x20, [x8, #0x10]
100315b84:     	ldr	x10, [x8]
100315b88:     	str	x10, [sp, #0x68]
100315b8c:     	blr	x9
100315b90:     	ldr	w8, [sp, #0x48]
100315b94:     	str	x23, [sp, #0x58]
100315b98:     	tbz	w8, #0x0, 0x100315bc8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x444>
100315b9c:     	ldr	x8, [sp, #0x68]
100315ba0:     	cbz	x8, 0x100315bc8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x444>
100315ba4:     	ldp	x9, x20, [x8, #0x10]
100315ba8:     	ldr	x10, [x8]
100315bac:     	str	x10, [sp, #0x68]
100315bb0:     	blr	x9
100315bb4:     	ldr	x20, [sp, #0x50]
100315bb8:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100315bbc:     	str	x20, [x0, #0x10]
100315bc0:     	ldr	x8, [sp, #0x60]
100315bc4:     	br	x8
100315bc8:     	ldr	x20, [sp, #0x50]
100315bcc:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100315bd0:     	str	x20, [x0, #0x10]
100315bd4:     	ldr	x8, [sp, #0x60]
100315bd8:     	br	x8
100315bdc:     	mov	x0, x19
100315be0:     	bl	0x100588d4c <_github.com/xgo-dev/llgo/runtime/internal/runtime.Rethrow>
100315be4:     	b	0x100315be8 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1+0x464>
100315be8:     	ldr	x8, [sp, #0x138]
100315bec:     	ldr	x9, [sp, #0x148]
100315bf0:     	ldr	x10, [sp, #0x140]
100315bf4:     	ldr	x11, [sp, #0x28]
100315bf8:     	stp	x8, x10, [x11]
100315bfc:     	str	x9, [x11, #0x10]
100315c00:     	add	sp, sp, #0x2d0
100315c04:     	ldp	x29, x30, [sp, #0x50]
100315c08:     	ldp	x20, x19, [sp, #0x40]
100315c0c:     	ldp	x22, x21, [sp, #0x30]
100315c10:     	ldp	x24, x23, [sp, #0x20]
100315c14:     	ldp	x26, x25, [sp, #0x10]
100315c18:     	ldp	x28, x27, [sp], #0x60
100315c1c:     	ret
100315c20:     	mov	x0, xzr
100315c24:     	mov	x1, xzr
100315c28:     	bl	0x100587104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100315c2c:     	adrp	x0, 0x1008fe000 <_[8]_llgo_Pointer+0x20>
100315c30:     	add	x0, x0, #0x828
100315c34:     	adrp	x1, 0x1008f5000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.boundsErrorFmts+0x30>
100315c38:     	add	x1, x1, #0xe0
100315c3c:     	bl	0x100586df8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100315c40:     	brk	#0x1

0000000100315c44 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$1>:
100315c44:     	ldp	x8, x9, [x20]
100315c48:     	str	x9, [x8, #0x20]
100315c4c:     	ret

0000000100315c50 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).configureCodec$1$2>:
100315c50:     	ldr	x8, [x20]
100315c54:     	strb	wzr, [x8, #0x69]
100315c58:     	ret

0000000100316910 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall>:
100316910:     	stp	x28, x27, [sp, #-0x60]!
100316914:     	stp	x26, x25, [sp, #0x10]
100316918:     	stp	x24, x23, [sp, #0x20]
10031691c:     	stp	x22, x21, [sp, #0x30]
100316920:     	stp	x20, x19, [sp, #0x40]
100316924:     	stp	x29, x30, [sp, #0x50]
100316928:     	add	x29, sp, #0x50
10031692c:     	sub	sp, sp, #0x180
100316930:     	mov	x19, sp
100316934:     	ldp	x9, x21, [x2]
100316938:     	mov	x26, x8
10031693c:     	mov	w8, #0x98               ; =152
100316940:     	mov	x20, x0
100316944:     	mov	w0, w8
100316948:     	str	x9, [x19, #0x20]
10031694c:     	str	xzr, [x19, #0x40]
100316950:     	str	x1, [x19, #0x40]
100316954:     	str	xzr, [x19, #0x48]
100316958:     	str	xzr, [x19, #0x58]
10031695c:     	str	xzr, [x19, #0x50]
100316960:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
100316964:     	cbz	x0, 0x100316e40 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x530>
100316968:     	mov	w8, #0x98               ; =152
10031696c:     	mov	x22, x0
100316970:     	mov	w0, w8
100316974:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100316978:     	cbz	x20, 0x100316d38 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x428>
10031697c:     	str	x21, [x19, #0x28]
100316980:     	ldr	x0, [x20]
100316984:     	mov	x3, xzr
100316988:     	ldr	x1, [x19, #0x40]
10031698c:     	ldr	x2, [x20, #0x30]
100316990:     	bl	0x100314cd4 <_github.com/cpunion/wasmvm/pkg/component.(*Instance).codec>
100316994:     	stp	x20, x0, [x22]
100316998:     	str	x22, [x19, #0x48]
10031699c:     	ldr	x8, [x20, #0x8]
1003169a0:     	ldr	x21, [x8, #0x18]
1003169a4:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
1003169a8:     	mov	x8, sp
1003169ac:     	ldr	x9, [x0, #0x10]
1003169b0:     	sub	x23, x8, #0xd0
1003169b4:     	mov	sp, x23
1003169b8:     	mov	x24, sp
1003169bc:     	sub	x25, x24, #0x30
1003169c0:     	mov	sp, x25
1003169c4:     	stp	x23, xzr, [x24, #-0x30]
1003169c8:     	adrp	x8, 0x10076d000 <dyld_stub_binder+0x10076d000>
1003169cc:     	mov	x28, x25
1003169d0:     	ldr	x8, [x8, #0x600]
1003169d4:     	str	x9, [x19, #0x30]
1003169d8:     	stp	x9, x8, [x24, #-0x20]
1003169dc:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
1003169e0:     	str	x25, [x0, #0x10]
1003169e4:     	mov	w1, wzr
1003169e8:     	mov	x0, x23
1003169ec:     	stur	xzr, [x24, #-0x8]
1003169f0:     	bl	0x1005a10a0 <dyld_stub_binder+0x1005a10a0>
1003169f4:     	adrp	x12, 0x10076d000 <dyld_stub_binder+0x10076d000>
1003169f8:     	ldr	x12, [x12, #0x5f8]
1003169fc:     	cbz	w0, 0x100316a18 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x108>
100316a00:     	ldr	x8, [x28, #0x18]
100316a04:     	str	x12, [x28, #0x20]
100316a08:     	br	x8
100316a0c:     	ldr	x0, [x19, #0x30]
100316a10:     	bl	0x100588d4c <_github.com/xgo-dev/llgo/runtime/internal/runtime.Rethrow>
100316a14:     	b	0x100316dd0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4c0>
100316a18:     	ldr	x24, [x19, #0x28]
100316a1c:     	cmp	x24, x21
100316a20:     	b.ne	0x100316ae0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x1d0>
100316a24:     	mov	w8, #0x1                ; =1
100316a28:     	mov	w0, w8
100316a2c:     	bl	0x1005a1130 <dyld_stub_binder+0x1005a1130>
100316a30:     	cbz	x0, 0x100316e40 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x530>
100316a34:     	mov	w8, #0x1                ; =1
100316a38:     	mov	x21, x0
100316a3c:     	mov	w0, w8
100316a40:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100316a44:     	strb	wzr, [x21]
100316a48:     	ldr	x8, [x19, #0x40]
100316a4c:     	add	x10, x19, #0x50
100316a50:     	ldr	x11, [x28, #0x8]
100316a54:     	add	x9, x19, #0x60
100316a58:     	stp	x10, x8, [x19, #0x70]
100316a5c:     	add	x10, x19, #0x48
100316a60:     	orr	x8, x11, #0x1
100316a64:     	stp	x10, x21, [x19, #0x60]
100316a68:     	str	x8, [x28, #0x8]
100316a6c:     	ldr	x8, [x28, #0x28]
100316a70:     	stp	x8, xzr, [x19, #0x80]
100316a74:     	adr	x8, 0x10031716c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1>
100316a78:     	nop
100316a7c:     	stp	x8, x9, [x19, #0x90]
100316a80:     	add	x8, x19, #0x80
100316a84:     	str	x8, [x28, #0x28]
100316a88:     	ldr	x8, [x19, #0x48]
100316a8c:     	str	x21, [x19, #0x18]
100316a90:     	cbz	x8, 0x100316b04 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x1f4>
100316a94:     	ldp	x9, x10, [x8]
100316a98:     	ldr	x9, [x9]
100316a9c:     	ldr	x11, [x10, #0x58]
100316aa0:     	ldr	x12, [x9, #0x160]
100316aa4:     	ldr	x13, [x9, #0x1b8]
100316aa8:     	add	x11, x12, x11
100316aac:     	sub	x11, x11, x13
100316ab0:     	str	x11, [x10, #0x50]
100316ab4:     	ldr	x10, [x10, #0x40]
100316ab8:     	ldr	x11, [x9, #0x168]
100316abc:     	ldr	x9, [x9, #0x1c0]
100316ac0:     	ldr	x8, [x8, #0x8]
100316ac4:     	add	x10, x11, x10
100316ac8:     	sub	x9, x10, x9
100316acc:     	str	x9, [x8, #0x28]
100316ad0:     	lsr	x8, x24, #58
100316ad4:     	ldr	x21, [x19, #0x48]
100316ad8:     	cbz	x8, 0x100316b18 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x208>
100316adc:     	b	0x100316e28 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x518>
100316ae0:     	adrp	x9, 0x1029c5000 <__MergedGlobals.22800+0xa80>
100316ae4:     	add	x9, x9, #0x690
100316ae8:     	ldr	x8, [x19, #0x48]
100316aec:     	ldp	x10, x0, [x9]
100316af0:     	adrp	x11, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316af4:     	ldr	x11, [x11, #0x608]
100316af8:     	mov	x9, x10
100316afc:     	mov	x10, x0
100316b00:     	b	0x100316d6c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x45c>
100316b04:     	mov	w0, #0x1                ; =1
100316b08:     	bl	0x10058b6dc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100316b0c:     	lsr	x8, x24, #58
100316b10:     	ldr	x21, [x19, #0x48]
100316b14:     	cbnz	x8, 0x100316e28 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x518>
100316b18:     	lsl	x22, x24, #6
100316b1c:     	mov	x8, #0x1                ; =1
100316b20:     	movk	x8, #0x1, lsl #48
100316b24:     	cmp	x22, x8
100316b28:     	b.hs	0x100316e28 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x518>
100316b2c:     	str	x26, [x19, #0x38]
100316b30:     	cbz	x22, 0x100316b54 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x244>
100316b34:     	mov	x0, x22
100316b38:     	bl	0x1005a1118 <dyld_stub_binder+0x1005a1118>
100316b3c:     	cbz	x0, 0x100316e40 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x530>
100316b40:     	mov	x23, x0
100316b44:     	mov	x0, x22
100316b48:     	bl	0x10058700c <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100316b4c:     	mov	x8, x23
100316b50:     	b	0x100316b5c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x24c>
100316b54:     	adrp	x8, 0x1029c4000 <__MergedGlobals.22799+0xa80>
100316b58:     	add	x8, x8, #0xb70
100316b5c:     	dup.2d	v0, x24
100316b60:     	str	x8, [x21, #0x10]
100316b64:     	mov	x26, xzr
100316b68:     	add	x22, x19, #0xb8
100316b6c:     	stur	q0, [x21, #0x18]
100316b70:     	ldr	x8, [x20, #0x8]
100316b74:     	ldp	x9, x23, [x8, #0x10]
100316b78:     	stp	x23, x24, [x19, #0x8]
100316b7c:     	bic	x24, x23, x23, asr #63
100316b80:     	add	x25, x9, #0x10
100316b84:     	b	0x100316b90 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x280>
100316b88:     	add	x25, x25, #0x18
100316b8c:     	add	x26, x26, #0x1
100316b90:     	cmp	x24, x26
100316b94:     	b.eq	0x100316c9c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x38c>
100316b98:     	cmp	x23, x26
100316b9c:     	b.eq	0x100316e04 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4f4>
100316ba0:     	ldp	x9, x10, [x25, #-0x10]
100316ba4:     	ldr	x11, [x25]
100316ba8:     	str	xzr, [x19, #0xa0]
100316bac:     	str	xzr, [x19, #0xa8]
100316bb0:     	str	xzr, [x19, #0xb0]
100316bb4:     	str	x9, [x19, #0xa0]
100316bb8:     	str	x10, [x19, #0xa8]
100316bbc:     	str	x11, [x19, #0xb0]
100316bc0:     	ldr	x8, [x19, #0x48]
100316bc4:     	ldp	x21, x27, [x8, #0x10]
100316bc8:     	ldr	x8, [x19, #0x48]
100316bcc:     	cbz	x8, 0x100316d38 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x428>
100316bd0:     	ldr	x0, [x8, #0x8]
100316bd4:     	ldr	x1, [x19, #0xb0]
100316bd8:     	ldr	x8, [x19, #0x28]
100316bdc:     	cmp	x8, x26
100316be0:     	b.eq	0x100316e10 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x500>
100316be4:     	ldr	x8, [x19, #0x20]
100316be8:     	sub	x2, x29, #0xc8
100316bec:     	add	x8, x8, x26, lsl #6
100316bf0:     	ldp	q0, q1, [x8]
100316bf4:     	ldr	w11, [x8, #0x30]
100316bf8:     	ldp	x9, x10, [x8, #0x20]
100316bfc:     	ldr	x8, [x8, #0x38]
100316c00:     	stur	w11, [x29, #-0x98]
100316c04:     	stur	x8, [x29, #-0x90]
100316c08:     	add	x8, x19, #0xb8
100316c0c:     	stp	q0, q1, [x22, #0x50]
100316c10:     	stp	x9, x10, [x29, #-0xa8]
100316c14:     	bl	0x10044b600 <_github.com/cpunion/wasmvm/internal/component/canonical.(*Codec).Clone>
100316c18:     	cmp	x26, x27
100316c1c:     	b.hs	0x100316e1c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x50c>
100316c20:     	ldr	x8, [x19, #0xc8]
100316c24:     	add	x9, x21, x26, lsl #6
100316c28:     	ldr	x10, [x19, #0xe0]
100316c2c:     	ldur	q0, [x19, #0xb8]
100316c30:     	ldur	q1, [x22, #0x18]
100316c34:     	str	x8, [x9, #0x10]
100316c38:     	ldr	w8, [x19, #0xe8]
100316c3c:     	str	x10, [x9, #0x28]
100316c40:     	ldr	x10, [x19, #0x100]
100316c44:     	str	w8, [x9, #0x30]
100316c48:     	ldp	x11, x8, [x19, #0xf0]
100316c4c:     	str	q0, [x9]
100316c50:     	stur	q1, [x9, #0x18]
100316c54:     	str	x11, [x9, #0x38]
100316c58:     	str	x10, [x19, #0x58]
100316c5c:     	str	x8, [x19, #0x50]
100316c60:     	ldr	x8, [x19, #0x58]
100316c64:     	ldr	x8, [x19, #0x50]
100316c68:     	cbz	x8, 0x100316b88 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x278>
100316c6c:     	ldr	x8, [x8, #0x8]
100316c70:     	cbz	x8, 0x100316b88 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x278>
100316c74:     	adrp	x0, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316c78:     	ldr	x8, [x19, #0x48]
100316c7c:     	adrp	x12, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316c80:     	ldr	x0, [x0, #0x618]
100316c84:     	ldr	x10, [x19, #0x58]
100316c88:     	ldr	x9, [x19, #0x50]
100316c8c:     	ldr	x26, [x19, #0x38]
100316c90:     	ldr	x12, [x12, #0x5f8]
100316c94:     	mov	x11, x0
100316c98:     	b	0x100316d6c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x45c>
100316c9c:     	ldr	x8, [x19, #0x48]
100316ca0:     	ldr	x26, [x19, #0x38]
100316ca4:     	ldr	x8, [x8, #0x8]
100316ca8:     	ldr	x8, [x8, #0x60]
100316cac:     	cbz	x8, 0x100316d44 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x434>
100316cb0:     	ldr	x8, [x8, #0x8]
100316cb4:     	cbz	x8, 0x100316d44 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x434>
100316cb8:     	ldr	x8, [x19, #0x48]
100316cbc:     	cbz	x8, 0x100316d38 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x428>
100316cc0:     	ldr	x9, [x20, #0x8]
100316cc4:     	ldr	x0, [x8, #0x8]
100316cc8:     	sub	x1, x29, #0x70
100316ccc:     	sub	x2, x29, #0x88
100316cd0:     	ldr	x8, [x9, #0x10]
100316cd4:     	ldr	x10, [x19, #0x48]
100316cd8:     	ldur	q0, [x9, #0x18]
100316cdc:     	ldr	x9, [x10, #0x10]
100316ce0:     	stur	q0, [x22, #0xb0]
100316ce4:     	ldur	q0, [x10, #0x18]
100316ce8:     	stur	x8, [x29, #-0x70]
100316cec:     	stur	x9, [x29, #-0x88]
100316cf0:     	stur	q0, [x22, #0x98]
100316cf4:     	bl	0x10044b334 <_github.com/cpunion/wasmvm/internal/component/canonical.(*Codec).AcceptParameters>
100316cf8:     	str	x0, [x19, #0x50]
100316cfc:     	str	x1, [x19, #0x58]
100316d00:     	ldr	x8, [x19, #0x58]
100316d04:     	ldr	x8, [x19, #0x50]
100316d08:     	cbz	x8, 0x100316d44 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x434>
100316d0c:     	ldr	x8, [x8, #0x8]
100316d10:     	cbz	x8, 0x100316d44 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x434>
100316d14:     	adrp	x0, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316d18:     	ldr	x8, [x19, #0x48]
100316d1c:     	adrp	x12, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316d20:     	ldr	x0, [x0, #0x5f0]
100316d24:     	ldr	x10, [x19, #0x58]
100316d28:     	ldr	x9, [x19, #0x50]
100316d2c:     	ldr	x12, [x12, #0x5f8]
100316d30:     	mov	x11, x0
100316d34:     	b	0x100316d6c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x45c>
100316d38:     	mov	w0, #0x1                ; =1
100316d3c:     	bl	0x10058b6dc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100316d40:     	b	0x100316de4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4d4>
100316d44:     	ldr	x9, [x19, #0x18]
100316d48:     	mov	w8, #0x1                ; =1
100316d4c:     	adrp	x11, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316d50:     	adrp	x12, 0x10076d000 <dyld_stub_binder+0x10076d000>
100316d54:     	mov	x10, xzr
100316d58:     	strb	w8, [x9]
100316d5c:     	mov	x9, xzr
100316d60:     	ldr	x8, [x19, #0x48]
100316d64:     	ldr	x11, [x11, #0x610]
100316d68:     	ldr	x12, [x12, #0x5f8]
100316d6c:     	str	x8, [x19, #0x48]
100316d70:     	str	x10, [x19, #0x58]
100316d74:     	str	x9, [x19, #0x50]
100316d78:     	str	x11, [x28, #0x20]
100316d7c:     	ldr	w8, [x28, #0x8]
100316d80:     	str	x12, [x28, #0x18]
100316d84:     	tbz	w8, #0x0, 0x100316db4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4a4>
100316d88:     	ldr	x8, [x28, #0x28]
100316d8c:     	cbz	x8, 0x100316db4 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4a4>
100316d90:     	ldp	x9, x20, [x8, #0x10]
100316d94:     	ldr	x10, [x8]
100316d98:     	str	x10, [x28, #0x28]
100316d9c:     	blr	x9
100316da0:     	ldr	x20, [x28, #0x10]
100316da4:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100316da8:     	str	x20, [x0, #0x10]
100316dac:     	ldr	x8, [x28, #0x20]
100316db0:     	br	x8
100316db4:     	ldr	x20, [x28, #0x10]
100316db8:     	bl	0x10058b964 <_github.com/xgo-dev/llgo/runtime/internal/runtime.getg>
100316dbc:     	str	x20, [x0, #0x10]
100316dc0:     	ldr	x8, [x28, #0x20]
100316dc4:     	br	x8
100316dc8:     	b	0x100316dd0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4c0>
100316dcc:     	b	0x100316dd0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x4c0>
100316dd0:     	ldr	x8, [x19, #0x48]
100316dd4:     	ldr	x9, [x19, #0x58]
100316dd8:     	ldr	x10, [x19, #0x50]
100316ddc:     	stp	x8, x10, [x26]
100316de0:     	str	x9, [x26, #0x10]
100316de4:     	sub	sp, x29, #0x50
100316de8:     	ldp	x29, x30, [sp, #0x50]
100316dec:     	ldp	x20, x19, [sp, #0x40]
100316df0:     	ldp	x22, x21, [sp, #0x30]
100316df4:     	ldp	x24, x23, [sp, #0x20]
100316df8:     	ldp	x26, x25, [sp, #0x10]
100316dfc:     	ldp	x28, x27, [sp], #0x60
100316e00:     	ret
100316e04:     	ldr	x0, [x19, #0x8]
100316e08:     	mov	x1, x0
100316e0c:     	bl	0x100587104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100316e10:     	ldr	x0, [x19, #0x10]
100316e14:     	mov	x1, x0
100316e18:     	bl	0x100587104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100316e1c:     	mov	x0, x26
100316e20:     	mov	x1, x27
100316e24:     	bl	0x100587104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100316e28:     	mov	x8, #0x1                ; =1
100316e2c:     	movk	x8, #0x400, lsl #32
100316e30:     	cmp	x24, x8
100316e34:     	b.lo	0x100316e3c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall+0x52c>
100316e38:     	bl	0x100597310 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicmakeslicelen>
100316e3c:     	bl	0x100598690 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicmakeslicecap>
100316e40:     	adrp	x0, 0x1008fe000 <_[8]_llgo_Pointer+0x20>
100316e44:     	add	x0, x0, #0x828
100316e48:     	adrp	x1, 0x1008f5000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.boundsErrorFmts+0x30>
100316e4c:     	add	x1, x1, #0xe0
100316e50:     	bl	0x100586df8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100316e54:     	brk	#0x1

000000010031716c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1>:
10031716c:     	stp	x22, x21, [sp, #-0x30]!
100317170:     	stp	x20, x19, [sp, #0x10]
100317174:     	stp	x29, x30, [sp, #0x20]
100317178:     	add	x29, sp, #0x20
10031717c:     	ldr	x21, [x20]
100317180:     	cbz	x21, 0x1003171ac <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x40>
100317184:     	ldr	x8, [x21]
100317188:     	ldp	x22, x19, [x20, #0x8]
10031718c:     	ldrb	w9, [x8, #0x80]
100317190:     	tbz	w9, #0x0, 0x1003171c0 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x54>
100317194:     	ldrb	w8, [x22]
100317198:     	tbz	w8, #0x0, 0x100317218 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0xac>
10031719c:     	ldp	x29, x30, [sp, #0x20]
1003171a0:     	ldp	x20, x19, [sp, #0x10]
1003171a4:     	ldp	x22, x21, [sp], #0x30
1003171a8:     	ret
1003171ac:     	ldp	x29, x30, [sp, #0x20]
1003171b0:     	mov	w0, #0x1                ; =1
1003171b4:     	ldp	x20, x19, [sp, #0x10]
1003171b8:     	ldp	x22, x21, [sp], #0x30
1003171bc:     	b	0x10058b6dc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1003171c0:     	cbz	x8, 0x100317208 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x9c>
1003171c4:     	ldp	x9, x10, [x8]
1003171c8:     	ldr	x11, [x8, #0x88]
1003171cc:     	ldr	x9, [x9]
1003171d0:     	ldr	x12, [x10, #0x58]
1003171d4:     	ldr	x10, [x10, #0x40]
1003171d8:     	ldp	x13, x14, [x9, #0x1b8]
1003171dc:     	sub	x11, x12, x11
1003171e0:     	add	x11, x11, x13
1003171e4:     	str	x11, [x9, #0x1b8]
1003171e8:     	ldr	x11, [x8, #0x90]
1003171ec:     	sub	x11, x10, x11
1003171f0:     	add	x11, x11, x14
1003171f4:     	str	x11, [x9, #0x1c0]
1003171f8:     	stp	x12, x10, [x8, #0x88]
1003171fc:     	ldrb	w8, [x22]
100317200:     	tbnz	w8, #0x0, 0x10031719c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x30>
100317204:     	b	0x100317218 <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0xac>
100317208:     	mov	w0, #0x1                ; =1
10031720c:     	bl	0x10058b6dc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100317210:     	ldrb	w8, [x22]
100317214:     	tbnz	w8, #0x0, 0x10031719c <_github.com/cpunion/wasmvm/pkg/component.(*Function).hostCall$1+0x30>
100317218:     	ldp	x3, x4, [x19]
10031721c:     	mov	w2, wzr
100317220:     	ldr	x0, [x21]
100317224:     	ldr	x1, [x20, #0x18]
100317228:     	bl	0x10030e208 <_github.com/cpunion/wasmvm/pkg/component.(*hostCall).finish>
10031722c:     	stp	x0, x1, [x19]
100317230:     	ldp	x29, x30, [sp, #0x20]
100317234:     	ldp	x20, x19, [sp, #0x10]
100317238:     	ldp	x22, x21, [sp], #0x30
10031723c:     	ret
