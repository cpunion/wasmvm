
/opt/homebrew/opt/bdw-gc/lib/libgc.1.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000000000049ec <_GC_malloc_kind>:
    49ec:      	stp	x24, x23, [sp, #-0x40]!
    49f0:      	stp	x22, x21, [sp, #0x10]
    49f4:      	stp	x20, x19, [sp, #0x20]
    49f8:      	stp	x29, x30, [sp, #0x30]
    49fc:      	add	x29, sp, #0x30
    4a00:      	mov	x19, x1
    4a04:      	mov	x20, x0
    4a08:      	cmp	w1, #0x3
    4a0c:      	b.ge	0x4b3c <_GC_malloc_kind+0x150>
    4a10:      	adrp	x8, 0x20000 <_GC_all_interior_pointers>
    4a14:      	ldrb	w8, [x8, #0x5c0]
    4a18:      	tbz	w8, #0x0, 0x4b3c <_GC_malloc_kind+0x150>
    4a1c:      	adrp	x8, 0xf4000 <_GC_arrays+0xd2380>
    4a20:      	ldr	x0, [x8, #0xe80]
    4a24:      	bl	0x167fc <_write+0x167fc>
    4a28:      	cbz	x0, 0x4b3c <_GC_malloc_kind+0x150>
    4a2c:      	adrp	x8, 0x20000 <_GC_all_interior_pointers>
    4a30:      	ldrsw	x8, [x8]
    4a34:      	mov	x9, #-0x10              ; =-16
    4a38:      	add	x10, x20, x8
    4a3c:      	add	x10, x10, #0xf
    4a40:      	lsr	x10, x10, #4
    4a44:      	sub	x8, x9, x8
    4a48:      	cmp	x8, x20
    4a4c:      	mov	x8, #0xfffffffffffffff  ; =1152921504606846975
    4a50:      	csel	x24, x10, x8, hi
    4a54:      	cmp	x24, #0x19
    4a58:      	b.hs	0x4b3c <_GC_malloc_kind+0x150>
    4a5c:      	mov	w8, #0xc8               ; =200
    4a60:      	smaddl	x8, w19, w8, x0
    4a64:      	add	x21, x8, x24, lsl #3
    4a68:      	ldr	x0, [x21]
    4a6c:      	lsl	x22, x24, #4
    4a70:      	mov	w8, #0x10               ; =16
    4a74:      	cmp	x24, #0x0
    4a78:      	csel	x23, x8, x22, eq
    4a7c:      	cmp	x0, #0x11b
    4a80:      	b.hs	0x4ac8 <_GC_malloc_kind+0xdc>
    4a84:      	cmp	x0, #0x100
    4a88:      	b.gt	0x4a90 <_GC_malloc_kind+0xa4>
    4a8c:      	cbnz	x0, 0x4b30 <_GC_malloc_kind+0x144>
    4a90:      	mov	x0, x23
    4a94:      	mov	x1, x19
    4a98:      	mov	x2, x21
    4a9c:      	bl	0x5b78 <_GC_generic_malloc_many>
    4aa0:      	ldr	x0, [x21]
    4aa4:      	cbnz	x0, 0x4a7c <_GC_malloc_kind+0x90>
    4aa8:      	bl	0x5180 <_GC_get_oom_fn>
    4aac:      	mov	x1, x0
    4ab0:      	mov	x0, x22
    4ab4:      	ldp	x29, x30, [sp, #0x30]
    4ab8:      	ldp	x20, x19, [sp, #0x20]
    4abc:      	ldp	x22, x21, [sp, #0x10]
    4ac0:      	ldp	x24, x23, [sp], #0x40
    4ac4:      	br	x1
    4ac8:      	ldr	x8, [x0]
    4acc:      	str	x8, [x21]
    4ad0:      	cbz	w19, 0x4b18 <_GC_malloc_kind+0x12c>
    4ad4:      	str	xzr, [x0]
    4ad8:      	prfm	pstl1keep, [x8]
    4adc:      	adrp	x9, 0x21000 <_GC_fail_count>
    4ae0:      	ldrb	w9, [x9, #0x730]
    4ae4:      	cmp	w9, #0x1
    4ae8:      	b.ne	0x4b14 <_GC_malloc_kind+0x128>
    4aec:      	lsr	x9, x21, #12
    4af0:      	ubfx	x10, x21, #18, #15
    4af4:      	adrp	x11, 0x21000 <_GC_fail_count>
    4af8:      	add	x11, x11, #0xc80
    4afc:      	add	x10, x11, x10, lsl #3
    4b00:      	add	x10, x10, #0x46, lsl #12 ; =0x46000
    4b04:      	add	x10, x10, #0x9f8
    4b08:      	mov	w11, #0x1               ; =1
    4b0c:      	lsl	x9, x11, x9
    4b10:      	ldset	x9, x9, [x10]
    4b14:      	b	0x4b1c <_GC_malloc_kind+0x130>
    4b18:      	prfm	pstl1keep, [x8]
    4b1c:      	ldp	x29, x30, [sp, #0x30]
    4b20:      	ldp	x20, x19, [sp, #0x20]
    4b24:      	ldp	x22, x21, [sp, #0x10]
    4b28:      	ldp	x24, x23, [sp], #0x40
    4b2c:      	ret
    4b30:      	add	x8, x0, x24
    4b34:      	add	x8, x8, #0x1
    4b38:      	str	x8, [x21]
    4b3c:      	mov	x0, x20
    4b40:      	mov	x1, x19
    4b44:      	ldp	x29, x30, [sp, #0x30]
    4b48:      	ldp	x20, x19, [sp, #0x20]
    4b4c:      	ldp	x22, x21, [sp, #0x10]
    4b50:      	ldp	x24, x23, [sp], #0x40
    4b54:      	b	0x51e0 <_GC_malloc_kind_global>
