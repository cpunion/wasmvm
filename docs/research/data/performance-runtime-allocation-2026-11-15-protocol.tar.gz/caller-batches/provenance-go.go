package phase
func init(){sourceRevision="1385093bcc2e0c1840d65e87e5fa6dac43813bb3";compilerRevision="go1.27.3"}
