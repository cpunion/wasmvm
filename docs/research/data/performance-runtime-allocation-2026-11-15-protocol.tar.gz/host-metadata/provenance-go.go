package phase
func init(){sourceRevision="35095cb126d32182661200d475c22fdd406de9c3";compilerRevision="go1.27.3"}
