from pathlib import Path
import json,gzip,hashlib,tarfile,io,statistics,math,collections
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');dest=w/'docs/research/data';stem='p3-http-readiness-2026-11-21'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
core=json.loads((p/'core-analysis.json').read_text());p3=json.loads((p/'p3-analysis.json').read_text());plan=json.loads((p/'core-plan.json').read_text());cases={(c['fixture']['cohort'],c['fixture']['id']):c for c in plan['cases']};counts={};sources={};core_rows=[]
raw=dest/(stem+'-raw.jsonl.gz')
with raw.open('wb')as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as stream:
 for cohort in ['core','p3-16','p3-65536']:
  f=p/cohort/'rows.jsonl.gz';sources[cohort]=sha(f);count=0
  for line in gzip.open(f,'rt'):
   r=json.loads(line);count+=1
   if cohort=='core':
    c=cases[(r['cohort'],r['case'])];fxt=c['fixture'];record=r['observation']['record'];assert record.get('result',record.get('checksum'))==fxt['expectedChecksum'];warm=record['warmCallNs'];assert len(warm)==7
    if 'warmResults'in record:assert record['warmResults']==[fxt['expectedChecksum']]*7
    reduce=statistics.mean if c['statistic']=='mean-including-pauses'else statistics.median;assert math.isclose(r['nsPerIteration'],reduce(warm)/fxt['iterations'],rel_tol=1e-12)
    core_rows.append(r)
   elif cohort.startswith('p3-'):
    record=r['record'];size=16 if cohort=='p3-16'else 65536;expected=1757737011 if size==16 else 2629362236;assert record['warmResults']==[expected]*21
    total={k:sum(x['after'][k]-x['before'][k]for x in r['rounds'])for k in r['totals']};assert total==r['totals'];clock=json.loads((p/cohort/'plan.json').read_text())['machTimebase'];tick=clock['numer']/clock['denom']
    assert math.isclose(r['cpuUs'],(total['ri_user_time']+total['ri_system_time'])*tick/r['windowRequests']/1000,rel_tol=1e-12)
    assert math.isclose(r['instructions'],total['ri_instructions']/r['windowRequests'],rel_tol=1e-12)
    assert math.isclose(r['throughput'],512e9/statistics.median(record['warmCallNs'][:20]),rel_tol=1e-12)
    for batch in record['service']['Batches']:
     for key in ['RequestNs','PublicAPINs']:
      if key in batch:
       values=batch.pop(key);batch[key+'Projection']=dict(count=len(values),minimum=min(values)if values else None,maximum=max(values)if values else None,sha256=hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest())
   stream.write((json.dumps(dict(cohort=cohort,row=r),separators=(',',':'))+'\n').encode())
  counts[cohort]=count
assert counts=={'core':5364,'p3-16':72,'p3-65536':72}

supported = {(f['case'],f['runtime']) for f in json.loads((p/'capability-smoke.json').read_text())['unsupported']}
failed = {(f['cohort'],f['case'],f['runtime']) for f in json.loads((p/'runtime-failures.json').read_text())['failures']}
expected=set()
for (cohort, case), trial in cases.items():
 for role in trial['commands']:
  if (case,role) in supported or (cohort,case,role) in failed:continue
  expected.update((block,cohort,case,role+alias) for block in range(plan['blocks']) for alias in ('','-aa'))
observed={(row['block'],row['cohort'],row['case'],row['id'])for row in core_rows}
assert len(observed)==len(core_rows) and observed==expected
for campaign in ['p3-16','p3-65536']:
 folder=p/campaign;run=json.loads((folder/'plan.json').read_text())
 observed=set()
 for line in gzip.open(folder/'rows.jsonl.gz','rt'):
  row=json.loads(line);key=(row['block'],row['id'])
  assert key not in observed
  observed.add(key)
 assert observed=={(block,role+alias)for block in range(run['blocks'])for role in run['variants']for alias in ('','-aa')}

# Recompute every phase median from raw records, including independently observed startup.
for key,result in core['results'].items():
 selected=[r for r in core_rows if r['cohort']+'/'+r['case']==key]
 for role,phases in result['phasesMedianNs'].items():
  rr=[r for r in selected if r['id']in[role,role+'-aa']];phases['processStartup']=statistics.median(r['observation']['processReadyNs']for r in rr)
  for family in ['preparationPartsNs','aotPreparationNs']:
   for k in {k for r in rr for k in r['observation']['record'].get(family,{})}:
    phases[family+'/'+k]=statistics.median(r['observation']['record'][family][k]for r in rr)
files=['build.json', 'qualification.json', 'campaign.json', 'core-plan.json', 'machine.json', 'prepare_core.py', 'measure_core.py', 'analyze_core.py', 'screen/analyze_p3.py', 'capability_smoke.py', 'capability-smoke.json', 'capability-smoke.log', 'wasmedge-full-size.py', 'wasmedge-full-size-smoke.json', 'runtime-failures.json', 'core/case-orders.json', 'core/unsupported.json', 'core/runtime-failures.json', 'core/complete.json', 'go-tests.log', 'go-race.log', 'llgo-tests.log', 'llgo-version.log', 'regression-witness.log', 'core-build/build.py', 'core-build/build-complete.json', 'core-build/head-go-phase-build.log', 'core-build/head-llgo-phase-build.log', 'head-go-build.txt', 'head-llgo-build.log', 'trace/validation.json', 'trace/base-direct-contentions.txt', 'trace/direct-contentions.txt', 'trace/base-queued-contentions.txt', 'trace/queued-contentions.txt', 'publish_evidence.py', 'render_report.py', 'p3-16/measure.py', 'p3-16/plan.json', 'p3-65536/measure.py', 'p3-65536/plan.json', 'go-direct-diagnostic/plan.json', 'go-direct-diagnostic/measure.py', 'go-direct-diagnostic/analyze.py', 'go-direct-diagnostic/p3-analysis.json', 'go-direct-diagnostic/rows.jsonl.gz']
extras={}
for cohort in ['core','p3-16','p3-65536']:
 for f in sorted((p/cohort).glob('*load*.json')):
  data=json.loads(f.read_text());original=sha(f)
  if isinstance(data,dict)and isinstance(data.get('processes'),str):
   rows=[]
   for line in data.pop('processes').splitlines()[1:]:
    fields=line.split(None,4)
    if len(fields)==5:rows.append(dict(pid=fields[0],ppid=fields[1],elapsed=fields[2],cpuPercent=fields[3],commandName=Path(fields[4].split()[0]).name))
   data['processes']=rows
  elif isinstance(data,list):
   for r in data:
    if 'command'in r:r['commandName']=Path(r.pop('command')).name
  extras[str(f.relative_to(p))]=json.dumps(dict(fullLocalSHA256=original,sanitizedLoad=data),separators=(',',':')).encode()
extras['REPRODUCE.md']=b'Rebase local output paths. Build Go 1.27.3 and pinned LLGo 3c6b33ec O3/full-LTO/default-GC binaries from the qualified sources. Verify hashes in the Core and P3 plans and rerun the semantic preflight. Follow each fixed seed and retain same-binary controls. The separately recorded HTTP scheduler traces are diagnostic. Their counts do not measure CPU speed. Use comparison_format from the measured repository tree. Runtime-profile gaps and reproduced WasmEdge failures remain categorical.\n'
protocol=dest/(stem+'-protocol.tar.gz')
with protocol.open('wb')as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for name in files:
  data=(p/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 for name,data in extras.items():
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
summary=dict(machine=json.loads((p/'machine.json').read_text()),qualification=json.loads((p/'qualification.json').read_text()),campaign=json.loads((p/'campaign.json').read_text()),builds=json.loads((p/'build.json').read_text()),core=core,p3=p3,failures=json.loads((p/'runtime-failures.json').read_text()),processCounts=counts,fullLocalRowsSHA256=sources,raw=dict(file=raw.name,sha256=sha(raw)),protocol=dict(file=protocol.name,sha256=sha(protocol)))
(dest/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
print('Verified and exported',counts,[(f.name,f.stat().st_size)for f in [raw,protocol,dest/(stem+'.json')]])
