from pathlib import Path
import json
import os
import signal
import subprocess


out = Path(__file__).resolve().parent
plan = json.loads((out / "core-plan.json").read_text())
env = dict(os.environ, GOMAXPROCS="4", GOGC="100", WASMVM_INTERLEAVE="0")
checks, failures = [], []
expected_failures = {
    ("gc-sustained-v1", f"gc/struct-{name}")
    for name in ("access", "allocation", "indirect-access")
}
for case in plan["cases"]:
    fixture = case["fixture"]
    command = case["commands"]["wasmedge-compiler"].copy()
    command[command.index("--samples") + 1] = "2"
    command[command.index("--warmups") + 1] = "0"
    run = subprocess.run(command, env=env, input="run\n" + "sample\n" * 8,
                         capture_output=True, text=True, timeout=120)
    key = fixture["cohort"], fixture["id"]
    record = dict(case=key[1], cohort=key[0], runtime="wasmedge-compiler",
                  command=command, exitCode=run.returncode, stderr=run.stderr)
    if run.returncode == -signal.SIGSEGV and key in expected_failures:
        failures.append(record)
    else:
        if run.returncode != 0:
            raise RuntimeError((record, run.stdout))
        last = json.loads(run.stdout.splitlines()[-1])
        assert last["result"] == fixture["expectedChecksum"], (key, last)
        if "warmResults" in last:
            assert last["warmResults"] == [fixture["expectedChecksum"]] * 2
        record["result"] = last["result"]
    checks.append(record)
    print("preflight", key, run.returncode, flush=True)

assert {(row["cohort"], row["case"]) for row in failures} == expected_failures
for name, records in (("wasmedge-full-size-smoke", dict(checks=checks)),
                      ("runtime-failures", dict(failures=failures))):
    (out / (name + ".json")).write_text(json.dumps(
        dict(scope="Fresh full-size WasmEdge AOT semantic preflight", **records), indent=2
    ) + "\n")
