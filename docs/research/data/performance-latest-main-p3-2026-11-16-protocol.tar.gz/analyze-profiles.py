from pathlib import Path
import xml.etree.ElementTree as ET,collections,json
D=Path(__file__).resolve().parent
for role in ('old','latest'):
 p=D/(role+'-profile');root=ET.parse(p/'samples.xml').getroot();ids={e.get('id'):e for e in root.iter() if e.get('id')}
 def resolve(e):return ids[e.get('ref')] if e.get('ref') else e
 leaf=collections.Counter();cum=collections.Counter();groups=collections.Counter();states=collections.Counter();total=0;samples=0
 for row in root.iter('row'):
  weight=int(resolve(row.find('cycle-weight')).text);stack=resolve(row.find('tagged-backtrace'));frames=[resolve(e) for e in stack.findall('frame')];names=[f.get('name',f.get('fmt','unknown')) for f in frames];name=names[0] if names else 'missing';leaf[name]+=weight;total+=weight;samples+=1
  states[resolve(row.find('thread-state')).get('fmt')]+=weight
  for n in set(names):cum[n]+=weight
  if name.startswith('GC_') or name.startswith('GC') or name in ('memset','bzero','_platform_memset') and any(n.startswith('GC_') for n in names):group='collector/allocator leaf'
  elif 'chanSignal).park' in name or 'chanSignalSpinHint' in name:group='channel park/spin leaf'
  elif name.startswith('0x'):group='anonymous leaf'
  elif '/wasmvm/pkg/component' in name or '/wasmvm/internal/component' in name:group='component leaf'
  elif '/wasmvm/pkg/vm' in name or '/wasmvm/internal/engine' in name or '/wasmvm/internal/platform/native' in name:group='core engine leaf'
  elif '/llgo/runtime' in name or name.startswith('sync.'):group='other LLGo/runtime sync leaf'
  else:group='other/system/provider leaf'
  groups[group]+=weight
 def tops(counter):return [dict(name=n,cycles=v,weightFraction=v/total) for n,v in counter.most_common(40)]
 result=dict(samples=samples,cycleWeight=total,states=states,groups=tops(groups),exclusive=tops(leaf),cumulative=tops(cum),scope='Statistical CPU-cycle sample weights, not exact exclusive CPU time. Cumulative frames overlap. Warm-only131072requests; rusage separately recorded. No profiled throughput acceptance.')
 (p/'stacks-summary.json').write_text(json.dumps(result,indent=2)+'\n')
 print(role,'samples',samples,'groups',[(g['name'],round(g['weightFraction']*100,2)) for g in result['groups']])
 print('leaf',[(g['name'],round(g['weightFraction']*100,2)) for g in result['exclusive'][:18]])
 print('cum',[(g['name'],round(g['weightFraction']*100,2)) for g in result['cumulative'][:18]])
