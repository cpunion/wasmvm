"""Post-completion analysis of separate fixed, interleaved hosted events."""
import hashlib,json,math,random,statistics,sys
from pathlib import Path
source=Path(sys.argv[1]);d=json.loads(source.read_text())
assert d['status']=='complete' and d['cohort']=='focused-case-v1'
assert len(d['cases'])==1 and d['protocol']['blocks']==20
case=d['cases'][0];rows=case['observations']+case['nativeC'];count=case['fixture']['iterations']
assert len(rows)==400 and len(d['checks'])==19
by={}
for row in rows:
 name=row['runtime'];block=row['block'];record=row['record']
 assert len(record['warmCallNs'])==7 and all(x>0 for x in record['warmCallNs'])
 assert record['iterations']==count
 assert (record.get('result') if name!='native-c' else record['checksum'])==case['fixture']['expectedChecksum']
 assert block not in by.setdefault(name,{})
 by[name][block]=statistics.median(record['warmCallNs'])/count
assert len(by)==20 and all(set(v)==set(range(20)) for v in by.values())
def paired(a,b):
 logs=[math.log(by[a][i]/by[b][i]) for i in range(20)]
 rng=random.Random(2026111019)
 draws=sorted(math.exp(statistics.mean(rng.choices(logs,k=20))) for _ in range(20000))
 return {'point':math.exp(statistics.mean(logs)), 'ci95':[draws[500],draws[-501]],'kind':'marginal 95% paired block bootstrap; diagnostic, not simultaneous controlled acceptance'}
comparisons={a+'/'+b:paired(a,b) for a,b in [('head-go-native','base-go-native'),('head-llgo-native','base-llgo-native'),('head-go-interpreter','base-go-interpreter'),('head-llgo-interpreter','base-llgo-interpreter'),('head-go-native','wasmtime-cranelift'),('head-go-native','wasmer-cranelift'),('head-go-native','wazero-compiler'),('head-go-native','native-c'),('head-llgo-native','head-go-native')]}
phases={}
for name in by:
 obs=[r for r in rows if r['runtime']==name]
 keys=set().union(*(r['record'].get('phasesNs',{}) for r in obs))
 phases[name]={key:statistics.median(r['record']['phasesNs'][key] for r in obs if key in r['record'].get('phasesNs',{})) for key in sorted(keys)}
summary={'rawSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'source':{'base':d['build']['base'],'head':d['build']['head']},'host':d['host'],'protocol':d['protocol'],'fixture':case['fixture'],'observations':len(rows),'alternateChecks':len(d['checks']),'medianNsPerSourceIteration':{name:statistics.median(v.values()) for name,v in sorted(by.items())},'pairedComparisons':comparisons,'calibration':case['calibration'],'phaseMediansNs':phases,'classification':d['classification'],'limitations':'Single fixed hosted event, physical frequency/neighbor isolation uncontrolled; native C unchecked. Startup/preparation/first/warm boundaries remain separate. No cross-event pooling or full-portfolio parity claim.'}
(source.parent/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'median':summary['medianNsPerSourceIteration'],'paired':comparisons,'AA':case['calibration']},indent=2))
