#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/lib/llvm-22/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin
export GOTOOLCHAIN=go1.27.3 GOMAXPROCS=4 GOPATH=/cache/linux-gopath GOMODCACHE=/cache/linux-gomodcache GOCACHE=/cache/linux-go-buildcache GOWORK=off GOFLAGS=-mod=readonly CC=/usr/lib/llvm-22/bin/clang CGO_ENABLED=1
go version
clang --version
go test -count=1 -timeout=8m ./internal/compiler/codegen ./internal/engine/nativeexec ./internal/engine/execute ./pkg/vm
