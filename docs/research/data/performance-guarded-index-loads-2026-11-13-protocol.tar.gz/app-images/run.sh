#!/usr/bin/env bash
set -euo pipefail
export PATH=/usr/lib/llvm-22/bin:/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin
export GOTOOLCHAIN=go1.27.3 GOMAXPROCS=4 GOPATH=/cache/linux-gopath GOMODCACHE=/cache/linux-gomodcache GOCACHE=/cache/linux-go-buildcache GOWORK=off GOFLAGS=-mod=readonly CC=/usr/lib/llvm-22/bin/clang CGO_ENABLED=1
probe_dir=/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/scaled-memory-20261113/app-images
for role in base head; do
  mkdir -p "$probe_dir/$role-images"
  APP_IMAGE_ROOT="$probe_dir/$role-images" go test -overlay="$probe_dir/$role-overlay.json" -run '^TestDumpApplicationImages$' -count=1 ./internal/engine/nativeexec
done
