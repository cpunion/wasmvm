base - diagnostic source offsets only
03cf: movl	%r9d, %r14d
03d2: andl	$4095, %r14d
03d9: shll	$2, %r14d
03dd: movl	(%r10,%r14), %r12d
03e1: movl	$4095, %r14d
03e7: movl	%r12d, %r9d
03ea: andl	$4095, %r9d
03f1: addl	%r9d, %r15d
03f4: addl	$1, %r13d
03f8: cmpq	$0, 144(%rdi)
0400: jne	1866
0406: cmpl	%ebx, %r13d
0409: jb	-64
040f: movl	$0, %eax
0414: movq	%rax, %r12
0417: jmp	598
head - diagnostic source offsets only
03cf: movq	%r9, %rax
03d2: movl	$4095, %ecx
03d7: cmpq	%rcx, %rax
03da: ja	407
03e0: movl	(%r10,%r9,4), %r12d
03e4: movl	$4095, %r14d
03ea: movl	%r12d, %r9d
03ed: andl	$4095, %r9d
03f4: addl	%r9d, %r15d
03f7: addl	$1, %r13d
03fb: cmpq	$0, 144(%rdi)
0403: jne	1871
0409: cmpl	%ebx, %r13d
040c: jb	-50
0412: movl	$0, %eax
0417: movq	%rax, %r12
041a: jmp	603
