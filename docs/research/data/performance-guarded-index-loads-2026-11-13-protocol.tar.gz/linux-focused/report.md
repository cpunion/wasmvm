## Runtime routing comparison: memory-simd / focused memory/dependent-address

**Hosted advisory; controlled milestone acceptance remains open.** 20 fresh blocks, two warmups/seven interleaved samples; pinned source/compiler/reference identities, one inherited CPU affinity and GOMAXPROCS=1. Physical CPU power and neighbor contention remain uncontrolled. Each marginal 95% paired A/A interval must lie within ±2.5% for this diagnostic calibration; this is not the controlled native feature equivalence gate.

Base `b546ea76663c2ee763ce303a7835e1f83096e59d`; head `9ef24ba0ae1ebdff4138b52b1ee40979051f08bd`.

| Workload / statistic | Go native head/base | LLGo native head/base | Go interpreter head/base | LLGo interpreter head/base | LLGo native / Wasmtime | / Native C | A/A within ±2.5% |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| memory/dependent-address / process median | 1.001× | 0.997× | 0.998× | 1.100× | 1.004× | 1.178× | yes, advisory only |

Allocation throughput uses the median of 20 fresh-process means, including every measured warm call and pause within each process. Other cases retain process medians. Allocation median diagnostics and both control reductions remain explicit; this statistic correction changes no counts, timers or samples.

Status: **complete**. Complete phases, all runtimes including Wasmer/wazero/WasmEdge, unsupported GC probes, orders, controls and raw observations are retained. No timer/phase subtraction or cross-job pooling; smaller diagnostic components cannot replace complete API outcomes.
