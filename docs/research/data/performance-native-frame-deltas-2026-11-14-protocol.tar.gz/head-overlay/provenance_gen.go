package phase
func init(){sourceRevision="4927def4f615a323f0758d6b9c17364947f0c22c";compilerRevision="go1.27.3"}
