
/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-frame-deltas-20261114/base-llgo-runner:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010034e9c4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames>:
10034e9c4: d10343ff    	sub	sp, sp, #0xd0
10034e9c8: a9095ff8    	stp	x24, x23, [sp, #0x90]
10034e9cc: a90a57f6    	stp	x22, x21, [sp, #0xa0]
10034e9d0: a90b4ff4    	stp	x20, x19, [sp, #0xb0]
10034e9d4: a90c7bfd    	stp	x29, x30, [sp, #0xc0]
10034e9d8: 910303fd    	add	x29, sp, #0xc0
10034e9dc: f940c808    	ldr	x8, [x0, #0x190]
10034e9e0: b4002128    	cbz	x8, 0x10034ee04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x440>
10034e9e4: f100051f    	cmp	x8, #0x1
10034e9e8: 54002140    	b.eq	0x10034ee10 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x44c>
10034e9ec: f940c409    	ldr	x9, [x0, #0x188]
10034e9f0: a9402533    	ldp	x19, x9, [x9]
10034e9f4: eb09027f    	cmp	x19, x9
10034e9f8: 54001a88    	b.hi	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034e9fc: f9400829    	ldr	x9, [x1, #0x10]
10034ea00: b940282a    	ldr	w10, [x1, #0x28]
10034ea04: 8b130129    	add	x9, x9, x19
10034ea08: eb0a013f    	cmp	x9, x10
10034ea0c: 540019e8    	b.hi	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ea10: 5280040a    	mov	w10, #0x20              ; =32
10034ea14: aa13194a    	orr	x10, x10, x19, lsl #6
10034ea18: eb080d5f    	cmp	x10, x8, lsl #3
10034ea1c: 54001968    	b.hi	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ea20: f9408c08    	ldr	x8, [x0, #0x118]
10034ea24: eb09011f    	cmp	x8, x9
10034ea28: 54001901    	b.ne	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ea2c: f940d803    	ldr	x3, [x0, #0x1b0]
10034ea30: 91000674    	add	x20, x19, #0x1
10034ea34: eb14007f    	cmp	x3, x20
10034ea38: 5400036a    	b.ge	0x10034eaa4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0xe0>
10034ea3c: 8b140688    	add	x8, x20, x20, lsl #1
10034ea40: b201f3e9    	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
10034ea44: 927fad29    	and	x9, x9, #0x1ffffffffffe
10034ea48: d37df116    	lsl	x22, x8, #3
10034ea4c: eb09029f    	cmp	x20, x9
10034ea50: 54001f88    	b.hi	0x10034ee40 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x47c>
10034ea54: b4000676    	cbz	x22, 0x10034eb20 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x15c>
10034ea58: aa0003f7    	mov	x23, x0
10034ea5c: aa1603e0    	mov	x0, x22
10034ea60: aa0103f8    	mov	x24, x1
10034ea64: 9409518a    	bl	0x1005a308c <dyld_stub_binder+0x1005a308c>
10034ea68: b4002100    	cbz	x0, 0x10034ee88 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c4>
10034ea6c: aa0003f5    	mov	x21, x0
10034ea70: aa1603e0    	mov	x0, x22
10034ea74: 9408e943    	bl	0x100588f80 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
10034ea78: 9100a3e8    	add	x8, sp, #0x28
10034ea7c: 91000663    	add	x3, x19, #0x1
10034ea80: aa1803e1    	mov	x1, x24
10034ea84: aa1703e0    	mov	x0, x23
10034ea88: a9000d14    	stp	x20, x3, [x8]
10034ea8c: 9106a2ec    	add	x12, x23, #0x1a8
10034ea90: 3dc00100    	ldr	q0, [x8]
10034ea94: f900d2f5    	str	x21, [x23, #0x1a0]
10034ea98: 3d800180    	str	q0, [x12]
10034ea9c: b5000573    	cbnz	x19, 0x10034eb48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x184>
10034eaa0: 14000077    	b	0x10034ec7c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x2b8>
10034eaa4: a95a1415    	ldp	x21, x5, [x0, #0x1a0]
10034eaa8: eb05029f    	cmp	x20, x5
10034eaac: 5400026a    	b.ge	0x10034eaf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x134>
10034eab0: aa0003f6    	mov	x22, x0
10034eab4: 9100e3e0    	add	x0, sp, #0x38
10034eab8: 91000664    	add	x4, x19, #0x1
10034eabc: aa0103f7    	mov	x23, x1
10034eac0: aa1503e1    	mov	x1, x21
10034eac4: 52800302    	mov	w2, #0x18               ; =24
10034eac8: 52800026    	mov	w6, #0x1                ; =1
10034eacc: 52800027    	mov	w7, #0x1                ; =1
10034ead0: 390003ff    	strb	wzr, [sp]
10034ead4: 94093708    	bl	0x10059c6f4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034ead8: a943a3e0    	ldp	x0, x8, [sp, #0x38]
10034eadc: 8b080508    	add	x8, x8, x8, lsl #1
10034eae0: d37df101    	lsl	x1, x8, #3
10034eae4: 9409516d    	bl	0x1005a3098 <dyld_stub_binder+0x1005a3098>
10034eae8: f940d2d5    	ldr	x21, [x22, #0x1a0]
10034eaec: f940dac3    	ldr	x3, [x22, #0x1b0]
10034eaf0: aa1603e0    	mov	x0, x22
10034eaf4: aa1703e1    	mov	x1, x23
10034eaf8: eb03029f    	cmp	x20, x3
10034eafc: 54001b48    	b.hi	0x10034ee64 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4a0>
10034eb00: 910143e8    	add	x8, sp, #0x50
10034eb04: a9000d14    	stp	x20, x3, [x8]
10034eb08: 9106a00c    	add	x12, x0, #0x1a8
10034eb0c: 3dc00100    	ldr	q0, [x8]
10034eb10: f900d015    	str	x21, [x0, #0x1a0]
10034eb14: 3d800180    	str	q0, [x12]
10034eb18: b5000193    	cbnz	x19, 0x10034eb48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x184>
10034eb1c: 14000058    	b	0x10034ec7c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x2b8>
10034eb20: b0013535    	adrp	x21, 0x1029f3000 <__MergedGlobals.22795+0x5e0>
10034eb24: 913fe2b5    	add	x21, x21, #0xff8
10034eb28: 9100a3e8    	add	x8, sp, #0x28
10034eb2c: 91000663    	add	x3, x19, #0x1
10034eb30: a9000d14    	stp	x20, x3, [x8]
10034eb34: 9106a00c    	add	x12, x0, #0x1a8
10034eb38: 3dc00100    	ldr	q0, [x8]
10034eb3c: f900d015    	str	x21, [x0, #0x1a0]
10034eb40: 3d800180    	str	q0, [x12]
10034eb44: b40009d3    	cbz	x19, 0x10034ec7c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x2b8>
10034eb48: aa1f03ed    	mov	x13, xzr
10034eb4c: aa1f03ee    	mov	x14, xzr
10034eb50: aa1f03e8    	mov	x8, xzr
10034eb54: 528000af    	mov	w15, #0x5               ; =5
10034eb58: 52800030    	mov	w16, #0x1               ; =1
10034eb5c: 927de5a2    	and	x2, x13, #0x1ffffffffffffff8
10034eb60: f940c809    	ldr	x9, [x0, #0x190]
10034eb64: b27e004a    	orr	x10, x2, #0x4
10034eb68: eb09015f    	cmp	x10, x9
10034eb6c: 54001582    	b.hs	0x10034ee1c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x458>
10034eb70: f940002b    	ldr	x11, [x1]
10034eb74: f940c411    	ldr	x17, [x0, #0x188]
10034eb78: f940216b    	ldr	x11, [x11, #0x40]
10034eb7c: b400024b    	cbz	x11, 0x10034ebc4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x200>
10034eb80: f9400d63    	ldr	x3, [x11, #0x18]
10034eb84: b40003a3    	cbz	x3, 0x10034ebf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x234>
10034eb88: f86a7a2a    	ldr	x10, [x17, x10, lsl #3]
10034eb8c: f9402564    	ldr	x4, [x11, #0x48]
10034eb90: eb04015f    	cmp	x10, x4
10034eb94: 54000182    	b.hs	0x10034ebc4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x200>
10034eb98: f9402164    	ldr	x4, [x11, #0x40]
10034eb9c: f86a788a    	ldr	x10, [x4, x10, lsl #3]
10034eba0: b400018a    	cbz	x10, 0x10034ebd0 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x20c>
10034eba4: f9406c64    	ldr	x4, [x3, #0xd8]
10034eba8: eb04015f    	cmp	x10, x4
10034ebac: 54000122    	b.hs	0x10034ebd0 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x20c>
10034ebb0: f9406863    	ldr	x3, [x3, #0xd0]
10034ebb4: f86a7863    	ldr	x3, [x3, x10, lsl #3]
10034ebb8: b40000c3    	cbz	x3, 0x10034ebd0 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x20c>
10034ebbc: 381c83b0    	sturb	w16, [x29, #-0x38]
10034ebc0: 14000006    	b	0x10034ebd8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x214>
10034ebc4: 2a1f03e4    	mov	w4, wzr
10034ebc8: aa1f03e3    	mov	x3, xzr
10034ebcc: 1400000c    	b	0x10034ebfc <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x238>
10034ebd0: aa1f03e3    	mov	x3, xzr
10034ebd4: 381c83bf    	sturb	wzr, [x29, #-0x38]
10034ebd8: 385c83aa    	ldurb	w10, [x29, #-0x38]
10034ebdc: 360000ea    	tbz	w10, #0x0, 0x10034ebf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x234>
10034ebe0: f940246a    	ldr	x10, [x3, #0x48]
10034ebe4: b40000aa    	cbz	x10, 0x10034ebf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x234>
10034ebe8: f940206a    	ldr	x10, [x3, #0x40]
10034ebec: eb0b015f    	cmp	x10, x11
10034ebf0: 1a9f17e4    	cset	w4, eq
10034ebf4: 14000002    	b	0x10034ebfc <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x238>
10034ebf8: 2a1f03e4    	mov	w4, wzr
10034ebfc: aa0f004b    	orr	x11, x2, x15
10034ec00: eb09017f    	cmp	x11, x9
10034ec04: 54001122    	b.hs	0x10034ee28 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x464>
10034ec08: b27f044a    	orr	x10, x2, #0x6
10034ec0c: eb09015f    	cmp	x10, x9
10034ec10: 54001062    	b.hs	0x10034ee1c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x458>
10034ec14: 340009a4    	cbz	w4, 0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ec18: f86b7a29    	ldr	x9, [x17, x11, lsl #3]
10034ec1c: 92400d2b    	and	x11, x9, #0xf
10034ec20: b500094b    	cbnz	x11, 0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ec24: d344fd2b    	lsr	x11, x9, #4
10034ec28: f9402c09    	ldr	x9, [x0, #0x58]
10034ec2c: eb09017f    	cmp	x11, x9
10034ec30: 540008c8    	b.hi	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ec34: f9402469    	ldr	x9, [x3, #0x48]
10034ec38: f86a7a2a    	ldr	x10, [x17, x10, lsl #3]
10034ec3c: f9405d29    	ldr	x9, [x9, #0xb8]
10034ec40: eb09015f    	cmp	x10, x9
10034ec44: 54000822    	b.hs	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ec48: f9400189    	ldr	x9, [x12]
10034ec4c: eb09011f    	cmp	x8, x9
10034ec50: 54000f22    	b.hs	0x10034ee34 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x470>
10034ec54: f940d009    	ldr	x9, [x0, #0x1a0]
10034ec58: 91000508    	add	x8, x8, #0x1
10034ec5c: 11000551    	add	w17, w10, #0x1
10034ec60: eb08027f    	cmp	x19, x8
10034ec64: 910021ad    	add	x13, x13, #0x8
10034ec68: 8b0e0129    	add	x9, x9, x14
10034ec6c: 910061ce    	add	x14, x14, #0x18
10034ec70: a9002d23    	stp	x3, x11, [x9]
10034ec74: 29022931    	stp	w17, w10, [x9, #0x10]
10034ec78: 54fff721    	b.ne	0x10034eb5c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x198>
10034ec7c: f9400028    	ldr	x8, [x1]
10034ec80: f9402108    	ldr	x8, [x8, #0x40]
10034ec84: b4000268    	cbz	x8, 0x10034ecd0 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x30c>
10034ec88: f9400d09    	ldr	x9, [x8, #0x18]
10034ec8c: b4000409    	cbz	x9, 0x10034ed0c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x348>
10034ec90: f940900a    	ldr	x10, [x0, #0x120]
10034ec94: f940250b    	ldr	x11, [x8, #0x48]
10034ec98: eb0b015f    	cmp	x10, x11
10034ec9c: 540001e2    	b.hs	0x10034ecd8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x314>
10034eca0: f940210b    	ldr	x11, [x8, #0x40]
10034eca4: f86a796a    	ldr	x10, [x11, x10, lsl #3]
10034eca8: b40001ea    	cbz	x10, 0x10034ece4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x320>
10034ecac: f9406d2b    	ldr	x11, [x9, #0xd8]
10034ecb0: eb0b015f    	cmp	x10, x11
10034ecb4: 54000182    	b.hs	0x10034ece4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x320>
10034ecb8: f9406929    	ldr	x9, [x9, #0xd0]
10034ecbc: f86a7929    	ldr	x9, [x9, x10, lsl #3]
10034ecc0: b4000129    	cbz	x9, 0x10034ece4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x320>
10034ecc4: 5280002a    	mov	w10, #0x1               ; =1
10034ecc8: 381c83aa    	sturb	w10, [x29, #-0x38]
10034eccc: 14000008    	b	0x10034ecec <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x328>
10034ecd0: aa1f03e9    	mov	x9, xzr
10034ecd4: 1400000f    	b	0x10034ed10 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x34c>
10034ecd8: 2a1f03e8    	mov	w8, wzr
10034ecdc: aa1f03e9    	mov	x9, xzr
10034ece0: 1400000c    	b	0x10034ed10 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x34c>
10034ece4: aa1f03e9    	mov	x9, xzr
10034ece8: 381c83bf    	sturb	wzr, [x29, #-0x38]
10034ecec: 385c83aa    	ldurb	w10, [x29, #-0x38]
10034ecf0: 360000ea    	tbz	w10, #0x0, 0x10034ed0c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x348>
10034ecf4: f940252a    	ldr	x10, [x9, #0x48]
10034ecf8: b40000aa    	cbz	x10, 0x10034ed0c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x348>
10034ecfc: f940212a    	ldr	x10, [x9, #0x40]
10034ed00: eb08015f    	cmp	x10, x8
10034ed04: 1a9f17e8    	cset	w8, eq
10034ed08: 14000002    	b	0x10034ed10 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x34c>
10034ed0c: 2a1f03e8    	mov	w8, wzr
10034ed10: 360001c8    	tbz	w8, #0x0, 0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ed14: f9408808    	ldr	x8, [x0, #0x110]
10034ed18: 92400d0a    	and	x10, x8, #0xf
10034ed1c: b500016a    	cbnz	x10, 0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ed20: f940252b    	ldr	x11, [x9, #0x48]
10034ed24: d344fd0a    	lsr	x10, x8, #4
10034ed28: f9404d68    	ldr	x8, [x11, #0x98]
10034ed2c: f9402c0b    	ldr	x11, [x0, #0x58]
10034ed30: 8b0a0105    	add	x5, x8, x10
10034ed34: eb0b00bf    	cmp	x5, x11
10034ed38: 54000088    	b.hi	0x10034ed48 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x384>
10034ed3c: b9402c28    	ldr	w8, [x1, #0x2c]
10034ed40: eb0800bf    	cmp	x5, x8
10034ed44: 54000149    	b.ls	0x10034ed6c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x3a8>
10034ed48: d0013528    	adrp	x8, 0x1029f4000 <__MergedGlobals.22796+0x5e0>
10034ed4c: 912ec108    	add	x8, x8, #0xbb0
10034ed50: a9400500    	ldp	x0, x1, [x8]
10034ed54: a94c7bfd    	ldp	x29, x30, [sp, #0xc0]
10034ed58: a94b4ff4    	ldp	x20, x19, [sp, #0xb0]
10034ed5c: a94a57f6    	ldp	x22, x21, [sp, #0xa0]
10034ed60: a9495ff8    	ldp	x24, x23, [sp, #0x90]
10034ed64: 910343ff    	add	sp, sp, #0xd0
10034ed68: d65f03c0    	ret
10034ed6c: f9400188    	ldr	x8, [x12]
10034ed70: eb08027f    	cmp	x19, x8
10034ed74: 54000842    	b.hs	0x10034ee7c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4b8>
10034ed78: 52800308    	mov	w8, #0x18               ; =24
10034ed7c: f940d00b    	ldr	x11, [x0, #0x1a0]
10034ed80: aa0103f4    	mov	x20, x1
10034ed84: 9b082e68    	madd	x8, x19, x8, x11
10034ed88: b940182b    	ldr	w11, [x1, #0x18]
10034ed8c: 52800202    	mov	w2, #0x10               ; =16
10034ed90: aa1f03e4    	mov	x4, xzr
10034ed94: 52800026    	mov	w6, #0x1                ; =1
10034ed98: 52800027    	mov	w7, #0x1                ; =1
10034ed9c: a9002909    	stp	x9, x10, [x8]
10034eda0: 29027d0b    	stp	w11, wzr, [x8, #0x10]
10034eda4: f9402808    	ldr	x8, [x0, #0x50]
10034eda8: 3dc06800    	ldr	q0, [x0, #0x1a0]
10034edac: f9403003    	ldr	x3, [x0, #0x60]
10034edb0: f940d813    	ldr	x19, [x0, #0x1b0]
10034edb4: 910183e0    	add	x0, sp, #0x60
10034edb8: 390003ff    	strb	wzr, [sp]
10034edbc: aa0803e1    	mov	x1, x8
10034edc0: 3d8007e0    	str	q0, [sp, #0x10]
10034edc4: 9409364c    	bl	0x10059c6f4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034edc8: 3dc007e0    	ldr	q0, [sp, #0x10]
10034edcc: f94033e8    	ldr	x8, [sp, #0x60]
10034edd0: aa1f03e0    	mov	x0, xzr
10034edd4: aa1f03e1    	mov	x1, xzr
10034edd8: f9002e93    	str	x19, [x20, #0x58]
10034eddc: 3c848280    	stur	q0, [x20, #0x48]
10034ede0: 3cc683e0    	ldur	q0, [sp, #0x68]
10034ede4: f9001a88    	str	x8, [x20, #0x30]
10034ede8: 3c838280    	stur	q0, [x20, #0x38]
10034edec: a94c7bfd    	ldp	x29, x30, [sp, #0xc0]
10034edf0: a94b4ff4    	ldp	x20, x19, [sp, #0xb0]
10034edf4: a94a57f6    	ldp	x22, x21, [sp, #0xa0]
10034edf8: a9495ff8    	ldp	x24, x23, [sp, #0x90]
10034edfc: 910343ff    	add	sp, sp, #0xd0
10034ee00: d65f03c0    	ret
10034ee04: aa1f03e0    	mov	x0, xzr
10034ee08: aa1f03e1    	mov	x1, xzr
10034ee0c: 9408e89b    	bl	0x100589078 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10034ee10: 52800020    	mov	w0, #0x1                ; =1
10034ee14: 52800021    	mov	w1, #0x1                ; =1
10034ee18: 9408e898    	bl	0x100589078 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10034ee1c: aa0a03e0    	mov	x0, x10
10034ee20: aa0903e1    	mov	x1, x9
10034ee24: 9408ee02    	bl	0x10058a62c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10034ee28: aa0b03e0    	mov	x0, x11
10034ee2c: aa0903e1    	mov	x1, x9
10034ee30: 9408edff    	bl	0x10058a62c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10034ee34: aa0803e0    	mov	x0, x8
10034ee38: aa0903e1    	mov	x1, x9
10034ee3c: 9408edfc    	bl	0x10058a62c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10034ee40: d2800028    	mov	x8, #0x1                ; =1
10034ee44: f2e00028    	movk	x8, #0x1, lsl #48
10034ee48: eb0802df    	cmp	x22, x8
10034ee4c: b201f3e8    	mov	x8, #-0x5555555555555556 ; =-6148914691236517206
10034ee50: f2955568    	movk	x8, #0xaaab
10034ee54: f2e15548    	movk	x8, #0xaaa, lsl #48
10034ee58: fa483282    	ccmp	x20, x8, #0x2, lo
10034ee5c: 540000e3    	b.lo	0x10034ee78 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4b4>
10034ee60: 94092909    	bl	0x100599284 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicmakeslicelen>
10034ee64: aa1403e0    	mov	x0, x20
10034ee68: 52800021    	mov	w1, #0x1                ; =1
10034ee6c: aa0303e2    	mov	x2, x3
10034ee70: 52800043    	mov	w3, #0x2                ; =2
10034ee74: 9408ebc7    	bl	0x100589d90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10034ee78: 94092de3    	bl	0x10059a604 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicmakeslicecap>
10034ee7c: aa1303e0    	mov	x0, x19
10034ee80: aa0803e1    	mov	x1, x8
10034ee84: 9408edea    	bl	0x10058a62c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10034ee88: 90002f00    	adrp	x0, 0x10092e000 <_[8]_llgo_Pointer+0x10>
10034ee8c: 9120e000    	add	x0, x0, #0x838
10034ee90: f0002ea1    	adrp	x1, 0x100925000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.boundsErrorFmts+0x20>
10034ee94: 9103c021    	add	x1, x1, #0xf0
10034ee98: 9408e7b5    	bl	0x100588d6c <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10034ee9c: d4200020    	brk	#0x1
