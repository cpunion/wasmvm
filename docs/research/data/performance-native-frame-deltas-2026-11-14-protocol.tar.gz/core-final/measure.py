from pathlib import Path
import json,os,random,statistics,sys,hashlib,subprocess
D=Path(__file__).resolve().parent;A=D.parent.parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup')
sys.path.insert(0,str(W/'benchmarks'));sys.path.insert(0,str(W/'benchmarks/native'))
import interleaved,runtime_fixtures
os.environ['GOMAXPROCS']='1';os.environ['GOGC']='100'
count=20000000;seed=17;expected=runtime_fixtures.checksum('indirect-calls',seed,count)
refs=json.loads((A/'transitive-leaves/plan.json').read_text())['commands']
binaries={'base':str(D.parent/'base-go-phase'),'head':str(D.parent/'head-go-phase'),**{k:refs[k][0]for k in ('wazero','wasmtime','wasmer')}}
commands={}
for name,binary in binaries.items():
 cmd=[binary,'--backend','native'if name in ('base','head')else'compiler','--wasm',str(W/'benchmarks/native/runtime-fixtures/indirect-calls.wasm'),'--iterations',str(count),'--seed',str(seed),'--expected',str(expected),'--samples','7','--warmups','2']
 if name in ('base','head'):cmd+=['--mode','api']
 commands[name]=cmd;commands[name+'-aa']=cmd
plan=dict(blocks=20,samples=7,warmups=2,iterations=count,seed=seed,expected=expected,randomSeed=202611142252,commands=commands,binaryHashes={k:hashlib.sha256(Path(v).read_bytes()).hexdigest()for k,v in binaries.items()},scope='Fixed20block200process independent pure indirect-call screen with three pinned references, samebinary aliases,20000000 source iterations, seven interleaved warmcalls, no extension; all results checked, preparation separate. No owned builds/tests/profiles/edits/pruning overlap. Diagnostic only.')
assert not(D/'rows.jsonl').exists();(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rng=random.Random(plan['randomSeed']);rows=[]
for block in range(plan['blocks']):
 load=subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True);(D/f'load-{block}.txt').write_text('\n'.join(l for l in load.splitlines()[1:]if float(l.split(None,2)[1])>5)+'\n')
 observations,orders=interleaved.invoke(commands,180,rng,samples=7)
 for name,ob in observations.items():
  r=ob['record'];assert r['result']==expected and r['warmResults']==[expected]*7 and r['warmupResults']==[expected]*2
  row=dict(block=block,id=name,nsPerIteration=statistics.median(r['warmCallNs'])/count,observation=ob,orders=orders)
  with(D/'rows.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  rows.append(row)
 print('block',block,{n:round(rows[-len(commands)+i]['nsPerIteration'],4)for i,n in enumerate(observations)},flush=True)
summary={n:statistics.median(r['nsPerIteration']for r in rows if r['id']==n)for n in commands};(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
