
/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-frame-deltas-20261114/head-llgo-runner:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010034e9b8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames>:
10034e9b8: d10443ff    	sub	sp, sp, #0x110
10034e9bc: a90b6ffc    	stp	x28, x27, [sp, #0xb0]
10034e9c0: a90c67fa    	stp	x26, x25, [sp, #0xc0]
10034e9c4: a90d5ff8    	stp	x24, x23, [sp, #0xd0]
10034e9c8: a90e57f6    	stp	x22, x21, [sp, #0xe0]
10034e9cc: a90f4ff4    	stp	x20, x19, [sp, #0xf0]
10034e9d0: a9107bfd    	stp	x29, x30, [sp, #0x100]
10034e9d4: 910403fd    	add	x29, sp, #0x100
10034e9d8: f940c808    	ldr	x8, [x0, #0x190]
10034e9dc: b4002028    	cbz	x8, 0x10034ede0 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x428>
10034e9e0: f100111f    	cmp	x8, #0x4
10034e9e4: 54002049    	b.ls	0x10034edec <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x434>
10034e9e8: f940082a    	ldr	x10, [x1, #0x10]
10034e9ec: f100055f    	cmp	x10, #0x1
10034e9f0: 540000ab    	b.lt	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034e9f4: f940c409    	ldr	x9, [x0, #0x188]
10034e9f8: a9402d34    	ldp	x20, x11, [x9]
10034e9fc: eb0b029f    	cmp	x20, x11
10034ea00: 54000189    	b.ls	0x10034ea30 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x78>
10034ea04: d0013528    	adrp	x8, 0x1029f4000 <__MergedGlobals.22796+0x5e0>
10034ea08: 912ec108    	add	x8, x8, #0xbb0
10034ea0c: a9400500    	ldp	x0, x1, [x8]
10034ea10: a9507bfd    	ldp	x29, x30, [sp, #0x100]
10034ea14: a94f4ff4    	ldp	x20, x19, [sp, #0xf0]
10034ea18: a94e57f6    	ldp	x22, x21, [sp, #0xe0]
10034ea1c: a94d5ff8    	ldp	x24, x23, [sp, #0xd0]
10034ea20: a94c67fa    	ldp	x26, x25, [sp, #0xc0]
10034ea24: a94b6ffc    	ldp	x28, x27, [sp, #0xb0]
10034ea28: 910443ff    	add	sp, sp, #0x110
10034ea2c: d65f03c0    	ret
10034ea30: b940282b    	ldr	w11, [x1, #0x28]
10034ea34: eb14016b    	subs	x11, x11, x20
10034ea38: 54fffe63    	b.lo	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea3c: eb0b015f    	cmp	x10, x11
10034ea40: 54fffe28    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea44: d37df108    	lsl	x8, x8, #3
10034ea48: d100a108    	sub	x8, x8, #0x28
10034ea4c: eb481a9f    	cmp	x20, x8, lsr #6
10034ea50: 54fffda8    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea54: f9408c08    	ldr	x8, [x0, #0x118]
10034ea58: 8b14014a    	add	x10, x10, x20
10034ea5c: eb0a011f    	cmp	x8, x10
10034ea60: 54fffd21    	b.ne	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea64: f9401133    	ldr	x19, [x9, #0x20]
10034ea68: eb14027f    	cmp	x19, x20
10034ea6c: 54fffcc8    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea70: b9406828    	ldr	w8, [x1, #0x68]
10034ea74: eb08027f    	cmp	x19, x8
10034ea78: 54fffc68    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea7c: f940d405    	ldr	x5, [x0, #0x1a8]
10034ea80: b4000073    	cbz	x19, 0x10034ea8c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0xd4>
10034ea84: eb05027f    	cmp	x19, x5
10034ea88: 54fffbe2    	b.hs	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ea8c: f940d803    	ldr	x3, [x0, #0x1b0]
10034ea90: 91000688    	add	x8, x20, #0x1
10034ea94: aa0103f6    	mov	x22, x1
10034ea98: aa0003f7    	mov	x23, x0
10034ea9c: eb14007f    	cmp	x3, x20
10034eaa0: 540003ad    	b.le	0x10034eb14 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x15c>
10034eaa4: f940d001    	ldr	x1, [x0, #0x1a0]
10034eaa8: eb05011f    	cmp	x8, x5
10034eaac: 540001ea    	b.ge	0x10034eae8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x130>
10034eab0: aa0003f5    	mov	x21, x0
10034eab4: 910103e0    	add	x0, sp, #0x40
10034eab8: 91000684    	add	x4, x20, #0x1
10034eabc: 52800302    	mov	w2, #0x18               ; =24
10034eac0: 52800026    	mov	w6, #0x1                ; =1
10034eac4: 52800027    	mov	w7, #0x1                ; =1
10034eac8: 390003ff    	strb	wzr, [sp]
10034eacc: 94093757    	bl	0x10059c828 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034ead0: a94423e0    	ldp	x0, x8, [sp, #0x40]
10034ead4: 8b080508    	add	x8, x8, x8, lsl #1
10034ead8: d37df101    	lsl	x1, x8, #3
10034eadc: 940951bc    	bl	0x1005a31cc <dyld_stub_binder+0x1005a31cc>
10034eae0: f940d2a1    	ldr	x1, [x21, #0x1a0]
10034eae4: f940daa3    	ldr	x3, [x21, #0x1b0]
10034eae8: 910163e0    	add	x0, sp, #0x58
10034eaec: 91000685    	add	x5, x20, #0x1
10034eaf0: 52800302    	mov	w2, #0x18               ; =24
10034eaf4: aa1f03e4    	mov	x4, xzr
10034eaf8: 52800026    	mov	w6, #0x1                ; =1
10034eafc: 52800027    	mov	w7, #0x1                ; =1
10034eb00: 390003ff    	strb	wzr, [sp]
10034eb04: 94093749    	bl	0x10059c828 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034eb08: a945e3f5    	ldp	x21, x24, [sp, #0x58]
10034eb0c: f94037f9    	ldr	x25, [sp, #0x68]
10034eb10: 1400001e    	b	0x10034eb88 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x1d0>
10034eb14: aa0003fa    	mov	x26, x0
10034eb18: 910043e0    	add	x0, sp, #0x10
10034eb1c: 91000681    	add	x1, x20, #0x1
10034eb20: 91000682    	add	x2, x20, #0x1
10034eb24: 52800303    	mov	w3, #0x18               ; =24
10034eb28: 52800024    	mov	w4, #0x1                ; =1
10034eb2c: 94093233    	bl	0x10059b3f8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MakeSlice>
10034eb30: a94163f5    	ldp	x21, x24, [sp, #0x10]
10034eb34: 9100a3e0    	add	x0, sp, #0x28
10034eb38: f940d341    	ldr	x1, [x26, #0x1a0]
10034eb3c: f940db43    	ldr	x3, [x26, #0x1b0]
10034eb40: 52800302    	mov	w2, #0x18               ; =24
10034eb44: f94013f9    	ldr	x25, [sp, #0x20]
10034eb48: aa1f03e4    	mov	x4, xzr
10034eb4c: aa1303e5    	mov	x5, x19
10034eb50: 52800026    	mov	w6, #0x1                ; =1
10034eb54: 52800027    	mov	w7, #0x1                ; =1
10034eb58: 390003ff    	strb	wzr, [sp]
10034eb5c: 94093733    	bl	0x10059c828 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034eb60: f9401be8    	ldr	x8, [sp, #0x30]
10034eb64: eb08031f    	cmp	x24, x8
10034eb68: 9a88b308    	csel	x8, x24, x8, lt
10034eb6c: f100051f    	cmp	x8, #0x1
10034eb70: 540000cb    	b.lt	0x10034eb88 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x1d0>
10034eb74: 8b080508    	add	x8, x8, x8, lsl #1
10034eb78: f94017e1    	ldr	x1, [sp, #0x28]
10034eb7c: aa1503e0    	mov	x0, x21
10034eb80: d37df102    	lsl	x2, x8, #3
10034eb84: 9409516e    	bl	0x1005a313c <dyld_stub_binder+0x1005a313c>
10034eb88: aa1603e9    	mov	x9, x22
10034eb8c: aa1703ea    	mov	x10, x23
10034eb90: eb14027f    	cmp	x19, x20
10034eb94: a91a62f5    	stp	x21, x24, [x23, #0x1a0]
10034eb98: f900daf9    	str	x25, [x23, #0x1b0]
10034eb9c: 540009c2    	b.hs	0x10034ecd4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x31c>
10034eba0: 8b130668    	add	x8, x19, x19, lsl #1
10034eba4: d37df26c    	lsl	x12, x19, #3
10034eba8: 5280002d    	mov	w13, #0x1               ; =1
10034ebac: aa1303e0    	mov	x0, x19
10034ebb0: d37df10b    	lsl	x11, x8, #3
10034ebb4: f940c941    	ldr	x1, [x10, #0x190]
10034ebb8: 91001588    	add	x8, x12, #0x5
10034ebbc: eb01011f    	cmp	x8, x1
10034ebc0: 540011c2    	b.hs	0x10034edf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x440>
10034ebc4: f9400128    	ldr	x8, [x9]
10034ebc8: f940c54e    	ldr	x14, [x10, #0x188]
10034ebcc: f9402108    	ldr	x8, [x8, #0x40]
10034ebd0: 8b0c0dce    	add	x14, x14, x12, lsl #3
10034ebd4: b4000248    	cbz	x8, 0x10034ec1c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x264>
10034ebd8: f9400d0f    	ldr	x15, [x8, #0x18]
10034ebdc: b40003af    	cbz	x15, 0x10034ec50 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x298>
10034ebe0: f94015d0    	ldr	x16, [x14, #0x28]
10034ebe4: f9402511    	ldr	x17, [x8, #0x48]
10034ebe8: eb11021f    	cmp	x16, x17
10034ebec: 54000182    	b.hs	0x10034ec1c <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x264>
10034ebf0: f9402111    	ldr	x17, [x8, #0x40]
10034ebf4: f8707a30    	ldr	x16, [x17, x16, lsl #3]
10034ebf8: b4000190    	cbz	x16, 0x10034ec28 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x270>
10034ebfc: f9406df1    	ldr	x17, [x15, #0xd8]
10034ec00: eb11021f    	cmp	x16, x17
10034ec04: 54000122    	b.hs	0x10034ec28 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x270>
10034ec08: f94069ef    	ldr	x15, [x15, #0xd0]
10034ec0c: f87079ef    	ldr	x15, [x15, x16, lsl #3]
10034ec10: b40000cf    	cbz	x15, 0x10034ec28 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x270>
10034ec14: 381a83ad    	sturb	w13, [x29, #-0x58]
10034ec18: 14000006    	b	0x10034ec30 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x278>
10034ec1c: 2a1f03f0    	mov	w16, wzr
10034ec20: aa1f03ef    	mov	x15, xzr
10034ec24: 1400000c    	b	0x10034ec54 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x29c>
10034ec28: aa1f03ef    	mov	x15, xzr
10034ec2c: 381a83bf    	sturb	wzr, [x29, #-0x58]
10034ec30: 385a83b0    	ldurb	w16, [x29, #-0x58]
10034ec34: 360000f0    	tbz	w16, #0x0, 0x10034ec50 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x298>
10034ec38: f94025f0    	ldr	x16, [x15, #0x48]
10034ec3c: b40000d0    	cbz	x16, 0x10034ec54 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x29c>
10034ec40: f94021f0    	ldr	x16, [x15, #0x40]
10034ec44: eb08021f    	cmp	x16, x8
10034ec48: 1a9f17f0    	cset	w16, eq
10034ec4c: 14000002    	b	0x10034ec54 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x29c>
10034ec50: 2a1f03f0    	mov	w16, wzr
10034ec54: 91001988    	add	x8, x12, #0x6
10034ec58: eb01011f    	cmp	x8, x1
10034ec5c: 54000ce2    	b.hs	0x10034edf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x440>
10034ec60: 91001d88    	add	x8, x12, #0x7
10034ec64: eb01011f    	cmp	x8, x1
10034ec68: 54000c82    	b.hs	0x10034edf8 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x440>
10034ec6c: 34ffecd0    	cbz	w16, 0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ec70: f94019c8    	ldr	x8, [x14, #0x30]
10034ec74: 92400d10    	and	x16, x8, #0xf
10034ec78: b5ffec70    	cbnz	x16, 0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ec7c: d344fd08    	lsr	x8, x8, #4
10034ec80: f9402d50    	ldr	x16, [x10, #0x58]
10034ec84: eb10011f    	cmp	x8, x16
10034ec88: 54ffebe8    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ec8c: f94025f0    	ldr	x16, [x15, #0x48]
10034ec90: f9401dce    	ldr	x14, [x14, #0x38]
10034ec94: f9405e10    	ldr	x16, [x16, #0xb8]
10034ec98: eb1001df    	cmp	x14, x16
10034ec9c: 54ffeb42    	b.hs	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034eca0: f940d541    	ldr	x1, [x10, #0x1a8]
10034eca4: eb01001f    	cmp	x0, x1
10034eca8: 54000aa2    	b.hs	0x10034edfc <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x444>
10034ecac: f940d150    	ldr	x16, [x10, #0x1a0]
10034ecb0: 91000400    	add	x0, x0, #0x1
10034ecb4: 9100218c    	add	x12, x12, #0x8
10034ecb8: eb00029f    	cmp	x20, x0
10034ecbc: 8b0b0210    	add	x16, x16, x11
10034ecc0: 9100616b    	add	x11, x11, #0x18
10034ecc4: a900220f    	stp	x15, x8, [x16]
10034ecc8: 110005cf    	add	w15, w14, #0x1
10034eccc: 29023a0f    	stp	w15, w14, [x16, #0x10]
10034ecd0: 54fff721    	b.ne	0x10034ebb4 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x1fc>
10034ecd4: f9400128    	ldr	x8, [x9]
10034ecd8: f9409141    	ldr	x1, [x10, #0x120]
10034ecdc: f9402100    	ldr	x0, [x8, #0x40]
10034ece0: 9400004a    	bl	0x10034ee08 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.linkedFunction>
10034ece4: 3607e901    	tbz	w1, #0x0, 0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ece8: f9408ae8    	ldr	x8, [x23, #0x110]
10034ecec: 92400d09    	and	x9, x8, #0xf
10034ecf0: b5ffe8a9    	cbnz	x9, 0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ecf4: f9402409    	ldr	x9, [x0, #0x48]
10034ecf8: d344fd08    	lsr	x8, x8, #4
10034ecfc: f9402eea    	ldr	x10, [x23, #0x58]
10034ed00: f9404d29    	ldr	x9, [x9, #0x98]
10034ed04: 8b080135    	add	x21, x9, x8
10034ed08: eb0a02bf    	cmp	x21, x10
10034ed0c: 54ffe7c8    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ed10: b9402eca    	ldr	w10, [x22, #0x2c]
10034ed14: aa1603e9    	mov	x9, x22
10034ed18: eb0a02bf    	cmp	x21, x10
10034ed1c: 54ffe748    	b.hi	0x10034ea04 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x4c>
10034ed20: f940d6e1    	ldr	x1, [x23, #0x1a8]
10034ed24: eb01029f    	cmp	x20, x1
10034ed28: 540006c2    	b.hs	0x10034ee00 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x448>
10034ed2c: 5280030a    	mov	w10, #0x18              ; =24
10034ed30: f940d2eb    	ldr	x11, [x23, #0x1a0]
10034ed34: b9401929    	ldr	w9, [x9, #0x18]
10034ed38: 9b0a2e8a    	madd	x10, x20, x10, x11
10034ed3c: 52800302    	mov	w2, #0x18               ; =24
10034ed40: aa1303e4    	mov	x4, x19
10034ed44: 2a1f03e6    	mov	w6, wzr
10034ed48: 52800027    	mov	w7, #0x1                ; =1
10034ed4c: a9002140    	stp	x0, x8, [x10]
10034ed50: 9101c3e0    	add	x0, sp, #0x70
10034ed54: 29027d49    	stp	w9, wzr, [x10, #0x10]
10034ed58: a95a16e1    	ldp	x1, x5, [x23, #0x1a0]
10034ed5c: f940dae3    	ldr	x3, [x23, #0x1b0]
10034ed60: 390003ff    	strb	wzr, [sp]
10034ed64: 940936b1    	bl	0x10059c828 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034ed68: a94763f4    	ldp	x20, x24, [sp, #0x70]
10034ed6c: d101e3a0    	sub	x0, x29, #0x78
10034ed70: f9402ae1    	ldr	x1, [x23, #0x50]
10034ed74: f94032e3    	ldr	x3, [x23, #0x60]
10034ed78: 52800202    	mov	w2, #0x10               ; =16
10034ed7c: f94043f9    	ldr	x25, [sp, #0x80]
10034ed80: aa1f03e4    	mov	x4, xzr
10034ed84: aa1503e5    	mov	x5, x21
10034ed88: 52800026    	mov	w6, #0x1                ; =1
10034ed8c: 52800027    	mov	w7, #0x1                ; =1
10034ed90: 390003ff    	strb	wzr, [sp]
10034ed94: 940936a5    	bl	0x10059c828 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10034ed98: f85883a8    	ldur	x8, [x29, #-0x78]
10034ed9c: b9406ac9    	ldr	w9, [x22, #0x68]
10034eda0: 3cd903a0    	ldur	q0, [x29, #-0x70]
10034eda4: a904e2d4    	stp	x20, x24, [x22, #0x48]
10034eda8: f9001ac8    	str	x8, [x22, #0x30]
10034edac: 4b130128    	sub	w8, w9, w19
10034edb0: f9002ed9    	str	x25, [x22, #0x58]
10034edb4: 3c8382c0    	stur	q0, [x22, #0x38]
10034edb8: b9006ac8    	str	w8, [x22, #0x68]
10034edbc: b4000138    	cbz	x24, 0x10034ede0 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x428>
10034edc0: a9402688    	ldp	x8, x9, [x20]
10034edc4: aa1f03e0    	mov	x0, xzr
10034edc8: f9400aca    	ldr	x10, [x22, #0x10]
10034edcc: aa1f03e1    	mov	x1, xzr
10034edd0: a90026c8    	stp	x8, x9, [x22]
10034edd4: 8b130148    	add	x8, x10, x19
10034edd8: f9000ac8    	str	x8, [x22, #0x10]
10034eddc: 17ffff0d    	b	0x10034ea10 <_github.com/cpunion/wasmvm/internal/engine/nativeexec.(*Execution).publishCallFrames+0x58>
10034ede0: aa1f03e0    	mov	x0, xzr
10034ede4: aa1f03e1    	mov	x1, xzr
10034ede8: 9408e8f1    	bl	0x1005891ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10034edec: 52800080    	mov	w0, #0x4                ; =4
10034edf0: aa0803e1    	mov	x1, x8
10034edf4: 9408e8ee    	bl	0x1005891ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10034edf8: aa0803e0    	mov	x0, x8
10034edfc: 9408ee59    	bl	0x10058a760 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10034ee00: aa1403e0    	mov	x0, x20
10034ee04: 9408ee57    	bl	0x10058a760 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
