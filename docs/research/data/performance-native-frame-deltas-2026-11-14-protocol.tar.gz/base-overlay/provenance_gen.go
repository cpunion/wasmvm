package phase
func init(){sourceRevision="1ebf33e5ffc61d2fedc6782107e3f3fc59ff0c0b";compilerRevision="go1.27.3"}
