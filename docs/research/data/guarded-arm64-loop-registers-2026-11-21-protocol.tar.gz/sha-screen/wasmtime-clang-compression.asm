mov     w23, #0x20
movk    w23, #1, lsl #16
add     w23, w21, w23
ldr     w23, [x0, w23, uxtw]
add     w24, w5, w21
ldr     w24, [x0, w24, uxtw]
ror     w26, w9, #2
ror     w27, w9, #0xd
eor     w26, w26, w27
ror     w27, w9, #0x16
eor     w26, w26, w27
eor     w27, w12, w14
and     w27, w9, w27
and     w28, w14, w12
eor     w27, w27, w28
add     w26, w26, w27
ror     w27, w15, #6
ror     w28, w15, #0xb
eor     w27, w27, w28
ror     w28, w15, #0x19
eor     w27, w27, w28
add     w25, w25, w27
eor     w27, w19, w20
and     w27, w27, w15
eor     w27, w27, w20
add     w25, w25, w27
add     w23, w25, w23
add     w24, w23, w24
add     w23, w26, w24
add     w22, w24, w22
add     w24, w21, #4
cmp     w21, #0xfc
b.eq    #0x5a0
mov     x25, x20
mov     x21, x24
mov     x20, x19
mov     x19, x15
mov     x15, x22
mov     x22, x14
mov     x14, x12
mov     x12, x9
mov     x9, x23
b       #0x4f4
