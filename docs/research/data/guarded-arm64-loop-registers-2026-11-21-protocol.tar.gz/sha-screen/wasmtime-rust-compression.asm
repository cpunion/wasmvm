add     w23, w21, #0x100, lsl #12
ldr     w23, [x0, w23, uxtw]
add     w24, w5, w21
ldr     w24, [x0, w24, uxtw]
eor     w26, w13, w10
and     w26, w26, w8
and     w27, w10, w13
eor     w26, w26, w27
ror     w27, w8, #2
ror     w28, w8, #0xd
eor     w27, w27, w28
ror     w28, w8, #0x16
eor     w27, w27, w28
add     w26, w26, w27
ror     w27, w15, #6
ror     w28, w15, #0xb
eor     w27, w27, w28
ror     w28, w15, #0x19
eor     w27, w27, w28
add     w25, w27, w25
eor     w27, w20, w19
and     w27, w27, w15
eor     w27, w20, w27
add     w25, w25, w27
add     w23, w25, w23
add     w24, w23, w24
add     w23, w26, w24
add     w22, w24, w22
add     w24, w21, #4
cmp     w21, #0xfc
b.eq    #0x198
mov     x25, x20
mov     x21, x24
mov     x20, x19
mov     x19, x15
mov     x15, x22
mov     x22, x13
mov     x13, x10
mov     x10, x8
mov     x8, x23
b       #0xf4
