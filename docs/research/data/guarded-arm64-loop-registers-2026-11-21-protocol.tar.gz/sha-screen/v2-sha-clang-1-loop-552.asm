	mov	x1, x24
	mov	x24, x4
	ror	w21, w24, #2
	eor	w21, w21, w24, ror #13
	eor	w21, w21, w24, ror #22
	mov	x8, x26
	eor	w22, w1, w8
	and	w22, w24, w22
	and	w23, w8, w1
	eor	w22, w22, w23
	add	w21, w21, w22
	mov	x19, x3
	ror	w22, w19, #6
	eor	w22, w22, w19, ror #11
	eor	w22, w22, w19, ror #25
	add	w22, w5, w22
	mov	x6, x28
	mov	x5, x2
	eor	w23, w6, w5
	and	w23, w23, w19
	eor	w23, w23, w5
	add	w22, w22, w23
	mov	w23, #32                        ; =0x20
	movk	w23, #1, lsl #16
	add	w23, w25, w23
	ldr	w20, [x16, w23, uxtw]
	add	w22, w22, w20
	ldr	w9, [x12, #16]
	mov	w10, w25
	add	w9, w9, w10
	mov	x20, x9
	ldr	w23, [x16, w20, uxtw]
	add	w3, w22, w23
	mov	x22, x3
	add	w4, w21, w3
	add	w3, w3, w27
	mov	x2, x6
	mov	x28, x19
	mov	x27, x8
	mov	x26, x1
	add	w25, w25, #4
	ldr	x9, [x0, #144]
	cbnz	x9, #4528
	cmp	w25, #256
	b.ne	#-176
