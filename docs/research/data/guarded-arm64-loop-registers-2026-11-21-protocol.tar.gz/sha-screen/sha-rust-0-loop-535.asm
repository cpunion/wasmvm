	mov	x9, x5
	str	x9, [x12, #336]
	mov	x5, x4
	mov	x4, x1
	eor	w21, w5, w4
	mov	x1, x8
	and	w21, w21, w1
	and	w23, w4, w5
	eor	w21, w21, w23
	ror	w23, w1, #2
	eor	w23, w23, w1, ror #13
	eor	w23, w23, w1, ror #22
	add	w21, w21, w23
	mov	x19, x3
	ror	w23, w19, #6
	eor	w23, w23, w19, ror #11
	eor	w23, w23, w19, ror #25
	add	w23, w23, w6
	mov	x6, x7
	mov	x7, x2
	eor	w22, w6, w7
	and	w22, w22, w19
	eor	w22, w6, w22
	add	w23, w23, w22
	mov	w22, #1048576                   ; =0x100000
	add	w22, w25, w22
	ldr	w20, [x16, w22, uxtw]
	add	w23, w23, w20
	ldr	w9, [x12, #16]
	mov	w10, w25
	add	w9, w9, w10
	mov	x20, x9
	ldr	w22, [x16, w20, uxtw]
	add	w3, w23, w22
	mov	x23, x3
	add	w8, w21, w3
	mov	w9, w3
	ldr	w10, [x12, #336]
	add	w9, w9, w10
	mov	x21, x9
	mov	x3, x21
	mov	x2, x19
	add	w25, w25, #4
	ldr	x9, [x0, #144]
	cbnz	x9, #4336
	cmp	w25, #256
	b.ne	#-184
