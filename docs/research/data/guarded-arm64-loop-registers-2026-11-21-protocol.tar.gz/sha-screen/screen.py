from pathlib import Path
import hashlib,json,os,random,statistics,sys
p=Path(__file__).resolve().parent
w=p.parents[3]/'wasmvm-source-cleanup'
sys.path.insert(0,str(w/'benchmarks'))
import interleaved
plan=json.loads((p/'screen-plan.json').read_text())
for path,digest in plan['sha256'].items():
 assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
rng=random.Random(plan['seed'])
os.environ.update(GOMAXPROCS='1',GOGC='100')
rows=[]
for block in range(plan['blocks']):
 cases=plan['cases'][:]
 rng.shuffle(cases)
 for fixture,commands in cases:
  result,_=interleaved.invoke(commands|{k+'-aa':v for k,v in commands.items()},180,rng,samples=7)
  name=fixture['cohort']+'/'+fixture['id']
  for id,obs in result.items():
   record=obs['record'];expected=fixture['expectedChecksum']
   assert record.get('result',record.get('checksum'))==expected
   assert len(record['warmCallNs'])==7
   if 'warmResults' in record:
    assert record['warmResults']==[expected]*7
   rows.append(dict(block=block,case=name,id=id,record=record,ns=statistics.median(record['warmCallNs'])/fixture['iterations']))
  print('checked',block,name,flush=True)
assert len(rows)==2*plan['blocks']*sum(len(roles)for f,roles in plan['cases'])
(p/'screen-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
