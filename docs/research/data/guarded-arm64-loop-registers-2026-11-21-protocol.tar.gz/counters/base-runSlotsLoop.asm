Disassembly of section __TEXT,__text:

000000010002f764 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>:
10002f764: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10002f768: a90167fa    	stp	x26, x25, [sp, #0x10]
10002f76c: a9025ff8    	stp	x24, x23, [sp, #0x20]
10002f770: a90357f6    	stp	x22, x21, [sp, #0x30]
10002f774: a9044ff4    	stp	x20, x19, [sp, #0x40]
10002f778: a9057bfd    	stp	x29, x30, [sp, #0x50]
10002f77c: 910143fd    	add	x29, sp, #0x50
10002f780: d10743ff    	sub	sp, sp, #0x1d0
10002f784: b400e9c0    	cbz	x0, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f788: f9402408    	ldr	x8, [x0, #0x48]
10002f78c: aa0003f5    	mov	x21, x0
10002f790: f100051f    	cmp	x8, #0x1
10002f794: 5400fceb    	b.lt	0x100031730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
10002f798: 394082bb    	ldrb	w27, [x21, #0x20]
10002f79c: aa0103f3    	mov	x19, x1
10002f7a0: b90027fb    	str	w27, [sp, #0x24]
10002f7a4: f94022a9    	ldr	x9, [x21, #0x40]
10002f7a8: 8b081929    	add	x9, x9, x8, lsl #6
10002f7ac: aa0903e8    	mov	x8, x9
10002f7b0: f9001be9    	str	x9, [sp, #0x30]
10002f7b4: f85c0d0a    	ldr	x10, [x8, #-0x40]!
10002f7b8: 381d013f    	sturb	wzr, [x9, #-0x30]
10002f7bc: b400e808    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f7c0: b400e7ea    	cbz	x10, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f7c4: f940254f    	ldr	x15, [x10, #0x48]
10002f7c8: b400e7af    	cbz	x15, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f7cc: f9401be8    	ldr	x8, [sp, #0x30]
10002f7d0: f9404df4    	ldr	x20, [x15, #0x98]
10002f7d4: f94046a2    	ldr	x2, [x21, #0x88]
10002f7d8: f85d8108    	ldur	x8, [x8, #-0x28]
10002f7dc: 8b080289    	add	x9, x20, x8
10002f7e0: eb02013f    	cmp	x9, x2
10002f7e4: 5400f548    	b.hi	0x10003168c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
10002f7e8: eb09011f    	cmp	x8, x9
10002f7ec: 5400f468    	b.hi	0x100031678 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f14>
10002f7f0: f9401be9    	ldr	x9, [sp, #0x30]
10002f7f4: f9405df6    	ldr	x22, [x15, #0xb8]
10002f7f8: b85c8120    	ldur	w0, [x9, #-0x38]
10002f7fc: cb080049    	sub	x9, x2, x8
10002f800: d37ced08    	lsl	x8, x8, #4
10002f804: f100013f    	cmp	x9, #0x0
10002f808: 9a9fc108    	csel	x8, x8, xzr, gt
10002f80c: eb0002df    	cmp	x22, x0
10002f810: 5400f209    	b.ls	0x100031650 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002f814: f9403ea9    	ldr	x9, [x21, #0x78]
10002f818: f94059fa    	ldr	x26, [x15, #0xb0]
10002f81c: 2a0003f8    	mov	w24, w0
10002f820: f9000fea    	str	x10, [sp, #0x18]
10002f824: f940214a    	ldr	x10, [x10, #0x40]
10002f828: 8b080137    	add	x23, x9, x8
10002f82c: f9001fef    	str	x15, [sp, #0x38]
10002f830: f90017ea    	str	x10, [sp, #0x28]
10002f834: 14000006    	b	0x10002f84c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe8>
10002f838: 1100071c    	add	w28, w24, #0x1
10002f83c: 2a1c03e0    	mov	w0, w28
10002f840: 2a1c03f8    	mov	w24, w28
10002f844: eb0002df    	cmp	x22, x0
10002f848: 5400f049    	b.ls	0x100031650 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002f84c: 8b00175c    	add	x28, x26, x0, lsl #5
10002f850: 3600021b    	tbz	w27, #0x0, 0x10002f890 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x12c>
10002f854: f94041e1    	ldr	x1, [x15, #0x80]
10002f858: b9400780    	ldr	w0, [x28, #0x4]
10002f85c: eb00003f    	cmp	x1, x0
10002f860: 5400efa9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002f864: 52801c09    	mov	w9, #0xe0               ; =224
10002f868: f9403de8    	ldr	x8, [x15, #0x78]
10002f86c: 9ba92019    	umaddl	x25, w0, w9, x8
10002f870: b9400328    	ldr	w8, [x25]
10002f874: 7100151f    	cmp	w8, #0x5
10002f878: 7a4b1904    	ccmp	w8, #0xb, #0x4, ne
10002f87c: f940aaa8    	ldr	x8, [x21, #0x150]
10002f880: 1a9f07e9    	cset	w9, ne
10002f884: eb090108    	subs	x8, x8, x9
10002f888: 5400e223    	b.lo	0x1000314cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d68>
10002f88c: f900aaa8    	str	x8, [x21, #0x150]
10002f890: 91000673    	add	x19, x19, #0x1
10002f894: f240167f    	tst	x19, #0x3f
10002f898: 54000381    	b.ne	0x10002f908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
10002f89c: f940b2a8    	ldr	x8, [x21, #0x160]
10002f8a0: b4000068    	cbz	x8, 0x10002f8ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x148>
10002f8a4: 88dffd08    	ldar	w8, [x8]
10002f8a8: 34000268    	cbz	w8, 0x10002f8f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x190>
10002f8ac: f94006a8    	ldr	x8, [x21, #0x8]
10002f8b0: b400f348    	cbz	x8, 0x100031718 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
10002f8b4: f9400509    	ldr	x9, [x8, #0x8]
10002f8b8: f9400aa0    	ldr	x0, [x21, #0x10]
10002f8bc: 39405d29    	ldrb	w9, [x9, #0x17]
10002f8c0: 1200112a    	and	w10, w9, #0x1f
10002f8c4: 121b0129    	and	w9, w9, #0x20
10002f8c8: 7100595f    	cmp	w10, #0x16
10002f8cc: 7a401924    	ccmp	w9, #0x0, #0x4, ne
10002f8d0: 54000060    	b.eq	0x10002f8dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
10002f8d4: f81883a0    	stur	x0, [x29, #-0x78]
10002f8d8: d101e3a0    	sub	x0, x29, #0x78
10002f8dc: f9401508    	ldr	x8, [x8, #0x28]
10002f8e0: d63f0100    	blr	x8
10002f8e4: f9401fef    	ldr	x15, [sp, #0x38]
10002f8e8: aa0103e2    	mov	x2, x1
10002f8ec: b50000a0    	cbnz	x0, 0x10002f900 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x19c>
10002f8f0: 14000006    	b	0x10002f908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
10002f8f4: aa1f03e0    	mov	x0, xzr
10002f8f8: aa1f03e2    	mov	x2, xzr
10002f8fc: 14000003    	b	0x10002f908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
10002f900: f9400408    	ldr	x8, [x0, #0x8]
10002f904: b500e368    	cbnz	x8, 0x100031570 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e0c>
10002f908: b9401f88    	ldr	w8, [x28, #0x1c]
10002f90c: 340003e8    	cbz	w8, 0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f910: 360000fb    	tbz	w27, #0x0, 0x10002f92c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
10002f914: b9400389    	ldr	w9, [x28]
10002f918: 7100813f    	cmp	w9, #0x20
10002f91c: 54000360    	b.eq	0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f920: 7101053f    	cmp	w9, #0x41
10002f924: 54000320    	b.eq	0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f928: 14000019    	b	0x10002f98c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
10002f92c: b9400389    	ldr	w9, [x28]
10002f930: 7100813f    	cmp	w9, #0x20
10002f934: 54000060    	b.eq	0x10002f940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dc>
10002f938: 7101053f    	cmp	w9, #0x41
10002f93c: 54000281    	b.ne	0x10002f98c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
10002f940: 2a3303e8    	mvn	w8, w19
10002f944: f240151f    	tst	x8, #0x3f
10002f948: 54000200    	b.eq	0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f94c: 7101053f    	cmp	w9, #0x41
10002f950: 540000e1    	b.ne	0x10002f96c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x208>
10002f954: b9400b80    	ldr	w0, [x28, #0x8]
10002f958: eb00029f    	cmp	x20, x0
10002f95c: 5400e709    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002f960: b9401b88    	ldr	w8, [x28, #0x18]
10002f964: 8b0012e9    	add	x9, x23, x0, lsl #4
10002f968: a9007d28    	stp	x8, xzr, [x9]
10002f96c: 11000718    	add	w24, w24, #0x1
10002f970: eb1802df    	cmp	x22, x24
10002f974: 5400e5e9    	b.ls	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ecc>
10002f978: 8b18175c    	add	x28, x26, x24, lsl #5
10002f97c: 91000673    	add	x19, x19, #0x1
10002f980: b9401f88    	ldr	w8, [x28, #0x1c]
10002f984: 35fffd48    	cbnz	w8, 0x10002f92c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
10002f988: b9400389    	ldr	w9, [x28]
10002f98c: 529fe40a    	mov	w10, #0xff20            ; =65312
10002f990: 51038128    	sub	w8, w9, #0xe0
10002f994: 72a01fea    	movk	w10, #0xff, lsl #16
10002f998: 6b0a011f    	cmp	w8, w10
10002f99c: 54000482    	b.hs	0x10002fa2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c8>
10002f9a0: 53107d28    	lsr	w8, w9, #16
10002f9a4: 7103ed1f    	cmp	w8, #0xfb
10002f9a8: 54000ea0    	b.eq	0x10002fb7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x418>
10002f9ac: 7103f11f    	cmp	w8, #0xfc
10002f9b0: 540006a0    	b.eq	0x10002fa84 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x320>
10002f9b4: 7103f51f    	cmp	w8, #0xfd
10002f9b8: 54001361    	b.ne	0x10002fc24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c0>
10002f9bc: b9400f80    	ldr	w0, [x28, #0xc]
10002f9c0: 3100041f    	cmn	w0, #0x1
10002f9c4: 54002140    	b.eq	0x10002fdec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x688>
10002f9c8: eb00029f    	cmp	x20, x0
10002f9cc: 5400e389    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002f9d0: 8b0012e8    	add	x8, x23, x0, lsl #4
10002f9d4: a9402102    	ldp	x2, x8, [x8]
10002f9d8: b9401380    	ldr	w0, [x28, #0x10]
10002f9dc: 3100041f    	cmn	w0, #0x1
10002f9e0: 54002100    	b.eq	0x10002fe00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x69c>
10002f9e4: eb00029f    	cmp	x20, x0
10002f9e8: 5400e2a9    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002f9ec: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002f9f0: 3d801fe0    	str	q0, [sp, #0x70]
10002f9f4: a9471be5    	ldp	x5, x6, [sp, #0x70]
10002f9f8: b9401780    	ldr	w0, [x28, #0x14]
10002f9fc: 3100041f    	cmn	w0, #0x1
10002fa00: 540020a0    	b.eq	0x10002fe14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6b0>
10002fa04: eb00029f    	cmp	x20, x0
10002fa08: 5400e1a9    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fa0c: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fa10: 3d8023e0    	str	q0, [sp, #0x80]
10002fa14: a9482fea    	ldp	x10, x11, [sp, #0x80]
10002fa18: f94041e1    	ldr	x1, [x15, #0x80]
10002fa1c: b9400780    	ldr	w0, [x28, #0x4]
10002fa20: eb00003f    	cmp	x1, x0
10002fa24: 54002048    	b.hi	0x10002fe2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6c8>
10002fa28: 1400070b    	b	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fa2c: 51011528    	sub	w8, w9, #0x45
10002fa30: 7102011f    	cmp	w8, #0x80
10002fa34: 54000fc2    	b.hs	0x10002fc2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
10002fa38: 7101fd1f    	cmp	w8, #0x7f
10002fa3c: 5400bc08    	b.hi	0x1000311bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a58>
10002fa40: f0000f8c    	adrp	x12, 0x100222000 <dyld_stub_binder+0x100222000>
10002fa44: 911e418c    	add	x12, x12, #0x790
10002fa48: 1000008a    	adr	x10, 0x10002fa58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
10002fa4c: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
10002fa50: 8b0b094a    	add	x10, x10, x11, lsl #2
10002fa54: d61f0140    	br	x10
10002fa58: b9401380    	ldr	w0, [x28, #0x10]
10002fa5c: 3100041f    	cmn	w0, #0x1
10002fa60: 54003d60    	b.eq	0x10003020c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
10002fa64: eb00029f    	cmp	x20, x0
10002fa68: 5400dfa9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002fa6c: d37cec08    	lsl	x8, x0, #4
10002fa70: f8686ae2    	ldr	x2, [x23, x8]
10002fa74: b9400f80    	ldr	w0, [x28, #0xc]
10002fa78: eb00029f    	cmp	x20, x0
10002fa7c: 54003d08    	b.hi	0x10003021c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xab8>
10002fa80: 140006f7    	b	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002fa84: 529ffda8    	mov	w8, #0xffed             ; =65517
10002fa88: 72bfe068    	movk	w8, #0xff03, lsl #16
10002fa8c: 0b08012c    	add	w12, w9, w8
10002fa90: 7100119f    	cmp	w12, #0x4
10002fa94: 54000cc2    	b.hs	0x10002fc2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
10002fa98: 29430388    	ldp	w8, w0, [x28, #0x18]
10002fa9c: f9406dea    	ldr	x10, [x15, #0xd8]
10002faa0: 0b00010b    	add	w11, w8, w0
10002faa4: 11000962    	add	w2, w11, #0x2
10002faa8: eb02015f    	cmp	x10, x2
10002faac: 5400e103    	b.lo	0x1000316cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f68>
10002fab0: 6b02011f    	cmp	w8, w2
10002fab4: 5400e048    	b.hi	0x1000316bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f58>
10002fab8: cb08014a    	sub	x10, x10, x8
10002fabc: d37ef50b    	lsl	x11, x8, #2
10002fac0: f100015f    	cmp	x10, #0x0
10002fac4: 9a9fc16a    	csel	x10, x11, xzr, gt
10002fac8: 6b08005f    	cmp	w2, w8
10002facc: 5400df20    	b.eq	0x1000316b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fad0: f94065eb    	ldr	x11, [x15, #0xc8]
10002fad4: 8b0a016b    	add	x11, x11, x10
10002fad8: b940016a    	ldr	w10, [x11]
10002fadc: eb0a029f    	cmp	x20, x10
10002fae0: 5400dc69    	b.ls	0x10003166c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
10002fae4: cb080041    	sub	x1, x2, x8
10002fae8: f100043f    	cmp	x1, #0x1
10002faec: 5400dde0    	b.eq	0x1000316a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f44>
10002faf0: b9400568    	ldr	w8, [x11, #0x4]
10002faf4: eb08029f    	cmp	x20, x8
10002faf8: 5400db09    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fafc: d37ced4a    	lsl	x10, x10, #4
10002fb00: d37ced08    	lsl	x8, x8, #4
10002fb04: 7100099f    	cmp	w12, #0x2
10002fb08: f86a6aee    	ldr	x14, [x23, x10]
10002fb0c: f8686aed    	ldr	x13, [x23, x8]
10002fb10: 540020c2    	b.hs	0x10002ff28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7c4>
10002fb14: f1000c3f    	cmp	x1, #0x3
10002fb18: 5400dfa3    	b.lo	0x10003170c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa8>
10002fb1c: b9400968    	ldr	w8, [x11, #0x8]
10002fb20: eb08029f    	cmp	x20, x8
10002fb24: 5400d9a9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fb28: f1000c3f    	cmp	x1, #0x3
10002fb2c: 5400dec0    	b.eq	0x100031704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
10002fb30: b9400d6a    	ldr	w10, [x11, #0xc]
10002fb34: eb0a029f    	cmp	x20, x10
10002fb38: 5400d9a9    	b.ls	0x10003166c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
10002fb3c: d37ced08    	lsl	x8, x8, #4
10002fb40: d37ced4a    	lsl	x10, x10, #4
10002fb44: f8686aec    	ldr	x12, [x23, x8]
10002fb48: f86a6ae8    	ldr	x8, [x23, x10]
10002fb4c: 5280026a    	mov	w10, #0x13              ; =19
10002fb50: 72a01f8a    	movk	w10, #0xfc, lsl #16
10002fb54: 6b0a013f    	cmp	w9, w10
10002fb58: 54002c61    	b.ne	0x1000300e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x980>
10002fb5c: 8b0e018a    	add	x10, x12, x14
10002fb60: aa0e0189    	orr	x9, x12, x14
10002fb64: 8a0e018c    	and	x12, x12, x14
10002fb68: 8a2a0129    	bic	x9, x9, x10
10002fb6c: 8b0d0108    	add	x8, x8, x13
10002fb70: aa0c0129    	orr	x9, x9, x12
10002fb74: 8b49fd0c    	add	x12, x8, x9, lsr #63
10002fb78: 14000162    	b	0x100030100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
10002fb7c: 51000928    	sub	w8, w9, #0x2
10002fb80: 12003d09    	and	w9, w8, #0xffff
10002fb84: 7100853f    	cmp	w9, #0x21
10002fb88: d287c1e9    	mov	x9, #0x3e0f             ; =15887
10002fb8c: f2a38009    	movk	x9, #0x1c00, lsl #16
10002fb90: 1a9f27ea    	cset	w10, lo
10002fb94: f2c00029    	movk	x9, #0x1, lsl #32
10002fb98: 9ac82529    	lsr	x9, x9, x8
10002fb9c: 0a090149    	and	w9, w10, w9
10002fba0: 36001169    	tbz	w9, #0x0, 0x10002fdcc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x668>
10002fba4: b9400f80    	ldr	w0, [x28, #0xc]
10002fba8: 3100041f    	cmn	w0, #0x1
10002fbac: 54002160    	b.eq	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
10002fbb0: eb00029f    	cmp	x20, x0
10002fbb4: 5400d449    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fbb8: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fbbc: 3d8013e0    	str	q0, [sp, #0x40]
10002fbc0: a94413e3    	ldp	x3, x4, [sp, #0x40]
10002fbc4: b9401380    	ldr	w0, [x28, #0x10]
10002fbc8: 3100041f    	cmn	w0, #0x1
10002fbcc: 54002100    	b.eq	0x10002ffec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
10002fbd0: eb00029f    	cmp	x20, x0
10002fbd4: 5400d349    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fbd8: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fbdc: 3d8017e0    	str	q0, [sp, #0x50]
10002fbe0: a9451be5    	ldp	x5, x6, [sp, #0x50]
10002fbe4: 12003d08    	and	w8, w8, #0xffff
10002fbe8: 7100311f    	cmp	w8, #0xc
10002fbec: 540020a1    	b.ne	0x100030000 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x89c>
10002fbf0: b9401b88    	ldr	w8, [x28, #0x18]
10002fbf4: f94069e1    	ldr	x1, [x15, #0xd0]
10002fbf8: 11000900    	add	w0, w8, #0x2
10002fbfc: eb00003f    	cmp	x1, x0
10002fc00: 5400d2a9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fc04: f94065e8    	ldr	x8, [x15, #0xc8]
10002fc08: b8607900    	ldr	w0, [x8, x0, lsl #2]
10002fc0c: eb00029f    	cmp	x20, x0
10002fc10: 5400d169    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fc14: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fc18: 3d801be0    	str	q0, [sp, #0x60]
10002fc1c: a94627e7    	ldp	x7, x9, [sp, #0x60]
10002fc20: 140000fa    	b	0x100030008 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8a4>
10002fc24: 71039d3f    	cmp	w9, #0xe7
10002fc28: 5400c123    	b.lo	0x10003144c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
10002fc2c: 51000528    	sub	w8, w9, #0x1
10002fc30: 71034d1f    	cmp	w8, #0xd3
10002fc34: 540005e8    	b.hi	0x10002fcf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x58c>
10002fc38: f0000f8c    	adrp	x12, 0x100222000 <dyld_stub_binder+0x100222000>
10002fc3c: 9122418c    	add	x12, x12, #0x890
10002fc40: aa1f03e0    	mov	x0, xzr
10002fc44: 100000aa    	adr	x10, 0x10002fc58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f4>
10002fc48: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
10002fc4c: 8b0b094a    	add	x10, x10, x11, lsl #2
10002fc50: aa1f03e1    	mov	x1, xzr
10002fc54: d61f0140    	br	x10
10002fc58: f94041e1    	ldr	x1, [x15, #0x80]
10002fc5c: b9400780    	ldr	w0, [x28, #0x4]
10002fc60: eb00003f    	cmp	x1, x0
10002fc64: 5400cf89    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fc68: 52801c0a    	mov	w10, #0xe0              ; =224
10002fc6c: f9403de8    	ldr	x8, [x15, #0x78]
10002fc70: 9baa200a    	umaddl	x10, w0, w10, x8
10002fc74: b400c24a    	cbz	x10, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fc78: f94017e8    	ldr	x8, [sp, #0x28]
10002fc7c: b400c208    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fc80: f9403d01    	ldr	x1, [x8, #0x78]
10002fc84: b9401940    	ldr	w0, [x10, #0x18]
10002fc88: eb00003f    	cmp	x1, x0
10002fc8c: 5400ce49    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fc90: f9403908    	ldr	x8, [x8, #0x70]
10002fc94: ab000d08    	adds	x8, x8, x0, lsl #3
10002fc98: 5400c120    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fc9c: f940010b    	ldr	x11, [x8]
10002fca0: b400c0eb    	cbz	x11, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fca4: b9400f88    	ldr	w8, [x28, #0xc]
10002fca8: eb08029f    	cmp	x20, x8
10002fcac: 5400cd69    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fcb0: f9400960    	ldr	x0, [x11, #0x10]
10002fcb4: d37ced08    	lsl	x8, x8, #4
10002fcb8: b940154b    	ldr	w11, [x10, #0x14]
10002fcbc: b9401d4a    	ldr	w10, [x10, #0x1c]
10002fcc0: f940200c    	ldr	x12, [x0, #0x40]
10002fcc4: f8686ae2    	ldr	x2, [x23, x8]
10002fcc8: aa0a8163    	orr	x3, x11, x10, lsl #32
10002fccc: b400006c    	cbz	x12, 0x10002fcd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x574>
10002fcd0: f9403008    	ldr	x8, [x0, #0x60]
10002fcd4: b4001d68    	cbz	x8, 0x100030080 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x91c>
10002fcd8: d101e3a8    	sub	x8, x29, #0x78
10002fcdc: 2a0903e1    	mov	w1, w9
10002fce0: 2a1f03e4    	mov	w4, wzr
10002fce4: aa1f03e5    	mov	x5, xzr
10002fce8: aa1f03e6    	mov	x6, xzr
10002fcec: 14000073    	b	0x10002feb8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x754>
10002fcf0: 517f0128    	sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
10002fcf4: 7100211f    	cmp	w8, #0x8
10002fcf8: 54000e62    	b.hs	0x10002fec4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x760>
10002fcfc: b9400f80    	ldr	w0, [x28, #0xc]
10002fd00: eb00029f    	cmp	x20, x0
10002fd04: 5400cac9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002fd08: d37cec08    	lsl	x8, x0, #4
10002fd0c: 2a0903e0    	mov	w0, w9
10002fd10: aa1f03e2    	mov	x2, xzr
10002fd14: f8686ae1    	ldr	x1, [x23, x8]
10002fd18: 94009b57    	bl	0x100056a74 <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10002fd1c: aa0103f9    	mov	x25, x1
10002fd20: aa1f03e1    	mov	x1, xzr
10002fd24: 140000e5    	b	0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10002fd28: f94041e1    	ldr	x1, [x15, #0x80]
10002fd2c: b9400780    	ldr	w0, [x28, #0x4]
10002fd30: eb00003f    	cmp	x1, x0
10002fd34: 5400c909    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fd38: 52801c0a    	mov	w10, #0xe0              ; =224
10002fd3c: f9403de8    	ldr	x8, [x15, #0x78]
10002fd40: 9baa200b    	umaddl	x11, w0, w10, x8
10002fd44: b400bbcb    	cbz	x11, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd48: f94017e8    	ldr	x8, [sp, #0x28]
10002fd4c: b400bb88    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd50: f9403d01    	ldr	x1, [x8, #0x78]
10002fd54: b9401960    	ldr	w0, [x11, #0x18]
10002fd58: eb00003f    	cmp	x1, x0
10002fd5c: 5400c7c9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fd60: f9403908    	ldr	x8, [x8, #0x70]
10002fd64: ab000d08    	adds	x8, x8, x0, lsl #3
10002fd68: 5400baa0    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd6c: f940010c    	ldr	x12, [x8]
10002fd70: b400ba6c    	cbz	x12, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd74: b9400f88    	ldr	w8, [x28, #0xc]
10002fd78: eb08029f    	cmp	x20, x8
10002fd7c: 5400c6e9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fd80: b940138a    	ldr	w10, [x28, #0x10]
10002fd84: eb0a029f    	cmp	x20, x10
10002fd88: 5400c729    	b.ls	0x10003166c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
10002fd8c: f9400980    	ldr	x0, [x12, #0x10]
10002fd90: b940156c    	ldr	w12, [x11, #0x14]
10002fd94: d37ced08    	lsl	x8, x8, #4
10002fd98: b9401d6b    	ldr	w11, [x11, #0x1c]
10002fd9c: d37ced4a    	lsl	x10, x10, #4
10002fda0: f940200d    	ldr	x13, [x0, #0x40]
10002fda4: f8686ae2    	ldr	x2, [x23, x8]
10002fda8: aa0b8183    	orr	x3, x12, x11, lsl #32
10002fdac: f86a6ae5    	ldr	x5, [x23, x10]
10002fdb0: b400006d    	cbz	x13, 0x10002fdbc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x658>
10002fdb4: f9403008    	ldr	x8, [x0, #0x60]
10002fdb8: b4001fc8    	cbz	x8, 0x1000301b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
10002fdbc: 2a0903e1    	mov	w1, w9
10002fdc0: 2a1f03e4    	mov	w4, wzr
10002fdc4: aa1f03e6    	mov	x6, xzr
10002fdc8: 1400007e    	b	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x85c>
10002fdcc: f9401be8    	ldr	x8, [sp, #0x30]
10002fdd0: aa1503e0    	mov	x0, x21
10002fdd4: b81c8118    	stur	w24, [x8, #-0x38]
10002fdd8: 940006e1    	bl	0x10003195c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
10002fddc: f9401fef    	ldr	x15, [sp, #0x38]
10002fde0: 72001c1f    	tst	w0, #0xff
10002fde4: 54001440    	b.eq	0x10003006c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
10002fde8: 140005cb    	b	0x100031514 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
10002fdec: aa1f03e8    	mov	x8, xzr
10002fdf0: aa1f03e2    	mov	x2, xzr
10002fdf4: b9401380    	ldr	w0, [x28, #0x10]
10002fdf8: 3100041f    	cmn	w0, #0x1
10002fdfc: 54ffdf41    	b.ne	0x10002f9e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x280>
10002fe00: aa1f03e5    	mov	x5, xzr
10002fe04: aa1f03e6    	mov	x6, xzr
10002fe08: b9401780    	ldr	w0, [x28, #0x14]
10002fe0c: 3100041f    	cmn	w0, #0x1
10002fe10: 54ffdfa1    	b.ne	0x10002fa04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2a0>
10002fe14: aa1f03ea    	mov	x10, xzr
10002fe18: aa1f03eb    	mov	x11, xzr
10002fe1c: f94041e1    	ldr	x1, [x15, #0x80]
10002fe20: b9400780    	ldr	w0, [x28, #0x4]
10002fe24: eb00003f    	cmp	x1, x0
10002fe28: 5400c169    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fe2c: 52801c0d    	mov	w13, #0xe0              ; =224
10002fe30: f9403dec    	ldr	x12, [x15, #0x78]
10002fe34: 9bad3000    	umaddl	x0, w0, w13, x12
10002fe38: b400b420    	cbz	x0, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe3c: 121e352c    	and	w12, w9, #0xfffc
10002fe40: 12003d2d    	and	w13, w9, #0xffff
10002fe44: 7101519f    	cmp	w12, #0x54
10002fe48: 7a4b19a0    	ccmp	w13, #0xb, #0x0, ne
10002fe4c: 54000083    	b.lo	0x10002fe5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6f8>
10002fe50: 510171ae    	sub	w14, w13, #0x5c
10002fe54: 710009df    	cmp	w14, #0x2
10002fe58: 54000802    	b.hs	0x10002ff58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f4>
10002fe5c: f94017ea    	ldr	x10, [sp, #0x28]
10002fe60: b400b2ea    	cbz	x10, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe64: f9403d41    	ldr	x1, [x10, #0x78]
10002fe68: b9401808    	ldr	w8, [x0, #0x18]
10002fe6c: eb08003f    	cmp	x1, x8
10002fe70: 5400bfa9    	b.ls	0x100031664 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
10002fe74: f940394a    	ldr	x10, [x10, #0x70]
10002fe78: ab080d48    	adds	x8, x10, x8, lsl #3
10002fe7c: 5400b200    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe80: f9400108    	ldr	x8, [x8]
10002fe84: b400b1c8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe88: f940090a    	ldr	x10, [x8, #0x10]
10002fe8c: b9401408    	ldr	w8, [x0, #0x14]
10002fe90: b9401c0b    	ldr	w11, [x0, #0x1c]
10002fe94: 39410004    	ldrb	w4, [x0, #0x40]
10002fe98: f940214c    	ldr	x12, [x10, #0x40]
10002fe9c: aa0b8103    	orr	x3, x8, x11, lsl #32
10002fea0: b400006c    	cbz	x12, 0x10002feac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x748>
10002fea4: f9403148    	ldr	x8, [x10, #0x60]
10002fea8: b4000f88    	cbz	x8, 0x100030098 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x934>
10002feac: d101e3a8    	sub	x8, x29, #0x78
10002feb0: aa0a03e0    	mov	x0, x10
10002feb4: 2a0903e1    	mov	w1, w9
10002feb8: d101e3bb    	sub	x27, x29, #0x78
10002febc: 94007ad8    	bl	0x10004ea1c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
10002fec0: 1400007b    	b	0x1000300ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
10002fec4: 12a02008    	mov	w8, #-0x1000001         ; =-16777217
10002fec8: 0b080128    	add	w8, w9, w8
10002fecc: 7100211f    	cmp	w8, #0x8
10002fed0: 54003e08    	b.hi	0x100030690 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf2c>
10002fed4: 528022ea    	mov	w10, #0x117             ; =279
10002fed8: 1ac8254a    	lsr	w10, w10, w8
10002fedc: 36003d2a    	tbz	w10, #0x0, 0x100030680 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf1c>
10002fee0: 12001d29    	and	w9, w9, #0xff
10002fee4: 2a1f03e8    	mov	w8, wzr
10002fee8: 7100113f    	cmp	w9, #0x4
10002feec: 540016ac    	b.gt	0x1000301c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa5c>
10002fef0: 7100093f    	cmp	w9, #0x2
10002fef4: 54001a80    	b.eq	0x100030244 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xae0>
10002fef8: 71000d3f    	cmp	w9, #0x3
10002fefc: 54003621    	b.ne	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
10002ff00: b9400f80    	ldr	w0, [x28, #0xc]
10002ff04: eb00029f    	cmp	x20, x0
10002ff08: 5400baa9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002ff0c: d37cec08    	lsl	x8, x0, #4
10002ff10: b9401f89    	ldr	w9, [x28, #0x1c]
10002ff14: b8686ae8    	ldr	w8, [x23, x8]
10002ff18: 51000529    	sub	w9, w9, #0x1
10002ff1c: 6b08013f    	cmp	w9, w8
10002ff20: 1a883128    	csel	w8, w9, w8, lo
10002ff24: 140001a7    	b	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
10002ff28: 9bce7dac    	umulh	x12, x13, x14
10002ff2c: 52800268    	mov	w8, #0x13               ; =19
10002ff30: 72a01f88    	movk	w8, #0xfc, lsl #16
10002ff34: 9b0e7daa    	mul	x10, x13, x14
10002ff38: 11000908    	add	w8, w8, #0x2
10002ff3c: 6b08013f    	cmp	w9, w8
10002ff40: 54000e01    	b.ne	0x100030100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
10002ff44: 8a8efda8    	and	x8, x13, x14, asr #63
10002ff48: 8a8dfdc9    	and	x9, x14, x13, asr #63
10002ff4c: 8b080128    	add	x8, x9, x8
10002ff50: cb08018c    	sub	x12, x12, x8
10002ff54: 1400006b    	b	0x100030100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
10002ff58: 71002dbf    	cmp	w13, #0xb
10002ff5c: f94017ed    	ldr	x13, [sp, #0x28]
10002ff60: 54000060    	b.eq	0x10002ff6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x808>
10002ff64: 7101619f    	cmp	w12, #0x58
10002ff68: 54001ca1    	b.ne	0x1000302fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb98>
10002ff6c: b400aa8d    	cbz	x13, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002ff70: f9403da1    	ldr	x1, [x13, #0x78]
10002ff74: b9401808    	ldr	w8, [x0, #0x18]
10002ff78: eb08003f    	cmp	x1, x8
10002ff7c: 5400b749    	b.ls	0x100031664 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
10002ff80: f94039aa    	ldr	x10, [x13, #0x70]
10002ff84: ab080d48    	adds	x8, x10, x8, lsl #3
10002ff88: 5400a9a0    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002ff8c: f9400108    	ldr	x8, [x8]
10002ff90: b400a968    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002ff94: f9400908    	ldr	x8, [x8, #0x10]
10002ff98: b940140a    	ldr	w10, [x0, #0x14]
10002ff9c: b9401c0b    	ldr	w11, [x0, #0x1c]
10002ffa0: 39410004    	ldrb	w4, [x0, #0x40]
10002ffa4: f940210c    	ldr	x12, [x8, #0x40]
10002ffa8: aa0b8143    	orr	x3, x10, x11, lsl #32
10002ffac: b400006c    	cbz	x12, 0x10002ffb8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x854>
10002ffb0: f940310a    	ldr	x10, [x8, #0x60]
10002ffb4: b4002f4a    	cbz	x10, 0x10003059c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe38>
10002ffb8: aa0803e0    	mov	x0, x8
10002ffbc: 2a0903e1    	mov	w1, w9
10002ffc0: 940070a4    	bl	0x10004c250 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
10002ffc4: 2a0003e8    	mov	w8, w0
10002ffc8: aa1f03e0    	mov	x0, xzr
10002ffcc: aa1f03e1    	mov	x1, xzr
10002ffd0: 12001d19    	and	w25, w8, #0xff
10002ffd4: 14000039    	b	0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10002ffd8: aa1f03e3    	mov	x3, xzr
10002ffdc: aa1f03e4    	mov	x4, xzr
10002ffe0: b9401380    	ldr	w0, [x28, #0x10]
10002ffe4: 3100041f    	cmn	w0, #0x1
10002ffe8: 54ffdf41    	b.ne	0x10002fbd0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x46c>
10002ffec: aa1f03e5    	mov	x5, xzr
10002fff0: aa1f03e6    	mov	x6, xzr
10002fff4: 12003d08    	and	w8, w8, #0xffff
10002fff8: 7100311f    	cmp	w8, #0xc
10002fffc: 54ffdfa0    	b.eq	0x10002fbf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x48c>
100030000: aa1f03e7    	mov	x7, xzr
100030004: aa1f03e9    	mov	x9, xzr
100030008: f94041e1    	ldr	x1, [x15, #0x80]
10003000c: b9400780    	ldr	w0, [x28, #0x4]
100030010: eb00003f    	cmp	x1, x0
100030014: 5400b209    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030018: 52801c0a    	mov	w10, #0xe0              ; =224
10003001c: f9403de8    	ldr	x8, [x15, #0x78]
100030020: 9baa2002    	umaddl	x2, w0, w10, x8
100030024: b400a4c2    	cbz	x2, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030028: f94002a0    	ldr	x0, [x21]
10003002c: f94017e1    	ldr	x1, [sp, #0x28]
100030030: 910243e8    	add	x8, sp, #0x90
100030034: f90003e9    	str	x9, [sp]
100030038: 94002f45    	bl	0x10003bd4c <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
10003003c: f94053f9    	ldr	x25, [sp, #0xa0]
100030040: 3dc027e0    	ldr	q0, [sp, #0x90]
100030044: b4000079    	cbz	x25, 0x100030050 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8ec>
100030048: f9400728    	ldr	x8, [x25, #0x8]
10003004c: b500a688    	cbnz	x8, 0x10003151c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db8>
100030050: b9400b80    	ldr	w0, [x28, #0x8]
100030054: f9401fef    	ldr	x15, [sp, #0x38]
100030058: 3100041f    	cmn	w0, #0x1
10003005c: 54000080    	b.eq	0x10003006c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
100030060: eb00029f    	cmp	x20, x0
100030064: 5400aec9    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030068: 3ca07ae0    	str	q0, [x23, x0, lsl #4]
10003006c: 1100071c    	add	w28, w24, #0x1
100030070: 14000034    	b	0x100030140 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9dc>
100030074: f9400f80    	ldr	x0, [x28, #0x18]
100030078: aa1f03e1    	mov	x1, xzr
10003007c: 14000012    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030080: d101e3a8    	sub	x8, x29, #0x78
100030084: 2a0903e1    	mov	w1, w9
100030088: 2a1f03e4    	mov	w4, wzr
10003008c: aa1f03e5    	mov	x5, xzr
100030090: aa1f03e6    	mov	x6, xzr
100030094: 14000004    	b	0x1000300a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x940>
100030098: d101e3a8    	sub	x8, x29, #0x78
10003009c: aa0a03e0    	mov	x0, x10
1000300a0: 2a0903e1    	mov	w1, w9
1000300a4: d101e3bb    	sub	x27, x29, #0x78
1000300a8: 94007aa7    	bl	0x10004eb44 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
1000300ac: a9400760    	ldp	x0, x1, [x27]
1000300b0: 39404379    	ldrb	w25, [x27, #0x10]
1000300b4: b94027fb    	ldr	w27, [sp, #0x24]
1000300b8: f9401fef    	ldr	x15, [sp, #0x38]
1000300bc: 72001f3f    	tst	w25, #0xff
1000300c0: 5400a641    	b.ne	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
1000300c4: b9400b88    	ldr	w8, [x28, #0x8]
1000300c8: 3100051f    	cmn	w8, #0x1
1000300cc: 54ffbb60    	b.eq	0x10002f838 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
1000300d0: eb08029f    	cmp	x20, x8
1000300d4: 5400ab89    	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
1000300d8: 8b0812e8    	add	x8, x23, x8, lsl #4
1000300dc: a9000500    	stp	x0, x1, [x8]
1000300e0: 17fffdd6    	b	0x10002f838 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
1000300e4: cb0c01ca    	sub	x10, x14, x12
1000300e8: ca2c01c9    	eon	x9, x14, x12
1000300ec: 8a2e018c    	bic	x12, x12, x14
1000300f0: 8a090149    	and	x9, x10, x9
1000300f4: aa0c0129    	orr	x9, x9, x12
1000300f8: 8b49fd08    	add	x8, x8, x9, lsr #63
1000300fc: cb0801ac    	sub	x12, x13, x8
100030100: eb00003f    	cmp	x1, x0
100030104: 5400aa89    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030108: 11000408    	add	w8, w0, #0x1
10003010c: eb08003f    	cmp	x1, x8
100030110: 5400aaa9    	b.ls	0x100031664 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
100030114: b8607969    	ldr	w9, [x11, x0, lsl #2]
100030118: eb09029f    	cmp	x20, x9
10003011c: 5400ac09    	b.ls	0x10003169c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f38>
100030120: b8687960    	ldr	w0, [x11, x8, lsl #2]
100030124: 8b0912e8    	add	x8, x23, x9, lsl #4
100030128: eb00029f    	cmp	x20, x0
10003012c: a9007d0a    	stp	x10, xzr, [x8]
100030130: 5400a969    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030134: 8b0012e8    	add	x8, x23, x0, lsl #4
100030138: 1100071c    	add	w28, w24, #0x1
10003013c: a9007d0c    	stp	x12, xzr, [x8]
100030140: f9401be8    	ldr	x8, [sp, #0x30]
100030144: b81c811c    	stur	w28, [x8, #-0x38]
100030148: 17fffdbd    	b	0x10002f83c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
10003014c: b9400f80    	ldr	w0, [x28, #0xc]
100030150: eb00029f    	cmp	x20, x0
100030154: 5400a749    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030158: b9401b88    	ldr	w8, [x28, #0x18]
10003015c: eb08029f    	cmp	x20, x8
100030160: 5400a729    	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030164: 8b0012e9    	add	x9, x23, x0, lsl #4
100030168: 3dc00120    	ldr	q0, [x9]
10003016c: f9400521    	ldr	x1, [x9, #0x8]
100030170: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
100030174: 9e660000    	fmov	x0, d0
100030178: 17ffffd3    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003017c: b9401780    	ldr	w0, [x28, #0x14]
100030180: eb00029f    	cmp	x20, x0
100030184: 5400a6c9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030188: d37cec08    	lsl	x8, x0, #4
10003018c: 52800209    	mov	w9, #0x10               ; =16
100030190: b8686ae8    	ldr	w8, [x23, x8]
100030194: 7100011f    	cmp	w8, #0x0
100030198: 52800188    	mov	w8, #0xc                ; =12
10003019c: 9a880128    	csel	x8, x9, x8, eq
1000301a0: b8686b80    	ldr	w0, [x28, x8]
1000301a4: eb00029f    	cmp	x20, x0
1000301a8: 54001ce8    	b.hi	0x100030544 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xde0>
1000301ac: 1400052c    	b	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000301b0: 2a0903e1    	mov	w1, w9
1000301b4: 2a1f03e4    	mov	w4, wzr
1000301b8: aa1f03e6    	mov	x6, xzr
1000301bc: 140000fa    	b	0x1000305a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
1000301c0: 7100253f    	cmp	w9, #0x9
1000301c4: 54001fa1    	b.ne	0x1000305b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe54>
1000301c8: b9400f80    	ldr	w0, [x28, #0xc]
1000301cc: eb00029f    	cmp	x20, x0
1000301d0: 5400a469    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000301d4: d37cec08    	lsl	x8, x0, #4
1000301d8: f8686ae8    	ldr	x8, [x23, x8]
1000301dc: f100011f    	cmp	x8, #0x0
1000301e0: 1a9f07e8    	cset	w8, ne
1000301e4: 140000f7    	b	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
1000301e8: b9400f80    	ldr	w0, [x28, #0xc]
1000301ec: eb00029f    	cmp	x20, x0
1000301f0: 5400a369    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000301f4: d37cec08    	lsl	x8, x0, #4
1000301f8: aa1f03e1    	mov	x1, xzr
1000301fc: f8686ae8    	ldr	x8, [x23, x8]
100030200: f100011f    	cmp	x8, #0x0
100030204: 1a9f17e0    	cset	w0, eq
100030208: 17ffffaf    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003020c: aa1f03e2    	mov	x2, xzr
100030210: b9400f80    	ldr	w0, [x28, #0xc]
100030214: eb00029f    	cmp	x20, x0
100030218: 5400a229    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003021c: d37cec08    	lsl	x8, x0, #4
100030220: 2a0903e0    	mov	w0, w9
100030224: f8686ae1    	ldr	x1, [x23, x8]
100030228: 94009a13    	bl	0x100056a74 <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10003022c: aa0103f9    	mov	x25, x1
100030230: f9401fef    	ldr	x15, [sp, #0x38]
100030234: 72001f3f    	tst	w25, #0xff
100030238: 54009a81    	b.ne	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
10003023c: aa1f03e1    	mov	x1, xzr
100030240: 17ffffa1    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030244: b9400f80    	ldr	w0, [x28, #0xc]
100030248: eb00029f    	cmp	x20, x0
10003024c: 5400a089    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030250: d37cec08    	lsl	x8, x0, #4
100030254: b8686ae8    	ldr	w8, [x23, x8]
100030258: 7100011f    	cmp	w8, #0x0
10003025c: 1a9f17e8    	cset	w8, eq
100030260: 140000d8    	b	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
100030264: b9400f80    	ldr	w0, [x28, #0xc]
100030268: eb00029f    	cmp	x20, x0
10003026c: 54009f89    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030270: d37cec08    	lsl	x8, x0, #4
100030274: 7101a53f    	cmp	w9, #0x69
100030278: aa1f03e1    	mov	x1, xzr
10003027c: f8686ae8    	ldr	x8, [x23, x8]
100030280: 2a0803e9    	mov	w9, w8
100030284: 9a880128    	csel	x8, x9, x8, eq
100030288: d341fd09    	lsr	x9, x8, #1
10003028c: 9200f108    	and	x8, x8, #0x5555555555555555
100030290: 9200f129    	and	x9, x9, #0x5555555555555555
100030294: 8b080128    	add	x8, x9, x8
100030298: d342fd09    	lsr	x9, x8, #2
10003029c: 9200e508    	and	x8, x8, #0x3333333333333333
1000302a0: 9200e529    	and	x9, x9, #0x3333333333333333
1000302a4: 8b080128    	add	x8, x9, x8
1000302a8: 8b481108    	add	x8, x8, x8, lsr #4
1000302ac: 9200cd08    	and	x8, x8, #0xf0f0f0f0f0f0f0f
1000302b0: 8b482108    	add	x8, x8, x8, lsr #8
1000302b4: 8b484108    	add	x8, x8, x8, lsr #16
1000302b8: 8b488108    	add	x8, x8, x8, lsr #32
1000302bc: 92401900    	and	x0, x8, #0x7f
1000302c0: 17ffff81    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000302c4: b9400f80    	ldr	w0, [x28, #0xc]
1000302c8: eb00029f    	cmp	x20, x0
1000302cc: 54009c89    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000302d0: d37cec08    	lsl	x8, x0, #4
1000302d4: aa1f03e1    	mov	x1, xzr
1000302d8: b8a86ae0    	ldrsw	x0, [x23, x8]
1000302dc: 17ffff7a    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000302e0: b9400f80    	ldr	w0, [x28, #0xc]
1000302e4: eb00029f    	cmp	x20, x0
1000302e8: 54009ba9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000302ec: d37cec08    	lsl	x8, x0, #4
1000302f0: aa1f03e1    	mov	x1, xzr
1000302f4: b8686ae0    	ldr	w0, [x23, x8]
1000302f8: 17ffff73    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000302fc: aa0203e1    	mov	x1, x2
100030300: aa0803e2    	mov	x2, x8
100030304: aa0503e3    	mov	x3, x5
100030308: aa0603e4    	mov	x4, x6
10003030c: aa0a03e5    	mov	x5, x10
100030310: aa0b03e6    	mov	x6, x11
100030314: 9400930a    	bl	0x100054f3c <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100030318: f9401fef    	ldr	x15, [sp, #0x38]
10003031c: 17ffff6a    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030320: b9400f80    	ldr	w0, [x28, #0xc]
100030324: eb00029f    	cmp	x20, x0
100030328: 540099a9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003032c: b9401388    	ldr	w8, [x28, #0x10]
100030330: eb08029f    	cmp	x20, x8
100030334: 54006208    	b.hi	0x100030f74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1810>
100030338: 140004c8    	b	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003033c: f94017e8    	ldr	x8, [sp, #0x28]
100030340: b4008be8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030344: f9403d01    	ldr	x1, [x8, #0x78]
100030348: b9401b80    	ldr	w0, [x28, #0x18]
10003034c: eb00003f    	cmp	x1, x0
100030350: 54009829    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030354: f9403908    	ldr	x8, [x8, #0x70]
100030358: ab000d08    	adds	x8, x8, x0, lsl #3
10003035c: 54008b00    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030360: f9400119    	ldr	x25, [x8]
100030364: b4008ad9    	cbz	x25, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030368: f9400b28    	ldr	x8, [x25, #0x10]
10003036c: f94002ab    	ldr	x11, [x21]
100030370: b4007d68    	cbz	x8, 0x10003131c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bb8>
100030374: 3940c508    	ldrb	w8, [x8, #0x31]
100030378: 140003ed    	b	0x10003132c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
10003037c: f94017e8    	ldr	x8, [sp, #0x28]
100030380: b40089e8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030384: f9403101    	ldr	x1, [x8, #0x60]
100030388: b9401b80    	ldr	w0, [x28, #0x18]
10003038c: eb00003f    	cmp	x1, x0
100030390: 54009629    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030394: f9402d08    	ldr	x8, [x8, #0x58]
100030398: ab000d08    	adds	x8, x8, x0, lsl #3
10003039c: 54008900    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000303a0: f9400108    	ldr	x8, [x8]
1000303a4: b40088c8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000303a8: b9400f80    	ldr	w0, [x28, #0xc]
1000303ac: eb00029f    	cmp	x20, x0
1000303b0: 54009569    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000303b4: d37cec09    	lsl	x9, x0, #4
1000303b8: 3940a50a    	ldrb	w10, [x8, #0x29]
1000303bc: f8696ae9    	ldr	x9, [x23, x9]
1000303c0: 7100015f    	cmp	w10, #0x0
1000303c4: f940210a    	ldr	x10, [x8, #0x40]
1000303c8: 2a0903eb    	mov	w11, w9
1000303cc: 9a8b1129    	csel	x9, x9, x11, ne
1000303d0: eb0a013f    	cmp	x9, x10
1000303d4: 54008c82    	b.hs	0x100031564 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
1000303d8: f9401d08    	ldr	x8, [x8, #0x38]
1000303dc: aa1f03e1    	mov	x1, xzr
1000303e0: f8697900    	ldr	x0, [x8, x9, lsl #3]
1000303e4: 17ffff38    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000303e8: f94017e8    	ldr	x8, [sp, #0x28]
1000303ec: b4008688    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000303f0: f9402501    	ldr	x1, [x8, #0x48]
1000303f4: b9401b80    	ldr	w0, [x28, #0x18]
1000303f8: eb00003f    	cmp	x1, x0
1000303fc: 540092c9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030400: f9402108    	ldr	x8, [x8, #0x40]
100030404: aa1f03e1    	mov	x1, xzr
100030408: f8607900    	ldr	x0, [x8, x0, lsl #3]
10003040c: 17ffff2e    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030410: b9400f80    	ldr	w0, [x28, #0xc]
100030414: eb00029f    	cmp	x20, x0
100030418: 54009229    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003041c: 8b0012e8    	add	x8, x23, x0, lsl #4
100030420: f9400100    	ldr	x0, [x8]
100030424: b4008b00    	cbz	x0, 0x100031584 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e20>
100030428: f9400501    	ldr	x1, [x8, #0x8]
10003042c: 17ffff26    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030430: f94017e8    	ldr	x8, [sp, #0x28]
100030434: b4008448    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030438: f9404901    	ldr	x1, [x8, #0x90]
10003043c: b9401b80    	ldr	w0, [x28, #0x18]
100030440: eb00003f    	cmp	x1, x0
100030444: 54009089    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030448: b9400f88    	ldr	w8, [x28, #0xc]
10003044c: eb08029f    	cmp	x20, x8
100030450: 54008fa9    	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030454: f94017e9    	ldr	x9, [sp, #0x28]
100030458: f9404529    	ldr	x9, [x9, #0x88]
10003045c: 8b000d29    	add	x9, x9, x0, lsl #3
100030460: b40082e9    	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030464: f9400129    	ldr	x9, [x9]
100030468: b40082a9    	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003046c: 3ce87ae0    	ldr	q0, [x23, x8, lsl #4]
100030470: aa1f03e0    	mov	x0, xzr
100030474: aa1f03e1    	mov	x1, xzr
100030478: 3d800920    	str	q0, [x9, #0x20]
10003047c: 17ffff12    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030480: f94017e8    	ldr	x8, [sp, #0x28]
100030484: b40081c8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030488: f9404901    	ldr	x1, [x8, #0x90]
10003048c: b9401b80    	ldr	w0, [x28, #0x18]
100030490: eb00003f    	cmp	x1, x0
100030494: 54008e09    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030498: f9404508    	ldr	x8, [x8, #0x88]
10003049c: ab000d08    	adds	x8, x8, x0, lsl #3
1000304a0: 540080e0    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304a4: f9400108    	ldr	x8, [x8]
1000304a8: b40080a8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304ac: a9420500    	ldp	x0, x1, [x8, #0x20]
1000304b0: 17ffff05    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000304b4: f94017e8    	ldr	x8, [sp, #0x28]
1000304b8: b4008028    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304bc: f9403101    	ldr	x1, [x8, #0x60]
1000304c0: b9401b80    	ldr	w0, [x28, #0x18]
1000304c4: eb00003f    	cmp	x1, x0
1000304c8: 54008c69    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000304cc: f9402d08    	ldr	x8, [x8, #0x58]
1000304d0: ab000d08    	adds	x8, x8, x0, lsl #3
1000304d4: 54007f40    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304d8: f9400109    	ldr	x9, [x8]
1000304dc: b4007f09    	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304e0: b9400f80    	ldr	w0, [x28, #0xc]
1000304e4: eb00029f    	cmp	x20, x0
1000304e8: 54008ba9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000304ec: d37cec08    	lsl	x8, x0, #4
1000304f0: 3940a52a    	ldrb	w10, [x9, #0x29]
1000304f4: f940212c    	ldr	x12, [x9, #0x40]
1000304f8: f8686ae8    	ldr	x8, [x23, x8]
1000304fc: 7100015f    	cmp	w10, #0x0
100030500: 2a0803eb    	mov	w11, w8
100030504: 9a8b110a    	csel	x10, x8, x11, ne
100030508: eb0c015f    	cmp	x10, x12
10003050c: 540082c2    	b.hs	0x100031564 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
100030510: b9401388    	ldr	w8, [x28, #0x10]
100030514: eb08029f    	cmp	x20, x8
100030518: 54008a09    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003051c: d37ced08    	lsl	x8, x8, #4
100030520: f9401d29    	ldr	x9, [x9, #0x38]
100030524: aa1f03e0    	mov	x0, xzr
100030528: aa1f03e1    	mov	x1, xzr
10003052c: f8686ae8    	ldr	x8, [x23, x8]
100030530: f82a7928    	str	x8, [x9, x10, lsl #3]
100030534: 17fffee4    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030538: b9401b80    	ldr	w0, [x28, #0x18]
10003053c: eb00029f    	cmp	x20, x0
100030540: 540087e9    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030544: 8b0012e8    	add	x8, x23, x0, lsl #4
100030548: a9400500    	ldp	x0, x1, [x8]
10003054c: 17fffede    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030550: f94017e8    	ldr	x8, [sp, #0x28]
100030554: b4007b48    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030558: f9403d01    	ldr	x1, [x8, #0x78]
10003055c: b9401b80    	ldr	w0, [x28, #0x18]
100030560: eb00003f    	cmp	x1, x0
100030564: 54008789    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030568: f9403908    	ldr	x8, [x8, #0x70]
10003056c: ab000d08    	adds	x8, x8, x0, lsl #3
100030570: 54007a60    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030574: f9400108    	ldr	x8, [x8]
100030578: b4007a28    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003057c: f9400900    	ldr	x0, [x8, #0x10]
100030580: 94006d31    	bl	0x10004ba44 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages>
100030584: f9401fef    	ldr	x15, [sp, #0x38]
100030588: aa1f03e1    	mov	x1, xzr
10003058c: 17fffece    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030590: b9401b80    	ldr	w0, [x28, #0x18]
100030594: aa1f03e1    	mov	x1, xzr
100030598: 17fffecb    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003059c: aa0803e0    	mov	x0, x8
1000305a0: 2a0903e1    	mov	w1, w9
1000305a4: 94006fbd    	bl	0x10004c498 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
1000305a8: 2a0003f9    	mov	w25, w0
1000305ac: aa1f03e0    	mov	x0, xzr
1000305b0: aa1f03e1    	mov	x1, xzr
1000305b4: 17fffec1    	b	0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
1000305b8: 7100153f    	cmp	w9, #0x5
1000305bc: 54007e00    	b.eq	0x10003157c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
1000305c0: b9401b89    	ldr	w9, [x28, #0x18]
1000305c4: f94075e1    	ldr	x1, [x15, #0xe8]
1000305c8: 0b080120    	add	w0, w9, w8
1000305cc: eb00003f    	cmp	x1, x0
1000305d0: 54008429    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000305d4: f94071e8    	ldr	x8, [x15, #0xe0]
1000305d8: 52800189    	mov	w9, #0xc                ; =12
1000305dc: 9ba92008    	umaddl	x8, w0, w9, x8
1000305e0: 2940651c    	ldp	w28, w25, [x8]
1000305e4: b940091b    	ldr	w27, [x8, #0x8]
1000305e8: 6b18039f    	cmp	w28, w24
1000305ec: 540000e8    	b.hi	0x100030608 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
1000305f0: aa1503e0    	mov	x0, x21
1000305f4: 94000eee    	bl	0x1000341ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
1000305f8: f9401fef    	ldr	x15, [sp, #0x38]
1000305fc: b4000060    	cbz	x0, 0x100030608 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
100030600: f9400408    	ldr	x8, [x0, #0x8]
100030604: b5007b48    	cbnz	x8, 0x10003156c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e08>
100030608: f94085e8    	ldr	x8, [x15, #0x108]
10003060c: 0b190362    	add	w2, w27, w25
100030610: eb02011f    	cmp	x8, x2
100030614: 540086e3    	b.lo	0x1000316f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f8c>
100030618: 6b02033f    	cmp	w25, w2
10003061c: 54008628    	b.hi	0x1000316e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f7c>
100030620: cb190108    	sub	x8, x8, x25
100030624: d37df329    	lsl	x9, x25, #3
100030628: f100011f    	cmp	x8, #0x0
10003062c: 9a9fc128    	csel	x8, x9, xzr, gt
100030630: 3400025b    	cbz	w27, 0x100030678 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
100030634: f9407de9    	ldr	x9, [x15, #0xf8]
100030638: b94027fb    	ldr	w27, [sp, #0x24]
10003063c: 8b080128    	add	x8, x9, x8
100030640: cb190049    	sub	x9, x2, x25
100030644: 9100110a    	add	x10, x8, #0x4
100030648: b9400140    	ldr	w0, [x10]
10003064c: eb00029f    	cmp	x20, x0
100030650: 54007f69    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030654: b85fc148    	ldur	w8, [x10, #-0x4]
100030658: eb08029f    	cmp	x20, x8
10003065c: 54007f49    	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030660: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
100030664: f1000529    	subs	x9, x9, #0x1
100030668: 9100214a    	add	x10, x10, #0x8
10003066c: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
100030670: 54fffec1    	b.ne	0x100030648 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xee4>
100030674: 17fffc72    	b	0x10002f83c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
100030678: b94027fb    	ldr	w27, [sp, #0x24]
10003067c: 17fffc70    	b	0x10002f83c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
100030680: 71000d1f    	cmp	w8, #0x3
100030684: 540070c0    	b.eq	0x10003149c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d38>
100030688: 7100191f    	cmp	w8, #0x6
10003068c: 54006e00    	b.eq	0x10003144c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
100030690: 51004928    	sub	w8, w9, #0x12
100030694: 7100111f    	cmp	w8, #0x4
100030698: 54006ee3    	b.lo	0x100031474 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d10>
10003069c: b9400f80    	ldr	w0, [x28, #0xc]
1000306a0: 3100041f    	cmn	w0, #0x1
1000306a4: 54005b00    	b.eq	0x100031204 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aa0>
1000306a8: eb00029f    	cmp	x20, x0
1000306ac: 54007d89    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000306b0: d37cec08    	lsl	x8, x0, #4
1000306b4: f8686ae5    	ldr	x5, [x23, x8]
1000306b8: b9401380    	ldr	w0, [x28, #0x10]
1000306bc: 3100041f    	cmn	w0, #0x1
1000306c0: 54005aa0    	b.eq	0x100031214 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ab0>
1000306c4: eb00029f    	cmp	x20, x0
1000306c8: 54007ca9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000306cc: d37cec08    	lsl	x8, x0, #4
1000306d0: f8686ae7    	ldr	x7, [x23, x8]
1000306d4: b9401780    	ldr	w0, [x28, #0x14]
1000306d8: 3100041f    	cmn	w0, #0x1
1000306dc: 54005a40    	b.eq	0x100031224 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ac0>
1000306e0: eb00029f    	cmp	x20, x0
1000306e4: 54007ac9    	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
1000306e8: d37cec08    	lsl	x8, x0, #4
1000306ec: f8686aea    	ldr	x10, [x23, x8]
1000306f0: 12103d28    	and	w8, w9, #0xffff0000
1000306f4: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
1000306f8: 540059e1    	b.ne	0x100031234 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ad0>
1000306fc: 12003d24    	and	w4, w9, #0xffff
100030700: 71000c9f    	cmp	w4, #0x3
100030704: 54006441    	b.ne	0x10003138c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c28>
100030708: f94002a8    	ldr	x8, [x21]
10003070c: b4006d88    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030710: f9400500    	ldr	x0, [x8, #0x8]
100030714: 94006a1b    	bl	0x10004af80 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
100030718: f9401fef    	ldr	x15, [sp, #0x38]
10003071c: aa1f03e0    	mov	x0, xzr
100030720: aa1f03e1    	mov	x1, xzr
100030724: 17fffe68    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030728: b9400f80    	ldr	w0, [x28, #0xc]
10003072c: eb00029f    	cmp	x20, x0
100030730: 54007969    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030734: b9401388    	ldr	w8, [x28, #0x10]
100030738: eb08029f    	cmp	x20, x8
10003073c: 540078e9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030740: d37cec09    	lsl	x9, x0, #4
100030744: d37ced08    	lsl	x8, x8, #4
100030748: aa1f03e1    	mov	x1, xzr
10003074c: f8696ae9    	ldr	x9, [x23, x9]
100030750: f8686ae8    	ldr	x8, [x23, x8]
100030754: ca090100    	eor	x0, x8, x9
100030758: 17fffe5b    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003075c: b9400f80    	ldr	w0, [x28, #0xc]
100030760: eb00029f    	cmp	x20, x0
100030764: 540077c9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030768: b9401388    	ldr	w8, [x28, #0x10]
10003076c: eb08029f    	cmp	x20, x8
100030770: 54007749    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030774: d37cec09    	lsl	x9, x0, #4
100030778: d37ced08    	lsl	x8, x8, #4
10003077c: aa1f03e1    	mov	x1, xzr
100030780: f8696ae9    	ldr	x9, [x23, x9]
100030784: f8686ae8    	ldr	x8, [x23, x8]
100030788: 9ac82520    	lsr	x0, x9, x8
10003078c: 17fffe4e    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030790: b9400f80    	ldr	w0, [x28, #0xc]
100030794: eb00029f    	cmp	x20, x0
100030798: 54007629    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003079c: b9401388    	ldr	w8, [x28, #0x10]
1000307a0: eb08029f    	cmp	x20, x8
1000307a4: 540075a9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000307a8: d37cec09    	lsl	x9, x0, #4
1000307ac: d37ced08    	lsl	x8, x8, #4
1000307b0: aa1f03e1    	mov	x1, xzr
1000307b4: b8696ae9    	ldr	w9, [x23, x9]
1000307b8: b8686ae8    	ldr	w8, [x23, x8]
1000307bc: 1ac82920    	asr	w0, w9, w8
1000307c0: 17fffe41    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000307c4: b9400f80    	ldr	w0, [x28, #0xc]
1000307c8: eb00029f    	cmp	x20, x0
1000307cc: 54007489    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000307d0: b9401388    	ldr	w8, [x28, #0x10]
1000307d4: eb08029f    	cmp	x20, x8
1000307d8: 54007409    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000307dc: d37cec09    	lsl	x9, x0, #4
1000307e0: d37ced08    	lsl	x8, x8, #4
1000307e4: aa1f03e1    	mov	x1, xzr
1000307e8: f8696ae9    	ldr	x9, [x23, x9]
1000307ec: f8686ae8    	ldr	x8, [x23, x8]
1000307f0: aa090100    	orr	x0, x8, x9
1000307f4: 17fffe34    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000307f8: b9400f80    	ldr	w0, [x28, #0xc]
1000307fc: eb00029f    	cmp	x20, x0
100030800: 540072e9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030804: b9401388    	ldr	w8, [x28, #0x10]
100030808: eb08029f    	cmp	x20, x8
10003080c: 54007269    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030810: d37cec09    	lsl	x9, x0, #4
100030814: d37ced08    	lsl	x8, x8, #4
100030818: aa1f03e1    	mov	x1, xzr
10003081c: b8696ae9    	ldr	w9, [x23, x9]
100030820: b8686ae8    	ldr	w8, [x23, x8]
100030824: 1ac82120    	lsl	w0, w9, w8
100030828: 17fffe27    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003082c: b9400f80    	ldr	w0, [x28, #0xc]
100030830: eb00029f    	cmp	x20, x0
100030834: 54007149    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030838: b9401388    	ldr	w8, [x28, #0x10]
10003083c: eb08029f    	cmp	x20, x8
100030840: 540070c9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030844: d37cec09    	lsl	x9, x0, #4
100030848: d37ced08    	lsl	x8, x8, #4
10003084c: aa1f03e1    	mov	x1, xzr
100030850: b8696ae9    	ldr	w9, [x23, x9]
100030854: b8686ae8    	ldr	w8, [x23, x8]
100030858: 2a090100    	orr	w0, w8, w9
10003085c: 17fffe1a    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030860: b9400f80    	ldr	w0, [x28, #0xc]
100030864: eb00029f    	cmp	x20, x0
100030868: 54006fa9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003086c: d37cec08    	lsl	x8, x0, #4
100030870: aa1f03e1    	mov	x1, xzr
100030874: f8686ae8    	ldr	x8, [x23, x8]
100030878: dac00108    	rbit	x8, x8
10003087c: dac01100    	clz	x0, x8
100030880: 17fffe11    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030884: b9400f80    	ldr	w0, [x28, #0xc]
100030888: eb00029f    	cmp	x20, x0
10003088c: 54006e89    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030890: b9401388    	ldr	w8, [x28, #0x10]
100030894: eb08029f    	cmp	x20, x8
100030898: 54006e09    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003089c: d37cec09    	lsl	x9, x0, #4
1000308a0: d37ced08    	lsl	x8, x8, #4
1000308a4: aa1f03e1    	mov	x1, xzr
1000308a8: f8696ae9    	ldr	x9, [x23, x9]
1000308ac: f8686ae8    	ldr	x8, [x23, x8]
1000308b0: eb08013f    	cmp	x9, x8
1000308b4: 1a9f27e0    	cset	w0, lo
1000308b8: 17fffe03    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000308bc: b9400f80    	ldr	w0, [x28, #0xc]
1000308c0: eb00029f    	cmp	x20, x0
1000308c4: 54006cc9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000308c8: b9401388    	ldr	w8, [x28, #0x10]
1000308cc: eb08029f    	cmp	x20, x8
1000308d0: 54006c49    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000308d4: d37cec09    	lsl	x9, x0, #4
1000308d8: d37ced08    	lsl	x8, x8, #4
1000308dc: aa1f03e1    	mov	x1, xzr
1000308e0: f8696ae9    	ldr	x9, [x23, x9]
1000308e4: f8686ae8    	ldr	x8, [x23, x8]
1000308e8: eb08013f    	cmp	x9, x8
1000308ec: 1a9f87e0    	cset	w0, ls
1000308f0: 17fffdf5    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000308f4: b9400f80    	ldr	w0, [x28, #0xc]
1000308f8: eb00029f    	cmp	x20, x0
1000308fc: 54006b09    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030900: b9401388    	ldr	w8, [x28, #0x10]
100030904: eb08029f    	cmp	x20, x8
100030908: 54006a89    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003090c: d37cec09    	lsl	x9, x0, #4
100030910: d37ced08    	lsl	x8, x8, #4
100030914: aa1f03e1    	mov	x1, xzr
100030918: f8696ae9    	ldr	x9, [x23, x9]
10003091c: f8686ae8    	ldr	x8, [x23, x8]
100030920: eb08013f    	cmp	x9, x8
100030924: 1a9f97e0    	cset	w0, hi
100030928: 17fffde7    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003092c: b9400f80    	ldr	w0, [x28, #0xc]
100030930: eb00029f    	cmp	x20, x0
100030934: 54006949    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030938: b9401388    	ldr	w8, [x28, #0x10]
10003093c: eb08029f    	cmp	x20, x8
100030940: 540068c9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030944: d37cec09    	lsl	x9, x0, #4
100030948: d37ced08    	lsl	x8, x8, #4
10003094c: aa1f03e1    	mov	x1, xzr
100030950: b8696ae9    	ldr	w9, [x23, x9]
100030954: b8686ae8    	ldr	w8, [x23, x8]
100030958: 4b080120    	sub	w0, w9, w8
10003095c: 17fffdda    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030960: b9400f80    	ldr	w0, [x28, #0xc]
100030964: eb00029f    	cmp	x20, x0
100030968: 540067a9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003096c: d37cec08    	lsl	x8, x0, #4
100030970: 5280040b    	mov	w11, #0x20              ; =32
100030974: 5280030c    	mov	w12, #0x18              ; =24
100030978: aa1f03e1    	mov	x1, xzr
10003097c: b8686ae8    	ldr	w8, [x23, x8]
100030980: 53107d09    	lsr	w9, w8, #16
100030984: 7100013f    	cmp	w9, #0x0
100030988: 1a881128    	csel	w8, w9, w8, ne
10003098c: 928001e9    	mov	x9, #-0x10              ; =-16
100030990: 53087d0a    	lsr	w10, w8, #8
100030994: 9a9f1129    	csel	x9, x9, xzr, ne
100030998: 7103fd1f    	cmp	w8, #0xff
10003099c: 1a888148    	csel	w8, w10, w8, hi
1000309a0: 9000140a    	adrp	x10, 0x1002b0000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x16b0>
1000309a4: 9103954a    	add	x10, x10, #0xe5
1000309a8: 92401d08    	and	x8, x8, #0xff
1000309ac: 38686948    	ldrb	w8, [x10, x8]
1000309b0: 9a8b818a    	csel	x10, x12, x11, hi
1000309b4: 8b090149    	add	x9, x10, x9
1000309b8: cb080120    	sub	x0, x9, x8
1000309bc: 17fffdc2    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000309c0: b9400f80    	ldr	w0, [x28, #0xc]
1000309c4: eb00029f    	cmp	x20, x0
1000309c8: 540064a9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000309cc: b9401388    	ldr	w8, [x28, #0x10]
1000309d0: eb08029f    	cmp	x20, x8
1000309d4: 54006429    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000309d8: d37cec09    	lsl	x9, x0, #4
1000309dc: d37ced08    	lsl	x8, x8, #4
1000309e0: aa1f03e1    	mov	x1, xzr
1000309e4: b8696ae9    	ldr	w9, [x23, x9]
1000309e8: b8686ae8    	ldr	w8, [x23, x8]
1000309ec: 1ac82520    	lsr	w0, w9, w8
1000309f0: 17fffdb5    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000309f4: b9400f80    	ldr	w0, [x28, #0xc]
1000309f8: eb00029f    	cmp	x20, x0
1000309fc: 54006309    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a00: b9401388    	ldr	w8, [x28, #0x10]
100030a04: eb08029f    	cmp	x20, x8
100030a08: 54006289    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030a0c: d37cec09    	lsl	x9, x0, #4
100030a10: d37ced08    	lsl	x8, x8, #4
100030a14: aa1f03e1    	mov	x1, xzr
100030a18: f8696ae9    	ldr	x9, [x23, x9]
100030a1c: f8686ae8    	ldr	x8, [x23, x8]
100030a20: eb08013f    	cmp	x9, x8
100030a24: 1a9fd7e0    	cset	w0, gt
100030a28: 17fffda7    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a2c: b9400f80    	ldr	w0, [x28, #0xc]
100030a30: eb00029f    	cmp	x20, x0
100030a34: 54006149    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a38: b9401388    	ldr	w8, [x28, #0x10]
100030a3c: eb08029f    	cmp	x20, x8
100030a40: 540060c9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030a44: d37cec09    	lsl	x9, x0, #4
100030a48: d37ced08    	lsl	x8, x8, #4
100030a4c: aa1f03e1    	mov	x1, xzr
100030a50: b8696ae9    	ldr	w9, [x23, x9]
100030a54: b8686ae8    	ldr	w8, [x23, x8]
100030a58: 6b08013f    	cmp	w9, w8
100030a5c: 1a9fa7e0    	cset	w0, lt
100030a60: 17fffd99    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a64: b9400f80    	ldr	w0, [x28, #0xc]
100030a68: eb00029f    	cmp	x20, x0
100030a6c: 54005f89    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a70: b9401388    	ldr	w8, [x28, #0x10]
100030a74: eb08029f    	cmp	x20, x8
100030a78: 54005f09    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030a7c: d37cec09    	lsl	x9, x0, #4
100030a80: d37ced08    	lsl	x8, x8, #4
100030a84: aa1f03e1    	mov	x1, xzr
100030a88: f8696ae9    	ldr	x9, [x23, x9]
100030a8c: f8686ae8    	ldr	x8, [x23, x8]
100030a90: eb08013f    	cmp	x9, x8
100030a94: 1a9f07e0    	cset	w0, ne
100030a98: 17fffd8b    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a9c: b9400f80    	ldr	w0, [x28, #0xc]
100030aa0: eb00029f    	cmp	x20, x0
100030aa4: 54005dc9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030aa8: d37cec08    	lsl	x8, x0, #4
100030aac: b8686ae8    	ldr	w8, [x23, x8]
100030ab0: 34004b88    	cbz	w8, 0x100031420 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cbc>
100030ab4: 5ac00108    	rbit	w8, w8
100030ab8: aa1f03e1    	mov	x1, xzr
100030abc: 5ac01100    	clz	w0, w8
100030ac0: 17fffd81    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ac4: b9400f80    	ldr	w0, [x28, #0xc]
100030ac8: eb00029f    	cmp	x20, x0
100030acc: 54005c89    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ad0: b9401388    	ldr	w8, [x28, #0x10]
100030ad4: eb08029f    	cmp	x20, x8
100030ad8: 54005c09    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030adc: d37cec09    	lsl	x9, x0, #4
100030ae0: d37ced08    	lsl	x8, x8, #4
100030ae4: aa1f03e1    	mov	x1, xzr
100030ae8: b8696ae9    	ldr	w9, [x23, x9]
100030aec: b8686ae8    	ldr	w8, [x23, x8]
100030af0: 6b08013f    	cmp	w9, w8
100030af4: 1a9f07e0    	cset	w0, ne
100030af8: 17fffd73    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030afc: b9400f80    	ldr	w0, [x28, #0xc]
100030b00: eb00029f    	cmp	x20, x0
100030b04: 54005ac9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b08: b9401388    	ldr	w8, [x28, #0x10]
100030b0c: eb08029f    	cmp	x20, x8
100030b10: 54005a49    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030b14: d37cec09    	lsl	x9, x0, #4
100030b18: d37ced08    	lsl	x8, x8, #4
100030b1c: aa1f03e1    	mov	x1, xzr
100030b20: f8696ae9    	ldr	x9, [x23, x9]
100030b24: f8686ae8    	ldr	x8, [x23, x8]
100030b28: eb08013f    	cmp	x9, x8
100030b2c: 1a9fc7e0    	cset	w0, le
100030b30: 17fffd65    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b34: b9400f80    	ldr	w0, [x28, #0xc]
100030b38: eb00029f    	cmp	x20, x0
100030b3c: 54005909    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b40: b9401388    	ldr	w8, [x28, #0x10]
100030b44: eb08029f    	cmp	x20, x8
100030b48: 54005889    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030b4c: d37ced08    	lsl	x8, x8, #4
100030b50: d37cec09    	lsl	x9, x0, #4
100030b54: aa1f03e1    	mov	x1, xzr
100030b58: b8686ae8    	ldr	w8, [x23, x8]
100030b5c: b8696ae9    	ldr	w9, [x23, x9]
100030b60: 4b0803e8    	neg	w8, w8
100030b64: 1ac82d20    	ror	w0, w9, w8
100030b68: 17fffd57    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b6c: b9400f80    	ldr	w0, [x28, #0xc]
100030b70: eb00029f    	cmp	x20, x0
100030b74: 54005749    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b78: b9401388    	ldr	w8, [x28, #0x10]
100030b7c: eb08029f    	cmp	x20, x8
100030b80: 540056c9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030b84: d37cec09    	lsl	x9, x0, #4
100030b88: d37ced08    	lsl	x8, x8, #4
100030b8c: aa1f03e1    	mov	x1, xzr
100030b90: b8696ae9    	ldr	w9, [x23, x9]
100030b94: b8686ae8    	ldr	w8, [x23, x8]
100030b98: 6b08013f    	cmp	w9, w8
100030b9c: 1a9f87e0    	cset	w0, ls
100030ba0: 17fffd49    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ba4: b9400f80    	ldr	w0, [x28, #0xc]
100030ba8: eb00029f    	cmp	x20, x0
100030bac: 54005589    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030bb0: b9401388    	ldr	w8, [x28, #0x10]
100030bb4: eb08029f    	cmp	x20, x8
100030bb8: 54005509    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030bbc: d37cec09    	lsl	x9, x0, #4
100030bc0: d37ced08    	lsl	x8, x8, #4
100030bc4: aa1f03e1    	mov	x1, xzr
100030bc8: b8696ae9    	ldr	w9, [x23, x9]
100030bcc: b8686ae8    	ldr	w8, [x23, x8]
100030bd0: 6b08013f    	cmp	w9, w8
100030bd4: 1a9fb7e0    	cset	w0, ge
100030bd8: 17fffd3b    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030bdc: b9400f80    	ldr	w0, [x28, #0xc]
100030be0: eb00029f    	cmp	x20, x0
100030be4: 540053c9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030be8: d37cec08    	lsl	x8, x0, #4
100030bec: aa1f03e1    	mov	x1, xzr
100030bf0: b8686ae8    	ldr	w8, [x23, x8]
100030bf4: 7100011f    	cmp	w8, #0x0
100030bf8: 1a9f17e0    	cset	w0, eq
100030bfc: 17fffd32    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c00: b9400f80    	ldr	w0, [x28, #0xc]
100030c04: eb00029f    	cmp	x20, x0
100030c08: 540052a9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c0c: b9401388    	ldr	w8, [x28, #0x10]
100030c10: eb08029f    	cmp	x20, x8
100030c14: 54005229    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030c18: d37cec09    	lsl	x9, x0, #4
100030c1c: d37ced08    	lsl	x8, x8, #4
100030c20: aa1f03e1    	mov	x1, xzr
100030c24: b8696ae9    	ldr	w9, [x23, x9]
100030c28: b8686ae8    	ldr	w8, [x23, x8]
100030c2c: 6b08013f    	cmp	w9, w8
100030c30: 1a9f27e0    	cset	w0, lo
100030c34: 17fffd24    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c38: b9400f80    	ldr	w0, [x28, #0xc]
100030c3c: eb00029f    	cmp	x20, x0
100030c40: 540050e9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c44: b9401388    	ldr	w8, [x28, #0x10]
100030c48: eb08029f    	cmp	x20, x8
100030c4c: 54005069    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030c50: d37cec09    	lsl	x9, x0, #4
100030c54: d37ced08    	lsl	x8, x8, #4
100030c58: aa1f03e1    	mov	x1, xzr
100030c5c: f8696ae9    	ldr	x9, [x23, x9]
100030c60: f8686ae8    	ldr	x8, [x23, x8]
100030c64: 8b090100    	add	x0, x8, x9
100030c68: 17fffd17    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c6c: b9400f80    	ldr	w0, [x28, #0xc]
100030c70: eb00029f    	cmp	x20, x0
100030c74: 54004f49    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c78: b9401388    	ldr	w8, [x28, #0x10]
100030c7c: eb08029f    	cmp	x20, x8
100030c80: 54004ec9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030c84: d37cec09    	lsl	x9, x0, #4
100030c88: d37ced08    	lsl	x8, x8, #4
100030c8c: aa1f03e1    	mov	x1, xzr
100030c90: b8696ae9    	ldr	w9, [x23, x9]
100030c94: b8686ae8    	ldr	w8, [x23, x8]
100030c98: 4a090100    	eor	w0, w8, w9
100030c9c: 17fffd0a    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ca0: b9400f80    	ldr	w0, [x28, #0xc]
100030ca4: eb00029f    	cmp	x20, x0
100030ca8: 54004da9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030cac: b9401388    	ldr	w8, [x28, #0x10]
100030cb0: eb08029f    	cmp	x20, x8
100030cb4: 54004d29    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030cb8: d37cec09    	lsl	x9, x0, #4
100030cbc: d37ced08    	lsl	x8, x8, #4
100030cc0: aa1f03e1    	mov	x1, xzr
100030cc4: f8696ae9    	ldr	x9, [x23, x9]
100030cc8: f8686ae8    	ldr	x8, [x23, x8]
100030ccc: 8a090100    	and	x0, x8, x9
100030cd0: 17fffcfd    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030cd4: b9400f80    	ldr	w0, [x28, #0xc]
100030cd8: eb00029f    	cmp	x20, x0
100030cdc: 54004c09    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ce0: b9401388    	ldr	w8, [x28, #0x10]
100030ce4: eb08029f    	cmp	x20, x8
100030ce8: 54004b89    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030cec: d37cec09    	lsl	x9, x0, #4
100030cf0: d37ced08    	lsl	x8, x8, #4
100030cf4: aa1f03e1    	mov	x1, xzr
100030cf8: f8696ae9    	ldr	x9, [x23, x9]
100030cfc: f8686ae8    	ldr	x8, [x23, x8]
100030d00: cb080120    	sub	x0, x9, x8
100030d04: 17fffcf0    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030d08: b9400f80    	ldr	w0, [x28, #0xc]
100030d0c: eb00029f    	cmp	x20, x0
100030d10: 54004a69    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d14: b9401388    	ldr	w8, [x28, #0x10]
100030d18: eb08029f    	cmp	x20, x8
100030d1c: 540049e9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030d20: d37ced08    	lsl	x8, x8, #4
100030d24: d37cec09    	lsl	x9, x0, #4
100030d28: b8686ae8    	ldr	w8, [x23, x8]
100030d2c: f8696ae9    	ldr	x9, [x23, x9]
100030d30: 4b0803e8    	neg	w8, w8
100030d34: 1400006b    	b	0x100030ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x177c>
100030d38: b9400f80    	ldr	w0, [x28, #0xc]
100030d3c: eb00029f    	cmp	x20, x0
100030d40: 540048e9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d44: b9401388    	ldr	w8, [x28, #0x10]
100030d48: eb08029f    	cmp	x20, x8
100030d4c: 54004869    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030d50: d37cec09    	lsl	x9, x0, #4
100030d54: d37ced08    	lsl	x8, x8, #4
100030d58: aa1f03e1    	mov	x1, xzr
100030d5c: b8696ae9    	ldr	w9, [x23, x9]
100030d60: b8686ae8    	ldr	w8, [x23, x8]
100030d64: 6b08013f    	cmp	w9, w8
100030d68: 1a9f17e0    	cset	w0, eq
100030d6c: 17fffcd6    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030d70: b9400f80    	ldr	w0, [x28, #0xc]
100030d74: eb00029f    	cmp	x20, x0
100030d78: 54004729    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d7c: b9401388    	ldr	w8, [x28, #0x10]
100030d80: eb08029f    	cmp	x20, x8
100030d84: 540046a9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030d88: d37cec09    	lsl	x9, x0, #4
100030d8c: d37ced08    	lsl	x8, x8, #4
100030d90: aa1f03e1    	mov	x1, xzr
100030d94: b8696ae9    	ldr	w9, [x23, x9]
100030d98: b8686ae8    	ldr	w8, [x23, x8]
100030d9c: 6b08013f    	cmp	w9, w8
100030da0: 1a9f37e0    	cset	w0, hs
100030da4: 17fffcc8    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030da8: b9400f80    	ldr	w0, [x28, #0xc]
100030dac: eb00029f    	cmp	x20, x0
100030db0: 54004569    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030db4: b9401388    	ldr	w8, [x28, #0x10]
100030db8: eb08029f    	cmp	x20, x8
100030dbc: 540044e9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030dc0: d37cec09    	lsl	x9, x0, #4
100030dc4: d37ced08    	lsl	x8, x8, #4
100030dc8: aa1f03e1    	mov	x1, xzr
100030dcc: b8696ae9    	ldr	w9, [x23, x9]
100030dd0: b8686ae8    	ldr	w8, [x23, x8]
100030dd4: 1b097d00    	mul	w0, w8, w9
100030dd8: 17fffcbb    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ddc: b9400f80    	ldr	w0, [x28, #0xc]
100030de0: eb00029f    	cmp	x20, x0
100030de4: 540043c9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030de8: b9401388    	ldr	w8, [x28, #0x10]
100030dec: eb08029f    	cmp	x20, x8
100030df0: 54004349    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030df4: d37cec09    	lsl	x9, x0, #4
100030df8: d37ced08    	lsl	x8, x8, #4
100030dfc: aa1f03e1    	mov	x1, xzr
100030e00: b8696ae9    	ldr	w9, [x23, x9]
100030e04: b8686ae8    	ldr	w8, [x23, x8]
100030e08: 6b08013f    	cmp	w9, w8
100030e0c: 1a9fc7e0    	cset	w0, le
100030e10: 17fffcad    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e14: b9400f80    	ldr	w0, [x28, #0xc]
100030e18: eb00029f    	cmp	x20, x0
100030e1c: 54004209    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030e20: b9401388    	ldr	w8, [x28, #0x10]
100030e24: eb08029f    	cmp	x20, x8
100030e28: 54004189    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030e2c: d37cec09    	lsl	x9, x0, #4
100030e30: d37ced08    	lsl	x8, x8, #4
100030e34: aa1f03e1    	mov	x1, xzr
100030e38: b8696ae9    	ldr	w9, [x23, x9]
100030e3c: b8686ae8    	ldr	w8, [x23, x8]
100030e40: 6b08013f    	cmp	w9, w8
100030e44: 1a9fd7e0    	cset	w0, gt
100030e48: 17fffc9f    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e4c: b9400f80    	ldr	w0, [x28, #0xc]
100030e50: eb00029f    	cmp	x20, x0
100030e54: 54004049    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030e58: b9401388    	ldr	w8, [x28, #0x10]
100030e5c: eb08029f    	cmp	x20, x8
100030e60: 54003fc9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030e64: d37cec09    	lsl	x9, x0, #4
100030e68: d37ced08    	lsl	x8, x8, #4
100030e6c: aa1f03e1    	mov	x1, xzr
100030e70: b8696ae9    	ldr	w9, [x23, x9]
100030e74: b8686ae8    	ldr	w8, [x23, x8]
100030e78: 1ac82d20    	ror	w0, w9, w8
100030e7c: 17fffc92    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e80: b9400f80    	ldr	w0, [x28, #0xc]
100030e84: eb00029f    	cmp	x20, x0
100030e88: 54003ea9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030e8c: b9401388    	ldr	w8, [x28, #0x10]
100030e90: eb08029f    	cmp	x20, x8
100030e94: 54003e29    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030e98: d37cec09    	lsl	x9, x0, #4
100030e9c: d37ced08    	lsl	x8, x8, #4
100030ea0: aa1f03e1    	mov	x1, xzr
100030ea4: f8696ae9    	ldr	x9, [x23, x9]
100030ea8: f8686ae8    	ldr	x8, [x23, x8]
100030eac: eb08013f    	cmp	x9, x8
100030eb0: 1a9fa7e0    	cset	w0, lt
100030eb4: 17fffc84    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030eb8: b9400f80    	ldr	w0, [x28, #0xc]
100030ebc: eb00029f    	cmp	x20, x0
100030ec0: 54003ce9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ec4: b9401388    	ldr	w8, [x28, #0x10]
100030ec8: eb08029f    	cmp	x20, x8
100030ecc: 54003c69    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030ed0: d37cec09    	lsl	x9, x0, #4
100030ed4: d37ced08    	lsl	x8, x8, #4
100030ed8: f8696ae9    	ldr	x9, [x23, x9]
100030edc: f8686ae8    	ldr	x8, [x23, x8]
100030ee0: 9ac82d20    	ror	x0, x9, x8
100030ee4: aa1f03e1    	mov	x1, xzr
100030ee8: 17fffc77    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030eec: b9400f80    	ldr	w0, [x28, #0xc]
100030ef0: eb00029f    	cmp	x20, x0
100030ef4: 54003b49    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ef8: b9401388    	ldr	w8, [x28, #0x10]
100030efc: eb08029f    	cmp	x20, x8
100030f00: 54003ac9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030f04: d37cec09    	lsl	x9, x0, #4
100030f08: d37ced08    	lsl	x8, x8, #4
100030f0c: aa1f03e1    	mov	x1, xzr
100030f10: b8696ae9    	ldr	w9, [x23, x9]
100030f14: b8686ae8    	ldr	w8, [x23, x8]
100030f18: 6b08013f    	cmp	w9, w8
100030f1c: 1a9f97e0    	cset	w0, hi
100030f20: 17fffc69    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f24: b9400f80    	ldr	w0, [x28, #0xc]
100030f28: eb00029f    	cmp	x20, x0
100030f2c: 54003989    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f30: d37cec08    	lsl	x8, x0, #4
100030f34: aa1f03e1    	mov	x1, xzr
100030f38: 38a86ae0    	ldrsb	x0, [x23, x8]
100030f3c: 17fffc62    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f40: b9400f80    	ldr	w0, [x28, #0xc]
100030f44: eb00029f    	cmp	x20, x0
100030f48: 540038a9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f4c: d37cec08    	lsl	x8, x0, #4
100030f50: aa1f03e1    	mov	x1, xzr
100030f54: 78a86ae0    	ldrsh	x0, [x23, x8]
100030f58: 17fffc5b    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f5c: b9400f80    	ldr	w0, [x28, #0xc]
100030f60: eb00029f    	cmp	x20, x0
100030f64: 540037c9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f68: b9401388    	ldr	w8, [x28, #0x10]
100030f6c: eb08029f    	cmp	x20, x8
100030f70: 54003749    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030f74: d37cec09    	lsl	x9, x0, #4
100030f78: d37ced08    	lsl	x8, x8, #4
100030f7c: aa1f03e1    	mov	x1, xzr
100030f80: f8696ae9    	ldr	x9, [x23, x9]
100030f84: f8686ae8    	ldr	x8, [x23, x8]
100030f88: eb08013f    	cmp	x9, x8
100030f8c: 1a9f17e0    	cset	w0, eq
100030f90: 17fffc4d    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f94: b9400f80    	ldr	w0, [x28, #0xc]
100030f98: eb00029f    	cmp	x20, x0
100030f9c: 54003609    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030fa0: b9401388    	ldr	w8, [x28, #0x10]
100030fa4: eb08029f    	cmp	x20, x8
100030fa8: 54003589    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030fac: d37cec09    	lsl	x9, x0, #4
100030fb0: d37ced08    	lsl	x8, x8, #4
100030fb4: aa1f03e1    	mov	x1, xzr
100030fb8: f8696ae9    	ldr	x9, [x23, x9]
100030fbc: f8686ae8    	ldr	x8, [x23, x8]
100030fc0: eb08013f    	cmp	x9, x8
100030fc4: 1a9f37e0    	cset	w0, hs
100030fc8: 17fffc3f    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030fcc: b9400f80    	ldr	w0, [x28, #0xc]
100030fd0: eb00029f    	cmp	x20, x0
100030fd4: 54003449    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030fd8: b9401388    	ldr	w8, [x28, #0x10]
100030fdc: eb08029f    	cmp	x20, x8
100030fe0: 540033c9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030fe4: d37cec09    	lsl	x9, x0, #4
100030fe8: d37ced08    	lsl	x8, x8, #4
100030fec: aa1f03e1    	mov	x1, xzr
100030ff0: f8696ae9    	ldr	x9, [x23, x9]
100030ff4: f8686ae8    	ldr	x8, [x23, x8]
100030ff8: eb08013f    	cmp	x9, x8
100030ffc: 1a9fb7e0    	cset	w0, ge
100031000: 17fffc31    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031004: b9400f80    	ldr	w0, [x28, #0xc]
100031008: eb00029f    	cmp	x20, x0
10003100c: 54003289    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031010: b9401388    	ldr	w8, [x28, #0x10]
100031014: eb08029f    	cmp	x20, x8
100031018: 54003209    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003101c: d37cec09    	lsl	x9, x0, #4
100031020: d37ced08    	lsl	x8, x8, #4
100031024: aa1f03e1    	mov	x1, xzr
100031028: f8696ae9    	ldr	x9, [x23, x9]
10003102c: f8686ae8    	ldr	x8, [x23, x8]
100031030: 9ac82920    	asr	x0, x9, x8
100031034: 17fffc24    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031038: b9400f80    	ldr	w0, [x28, #0xc]
10003103c: eb00029f    	cmp	x20, x0
100031040: 540030e9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031044: b9401388    	ldr	w8, [x28, #0x10]
100031048: eb08029f    	cmp	x20, x8
10003104c: 54003069    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031050: d37cec09    	lsl	x9, x0, #4
100031054: d37ced08    	lsl	x8, x8, #4
100031058: aa1f03e1    	mov	x1, xzr
10003105c: b8696ae9    	ldr	w9, [x23, x9]
100031060: b8686ae8    	ldr	w8, [x23, x8]
100031064: 0a080120    	and	w0, w9, w8
100031068: 17fffc17    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003106c: b9400f80    	ldr	w0, [x28, #0xc]
100031070: eb00029f    	cmp	x20, x0
100031074: 54002f49    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031078: b9401388    	ldr	w8, [x28, #0x10]
10003107c: eb08029f    	cmp	x20, x8
100031080: 54002ec9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031084: d37cec09    	lsl	x9, x0, #4
100031088: d37ced08    	lsl	x8, x8, #4
10003108c: aa1f03e1    	mov	x1, xzr
100031090: b8696ae9    	ldr	w9, [x23, x9]
100031094: b8686ae8    	ldr	w8, [x23, x8]
100031098: 0b090100    	add	w0, w8, w9
10003109c: 17fffc0a    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310a0: b9400f80    	ldr	w0, [x28, #0xc]
1000310a4: eb00029f    	cmp	x20, x0
1000310a8: 54002da9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000310ac: b9401388    	ldr	w8, [x28, #0x10]
1000310b0: eb08029f    	cmp	x20, x8
1000310b4: 54002d29    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000310b8: d37cec09    	lsl	x9, x0, #4
1000310bc: d37ced08    	lsl	x8, x8, #4
1000310c0: aa1f03e1    	mov	x1, xzr
1000310c4: f8696ae9    	ldr	x9, [x23, x9]
1000310c8: f8686ae8    	ldr	x8, [x23, x8]
1000310cc: 9b097d00    	mul	x0, x8, x9
1000310d0: 17fffbfd    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310d4: b9400f80    	ldr	w0, [x28, #0xc]
1000310d8: eb00029f    	cmp	x20, x0
1000310dc: 54002c09    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000310e0: d37cec08    	lsl	x8, x0, #4
1000310e4: aa1f03e1    	mov	x1, xzr
1000310e8: 38a86ae8    	ldrsb	x8, [x23, x8]
1000310ec: 2a0803e0    	mov	w0, w8
1000310f0: 17fffbf5    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310f4: b9400f80    	ldr	w0, [x28, #0xc]
1000310f8: eb00029f    	cmp	x20, x0
1000310fc: 54002b09    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031100: d37cec08    	lsl	x8, x0, #4
100031104: 5280040a    	mov	w10, #0x20              ; =32
100031108: aa1f03e1    	mov	x1, xzr
10003110c: f8686ae8    	ldr	x8, [x23, x8]
100031110: d360fd09    	lsr	x9, x8, #32
100031114: f100013f    	cmp	x9, #0x0
100031118: 9a881128    	csel	x8, x9, x8, ne
10003111c: 9a9f114a    	csel	x10, x10, xzr, ne
100031120: d350fd09    	lsr	x9, x8, #16
100031124: f100013f    	cmp	x9, #0x0
100031128: 9a881128    	csel	x8, x9, x8, ne
10003112c: b27c0149    	orr	x9, x10, #0x10
100031130: d348fd0b    	lsr	x11, x8, #8
100031134: 9a8a1129    	csel	x9, x9, x10, ne
100031138: f103fd1f    	cmp	x8, #0xff
10003113c: b27d012a    	orr	x10, x9, #0x8
100031140: 9a888168    	csel	x8, x11, x8, hi
100031144: f00013eb    	adrp	x11, 0x1002b0000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x16b0>
100031148: 9103956b    	add	x11, x11, #0xe5
10003114c: 92401d08    	and	x8, x8, #0xff
100031150: 9a898149    	csel	x9, x10, x9, hi
100031154: 5280080a    	mov	w10, #0x40              ; =64
100031158: 38686968    	ldrb	w8, [x11, x8]
10003115c: cb090149    	sub	x9, x10, x9
100031160: cb080120    	sub	x0, x9, x8
100031164: 17fffbd8    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031168: b9400f80    	ldr	w0, [x28, #0xc]
10003116c: eb00029f    	cmp	x20, x0
100031170: 54002769    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031174: b9401388    	ldr	w8, [x28, #0x10]
100031178: eb08029f    	cmp	x20, x8
10003117c: 540026e9    	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031180: d37cec09    	lsl	x9, x0, #4
100031184: d37ced08    	lsl	x8, x8, #4
100031188: aa1f03e1    	mov	x1, xzr
10003118c: f8696ae9    	ldr	x9, [x23, x9]
100031190: f8686ae8    	ldr	x8, [x23, x8]
100031194: 9ac82120    	lsl	x0, x9, x8
100031198: 17fffbcb    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003119c: b9400f80    	ldr	w0, [x28, #0xc]
1000311a0: eb00029f    	cmp	x20, x0
1000311a4: 540025c9    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000311a8: d37cec08    	lsl	x8, x0, #4
1000311ac: aa1f03e1    	mov	x1, xzr
1000311b0: 78a86ae8    	ldrsh	x8, [x23, x8]
1000311b4: 2a0803e0    	mov	w0, w8
1000311b8: 17fffbc3    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000311bc: 51022d28    	sub	w8, w9, #0x8b
1000311c0: 7100d11f    	cmp	w8, #0x34
1000311c4: 540000c8    	b.hi	0x1000311dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a78>
1000311c8: 92a2000a    	mov	x10, #-0x10000001       ; =-268435457
1000311cc: f2dfff2a    	movk	x10, #0xfff9, lsl #32
1000311d0: f2e003ea    	movk	x10, #0x1f, lsl #48
1000311d4: 9ac82548    	lsr	x8, x10, x8
1000311d8: 37074408    	tbnz	w8, #0x0, 0x10002fa58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
1000311dc: 51018528    	sub	w8, w9, #0x61
1000311e0: aa1f03e0    	mov	x0, xzr
1000311e4: 7100851f    	cmp	w8, #0x21
1000311e8: 540012e8    	b.hi	0x100031444 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce0>
1000311ec: b2620fea    	mov	x10, #0x3c0000000       ; =16106127360
1000311f0: aa0003e1    	mov	x1, x0
1000311f4: f29e07ea    	movk	x10, #0xf03f
1000311f8: 9ac82548    	lsr	x8, x10, x8
1000311fc: 370742e8    	tbnz	w8, #0x0, 0x10002fa58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
100031200: 17fffbb1    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031204: aa1f03e5    	mov	x5, xzr
100031208: b9401380    	ldr	w0, [x28, #0x10]
10003120c: 3100041f    	cmn	w0, #0x1
100031210: 54ffa5a1    	b.ne	0x1000306c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf60>
100031214: aa1f03e7    	mov	x7, xzr
100031218: b9401780    	ldr	w0, [x28, #0x14]
10003121c: 3100041f    	cmn	w0, #0x1
100031220: 54ffa601    	b.ne	0x1000306e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf7c>
100031224: aa1f03ea    	mov	x10, xzr
100031228: 12103d28    	and	w8, w9, #0xffff0000
10003122c: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100031230: 54ffa660    	b.eq	0x1000306fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf98>
100031234: 529ffda8    	mov	w8, #0xffed             ; =65517
100031238: 72bfe068    	movk	w8, #0xff03, lsl #16
10003123c: 0b090108    	add	w8, w8, w9
100031240: 11002d08    	add	w8, w8, #0xb
100031244: 7100291f    	cmp	w8, #0xa
100031248: 54002802    	b.hs	0x100031748 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
10003124c: f94041e1    	ldr	x1, [x15, #0x80]
100031250: b9400780    	ldr	w0, [x28, #0x4]
100031254: eb00003f    	cmp	x1, x0
100031258: 54001fe9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10003125c: f9403de8    	ldr	x8, [x15, #0x78]
100031260: 52801c09    	mov	w9, #0xe0               ; =224
100031264: 9ba92008    	umaddl	x8, w0, w9, x8
100031268: b40012a8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003126c: b9400109    	ldr	w9, [x8]
100031270: f940050b    	ldr	x11, [x8, #0x8]
100031274: 910363ec    	add	x12, sp, #0xd8
100031278: 3dc00500    	ldr	q0, [x8, #0x10]
10003127c: 3cc48101    	ldur	q1, [x8, #0x48]
100031280: 910363e2    	add	x2, sp, #0xd8
100031284: b900dbe9    	str	w9, [sp, #0xd8]
100031288: 3cc68102    	ldur	q2, [x8, #0x68]
10003128c: aa1503e0    	mov	x0, x21
100031290: f90073eb    	str	x11, [sp, #0xe0]
100031294: a9422d09    	ldp	x9, x11, [x8, #0x20]
100031298: 3d800580    	str	q0, [x12, #0x10]
10003129c: aa0503e3    	mov	x3, x5
1000312a0: aa1f03e4    	mov	x4, xzr
1000312a4: 3dc00d00    	ldr	q0, [x8, #0x30]
1000312a8: 3c848181    	stur	q1, [x12, #0x48]
1000312ac: aa0703e5    	mov	x5, x7
1000312b0: a90fafe9    	stp	x9, x11, [sp, #0xf8]
1000312b4: 39410109    	ldrb	w9, [x8, #0x40]
1000312b8: aa1f03e6    	mov	x6, xzr
1000312bc: 3d800d80    	str	q0, [x12, #0x30]
1000312c0: 3cc58100    	ldur	q0, [x8, #0x58]
1000312c4: aa0a03e7    	mov	x7, x10
1000312c8: 390463e9    	strb	w9, [sp, #0x118]
1000312cc: 3cc78101    	ldur	q1, [x8, #0x78]
1000312d0: f94017e1    	ldr	x1, [sp, #0x28]
1000312d4: 3c858180    	stur	q0, [x12, #0x58]
1000312d8: 3cc88100    	ldur	q0, [x8, #0x88]
1000312dc: a949a109    	ldp	x9, x8, [x8, #0x98]
1000312e0: 3c868182    	stur	q2, [x12, #0x68]
1000312e4: 3c878181    	stur	q1, [x12, #0x78]
1000312e8: 3c888180    	stur	q0, [x12, #0x88]
1000312ec: a91723e9    	stp	x9, x8, [sp, #0x170]
1000312f0: 9102c3e8    	add	x8, sp, #0xb0
1000312f4: f90003ff    	str	xzr, [sp]
1000312f8: 9400119d    	bl	0x10003596c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
1000312fc: a94b07e0    	ldp	x0, x1, [sp, #0xb0]
100031300: f94067e8    	ldr	x8, [sp, #0xc8]
100031304: 394303f9    	ldrb	w25, [sp, #0xc0]
100031308: b4ff6d88    	cbz	x8, 0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10003130c: f9400509    	ldr	x9, [x8, #0x8]
100031310: f9401fef    	ldr	x15, [sp, #0x38]
100031314: b4ff6d49    	cbz	x9, 0x1000300bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
100031318: 140000c0    	b	0x100031618 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eb4>
10003131c: 52800020    	mov	w0, #0x1                ; =1
100031320: f9000beb    	str	x11, [sp, #0x10]
100031324: 940769c2    	bl	0x10020ba2c <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031328: f9400beb    	ldr	x11, [sp, #0x10]
10003132c: b9400f80    	ldr	w0, [x28, #0xc]
100031330: eb00029f    	cmp	x20, x0
100031334: 54001949    	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031338: d37cec09    	lsl	x9, x0, #4
10003133c: 7200011f    	tst	w8, #0x1
100031340: aa0b03e0    	mov	x0, x11
100031344: aa1903e1    	mov	x1, x25
100031348: f8696ae9    	ldr	x9, [x23, x9]
10003134c: 2a0903ea    	mov	w10, w9
100031350: 9a8a1122    	csel	x2, x9, x10, ne
100031354: 94005e91    	bl	0x100048d98 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
100031358: 36000081    	tbz	w1, #0x0, 0x100031368 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
10003135c: f9401fef    	ldr	x15, [sp, #0x38]
100031360: aa1f03e1    	mov	x1, xzr
100031364: 17fffb58    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031368: f9400b28    	ldr	x8, [x25, #0x10]
10003136c: f9401fef    	ldr	x15, [sp, #0x38]
100031370: b40005e8    	cbz	x8, 0x10003142c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cc8>
100031374: 3940c508    	ldrb	w8, [x8, #0x31]
100031378: aa1f03e1    	mov	x1, xzr
10003137c: 7100011f    	cmp	w8, #0x0
100031380: 12800008    	mov	w8, #-0x1               ; =-1
100031384: da9f0100    	csinv	x0, x8, xzr, eq
100031388: 17fffb4f    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003138c: f94041e1    	ldr	x1, [x15, #0x80]
100031390: b9400780    	ldr	w0, [x28, #0x4]
100031394: eb00003f    	cmp	x1, x0
100031398: 540015e9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10003139c: f9403de8    	ldr	x8, [x15, #0x78]
1000313a0: 52801c09    	mov	w9, #0xe0               ; =224
1000313a4: 9ba92008    	umaddl	x8, w0, w9, x8
1000313a8: b40008a8    	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313ac: f94017e9    	ldr	x9, [sp, #0x28]
1000313b0: b4000869    	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313b4: f9403d21    	ldr	x1, [x9, #0x78]
1000313b8: b9401900    	ldr	w0, [x8, #0x18]
1000313bc: eb00003f    	cmp	x1, x0
1000313c0: 540014a9    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000313c4: f9403929    	ldr	x9, [x9, #0x70]
1000313c8: ab000d29    	adds	x9, x9, x0, lsl #3
1000313cc: 54000780    	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313d0: f9400129    	ldr	x9, [x9]
1000313d4: b4000749    	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313d8: a94006ab    	ldp	x11, x1, [x21]
1000313dc: b940150c    	ldr	w12, [x8, #0x14]
1000313e0: b9401d08    	ldr	w8, [x8, #0x1c]
1000313e4: f9400920    	ldr	x0, [x9, #0x10]
1000313e8: f9400aa2    	ldr	x2, [x21, #0x10]
1000313ec: f9400563    	ldr	x3, [x11, #0x8]
1000313f0: aa088186    	orr	x6, x12, x8, lsl #32
1000313f4: d10283a8    	sub	x8, x29, #0xa0
1000313f8: f90003ea    	str	x10, [sp]
1000313fc: 94006f21    	bl	0x10004d080 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
100031400: a97607a0    	ldp	x0, x1, [x29, #-0xa0]
100031404: f85783a8    	ldur	x8, [x29, #-0x88]
100031408: 385703b9    	ldurb	w25, [x29, #-0x90]
10003140c: b4ff6568    	cbz	x8, 0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
100031410: f9400509    	ldr	x9, [x8, #0x8]
100031414: f9401fef    	ldr	x15, [sp, #0x38]
100031418: b4ff6529    	cbz	x9, 0x1000300bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
10003141c: 14000081    	b	0x100031620 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ebc>
100031420: aa1f03e1    	mov	x1, xzr
100031424: 52800400    	mov	w0, #0x20               ; =32
100031428: 17fffb27    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003142c: 52800020    	mov	w0, #0x1                ; =1
100031430: 9407697f    	bl	0x10020ba2c <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031434: f9401fef    	ldr	x15, [sp, #0x38]
100031438: aa1f03e1    	mov	x1, xzr
10003143c: 12800000    	mov	w0, #-0x1               ; =-1
100031440: 17fffb21    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031444: aa0003e1    	mov	x1, x0
100031448: 17fffb1f    	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003144c: f9401be8    	ldr	x8, [sp, #0x30]
100031450: aa1503e0    	mov	x0, x21
100031454: b81c8118    	stur	w24, [x8, #-0x38]
100031458: 9400080d    	bl	0x10003348c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
10003145c: 72001c1f    	tst	w0, #0xff
100031460: 540005a1    	b.ne	0x100031514 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
100031464: f94026a8    	ldr	x8, [x21, #0x48]
100031468: f100011f    	cmp	x8, #0x0
10003146c: 54ff19cc    	b.gt	0x10002f7a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x40>
100031470: 140000b0    	b	0x100031730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
100031474: f9401be8    	ldr	x8, [sp, #0x30]
100031478: aa1503e0    	mov	x0, x21
10003147c: b81c8118    	stur	w24, [x8, #-0x38]
100031480: 9400044b    	bl	0x1000325ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
100031484: 17fffff6    	b	0x10003145c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
100031488: f9401be8    	ldr	x8, [sp, #0x30]
10003148c: aa1503e0    	mov	x0, x21
100031490: b81c8118    	stur	w24, [x8, #-0x38]
100031494: 94000701    	bl	0x100033098 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
100031498: 17fffff1    	b	0x10003145c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
10003149c: f9401be8    	ldr	x8, [sp, #0x30]
1000314a0: aa1503e0    	mov	x0, x21
1000314a4: b81c8118    	stur	w24, [x8, #-0x38]
1000314a8: 94000348    	bl	0x1000321c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
1000314ac: 72001c1f    	tst	w0, #0xff
1000314b0: 54fffda0    	b.eq	0x100031464 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d00>
1000314b4: 52800020    	mov	w0, #0x1                ; =1
1000314b8: 1400004f    	b	0x1000315f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
1000314bc: 52800020    	mov	w0, #0x1                ; =1
1000314c0: 9407695b    	bl	0x10020ba2c <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000314c4: aa1f03e0    	mov	x0, xzr
1000314c8: 1400004b    	b	0x1000315f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
1000314cc: 52800500    	mov	w0, #0x28               ; =40
1000314d0: 9407bb83    	bl	0x1002202dc <dyld_stub_binder+0x1002202dc>
1000314d4: b4001460    	cbz	x0, 0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
1000314d8: aa0003f4    	mov	x20, x0
1000314dc: 52800500    	mov	w0, #0x28               ; =40
1000314e0: 94075806    	bl	0x1002074f8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1000314e4: f9400728    	ldr	x8, [x25, #0x8]
1000314e8: f0001c49    	adrp	x9, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
1000314ec: 9000132a    	adrp	x10, 0x100295000 <dyld_stub_binder+0x100295000>
1000314f0: 9106294a    	add	x10, x10, #0x18a
1000314f4: 3dc38520    	ldr	q0, [x9, #0xe10]
1000314f8: b00015e1    	adrp	x1, 0x1002ee000 <_map[_llgo_uint32][]_llgo_github.com/cpunion/wasmvm/internal/compiler/ir.Catch+0x8>
1000314fc: 911fa021    	add	x1, x1, #0x7e8
100031500: a9012a88    	stp	x8, x10, [x20, #0x10]
100031504: 528001c8    	mov	w8, #0xe                ; =14
100031508: 3d800280    	str	q0, [x20]
10003150c: f9001288    	str	x8, [x20, #0x20]
100031510: 14000035    	b	0x1000315e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
100031514: 92401c00    	and	x0, x0, #0xff
100031518: 14000037    	b	0x1000315f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
10003151c: f94057f4    	ldr	x20, [sp, #0xa8]
100031520: 52800100    	mov	w0, #0x8                ; =8
100031524: 940768b6    	bl	0x10020b7fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
100031528: aa0003f6    	mov	x22, x0
10003152c: 90001502    	adrp	x2, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xd8>
100031530: 9117c042    	add	x2, x2, #0x5f0
100031534: aa1903e0    	mov	x0, x25
100031538: aa1403e1    	mov	x1, x20
10003153c: aa1603e3    	mov	x3, x22
100031540: 9406d4e1    	bl	0x1001e68c4 <_errors.As>
100031544: 360000a0    	tbz	w0, #0x0, 0x100031558 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1df4>
100031548: f9400fe9    	ldr	x9, [sp, #0x18]
10003154c: f94002c8    	ldr	x8, [x22]
100031550: b9405129    	ldr	w9, [x9, #0x50]
100031554: b9000509    	str	w9, [x8, #0x4]
100031558: aa1503e0    	mov	x0, x21
10003155c: aa1903e1    	mov	x1, x25
100031560: 14000022    	b	0x1000315e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e84>
100031564: 52800079    	mov	w25, #0x3               ; =3
100031568: 14000008    	b	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
10003156c: aa0103e2    	mov	x2, x1
100031570: aa0003e1    	mov	x1, x0
100031574: aa1503e0    	mov	x0, x21
100031578: 1400001d    	b	0x1000315ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
10003157c: 52800039    	mov	w25, #0x1               ; =1
100031580: 14000002    	b	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
100031584: 52800139    	mov	w25, #0x9               ; =9
100031588: 52800200    	mov	w0, #0x10               ; =16
10003158c: 9407bb51    	bl	0x1002202d0 <dyld_stub_binder+0x1002202d0>
100031590: b4000e80    	cbz	x0, 0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
100031594: aa0003f4    	mov	x20, x0
100031598: 52800200    	mov	w0, #0x10               ; =16
10003159c: 940757d7    	bl	0x1002074f8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1000315a0: f9401fe9    	ldr	x9, [sp, #0x38]
1000315a4: a9007e9f    	stp	xzr, xzr, [x20]
1000315a8: b9400780    	ldr	w0, [x28, #0x4]
1000315ac: f9404121    	ldr	x1, [x9, #0x80]
1000315b0: eb00003f    	cmp	x1, x0
1000315b4: 54000509    	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000315b8: 52801c08    	mov	w8, #0xe0               ; =224
1000315bc: f9403d29    	ldr	x9, [x9, #0x78]
1000315c0: 90001501    	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xd8>
1000315c4: 91256021    	add	x1, x1, #0x958
1000315c8: 9ba82408    	umaddl	x8, w0, w8, x9
1000315cc: f9400fe9    	ldr	x9, [sp, #0x18]
1000315d0: b9405129    	ldr	w9, [x9, #0x50]
1000315d4: f9400508    	ldr	x8, [x8, #0x8]
1000315d8: 39000299    	strb	w25, [x20]
1000315dc: b9000689    	str	w9, [x20, #0x4]
1000315e0: f9000688    	str	x8, [x20, #0x8]
1000315e4: aa1503e0    	mov	x0, x21
1000315e8: aa1403e2    	mov	x2, x20
1000315ec: 97fff4d8    	bl	0x10002e94c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
1000315f0: 52800060    	mov	w0, #0x3                ; =3
1000315f4: aa1303e1    	mov	x1, x19
1000315f8: 910743ff    	add	sp, sp, #0x1d0
1000315fc: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100031600: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100031604: a94357f6    	ldp	x22, x21, [sp, #0x30]
100031608: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10003160c: a94167fa    	ldp	x26, x25, [sp, #0x10]
100031610: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100031614: d65f03c0    	ret
100031618: f9406be2    	ldr	x2, [sp, #0xd0]
10003161c: 14000002    	b	0x100031624 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ec0>
100031620: f85803a2    	ldur	x2, [x29, #-0x80]
100031624: aa1503e0    	mov	x0, x21
100031628: aa0803e1    	mov	x1, x8
10003162c: 17fffff0    	b	0x1000315ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
100031630: aa1803e0    	mov	x0, x24
100031634: aa1603e1    	mov	x1, x22
100031638: 94075d5b    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003163c: aa1403e1    	mov	x1, x20
100031640: 940757ec    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031644: aa0803e0    	mov	x0, x8
100031648: aa1403e1    	mov	x1, x20
10003164c: 940757e9    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031650: aa1603e1    	mov	x1, x22
100031654: 94075d54    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031658: aa0803e0    	mov	x0, x8
10003165c: aa1403e1    	mov	x1, x20
100031660: 94075d51    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031664: aa0803e0    	mov	x0, x8
100031668: 94075d4f    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003166c: aa0a03e0    	mov	x0, x10
100031670: aa1403e1    	mov	x1, x20
100031674: 94075d4c    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031678: aa0803e0    	mov	x0, x8
10003167c: 52800021    	mov	w1, #0x1                ; =1
100031680: aa0903e2    	mov	x2, x9
100031684: 52800063    	mov	w3, #0x3                ; =3
100031688: 94075b20    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003168c: aa0903e0    	mov	x0, x9
100031690: 52800021    	mov	w1, #0x1                ; =1
100031694: 52800043    	mov	w3, #0x2                ; =2
100031698: 94075b1c    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003169c: aa0903e0    	mov	x0, x9
1000316a0: aa1403e1    	mov	x1, x20
1000316a4: 94075d40    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000316a8: 52800020    	mov	w0, #0x1                ; =1
1000316ac: 940757d1    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000316b0: aa1f03e0    	mov	x0, xzr
1000316b4: aa1f03e1    	mov	x1, xzr
1000316b8: 940757ce    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000316bc: aa0803e0    	mov	x0, x8
1000316c0: 2a1f03e1    	mov	w1, wzr
1000316c4: 52800063    	mov	w3, #0x3                ; =3
1000316c8: 94075b10    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000316cc: aa0203e0    	mov	x0, x2
1000316d0: 2a1f03e1    	mov	w1, wzr
1000316d4: aa0a03e2    	mov	x2, x10
1000316d8: 52800043    	mov	w3, #0x2                ; =2
1000316dc: 94075b0b    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000316e0: aa1903e0    	mov	x0, x25
1000316e4: 2a1f03e1    	mov	w1, wzr
1000316e8: 52800063    	mov	w3, #0x3                ; =3
1000316ec: 94075b07    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000316f0: aa0203e0    	mov	x0, x2
1000316f4: 2a1f03e1    	mov	w1, wzr
1000316f8: aa0803e2    	mov	x2, x8
1000316fc: 52800043    	mov	w3, #0x2                ; =2
100031700: 94075b02    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031704: 52800060    	mov	w0, #0x3                ; =3
100031708: 940757ba    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003170c: 52800040    	mov	w0, #0x2                ; =2
100031710: 52800041    	mov	w1, #0x2                ; =2
100031714: 940757b7    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031718: 900018a0    	adrp	x0, 0x100345000 <__llgo_func$liJhyFxTggkeBgD9S7kFqNywlkHIJyTDinflDswHAAs+0x68>
10003171c: 913ac000    	add	x0, x0, #0xeb0
100031720: b00018a1    	adrp	x1, 0x100346000 <_*_llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.errorString+0xa0>
100031724: 9104c021    	add	x1, x1, #0x130
100031728: 940756ef    	bl	0x1002072e4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10003172c: d4200020    	brk	#0x1
100031730: d00018e0    	adrp	x0, 0x10034f000 <_[8]_llgo_Pointer+0x50>
100031734: 911fa000    	add	x0, x0, #0x7e8
100031738: 90001501    	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xd8>
10003173c: 91190021    	add	x1, x1, #0x640
100031740: 940756e9    	bl	0x1002072e4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031744: d4200020    	brk	#0x1
100031748: d00018e0    	adrp	x0, 0x10034f000 <_[8]_llgo_Pointer+0x50>
10003174c: 911fa000    	add	x0, x0, #0x7e8
100031750: 90001501    	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xd8>
100031754: 91194021    	add	x1, x1, #0x650
100031758: 940756e3    	bl	0x1002072e4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10003175c: d4200020    	brk	#0x1
100031760: d00018e0    	adrp	x0, 0x10034f000 <_[8]_llgo_Pointer+0x50>
100031764: 911fa000    	add	x0, x0, #0x7e8
100031768: 900018a1    	adrp	x1, 0x100345000 <__llgo_func$liJhyFxTggkeBgD9S7kFqNywlkHIJyTDinflDswHAAs+0x68>
10003176c: 913a8021    	add	x1, x1, #0xea0
100031770: 940756dd    	bl	0x1002072e4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031774: d4200020    	brk	#0x1
