from pathlib import Path
import ctypes,json,os,random,re,statistics,subprocess,threading

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/lijie/source/goplus/wasmvm')
header=Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sys/resource.h').read_text()
body=header.split('struct rusage_info_v4 {',1)[1].split('};',1)[0]
fields=re.findall(r'uint64_t\s+(ri_\w+);',body)
class Info(ctypes.Structure):_fields_=[('ri_uuid',ctypes.c_ubyte*16)]+[(n,ctypes.c_uint64)for n in fields]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
names=['ri_user_time','ri_system_time','ri_instructions','ri_cycles','ri_pkg_idle_wkups','ri_interrupt_wkups','ri_phys_footprint','ri_lifetime_max_phys_footprint','ri_runnable_time']
def snapshot(pid):
 info=Info();result=lib.proc_pid_rusage(pid,4,ctypes.byref(info))
 if result:raise OSError(ctypes.get_errno(),'proc_pid_rusage')
 return {n:int(getattr(info,n)) for n in names}
assert snapshot(os.getpid())['ri_user_time']>0
class Timebase(ctypes.Structure):
 _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
system=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
system.mach_timebase_info.argtypes=[ctypes.POINTER(Timebase)]
system.mach_timebase_info.restype=ctypes.c_int
clockbase=Timebase()
assert system.mach_timebase_info(ctypes.byref(clockbase))==0
tickNanoseconds=clockbase.numer/clockbase.denom



import hashlib,time,signal,gzip
plan=json.loads((OUT/'frozen-plan.json').read_text());rng=random.Random(plan['seed']);assert not(OUT/'rows.jsonl.gz').exists();env=dict(os.environ,GOMAXPROCS='1',GOGC='100',WASMVM_INTERLEAVE='1')
for k in ['GC_DONT_GC','GC_FREE_SPACE_DIVISOR','GC_MARKERS','GC_PRINT_STATS']:env.pop(k,None)
for case in plan['cases']:
 for cmd in case['commands'].values():assert hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()==plan['binarySHA256'][cmd[0]]
def freeze(p):
 os.kill(p.pid,signal.SIGSTOP);pid,status=os.waitpid(p.pid,os.WUNTRACED);assert pid==p.pid and os.WIFSTOPPED(status)
(OUT/'load-start.json').write_text(json.dumps(os.getloadavg())+'\n')
for block in range(plan['blocks']):
 cases=list(plan['cases']);rng.shuffle(cases)
 for case in cases:
  order=[(role,alias)for role in case['commands']for alias in ['','-aa']];rng.shuffle(order);children=[]
  try:
   for role,alias in order:
    err=(OUT/(str(block)+'-'+case['id'].replace('/','-')+'-'+role+alias+'.stderr')).open('w');cmd=case['commands'][role];p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=env);c=dict(id=role+alias,p=p,err=err,deltas=[]);children.append(c);c['timer']=threading.Timer(600,p.kill);c['timer'].start();assert json.loads(p.stdout.readline())=={'ready':True};p.stdin.write('run\n');p.stdin.flush();assert json.loads(p.stdout.readline())=={'sampleReady':0};time.sleep(.05);freeze(p)
   for sample in range(plan['samples']):
    order=list(children);rng.shuffle(order)
    for c in order:
     p=c['p'];before=snapshot(p.pid);os.kill(p.pid,signal.SIGCONT);p.stdin.write('sample\n');p.stdin.flush();assert json.loads(p.stdout.readline())=={'sampleReady':sample+1};freeze(p);after=snapshot(p.pid);c['deltas'].append({k:after[k]-before[k]for k in names})
   for c in children:
    p=c['p'];os.kill(p.pid,signal.SIGCONT);p.stdin.write('sample\n');p.stdin.close();record=json.loads(p.stdout.readline());rest=p.stdout.read();assert p.wait(timeout=30)==0 and not rest and record.get('result',record.get('checksum'))==case['fixture']['expectedChecksum'] and ('warmResults' not in record or record['warmResults']==[case['fixture']['expectedChecksum']]*6)
    counts=case['fixture']['iterations']*plan['samples'];total={k:sum(x[k]for x in c['deltas'])for k in names};row=dict(block=block,id=c['id'],case=case['id'],record=record,deltas=c['deltas'],cpuNs=(total['ri_user_time']+total['ri_system_time'])*tickNanoseconds/counts,instructions=total['ri_instructions']/counts,cycles=total['ri_cycles']/counts);row['cyclesPerInstruction']=row['cycles']/row['instructions']
    with gzip.open(OUT/'rows.jsonl.gz','at',compresslevel=1)as f:f.write(json.dumps(row)+'\n')
   print('checked',block,case['id'],flush=True)
  finally:
   for c in children:
    c['timer'].cancel();p=c['p']
    if p.poll()is None:p.kill();p.wait()
    c['err'].close()
(OUT/'complete.json').write_text(json.dumps({'processes':plan['blocks']*sum(len(c['commands'])*2 for c in plan['cases']),'status':'All results checked.'})+'\n')
(OUT/'load-end.json').write_text(json.dumps(os.getloadavg())+'\n')
