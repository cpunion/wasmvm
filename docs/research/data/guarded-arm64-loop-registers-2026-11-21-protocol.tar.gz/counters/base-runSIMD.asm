Disassembly of section __TEXT,__text:

0000000100031e74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD>:
100031e74: d10343ff    	sub	sp, sp, #0xd0
100031e78: a9076ffc    	stp	x28, x27, [sp, #0x70]
100031e7c: a90867fa    	stp	x26, x25, [sp, #0x80]
100031e80: a9095ff8    	stp	x24, x23, [sp, #0x90]
100031e84: a90a57f6    	stp	x22, x21, [sp, #0xa0]
100031e88: a90b4ff4    	stp	x20, x19, [sp, #0xb0]
100031e8c: a90c7bfd    	stp	x29, x30, [sp, #0xc0]
100031e90: 910303fd    	add	x29, sp, #0xc0
100031e94: b4001360    	cbz	x0, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031e98: f9402409    	ldr	x9, [x0, #0x48]
100031e9c: d1000528    	sub	x8, x9, #0x1
100031ea0: b4001689    	cbz	x9, 0x100032170 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2fc>
100031ea4: f9402009    	ldr	x9, [x0, #0x40]
100031ea8: ab081937    	adds	x23, x9, x8, lsl #6
100031eac: 540012a0    	b.eq	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031eb0: f94002f5    	ldr	x21, [x23]
100031eb4: b4001275    	cbz	x21, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031eb8: f94026a8    	ldr	x8, [x21, #0x48]
100031ebc: b4001228    	cbz	x8, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031ec0: b9400aed    	ldr	w13, [x23, #0x8]
100031ec4: f9405d01    	ldr	x1, [x8, #0xb8]
100031ec8: eb0d003f    	cmp	x1, x13
100031ecc: 540015e9    	b.ls	0x100032188 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x314>
100031ed0: f9400ee9    	ldr	x9, [x23, #0x18]
100031ed4: f9404d14    	ldr	x20, [x8, #0x98]
100031ed8: f9404402    	ldr	x2, [x0, #0x88]
100031edc: 8b09028a    	add	x10, x20, x9
100031ee0: eb02015f    	cmp	x10, x2
100031ee4: 54001568    	b.hi	0x100032190 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x31c>
100031ee8: eb0a013f    	cmp	x9, x10
100031eec: 540015a8    	b.hi	0x1000321a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x32c>
100031ef0: f940590a    	ldr	x10, [x8, #0xb0]
100031ef4: d37ced2b    	lsl	x11, x9, #4
100031ef8: f94022ba    	ldr	x26, [x21, #0x40]
100031efc: f90007ed    	str	x13, [sp, #0x8]
100031f00: 8b0d1558    	add	x24, x10, x13, lsl #5
100031f04: cb09004a    	sub	x10, x2, x9
100031f08: f100015f    	cmp	x10, #0x0
100031f0c: f9403c0a    	ldr	x10, [x0, #0x78]
100031f10: b9400f09    	ldr	w9, [x24, #0xc]
100031f14: 9a9fc16b    	csel	x11, x11, xzr, gt
100031f18: b9400316    	ldr	w22, [x24]
100031f1c: 8b0b0159    	add	x25, x10, x11
100031f20: 3100053f    	cmn	w9, #0x1
100031f24: 540003c0    	b.eq	0x100031f9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x128>
100031f28: eb09029f    	cmp	x20, x9
100031f2c: 54001289    	b.ls	0x10003217c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x308>
100031f30: 8b091329    	add	x9, x25, x9, lsl #4
100031f34: a9404d2a    	ldp	x10, x19, [x9]
100031f38: b9401309    	ldr	w9, [x24, #0x10]
100031f3c: 3100053f    	cmn	w9, #0x1
100031f40: 54000380    	b.eq	0x100031fb0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x13c>
100031f44: eb09029f    	cmp	x20, x9
100031f48: 540011a9    	b.ls	0x10003217c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x308>
100031f4c: 3ce97b20    	ldr	q0, [x25, x9, lsl #4]
100031f50: 3d800fe0    	str	q0, [sp, #0x30]
100031f54: a9432fec    	ldp	x12, x11, [sp, #0x30]
100031f58: b9401709    	ldr	w9, [x24, #0x14]
100031f5c: a9022beb    	stp	x11, x10, [sp, #0x20]
100031f60: f9000fec    	str	x12, [sp, #0x18]
100031f64: 3100053f    	cmn	w9, #0x1
100031f68: 540002e0    	b.eq	0x100031fc4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x150>
100031f6c: eb09029f    	cmp	x20, x9
100031f70: 54001069    	b.ls	0x10003217c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x308>
100031f74: 3ce97b20    	ldr	q0, [x25, x9, lsl #4]
100031f78: 3d8013e0    	str	q0, [sp, #0x40]
100031f7c: a94473fb    	ldp	x27, x28, [sp, #0x40]
100031f80: b9400701    	ldr	w1, [x24, #0x4]
100031f84: f9000be0    	str	x0, [sp, #0x10]
100031f88: 91076002    	add	x2, x0, #0x1d8
100031f8c: aa0803e0    	mov	x0, x8
100031f90: 94026eb1    	bl	0x1000cda54 <_github.com/cpunion/wasmvm/internal/compiler/slots.(*Function).ReadSource>
100031f94: b5000280    	cbnz	x0, 0x100031fe4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x170>
100031f98: 1400005a    	b	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031f9c: aa1f03f3    	mov	x19, xzr
100031fa0: aa1f03ea    	mov	x10, xzr
100031fa4: b9401309    	ldr	w9, [x24, #0x10]
100031fa8: 3100053f    	cmn	w9, #0x1
100031fac: 54fffcc1    	b.ne	0x100031f44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0xd0>
100031fb0: b9401709    	ldr	w9, [x24, #0x14]
100031fb4: a9022bff    	stp	xzr, x10, [sp, #0x20]
100031fb8: f9000fff    	str	xzr, [sp, #0x18]
100031fbc: 3100053f    	cmn	w9, #0x1
100031fc0: 54fffd61    	b.ne	0x100031f6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0xf8>
100031fc4: aa1f03fb    	mov	x27, xzr
100031fc8: aa1f03fc    	mov	x28, xzr
100031fcc: b9400701    	ldr	w1, [x24, #0x4]
100031fd0: f9000be0    	str	x0, [sp, #0x10]
100031fd4: 91076002    	add	x2, x0, #0x1d8
100031fd8: aa0803e0    	mov	x0, x8
100031fdc: 94026e9e    	bl	0x1000cda54 <_github.com/cpunion/wasmvm/internal/compiler/slots.(*Function).ReadSource>
100031fe0: b4000900    	cbz	x0, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031fe4: 121e36c8    	and	w8, w22, #0xfffc
100031fe8: 12003ec9    	and	w9, w22, #0xffff
100031fec: 7101511f    	cmp	w8, #0x54
100031ff0: 7a4b1920    	ccmp	w9, #0xb, #0x0, ne
100031ff4: 54000083    	b.lo	0x100032004 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x190>
100031ff8: 5101712a    	sub	w10, w9, #0x5c
100031ffc: 7100095f    	cmp	w10, #0x2
100032000: 54000422    	b.hs	0x100032084 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x210>
100032004: b40007fa    	cbz	x26, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100032008: f9403f41    	ldr	x1, [x26, #0x78]
10003200c: b9401808    	ldr	w8, [x0, #0x18]
100032010: eb08003f    	cmp	x1, x8
100032014: 54000d09    	b.ls	0x1000321b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x340>
100032018: f9403b49    	ldr	x9, [x26, #0x70]
10003201c: ab080d28    	adds	x8, x9, x8, lsl #3
100032020: 54000700    	b.eq	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100032024: f9400108    	ldr	x8, [x8]
100032028: b40006c8    	cbz	x8, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
10003202c: b940140a    	ldr	w10, [x0, #0x14]
100032030: b9401c0b    	ldr	w11, [x0, #0x1c]
100032034: 2a1603e1    	mov	w1, w22
100032038: f9400909    	ldr	x9, [x8, #0x10]
10003203c: a9420be6    	ldp	x6, x2, [sp, #0x20]
100032040: aa0b8143    	orr	x3, x10, x11, lsl #32
100032044: 39410004    	ldrb	w4, [x0, #0x40]
100032048: 910163e8    	add	x8, sp, #0x58
10003204c: f9400fe5    	ldr	x5, [sp, #0x18]
100032050: aa0903e0    	mov	x0, x9
100032054: 9400725a    	bl	0x10004e9bc <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load>
100032058: a94587e0    	ldp	x0, x1, [sp, #0x58]
10003205c: 3941a3e3    	ldrb	w3, [sp, #0x68]
100032060: f9400be8    	ldr	x8, [sp, #0x10]
100032064: 72001c7f    	tst	w3, #0xff
100032068: 540006c0    	b.eq	0x100032140 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2cc>
10003206c: b9400702    	ldr	w2, [x24, #0x4]
100032070: aa0803e0    	mov	x0, x8
100032074: aa1503e1    	mov	x1, x21
100032078: 94000877    	bl	0x100034254 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
10003207c: 52800060    	mov	w0, #0x3                ; =3
100032080: 14000022    	b	0x100032108 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x294>
100032084: 71002d3f    	cmp	w9, #0xb
100032088: 54000060    	b.eq	0x100032094 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x220>
10003208c: 7101611f    	cmp	w8, #0x58
100032090: 540004c1    	b.ne	0x100032128 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2b4>
100032094: b400037a    	cbz	x26, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100032098: f9403f41    	ldr	x1, [x26, #0x78]
10003209c: b9401808    	ldr	w8, [x0, #0x18]
1000320a0: eb08003f    	cmp	x1, x8
1000320a4: 54000889    	b.ls	0x1000321b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x340>
1000320a8: f9403b49    	ldr	x9, [x26, #0x70]
1000320ac: ab080d28    	adds	x8, x9, x8, lsl #3
1000320b0: 54000280    	b.eq	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
1000320b4: f9400108    	ldr	x8, [x8]
1000320b8: b4000248    	cbz	x8, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
1000320bc: b9401409    	ldr	w9, [x0, #0x14]
1000320c0: b9401c0a    	ldr	w10, [x0, #0x1c]
1000320c4: 2a1603e1    	mov	w1, w22
1000320c8: f9400908    	ldr	x8, [x8, #0x10]
1000320cc: a9420be6    	ldp	x6, x2, [sp, #0x20]
1000320d0: aa0a8123    	orr	x3, x9, x10, lsl #32
1000320d4: 39410004    	ldrb	w4, [x0, #0x40]
1000320d8: f9400fe5    	ldr	x5, [sp, #0x18]
1000320dc: aa0803e0    	mov	x0, x8
1000320e0: 94006856    	bl	0x10004c238 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store>
1000320e4: 2a0003e3    	mov	w3, w0
1000320e8: aa1f03e0    	mov	x0, xzr
1000320ec: aa1f03e1    	mov	x1, xzr
1000320f0: f9400be8    	ldr	x8, [sp, #0x10]
1000320f4: 72001c7f    	tst	w3, #0xff
1000320f8: 54fffba1    	b.ne	0x10003206c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x1f8>
1000320fc: 14000011    	b	0x100032140 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2cc>
100032100: 52800020    	mov	w0, #0x1                ; =1
100032104: 9407664a    	bl	0x10020ba2c <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100032108: a94c7bfd    	ldp	x29, x30, [sp, #0xc0]
10003210c: a94b4ff4    	ldp	x20, x19, [sp, #0xb0]
100032110: a94a57f6    	ldp	x22, x21, [sp, #0xa0]
100032114: a9495ff8    	ldp	x24, x23, [sp, #0x90]
100032118: a94867fa    	ldp	x26, x25, [sp, #0x80]
10003211c: a9476ffc    	ldp	x28, x27, [sp, #0x70]
100032120: 910343ff    	add	sp, sp, #0xd0
100032124: d65f03c0    	ret
100032128: a94207e4    	ldp	x4, x1, [sp, #0x20]
10003212c: aa1303e2    	mov	x2, x19
100032130: f9400fe3    	ldr	x3, [sp, #0x18]
100032134: aa1b03e5    	mov	x5, x27
100032138: aa1c03e6    	mov	x6, x28
10003213c: 94008b80    	bl	0x100054f3c <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100032140: b9400b08    	ldr	w8, [x24, #0x8]
100032144: f94007e9    	ldr	x9, [sp, #0x8]
100032148: 3100051f    	cmn	w8, #0x1
10003214c: 540000a0    	b.eq	0x100032160 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2ec>
100032150: eb08029f    	cmp	x20, x8
100032154: 54000349    	b.ls	0x1000321bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x348>
100032158: 8b081328    	add	x8, x25, x8, lsl #4
10003215c: a9000500    	stp	x0, x1, [x8]
100032160: 11000528    	add	w8, w9, #0x1
100032164: 2a1f03e0    	mov	w0, wzr
100032168: b9000ae8    	str	w8, [x23, #0x8]
10003216c: 17ffffe7    	b	0x100032108 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x294>
100032170: aa0803e0    	mov	x0, x8
100032174: aa1f03e1    	mov	x1, xzr
100032178: 9407551e    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003217c: aa0903e0    	mov	x0, x9
100032180: aa1403e1    	mov	x1, x20
100032184: 9407551b    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100032188: aa0d03e0    	mov	x0, x13
10003218c: 94075a86    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100032190: aa0a03e0    	mov	x0, x10
100032194: 52800021    	mov	w1, #0x1                ; =1
100032198: 52800043    	mov	w3, #0x2                ; =2
10003219c: 9407585b    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000321a0: aa0903e0    	mov	x0, x9
1000321a4: 52800021    	mov	w1, #0x1                ; =1
1000321a8: aa0a03e2    	mov	x2, x10
1000321ac: 52800063    	mov	w3, #0x3                ; =3
1000321b0: 94075856    	bl	0x100208308 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000321b4: aa0803e0    	mov	x0, x8
1000321b8: 94075a7b    	bl	0x100208ba4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000321bc: aa0803e0    	mov	x0, x8
1000321c0: aa1403e1    	mov	x1, x20
1000321c4: 9407550b    	bl	0x1002075f0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
