from collections import defaultdict
import gzip
import json
import math
from pathlib import Path
import random
from statistics import mean, median

root = Path(__file__).resolve().parent
plan = json.loads((root / "frozen-plan.json").read_text())
n = plan["blocks"]
rng = random.Random(202611210922)
draws = [rng.choices(range(n), k=n) for _ in range(20_000)]


def bootstrap(ratios):
    logs = [math.log(v) for v in ratios]
    results = sorted(math.exp(sum(logs[i] for i in draw) / n) for draw in draws)
    return dict(ratio=math.exp(mean(logs)), ci95=[results[500], results[19499]])


data = defaultdict(dict)
with gzip.open(root / "rows.jsonl.gz", "rt") as src:
    for line in src:
        row = json.loads(line)
        key = row["case"], row["id"]
        assert row["block"] not in data[key]
        data[key][row["block"]] = row
assert all(len(rows) == n for rows in data.values())
result = {}
for case in plan["cases"]:
    key = case["id"]
    roles = case["commands"]
    metrics = {}
    for metric in ["cpuNs", "instructions", "cycles", "cyclesPerInstruction"]:
        aa, medians, grouped = {}, {}, {}
        for role in roles:
            x = [data[key, role][i][metric] for i in range(n)]
            y = [data[key, role + "-aa"][i][metric] for i in range(n)]
            medians[role] = median(x + y)
            aa[role] = bootstrap([b / a for a, b in zip(x, y)])
            lo, hi = aa[role]["ci95"]
            aa[role]["resolves2_5Percent"] = lo >= 0.975 and hi <= 1.025
            grouped[role] = [math.sqrt(a*b) for a, b in zip(x,y)]
        pairs = {}
        for head in roles:
            if not head.startswith("head-"):
                continue
            for ref in [head.replace("head-", "base-", 1), "wasmtime-compiler", "wasmedge-compiler"]:
                if ref not in roles:
                    continue
                ratio = bootstrap([a / b for a, b in zip(grouped[head], grouped[ref])])
                ratio["controlsResolve"] = aa[head]["resolves2_5Percent"] and aa[ref]["resolves2_5Percent"]
                pairs[f"{head}/{ref}"] = ratio
        metrics[metric] = dict(medians=medians, AA=aa, comparisons=pairs)
    result[key] = metrics
(root / "analysis.json").write_text(json.dumps(result, indent=2) + "\n")
for key, metrics in result.items():
    print(key)
    for metric, result in metrics.items():
        print(metric, {k:(round(v["ratio"],5),[round(x,5) for x in v["ci95"]],v["controlsResolve"])
                    for k,v in result["comparisons"].items()})
