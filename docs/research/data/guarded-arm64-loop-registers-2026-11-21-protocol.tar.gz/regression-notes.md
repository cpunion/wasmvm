## Independent counter replay

Six fresh blocks on the exact primary binaries captured retired instructions,
CPU time and cycles around five steady calls per process, with symmetric A/A
controls. These 168 records are separate from the 5,508 primary observations.

| Warm SHA cohort | Go retired instructions Δ vs source base | LLGo retired instructions Δ vs source base | Go CPU speed Δ vs source base | LLGo CPU speed Δ vs source base |
| --- | ---: | ---: | ---: | ---: |
| Clang | −10.41% | −10.49% | +14.54% † | +15.95% † |
| Rust | −10.18% | −10.19% | +10.35% | +10.56% |

The instruction controls resolved for all four comparisons. In the Rust cohort,
relative to Wasmtime, the Go build retires 6.18% more instructions and uses
10.52% more cycles per instruction. LLGo retires 5.68% more instructions and
uses 7.19% more cycles per instruction. The Rust CPU controls resolve against
Wasmtime. Clang CPU controls and the WasmEdge CPU comparison remain unresolved.
Wasmtime's audited compression bodies issue both memory loads ahead of the
arithmetic, while this change leaves wasmvm's loads closer to their consumers.
The independent counters cover the full guest call. The effect of moving the
loads remains to be measured in isolation.

### Adverse source observations

- LLGo interpreter SIMD widening took 1.38% longer in the primary event. The
  independent replay retired the same instruction count to within 0.002% and
  measured 0.81% less CPU time and 0.86% fewer cycles per instruction. The
  instruction count and virtual address of each of `runSlotsLoop` and `runSIMD`
  match across binaries. Changes in their disassembly are relocated data and
  call references. The timing regression did not reproduce. The exact source
  of the cycle variation remains open.
- The Go 64 KiB P3 allocation median moved from 510.504150 to 510.505420
  allocations per request, about 0.65 event per 512-request batch. The baseline
  and current windows overlap in the 261,374–261,390 range. The counter samples
  process-wide managed allocation and the aggregate observation leaves allocation
  sites unresolved. CPU and throughput show no resolved adverse source interval
  for this cohort.
