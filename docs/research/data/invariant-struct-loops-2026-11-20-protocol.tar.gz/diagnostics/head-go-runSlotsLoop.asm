TEXT github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB) /Users/lijie/source/goplus/wasmvm-source-cleanup/internal/engine/execute/execution.go
  execution.go:325	0x100212e40		f9400b90		MOVD 16(R28), R16									
  execution.go:325	0x100212e44		d10703f1		SUB $448, RSP, R17									
  execution.go:325	0x100212e48		eb10023f		CMP R16, R17										
  execution.go:325	0x100212e4c		54013b09		BLS 2520(PC)										
  execution.go:325	0x100212e50		d10903f4		SUB $576, RSP, R20									
  execution.go:325	0x100212e54		a93ffa9d		STP (R29, R30), -8(R20)									
  execution.go:325	0x100212e58		9100029f		MOVD R20, RSP										
  execution.go:325	0x100212e5c		d10023fd		SUB $8, RSP, R29									
  execution.go:327	0x100212e60		f90127e0		MOVD R0, 584(RSP)									
  execution.go:326	0x100212e64		39408009		MOVBU 32(R0), R9									
  execution.go:326	0x100212e68		3903dfe9		MOVB R9, 247(RSP)									
  execution.go:327	0x100212e6c		14000004		JMP 4(PC)										
  execution.go:327	0x100212e70		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x100212e74		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:328	0x100212e78		f94093e1		MOVD 288(RSP), R1									
  execution.go:327	0x100212e7c		a9442c0a		LDP 64(R0), (R10, R11)									
  execution.go:327	0x100212e80		b40138ab		CBZ R11, 2501(PC)									
  execution.go:328	0x100212e84		d100056b		SUB $1, R11, R11									
  execution.go:329	0x100212e88		8b0b194a		ADD R11<<6, R10, R10									
  execution.go:330	0x100212e8c		3900415f		MOVB ZR, 16(R10)									
  execution.go:331	0x100212e90		f940014b		MOVD (R10), R11										
  execution.go:334	0x100212e94		f9400d4c		MOVD 24(R10), R12									
  execution.go:332	0x100212e98		a944396d		LDP 64(R11), (R13, R14)									
  execution.go:333	0x100212e9c		a94b41cf		LDP 176(R14), (R15, R16)								
  execution.go:337	0x100212ea0		f9404411		MOVD 136(R0), R17									
  execution.go:337	0x100212ea4		f9404dd3		MOVD 152(R14), R19									
  execution.go:337	0x100212ea8		8b130194		ADD R19, R12, R20									
  execution.go:337	0x100212eac		eb14023f		CMP R20, R17										
  execution.go:337	0x100212eb0		540136c3		BCC 2486(PC)										
  execution.go:337	0x100212eb4		eb14019f		CMP R20, R12										
  execution.go:337	0x100212eb8		54013648		BHI 2482(PC)										
  execution.go:329	0x100212ebc		f900b7ea		MOVD R10, 360(RSP)									
  execution.go:331	0x100212ec0		f900b3eb		MOVD R11, 352(RSP)									
  execution.go:332	0x100212ec4		f900bfee		MOVD R14, 376(RSP)									
  execution.go:335	0x100212ec8		f900abed		MOVD R13, 336(RSP)									
  execution.go:337	0x100212ecc		f90087f3		MOVD R19, 264(RSP)									
  execution.go:333	0x100212ed0		f9008bf0		MOVD R16, 272(RSP)									
  execution.go:333	0x100212ed4		f900a7ef		MOVD R15, 328(RSP)									
  execution.go:337	0x100212ed8		f9403c14		MOVD 120(R0), R20									
  execution.go:337	0x100212edc		cb110191		SUB R17, R12, R17									
  execution.go:337	0x100212ee0		8a91fd8c		AND R17->63, R12, R12									
  execution.go:336	0x100212ee4		b9400951		MOVWU 8(R10), R17									
  execution.go:337	0x100212ee8		8b0c128c		ADD R12<<4, R20, R12									
  execution.go:337	0x100212eec		f9009bec		MOVD R12, 304(RSP)									
  execution.go:338	0x100212ef0		14000002		JMP 2(PC)										
  execution.go:341	0x100212ef4		aa1503e1		MOVD R21, R1										
  execution.go:341	0x100212ef8		2a1103f4		MOVW R17, R20										
  execution.go:341	0x100212efc		eb10029f		CMP R16, R20										
  execution.go:341	0x100212f00		540133a2		BCS 2461(PC)										
  execution.go:341	0x100212f04		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:342	0x100212f08		360002c9		TBZ $0, R9, 22(PC)									
  execution.go:343	0x100212f0c		a947d9d5		LDP 120(R14), (R21, R22)								
  execution.go:343	0x100212f10		b9400697		MOVWU 4(R20), R23									
  execution.go:343	0x100212f14		aa1703f8		MOVD R23, R24										
  execution.go:343	0x100212f18		eb16031f		CMP R22, R24										
  execution.go:343	0x100212f1c		54013262		BCS 2451(PC)										
  execution.go:343	0x100212f20		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:343	0x100212f24		cb1816d6		SUB R24<<5, R22, R22									
  ir.go:27		0x100212f28		b8766ab7		MOVWU (R21)(R22), R23									
  execution.go:343	0x100212f2c		8b1602b5		ADD R22, R21, R21									
  ir.go:27		0x100212f30		710016ff		CMPW $5, R23										
  ir.go:27		0x100212f34		54000060		BEQ 3(PC)										
  ir.go:27		0x100212f38		71002eff		CMPW $11, R23										
  ir.go:27		0x100212f3c		54000061		BNE 3(PC)										
  execution.go:344	0x100212f40		aa1f03e2		MOVD ZR, R2										
  execution.go:344	0x100212f44		14000002		JMP 2(PC)										
  execution.go:344	0x100212f48		b24003e2		ORR $1, ZR, R2										
  execution.go:345	0x100212f4c		f940a816		MOVD 336(R0), R22									
  execution.go:345	0x100212f50		eb16005f		CMP R22, R2										
  execution.go:345	0x100212f54		5400de88		BHI 1780(PC)										
  execution.go:348	0x100212f58		cb0202d5		SUB R2, R22, R21									
  execution.go:348	0x100212f5c		f900a815		MOVD R21, 336(R0)									
  execution.go:350	0x100212f60		91000435		ADD $1, R1, R21										
  execution.go:351	0x100212f64		f24016bf		TST $63, R21										
  execution.go:351	0x100212f68		54000421		BNE 33(PC)										
  execution.go:341	0x100212f6c		f900aff4		MOVD R20, 344(RSP)									
  execution.go:350	0x100212f70		f90097f5		MOVD R21, 296(RSP)									
  execution.go:341	0x100212f74		b900fbf1		MOVW R17, 248(RSP)									
  execution.go:209	0x100212f78		f940b016		MOVD 352(R0), R22									
  execution.go:209	0x100212f7c		b40000d6		CBZ R22, 6(PC)										
  type.go:19		0x100212f80		88dffed6		LDARW (R22), R22									
  execution.go:209	0x100212f84		35000096		CBNZW R22, 4(PC)									
  execution.go:212	0x100212f88		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x100212f8c		aa1f03e2		MOVD ZR, R2										
  execution.go:352	0x100212f90		14000013		JMP 19(PC)										
  execution.go:212	0x100212f94		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100212f98		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x100212f9c		d63f0020		CALL (R1)										
  execution.go:356	0x100212fa0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100212fa4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100212fa8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x100212fac		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100212fb0		f940abed		MOVD 336(RSP), R13									
  execution.go:434	0x100212fb4		f940bfee		MOVD 376(RSP), R14									
  execution.go:364	0x100212fb8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:364	0x100212fbc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:360	0x100212fc0		b940fbf1		MOVWU 248(RSP), R17									
  execution.go:361	0x100212fc4		f94087f3		MOVD 264(RSP), R19									
  execution.go:360	0x100212fc8		f940aff4		MOVD 344(RSP), R20									
  execution.go:360	0x100212fcc		f94097f5		MOVD 296(RSP), R21									
  execution.go:212	0x100212fd0		aa0103e2		MOVD R1, R2										
  execution.go:212	0x100212fd4		aa0003e1		MOVD R0, R1										
  execution.go:353	0x100212fd8		f94127e0		MOVD 584(RSP), R0									
  execution.go:352	0x100212fdc		b4000081		CBZ R1, 4(PC)										
  execution.go:352	0x100212fe0		140006f2		JMP 1778(PC)										
  execution.go:364	0x100212fe4		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:365	0x100212fe8		910006b5		ADD $1, R21, R21									
  execution.go:356	0x100212fec		b9401e96		MOVWU 28(R20), R22									
  execution.go:356	0x100212ff0		340002f6		CBZW R22, 23(PC)									
  execution.go:356	0x100212ff4		b9400297		MOVWU (R20), R23									
  execution.go:356	0x100212ff8		710082ff		CMPW $32, R23										
  execution.go:356	0x100212ffc		54000060		BEQ 3(PC)										
  execution.go:356	0x100213000		710106ff		CMPW $65, R23										
  execution.go:356	0x100213004		54000241		BNE 18(PC)										
  execution.go:356	0x100213008		37000229		TBNZ $0, R9, 17(PC)									
  execution.go:356	0x10021300c		924016b8		AND $63, R21, R24									
  execution.go:356	0x100213010		f100ff1f		CMP $63, R24										
  execution.go:356	0x100213014		540001c0		BEQ 14(PC)										
  execution.go:360	0x100213018		710106ff		CMPW $65, R23										
  execution.go:360	0x10021301c		540000e1		BNE 7(PC)										
  execution.go:361	0x100213020		b9400a96		MOVWU 8(R20), R22									
  execution.go:361	0x100213024		eb1302df		CMP R19, R22										
  execution.go:361	0x100213028		540129a2		BCS 2381(PC)										
  execution.go:361	0x10021302c		8b161196		ADD R22<<4, R12, R22									
  execution.go:361	0x100213030		b9401a94		MOVWU 24(R20), R20									
  execution.go:361	0x100213034		a9007ed4		STP (R20, ZR), (R22)									
  execution.go:363	0x100213038		91000631		ADD $1, R17, R17									
  execution.go:364	0x10021303c		2a1103f4		MOVW R17, R20										
  execution.go:364	0x100213040		eb10029f		CMP R16, R20										
  execution.go:364	0x100213044		54fffd03		BCC -24(PC)										
  execution.go:364	0x100213048		14000942		JMP 2370(PC)										
  execution.go:360	0x10021304c		b90107f1		MOVW R17, 260(RSP)									
  execution.go:360	0x100213050		f90093f5		MOVD R21, 288(RSP)									
  execution.go:360	0x100213054		f900c3f4		MOVD R20, 384(RSP)									
  execution.go:371	0x100213058		b9400281		MOVWU (R20), R1										
  execution.go:371	0x10021305c		d1038037		SUB $224, R1, R23									
  execution.go:371	0x100213060		d29fe418		MOVD $65312, R24									
  execution.go:371	0x100213064		f2a01ff8		MOVK $(255<<16), R24									
  execution.go:371	0x100213068		6b1802ff		CMPW R24, R23										
  execution.go:371	0x10021306c		54002822		BCS 321(PC)										
  execution.go:372	0x100213070		d3507c37		UBFX $16, R1, $16, R23									
  execution.go:396	0x100213074		7103eeff		CMPW $251, R23										
  execution.go:396	0x100213078		540019e0		BEQ 207(PC)										
  execution.go:432	0x10021307c		7103f2ff		CMPW $252, R23										
  execution.go:432	0x100213080		54000ba1		BNE 93(PC)										
  wide.go:3		0x100213084		d2800277		MOVD $19, R23										
  wide.go:3		0x100213088		f2a01f97		MOVK $(252<<16), R23									
  wide.go:3		0x10021308c		cb170038		SUB R23, R1, R24									
  wide.go:3		0x100213090		71000f1f		CMPW $3, R24										
  execution.go:433	0x100213094		540026e8		BHI 311(PC)										
  execution.go:434	0x100213098		f9406dd8		MOVD 216(R14), R24									
  execution.go:434	0x10021309c		b9401a94		MOVWU 24(R20), R20									
  execution.go:434	0x1002130a0		8b160299		ADD R22, R20, R25									
  execution.go:434	0x1002130a4		91000b39		ADD $2, R25, R25									
  execution.go:434	0x1002130a8		2a1903f9		MOVW R25, R25										
  execution.go:434	0x1002130ac		eb18033f		CMP R24, R25										
  execution.go:434	0x1002130b0		540124a8		BHI 2341(PC)										
  execution.go:434	0x1002130b4		eb19029f		CMP R25, R20										
  execution.go:434	0x1002130b8		54012408		BHI 2336(PC)										
  execution.go:434	0x1002130bc		f94065da		MOVD 200(R14), R26									
  execution.go:434	0x1002130c0		cb180298		SUB R24, R20, R24									
  execution.go:434	0x1002130c4		8a98fe98		AND R24->63, R20, R24									
  execution.go:434	0x1002130c8		8b180b5e		ADD R24<<2, R26, R30									
  execution.go:434	0x1002130cc		cb140334		SUB R20, R25, R20									
  execution.go:435	0x1002130d0		b4012334		CBZ R20, 2329(PC)									
  execution.go:435	0x1002130d4		b8787b58		MOVWU (R26)(R24<<2), R24								
  execution.go:435	0x1002130d8		eb13031f		CMP R19, R24										
  execution.go:435	0x1002130dc		54012262		BCS 2323(PC)										
  execution.go:435	0x1002130e0		8b181198		ADD R24<<4, R12, R24									
  execution.go:435	0x1002130e4		f100069f		CMP $1, R20										
  execution.go:435	0x1002130e8		540121e9		BLS 2319(PC)										
  execution.go:435	0x1002130ec		b94007d9		MOVWU 4(R30), R25									
  execution.go:435	0x1002130f0		eb13033f		CMP R19, R25										
  execution.go:435	0x1002130f4		54012122		BCS 2313(PC)										
  execution.go:435	0x1002130f8		8b191199		ADD R25<<4, R12, R25									
  execution.go:435	0x1002130fc		f9400318		MOVD (R24), R24										
  execution.go:435	0x100213100		f9400339		MOVD (R25), R25										
  execution.go:438	0x100213104		d280029a		MOVD $20, R26										
  execution.go:438	0x100213108		f2a01f9a		MOVK $(252<<16), R26									
  execution.go:438	0x10021310c		6b1a003f		CMPW R26, R1										
  execution.go:438	0x100213110		540002e8		BHI 23(PC)										
  execution.go:439	0x100213114		f1000a9f		CMP $2, R20										
  execution.go:439	0x100213118		54011fe9		BLS 2303(PC)										
  execution.go:439	0x10021311c		b9400bda		MOVWU 8(R30), R26									
  execution.go:439	0x100213120		eb13035f		CMP R19, R26										
  execution.go:439	0x100213124		54011f22		BCS 2297(PC)										
  execution.go:439	0x100213128		8b1a119a		ADD R26<<4, R12, R26									
  execution.go:439	0x10021312c		f1000e9f		CMP $3, R20										
  execution.go:439	0x100213130		54011ea9		BLS 2293(PC)										
  execution.go:439	0x100213134		b9400fc2		MOVWU 12(R30), R2									
  execution.go:439	0x100213138		eb13005f		CMP R19, R2										
  execution.go:439	0x10021313c		54011e02		BCS 2288(PC)										
  execution.go:439	0x100213140		8b021182		ADD R2<<4, R12, R2									
  execution.go:439	0x100213144		f940035a		MOVD (R26), R26										
  execution.go:439	0x100213148		f9400042		MOVD (R2), R2										
  execution.go:441	0x10021314c		6b17003f		CMPW R23, R1										
  execution.go:441	0x100213150		54000081		BNE 4(PC)										
  execution.go:442	0x100213154		ab180357		ADDS R24, R26, R23									
  execution.go:443	0x100213158		ba020338		ADCS R2, R25, R24									
  <autogenerated>:1	0x10021315c		14000013		JMP 19(PC)										
  execution.go:445	0x100213160		eb1a0317		SUBS R26, R24, R23									
  execution.go:446	0x100213164		fa020338		SBCS R2, R25, R24									
  <autogenerated>:1	0x100213168		14000010		JMP 16(PC)										
  execution.go:449	0x10021316c		9b187f37		MUL R24, R25, R23									
  execution.go:449	0x100213170		9bd97f1a		UMULH R25, R24, R26									
  execution.go:331	0x100213174		aa0b03e2		MOVD R11, R2										
  execution.go:450	0x100213178		d28002ab		MOVD $21, R11										
  execution.go:450	0x10021317c		f2a01f8b		MOVK $(252<<16), R11									
  execution.go:450	0x100213180		6b0b003f		CMPW R11, R1										
  execution.go:450	0x100213184		540000e1		BNE 7(PC)										
  execution.go:452	0x100213188		cb19034b		SUB R25, R26, R11									
  execution.go:451	0x10021318c		f100031f		CMP $0, R24										
  execution.go:452	0x100213190		9a9ab16b		CSEL LT, R11, R26, R11									
  execution.go:455	0x100213194		cb180178		SUB R24, R11, R24									
  execution.go:454	0x100213198		f100033f		CMP $0, R25										
  execution.go:455	0x10021319c		9a8bb31a		CSEL LT, R24, R11, R26									
  execution.go:786	0x1002131a0		aa0203eb		MOVD R2, R11										
  execution.go:441	0x1002131a4		aa1a03f8		MOVD R26, R24										
  execution.go:459	0x1002131a8		910006d9		ADD $1, R22, R25									
  execution.go:459	0x1002131ac		2a1903f9		MOVW R25, R25										
  execution.go:459	0x1002131b0		eb14033f		CMP R20, R25										
  execution.go:459	0x1002131b4		540119e2		BCS 2255(PC)										
  execution.go:459	0x1002131b8		b8797bd9		MOVWU (R30)(R25<<2), R25								
  execution.go:459	0x1002131bc		eb1402df		CMP R20, R22										
  execution.go:459	0x1002131c0		54011922		BCS 2249(PC)										
  execution.go:459	0x1002131c4		b8767bd4		MOVWU (R30)(R22<<2), R20								
  execution.go:459	0x1002131c8		eb13029f		CMP R19, R20										
  execution.go:459	0x1002131cc		54011862		BCS 2243(PC)										
  execution.go:459	0x1002131d0		8b141194		ADD R20<<4, R12, R20									
  execution.go:459	0x1002131d4		a9007e97		STP (R23, ZR), (R20)									
  execution.go:459	0x1002131d8		eb13033f		CMP R19, R25										
  execution.go:459	0x1002131dc		54011782		BCS 2236(PC)										
  execution.go:459	0x1002131e0		8b191194		ADD R25<<4, R12, R20									
  execution.go:459	0x1002131e4		a9007e98		STP (R24, ZR), (R20)									
  execution.go:460	0x1002131e8		91000631		ADD $1, R17, R17									
  execution.go:461	0x1002131ec		b9000951		MOVW R17, 8(R10)									
  execution.go:462	0x1002131f0		17ffff41		JMP -191(PC)										
  execution.go:373	0x1002131f4		7103f6ff		CMPW $253, R23										
  execution.go:373	0x1002131f8		54000080		BEQ 4(PC)										
  execution.go:465	0x1002131fc		7103983f		CMPW $230, R1										
  execution.go:465	0x100213200		54001b88		BHI 220(PC)										
  execution.go:465	0x100213204		1400062f		JMP 1583(PC)										
  execution.go:375	0x100213208		b9400e87		MOVWU 12(R20), R7									
  execution.go:375	0x10021320c		310004ff		CMNW $1, R7										
  execution.go:375	0x100213210		540000c0		BEQ 6(PC)										
  execution.go:376	0x100213214		eb1300ff		CMP R19, R7										
  execution.go:376	0x100213218		54011562		BCS 2219(PC)										
  execution.go:376	0x10021321c		8b071187		ADD R7<<4, R12, R7									
  execution.go:376	0x100213220		a9401ce2		LDP (R7), (R2, R7)									
  execution.go:376	0x100213224		14000003		JMP 3(PC)										
  execution.go:376	0x100213228		aa1f03e2		MOVD ZR, R2										
  execution.go:376	0x10021322c		aa1f03e7		MOVD ZR, R7										
  execution.go:378	0x100213230		b9401288		MOVWU 16(R20), R8									
  execution.go:378	0x100213234		3100051f		CMNW $1, R8										
  execution.go:378	0x100213238		540000c0		BEQ 6(PC)										
  execution.go:379	0x10021323c		eb13011f		CMP R19, R8										
  execution.go:379	0x100213240		540113e2		BCS 2207(PC)										
  execution.go:379	0x100213244		8b081188		ADD R8<<4, R12, R8									
  execution.go:379	0x100213248		a9401103		LDP (R8), (R3, R4)									
  execution.go:379	0x10021324c		14000003		JMP 3(PC)										
  execution.go:379	0x100213250		aa1f03e4		MOVD ZR, R4										
  execution.go:379	0x100213254		aa1f03e3		MOVD ZR, R3										
  execution.go:382	0x100213258		b9401688		MOVWU 20(R20), R8									
  execution.go:382	0x10021325c		3100051f		CMNW $1, R8										
  execution.go:382	0x100213260		540000c0		BEQ 6(PC)										
  execution.go:383	0x100213264		eb13011f		CMP R19, R8										
  execution.go:383	0x100213268		54011262		BCS 2195(PC)										
  execution.go:383	0x10021326c		8b081188		ADD R8<<4, R12, R8									
  execution.go:383	0x100213270		a9401905		LDP (R8), (R5, R6)									
  execution.go:383	0x100213274		14000003		JMP 3(PC)										
  execution.go:383	0x100213278		aa1f03e6		MOVD ZR, R6										
  execution.go:383	0x10021327c		aa1f03e5		MOVD ZR, R5										
  execution.go:385	0x100213280		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:385	0x100213284		b9400697		MOVWU 4(R20), R23									
  execution.go:385	0x100213288		aa1703f8		MOVD R23, R24										
  execution.go:385	0x10021328c		eb16031f		CMP R22, R24										
  execution.go:385	0x100213290		540110c2		BCS 2182(PC)										
  execution.go:385	0x100213294		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:385	0x100213298		cb1816d6		SUB R24<<5, R22, R22									
  execution.go:386	0x10021329c		d3403c37		UBFX $0, R1, $16, R23									
  execution.go:385	0x1002132a0		8b160108		ADD R22, R8, R8										
  execution.go:388	0x1002132a4		71002aff		CMPW $10, R23										
  execution.go:388	0x1002132a8		540000e9		BLS 7(PC)										
  execution.go:388	0x1002132ac		d10152f6		SUB $84, R23, R22									
  execution.go:388	0x1002132b0		71000edf		CMPW $3, R22										
  execution.go:388	0x1002132b4		54000089		BLS 4(PC)										
  execution.go:388	0x1002132b8		b24002f6		ORR $1, R23, R22									
  execution.go:388	0x1002132bc		710176df		CMPW $93, R22										
  execution.go:388	0x1002132c0		54000201		BNE 16(PC)										
  execution.go:389	0x1002132c4		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x1002132c8		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x1002132cc		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x1002132d0		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:389	0x1002132d4		eb16031f		CMP R22, R24										
  execution.go:389	0x1002132d8		54010e22		BCS 2161(PC)										
  execution.go:389	0x1002132dc		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:389	0x1002132e0		f94008e0		MOVD 16(R7), R0										
  execution.go:389	0x1002132e4		39410107		MOVBU 64(R8), R7									
  execution.go:389	0x1002132e8		aa0303e5		MOVD R3, R5										
  execution.go:389	0x1002132ec		aa0403e6		MOVD R4, R6										
  execution.go:389	0x1002132f0		aa1703e3		MOVD R23, R3										
  execution.go:389	0x1002132f4		aa0703e4		MOVD R7, R4										
  execution.go:389	0x1002132f8		97ffa312		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:389	0x1002132fc		1400001d		JMP 29(PC)										
  execution.go:390	0x100213300		71002eff		CMPW $11, R23										
  execution.go:390	0x100213304		54000080		BEQ 4(PC)										
  execution.go:390	0x100213308		d10162f6		SUB $88, R23, R22									
  execution.go:390	0x10021330c		71000edf		CMPW $3, R22										
  execution.go:390	0x100213310		54000268		BHI 19(PC)										
  execution.go:391	0x100213314		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x100213318		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x10021331c		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x100213320		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:391	0x100213324		eb16031f		CMP R22, R24										
  execution.go:391	0x100213328		54010b42		BCS 2138(PC)										
  execution.go:391	0x10021332c		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:391	0x100213330		f94008e0		MOVD 16(R7), R0										
  execution.go:391	0x100213334		39410107		MOVBU 64(R8), R7									
  execution.go:391	0x100213338		aa0303e5		MOVD R3, R5										
  execution.go:391	0x10021333c		aa0403e6		MOVD R4, R6										
  execution.go:391	0x100213340		aa1703e3		MOVD R23, R3										
  execution.go:391	0x100213344		aa0703e4		MOVD R7, R4										
  execution.go:391	0x100213348		97ffa376		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:391	0x10021334c		aa0003e2		MOVD R0, R2										
  execution.go:393	0x100213350		aa1f03e1		MOVD ZR, R1										
  execution.go:393	0x100213354		aa1f03e0		MOVD ZR, R0										
  execution.go:391	0x100213358		14000006		JMP 6(PC)										
  execution.go:393	0x10021335c		aa0803e0		MOVD R8, R0										
  execution.go:393	0x100213360		aa0203e1		MOVD R2, R1										
  execution.go:393	0x100213364		aa0703e2		MOVD R7, R2										
  execution.go:393	0x100213368		97ffb362		CALL github.com/cpunion/wasmvm/internal/engine/simd.Eval(SB)				
  execution.go:391	0x10021336c		aa1f03e2		MOVD ZR, R2										
  execution.go:342	0x100213370		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213374		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213378		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021337c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213380		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213384		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213388		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021338c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213390		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213394		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213398		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021339c		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x1002133a0		aa0103f7		MOVD R1, R23										
  execution.go:395	0x1002133a4		aa0003f6		MOVD R0, R22										
  execution.go:209	0x1002133a8		f94127e0		MOVD 584(RSP), R0									
  execution.go:395	0x1002133ac		aa0203e1		MOVD R2, R1										
  execution.go:395	0x1002133b0		140005b9		JMP 1465(PC)										
  gc_access.go:11	0x1002133b4		d3403c36		UBFX $0, R1, $16, R22									
  gc_access.go:11	0x1002133b8		710036df		CMPW $13, R22										
  gc_access.go:14	0x1002133bc		54000148		BHI 10(PC)										
  gc_access.go:12	0x1002133c0		d1000ad7		SUB $2, R22, R23									
  gc_access.go:12	0x1002133c4		71000aff		CMPW $2, R23										
  gc_access.go:12	0x1002133c8		54000249		BLS 18(PC)										
  gc_access.go:14	0x1002133cc		710016df		CMPW $5, R22										
  gc_access.go:14	0x1002133d0		54000060		BEQ 3(PC)										
  gc_access.go:14	0x1002133d4		71002edf		CMPW $11, R22										
  gc_access.go:14	0x1002133d8		54000203		BCC 16(PC)										
  gc_access.go:14	0x1002133dc		b27f03e1		ORR $2, ZR, R1										
  execution.go:400	0x1002133e0		1400000f		JMP 15(PC)										
  gc_access.go:11	0x1002133e4		71003edf		CMPW $15, R22										
  gc_access.go:12	0x1002133e8		540000a8		BHI 5(PC)										
  gc_access.go:16	0x1002133ec		71003adf		CMPW $14, R22										
  gc_access.go:16	0x1002133f0		54000101		BNE 8(PC)										
  gc_access.go:16	0x1002133f4		b24007e1		ORR $3, ZR, R1										
  execution.go:400	0x1002133f8		14000009		JMP 9(PC)										
  gc_access.go:12	0x1002133fc		d10072d7		SUB $28, R22, R23									
  gc_access.go:12	0x100213400		71000aff		CMPW $2, R23										
  gc_access.go:12	0x100213404		54000069		BLS 3(PC)										
  gc_access.go:12	0x100213408		71008adf		CMPW $34, R22										
  gc_access.go:12	0x10021340c		54000061		BNE 3(PC)										
  gc_access.go:12	0x100213410		b24003e1		ORR $1, ZR, R1										
  execution.go:400	0x100213414		14000002		JMP 2(PC)										
  execution.go:400	0x100213418		aa1f03e1		MOVD ZR, R1										
  execution.go:400	0x10021341c		b40007e1		CBZ R1, 63(PC)										
  execution.go:402	0x100213420		b9400e96		MOVWU 12(R20), R22									
  execution.go:402	0x100213424		310006df		CMNW $1, R22										
  execution.go:402	0x100213428		540000c0		BEQ 6(PC)										
  execution.go:403	0x10021342c		eb1302df		CMP R19, R22										
  execution.go:403	0x100213430		540102a2		BCS 2069(PC)										
  execution.go:403	0x100213434		8b161196		ADD R22<<4, R12, R22									
  execution.go:403	0x100213438		a94012c3		LDP (R22), (R3, R4)									
  execution.go:403	0x10021343c		14000003		JMP 3(PC)										
  execution.go:403	0x100213440		aa1f03e4		MOVD ZR, R4										
  execution.go:403	0x100213444		aa1f03e3		MOVD ZR, R3										
  execution.go:405	0x100213448		b9401296		MOVWU 16(R20), R22									
  execution.go:405	0x10021344c		310006df		CMNW $1, R22										
  execution.go:405	0x100213450		540000c0		BEQ 6(PC)										
  execution.go:406	0x100213454		eb1302df		CMP R19, R22										
  execution.go:406	0x100213458		54010102		BCS 2056(PC)										
  execution.go:406	0x10021345c		8b161196		ADD R22<<4, R12, R22									
  execution.go:406	0x100213460		a9401ac5		LDP (R22), (R5, R6)									
  execution.go:406	0x100213464		14000003		JMP 3(PC)										
  execution.go:406	0x100213468		aa1f03e6		MOVD ZR, R6										
  execution.go:406	0x10021346c		aa1f03e5		MOVD ZR, R5										
  execution.go:408	0x100213470		f100083f		CMP $2, R1										
  execution.go:408	0x100213474		540001ad		BLE 13(PC)										
  execution.go:409	0x100213478		a94cddd6		LDP 200(R14), (R22, R23)								
  execution.go:409	0x10021347c		b9401a98		MOVWU 24(R20), R24									
  execution.go:409	0x100213480		91000b18		ADD $2, R24, R24									
  execution.go:409	0x100213484		2a1803f8		MOVW R24, R24										
  execution.go:409	0x100213488		eb17031f		CMP R23, R24										
  execution.go:409	0x10021348c		5400ff02		BCS 2040(PC)										
  execution.go:409	0x100213490		b8787ad6		MOVWU (R22)(R24<<2), R22								
  execution.go:409	0x100213494		eb1302df		CMP R19, R22										
  execution.go:409	0x100213498		5400fe42		BCS 2034(PC)										
  execution.go:409	0x10021349c		8b161196		ADD R22<<4, R12, R22									
  execution.go:409	0x1002134a0		a94022c7		LDP (R22), (R7, R8)									
  execution.go:409	0x1002134a4		14000003		JMP 3(PC)										
  execution.go:409	0x1002134a8		aa1f03e7		MOVD ZR, R7										
  execution.go:409	0x1002134ac		aa1f03e8		MOVD ZR, R8										
  execution.go:412	0x1002134b0		a947ddd6		LDP 120(R14), (R22, R23)								
  execution.go:412	0x1002134b4		b9400698		MOVWU 4(R20), R24									
  execution.go:412	0x1002134b8		aa1803f9		MOVD R24, R25										
  execution.go:412	0x1002134bc		eb17033f		CMP R23, R25										
  execution.go:412	0x1002134c0		5400fca2		BCS 2021(PC)										
  execution.go:412	0x1002134c4		f9400000		MOVD (R0), R0										
  execution.go:412	0x1002134c8		d3787f09		UBFIZ $8, R24, $32, R9									
  execution.go:412	0x1002134cc		cb191529		SUB R25<<5, R9, R9									
  execution.go:412	0x1002134d0		8b0902c2		ADD R9, R22, R2										
  execution.go:412	0x1002134d4		aa0d03e1		MOVD R13, R1										
  execution.go:412	0x1002134d8		97ffc37a		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess(SB)		
  execution.go:413	0x1002134dc		b500b782		CBNZ R2, 1468(PC)									
  execution.go:420	0x1002134e0		f940c3e9		MOVD 384(RSP), R9									
  execution.go:420	0x1002134e4		b9400929		MOVWU 8(R9), R9										
  execution.go:420	0x1002134e8		3100053f		CMNW $1, R9										
  execution.go:420	0x1002134ec		54000100		BEQ 8(PC)										
  execution.go:421	0x1002134f0		f94087ea		MOVD 264(RSP), R10									
  execution.go:421	0x1002134f4		eb0a013f		CMP R10, R9										
  execution.go:421	0x1002134f8		5400fac2		BCS 2006(PC)										
  execution.go:421	0x1002134fc		f9409beb		MOVD 304(RSP), R11									
  execution.go:421	0x100213500		8b091169		ADD R9<<4, R11, R9									
  execution.go:421	0x100213504		a9000520		STP (R0, R1), (R9)									
  execution.go:421	0x100213508		1400000a		JMP 10(PC)										
  execution.go:361	0x10021350c		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x100213510		f9409beb		MOVD 304(RSP), R11									
  execution.go:420	0x100213514		14000007		JMP 7(PC)										
  execution.go:424	0x100213518		b9000951		MOVW R17, 8(R10)									
  execution.go:425	0x10021351c		9400091d		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC(SB)		
  execution.go:425	0x100213520		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:425	0x100213524		3500b8c1		CBNZW R1, 1478(PC)									
  execution.go:361	0x100213528		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x10021352c		f9409beb		MOVD 304(RSP), R11									
  execution.go:429	0x100213530		b94107e9		MOVWU 260(RSP), R9									
  execution.go:429	0x100213534		91000531		ADD $1, R9, R17										
  execution.go:430	0x100213538		f940b7e9		MOVD 360(RSP), R9									
  execution.go:430	0x10021353c		b9000931		MOVW R17, 8(R9)										
  execution.go:209	0x100213540		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x100213544		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213548		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10021354c		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x100213550		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213554		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213558		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10021355c		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213560		f9408bf0		MOVD 272(RSP), R16									
  execution.go:361	0x100213564		f94087f3		MOVD 264(RSP), R19									
  execution.go:341	0x100213568		f94093f5		MOVD 288(RSP), R21									
  execution.go:431	0x10021356c		17fffe62		JMP -414(PC)										
  execution.go:479	0x100213570		d1011437		SUB $69, R1, R23									
  execution.go:479	0x100213574		7101feff		CMPW $127, R23										
  execution.go:479	0x100213578		54005468		BHI 675(PC)										
  execution.go:480	0x10021357c		aa0103f6		MOVD R1, R22										
  execution.go:480	0x100213580		d10116d6		SUB $69, R22, R22									
  execution.go:480	0x100213584		d0000fe2		ADRP 2088960(PC), R2									
  execution.go:480	0x100213588		91390042		ADD $3648, R2, R2									
  execution.go:480	0x10021358c		f876785b		MOVD (R2)(R22<<3), R27									
  execution.go:480	0x100213590		d61f0360		JMP (R27)										
  execution.go:482	0x100213594		b9400e96		MOVWU 12(R20), R22									
  execution.go:482	0x100213598		eb1302df		CMP R19, R22										
  execution.go:482	0x10021359c		5400f542		BCS 1962(PC)										
  execution.go:482	0x1002135a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:482	0x1002135a4		f94002d6		MOVD (R22), R22										
  integer.go:9		0x1002135a8		710002df		CMPW $0, R22										
  integer.go:9		0x1002135ac		9a9f17f6		CSET EQ, R22										
  execution.go:482	0x1002135b0		14000293		JMP 659(PC)										
  execution.go:484	0x1002135b4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:484	0x1002135b8		eb1302df		CMP R19, R22										
  execution.go:484	0x1002135bc		5400f3e2		BCS 1951(PC)										
  execution.go:484	0x1002135c0		8b161196		ADD R22<<4, R12, R22									
  execution.go:484	0x1002135c4		eb1302ff		CMP R19, R23										
  execution.go:484	0x1002135c8		5400f322		BCS 1945(PC)										
  execution.go:484	0x1002135cc		f94002d8		MOVD (R22), R24										
  execution.go:484	0x1002135d0		8b171197		ADD R23<<4, R12, R23									
  execution.go:484	0x1002135d4		f94002f7		MOVD (R23), R23										
  integer.go:10		0x1002135d8		6b1802ff		CMPW R24, R23										
  integer.go:10		0x1002135dc		9a9f17f6		CSET EQ, R22										
  execution.go:484	0x1002135e0		14000287		JMP 647(PC)										
  execution.go:486	0x1002135e4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:486	0x1002135e8		eb1302df		CMP R19, R22										
  execution.go:486	0x1002135ec		5400f1a2		BCS 1933(PC)										
  execution.go:486	0x1002135f0		8b161196		ADD R22<<4, R12, R22									
  execution.go:486	0x1002135f4		eb1302ff		CMP R19, R23										
  execution.go:486	0x1002135f8		5400f0e2		BCS 1927(PC)										
  execution.go:486	0x1002135fc		f94002d8		MOVD (R22), R24										
  execution.go:486	0x100213600		8b171197		ADD R23<<4, R12, R23									
  execution.go:486	0x100213604		f94002f7		MOVD (R23), R23										
  integer.go:11		0x100213608		6b1802ff		CMPW R24, R23										
  integer.go:11		0x10021360c		9a9f07f6		CSET NE, R22										
  execution.go:486	0x100213610		1400027b		JMP 635(PC)										
  execution.go:488	0x100213614		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:488	0x100213618		eb1302df		CMP R19, R22										
  execution.go:488	0x10021361c		5400ef62		BCS 1915(PC)										
  execution.go:488	0x100213620		8b161196		ADD R22<<4, R12, R22									
  execution.go:488	0x100213624		eb1302ff		CMP R19, R23										
  execution.go:488	0x100213628		5400eea2		BCS 1909(PC)										
  execution.go:488	0x10021362c		f94002d8		MOVD (R22), R24										
  execution.go:488	0x100213630		8b171197		ADD R23<<4, R12, R23									
  execution.go:488	0x100213634		f94002f7		MOVD (R23), R23										
  integer.go:12		0x100213638		6b1802ff		CMPW R24, R23										
  integer.go:12		0x10021363c		9a9fd7f6		CSET GT, R22										
  execution.go:488	0x100213640		1400026f		JMP 623(PC)										
  execution.go:490	0x100213644		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:490	0x100213648		eb1302df		CMP R19, R22										
  execution.go:490	0x10021364c		5400ed22		BCS 1897(PC)										
  execution.go:490	0x100213650		8b161196		ADD R22<<4, R12, R22									
  execution.go:490	0x100213654		eb1302ff		CMP R19, R23										
  execution.go:490	0x100213658		5400ec62		BCS 1891(PC)										
  execution.go:490	0x10021365c		f94002d8		MOVD (R22), R24										
  execution.go:490	0x100213660		8b171197		ADD R23<<4, R12, R23									
  execution.go:490	0x100213664		f94002f7		MOVD (R23), R23										
  integer.go:13		0x100213668		6b1802ff		CMPW R24, R23										
  integer.go:13		0x10021366c		9a9f97f6		CSET HI, R22										
  execution.go:490	0x100213670		14000263		JMP 611(PC)										
  execution.go:492	0x100213674		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:492	0x100213678		eb1302df		CMP R19, R22										
  execution.go:492	0x10021367c		5400eae2		BCS 1879(PC)										
  execution.go:492	0x100213680		8b161196		ADD R22<<4, R12, R22									
  execution.go:492	0x100213684		eb1302ff		CMP R19, R23										
  execution.go:492	0x100213688		5400ea22		BCS 1873(PC)										
  execution.go:492	0x10021368c		f94002d8		MOVD (R22), R24										
  execution.go:492	0x100213690		8b171197		ADD R23<<4, R12, R23									
  execution.go:492	0x100213694		f94002f7		MOVD (R23), R23										
  integer.go:14		0x100213698		6b1802ff		CMPW R24, R23										
  integer.go:14		0x10021369c		9a9fa7f6		CSET LT, R22										
  execution.go:492	0x1002136a0		14000257		JMP 599(PC)										
  execution.go:494	0x1002136a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:494	0x1002136a8		eb1302df		CMP R19, R22										
  execution.go:494	0x1002136ac		5400e8a2		BCS 1861(PC)										
  execution.go:494	0x1002136b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:494	0x1002136b4		eb1302ff		CMP R19, R23										
  execution.go:494	0x1002136b8		5400e7e2		BCS 1855(PC)										
  execution.go:494	0x1002136bc		f94002d8		MOVD (R22), R24										
  execution.go:494	0x1002136c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:494	0x1002136c4		f94002f7		MOVD (R23), R23										
  integer.go:15		0x1002136c8		6b1802ff		CMPW R24, R23										
  integer.go:15		0x1002136cc		9a9f27f6		CSET LO, R22										
  execution.go:494	0x1002136d0		1400024b		JMP 587(PC)										
  execution.go:496	0x1002136d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:496	0x1002136d8		eb1302df		CMP R19, R22										
  execution.go:496	0x1002136dc		5400e662		BCS 1843(PC)										
  execution.go:496	0x1002136e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:496	0x1002136e4		eb1302ff		CMP R19, R23										
  execution.go:496	0x1002136e8		5400e5a2		BCS 1837(PC)										
  execution.go:496	0x1002136ec		f94002d8		MOVD (R22), R24										
  execution.go:496	0x1002136f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:496	0x1002136f4		f94002f7		MOVD (R23), R23										
  integer.go:16		0x1002136f8		6b1802ff		CMPW R24, R23										
  integer.go:16		0x1002136fc		9a9fb7f6		CSET GE, R22										
  execution.go:496	0x100213700		1400023f		JMP 575(PC)										
  execution.go:498	0x100213704		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:498	0x100213708		eb1302df		CMP R19, R22										
  execution.go:498	0x10021370c		5400e422		BCS 1825(PC)										
  execution.go:498	0x100213710		8b161196		ADD R22<<4, R12, R22									
  execution.go:498	0x100213714		eb1302ff		CMP R19, R23										
  execution.go:498	0x100213718		5400e362		BCS 1819(PC)										
  execution.go:498	0x10021371c		f94002d8		MOVD (R22), R24										
  execution.go:498	0x100213720		8b171197		ADD R23<<4, R12, R23									
  execution.go:498	0x100213724		f94002f7		MOVD (R23), R23										
  integer.go:17		0x100213728		6b1802ff		CMPW R24, R23										
  integer.go:17		0x10021372c		9a9f37f6		CSET HS, R22										
  execution.go:498	0x100213730		14000233		JMP 563(PC)										
  execution.go:500	0x100213734		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:500	0x100213738		eb1302df		CMP R19, R22										
  execution.go:500	0x10021373c		5400e1e2		BCS 1807(PC)										
  execution.go:500	0x100213740		8b161196		ADD R22<<4, R12, R22									
  execution.go:500	0x100213744		eb1302ff		CMP R19, R23										
  execution.go:500	0x100213748		5400e122		BCS 1801(PC)										
  execution.go:500	0x10021374c		f94002d8		MOVD (R22), R24										
  execution.go:500	0x100213750		8b171197		ADD R23<<4, R12, R23									
  execution.go:500	0x100213754		f94002f7		MOVD (R23), R23										
  integer.go:18		0x100213758		6b1802ff		CMPW R24, R23										
  integer.go:18		0x10021375c		9a9fc7f6		CSET LE, R22										
  execution.go:500	0x100213760		14000227		JMP 551(PC)										
  execution.go:502	0x100213764		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:502	0x100213768		eb1302df		CMP R19, R22										
  execution.go:502	0x10021376c		5400dfa2		BCS 1789(PC)										
  execution.go:502	0x100213770		8b161196		ADD R22<<4, R12, R22									
  execution.go:502	0x100213774		eb1302ff		CMP R19, R23										
  execution.go:502	0x100213778		5400dee2		BCS 1783(PC)										
  execution.go:502	0x10021377c		f94002d8		MOVD (R22), R24										
  execution.go:502	0x100213780		8b171197		ADD R23<<4, R12, R23									
  execution.go:502	0x100213784		f94002f7		MOVD (R23), R23										
  integer.go:19		0x100213788		6b1802ff		CMPW R24, R23										
  integer.go:19		0x10021378c		9a9f87f6		CSET LS, R22										
  execution.go:502	0x100213790		1400021b		JMP 539(PC)										
  execution.go:504	0x100213794		b9400e96		MOVWU 12(R20), R22									
  execution.go:504	0x100213798		eb1302df		CMP R19, R22										
  execution.go:504	0x10021379c		5400dd62		BCS 1771(PC)										
  execution.go:504	0x1002137a0		8b161197		ADD R22<<4, R12, R23									
  execution.go:504	0x1002137a4		f94002f7		MOVD (R23), R23										
  integer.go:20		0x1002137a8		f10002ff		CMP $0, R23										
  integer.go:20		0x1002137ac		9a9f17f6		CSET EQ, R22										
  execution.go:504	0x1002137b0		14000213		JMP 531(PC)										
  execution.go:506	0x1002137b4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:506	0x1002137b8		eb1302df		CMP R19, R22										
  execution.go:506	0x1002137bc		5400dc02		BCS 1760(PC)										
  execution.go:506	0x1002137c0		8b161196		ADD R22<<4, R12, R22									
  execution.go:506	0x1002137c4		eb1302ff		CMP R19, R23										
  execution.go:506	0x1002137c8		5400db42		BCS 1754(PC)										
  execution.go:506	0x1002137cc		f94002d8		MOVD (R22), R24										
  execution.go:506	0x1002137d0		8b171197		ADD R23<<4, R12, R23									
  execution.go:506	0x1002137d4		f94002f7		MOVD (R23), R23										
  integer.go:21		0x1002137d8		eb1802ff		CMP R24, R23										
  integer.go:21		0x1002137dc		9a9f17f6		CSET EQ, R22										
  execution.go:506	0x1002137e0		14000207		JMP 519(PC)										
  execution.go:508	0x1002137e4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:508	0x1002137e8		eb1302df		CMP R19, R22										
  execution.go:508	0x1002137ec		5400d9c2		BCS 1742(PC)										
  execution.go:508	0x1002137f0		8b161196		ADD R22<<4, R12, R22									
  execution.go:508	0x1002137f4		eb1302ff		CMP R19, R23										
  execution.go:508	0x1002137f8		5400d902		BCS 1736(PC)										
  execution.go:508	0x1002137fc		f94002d8		MOVD (R22), R24										
  execution.go:508	0x100213800		8b171197		ADD R23<<4, R12, R23									
  execution.go:508	0x100213804		f94002f7		MOVD (R23), R23										
  integer.go:22		0x100213808		eb1802ff		CMP R24, R23										
  integer.go:22		0x10021380c		9a9f07f6		CSET NE, R22										
  execution.go:508	0x100213810		140001fb		JMP 507(PC)										
  execution.go:510	0x100213814		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:510	0x100213818		eb1302df		CMP R19, R22										
  execution.go:510	0x10021381c		5400d782		BCS 1724(PC)										
  execution.go:510	0x100213820		8b161196		ADD R22<<4, R12, R22									
  execution.go:510	0x100213824		eb1302ff		CMP R19, R23										
  execution.go:510	0x100213828		5400d6c2		BCS 1718(PC)										
  execution.go:510	0x10021382c		f94002d8		MOVD (R22), R24										
  execution.go:510	0x100213830		8b171197		ADD R23<<4, R12, R23									
  execution.go:510	0x100213834		f94002f7		MOVD (R23), R23										
  integer.go:23		0x100213838		eb1802ff		CMP R24, R23										
  integer.go:23		0x10021383c		9a9fd7f6		CSET GT, R22										
  execution.go:510	0x100213840		140001ef		JMP 495(PC)										
  execution.go:512	0x100213844		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:512	0x100213848		eb1302df		CMP R19, R22										
  execution.go:512	0x10021384c		5400d542		BCS 1706(PC)										
  execution.go:512	0x100213850		8b161196		ADD R22<<4, R12, R22									
  execution.go:512	0x100213854		eb1302ff		CMP R19, R23										
  execution.go:512	0x100213858		5400d482		BCS 1700(PC)										
  execution.go:512	0x10021385c		f94002d8		MOVD (R22), R24										
  execution.go:512	0x100213860		8b171197		ADD R23<<4, R12, R23									
  execution.go:512	0x100213864		f94002f7		MOVD (R23), R23										
  integer.go:24		0x100213868		eb1802ff		CMP R24, R23										
  integer.go:24		0x10021386c		9a9f97f6		CSET HI, R22										
  execution.go:512	0x100213870		140001e3		JMP 483(PC)										
  execution.go:514	0x100213874		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:514	0x100213878		eb1302df		CMP R19, R22										
  execution.go:514	0x10021387c		5400d302		BCS 1688(PC)										
  execution.go:514	0x100213880		8b161196		ADD R22<<4, R12, R22									
  execution.go:514	0x100213884		eb1302ff		CMP R19, R23										
  execution.go:514	0x100213888		5400d242		BCS 1682(PC)										
  execution.go:514	0x10021388c		f94002d8		MOVD (R22), R24										
  execution.go:514	0x100213890		8b171197		ADD R23<<4, R12, R23									
  execution.go:514	0x100213894		f94002f7		MOVD (R23), R23										
  integer.go:25		0x100213898		eb1802ff		CMP R24, R23										
  integer.go:25		0x10021389c		9a9fa7f6		CSET LT, R22										
  execution.go:514	0x1002138a0		140001d7		JMP 471(PC)										
  execution.go:516	0x1002138a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:516	0x1002138a8		eb1302df		CMP R19, R22										
  execution.go:516	0x1002138ac		5400d0c2		BCS 1670(PC)										
  execution.go:516	0x1002138b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:516	0x1002138b4		eb1302ff		CMP R19, R23										
  execution.go:516	0x1002138b8		5400d002		BCS 1664(PC)										
  execution.go:516	0x1002138bc		f94002d8		MOVD (R22), R24										
  execution.go:516	0x1002138c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:516	0x1002138c4		f94002f7		MOVD (R23), R23										
  integer.go:26		0x1002138c8		eb1802ff		CMP R24, R23										
  integer.go:26		0x1002138cc		9a9f27f6		CSET LO, R22										
  execution.go:516	0x1002138d0		140001cb		JMP 459(PC)										
  execution.go:518	0x1002138d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:518	0x1002138d8		eb1302df		CMP R19, R22										
  execution.go:518	0x1002138dc		5400ce82		BCS 1652(PC)										
  execution.go:518	0x1002138e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:518	0x1002138e4		eb1302ff		CMP R19, R23										
  execution.go:518	0x1002138e8		5400cdc2		BCS 1646(PC)										
  execution.go:518	0x1002138ec		f94002d8		MOVD (R22), R24										
  execution.go:518	0x1002138f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:518	0x1002138f4		f94002f7		MOVD (R23), R23										
  integer.go:27		0x1002138f8		eb1802ff		CMP R24, R23										
  integer.go:27		0x1002138fc		9a9fb7f6		CSET GE, R22										
  execution.go:518	0x100213900		140001bf		JMP 447(PC)										
  execution.go:520	0x100213904		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:520	0x100213908		eb1302df		CMP R19, R22										
  execution.go:520	0x10021390c		5400cc42		BCS 1634(PC)										
  execution.go:520	0x100213910		8b161196		ADD R22<<4, R12, R22									
  execution.go:520	0x100213914		eb1302ff		CMP R19, R23										
  execution.go:520	0x100213918		5400cb82		BCS 1628(PC)										
  execution.go:520	0x10021391c		f94002d8		MOVD (R22), R24										
  execution.go:520	0x100213920		8b171197		ADD R23<<4, R12, R23									
  execution.go:520	0x100213924		f94002f7		MOVD (R23), R23										
  integer.go:28		0x100213928		eb1802ff		CMP R24, R23										
  integer.go:28		0x10021392c		9a9f37f6		CSET HS, R22										
  execution.go:520	0x100213930		140001b3		JMP 435(PC)										
  execution.go:522	0x100213934		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:522	0x100213938		eb1302df		CMP R19, R22										
  execution.go:522	0x10021393c		5400ca02		BCS 1616(PC)										
  execution.go:522	0x100213940		8b161196		ADD R22<<4, R12, R22									
  execution.go:522	0x100213944		eb1302ff		CMP R19, R23										
  execution.go:522	0x100213948		5400c942		BCS 1610(PC)										
  execution.go:522	0x10021394c		f94002d8		MOVD (R22), R24										
  execution.go:522	0x100213950		8b171197		ADD R23<<4, R12, R23									
  execution.go:522	0x100213954		f94002f7		MOVD (R23), R23										
  integer.go:29		0x100213958		eb1802ff		CMP R24, R23										
  integer.go:29		0x10021395c		9a9fc7f6		CSET LE, R22										
  execution.go:522	0x100213960		140001a7		JMP 423(PC)										
  execution.go:524	0x100213964		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:524	0x100213968		eb1302df		CMP R19, R22										
  execution.go:524	0x10021396c		5400c7c2		BCS 1598(PC)										
  execution.go:524	0x100213970		8b161196		ADD R22<<4, R12, R22									
  execution.go:524	0x100213974		eb1302ff		CMP R19, R23										
  execution.go:524	0x100213978		5400c702		BCS 1592(PC)										
  execution.go:524	0x10021397c		f94002d8		MOVD (R22), R24										
  execution.go:524	0x100213980		8b171197		ADD R23<<4, R12, R23									
  execution.go:524	0x100213984		f94002f7		MOVD (R23), R23										
  integer.go:30		0x100213988		eb1802ff		CMP R24, R23										
  integer.go:30		0x10021398c		9a9f87f6		CSET LS, R22										
  execution.go:524	0x100213990		1400019b		JMP 411(PC)										
  execution.go:526	0x100213994		b9400e96		MOVWU 12(R20), R22									
  execution.go:526	0x100213998		eb1302df		CMP R19, R22										
  execution.go:526	0x10021399c		5400c582		BCS 1580(PC)										
  execution.go:526	0x1002139a0		8b161197		ADD R22<<4, R12, R23									
  execution.go:526	0x1002139a4		f94002f7		MOVD (R23), R23										
  integer.go:31		0x1002139a8		d503201f		NOOP											
  bits.go:34		0x1002139ac		5ac012f6		CLZW R23, R22										
  execution.go:526	0x1002139b0		14000193		JMP 403(PC)										
  execution.go:528	0x1002139b4		b9400e96		MOVWU 12(R20), R22									
  execution.go:528	0x1002139b8		eb1302df		CMP R19, R22										
  execution.go:528	0x1002139bc		5400c422		BCS 1569(PC)										
  execution.go:528	0x1002139c0		8b161197		ADD R22<<4, R12, R23									
  execution.go:528	0x1002139c4		f94002f7		MOVD (R23), R23										
  integer.go:32		0x1002139c8		5ac002f7		RBITW R23, R23										
  integer.go:32		0x1002139cc		5ac012f6		CLZW R23, R22										
  execution.go:528	0x1002139d0		1400018b		JMP 395(PC)										
  execution.go:538	0x1002139d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:538	0x1002139d8		eb1302df		CMP R19, R22										
  execution.go:538	0x1002139dc		5400c2c2		BCS 1558(PC)										
  execution.go:538	0x1002139e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:538	0x1002139e4		eb1302ff		CMP R19, R23										
  execution.go:538	0x1002139e8		5400c202		BCS 1552(PC)										
  execution.go:538	0x1002139ec		f94002d8		MOVD (R22), R24										
  execution.go:538	0x1002139f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:538	0x1002139f4		f94002f7		MOVD (R23), R23										
  integer.go:34		0x1002139f8		8b170317		ADD R23, R24, R23									
  integer.go:34		0x1002139fc		2a1703f6		MOVW R23, R22										
  execution.go:538	0x100213a00		1400017f		JMP 383(PC)										
  execution.go:540	0x100213a04		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:540	0x100213a08		eb1302df		CMP R19, R22										
  execution.go:540	0x100213a0c		5400c082		BCS 1540(PC)										
  execution.go:540	0x100213a10		8b161196		ADD R22<<4, R12, R22									
  execution.go:540	0x100213a14		eb1302ff		CMP R19, R23										
  execution.go:540	0x100213a18		5400bfc2		BCS 1534(PC)										
  execution.go:540	0x100213a1c		f94002d8		MOVD (R22), R24										
  execution.go:540	0x100213a20		8b171197		ADD R23<<4, R12, R23									
  execution.go:540	0x100213a24		f94002f7		MOVD (R23), R23										
  integer.go:35		0x100213a28		cb170317		SUB R23, R24, R23									
  integer.go:35		0x100213a2c		2a1703f6		MOVW R23, R22										
  execution.go:540	0x100213a30		14000173		JMP 371(PC)										
  execution.go:542	0x100213a34		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:542	0x100213a38		eb1302df		CMP R19, R22										
  execution.go:542	0x100213a3c		5400be42		BCS 1522(PC)										
  execution.go:542	0x100213a40		8b161196		ADD R22<<4, R12, R22									
  execution.go:542	0x100213a44		eb1302ff		CMP R19, R23										
  execution.go:542	0x100213a48		5400bd82		BCS 1516(PC)										
  execution.go:542	0x100213a4c		f94002d8		MOVD (R22), R24										
  execution.go:542	0x100213a50		8b171197		ADD R23<<4, R12, R23									
  execution.go:542	0x100213a54		f94002f7		MOVD (R23), R23										
  integer.go:36		0x100213a58		1b177f16		MULW R23, R24, R22									
  execution.go:542	0x100213a5c		14000168		JMP 360(PC)										
  execution.go:544	0x100213a60		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:544	0x100213a64		eb1302df		CMP R19, R22										
  execution.go:544	0x100213a68		5400bc22		BCS 1505(PC)										
  execution.go:544	0x100213a6c		8b161196		ADD R22<<4, R12, R22									
  execution.go:544	0x100213a70		eb1302ff		CMP R19, R23										
  execution.go:544	0x100213a74		5400bb62		BCS 1499(PC)										
  execution.go:544	0x100213a78		f94002d8		MOVD (R22), R24										
  execution.go:544	0x100213a7c		8b171197		ADD R23<<4, R12, R23									
  execution.go:544	0x100213a80		f94002f7		MOVD (R23), R23										
  integer.go:37		0x100213a84		8a170317		AND R23, R24, R23									
  integer.go:37		0x100213a88		2a1703f6		MOVW R23, R22										
  execution.go:544	0x100213a8c		1400015c		JMP 348(PC)										
  execution.go:546	0x100213a90		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:546	0x100213a94		eb1302df		CMP R19, R22										
  execution.go:546	0x100213a98		5400b9e2		BCS 1487(PC)										
  execution.go:546	0x100213a9c		8b161196		ADD R22<<4, R12, R22									
  execution.go:546	0x100213aa0		eb1302ff		CMP R19, R23										
  execution.go:546	0x100213aa4		5400b922		BCS 1481(PC)										
  execution.go:546	0x100213aa8		f94002d8		MOVD (R22), R24										
  execution.go:546	0x100213aac		8b171197		ADD R23<<4, R12, R23									
  execution.go:546	0x100213ab0		f94002f7		MOVD (R23), R23										
  integer.go:38		0x100213ab4		aa170317		ORR R23, R24, R23									
  integer.go:38		0x100213ab8		2a1703f6		MOVW R23, R22										
  execution.go:546	0x100213abc		14000150		JMP 336(PC)										
  execution.go:548	0x100213ac0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:548	0x100213ac4		eb1302df		CMP R19, R22										
  execution.go:548	0x100213ac8		5400b7a2		BCS 1469(PC)										
  execution.go:548	0x100213acc		8b161196		ADD R22<<4, R12, R22									
  execution.go:548	0x100213ad0		eb1302ff		CMP R19, R23										
  execution.go:548	0x100213ad4		5400b6e2		BCS 1463(PC)										
  execution.go:548	0x100213ad8		f94002d8		MOVD (R22), R24										
  execution.go:548	0x100213adc		8b171197		ADD R23<<4, R12, R23									
  execution.go:548	0x100213ae0		f94002f7		MOVD (R23), R23										
  integer.go:39		0x100213ae4		ca170317		EOR R23, R24, R23									
  integer.go:39		0x100213ae8		2a1703f6		MOVW R23, R22										
  execution.go:548	0x100213aec		14000144		JMP 324(PC)										
  execution.go:550	0x100213af0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:550	0x100213af4		eb1302df		CMP R19, R22										
  execution.go:550	0x100213af8		5400b562		BCS 1451(PC)										
  execution.go:550	0x100213afc		8b161196		ADD R22<<4, R12, R22									
  execution.go:550	0x100213b00		eb1302ff		CMP R19, R23										
  execution.go:550	0x100213b04		5400b4a2		BCS 1445(PC)										
  execution.go:550	0x100213b08		f94002d8		MOVD (R22), R24										
  execution.go:550	0x100213b0c		8b171197		ADD R23<<4, R12, R23									
  execution.go:550	0x100213b10		f94002f7		MOVD (R23), R23										
  integer.go:40		0x100213b14		924012f7		AND $31, R23, R23									
  integer.go:40		0x100213b18		9ad72317		LSL R23, R24, R23									
  integer.go:40		0x100213b1c		2a1703f6		MOVW R23, R22										
  execution.go:550	0x100213b20		14000137		JMP 311(PC)										
  execution.go:552	0x100213b24		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:552	0x100213b28		eb1302df		CMP R19, R22										
  execution.go:552	0x100213b2c		5400b302		BCS 1432(PC)										
  execution.go:552	0x100213b30		8b161196		ADD R22<<4, R12, R22									
  execution.go:552	0x100213b34		eb1302ff		CMP R19, R23										
  execution.go:552	0x100213b38		5400b242		BCS 1426(PC)										
  execution.go:552	0x100213b3c		f94002d8		MOVD (R22), R24										
  execution.go:552	0x100213b40		8b171197		ADD R23<<4, R12, R23									
  execution.go:552	0x100213b44		f94002f7		MOVD (R23), R23										
  integer.go:41		0x100213b48		93407f18		SXTW R24, R24										
  integer.go:41		0x100213b4c		924012f7		AND $31, R23, R23									
  integer.go:41		0x100213b50		9ad72b17		ASR R23, R24, R23									
  integer.go:41		0x100213b54		2a1703f6		MOVW R23, R22										
  execution.go:552	0x100213b58		14000129		JMP 297(PC)										
  execution.go:554	0x100213b5c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:554	0x100213b60		eb1302df		CMP R19, R22										
  execution.go:554	0x100213b64		5400b082		BCS 1412(PC)										
  execution.go:554	0x100213b68		8b161196		ADD R22<<4, R12, R22									
  execution.go:554	0x100213b6c		eb1302ff		CMP R19, R23										
  execution.go:554	0x100213b70		5400afc2		BCS 1406(PC)										
  execution.go:554	0x100213b74		f94002d8		MOVD (R22), R24										
  execution.go:554	0x100213b78		8b171197		ADD R23<<4, R12, R23									
  execution.go:554	0x100213b7c		f94002f7		MOVD (R23), R23										
  integer.go:42		0x100213b80		2a1803f8		MOVW R24, R24										
  integer.go:42		0x100213b84		924012f7		AND $31, R23, R23									
  integer.go:42		0x100213b88		9ad72717		LSR R23, R24, R23									
  integer.go:42		0x100213b8c		2a1703f6		MOVW R23, R22										
  execution.go:554	0x100213b90		1400011b		JMP 283(PC)										
  execution.go:556	0x100213b94		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:556	0x100213b98		eb1302df		CMP R19, R22										
  execution.go:556	0x100213b9c		5400ae02		BCS 1392(PC)										
  execution.go:556	0x100213ba0		8b161196		ADD R22<<4, R12, R22									
  execution.go:556	0x100213ba4		eb1302ff		CMP R19, R23										
  execution.go:556	0x100213ba8		5400ad42		BCS 1386(PC)										
  execution.go:556	0x100213bac		f94002d8		MOVD (R22), R24										
  execution.go:556	0x100213bb0		8b171197		ADD R23<<4, R12, R23									
  execution.go:556	0x100213bb4		f94002f7		MOVD (R23), R23										
  integer.go:43		0x100213bb8		cb1703f7		NEG R23, R23										
  integer.go:43		0x100213bbc		1ad72f16		RORW R23, R24, R22									
  execution.go:556	0x100213bc0		1400010f		JMP 271(PC)										
  execution.go:558	0x100213bc4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:558	0x100213bc8		eb1302df		CMP R19, R22										
  execution.go:558	0x100213bcc		5400abc2		BCS 1374(PC)										
  execution.go:558	0x100213bd0		8b161196		ADD R22<<4, R12, R22									
  execution.go:558	0x100213bd4		eb1302ff		CMP R19, R23										
  execution.go:558	0x100213bd8		5400ab02		BCS 1368(PC)										
  execution.go:558	0x100213bdc		f94002d8		MOVD (R22), R24										
  execution.go:558	0x100213be0		8b171197		ADD R23<<4, R12, R23									
  execution.go:558	0x100213be4		f94002f7		MOVD (R23), R23										
  integer.go:44		0x100213be8		1ad72f16		RORW R23, R24, R22									
  execution.go:558	0x100213bec		14000104		JMP 260(PC)										
  execution.go:560	0x100213bf0		b9400e96		MOVWU 12(R20), R22									
  execution.go:560	0x100213bf4		eb1302df		CMP R19, R22										
  execution.go:560	0x100213bf8		5400a9a2		BCS 1357(PC)										
  execution.go:560	0x100213bfc		8b161197		ADD R22<<4, R12, R23									
  execution.go:560	0x100213c00		f94002f7		MOVD (R23), R23										
  integer.go:45		0x100213c04		d503201f		NOOP											
  bits.go:37		0x100213c08		dac012f6		CLZ R23, R22										
  execution.go:560	0x100213c0c		140000fc		JMP 252(PC)										
  execution.go:562	0x100213c10		b9400e96		MOVWU 12(R20), R22									
  execution.go:562	0x100213c14		eb1302df		CMP R19, R22										
  execution.go:562	0x100213c18		5400a842		BCS 1346(PC)										
  execution.go:562	0x100213c1c		8b161197		ADD R22<<4, R12, R23									
  execution.go:562	0x100213c20		f94002f7		MOVD (R23), R23										
  integer.go:46		0x100213c24		dac002f7		RBIT R23, R23										
  integer.go:46		0x100213c28		dac012f6		CLZ R23, R22										
  execution.go:562	0x100213c2c		140000f4		JMP 244(PC)										
  execution.go:532	0x100213c30		b9400e96		MOVWU 12(R20), R22									
  execution.go:532	0x100213c34		eb1302df		CMP R19, R22										
  execution.go:532	0x100213c38		5400a6e2		BCS 1335(PC)										
  execution.go:532	0x100213c3c		8b161197		ADD R22<<4, R12, R23									
  execution.go:532	0x100213c40		f94002f7		MOVD (R23), R23										
  execution.go:534	0x100213c44		2a1703f8		MOVW R23, R24										
  execution.go:536	0x100213c48		d503201f		NOOP											
  execution.go:533	0x100213c4c		7101a43f		CMPW $105, R1										
  execution.go:534	0x100213c50		9a970317		CSEL EQ, R24, R23, R23									
  integer.go:47		0x100213c54		9e6702e0		FMOVD R23, F0										
  integer.go:47		0x100213c58		0e205800		VCNT V0.B8, V0.B8									
  integer.go:47		0x100213c5c		2e303800		VUADDLV V0.B8, V0									
  integer.go:47		0x100213c60		9e660016		FMOVD F0, R22										
  execution.go:533	0x100213c64		140000e6		JMP 230(PC)										
  execution.go:564	0x100213c68		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:564	0x100213c6c		eb1302df		CMP R19, R22										
  execution.go:564	0x100213c70		5400a4c2		BCS 1318(PC)										
  execution.go:564	0x100213c74		8b161196		ADD R22<<4, R12, R22									
  execution.go:564	0x100213c78		eb1302ff		CMP R19, R23										
  execution.go:564	0x100213c7c		5400a402		BCS 1312(PC)										
  execution.go:564	0x100213c80		f94002d8		MOVD (R22), R24										
  execution.go:564	0x100213c84		8b171197		ADD R23<<4, R12, R23									
  execution.go:564	0x100213c88		f94002f7		MOVD (R23), R23										
  integer.go:48		0x100213c8c		8b170316		ADD R23, R24, R22									
  execution.go:564	0x100213c90		140000db		JMP 219(PC)										
  execution.go:566	0x100213c94		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:566	0x100213c98		eb1302df		CMP R19, R22										
  execution.go:566	0x100213c9c		5400a2a2		BCS 1301(PC)										
  execution.go:566	0x100213ca0		8b161196		ADD R22<<4, R12, R22									
  execution.go:566	0x100213ca4		eb1302ff		CMP R19, R23										
  execution.go:566	0x100213ca8		5400a1e2		BCS 1295(PC)										
  execution.go:566	0x100213cac		f94002d8		MOVD (R22), R24										
  execution.go:566	0x100213cb0		8b171197		ADD R23<<4, R12, R23									
  execution.go:566	0x100213cb4		f94002f7		MOVD (R23), R23										
  integer.go:49		0x100213cb8		cb170316		SUB R23, R24, R22									
  execution.go:566	0x100213cbc		140000d0		JMP 208(PC)										
  execution.go:568	0x100213cc0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:568	0x100213cc4		eb1302df		CMP R19, R22										
  execution.go:568	0x100213cc8		5400a082		BCS 1284(PC)										
  execution.go:568	0x100213ccc		8b161196		ADD R22<<4, R12, R22									
  execution.go:568	0x100213cd0		eb1302ff		CMP R19, R23										
  execution.go:568	0x100213cd4		54009fc2		BCS 1278(PC)										
  execution.go:568	0x100213cd8		f94002d8		MOVD (R22), R24										
  execution.go:568	0x100213cdc		8b171197		ADD R23<<4, R12, R23									
  execution.go:568	0x100213ce0		f94002f7		MOVD (R23), R23										
  integer.go:50		0x100213ce4		9b187ef6		MUL R24, R23, R22									
  execution.go:568	0x100213ce8		140000c5		JMP 197(PC)										
  execution.go:570	0x100213cec		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:570	0x100213cf0		eb1302df		CMP R19, R22										
  execution.go:570	0x100213cf4		54009e62		BCS 1267(PC)										
  execution.go:570	0x100213cf8		8b161196		ADD R22<<4, R12, R22									
  execution.go:570	0x100213cfc		eb1302ff		CMP R19, R23										
  execution.go:570	0x100213d00		54009da2		BCS 1261(PC)										
  execution.go:570	0x100213d04		f94002d8		MOVD (R22), R24										
  execution.go:570	0x100213d08		8b171197		ADD R23<<4, R12, R23									
  execution.go:570	0x100213d0c		f94002f7		MOVD (R23), R23										
  integer.go:51		0x100213d10		8a170316		AND R23, R24, R22									
  execution.go:570	0x100213d14		140000ba		JMP 186(PC)										
  execution.go:572	0x100213d18		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:572	0x100213d1c		eb1302df		CMP R19, R22										
  execution.go:572	0x100213d20		54009c42		BCS 1250(PC)										
  execution.go:572	0x100213d24		8b161196		ADD R22<<4, R12, R22									
  execution.go:572	0x100213d28		eb1302ff		CMP R19, R23										
  execution.go:572	0x100213d2c		54009b82		BCS 1244(PC)										
  execution.go:572	0x100213d30		f94002d8		MOVD (R22), R24										
  execution.go:572	0x100213d34		8b171197		ADD R23<<4, R12, R23									
  execution.go:572	0x100213d38		f94002f7		MOVD (R23), R23										
  integer.go:52		0x100213d3c		aa170316		ORR R23, R24, R22									
  execution.go:572	0x100213d40		140000af		JMP 175(PC)										
  execution.go:574	0x100213d44		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:574	0x100213d48		eb1302df		CMP R19, R22										
  execution.go:574	0x100213d4c		54009a22		BCS 1233(PC)										
  execution.go:574	0x100213d50		8b161196		ADD R22<<4, R12, R22									
  execution.go:574	0x100213d54		eb1302ff		CMP R19, R23										
  execution.go:574	0x100213d58		54009962		BCS 1227(PC)										
  execution.go:574	0x100213d5c		f94002d8		MOVD (R22), R24										
  execution.go:574	0x100213d60		8b171197		ADD R23<<4, R12, R23									
  execution.go:574	0x100213d64		f94002f7		MOVD (R23), R23										
  integer.go:53		0x100213d68		ca170316		EOR R23, R24, R22									
  execution.go:574	0x100213d6c		140000a4		JMP 164(PC)										
  execution.go:576	0x100213d70		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:576	0x100213d74		eb1302df		CMP R19, R22										
  execution.go:576	0x100213d78		54009802		BCS 1216(PC)										
  execution.go:576	0x100213d7c		8b161196		ADD R22<<4, R12, R22									
  execution.go:576	0x100213d80		eb1302ff		CMP R19, R23										
  execution.go:576	0x100213d84		54009742		BCS 1210(PC)										
  execution.go:576	0x100213d88		f94002d8		MOVD (R22), R24										
  execution.go:576	0x100213d8c		8b171197		ADD R23<<4, R12, R23									
  execution.go:576	0x100213d90		f94002f7		MOVD (R23), R23										
  integer.go:54		0x100213d94		9ad72316		LSL R23, R24, R22									
  execution.go:576	0x100213d98		14000099		JMP 153(PC)										
  execution.go:578	0x100213d9c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:578	0x100213da0		eb1302df		CMP R19, R22										
  execution.go:578	0x100213da4		540095e2		BCS 1199(PC)										
  execution.go:578	0x100213da8		8b161196		ADD R22<<4, R12, R22									
  execution.go:578	0x100213dac		eb1302ff		CMP R19, R23										
  execution.go:578	0x100213db0		54009522		BCS 1193(PC)										
  execution.go:578	0x100213db4		f94002d8		MOVD (R22), R24										
  execution.go:578	0x100213db8		8b171197		ADD R23<<4, R12, R23									
  execution.go:578	0x100213dbc		f94002f7		MOVD (R23), R23										
  integer.go:55		0x100213dc0		9ad72b16		ASR R23, R24, R22									
  execution.go:578	0x100213dc4		1400008e		JMP 142(PC)										
  execution.go:580	0x100213dc8		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:580	0x100213dcc		eb1302df		CMP R19, R22										
  execution.go:580	0x100213dd0		540093c2		BCS 1182(PC)										
  execution.go:580	0x100213dd4		8b161196		ADD R22<<4, R12, R22									
  execution.go:580	0x100213dd8		eb1302ff		CMP R19, R23										
  execution.go:580	0x100213ddc		54009302		BCS 1176(PC)										
  execution.go:580	0x100213de0		f94002d8		MOVD (R22), R24										
  execution.go:580	0x100213de4		8b171197		ADD R23<<4, R12, R23									
  execution.go:580	0x100213de8		f94002f7		MOVD (R23), R23										
  integer.go:56		0x100213dec		9ad72716		LSR R23, R24, R22									
  execution.go:580	0x100213df0		14000083		JMP 131(PC)										
  execution.go:582	0x100213df4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:582	0x100213df8		eb1302df		CMP R19, R22										
  execution.go:582	0x100213dfc		540091a2		BCS 1165(PC)										
  execution.go:582	0x100213e00		8b161196		ADD R22<<4, R12, R22									
  execution.go:582	0x100213e04		eb1302ff		CMP R19, R23										
  execution.go:582	0x100213e08		540090e2		BCS 1159(PC)										
  execution.go:582	0x100213e0c		f94002d8		MOVD (R22), R24										
  execution.go:582	0x100213e10		8b171197		ADD R23<<4, R12, R23									
  execution.go:582	0x100213e14		f94002f7		MOVD (R23), R23										
  integer.go:57		0x100213e18		cb1703f7		NEG R23, R23										
  integer.go:57		0x100213e1c		9ad72f16		ROR R23, R24, R22									
  execution.go:582	0x100213e20		14000077		JMP 119(PC)										
  execution.go:584	0x100213e24		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:584	0x100213e28		eb1302df		CMP R19, R22										
  execution.go:584	0x100213e2c		54008f62		BCS 1147(PC)										
  execution.go:584	0x100213e30		8b161196		ADD R22<<4, R12, R22									
  execution.go:584	0x100213e34		eb1302ff		CMP R19, R23										
  execution.go:584	0x100213e38		54008ea2		BCS 1141(PC)										
  execution.go:584	0x100213e3c		f94002d8		MOVD (R22), R24										
  execution.go:584	0x100213e40		8b171197		ADD R23<<4, R12, R23									
  execution.go:584	0x100213e44		f94002f7		MOVD (R23), R23										
  integer.go:58		0x100213e48		9ad72f16		ROR R23, R24, R22									
  execution.go:584	0x100213e4c		1400006c		JMP 108(PC)										
  execution.go:586	0x100213e50		b9400e96		MOVWU 12(R20), R22									
  execution.go:586	0x100213e54		eb1302df		CMP R19, R22										
  execution.go:586	0x100213e58		54008d42		BCS 1130(PC)										
  execution.go:586	0x100213e5c		8b161197		ADD R22<<4, R12, R23									
  execution.go:586	0x100213e60		f94002f7		MOVD (R23), R23										
  integer.go:59		0x100213e64		2a1703f6		MOVW R23, R22										
  execution.go:586	0x100213e68		14000065		JMP 101(PC)										
  execution.go:588	0x100213e6c		b9400e96		MOVWU 12(R20), R22									
  execution.go:588	0x100213e70		eb1302df		CMP R19, R22										
  execution.go:588	0x100213e74		54008c02		BCS 1120(PC)										
  execution.go:588	0x100213e78		8b161197		ADD R22<<4, R12, R23									
  execution.go:588	0x100213e7c		f94002f7		MOVD (R23), R23										
  integer.go:60		0x100213e80		93407ef6		SXTW R23, R22										
  execution.go:588	0x100213e84		1400005e		JMP 94(PC)										
  execution.go:590	0x100213e88		b9400e96		MOVWU 12(R20), R22									
  execution.go:590	0x100213e8c		eb1302df		CMP R19, R22										
  execution.go:590	0x100213e90		54008ac2		BCS 1110(PC)										
  execution.go:590	0x100213e94		8b161197		ADD R22<<4, R12, R23									
  execution.go:590	0x100213e98		f94002f7		MOVD (R23), R23										
  integer.go:61		0x100213e9c		2a1703f6		MOVW R23, R22										
  execution.go:590	0x100213ea0		14000057		JMP 87(PC)										
  execution.go:611	0x100213ea4		b9401283		MOVWU 16(R20), R3									
  execution.go:611	0x100213ea8		3100047f		CMNW $1, R3										
  execution.go:611	0x100213eac		540000c0		BEQ 6(PC)										
  execution.go:612	0x100213eb0		eb13007f		CMP R19, R3										
  execution.go:612	0x100213eb4		54008962		BCS 1099(PC)										
  execution.go:612	0x100213eb8		8b031183		ADD R3<<4, R12, R3									
  execution.go:612	0x100213ebc		f9400062		MOVD (R3), R2										
  execution.go:612	0x100213ec0		14000002		JMP 2(PC)										
  execution.go:612	0x100213ec4		aa1f03e2		MOVD ZR, R2										
  execution.go:614	0x100213ec8		b9400e83		MOVWU 12(R20), R3									
  execution.go:614	0x100213ecc		eb13007f		CMP R19, R3										
  execution.go:614	0x100213ed0		54008842		BCS 1090(PC)										
  execution.go:614	0x100213ed4		8b031183		ADD R3<<4, R12, R3									
  execution.go:614	0x100213ed8		f9400063		MOVD (R3), R3										
  execution.go:614	0x100213edc		aa0103e0		MOVD R1, R0										
  execution.go:614	0x100213ee0		aa0303e1		MOVD R3, R1										
  execution.go:614	0x100213ee4		97ffa8c3		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:615	0x100213ee8		d3401c23		UBFX $0, R1, $8, R3									
  execution.go:615	0x100213eec		34000223		CBZW R3, 17(PC)										
  execution.go:342	0x100213ef0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213ef4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213ef8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100213efc		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213f00		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213f04		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213f08		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213f0c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213f10		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213f14		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213f18		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100213f1c		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x100213f20		aa1f03f7		MOVD ZR, R23										
  execution.go:395	0x100213f24		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100213f28		f94127e0		MOVD 584(RSP), R0									
  execution.go:616	0x100213f2c		140002da		JMP 730(PC)										
  execution.go:342	0x100213f30		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213f34		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213f38		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100213f3c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213f40		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213f44		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213f48		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213f4c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213f50		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213f54		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213f58		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100213f5c		f94093f5		MOVD 288(RSP), R21									
  execution.go:488	0x100213f60		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100213f64		f94127e0		MOVD 584(RSP), R0									
  execution.go:615	0x100213f68		14000025		JMP 37(PC)										
  execution.go:592	0x100213f6c		b9400e96		MOVWU 12(R20), R22									
  execution.go:592	0x100213f70		eb1302df		CMP R19, R22										
  execution.go:592	0x100213f74		540082c2		BCS 1046(PC)										
  execution.go:592	0x100213f78		8b161196		ADD R22<<4, R12, R22									
  execution.go:592	0x100213f7c		f94002d6		MOVD (R22), R22										
  integer.go:62		0x100213f80		93401ed6		SXTB R22, R22										
  integer.go:62		0x100213f84		2a1603f6		MOVW R22, R22										
  execution.go:592	0x100213f88		1400001d		JMP 29(PC)										
  execution.go:594	0x100213f8c		b9400e96		MOVWU 12(R20), R22									
  execution.go:594	0x100213f90		eb1302df		CMP R19, R22										
  execution.go:594	0x100213f94		54008162		BCS 1035(PC)										
  execution.go:594	0x100213f98		8b161196		ADD R22<<4, R12, R22									
  execution.go:594	0x100213f9c		f94002d6		MOVD (R22), R22										
  integer.go:63		0x100213fa0		93403ed6		SXTH R22, R22										
  integer.go:63		0x100213fa4		2a1603f6		MOVW R22, R22										
  execution.go:594	0x100213fa8		14000015		JMP 21(PC)										
  execution.go:596	0x100213fac		b9400e96		MOVWU 12(R20), R22									
  execution.go:596	0x100213fb0		eb1302df		CMP R19, R22										
  execution.go:596	0x100213fb4		54008002		BCS 1024(PC)										
  execution.go:596	0x100213fb8		8b161196		ADD R22<<4, R12, R22									
  execution.go:596	0x100213fbc		f94002d6		MOVD (R22), R22										
  integer.go:64		0x100213fc0		93401ed6		SXTB R22, R22										
  execution.go:596	0x100213fc4		1400000e		JMP 14(PC)										
  execution.go:598	0x100213fc8		b9400e96		MOVWU 12(R20), R22									
  execution.go:598	0x100213fcc		eb1302df		CMP R19, R22										
  execution.go:598	0x100213fd0		54007ec2		BCS 1014(PC)										
  execution.go:598	0x100213fd4		8b161196		ADD R22<<4, R12, R22									
  execution.go:598	0x100213fd8		f94002d6		MOVD (R22), R22										
  integer.go:65		0x100213fdc		93403ed6		SXTH R22, R22										
  execution.go:598	0x100213fe0		14000007		JMP 7(PC)										
  execution.go:600	0x100213fe4		b9400e96		MOVWU 12(R20), R22									
  execution.go:600	0x100213fe8		eb1302df		CMP R19, R22										
  execution.go:600	0x100213fec		54007d82		BCS 1004(PC)										
  execution.go:600	0x100213ff0		8b161196		ADD R22<<4, R12, R22									
  execution.go:600	0x100213ff4		f94002d6		MOVD (R22), R22										
  integer.go:66		0x100213ff8		93407ed6		SXTW R22, R22										
  execution.go:619	0x100213ffc		aa1f03f7		MOVD ZR, R23										
  execution.go:619	0x100214000		140002a7		JMP 679(PC)										
  execution.go:621	0x100214004		7100f83f		CMPW $62, R1										
  execution.go:706	0x100214008		54001e68		BHI 243(PC)										
  execution.go:621	0x10021400c		7100803f		CMPW $32, R1										
  execution.go:676	0x100214010		540005c8		BHI 46(PC)										
  execution.go:621	0x100214014		7100283f		CMPW $10, R1										
  execution.go:663	0x100214018		54000108		BHI 8(PC)										
  execution.go:669	0x10021401c		7100043f		CMPW $1, R1										
  execution.go:669	0x100214020		540001a0		BEQ 13(PC)										
  execution.go:663	0x100214024		7100203f		CMPW $8, R1										
  execution.go:663	0x100214028		54005560		BEQ 683(PC)										
  execution.go:621	0x10021402c		7100283f		CMPW $10, R1										
  execution.go:663	0x100214030		540042e1		BNE 535(PC)										
  execution.go:663	0x100214034		140002a8		JMP 680(PC)										
  execution.go:621	0x100214038		7100683f		CMPW $26, R1										
  execution.go:669	0x10021403c		54000148		BHI 10(PC)										
  execution.go:743	0x100214040		d1004036		SUB $16, R1, R22									
  execution.go:743	0x100214044		710016df		CMPW $5, R22										
  execution.go:743	0x100214048		54005509		BLS 680(PC)										
  execution.go:621	0x10021404c		7100683f		CMPW $26, R1										
  execution.go:669	0x100214050		540041e1		BNE 527(PC)										
  execution.go:704	0x100214054		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100214058		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x10021405c		aa1f03e1		MOVD ZR, R1										
  execution.go:669	0x100214060		1400028d		JMP 653(PC)										
  execution.go:670	0x100214064		7100703f		CMPW $28, R1										
  execution.go:670	0x100214068		540001e8		BHI 15(PC)										
  execution.go:671	0x10021406c		29425e96		LDPW 16(R20), (R22, R23)								
  execution.go:672	0x100214070		eb1302ff		CMP R19, R23										
  execution.go:672	0x100214074		540078e2		BCS 967(PC)										
  execution.go:672	0x100214078		8b171197		ADD R23<<4, R12, R23									
  execution.go:672	0x10021407c		f94002f7		MOVD (R23), R23										
  execution.go:672	0x100214080		34000057		CBZW R23, 2(PC)										
  execution.go:673	0x100214084		b9400e96		MOVWU 12(R20), R22									
  execution.go:675	0x100214088		2a1603f6		MOVW R22, R22										
  execution.go:675	0x10021408c		eb1302df		CMP R19, R22										
  execution.go:675	0x100214090		540077a2		BCS 957(PC)										
  execution.go:675	0x100214094		8b161196		ADD R22<<4, R12, R22									
  execution.go:675	0x100214098		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x10021409c		aa1f03e1		MOVD ZR, R1										
  execution.go:675	0x1002140a0		1400027d		JMP 637(PC)										
  execution.go:621	0x1002140a4		7100803f		CMPW $32, R1										
  execution.go:676	0x1002140a8		54003f21		BNE 505(PC)										
  execution.go:677	0x1002140ac		b9401a96		MOVWU 24(R20), R22									
  execution.go:677	0x1002140b0		eb1302df		CMP R19, R22										
  execution.go:677	0x1002140b4		54007622		BCS 945(PC)										
  execution.go:677	0x1002140b8		8b161196		ADD R22<<4, R12, R22									
  execution.go:677	0x1002140bc		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x1002140c0		aa1f03e1		MOVD ZR, R1										
  execution.go:677	0x1002140c4		14000274		JMP 628(PC)										
  execution.go:621	0x1002140c8		7100903f		CMPW $36, R1										
  execution.go:683	0x1002140cc		54000548		BHI 42(PC)										
  execution.go:678	0x1002140d0		7100883f		CMPW $34, R1										
  execution.go:678	0x1002140d4		540001a8		BHI 13(PC)										
  execution.go:679	0x1002140d8		b9400e96		MOVWU 12(R20), R22									
  execution.go:679	0x1002140dc		eb1302df		CMP R19, R22										
  execution.go:679	0x1002140e0		54007462		BCS 931(PC)										
  execution.go:679	0x1002140e4		8b161196		ADD R22<<4, R12, R22									
  execution.go:679	0x1002140e8		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:680	0x1002140ec		b9401a98		MOVWU 24(R20), R24									
  execution.go:680	0x1002140f0		eb13031f		CMP R19, R24										
  execution.go:680	0x1002140f4		54007362		BCS 923(PC)										
  execution.go:680	0x1002140f8		8b181198		ADD R24<<4, R12, R24									
  execution.go:680	0x1002140fc		a9005f16		STP (R22, R23), (R24)									
  execution.go:708	0x100214100		aa1f03e1		MOVD ZR, R1										
  execution.go:680	0x100214104		14000264		JMP 612(PC)										
  execution.go:681	0x100214108		71008c3f		CMPW $35, R1										
  execution.go:681	0x10021410c		54000121		BNE 9(PC)										
  execution.go:682	0x100214110		a948ddb6		LDP 136(R13), (R22, R23)								
  execution.go:682	0x100214114		b9401a98		MOVWU 24(R20), R24									
  execution.go:682	0x100214118		eb17031f		CMP R23, R24										
  execution.go:682	0x10021411c		540071c2		BCS 910(PC)										
  execution.go:682	0x100214120		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:682	0x100214124		a9425ed6		LDP 32(R22), (R22, R23)									
  execution.go:708	0x100214128		aa1f03e1		MOVD ZR, R1										
  execution.go:682	0x10021412c		1400025a		JMP 602(PC)										
  execution.go:621	0x100214130		7100903f		CMPW $36, R1										
  execution.go:683	0x100214134		54003ac1		BNE 470(PC)										
  execution.go:684	0x100214138		b9400e96		MOVWU 12(R20), R22									
  execution.go:684	0x10021413c		eb1302df		CMP R19, R22										
  execution.go:684	0x100214140		54007042		BCS 898(PC)										
  execution.go:684	0x100214144		a948e1b7		LDP 136(R13), (R23, R24)								
  execution.go:684	0x100214148		b9401a99		MOVWU 24(R20), R25									
  execution.go:684	0x10021414c		8b161196		ADD R22<<4, R12, R22									
  execution.go:684	0x100214150		a9406ad6		LDP (R22), (R22, R26)									
  execution.go:684	0x100214154		eb18033f		CMP R24, R25										
  execution.go:684	0x100214158		54006f22		BCS 889(PC)										
  execution.go:684	0x10021415c		f8797af7		MOVD (R23)(R25<<3), R23									
  execution.go:684	0x100214160		a9026af6		STP (R22, R26), 32(R23)									
  execution.go:704	0x100214164		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100214168		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x10021416c		aa1f03e1		MOVD ZR, R1										
  execution.go:684	0x100214170		14000249		JMP 585(PC)										
  execution.go:621	0x100214174		7100983f		CMPW $38, R1										
  execution.go:693	0x100214178		54000708		BHI 56(PC)										
  execution.go:685	0x10021417c		7100943f		CMPW $37, R1										
  execution.go:685	0x100214180		54000321		BNE 25(PC)										
  execution.go:686	0x100214184		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:686	0x100214188		b9401a98		MOVWU 24(R20), R24									
  execution.go:686	0x10021418c		eb17031f		CMP R23, R24										
  execution.go:686	0x100214190		54006d02		BCS 872(PC)										
  execution.go:686	0x100214194		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:687	0x100214198		398002db		MOVB (R22), R27										
  execution.go:687	0x10021419c		b9400e97		MOVWU 12(R20), R23									
  execution.go:687	0x1002141a0		eb1302ff		CMP R19, R23										
  execution.go:687	0x1002141a4		54006c02		BCS 864(PC)										
  execution.go:687	0x1002141a8		8b171197		ADD R23<<4, R12, R23									
  execution.go:687	0x1002141ac		f94002f7		MOVD (R23), R23										
  module.go:70		0x1002141b0		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x1002141b4		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x1002141b8		2a1703f7		MOVW R23, R23										
  execution.go:688	0x1002141bc		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:688	0x1002141c0		eb1802ff		CMP R24, R23										
  execution.go:688	0x1002141c4		54000083		BCC 4(PC)										
  execution.go:688	0x1002141c8		b24007e1		ORR $3, ZR, R1										
  execution.go:691	0x1002141cc		aa1f03f6		MOVD ZR, R22										
  execution.go:688	0x1002141d0		14000003		JMP 3(PC)										
  execution.go:691	0x1002141d4		f8777ad6		MOVD (R22)(R23<<3), R22									
  execution.go:689	0x1002141d8		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x1002141dc		aa1f03f7		MOVD ZR, R23										
  execution.go:688	0x1002141e0		1400022d		JMP 557(PC)										
  execution.go:694	0x1002141e4		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:694	0x1002141e8		b9401a98		MOVWU 24(R20), R24									
  execution.go:694	0x1002141ec		eb17031f		CMP R23, R24										
  execution.go:694	0x1002141f0		54006942		BCS 842(PC)										
  execution.go:694	0x1002141f4		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:695	0x1002141f8		398002db		MOVB (R22), R27										
  execution.go:695	0x1002141fc		b9400e97		MOVWU 12(R20), R23									
  execution.go:695	0x100214200		eb1302ff		CMP R19, R23										
  execution.go:695	0x100214204		54006842		BCS 834(PC)										
  execution.go:695	0x100214208		8b171197		ADD R23<<4, R12, R23									
  execution.go:695	0x10021420c		f94002f7		MOVD (R23), R23										
  module.go:70		0x100214210		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x100214214		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x100214218		2a1703f7		MOVW R23, R23										
  execution.go:696	0x10021421c		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:696	0x100214220		eb1802ff		CMP R24, R23										
  execution.go:696	0x100214224		54000063		BCC 3(PC)										
  execution.go:696	0x100214228		b24007e1		ORR $3, ZR, R1										
  execution.go:696	0x10021422c		14000008		JMP 8(PC)										
  execution.go:699	0x100214230		b9401298		MOVWU 16(R20), R24									
  execution.go:699	0x100214234		eb13031f		CMP R19, R24										
  execution.go:699	0x100214238		54006642		BCS 818(PC)										
  execution.go:699	0x10021423c		8b181198		ADD R24<<4, R12, R24									
  execution.go:699	0x100214240		f9400318		MOVD (R24), R24										
  execution.go:699	0x100214244		f8377ad8		MOVD R24, (R22)(R23<<3)									
  execution.go:697	0x100214248		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x10021424c		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100214250		aa1f03f6		MOVD ZR, R22										
  execution.go:696	0x100214254		14000210		JMP 528(PC)										
  execution.go:701	0x100214258		d100a036		SUB $40, R1, R22									
  execution.go:701	0x10021425c		710036df		CMPW $13, R22										
  execution.go:702	0x100214260		54000588		BHI 44(PC)										
  execution.go:703	0x100214264		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:703	0x100214268		b9400696		MOVWU 4(R20), R22									
  execution.go:703	0x10021426c		aa1603f7		MOVD R22, R23										
  execution.go:703	0x100214270		eb0802ff		CMP R8, R23										
  execution.go:703	0x100214274		54006422		BCS 801(PC)										
  execution.go:703	0x100214278		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:703	0x10021427c		cb171508		SUB R23<<5, R8, R8									
  execution.go:703	0x100214280		8b0800e7		ADD R8, R7, R7										
  execution.go:704	0x100214284		a94759a8		LDP 112(R13), (R8, R22)									
  module.go:178		0x100214288		2942e0f7		LDPW 20(R7), (R23, R24)									
  module.go:178		0x10021428c		b9401ce7		MOVWU 28(R7), R7									
  module.go:178		0x100214290		aa0782e3		ORR R7<<32, R23, R3									
  execution.go:704	0x100214294		eb16031f		CMP R22, R24										
  execution.go:704	0x100214298		540062a2		BCS 789(PC)										
  execution.go:704	0x10021429c		f8787907		MOVD (R8)(R24<<3), R7									
  execution.go:704	0x1002142a0		398000fb		MOVB (R7), R27										
  execution.go:704	0x1002142a4		b9400e88		MOVWU 12(R20), R8									
  execution.go:704	0x1002142a8		eb13011f		CMP R19, R8										
  execution.go:704	0x1002142ac		540061c2		BCS 782(PC)										
  execution.go:704	0x1002142b0		f94008e0		MOVD 16(R7), R0										
  execution.go:704	0x1002142b4		8b081187		ADD R8<<4, R12, R7									
  execution.go:704	0x1002142b8		f94000e2		MOVD (R7), R2										
  execution.go:704	0x1002142bc		aa1f03e4		MOVD ZR, R4										
  execution.go:704	0x1002142c0		aa1f03e5		MOVD ZR, R5										
  execution.go:704	0x1002142c4		aa1f03e6		MOVD ZR, R6										
  execution.go:704	0x1002142c8		97ff9f1e		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:342	0x1002142cc		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002142d0		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002142d4		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x1002142d8		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002142dc		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002142e0		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002142e4		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002142e8		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002142ec		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002142f0		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002142f4		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002142f8		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002142fc		aa0103f7		MOVD R1, R23										
  execution.go:704	0x100214300		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100214304		aa0203e1		MOVD R2, R1										
  execution.go:209	0x100214308		f94127e0		MOVD 584(RSP), R0									
  execution.go:704	0x10021430c		140001e2		JMP 482(PC)										
  execution.go:705	0x100214310		7100d83f		CMPW $54, R1										
  execution.go:705	0x100214314		54002bc3		BCC 350(PC)										
  execution.go:707	0x100214318		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:707	0x10021431c		b9400696		MOVWU 4(R20), R22									
  execution.go:707	0x100214320		aa1603f7		MOVD R22, R23										
  execution.go:707	0x100214324		eb0802ff		CMP R8, R23										
  execution.go:707	0x100214328		54005da2		BCS 749(PC)										
  execution.go:707	0x10021432c		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:707	0x100214330		cb171508		SUB R23<<5, R8, R8									
  execution.go:707	0x100214334		8b0800e7		ADD R8, R7, R7										
  execution.go:708	0x100214338		b9401288		MOVWU 16(R20), R8									
  module.go:178		0x10021433c		b94014f6		MOVWU 20(R7), R22									
  module.go:178		0x100214340		29435ce7		LDPW 24(R7), (R7, R23)									
  module.go:178		0x100214344		aa1782c3		ORR R23<<32, R22, R3									
  execution.go:708	0x100214348		eb13011f		CMP R19, R8										
  execution.go:708	0x10021434c		54005c42		BCS 738(PC)										
  execution.go:708	0x100214350		a9475db6		LDP 112(R13), (R22, R23)								
  execution.go:708	0x100214354		8b081188		ADD R8<<4, R12, R8									
  execution.go:708	0x100214358		eb1700ff		CMP R23, R7										
  execution.go:708	0x10021435c		54005b82		BCS 732(PC)										
  execution.go:708	0x100214360		f8677ac7		MOVD (R22)(R7<<3), R7									
  execution.go:708	0x100214364		398000fb		MOVB (R7), R27										
  execution.go:708	0x100214368		b9400e96		MOVWU 12(R20), R22									
  execution.go:708	0x10021436c		eb1302df		CMP R19, R22										
  execution.go:708	0x100214370		54005a82		BCS 724(PC)										
  execution.go:708	0x100214374		f94008e0		MOVD 16(R7), R0										
  execution.go:708	0x100214378		8b161187		ADD R22<<4, R12, R7									
  execution.go:708	0x10021437c		f94000e2		MOVD (R7), R2										
  execution.go:708	0x100214380		f9400105		MOVD (R8), R5										
  execution.go:708	0x100214384		aa1f03e4		MOVD ZR, R4										
  execution.go:708	0x100214388		aa1f03e6		MOVD ZR, R6										
  execution.go:708	0x10021438c		97ff9f65		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:342	0x100214390		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100214394		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100214398		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021439c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002143a0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002143a4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002143a8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002143ac		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002143b0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002143b4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002143b8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002143bc		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002143c0		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002143c4		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x1002143c8		aa0003e1		MOVD R0, R1										
  execution.go:209	0x1002143cc		f94127e0		MOVD 584(RSP), R0									
  execution.go:708	0x1002143d0		140001b1		JMP 433(PC)										
  execution.go:621	0x1002143d4		7103483f		CMPW $210, R1										
  execution.go:741	0x1002143d8		54000ec8		BHI 118(PC)										
  execution.go:621	0x1002143dc		7101043f		CMPW $65, R1										
  execution.go:718	0x1002143e0		54000a28		BHI 81(PC)										
  execution.go:709	0x1002143e4		7100fc3f		CMPW $63, R1										
  execution.go:709	0x1002143e8		540006e0		BEQ 55(PC)										
  execution.go:711	0x1002143ec		7101003f		CMPW $64, R1										
  execution.go:711	0x1002143f0		540000a0		BEQ 5(PC)										
  execution.go:719	0x1002143f4		b9401a96		MOVWU 24(R20), R22									
  execution.go:704	0x1002143f8		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x1002143fc		aa1f03e1		MOVD ZR, R1										
  execution.go:719	0x100214400		140001a5		JMP 421(PC)										
  execution.go:712	0x100214404		a94711a3		LDP 112(R13), (R3, R4)									
  execution.go:712	0x100214408		b9401a85		MOVWU 24(R20), R5									
  execution.go:712	0x10021440c		eb0400bf		CMP R4, R5										
  execution.go:712	0x100214410		54005562		BCS 683(PC)										
  execution.go:712	0x100214414		f8657861		MOVD (R3)(R5<<3), R1									
  execution.go:713	0x100214418		f9400823		MOVD 16(R1), R3										
  memory.go:127		0x10021441c		ad410460		FLDPQ 32(R3), (F0, F1)									
  execution.go:713	0x100214420		910623fb		ADD $392, RSP, R27									
  execution.go:713	0x100214424		ad000760		FSTPQ (F0, F1), (R27)									
  execution.go:713	0x100214428		b9400e83		MOVWU 12(R20), R3									
  execution.go:713	0x10021442c		eb13007f		CMP R19, R3										
  execution.go:713	0x100214430		54005422		BCS 673(PC)										
  execution.go:713	0x100214434		8b031183		ADD R3<<4, R12, R3									
  execution.go:713	0x100214438		f9400062		MOVD (R3), R2										
  module.go:70		0x10021443c		394667e3		MOVBU 409(RSP), R3									
  module.go:70		0x100214440		37000043		TBNZ $0, R3, 2(PC)									
  module.go:73		0x100214444		2a0203e2		MOVW R2, R2										
  execution.go:712	0x100214448		f900a3e1		MOVD R1, 320(RSP)									
  execution.go:713	0x10021444c		f9400000		MOVD (R0), R0										
  execution.go:713	0x100214450		97ffe548		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory(SB)		
  execution.go:715	0x100214454		37000161		TBNZ $0, R1, 11(PC)									
  execution.go:716	0x100214458		f940a3e9		MOVD 320(RSP), R9									
  execution.go:716	0x10021445c		f9400929		MOVD 16(R9), R9										
  memory.go:127		0x100214460		ad410520		FLDPQ 32(R9), (F0, F1)									
  execution.go:716	0x100214464		910623fb		ADD $392, RSP, R27									
  execution.go:716	0x100214468		ad000760		FSTPQ (F0, F1), (R27)									
  module.go:77		0x10021446c		394667e9		MOVBU 409(RSP), R9									
  execution.go:716	0x100214470		7200013f		TSTW $1, R9										
  execution.go:716	0x100214474		92800009		MOVD $-1, R9										
  execution.go:716	0x100214478		b2407fea		MOVD $4294967295, R10									
  execution.go:716	0x10021447c		9a8a1120		CSEL NE, R9, R10, R0									
  execution.go:342	0x100214480		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100214484		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100214488		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021448c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100214490		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100214494		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100214498		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021449c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002144a0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002144a4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002144a8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002144ac		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002144b0		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002144b4		aa0003f6		MOVD R0, R22										
  execution.go:708	0x1002144b8		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x1002144bc		f94127e0		MOVD 584(RSP), R0									
  execution.go:715	0x1002144c0		14000175		JMP 373(PC)										
  execution.go:710	0x1002144c4		a94709a1		LDP 112(R13), (R1, R2)									
  execution.go:710	0x1002144c8		b9401a83		MOVWU 24(R20), R3									
  execution.go:710	0x1002144cc		eb02007f		CMP R2, R3										
  execution.go:710	0x1002144d0		54004f02		BCS 632(PC)										
  execution.go:710	0x1002144d4		f8637821		MOVD (R1)(R3<<3), R1									
  execution.go:710	0x1002144d8		f9400820		MOVD 16(R1), R0										
  execution.go:710	0x1002144dc		97ff9c19		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages(SB)		
  execution.go:342	0x1002144e0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002144e4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002144e8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x1002144ec		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002144f0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002144f4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002144f8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002144fc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100214500		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100214504		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100214508		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021450c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100214510		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100214514		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100214518		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x10021451c		f94127e0		MOVD 584(RSP), R0									
  execution.go:710	0x100214520		1400015d		JMP 349(PC)										
  execution.go:621	0x100214524		7103403f		CMPW $208, R1										
  execution.go:730	0x100214528		540001c8		BHI 14(PC)										
  execution.go:721	0x10021452c		7101103f		CMPW $68, R1										
  execution.go:721	0x100214530		540000c8		BHI 6(PC)										
  execution.go:722	0x100214534		b9401a97		MOVWU 24(R20), R23									
  execution.go:722	0x100214538		aa1682f6		ORR R22<<32, R23, R22									
  execution.go:704	0x10021453c		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100214540		aa1f03e1		MOVD ZR, R1										
  execution.go:722	0x100214544		14000154		JMP 340(PC)										
  execution.go:621	0x100214548		7103403f		CMPW $208, R1										
  execution.go:730	0x10021454c		54001a01		BNE 208(PC)										
  execution.go:704	0x100214550		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100214554		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100214558		aa1f03e1		MOVD ZR, R1										
  execution.go:730	0x10021455c		1400014e		JMP 334(PC)										
  execution.go:737	0x100214560		7103443f		CMPW $209, R1										
  execution.go:737	0x100214564		54000161		BNE 11(PC)										
  execution.go:738	0x100214568		b9400e96		MOVWU 12(R20), R22									
  execution.go:738	0x10021456c		eb1302df		CMP R19, R22										
  execution.go:738	0x100214570		540049a2		BCS 589(PC)										
  execution.go:738	0x100214574		8b161196		ADD R22<<4, R12, R22									
  execution.go:738	0x100214578		f94002d6		MOVD (R22), R22										
  execution.go:738	0x10021457c		f10002df		CMP $0, R22										
  execution.go:738	0x100214580		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x100214584		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100214588		aa1f03e1		MOVD ZR, R1										
  execution.go:738	0x10021458c		14000142		JMP 322(PC)										
  execution.go:742	0x100214590		a9445db6		LDP 64(R13), (R22, R23)									
  execution.go:742	0x100214594		b9401a98		MOVWU 24(R20), R24									
  execution.go:742	0x100214598		eb17031f		CMP R23, R24										
  execution.go:742	0x10021459c		540047e2		BCS 575(PC)										
  execution.go:742	0x1002145a0		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:704	0x1002145a4		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x1002145a8		aa1f03e1		MOVD ZR, R1										
  execution.go:742	0x1002145ac		1400013a		JMP 314(PC)										
  execution.go:621	0x1002145b0		d2800077		MOVD $3, R23										
  execution.go:621	0x1002145b4		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x1002145b8		6b17003f		CMPW R23, R1										
  execution.go:634	0x1002145bc		54000808		BHI 64(PC)										
  execution.go:621	0x1002145c0		7103503f		CMPW $212, R1										
  execution.go:731	0x1002145c4		540003a8		BHI 29(PC)										
  execution.go:726	0x1002145c8		71034c3f		CMPW $211, R1										
  execution.go:726	0x1002145cc		540001e1		BNE 15(PC)										
  execution.go:727	0x1002145d0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:727	0x1002145d4		eb1302df		CMP R19, R22										
  execution.go:727	0x1002145d8		540045a2		BCS 557(PC)										
  execution.go:727	0x1002145dc		8b161196		ADD R22<<4, R12, R22									
  execution.go:727	0x1002145e0		eb1302ff		CMP R19, R23										
  execution.go:727	0x1002145e4		540044e2		BCS 551(PC)										
  execution.go:727	0x1002145e8		f94002d6		MOVD (R22), R22										
  execution.go:727	0x1002145ec		8b171197		ADD R23<<4, R12, R23									
  execution.go:727	0x1002145f0		f94002f7		MOVD (R23), R23										
  execution.go:727	0x1002145f4		eb1602ff		CMP R22, R23										
  execution.go:727	0x1002145f8		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x1002145fc		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100214600		aa1f03e1		MOVD ZR, R1										
  execution.go:727	0x100214604		14000124		JMP 292(PC)										
  execution.go:732	0x100214608		b9400e96		MOVWU 12(R20), R22									
  execution.go:732	0x10021460c		eb1302df		CMP R19, R22										
  execution.go:732	0x100214610		54004322		BCS 537(PC)										
  execution.go:732	0x100214614		8b161196		ADD R22<<4, R12, R22									
  execution.go:732	0x100214618		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:732	0x10021461c		b50000b6		CBNZ R22, 5(PC)										
  execution.go:732	0x100214620		d2800121		MOVD $9, R1										
  execution.go:735	0x100214624		aa1f03f7		MOVD ZR, R23										
  execution.go:735	0x100214628		aa1f03f6		MOVD ZR, R22										
  execution.go:732	0x10021462c		1400011a		JMP 282(PC)										
  execution.go:733	0x100214630		aa1f03e1		MOVD ZR, R1										
  execution.go:735	0x100214634		14000118		JMP 280(PC)										
  execution.go:723	0x100214638		d17f0037		SUB $(4032<<12), R1, R23								
  execution.go:723	0x10021463c		71001eff		CMPW $7, R23										
  execution.go:724	0x100214640		540000c9		BLS 6(PC)										
  execution.go:634	0x100214644		d2800037		MOVD $1, R23										
  execution.go:634	0x100214648		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x10021464c		6b17003f		CMPW R23, R1										
  execution.go:634	0x100214650		54000582		BCS 44(PC)										
  execution.go:634	0x100214654		1400008e		JMP 142(PC)										
  execution.go:725	0x100214658		b9400e83		MOVWU 12(R20), R3									
  execution.go:725	0x10021465c		eb13007f		CMP R19, R3										
  execution.go:725	0x100214660		54004062		BCS 515(PC)										
  execution.go:725	0x100214664		8b031183		ADD R3<<4, R12, R3									
  execution.go:725	0x100214668		f9400063		MOVD (R3), R3										
  execution.go:725	0x10021466c		aa0103e0		MOVD R1, R0										
  execution.go:725	0x100214670		aa0303e1		MOVD R3, R1										
  execution.go:725	0x100214674		aa1f03e2		MOVD ZR, R2										
  execution.go:725	0x100214678		97ffa6de		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:342	0x10021467c		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100214680		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100214684		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100214688		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10021468c		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100214690		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100214694		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100214698		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x10021469c		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002146a0		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002146a4		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002146a8		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002146ac		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002146b0		aa0003f6		MOVD R0, R22										
  execution.go:209	0x1002146b4		f94127e0		MOVD 584(RSP), R0									
  execution.go:725	0x1002146b8		140000f7		JMP 247(PC)										
  execution.go:621	0x1002146bc		d28000b7		MOVD $5, R23										
  execution.go:621	0x1002146c0		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x1002146c4		6b17003f		CMPW R23, R1										
  execution.go:634	0x1002146c8		540000c8		BHI 6(PC)										
  execution.go:622	0x1002146cc		d2800097		MOVD $4, R23										
  execution.go:622	0x1002146d0		f2a02017		MOVK $(256<<16), R23									
  execution.go:622	0x1002146d4		6b17003f		CMPW R23, R1										
  execution.go:622	0x1002146d8		54000141		BNE 10(PC)										
  execution.go:622	0x1002146dc		14000108		JMP 264(PC)										
  execution.go:628	0x1002146e0		d28000f7		MOVD $7, R23										
  execution.go:628	0x1002146e4		f2a02017		MOVK $(256<<16), R23									
  execution.go:628	0x1002146e8		6b17003f		CMPW R23, R1										
  execution.go:628	0x1002146ec		54002120		BEQ 265(PC)										
  execution.go:634	0x1002146f0		d2800137		MOVD $9, R23										
  execution.go:634	0x1002146f4		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x1002146f8		6b17003f		CMPW R23, R1										
  execution.go:634	0x1002146fc		54000c81		BNE 100(PC)										
  execution.go:635	0x100214700		d2a02017		MOVD $16777216, R23									
  execution.go:635	0x100214704		cb170037		SUB R23, R1, R23									
  execution.go:636	0x100214708		d3401ef7		UBFX $0, R23, $8, R23									
  execution.go:636	0x10021470c		710016ff		CMPW $5, R23										
  execution.go:636	0x100214710		540000a1		BNE 5(PC)										
  execution.go:704	0x100214714		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100214718		aa1f03f6		MOVD ZR, R22										
  execution.go:704	0x10021471c		b24003e1		ORR $1, ZR, R1										
  execution.go:638	0x100214720		140000dd		JMP 221(PC)										
  execution.go:641	0x100214724		710026ff		CMPW $9, R23										
  execution.go:641	0x100214728		54000121		BNE 9(PC)										
  execution.go:641	0x10021472c		b9400e98		MOVWU 12(R20), R24									
  execution.go:641	0x100214730		eb13031f		CMP R19, R24										
  execution.go:641	0x100214734		54003962		BCS 459(PC)										
  execution.go:641	0x100214738		8b181198		ADD R24<<4, R12, R24									
  execution.go:641	0x10021473c		f9400318		MOVD (R24), R24										
  execution.go:641	0x100214740		b4000078		CBZ R24, 3(PC)										
  execution.go:641	0x100214744		b24003f6		ORR $1, ZR, R22										
  execution.go:641	0x100214748		14000018		JMP 24(PC)										
  execution.go:643	0x10021474c		71000aff		CMPW $2, R23										
  execution.go:643	0x100214750		54000121		BNE 9(PC)										
  execution.go:643	0x100214754		b9400e98		MOVWU 12(R20), R24									
  execution.go:643	0x100214758		eb13031f		CMP R19, R24										
  execution.go:643	0x10021475c		540037c2		BCS 446(PC)										
  execution.go:643	0x100214760		8b181198		ADD R24<<4, R12, R24									
  execution.go:643	0x100214764		f9400318		MOVD (R24), R24										
  execution.go:643	0x100214768		35000078		CBNZW R24, 3(PC)									
  execution.go:643	0x10021476c		b24003f6		ORR $1, ZR, R22										
  execution.go:643	0x100214770		1400000e		JMP 14(PC)										
  execution.go:645	0x100214774		71000eff		CMPW $3, R23										
  execution.go:645	0x100214778		54000161		BNE 11(PC)										
  execution.go:646	0x10021477c		b9400e97		MOVWU 12(R20), R23									
  execution.go:646	0x100214780		eb1302ff		CMP R19, R23										
  execution.go:646	0x100214784		54003622		BCS 433(PC)										
  execution.go:646	0x100214788		8b171197		ADD R23<<4, R12, R23									
  execution.go:646	0x10021478c		f94002f7		MOVD (R23), R23										
  execution.go:647	0x100214790		d10006d6		SUB $1, R22, R22									
  execution.go:647	0x100214794		6b1602ff		CMPW R22, R23										
  execution.go:647	0x100214798		54000082		BCS 4(PC)										
  execution.go:648	0x10021479c		aa1703f6		MOVD R23, R22										
  execution.go:647	0x1002147a0		14000002		JMP 2(PC)										
  execution.go:647	0x1002147a4		aa1f03f6		MOVD ZR, R22										
  execution.go:651	0x1002147a8		a94e61d7		LDP 224(R14), (R23, R24)								
  execution.go:651	0x1002147ac		b9401a94		MOVWU 24(R20), R20									
  execution.go:651	0x1002147b0		8b1402d4		ADD R20, R22, R20									
  execution.go:651	0x1002147b4		2a1403f6		MOVW R20, R22										
  execution.go:651	0x1002147b8		eb1802df		CMP R24, R22										
  execution.go:651	0x1002147bc		54003402		BCS 416(PC)										
  execution.go:651	0x1002147c0		d37e7e94		UBFIZ $2, R20, $32, R20									
  execution.go:651	0x1002147c4		8b140694		ADD R20<<1, R20, R20									
  execution.go:651	0x1002147c8		b8746af6		MOVWU (R23)(R20), R22									
  execution.go:651	0x1002147cc		8b1402f4		ADD R20, R23, R20									
  execution.go:651	0x1002147d0		2940de94		LDPW 4(R20), (R20, R23)									
  execution.go:652	0x1002147d4		6b16023f		CMPW R22, R17										
  execution.go:652	0x1002147d8		540003e3		BCC 31(PC)										
  execution.go:651	0x1002147dc		b90107f7		MOVW R23, 260(RSP)									
  execution.go:651	0x1002147e0		b90103f4		MOVW R20, 256(RSP)									
  execution.go:651	0x1002147e4		b900fff6		MOVW R22, 252(RSP)									
  execution.go:209	0x1002147e8		f940b011		MOVD 352(R0), R17									
  execution.go:209	0x1002147ec		b40000d1		CBZ R17, 6(PC)										
  type.go:19		0x1002147f0		88dffe31		LDARW (R17), R17									
  execution.go:209	0x1002147f4		35000091		CBNZW R17, 4(PC)									
  execution.go:212	0x1002147f8		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x1002147fc		aa1f03e2		MOVD ZR, R2										
  execution.go:653	0x100214800		14000014		JMP 20(PC)										
  execution.go:212	0x100214804		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100214808		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10021480c		d63f0020		CALL (R1)										
  execution.go:342	0x100214810		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100214814		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100214818		f940b3eb		MOVD 352(RSP), R11									
  execution.go:658	0x10021481c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100214820		f940abed		MOVD 336(RSP), R13									
  execution.go:657	0x100214824		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100214828		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021482c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:658	0x100214830		f94087f3		MOVD 264(RSP), R19									
  execution.go:657	0x100214834		b94103f4		MOVWU 256(RSP), R20									
  execution.go:341	0x100214838		f94093f5		MOVD 288(RSP), R21									
  execution.go:460	0x10021483c		b940fff6		MOVWU 252(RSP), R22									
  execution.go:657	0x100214840		b94107f7		MOVWU 260(RSP), R23									
  execution.go:212	0x100214844		aa0103e2		MOVD R1, R2										
  execution.go:212	0x100214848		aa0003e1		MOVD R0, R1										
  execution.go:654	0x10021484c		f94127e0		MOVD 584(RSP), R0									
  execution.go:653	0x100214850		b5002161		CBNZ R1, 267(PC)									
  execution.go:657	0x100214854		f94085d1		MOVD 264(R14), R17									
  execution.go:657	0x100214858		8b170297		ADD R23, R20, R23									
  execution.go:657	0x10021485c		2a1703f7		MOVW R23, R23										
  execution.go:657	0x100214860		eb1102ff		CMP R17, R23										
  execution.go:657	0x100214864		54002e68		BHI 371(PC)										
  execution.go:657	0x100214868		eb17029f		CMP R23, R20										
  execution.go:657	0x10021486c		54002dc8		BHI 366(PC)										
  execution.go:657	0x100214870		f9407dd8		MOVD 248(R14), R24									
  execution.go:657	0x100214874		cb110291		SUB R17, R20, R17									
  execution.go:657	0x100214878		8a91fe91		AND R17->63, R20, R17									
  execution.go:657	0x10021487c		cb1402f4		SUB R20, R23, R20									
  execution.go:657	0x100214880		8b110f11		ADD R17<<3, R24, R17									
  execution.go:657	0x100214884		aa1f03f7		MOVD ZR, R23										
  execution.go:657	0x100214888		14000154		JMP 340(PC)										
  execution.go:751	0x10021488c		b9400e96		MOVWU 12(R20), R22									
  execution.go:751	0x100214890		310006df		CMNW $1, R22										
  execution.go:751	0x100214894		540000c0		BEQ 6(PC)										
  execution.go:752	0x100214898		eb1302df		CMP R19, R22										
  execution.go:752	0x10021489c		54002922		BCS 329(PC)										
  execution.go:752	0x1002148a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:752	0x1002148a4		f94002c2		MOVD (R22), R2										
  execution.go:752	0x1002148a8		14000002		JMP 2(PC)										
  execution.go:752	0x1002148ac		aa1f03e2		MOVD ZR, R2										
  execution.go:754	0x1002148b0		b9401296		MOVWU 16(R20), R22									
  execution.go:754	0x1002148b4		310006df		CMNW $1, R22										
  execution.go:754	0x1002148b8		540000c0		BEQ 6(PC)										
  execution.go:755	0x1002148bc		eb1302df		CMP R19, R22										
  execution.go:755	0x1002148c0		540027a2		BCS 317(PC)										
  execution.go:755	0x1002148c4		8b161196		ADD R22<<4, R12, R22									
  execution.go:755	0x1002148c8		f94002c4		MOVD (R22), R4										
  execution.go:755	0x1002148cc		14000002		JMP 2(PC)										
  execution.go:755	0x1002148d0		aa1f03e4		MOVD ZR, R4										
  execution.go:757	0x1002148d4		b9401696		MOVWU 20(R20), R22									
  execution.go:757	0x1002148d8		310006df		CMNW $1, R22										
  execution.go:757	0x1002148dc		540000c0		BEQ 6(PC)										
  execution.go:758	0x1002148e0		eb1302df		CMP R19, R22										
  execution.go:758	0x1002148e4		54002622		BCS 305(PC)										
  execution.go:758	0x1002148e8		8b161196		ADD R22<<4, R12, R22									
  execution.go:758	0x1002148ec		f94002c6		MOVD (R22), R6										
  execution.go:758	0x1002148f0		14000002		JMP 2(PC)										
  execution.go:758	0x1002148f4		aa1f03e6		MOVD ZR, R6										
  execution.go:762	0x1002148f8		d3507c36		UBFX $16, R1, $16, R22									
  execution.go:762	0x1002148fc		7103fadf		CMPW $254, R22										
  execution.go:762	0x100214900		54000501		BNE 40(PC)										
  execution.go:763	0x100214904		d3403c36		UBFX $0, R1, $16, R22									
  execution.go:763	0x100214908		71000edf		CMPW $3, R22										
  execution.go:763	0x10021490c		54000101		BNE 8(PC)										
  execution.go:764	0x100214910		f9400001		MOVD (R0), R1										
  execution.go:764	0x100214914		f9400420		MOVD 8(R1), R0										
  execution.go:764	0x100214918		97ff9a36		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence(SB)		
  execution.go:770	0x10021491c		aa1f03e2		MOVD ZR, R2										
  execution.go:770	0x100214920		aa1f03e1		MOVD ZR, R1										
  execution.go:770	0x100214924		aa1f03e0		MOVD ZR, R0										
  execution.go:765	0x100214928		1400004b		JMP 75(PC)										
  execution.go:767	0x10021492c		a947e1d7		LDP 120(R14), (R23, R24)								
  execution.go:767	0x100214930		b9400699		MOVWU 4(R20), R25									
  execution.go:767	0x100214934		aa1903fa		MOVD R25, R26										
  execution.go:767	0x100214938		eb18035f		CMP R24, R26										
  execution.go:767	0x10021493c		54002302		BCS 280(PC)										
  execution.go:767	0x100214940		d3787f38		UBFIZ $8, R25, $32, R24									
  execution.go:767	0x100214944		cb1a1718		SUB R26<<5, R24, R24									
  execution.go:767	0x100214948		8b1802f7		ADD R24, R23, R23									
  execution.go:769	0x10021494c		a94765b8		LDP 112(R13), (R24, R25)								
  module.go:178		0x100214950		2942fafa		LDPW 20(R23), (R26, R30)								
  module.go:178		0x100214954		b9401ef7		MOVWU 28(R23), R23									
  module.go:178		0x100214958		aa178357		ORR R23<<32, R26, R23									
  execution.go:769	0x10021495c		eb1903df		CMP R25, R30										
  execution.go:769	0x100214960		54002182		BCS 268(PC)										
  execution.go:769	0x100214964		f87e7b09		MOVD (R24)(R30<<3), R9									
  execution.go:769	0x100214968		f9400929		MOVD 16(R9), R9										
  execution.go:769	0x10021496c		f940080a		MOVD 16(R0), R10									
  execution.go:769	0x100214970		a940040b		LDP (R0), (R11, R1)									
  execution.go:769	0x100214974		f9400563		MOVD 8(R11), R3										
  execution.go:769	0x100214978		aa0903e0		MOVD R9, R0										
  execution.go:769	0x10021497c		aa0203e5		MOVD R2, R5										
  execution.go:769	0x100214980		aa0403e7		MOVD R4, R7										
  execution.go:769	0x100214984		aa0603e8		MOVD R6, R8										
  execution.go:769	0x100214988		aa0a03e2		MOVD R10, R2										
  execution.go:769	0x10021498c		aa1603e4		MOVD R22, R4										
  execution.go:769	0x100214990		aa1703e6		MOVD R23, R6										
  execution.go:769	0x100214994		97ff9e57		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic(SB)		
  execution.go:770	0x100214998		b40005e3		CBZ R3, 47(PC)										
  execution.go:770	0x10021499c		140000bd		JMP 189(PC)										
  execution.go:773	0x1002149a0		d2800108		MOVD $8, R8										
  execution.go:773	0x1002149a4		f2a01f88		MOVK $(252<<16), R8									
  execution.go:773	0x1002149a8		cb080028		SUB R8, R1, R8										
  execution.go:773	0x1002149ac		7100251f		CMPW $9, R8										
  execution.go:773	0x1002149b0		54001e68		BHI 243(PC)										
  execution.go:774	0x1002149b4		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:774	0x1002149b8		b9400697		MOVWU 4(R20), R23									
  execution.go:774	0x1002149bc		aa1703f8		MOVD R23, R24										
  execution.go:774	0x1002149c0		eb16031f		CMP R22, R24										
  execution.go:774	0x1002149c4		54001d62		BCS 235(PC)										
  execution.go:774	0x1002149c8		d3787ee9		UBFIZ $8, R23, $32, R9									
  execution.go:774	0x1002149cc		cb181529		SUB R24<<5, R9, R9									
  execution.go:774	0x1002149d0		8b090108		ADD R9, R8, R8										
  execution.go:776	0x1002149d4		910623e9		ADD $392, RSP, R9									
  execution.go:776	0x1002149d8		ad404510		FLDPQ (R8), (F16, F17)									
  execution.go:776	0x1002149dc		ad004530		FSTPQ (F16, F17), (R9)									
  execution.go:776	0x1002149e0		ad414510		FLDPQ 32(R8), (F16, F17)								
  execution.go:776	0x1002149e4		ad014530		FSTPQ (F16, F17), 32(R9)								
  execution.go:776	0x1002149e8		ad424510		FLDPQ 64(R8), (F16, F17)								
  execution.go:776	0x1002149ec		ad024530		FSTPQ (F16, F17), 64(R9)								
  execution.go:776	0x1002149f0		ad434510		FLDPQ 96(R8), (F16, F17)								
  execution.go:776	0x1002149f4		ad034530		FSTPQ (F16, F17), 96(R9)								
  execution.go:776	0x1002149f8		ad444510		FLDPQ 128(R8), (F16, F17)								
  execution.go:776	0x1002149fc		ad044530		FSTPQ (F16, F17), 128(R9)								
  execution.go:776	0x100214a00		f9405119		MOVD 160(R8), R25									
  execution.go:776	0x100214a04		f9005139		MOVD R25, 160(R9)									
  execution.go:776	0x100214a08		910023e8		ADD $8, RSP, R8										
  execution.go:776	0x100214a0c		ad404530		FLDPQ (R9), (F16, F17)									
  execution.go:776	0x100214a10		ad004510		FSTPQ (F16, F17), (R8)									
  execution.go:776	0x100214a14		ad414530		FLDPQ 32(R9), (F16, F17)								
  execution.go:776	0x100214a18		ad014510		FSTPQ (F16, F17), 32(R8)								
  execution.go:776	0x100214a1c		ad424530		FLDPQ 64(R9), (F16, F17)								
  execution.go:776	0x100214a20		ad024510		FSTPQ (F16, F17), 64(R8)								
  execution.go:776	0x100214a24		ad434530		FLDPQ 96(R9), (F16, F17)								
  execution.go:776	0x100214a28		ad034510		FSTPQ (F16, F17), 96(R8)								
  execution.go:776	0x100214a2c		ad444530		FLDPQ 128(R9), (F16, F17)								
  execution.go:776	0x100214a30		ad044510		FSTPQ (F16, F17), 128(R8)								
  execution.go:776	0x100214a34		f9405139		MOVD 160(R9), R25									
  execution.go:776	0x100214a38		f9005119		MOVD R25, 160(R8)									
  execution.go:776	0x100214a3c		aa0d03e1		MOVD R13, R1										
  execution.go:776	0x100214a40		aa1f03e3		MOVD ZR, R3										
  execution.go:776	0x100214a44		aa1f03e5		MOVD ZR, R5										
  execution.go:776	0x100214a48		aa1f03e7		MOVD ZR, R7										
  execution.go:776	0x100214a4c		97fff0c1		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk(SB)		
  execution.go:777	0x100214a50		b5001703		CBNZ R3, 184(PC)									
  execution.go:342	0x100214a54		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100214a58		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100214a5c		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100214a60		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100214a64		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100214a68		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100214a6c		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100214a70		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100214a74		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100214a78		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100214a7c		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100214a80		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100214a84		aa0103f7		MOVD R1, R23										
  execution.go:704	0x100214a88		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100214a8c		aa0203e1		MOVD R2, R1										
  execution.go:209	0x100214a90		f94127e0		MOVD 584(RSP), R0									
  execution.go:785	0x100214a94		d3401c38		UBFX $0, R1, $8, R24									
  execution.go:785	0x100214a98		350010d8		CBNZW R24, 134(PC)									
  execution.go:789	0x100214a9c		b9400a94		MOVWU 8(R20), R20									
  execution.go:789	0x100214aa0		3100069f		CMNW $1, R20										
  execution.go:789	0x100214aa4		540000a0		BEQ 5(PC)										
  execution.go:790	0x100214aa8		eb13029f		CMP R19, R20										
  execution.go:790	0x100214aac		540015c2		BCS 174(PC)										
  execution.go:790	0x100214ab0		8b141194		ADD R20<<4, R12, R20									
  execution.go:790	0x100214ab4		a9005e96		STP (R22, R23), (R20)									
  execution.go:792	0x100214ab8		91000631		ADD $1, R17, R17									
  execution.go:793	0x100214abc		17fff90e		JMP -1778(PC)										
  execution.go:466	0x100214ac0		b9000951		MOVW R17, 8(R10)									
  execution.go:467	0x100214ac4		94000827		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:467	0x100214ac8		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:467	0x100214acc		34ff1d21		CBZW R1, -1815(PC)									
  execution.go:467	0x100214ad0		1400003b		JMP 59(PC)										
  execution.go:664	0x100214ad4		b9000951		MOVW R17, 8(R10)									
  execution.go:665	0x100214ad8		94000dde		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow(SB)	
  execution.go:665	0x100214adc		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:665	0x100214ae0		34ff1c81		CBZW R1, -1820(PC)									
  execution.go:665	0x100214ae4		1400005a		JMP 90(PC)										
  execution.go:744	0x100214ae8		b9000951		MOVW R17, 8(R10)									
  execution.go:745	0x100214aec		94000abd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB)		
  execution.go:745	0x100214af0		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:745	0x100214af4		34ff1be1		CBZW R1, -1825(PC)									
  execution.go:745	0x100214af8		14000059		JMP 89(PC)										
  execution.go:623	0x100214afc		b9000951		MOVW R17, 8(R10)									
  execution.go:624	0x100214b00		94000eb0		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame(SB)	
  execution.go:624	0x100214b04		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:624	0x100214b08		34ff1b41		CBZW R1, -1830(PC)									
  execution.go:624	0x100214b0c		14000058		JMP 88(PC)										
  execution.go:629	0x100214b10		b9000951		MOVW R17, 8(R10)									
  execution.go:630	0x100214b14		94000813		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:630	0x100214b18		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:630	0x100214b1c		34ff1aa1		CBZW R1, -1835(PC)									
  execution.go:630	0x100214b20		1400008c		JMP 140(PC)										
  execution.go:343	0x100214b24		f9009ff5		MOVD R21, 312(RSP)									
  execution.go:341	0x100214b28		f90097e1		MOVD R1, 296(RSP)									
  execution.go:346	0x100214b2c		d2800500		MOVD $40, R0										
  execution.go:346	0x100214b30		f0001241		ADRP 2404352(PC), R1									
  execution.go:346	0x100214b34		910ee021		ADD $952, R1, R1									
  execution.go:346	0x100214b38		b24003e2		ORR $1, ZR, R2										
  execution.go:346	0x100214b3c		97f82031		CALL runtime.mallocgcSmallScanNoHeaderSC5(SB)						
  execution.go:346	0x100214b40		f000139b		ADRP 2568192(PC), R27									
  execution.go:346	0x100214b44		9104437b		ADD $272, R27, R27									
  execution.go:346	0x100214b48		a9401363		LDP (R27), (R3, R4)									
  execution.go:346	0x100214b4c		f9000003		MOVD R3, (R0)										
  execution.go:346	0x100214b50		9000151b		ADRP 2752512(PC), R27									
  execution.go:346	0x100214b54		b94ef363		MOVWU 3824(R27), R3									
  execution.go:346	0x100214b58		34000063		CBZW R3, 3(PC)										
  execution.go:346	0x100214b5c		97f9b9c1		CALL runtime.gcWriteBarrier1(SB)							
  execution.go:346	0x100214b60		f9000324		MOVD R4, (R25)										
  execution.go:346	0x100214b64		f9000404		MOVD R4, 8(R0)										
  execution.go:346	0x100214b68		f9409fe3		MOVD 312(RSP), R3									
  execution.go:346	0x100214b6c		f9400463		MOVD 8(R3), R3										
  execution.go:346	0x100214b70		90000104		ADRP 131072(PC), R4									
  execution.go:346	0x100214b74		91033c84		ADD $207, R4, R4									
  execution.go:346	0x100214b78		a9011003		STP (R3, R4), 16(R0)									
  execution.go:346	0x100214b7c		b27f0be3		ORR $14, ZR, R3										
  execution.go:346	0x100214b80		f9001003		MOVD R3, 32(R0)										
  execution.go:346	0x100214b84		90001321		ADRP 2506752(PC), R1									
  execution.go:346	0x100214b88		911f4021		ADD $2000, R1, R1									
  execution.go:346	0x100214b8c		aa0003e2		MOVD R0, R2										
  execution.go:346	0x100214b90		f94127e0		MOVD 584(RSP), R0									
  execution.go:346	0x100214b94		97fff63f		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:346	0x100214b98		f94097e1		MOVD 296(RSP), R1									
  execution.go:346	0x100214b9c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:346	0x100214ba0		910903ff		ADD $576, RSP, RSP									
  execution.go:346	0x100214ba4		d65f03c0		RET											
  execution.go:353	0x100214ba8		97fff63a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:353	0x100214bac		f94097e1		MOVD 296(RSP), R1									
  execution.go:353	0x100214bb0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:353	0x100214bb4		910903ff		ADD $576, RSP, RSP									
  execution.go:353	0x100214bb8		d65f03c0		RET											
  execution.go:468	0x100214bbc		f94093e1		MOVD 288(RSP), R1									
  execution.go:468	0x100214bc0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:468	0x100214bc4		910903ff		ADD $576, RSP, RSP									
  execution.go:468	0x100214bc8		d65f03c0		RET											
  execution.go:412	0x100214bcc		f900bbe3		MOVD R3, 368(RSP)									
  execution.go:412	0x100214bd0		f9008fe2		MOVD R2, 280(RSP)									
  execution.go:414	0x100214bd4		b27d03e0		ORR $8, ZR, R0										
  execution.go:414	0x100214bd8		b00010a1		ADRP 2183168(PC), R1									
  execution.go:414	0x100214bdc		91064021		ADD $400, R1, R1									
  execution.go:414	0x100214be0		b24003e2		ORR $1, ZR, R2										
  execution.go:414	0x100214be4		97f81cd3		CALL runtime.mallocgcSmallScanNoHeaderSC1(SB)						
  execution.go:414	0x100214be8		f9011be0		MOVD R0, 560(RSP)									
  execution.go:415	0x100214bec		f940bbe1		MOVD 368(RSP), R1									
  execution.go:415	0x100214bf0		d0000fe2		ADRP 2088960(PC), R2									
  execution.go:415	0x100214bf4		91276042		ADD $2520, R2, R2									
  execution.go:415	0x100214bf8		aa0003e3		MOVD R0, R3										
  execution.go:415	0x100214bfc		f9408fe0		MOVD 280(RSP), R0									
  execution.go:415	0x100214c00		97f9cd7c		CALL errors.As(SB)									
  execution.go:415	0x100214c04		360000c0		TBZ $0, R0, 6(PC)									
  execution.go:416	0x100214c08		f9411be3		MOVD 560(RSP), R3									
  execution.go:416	0x100214c0c		f9400063		MOVD (R3), R3										
  execution.go:416	0x100214c10		f940b3e4		MOVD 352(RSP), R4									
  execution.go:416	0x100214c14		b9405084		MOVWU 80(R4), R4									
  execution.go:416	0x100214c18		b9000464		MOVW R4, 4(R3)										
  execution.go:418	0x100214c1c		f94127e0		MOVD 584(RSP), R0									
  execution.go:418	0x100214c20		f9408fe1		MOVD 280(RSP), R1									
  execution.go:418	0x100214c24		f940bbe2		MOVD 368(RSP), R2									
  execution.go:418	0x100214c28		97fff61a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:418	0x100214c2c		f94093e1		MOVD 288(RSP), R1									
  execution.go:418	0x100214c30		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:418	0x100214c34		910903ff		ADD $576, RSP, RSP									
  execution.go:418	0x100214c38		d65f03c0		RET											
  execution.go:426	0x100214c3c		f94093e1		MOVD 288(RSP), R1									
  execution.go:426	0x100214c40		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:426	0x100214c44		910903ff		ADD $576, RSP, RSP									
  execution.go:426	0x100214c48		d65f03c0		RET											
  execution.go:666	0x100214c4c		f94093e1		MOVD 288(RSP), R1									
  execution.go:666	0x100214c50		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:666	0x100214c54		910903ff		ADD $576, RSP, RSP									
  execution.go:666	0x100214c58		d65f03c0		RET											
  execution.go:746	0x100214c5c		f94093e1		MOVD 288(RSP), R1									
  execution.go:746	0x100214c60		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:746	0x100214c64		910903ff		ADD $576, RSP, RSP									
  execution.go:746	0x100214c68		d65f03c0		RET											
  execution.go:625	0x100214c6c		f94093e1		MOVD 288(RSP), R1									
  execution.go:625	0x100214c70		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:625	0x100214c74		910903ff		ADD $576, RSP, RSP									
  execution.go:625	0x100214c78		d65f03c0		RET											
  execution.go:654	0x100214c7c		97fff605		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:654	0x100214c80		f94093e1		MOVD 288(RSP), R1									
  execution.go:654	0x100214c84		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:654	0x100214c88		910903ff		ADD $576, RSP, RSP									
  execution.go:654	0x100214c8c		d65f03c0		RET											
  execution.go:771	0x100214c90		f94127e0		MOVD 584(RSP), R0									
  execution.go:771	0x100214c94		aa0303e1		MOVD R3, R1										
  execution.go:771	0x100214c98		aa0403e2		MOVD R4, R2										
  execution.go:771	0x100214c9c		97fff5fd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:771	0x100214ca0		f94093e1		MOVD 288(RSP), R1									
  execution.go:771	0x100214ca4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:771	0x100214ca8		910903ff		ADD $576, RSP, RSP									
  execution.go:771	0x100214cac		d65f03c0		RET											
  execution.go:395	0x100214cb0		3903dbe1		MOVB R1, 246(RSP)									
  execution.go:786	0x100214cb4		b27c03e0		ORR $16, ZR, R0										
  execution.go:786	0x100214cb8		f0001241		ADRP 2404352(PC), R1									
  execution.go:786	0x100214cbc		91118021		ADD $1120, R1, R1									
  execution.go:786	0x100214cc0		b24003e2		ORR $1, ZR, R2										
  execution.go:786	0x100214cc4		97f82353		CALL runtime.mallocgcSmallNoScanSC2(SB)							
  execution.go:786	0x100214cc8		3943dbe3		MOVBU 246(RSP), R3									
  execution.go:786	0x100214ccc		39000003		MOVB R3, (R0)										
  execution.go:786	0x100214cd0		f940b3e3		MOVD 352(RSP), R3									
  execution.go:786	0x100214cd4		b9405063		MOVWU 80(R3), R3									
  execution.go:786	0x100214cd8		b9000403		MOVW R3, 4(R0)										
  execution.go:786	0x100214cdc		f940bfe3		MOVD 376(RSP), R3									
  execution.go:786	0x100214ce0		a9479063		LDP 120(R3), (R3, R4)									
  execution.go:786	0x100214ce4		f940c3e5		MOVD 384(RSP), R5									
  execution.go:786	0x100214ce8		b94004a5		MOVWU 4(R5), R5										
  execution.go:786	0x100214cec		aa0503e6		MOVD R5, R6										
  execution.go:786	0x100214cf0		eb0400df		CMP R4, R6										
  execution.go:786	0x100214cf4		54000362		BCS 27(PC)										
  execution.go:786	0x100214cf8		d3787ca4		UBFIZ $8, R5, $32, R4									
  execution.go:786	0x100214cfc		cb061484		SUB R6<<5, R4, R4									
  execution.go:786	0x100214d00		8b040063		ADD R4, R3, R3										
  execution.go:786	0x100214d04		f9400463		MOVD 8(R3), R3										
  execution.go:786	0x100214d08		f9000403		MOVD R3, 8(R0)										
  execution.go:786	0x100214d0c		90001321		ADRP 2506752(PC), R1									
  execution.go:786	0x100214d10		91204021		ADD $2064, R1, R1									
  execution.go:786	0x100214d14		aa0003e2		MOVD R0, R2										
  execution.go:786	0x100214d18		f94127e0		MOVD 584(RSP), R0									
  execution.go:786	0x100214d1c		97fff5dd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:786	0x100214d20		f94093e1		MOVD 288(RSP), R1									
  execution.go:786	0x100214d24		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:786	0x100214d28		910903ff		ADD $576, RSP, RSP									
  execution.go:786	0x100214d2c		d65f03c0		RET											
  execution.go:778	0x100214d30		f94127e0		MOVD 584(RSP), R0									
  execution.go:778	0x100214d34		aa0303e1		MOVD R3, R1										
  execution.go:778	0x100214d38		aa0403e2		MOVD R4, R2										
  execution.go:778	0x100214d3c		97fff5d5		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:778	0x100214d40		f94093e1		MOVD 288(RSP), R1									
  execution.go:778	0x100214d44		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:778	0x100214d48		910903ff		ADD $576, RSP, RSP									
  execution.go:778	0x100214d4c		d65f03c0		RET											
  execution.go:631	0x100214d50		f94093e1		MOVD 288(RSP), R1									
  execution.go:631	0x100214d54		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:631	0x100214d58		910903ff		ADD $576, RSP, RSP									
  execution.go:631	0x100214d5c		d65f03c0		RET											
  execution.go:786	0x100214d60		97f9b9f8		CALL runtime.panicBounds(SB)								
  execution.go:790	0x100214d64		aa1403e0		MOVD R20, R0										
  execution.go:790	0x100214d68		aa1303e1		MOVD R19, R1										
  execution.go:790	0x100214d6c		97f9b9f5		CALL runtime.panicBounds(SB)								
  execution.go:774	0x100214d70		aa1803e0		MOVD R24, R0										
  execution.go:774	0x100214d74		aa1603e1		MOVD R22, R1										
  execution.go:774	0x100214d78		97f9b9f2		CALL runtime.panicBounds(SB)								
  execution.go:781	0x100214d7c		900011a0		ADRP 2310144(PC), R0									
  execution.go:781	0x100214d80		912aa000		ADD $2728, R0, R0									
  execution.go:781	0x100214d84		90000fc1		ADRP 2064384(PC), R1									
  execution.go:781	0x100214d88		91294021		ADD $2640, R1, R1									
  execution.go:781	0x100214d8c		97f99e81		CALL runtime.gopanic(SB)								
  execution.go:769	0x100214d90		aa1e03e0		MOVD R30, R0										
  execution.go:769	0x100214d94		aa1903e1		MOVD R25, R1										
  execution.go:769	0x100214d98		97f9b9ea		CALL runtime.panicBounds(SB)								
  execution.go:767	0x100214d9c		aa1a03e0		MOVD R26, R0										
  execution.go:767	0x100214da0		aa1803e1		MOVD R24, R1										
  execution.go:767	0x100214da4		97f9b9e7		CALL runtime.panicBounds(SB)								
  execution.go:758	0x100214da8		aa1603e0		MOVD R22, R0										
  execution.go:758	0x100214dac		aa1303e1		MOVD R19, R1										
  execution.go:758	0x100214db0		97f9b9e4		CALL runtime.panicBounds(SB)								
  execution.go:755	0x100214db4		aa1603e0		MOVD R22, R0										
  execution.go:755	0x100214db8		aa1303e1		MOVD R19, R1										
  execution.go:755	0x100214dbc		97f9b9e1		CALL runtime.panicBounds(SB)								
  execution.go:752	0x100214dc0		aa1603e0		MOVD R22, R0										
  execution.go:752	0x100214dc4		aa1303e1		MOVD R19, R1										
  execution.go:752	0x100214dc8		97f9b9de		CALL runtime.panicBounds(SB)								
  execution.go:658	0x100214dcc		8b181198		ADD R24<<4, R12, R24									
  execution.go:658	0x100214dd0		a9006b19		STP (R25, R26), (R24)									
  execution.go:657	0x100214dd4		910006f7		ADD $1, R23, R23									
  execution.go:657	0x100214dd8		eb1402ff		CMP R20, R23										
  execution.go:657	0x100214ddc		5400014a		BGE 10(PC)										
  execution.go:657	0x100214de0		8b170e38		ADD R23<<3, R17, R24									
  execution.go:657	0x100214de4		29406718		LDPW (R24), (R24, R25)									
  execution.go:658	0x100214de8		eb13033f		CMP R19, R25										
  execution.go:658	0x100214dec		54000162		BCS 11(PC)										
  execution.go:658	0x100214df0		8b191199		ADD R25<<4, R12, R25									
  execution.go:658	0x100214df4		a9406b39		LDP (R25), (R25, R26)									
  execution.go:658	0x100214df8		eb13031f		CMP R19, R24										
  execution.go:658	0x100214dfc		54fffe83		BCC -12(PC)										
  execution.go:658	0x100214e00		14000003		JMP 3(PC)										
  execution.go:460	0x100214e04		aa1603f1		MOVD R22, R17										
  execution.go:661	0x100214e08		17fff83b		JMP -1989(PC)										
  execution.go:658	0x100214e0c		aa1803e0		MOVD R24, R0										
  execution.go:658	0x100214e10		aa1303e1		MOVD R19, R1										
  execution.go:658	0x100214e14		97f9b9cb		CALL runtime.panicBounds(SB)								
  execution.go:658	0x100214e18		aa1903e0		MOVD R25, R0										
  execution.go:658	0x100214e1c		aa1303e1		MOVD R19, R1										
  execution.go:658	0x100214e20		97f9b9c8		CALL runtime.panicBounds(SB)								
  execution.go:657	0x100214e24		aa1403e0		MOVD R20, R0										
  execution.go:657	0x100214e28		aa1703e1		MOVD R23, R1										
  execution.go:657	0x100214e2c		97f9b9c5		CALL runtime.panicBounds(SB)								
  execution.go:657	0x100214e30		aa1703e0		MOVD R23, R0										
  execution.go:657	0x100214e34		aa1103e1		MOVD R17, R1										
  execution.go:657	0x100214e38		97f9b9c2		CALL runtime.panicBounds(SB)								
  execution.go:651	0x100214e3c		aa1603e0		MOVD R22, R0										
  execution.go:651	0x100214e40		aa1803e1		MOVD R24, R1										
  execution.go:651	0x100214e44		97f9b9bf		CALL runtime.panicBounds(SB)								
  execution.go:646	0x100214e48		aa1703e0		MOVD R23, R0										
  execution.go:646	0x100214e4c		aa1303e1		MOVD R19, R1										
  execution.go:646	0x100214e50		97f9b9bc		CALL runtime.panicBounds(SB)								
  execution.go:643	0x100214e54		aa1803e0		MOVD R24, R0										
  execution.go:643	0x100214e58		aa1303e1		MOVD R19, R1										
  execution.go:643	0x100214e5c		97f9b9b9		CALL runtime.panicBounds(SB)								
  execution.go:641	0x100214e60		aa1803e0		MOVD R24, R0										
  execution.go:641	0x100214e64		aa1303e1		MOVD R19, R1										
  execution.go:641	0x100214e68		97f9b9b6		CALL runtime.panicBounds(SB)								
  execution.go:725	0x100214e6c		aa1303e0		MOVD R19, R0										
  execution.go:725	0x100214e70		97f9b9b4		CALL runtime.panicBounds(SB)								
  execution.go:732	0x100214e74		aa1603e0		MOVD R22, R0										
  execution.go:732	0x100214e78		aa1303e1		MOVD R19, R1										
  execution.go:732	0x100214e7c		97f9b9b1		CALL runtime.panicBounds(SB)								
  execution.go:727	0x100214e80		aa1703e0		MOVD R23, R0										
  execution.go:727	0x100214e84		aa1303e1		MOVD R19, R1										
  execution.go:727	0x100214e88		97f9b9ae		CALL runtime.panicBounds(SB)								
  execution.go:727	0x100214e8c		aa1603e0		MOVD R22, R0										
  execution.go:727	0x100214e90		aa1303e1		MOVD R19, R1										
  execution.go:727	0x100214e94		97f9b9ab		CALL runtime.panicBounds(SB)								
  execution.go:742	0x100214e98		aa1803e0		MOVD R24, R0										
  execution.go:742	0x100214e9c		aa1703e1		MOVD R23, R1										
  execution.go:742	0x100214ea0		97f9b9a8		CALL runtime.panicBounds(SB)								
  execution.go:738	0x100214ea4		aa1603e0		MOVD R22, R0										
  execution.go:738	0x100214ea8		aa1303e1		MOVD R19, R1										
  execution.go:738	0x100214eac		97f9b9a5		CALL runtime.panicBounds(SB)								
  execution.go:710	0x100214eb0		97f9b9a4		CALL runtime.panicBounds(SB)								
  execution.go:713	0x100214eb4		aa1303e0		MOVD R19, R0										
  execution.go:713	0x100214eb8		97f9b9a2		CALL runtime.panicBounds(SB)								
  execution.go:712	0x100214ebc		97f9b9a1		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100214ec0		aa1603e0		MOVD R22, R0										
  execution.go:708	0x100214ec4		aa1303e1		MOVD R19, R1										
  execution.go:708	0x100214ec8		97f9b99e		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100214ecc		aa1703e0		MOVD R23, R0										
  execution.go:708	0x100214ed0		97f9b99c		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100214ed4		aa1303e0		MOVD R19, R0										
  execution.go:708	0x100214ed8		97f9b99a		CALL runtime.panicBounds(SB)								
  execution.go:707	0x100214edc		aa1703e0		MOVD R23, R0										
  execution.go:707	0x100214ee0		97f9b998		CALL runtime.panicBounds(SB)								
  execution.go:704	0x100214ee4		aa1303e0		MOVD R19, R0										
  execution.go:704	0x100214ee8		97f9b996		CALL runtime.panicBounds(SB)								
  execution.go:704	0x100214eec		aa1803e0		MOVD R24, R0										
  execution.go:704	0x100214ef0		aa1603e1		MOVD R22, R1										
  execution.go:704	0x100214ef4		97f9b993		CALL runtime.panicBounds(SB)								
  execution.go:703	0x100214ef8		aa1703e0		MOVD R23, R0										
  execution.go:703	0x100214efc		97f9b991		CALL runtime.panicBounds(SB)								
  execution.go:699	0x100214f00		aa1803e0		MOVD R24, R0										
  execution.go:699	0x100214f04		aa1303e1		MOVD R19, R1										
  execution.go:699	0x100214f08		97f9b98e		CALL runtime.panicBounds(SB)								
  execution.go:695	0x100214f0c		aa1703e0		MOVD R23, R0										
  execution.go:695	0x100214f10		aa1303e1		MOVD R19, R1										
  execution.go:695	0x100214f14		97f9b98b		CALL runtime.panicBounds(SB)								
  execution.go:694	0x100214f18		aa1803e0		MOVD R24, R0										
  execution.go:694	0x100214f1c		aa1703e1		MOVD R23, R1										
  execution.go:694	0x100214f20		97f9b988		CALL runtime.panicBounds(SB)								
  execution.go:687	0x100214f24		aa1703e0		MOVD R23, R0										
  execution.go:687	0x100214f28		aa1303e1		MOVD R19, R1										
  execution.go:687	0x100214f2c		97f9b985		CALL runtime.panicBounds(SB)								
  execution.go:686	0x100214f30		aa1803e0		MOVD R24, R0										
  execution.go:686	0x100214f34		aa1703e1		MOVD R23, R1										
  execution.go:686	0x100214f38		97f9b982		CALL runtime.panicBounds(SB)								
  execution.go:684	0x100214f3c		aa1903e0		MOVD R25, R0										
  execution.go:684	0x100214f40		aa1803e1		MOVD R24, R1										
  execution.go:684	0x100214f44		97f9b97f		CALL runtime.panicBounds(SB)								
  execution.go:684	0x100214f48		aa1603e0		MOVD R22, R0										
  execution.go:684	0x100214f4c		aa1303e1		MOVD R19, R1										
  execution.go:684	0x100214f50		97f9b97c		CALL runtime.panicBounds(SB)								
  execution.go:682	0x100214f54		aa1803e0		MOVD R24, R0										
  execution.go:682	0x100214f58		aa1703e1		MOVD R23, R1										
  execution.go:682	0x100214f5c		97f9b979		CALL runtime.panicBounds(SB)								
  execution.go:680	0x100214f60		aa1803e0		MOVD R24, R0										
  execution.go:680	0x100214f64		aa1303e1		MOVD R19, R1										
  execution.go:680	0x100214f68		97f9b976		CALL runtime.panicBounds(SB)								
  execution.go:679	0x100214f6c		aa1603e0		MOVD R22, R0										
  execution.go:679	0x100214f70		aa1303e1		MOVD R19, R1										
  execution.go:679	0x100214f74		97f9b973		CALL runtime.panicBounds(SB)								
  execution.go:677	0x100214f78		aa1603e0		MOVD R22, R0										
  execution.go:677	0x100214f7c		aa1303e1		MOVD R19, R1										
  execution.go:677	0x100214f80		97f9b970		CALL runtime.panicBounds(SB)								
  execution.go:675	0x100214f84		aa1603e0		MOVD R22, R0										
  execution.go:675	0x100214f88		aa1303e1		MOVD R19, R1										
  execution.go:675	0x100214f8c		97f9b96d		CALL runtime.panicBounds(SB)								
  execution.go:672	0x100214f90		aa1703e0		MOVD R23, R0										
  execution.go:672	0x100214f94		aa1303e1		MOVD R19, R1										
  execution.go:672	0x100214f98		97f9b96a		CALL runtime.panicBounds(SB)								
  execution.go:600	0x100214f9c		aa1603e0		MOVD R22, R0										
  execution.go:600	0x100214fa0		aa1303e1		MOVD R19, R1										
  execution.go:600	0x100214fa4		97f9b967		CALL runtime.panicBounds(SB)								
  execution.go:598	0x100214fa8		aa1603e0		MOVD R22, R0										
  execution.go:598	0x100214fac		aa1303e1		MOVD R19, R1										
  execution.go:598	0x100214fb0		97f9b964		CALL runtime.panicBounds(SB)								
  execution.go:596	0x100214fb4		aa1603e0		MOVD R22, R0										
  execution.go:596	0x100214fb8		aa1303e1		MOVD R19, R1										
  execution.go:596	0x100214fbc		97f9b961		CALL runtime.panicBounds(SB)								
  execution.go:594	0x100214fc0		aa1603e0		MOVD R22, R0										
  execution.go:594	0x100214fc4		aa1303e1		MOVD R19, R1										
  execution.go:594	0x100214fc8		97f9b95e		CALL runtime.panicBounds(SB)								
  execution.go:592	0x100214fcc		aa1603e0		MOVD R22, R0										
  execution.go:592	0x100214fd0		aa1303e1		MOVD R19, R1										
  execution.go:592	0x100214fd4		97f9b95b		CALL runtime.panicBounds(SB)								
  execution.go:614	0x100214fd8		aa1303e0		MOVD R19, R0										
  execution.go:614	0x100214fdc		97f9b959		CALL runtime.panicBounds(SB)								
  execution.go:612	0x100214fe0		aa1303e0		MOVD R19, R0										
  execution.go:612	0x100214fe4		97f9b957		CALL runtime.panicBounds(SB)								
  execution.go:590	0x100214fe8		aa1603e0		MOVD R22, R0										
  execution.go:590	0x100214fec		aa1303e1		MOVD R19, R1										
  execution.go:590	0x100214ff0		97f9b954		CALL runtime.panicBounds(SB)								
  execution.go:588	0x100214ff4		aa1603e0		MOVD R22, R0										
  execution.go:588	0x100214ff8		aa1303e1		MOVD R19, R1										
  execution.go:588	0x100214ffc		97f9b951		CALL runtime.panicBounds(SB)								
  execution.go:586	0x100215000		aa1603e0		MOVD R22, R0										
  execution.go:586	0x100215004		aa1303e1		MOVD R19, R1										
  execution.go:586	0x100215008		97f9b94e		CALL runtime.panicBounds(SB)								
  execution.go:584	0x10021500c		aa1703e0		MOVD R23, R0										
  execution.go:584	0x100215010		aa1303e1		MOVD R19, R1										
  execution.go:584	0x100215014		97f9b94b		CALL runtime.panicBounds(SB)								
  execution.go:584	0x100215018		aa1603e0		MOVD R22, R0										
  execution.go:584	0x10021501c		aa1303e1		MOVD R19, R1										
  execution.go:584	0x100215020		97f9b948		CALL runtime.panicBounds(SB)								
  execution.go:582	0x100215024		aa1703e0		MOVD R23, R0										
  execution.go:582	0x100215028		aa1303e1		MOVD R19, R1										
  execution.go:582	0x10021502c		97f9b945		CALL runtime.panicBounds(SB)								
  execution.go:582	0x100215030		aa1603e0		MOVD R22, R0										
  execution.go:582	0x100215034		aa1303e1		MOVD R19, R1										
  execution.go:582	0x100215038		97f9b942		CALL runtime.panicBounds(SB)								
  execution.go:580	0x10021503c		aa1703e0		MOVD R23, R0										
  execution.go:580	0x100215040		aa1303e1		MOVD R19, R1										
  execution.go:580	0x100215044		97f9b93f		CALL runtime.panicBounds(SB)								
  execution.go:580	0x100215048		aa1603e0		MOVD R22, R0										
  execution.go:580	0x10021504c		aa1303e1		MOVD R19, R1										
  execution.go:580	0x100215050		97f9b93c		CALL runtime.panicBounds(SB)								
  execution.go:578	0x100215054		aa1703e0		MOVD R23, R0										
  execution.go:578	0x100215058		aa1303e1		MOVD R19, R1										
  execution.go:578	0x10021505c		97f9b939		CALL runtime.panicBounds(SB)								
  execution.go:578	0x100215060		aa1603e0		MOVD R22, R0										
  execution.go:578	0x100215064		aa1303e1		MOVD R19, R1										
  execution.go:578	0x100215068		97f9b936		CALL runtime.panicBounds(SB)								
  execution.go:576	0x10021506c		aa1703e0		MOVD R23, R0										
  execution.go:576	0x100215070		aa1303e1		MOVD R19, R1										
  execution.go:576	0x100215074		97f9b933		CALL runtime.panicBounds(SB)								
  execution.go:576	0x100215078		aa1603e0		MOVD R22, R0										
  execution.go:576	0x10021507c		aa1303e1		MOVD R19, R1										
  execution.go:576	0x100215080		97f9b930		CALL runtime.panicBounds(SB)								
  execution.go:574	0x100215084		aa1703e0		MOVD R23, R0										
  execution.go:574	0x100215088		aa1303e1		MOVD R19, R1										
  execution.go:574	0x10021508c		97f9b92d		CALL runtime.panicBounds(SB)								
  execution.go:574	0x100215090		aa1603e0		MOVD R22, R0										
  execution.go:574	0x100215094		aa1303e1		MOVD R19, R1										
  execution.go:574	0x100215098		97f9b92a		CALL runtime.panicBounds(SB)								
  execution.go:572	0x10021509c		aa1703e0		MOVD R23, R0										
  execution.go:572	0x1002150a0		aa1303e1		MOVD R19, R1										
  execution.go:572	0x1002150a4		97f9b927		CALL runtime.panicBounds(SB)								
  execution.go:572	0x1002150a8		aa1603e0		MOVD R22, R0										
  execution.go:572	0x1002150ac		aa1303e1		MOVD R19, R1										
  execution.go:572	0x1002150b0		97f9b924		CALL runtime.panicBounds(SB)								
  execution.go:570	0x1002150b4		aa1703e0		MOVD R23, R0										
  execution.go:570	0x1002150b8		aa1303e1		MOVD R19, R1										
  execution.go:570	0x1002150bc		97f9b921		CALL runtime.panicBounds(SB)								
  execution.go:570	0x1002150c0		aa1603e0		MOVD R22, R0										
  execution.go:570	0x1002150c4		aa1303e1		MOVD R19, R1										
  execution.go:570	0x1002150c8		97f9b91e		CALL runtime.panicBounds(SB)								
  execution.go:568	0x1002150cc		aa1703e0		MOVD R23, R0										
  execution.go:568	0x1002150d0		aa1303e1		MOVD R19, R1										
  execution.go:568	0x1002150d4		97f9b91b		CALL runtime.panicBounds(SB)								
  execution.go:568	0x1002150d8		aa1603e0		MOVD R22, R0										
  execution.go:568	0x1002150dc		aa1303e1		MOVD R19, R1										
  execution.go:568	0x1002150e0		97f9b918		CALL runtime.panicBounds(SB)								
  execution.go:566	0x1002150e4		aa1703e0		MOVD R23, R0										
  execution.go:566	0x1002150e8		aa1303e1		MOVD R19, R1										
  execution.go:566	0x1002150ec		97f9b915		CALL runtime.panicBounds(SB)								
  execution.go:566	0x1002150f0		aa1603e0		MOVD R22, R0										
  execution.go:566	0x1002150f4		aa1303e1		MOVD R19, R1										
  execution.go:566	0x1002150f8		97f9b912		CALL runtime.panicBounds(SB)								
  execution.go:564	0x1002150fc		aa1703e0		MOVD R23, R0										
  execution.go:564	0x100215100		aa1303e1		MOVD R19, R1										
  execution.go:564	0x100215104		97f9b90f		CALL runtime.panicBounds(SB)								
  execution.go:564	0x100215108		aa1603e0		MOVD R22, R0										
  execution.go:564	0x10021510c		aa1303e1		MOVD R19, R1										
  execution.go:564	0x100215110		97f9b90c		CALL runtime.panicBounds(SB)								
  execution.go:532	0x100215114		aa1603e0		MOVD R22, R0										
  execution.go:532	0x100215118		aa1303e1		MOVD R19, R1										
  execution.go:532	0x10021511c		97f9b909		CALL runtime.panicBounds(SB)								
  execution.go:562	0x100215120		aa1603e0		MOVD R22, R0										
  execution.go:562	0x100215124		aa1303e1		MOVD R19, R1										
  execution.go:562	0x100215128		97f9b906		CALL runtime.panicBounds(SB)								
  execution.go:560	0x10021512c		aa1603e0		MOVD R22, R0										
  execution.go:560	0x100215130		aa1303e1		MOVD R19, R1										
  execution.go:560	0x100215134		97f9b903		CALL runtime.panicBounds(SB)								
  execution.go:558	0x100215138		aa1703e0		MOVD R23, R0										
  execution.go:558	0x10021513c		aa1303e1		MOVD R19, R1										
  execution.go:558	0x100215140		97f9b900		CALL runtime.panicBounds(SB)								
  execution.go:558	0x100215144		aa1603e0		MOVD R22, R0										
  execution.go:558	0x100215148		aa1303e1		MOVD R19, R1										
  execution.go:558	0x10021514c		97f9b8fd		CALL runtime.panicBounds(SB)								
  execution.go:556	0x100215150		aa1703e0		MOVD R23, R0										
  execution.go:556	0x100215154		aa1303e1		MOVD R19, R1										
  execution.go:556	0x100215158		97f9b8fa		CALL runtime.panicBounds(SB)								
  execution.go:556	0x10021515c		aa1603e0		MOVD R22, R0										
  execution.go:556	0x100215160		aa1303e1		MOVD R19, R1										
  execution.go:556	0x100215164		97f9b8f7		CALL runtime.panicBounds(SB)								
  execution.go:554	0x100215168		aa1703e0		MOVD R23, R0										
  execution.go:554	0x10021516c		aa1303e1		MOVD R19, R1										
  execution.go:554	0x100215170		97f9b8f4		CALL runtime.panicBounds(SB)								
  execution.go:554	0x100215174		aa1603e0		MOVD R22, R0										
  execution.go:554	0x100215178		aa1303e1		MOVD R19, R1										
  execution.go:554	0x10021517c		97f9b8f1		CALL runtime.panicBounds(SB)								
  execution.go:552	0x100215180		aa1703e0		MOVD R23, R0										
  execution.go:552	0x100215184		aa1303e1		MOVD R19, R1										
  execution.go:552	0x100215188		97f9b8ee		CALL runtime.panicBounds(SB)								
  execution.go:552	0x10021518c		aa1603e0		MOVD R22, R0										
  execution.go:552	0x100215190		aa1303e1		MOVD R19, R1										
  execution.go:552	0x100215194		97f9b8eb		CALL runtime.panicBounds(SB)								
  execution.go:550	0x100215198		aa1703e0		MOVD R23, R0										
  execution.go:550	0x10021519c		aa1303e1		MOVD R19, R1										
  execution.go:550	0x1002151a0		97f9b8e8		CALL runtime.panicBounds(SB)								
  execution.go:550	0x1002151a4		aa1603e0		MOVD R22, R0										
  execution.go:550	0x1002151a8		aa1303e1		MOVD R19, R1										
  execution.go:550	0x1002151ac		97f9b8e5		CALL runtime.panicBounds(SB)								
  execution.go:548	0x1002151b0		aa1703e0		MOVD R23, R0										
  execution.go:548	0x1002151b4		aa1303e1		MOVD R19, R1										
  execution.go:548	0x1002151b8		97f9b8e2		CALL runtime.panicBounds(SB)								
  execution.go:548	0x1002151bc		aa1603e0		MOVD R22, R0										
  execution.go:548	0x1002151c0		aa1303e1		MOVD R19, R1										
  execution.go:548	0x1002151c4		97f9b8df		CALL runtime.panicBounds(SB)								
  execution.go:546	0x1002151c8		aa1703e0		MOVD R23, R0										
  execution.go:546	0x1002151cc		aa1303e1		MOVD R19, R1										
  execution.go:546	0x1002151d0		97f9b8dc		CALL runtime.panicBounds(SB)								
  execution.go:546	0x1002151d4		aa1603e0		MOVD R22, R0										
  execution.go:546	0x1002151d8		aa1303e1		MOVD R19, R1										
  execution.go:546	0x1002151dc		97f9b8d9		CALL runtime.panicBounds(SB)								
  execution.go:544	0x1002151e0		aa1703e0		MOVD R23, R0										
  execution.go:544	0x1002151e4		aa1303e1		MOVD R19, R1										
  execution.go:544	0x1002151e8		97f9b8d6		CALL runtime.panicBounds(SB)								
  execution.go:544	0x1002151ec		aa1603e0		MOVD R22, R0										
  execution.go:544	0x1002151f0		aa1303e1		MOVD R19, R1										
  execution.go:544	0x1002151f4		97f9b8d3		CALL runtime.panicBounds(SB)								
  execution.go:542	0x1002151f8		aa1703e0		MOVD R23, R0										
  execution.go:542	0x1002151fc		aa1303e1		MOVD R19, R1										
  execution.go:542	0x100215200		97f9b8d0		CALL runtime.panicBounds(SB)								
  execution.go:542	0x100215204		aa1603e0		MOVD R22, R0										
  execution.go:542	0x100215208		aa1303e1		MOVD R19, R1										
  execution.go:542	0x10021520c		97f9b8cd		CALL runtime.panicBounds(SB)								
  execution.go:540	0x100215210		aa1703e0		MOVD R23, R0										
  execution.go:540	0x100215214		aa1303e1		MOVD R19, R1										
  execution.go:540	0x100215218		97f9b8ca		CALL runtime.panicBounds(SB)								
  execution.go:540	0x10021521c		aa1603e0		MOVD R22, R0										
  execution.go:540	0x100215220		aa1303e1		MOVD R19, R1										
  execution.go:540	0x100215224		97f9b8c7		CALL runtime.panicBounds(SB)								
  execution.go:538	0x100215228		aa1703e0		MOVD R23, R0										
  execution.go:538	0x10021522c		aa1303e1		MOVD R19, R1										
  execution.go:538	0x100215230		97f9b8c4		CALL runtime.panicBounds(SB)								
  execution.go:538	0x100215234		aa1603e0		MOVD R22, R0										
  execution.go:538	0x100215238		aa1303e1		MOVD R19, R1										
  execution.go:538	0x10021523c		97f9b8c1		CALL runtime.panicBounds(SB)								
  execution.go:528	0x100215240		aa1603e0		MOVD R22, R0										
  execution.go:528	0x100215244		aa1303e1		MOVD R19, R1										
  execution.go:528	0x100215248		97f9b8be		CALL runtime.panicBounds(SB)								
  execution.go:526	0x10021524c		aa1603e0		MOVD R22, R0										
  execution.go:526	0x100215250		aa1303e1		MOVD R19, R1										
  execution.go:526	0x100215254		97f9b8bb		CALL runtime.panicBounds(SB)								
  execution.go:524	0x100215258		aa1703e0		MOVD R23, R0										
  execution.go:524	0x10021525c		aa1303e1		MOVD R19, R1										
  execution.go:524	0x100215260		97f9b8b8		CALL runtime.panicBounds(SB)								
  execution.go:524	0x100215264		aa1603e0		MOVD R22, R0										
  execution.go:524	0x100215268		aa1303e1		MOVD R19, R1										
  execution.go:524	0x10021526c		97f9b8b5		CALL runtime.panicBounds(SB)								
  execution.go:522	0x100215270		aa1703e0		MOVD R23, R0										
  execution.go:522	0x100215274		aa1303e1		MOVD R19, R1										
  execution.go:522	0x100215278		97f9b8b2		CALL runtime.panicBounds(SB)								
  execution.go:522	0x10021527c		aa1603e0		MOVD R22, R0										
  execution.go:522	0x100215280		aa1303e1		MOVD R19, R1										
  execution.go:522	0x100215284		97f9b8af		CALL runtime.panicBounds(SB)								
  execution.go:520	0x100215288		aa1703e0		MOVD R23, R0										
  execution.go:520	0x10021528c		aa1303e1		MOVD R19, R1										
  execution.go:520	0x100215290		97f9b8ac		CALL runtime.panicBounds(SB)								
  execution.go:520	0x100215294		aa1603e0		MOVD R22, R0										
  execution.go:520	0x100215298		aa1303e1		MOVD R19, R1										
  execution.go:520	0x10021529c		97f9b8a9		CALL runtime.panicBounds(SB)								
  execution.go:518	0x1002152a0		aa1703e0		MOVD R23, R0										
  execution.go:518	0x1002152a4		aa1303e1		MOVD R19, R1										
  execution.go:518	0x1002152a8		97f9b8a6		CALL runtime.panicBounds(SB)								
  execution.go:518	0x1002152ac		aa1603e0		MOVD R22, R0										
  execution.go:518	0x1002152b0		aa1303e1		MOVD R19, R1										
  execution.go:518	0x1002152b4		97f9b8a3		CALL runtime.panicBounds(SB)								
  execution.go:516	0x1002152b8		aa1703e0		MOVD R23, R0										
  execution.go:516	0x1002152bc		aa1303e1		MOVD R19, R1										
  execution.go:516	0x1002152c0		97f9b8a0		CALL runtime.panicBounds(SB)								
  execution.go:516	0x1002152c4		aa1603e0		MOVD R22, R0										
  execution.go:516	0x1002152c8		aa1303e1		MOVD R19, R1										
  execution.go:516	0x1002152cc		97f9b89d		CALL runtime.panicBounds(SB)								
  execution.go:514	0x1002152d0		aa1703e0		MOVD R23, R0										
  execution.go:514	0x1002152d4		aa1303e1		MOVD R19, R1										
  execution.go:514	0x1002152d8		97f9b89a		CALL runtime.panicBounds(SB)								
  execution.go:514	0x1002152dc		aa1603e0		MOVD R22, R0										
  execution.go:514	0x1002152e0		aa1303e1		MOVD R19, R1										
  execution.go:514	0x1002152e4		97f9b897		CALL runtime.panicBounds(SB)								
  execution.go:512	0x1002152e8		aa1703e0		MOVD R23, R0										
  execution.go:512	0x1002152ec		aa1303e1		MOVD R19, R1										
  execution.go:512	0x1002152f0		97f9b894		CALL runtime.panicBounds(SB)								
  execution.go:512	0x1002152f4		aa1603e0		MOVD R22, R0										
  execution.go:512	0x1002152f8		aa1303e1		MOVD R19, R1										
  execution.go:512	0x1002152fc		97f9b891		CALL runtime.panicBounds(SB)								
  execution.go:510	0x100215300		aa1703e0		MOVD R23, R0										
  execution.go:510	0x100215304		aa1303e1		MOVD R19, R1										
  execution.go:510	0x100215308		97f9b88e		CALL runtime.panicBounds(SB)								
  execution.go:510	0x10021530c		aa1603e0		MOVD R22, R0										
  execution.go:510	0x100215310		aa1303e1		MOVD R19, R1										
  execution.go:510	0x100215314		97f9b88b		CALL runtime.panicBounds(SB)								
  execution.go:508	0x100215318		aa1703e0		MOVD R23, R0										
  execution.go:508	0x10021531c		aa1303e1		MOVD R19, R1										
  execution.go:508	0x100215320		97f9b888		CALL runtime.panicBounds(SB)								
  execution.go:508	0x100215324		aa1603e0		MOVD R22, R0										
  execution.go:508	0x100215328		aa1303e1		MOVD R19, R1										
  execution.go:508	0x10021532c		97f9b885		CALL runtime.panicBounds(SB)								
  execution.go:506	0x100215330		aa1703e0		MOVD R23, R0										
  execution.go:506	0x100215334		aa1303e1		MOVD R19, R1										
  execution.go:506	0x100215338		97f9b882		CALL runtime.panicBounds(SB)								
  execution.go:506	0x10021533c		aa1603e0		MOVD R22, R0										
  execution.go:506	0x100215340		aa1303e1		MOVD R19, R1										
  execution.go:506	0x100215344		97f9b87f		CALL runtime.panicBounds(SB)								
  execution.go:504	0x100215348		aa1603e0		MOVD R22, R0										
  execution.go:504	0x10021534c		aa1303e1		MOVD R19, R1										
  execution.go:504	0x100215350		97f9b87c		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100215354		aa1703e0		MOVD R23, R0										
  execution.go:502	0x100215358		aa1303e1		MOVD R19, R1										
  execution.go:502	0x10021535c		97f9b879		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100215360		aa1603e0		MOVD R22, R0										
  execution.go:502	0x100215364		aa1303e1		MOVD R19, R1										
  execution.go:502	0x100215368		97f9b876		CALL runtime.panicBounds(SB)								
  execution.go:500	0x10021536c		aa1703e0		MOVD R23, R0										
  execution.go:500	0x100215370		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100215374		97f9b873		CALL runtime.panicBounds(SB)								
  execution.go:500	0x100215378		aa1603e0		MOVD R22, R0										
  execution.go:500	0x10021537c		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100215380		97f9b870		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100215384		aa1703e0		MOVD R23, R0										
  execution.go:498	0x100215388		aa1303e1		MOVD R19, R1										
  execution.go:498	0x10021538c		97f9b86d		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100215390		aa1603e0		MOVD R22, R0										
  execution.go:498	0x100215394		aa1303e1		MOVD R19, R1										
  execution.go:498	0x100215398		97f9b86a		CALL runtime.panicBounds(SB)								
  execution.go:496	0x10021539c		aa1703e0		MOVD R23, R0										
  execution.go:496	0x1002153a0		aa1303e1		MOVD R19, R1										
  execution.go:496	0x1002153a4		97f9b867		CALL runtime.panicBounds(SB)								
  execution.go:496	0x1002153a8		aa1603e0		MOVD R22, R0										
  execution.go:496	0x1002153ac		aa1303e1		MOVD R19, R1										
  execution.go:496	0x1002153b0		97f9b864		CALL runtime.panicBounds(SB)								
  execution.go:494	0x1002153b4		aa1703e0		MOVD R23, R0										
  execution.go:494	0x1002153b8		aa1303e1		MOVD R19, R1										
  execution.go:494	0x1002153bc		97f9b861		CALL runtime.panicBounds(SB)								
  execution.go:494	0x1002153c0		aa1603e0		MOVD R22, R0										
  execution.go:494	0x1002153c4		aa1303e1		MOVD R19, R1										
  execution.go:494	0x1002153c8		97f9b85e		CALL runtime.panicBounds(SB)								
  execution.go:492	0x1002153cc		aa1703e0		MOVD R23, R0										
  execution.go:492	0x1002153d0		aa1303e1		MOVD R19, R1										
  execution.go:492	0x1002153d4		97f9b85b		CALL runtime.panicBounds(SB)								
  execution.go:492	0x1002153d8		aa1603e0		MOVD R22, R0										
  execution.go:492	0x1002153dc		aa1303e1		MOVD R19, R1										
  execution.go:492	0x1002153e0		97f9b858		CALL runtime.panicBounds(SB)								
  execution.go:490	0x1002153e4		aa1703e0		MOVD R23, R0										
  execution.go:490	0x1002153e8		aa1303e1		MOVD R19, R1										
  execution.go:490	0x1002153ec		97f9b855		CALL runtime.panicBounds(SB)								
  execution.go:490	0x1002153f0		aa1603e0		MOVD R22, R0										
  execution.go:490	0x1002153f4		aa1303e1		MOVD R19, R1										
  execution.go:490	0x1002153f8		97f9b852		CALL runtime.panicBounds(SB)								
  execution.go:488	0x1002153fc		aa1703e0		MOVD R23, R0										
  execution.go:488	0x100215400		aa1303e1		MOVD R19, R1										
  execution.go:488	0x100215404		97f9b84f		CALL runtime.panicBounds(SB)								
  execution.go:488	0x100215408		aa1603e0		MOVD R22, R0										
  execution.go:488	0x10021540c		aa1303e1		MOVD R19, R1										
  execution.go:488	0x100215410		97f9b84c		CALL runtime.panicBounds(SB)								
  execution.go:486	0x100215414		aa1703e0		MOVD R23, R0										
  execution.go:486	0x100215418		aa1303e1		MOVD R19, R1										
  execution.go:486	0x10021541c		97f9b849		CALL runtime.panicBounds(SB)								
  execution.go:486	0x100215420		aa1603e0		MOVD R22, R0										
  execution.go:486	0x100215424		aa1303e1		MOVD R19, R1										
  execution.go:486	0x100215428		97f9b846		CALL runtime.panicBounds(SB)								
  execution.go:484	0x10021542c		aa1703e0		MOVD R23, R0										
  execution.go:484	0x100215430		aa1303e1		MOVD R19, R1										
  execution.go:484	0x100215434		97f9b843		CALL runtime.panicBounds(SB)								
  execution.go:484	0x100215438		aa1603e0		MOVD R22, R0										
  execution.go:484	0x10021543c		aa1303e1		MOVD R19, R1										
  execution.go:484	0x100215440		97f9b840		CALL runtime.panicBounds(SB)								
  execution.go:482	0x100215444		aa1603e0		MOVD R22, R0										
  execution.go:482	0x100215448		aa1303e1		MOVD R19, R1										
  execution.go:482	0x10021544c		97f9b83d		CALL runtime.panicBounds(SB)								
  execution.go:421	0x100215450		97f9b83c		CALL runtime.panicBounds(SB)								
  execution.go:412	0x100215454		aa1903e0		MOVD R25, R0										
  execution.go:412	0x100215458		aa1703e1		MOVD R23, R1										
  execution.go:412	0x10021545c		97f9b839		CALL runtime.panicBounds(SB)								
  execution.go:409	0x100215460		aa1603e0		MOVD R22, R0										
  execution.go:409	0x100215464		aa1303e1		MOVD R19, R1										
  execution.go:409	0x100215468		97f9b836		CALL runtime.panicBounds(SB)								
  execution.go:409	0x10021546c		aa1803e0		MOVD R24, R0										
  execution.go:409	0x100215470		aa1703e1		MOVD R23, R1										
  execution.go:409	0x100215474		97f9b833		CALL runtime.panicBounds(SB)								
  execution.go:406	0x100215478		aa1603e0		MOVD R22, R0										
  execution.go:406	0x10021547c		aa1303e1		MOVD R19, R1										
  execution.go:406	0x100215480		97f9b830		CALL runtime.panicBounds(SB)								
  execution.go:403	0x100215484		aa1603e0		MOVD R22, R0										
  execution.go:403	0x100215488		aa1303e1		MOVD R19, R1										
  execution.go:403	0x10021548c		97f9b82d		CALL runtime.panicBounds(SB)								
  execution.go:391	0x100215490		aa1803e0		MOVD R24, R0										
  execution.go:391	0x100215494		aa1603e1		MOVD R22, R1										
  execution.go:391	0x100215498		97f9b82a		CALL runtime.panicBounds(SB)								
  execution.go:389	0x10021549c		aa1803e0		MOVD R24, R0										
  execution.go:389	0x1002154a0		aa1603e1		MOVD R22, R1										
  execution.go:389	0x1002154a4		97f9b827		CALL runtime.panicBounds(SB)								
  execution.go:385	0x1002154a8		aa1803e0		MOVD R24, R0										
  execution.go:385	0x1002154ac		aa1603e1		MOVD R22, R1										
  execution.go:385	0x1002154b0		97f9b824		CALL runtime.panicBounds(SB)								
  execution.go:383	0x1002154b4		aa1303e0		MOVD R19, R0										
  execution.go:383	0x1002154b8		97f9b822		CALL runtime.panicBounds(SB)								
  execution.go:379	0x1002154bc		aa1303e0		MOVD R19, R0										
  execution.go:379	0x1002154c0		97f9b820		CALL runtime.panicBounds(SB)								
  execution.go:376	0x1002154c4		aa1303e0		MOVD R19, R0										
  execution.go:376	0x1002154c8		97f9b81e		CALL runtime.panicBounds(SB)								
  execution.go:459	0x1002154cc		aa1903e0		MOVD R25, R0										
  execution.go:459	0x1002154d0		aa1303e1		MOVD R19, R1										
  execution.go:459	0x1002154d4		97f9b81b		CALL runtime.panicBounds(SB)								
  execution.go:459	0x1002154d8		aa1403e0		MOVD R20, R0										
  execution.go:459	0x1002154dc		aa1303e1		MOVD R19, R1										
  execution.go:459	0x1002154e0		97f9b818		CALL runtime.panicBounds(SB)								
  execution.go:459	0x1002154e4		aa1603e0		MOVD R22, R0										
  execution.go:459	0x1002154e8		aa1403e1		MOVD R20, R1										
  execution.go:459	0x1002154ec		97f9b815		CALL runtime.panicBounds(SB)								
  execution.go:459	0x1002154f0		aa1903e0		MOVD R25, R0										
  execution.go:459	0x1002154f4		aa1403e1		MOVD R20, R1										
  execution.go:459	0x1002154f8		97f9b812		CALL runtime.panicBounds(SB)								
  execution.go:439	0x1002154fc		aa1303e0		MOVD R19, R0										
  execution.go:439	0x100215500		97f9b810		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100215504		97f9b80f		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100215508		aa1a03e0		MOVD R26, R0										
  execution.go:439	0x10021550c		aa1303e1		MOVD R19, R1										
  execution.go:439	0x100215510		97f9b80c		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100215514		97f9b80b		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100215518		aa1903e0		MOVD R25, R0										
  execution.go:435	0x10021551c		aa1303e1		MOVD R19, R1										
  execution.go:435	0x100215520		97f9b808		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100215524		97f9b807		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100215528		aa1803e0		MOVD R24, R0										
  execution.go:435	0x10021552c		aa1303e1		MOVD R19, R1										
  execution.go:435	0x100215530		97f9b804		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100215534		97f9b803		CALL runtime.panicBounds(SB)								
  execution.go:434	0x100215538		aa1403e0		MOVD R20, R0										
  execution.go:434	0x10021553c		aa1903e1		MOVD R25, R1										
  execution.go:434	0x100215540		97f9b800		CALL runtime.panicBounds(SB)								
  execution.go:434	0x100215544		aa1903e0		MOVD R25, R0										
  execution.go:434	0x100215548		aa1803e1		MOVD R24, R1										
  execution.go:434	0x10021554c		97f9b7fd		CALL runtime.panicBounds(SB)								
  execution.go:364	0x100215550		aa1403e0		MOVD R20, R0										
  execution.go:364	0x100215554		aa1003e1		MOVD R16, R1										
  execution.go:364	0x100215558		97f9b7fa		CALL runtime.panicBounds(SB)								
  execution.go:361	0x10021555c		aa1603e0		MOVD R22, R0										
  execution.go:361	0x100215560		aa1303e1		MOVD R19, R1										
  execution.go:361	0x100215564		97f9b7f7		CALL runtime.panicBounds(SB)								
  execution.go:343	0x100215568		aa1803e0		MOVD R24, R0										
  execution.go:343	0x10021556c		aa1603e1		MOVD R22, R1										
  execution.go:343	0x100215570		97f9b7f4		CALL runtime.panicBounds(SB)								
  execution.go:341	0x100215574		aa1403e0		MOVD R20, R0										
  execution.go:341	0x100215578		aa1003e1		MOVD R16, R1										
  execution.go:341	0x10021557c		97f9b7f1		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100215580		aa1403e0		MOVD R20, R0										
  execution.go:337	0x100215584		97f9b7ef		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100215588		aa1403e0		MOVD R20, R0										
  execution.go:337	0x10021558c		aa1103e1		MOVD R17, R1										
  execution.go:337	0x100215590		97f9b7ec		CALL runtime.panicBounds(SB)								
  execution.go:797	0x100215594		f0001180		ADRP 2306048(PC), R0									
  execution.go:797	0x100215598		912aa000		ADD $2728, R0, R0									
  execution.go:797	0x10021559c		f0000fa1		ADRP 2060288(PC), R1									
  execution.go:797	0x1002155a0		91298021		ADD $2656, R1, R1									
  execution.go:797	0x1002155a4		97f99c7b		CALL runtime.gopanic(SB)								
  execution.go:797	0x1002155a8		d503201f		NOOP											
  execution.go:325	0x1002155ac		a90087e0		STP (R0, R1), 8(RSP)									
  execution.go:325	0x1002155b0		aa1e03e3		MOVD R30, R3										
  execution.go:325	0x1002155b4		97f9af4b		CALL runtime.morestack_noctxt.abi0(SB)							
  execution.go:325	0x1002155b8		a94087e0		LDP 8(RSP), (R0, R1)									
  execution.go:325	0x1002155bc		17fff621		JMP github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB)	
