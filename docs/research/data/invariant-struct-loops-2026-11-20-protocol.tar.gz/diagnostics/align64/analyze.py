from collections import defaultdict
import gzip
import json
from pathlib import Path
from statistics import median

root = Path(__file__).resolve().parent
groups = defaultdict(list)
with gzip.open(root / 'rows.jsonl.gz', 'rt') as stream:
    for raw in stream:
        row = json.loads(raw)
        groups[row['case'], row['id']].append(row)
results = {}
for case in sorted({key[0] for key in groups}):
    roles = {}
    for role in ['base', 'head', 'base-aa', 'head-aa']:
        rows = groups[case, role]
        assert len(rows) == 4
        roles[role] = {name: median(r[name] for r in rows) for name in
                       ['cpuNs', 'instructions', 'cycles', 'cyclesPerInstruction']}
    result = {role: {name: median(r[name] for r in groups[case, role] + groups[case, role+'-aa'])
                     for name in roles[role]} for role in ['base', 'head']}
    result['headOverBase'] = {name: result['head'][name]/value for name, value in result['base'].items()}
    result['separateArms'] = roles
    results[case] = result
    print(case, {k: round(v, 5) for k, v in result['headOverBase'].items()})
(root / 'medians.json').write_text(json.dumps(results, indent=2)+'\n')
