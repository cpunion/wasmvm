TEXT github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB) /Users/lijie/source/goplus/wasmvm-source-cleanup/internal/engine/execute/execution.go
  execution.go:325	0x1002120f0		f9400b90		MOVD 16(R28), R16									
  execution.go:325	0x1002120f4		d10703f1		SUB $448, RSP, R17									
  execution.go:325	0x1002120f8		eb10023f		CMP R16, R17										
  execution.go:325	0x1002120fc		54013b09		BLS 2520(PC)										
  execution.go:325	0x100212100		d10903f4		SUB $576, RSP, R20									
  execution.go:325	0x100212104		a93ffa9d		STP (R29, R30), -8(R20)									
  execution.go:325	0x100212108		9100029f		MOVD R20, RSP										
  execution.go:325	0x10021210c		d10023fd		SUB $8, RSP, R29									
  execution.go:327	0x100212110		f90127e0		MOVD R0, 584(RSP)									
  execution.go:326	0x100212114		39408009		MOVBU 32(R0), R9									
  execution.go:326	0x100212118		3903dfe9		MOVB R9, 247(RSP)									
  execution.go:327	0x10021211c		14000004		JMP 4(PC)										
  execution.go:327	0x100212120		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x100212124		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:328	0x100212128		f94093e1		MOVD 288(RSP), R1									
  execution.go:327	0x10021212c		a9442c0a		LDP 64(R0), (R10, R11)									
  execution.go:327	0x100212130		b40138ab		CBZ R11, 2501(PC)									
  execution.go:328	0x100212134		d100056b		SUB $1, R11, R11									
  execution.go:329	0x100212138		8b0b194a		ADD R11<<6, R10, R10									
  execution.go:330	0x10021213c		3900415f		MOVB ZR, 16(R10)									
  execution.go:331	0x100212140		f940014b		MOVD (R10), R11										
  execution.go:334	0x100212144		f9400d4c		MOVD 24(R10), R12									
  execution.go:332	0x100212148		a944396d		LDP 64(R11), (R13, R14)									
  execution.go:333	0x10021214c		a94b41cf		LDP 176(R14), (R15, R16)								
  execution.go:337	0x100212150		f9404411		MOVD 136(R0), R17									
  execution.go:337	0x100212154		f9404dd3		MOVD 152(R14), R19									
  execution.go:337	0x100212158		8b130194		ADD R19, R12, R20									
  execution.go:337	0x10021215c		eb14023f		CMP R20, R17										
  execution.go:337	0x100212160		540136c3		BCC 2486(PC)										
  execution.go:337	0x100212164		eb14019f		CMP R20, R12										
  execution.go:337	0x100212168		54013648		BHI 2482(PC)										
  execution.go:329	0x10021216c		f900b7ea		MOVD R10, 360(RSP)									
  execution.go:331	0x100212170		f900b3eb		MOVD R11, 352(RSP)									
  execution.go:332	0x100212174		f900bfee		MOVD R14, 376(RSP)									
  execution.go:335	0x100212178		f900abed		MOVD R13, 336(RSP)									
  execution.go:337	0x10021217c		f90087f3		MOVD R19, 264(RSP)									
  execution.go:333	0x100212180		f9008bf0		MOVD R16, 272(RSP)									
  execution.go:333	0x100212184		f900a7ef		MOVD R15, 328(RSP)									
  execution.go:337	0x100212188		f9403c14		MOVD 120(R0), R20									
  execution.go:337	0x10021218c		cb110191		SUB R17, R12, R17									
  execution.go:337	0x100212190		8a91fd8c		AND R17->63, R12, R12									
  execution.go:336	0x100212194		b9400951		MOVWU 8(R10), R17									
  execution.go:337	0x100212198		8b0c128c		ADD R12<<4, R20, R12									
  execution.go:337	0x10021219c		f9009bec		MOVD R12, 304(RSP)									
  execution.go:338	0x1002121a0		14000002		JMP 2(PC)										
  execution.go:341	0x1002121a4		aa1503e1		MOVD R21, R1										
  execution.go:341	0x1002121a8		2a1103f4		MOVW R17, R20										
  execution.go:341	0x1002121ac		eb10029f		CMP R16, R20										
  execution.go:341	0x1002121b0		540133a2		BCS 2461(PC)										
  execution.go:341	0x1002121b4		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:342	0x1002121b8		360002c9		TBZ $0, R9, 22(PC)									
  execution.go:343	0x1002121bc		a947d9d5		LDP 120(R14), (R21, R22)								
  execution.go:343	0x1002121c0		b9400697		MOVWU 4(R20), R23									
  execution.go:343	0x1002121c4		aa1703f8		MOVD R23, R24										
  execution.go:343	0x1002121c8		eb16031f		CMP R22, R24										
  execution.go:343	0x1002121cc		54013262		BCS 2451(PC)										
  execution.go:343	0x1002121d0		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:343	0x1002121d4		cb1816d6		SUB R24<<5, R22, R22									
  ir.go:27		0x1002121d8		b8766ab7		MOVWU (R21)(R22), R23									
  execution.go:343	0x1002121dc		8b1602b5		ADD R22, R21, R21									
  ir.go:27		0x1002121e0		710016ff		CMPW $5, R23										
  ir.go:27		0x1002121e4		54000060		BEQ 3(PC)										
  ir.go:27		0x1002121e8		71002eff		CMPW $11, R23										
  ir.go:27		0x1002121ec		54000061		BNE 3(PC)										
  execution.go:344	0x1002121f0		aa1f03e2		MOVD ZR, R2										
  execution.go:344	0x1002121f4		14000002		JMP 2(PC)										
  execution.go:344	0x1002121f8		b24003e2		ORR $1, ZR, R2										
  execution.go:345	0x1002121fc		f940a816		MOVD 336(R0), R22									
  execution.go:345	0x100212200		eb16005f		CMP R22, R2										
  execution.go:345	0x100212204		5400de88		BHI 1780(PC)										
  execution.go:348	0x100212208		cb0202d5		SUB R2, R22, R21									
  execution.go:348	0x10021220c		f900a815		MOVD R21, 336(R0)									
  execution.go:350	0x100212210		91000435		ADD $1, R1, R21										
  execution.go:351	0x100212214		f24016bf		TST $63, R21										
  execution.go:351	0x100212218		54000421		BNE 33(PC)										
  execution.go:341	0x10021221c		f900aff4		MOVD R20, 344(RSP)									
  execution.go:350	0x100212220		f90097f5		MOVD R21, 296(RSP)									
  execution.go:341	0x100212224		b900fbf1		MOVW R17, 248(RSP)									
  execution.go:209	0x100212228		f940b016		MOVD 352(R0), R22									
  execution.go:209	0x10021222c		b40000d6		CBZ R22, 6(PC)										
  type.go:19		0x100212230		88dffed6		LDARW (R22), R22									
  execution.go:209	0x100212234		35000096		CBNZW R22, 4(PC)									
  execution.go:212	0x100212238		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x10021223c		aa1f03e2		MOVD ZR, R2										
  execution.go:352	0x100212240		14000013		JMP 19(PC)										
  execution.go:212	0x100212244		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100212248		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10021224c		d63f0020		CALL (R1)										
  execution.go:356	0x100212250		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100212254		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100212258		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x10021225c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100212260		f940abed		MOVD 336(RSP), R13									
  execution.go:434	0x100212264		f940bfee		MOVD 376(RSP), R14									
  execution.go:364	0x100212268		f940a7ef		MOVD 328(RSP), R15									
  execution.go:364	0x10021226c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:360	0x100212270		b940fbf1		MOVWU 248(RSP), R17									
  execution.go:361	0x100212274		f94087f3		MOVD 264(RSP), R19									
  execution.go:360	0x100212278		f940aff4		MOVD 344(RSP), R20									
  execution.go:360	0x10021227c		f94097f5		MOVD 296(RSP), R21									
  execution.go:212	0x100212280		aa0103e2		MOVD R1, R2										
  execution.go:212	0x100212284		aa0003e1		MOVD R0, R1										
  execution.go:353	0x100212288		f94127e0		MOVD 584(RSP), R0									
  execution.go:352	0x10021228c		b4000081		CBZ R1, 4(PC)										
  execution.go:352	0x100212290		140006f2		JMP 1778(PC)										
  execution.go:364	0x100212294		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:365	0x100212298		910006b5		ADD $1, R21, R21									
  execution.go:356	0x10021229c		b9401e96		MOVWU 28(R20), R22									
  execution.go:356	0x1002122a0		340002f6		CBZW R22, 23(PC)									
  execution.go:356	0x1002122a4		b9400297		MOVWU (R20), R23									
  execution.go:356	0x1002122a8		710082ff		CMPW $32, R23										
  execution.go:356	0x1002122ac		54000060		BEQ 3(PC)										
  execution.go:356	0x1002122b0		710106ff		CMPW $65, R23										
  execution.go:356	0x1002122b4		54000241		BNE 18(PC)										
  execution.go:356	0x1002122b8		37000229		TBNZ $0, R9, 17(PC)									
  execution.go:356	0x1002122bc		924016b8		AND $63, R21, R24									
  execution.go:356	0x1002122c0		f100ff1f		CMP $63, R24										
  execution.go:356	0x1002122c4		540001c0		BEQ 14(PC)										
  execution.go:360	0x1002122c8		710106ff		CMPW $65, R23										
  execution.go:360	0x1002122cc		540000e1		BNE 7(PC)										
  execution.go:361	0x1002122d0		b9400a96		MOVWU 8(R20), R22									
  execution.go:361	0x1002122d4		eb1302df		CMP R19, R22										
  execution.go:361	0x1002122d8		540129a2		BCS 2381(PC)										
  execution.go:361	0x1002122dc		8b161196		ADD R22<<4, R12, R22									
  execution.go:361	0x1002122e0		b9401a94		MOVWU 24(R20), R20									
  execution.go:361	0x1002122e4		a9007ed4		STP (R20, ZR), (R22)									
  execution.go:363	0x1002122e8		91000631		ADD $1, R17, R17									
  execution.go:364	0x1002122ec		2a1103f4		MOVW R17, R20										
  execution.go:364	0x1002122f0		eb10029f		CMP R16, R20										
  execution.go:364	0x1002122f4		54fffd03		BCC -24(PC)										
  execution.go:364	0x1002122f8		14000942		JMP 2370(PC)										
  execution.go:360	0x1002122fc		b90107f1		MOVW R17, 260(RSP)									
  execution.go:360	0x100212300		f90093f5		MOVD R21, 288(RSP)									
  execution.go:360	0x100212304		f900c3f4		MOVD R20, 384(RSP)									
  execution.go:371	0x100212308		b9400281		MOVWU (R20), R1										
  execution.go:371	0x10021230c		d1038037		SUB $224, R1, R23									
  execution.go:371	0x100212310		d29fe418		MOVD $65312, R24									
  execution.go:371	0x100212314		f2a01ff8		MOVK $(255<<16), R24									
  execution.go:371	0x100212318		6b1802ff		CMPW R24, R23										
  execution.go:371	0x10021231c		54002822		BCS 321(PC)										
  execution.go:372	0x100212320		d3507c37		UBFX $16, R1, $16, R23									
  execution.go:396	0x100212324		7103eeff		CMPW $251, R23										
  execution.go:396	0x100212328		540019e0		BEQ 207(PC)										
  execution.go:432	0x10021232c		7103f2ff		CMPW $252, R23										
  execution.go:432	0x100212330		54000ba1		BNE 93(PC)										
  wide.go:3		0x100212334		d2800277		MOVD $19, R23										
  wide.go:3		0x100212338		f2a01f97		MOVK $(252<<16), R23									
  wide.go:3		0x10021233c		cb170038		SUB R23, R1, R24									
  wide.go:3		0x100212340		71000f1f		CMPW $3, R24										
  execution.go:433	0x100212344		540026e8		BHI 311(PC)										
  execution.go:434	0x100212348		f9406dd8		MOVD 216(R14), R24									
  execution.go:434	0x10021234c		b9401a94		MOVWU 24(R20), R20									
  execution.go:434	0x100212350		8b160299		ADD R22, R20, R25									
  execution.go:434	0x100212354		91000b39		ADD $2, R25, R25									
  execution.go:434	0x100212358		2a1903f9		MOVW R25, R25										
  execution.go:434	0x10021235c		eb18033f		CMP R24, R25										
  execution.go:434	0x100212360		540124a8		BHI 2341(PC)										
  execution.go:434	0x100212364		eb19029f		CMP R25, R20										
  execution.go:434	0x100212368		54012408		BHI 2336(PC)										
  execution.go:434	0x10021236c		f94065da		MOVD 200(R14), R26									
  execution.go:434	0x100212370		cb180298		SUB R24, R20, R24									
  execution.go:434	0x100212374		8a98fe98		AND R24->63, R20, R24									
  execution.go:434	0x100212378		8b180b5e		ADD R24<<2, R26, R30									
  execution.go:434	0x10021237c		cb140334		SUB R20, R25, R20									
  execution.go:435	0x100212380		b4012334		CBZ R20, 2329(PC)									
  execution.go:435	0x100212384		b8787b58		MOVWU (R26)(R24<<2), R24								
  execution.go:435	0x100212388		eb13031f		CMP R19, R24										
  execution.go:435	0x10021238c		54012262		BCS 2323(PC)										
  execution.go:435	0x100212390		8b181198		ADD R24<<4, R12, R24									
  execution.go:435	0x100212394		f100069f		CMP $1, R20										
  execution.go:435	0x100212398		540121e9		BLS 2319(PC)										
  execution.go:435	0x10021239c		b94007d9		MOVWU 4(R30), R25									
  execution.go:435	0x1002123a0		eb13033f		CMP R19, R25										
  execution.go:435	0x1002123a4		54012122		BCS 2313(PC)										
  execution.go:435	0x1002123a8		8b191199		ADD R25<<4, R12, R25									
  execution.go:435	0x1002123ac		f9400318		MOVD (R24), R24										
  execution.go:435	0x1002123b0		f9400339		MOVD (R25), R25										
  execution.go:438	0x1002123b4		d280029a		MOVD $20, R26										
  execution.go:438	0x1002123b8		f2a01f9a		MOVK $(252<<16), R26									
  execution.go:438	0x1002123bc		6b1a003f		CMPW R26, R1										
  execution.go:438	0x1002123c0		540002e8		BHI 23(PC)										
  execution.go:439	0x1002123c4		f1000a9f		CMP $2, R20										
  execution.go:439	0x1002123c8		54011fe9		BLS 2303(PC)										
  execution.go:439	0x1002123cc		b9400bda		MOVWU 8(R30), R26									
  execution.go:439	0x1002123d0		eb13035f		CMP R19, R26										
  execution.go:439	0x1002123d4		54011f22		BCS 2297(PC)										
  execution.go:439	0x1002123d8		8b1a119a		ADD R26<<4, R12, R26									
  execution.go:439	0x1002123dc		f1000e9f		CMP $3, R20										
  execution.go:439	0x1002123e0		54011ea9		BLS 2293(PC)										
  execution.go:439	0x1002123e4		b9400fc2		MOVWU 12(R30), R2									
  execution.go:439	0x1002123e8		eb13005f		CMP R19, R2										
  execution.go:439	0x1002123ec		54011e02		BCS 2288(PC)										
  execution.go:439	0x1002123f0		8b021182		ADD R2<<4, R12, R2									
  execution.go:439	0x1002123f4		f940035a		MOVD (R26), R26										
  execution.go:439	0x1002123f8		f9400042		MOVD (R2), R2										
  execution.go:441	0x1002123fc		6b17003f		CMPW R23, R1										
  execution.go:441	0x100212400		54000081		BNE 4(PC)										
  execution.go:442	0x100212404		ab180357		ADDS R24, R26, R23									
  execution.go:443	0x100212408		ba020338		ADCS R2, R25, R24									
  <autogenerated>:1	0x10021240c		14000013		JMP 19(PC)										
  execution.go:445	0x100212410		eb1a0317		SUBS R26, R24, R23									
  execution.go:446	0x100212414		fa020338		SBCS R2, R25, R24									
  <autogenerated>:1	0x100212418		14000010		JMP 16(PC)										
  execution.go:449	0x10021241c		9b187f37		MUL R24, R25, R23									
  execution.go:449	0x100212420		9bd97f1a		UMULH R25, R24, R26									
  execution.go:331	0x100212424		aa0b03e2		MOVD R11, R2										
  execution.go:450	0x100212428		d28002ab		MOVD $21, R11										
  execution.go:450	0x10021242c		f2a01f8b		MOVK $(252<<16), R11									
  execution.go:450	0x100212430		6b0b003f		CMPW R11, R1										
  execution.go:450	0x100212434		540000e1		BNE 7(PC)										
  execution.go:452	0x100212438		cb19034b		SUB R25, R26, R11									
  execution.go:451	0x10021243c		f100031f		CMP $0, R24										
  execution.go:452	0x100212440		9a9ab16b		CSEL LT, R11, R26, R11									
  execution.go:455	0x100212444		cb180178		SUB R24, R11, R24									
  execution.go:454	0x100212448		f100033f		CMP $0, R25										
  execution.go:455	0x10021244c		9a8bb31a		CSEL LT, R24, R11, R26									
  execution.go:786	0x100212450		aa0203eb		MOVD R2, R11										
  execution.go:441	0x100212454		aa1a03f8		MOVD R26, R24										
  execution.go:459	0x100212458		910006d9		ADD $1, R22, R25									
  execution.go:459	0x10021245c		2a1903f9		MOVW R25, R25										
  execution.go:459	0x100212460		eb14033f		CMP R20, R25										
  execution.go:459	0x100212464		540119e2		BCS 2255(PC)										
  execution.go:459	0x100212468		b8797bd9		MOVWU (R30)(R25<<2), R25								
  execution.go:459	0x10021246c		eb1402df		CMP R20, R22										
  execution.go:459	0x100212470		54011922		BCS 2249(PC)										
  execution.go:459	0x100212474		b8767bd4		MOVWU (R30)(R22<<2), R20								
  execution.go:459	0x100212478		eb13029f		CMP R19, R20										
  execution.go:459	0x10021247c		54011862		BCS 2243(PC)										
  execution.go:459	0x100212480		8b141194		ADD R20<<4, R12, R20									
  execution.go:459	0x100212484		a9007e97		STP (R23, ZR), (R20)									
  execution.go:459	0x100212488		eb13033f		CMP R19, R25										
  execution.go:459	0x10021248c		54011782		BCS 2236(PC)										
  execution.go:459	0x100212490		8b191194		ADD R25<<4, R12, R20									
  execution.go:459	0x100212494		a9007e98		STP (R24, ZR), (R20)									
  execution.go:460	0x100212498		91000631		ADD $1, R17, R17									
  execution.go:461	0x10021249c		b9000951		MOVW R17, 8(R10)									
  execution.go:462	0x1002124a0		17ffff41		JMP -191(PC)										
  execution.go:373	0x1002124a4		7103f6ff		CMPW $253, R23										
  execution.go:373	0x1002124a8		54000080		BEQ 4(PC)										
  execution.go:465	0x1002124ac		7103983f		CMPW $230, R1										
  execution.go:465	0x1002124b0		54001b88		BHI 220(PC)										
  execution.go:465	0x1002124b4		1400062f		JMP 1583(PC)										
  execution.go:375	0x1002124b8		b9400e87		MOVWU 12(R20), R7									
  execution.go:375	0x1002124bc		310004ff		CMNW $1, R7										
  execution.go:375	0x1002124c0		540000c0		BEQ 6(PC)										
  execution.go:376	0x1002124c4		eb1300ff		CMP R19, R7										
  execution.go:376	0x1002124c8		54011562		BCS 2219(PC)										
  execution.go:376	0x1002124cc		8b071187		ADD R7<<4, R12, R7									
  execution.go:376	0x1002124d0		a9401ce2		LDP (R7), (R2, R7)									
  execution.go:376	0x1002124d4		14000003		JMP 3(PC)										
  execution.go:376	0x1002124d8		aa1f03e2		MOVD ZR, R2										
  execution.go:376	0x1002124dc		aa1f03e7		MOVD ZR, R7										
  execution.go:378	0x1002124e0		b9401288		MOVWU 16(R20), R8									
  execution.go:378	0x1002124e4		3100051f		CMNW $1, R8										
  execution.go:378	0x1002124e8		540000c0		BEQ 6(PC)										
  execution.go:379	0x1002124ec		eb13011f		CMP R19, R8										
  execution.go:379	0x1002124f0		540113e2		BCS 2207(PC)										
  execution.go:379	0x1002124f4		8b081188		ADD R8<<4, R12, R8									
  execution.go:379	0x1002124f8		a9401103		LDP (R8), (R3, R4)									
  execution.go:379	0x1002124fc		14000003		JMP 3(PC)										
  execution.go:379	0x100212500		aa1f03e4		MOVD ZR, R4										
  execution.go:379	0x100212504		aa1f03e3		MOVD ZR, R3										
  execution.go:382	0x100212508		b9401688		MOVWU 20(R20), R8									
  execution.go:382	0x10021250c		3100051f		CMNW $1, R8										
  execution.go:382	0x100212510		540000c0		BEQ 6(PC)										
  execution.go:383	0x100212514		eb13011f		CMP R19, R8										
  execution.go:383	0x100212518		54011262		BCS 2195(PC)										
  execution.go:383	0x10021251c		8b081188		ADD R8<<4, R12, R8									
  execution.go:383	0x100212520		a9401905		LDP (R8), (R5, R6)									
  execution.go:383	0x100212524		14000003		JMP 3(PC)										
  execution.go:383	0x100212528		aa1f03e6		MOVD ZR, R6										
  execution.go:383	0x10021252c		aa1f03e5		MOVD ZR, R5										
  execution.go:385	0x100212530		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:385	0x100212534		b9400697		MOVWU 4(R20), R23									
  execution.go:385	0x100212538		aa1703f8		MOVD R23, R24										
  execution.go:385	0x10021253c		eb16031f		CMP R22, R24										
  execution.go:385	0x100212540		540110c2		BCS 2182(PC)										
  execution.go:385	0x100212544		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:385	0x100212548		cb1816d6		SUB R24<<5, R22, R22									
  execution.go:386	0x10021254c		d3403c37		UBFX $0, R1, $16, R23									
  execution.go:385	0x100212550		8b160108		ADD R22, R8, R8										
  execution.go:388	0x100212554		71002aff		CMPW $10, R23										
  execution.go:388	0x100212558		540000e9		BLS 7(PC)										
  execution.go:388	0x10021255c		d10152f6		SUB $84, R23, R22									
  execution.go:388	0x100212560		71000edf		CMPW $3, R22										
  execution.go:388	0x100212564		54000089		BLS 4(PC)										
  execution.go:388	0x100212568		b24002f6		ORR $1, R23, R22									
  execution.go:388	0x10021256c		710176df		CMPW $93, R22										
  execution.go:388	0x100212570		54000201		BNE 16(PC)										
  execution.go:389	0x100212574		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x100212578		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x10021257c		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x100212580		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:389	0x100212584		eb16031f		CMP R22, R24										
  execution.go:389	0x100212588		54010e22		BCS 2161(PC)										
  execution.go:389	0x10021258c		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:389	0x100212590		f94008e0		MOVD 16(R7), R0										
  execution.go:389	0x100212594		39410107		MOVBU 64(R8), R7									
  execution.go:389	0x100212598		aa0303e5		MOVD R3, R5										
  execution.go:389	0x10021259c		aa0403e6		MOVD R4, R6										
  execution.go:389	0x1002125a0		aa1703e3		MOVD R23, R3										
  execution.go:389	0x1002125a4		aa0703e4		MOVD R7, R4										
  execution.go:389	0x1002125a8		97ffa312		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:389	0x1002125ac		1400001d		JMP 29(PC)										
  execution.go:390	0x1002125b0		71002eff		CMPW $11, R23										
  execution.go:390	0x1002125b4		54000080		BEQ 4(PC)										
  execution.go:390	0x1002125b8		d10162f6		SUB $88, R23, R22									
  execution.go:390	0x1002125bc		71000edf		CMPW $3, R22										
  execution.go:390	0x1002125c0		54000268		BHI 19(PC)										
  execution.go:391	0x1002125c4		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x1002125c8		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x1002125cc		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x1002125d0		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:391	0x1002125d4		eb16031f		CMP R22, R24										
  execution.go:391	0x1002125d8		54010b42		BCS 2138(PC)										
  execution.go:391	0x1002125dc		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:391	0x1002125e0		f94008e0		MOVD 16(R7), R0										
  execution.go:391	0x1002125e4		39410107		MOVBU 64(R8), R7									
  execution.go:391	0x1002125e8		aa0303e5		MOVD R3, R5										
  execution.go:391	0x1002125ec		aa0403e6		MOVD R4, R6										
  execution.go:391	0x1002125f0		aa1703e3		MOVD R23, R3										
  execution.go:391	0x1002125f4		aa0703e4		MOVD R7, R4										
  execution.go:391	0x1002125f8		97ffa376		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:391	0x1002125fc		aa0003e2		MOVD R0, R2										
  execution.go:393	0x100212600		aa1f03e1		MOVD ZR, R1										
  execution.go:393	0x100212604		aa1f03e0		MOVD ZR, R0										
  execution.go:391	0x100212608		14000006		JMP 6(PC)										
  execution.go:393	0x10021260c		aa0803e0		MOVD R8, R0										
  execution.go:393	0x100212610		aa0203e1		MOVD R2, R1										
  execution.go:393	0x100212614		aa0703e2		MOVD R7, R2										
  execution.go:393	0x100212618		97ffb362		CALL github.com/cpunion/wasmvm/internal/engine/simd.Eval(SB)				
  execution.go:391	0x10021261c		aa1f03e2		MOVD ZR, R2										
  execution.go:342	0x100212620		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100212624		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100212628		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021262c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100212630		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100212634		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100212638		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021263c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100212640		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100212644		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100212648		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021264c		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x100212650		aa0103f7		MOVD R1, R23										
  execution.go:395	0x100212654		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100212658		f94127e0		MOVD 584(RSP), R0									
  execution.go:395	0x10021265c		aa0203e1		MOVD R2, R1										
  execution.go:395	0x100212660		140005b9		JMP 1465(PC)										
  gc_access.go:11	0x100212664		d3403c36		UBFX $0, R1, $16, R22									
  gc_access.go:11	0x100212668		710036df		CMPW $13, R22										
  gc_access.go:14	0x10021266c		54000148		BHI 10(PC)										
  gc_access.go:12	0x100212670		d1000ad7		SUB $2, R22, R23									
  gc_access.go:12	0x100212674		71000aff		CMPW $2, R23										
  gc_access.go:12	0x100212678		54000249		BLS 18(PC)										
  gc_access.go:14	0x10021267c		710016df		CMPW $5, R22										
  gc_access.go:14	0x100212680		54000060		BEQ 3(PC)										
  gc_access.go:14	0x100212684		71002edf		CMPW $11, R22										
  gc_access.go:14	0x100212688		54000203		BCC 16(PC)										
  gc_access.go:14	0x10021268c		b27f03e1		ORR $2, ZR, R1										
  execution.go:400	0x100212690		1400000f		JMP 15(PC)										
  gc_access.go:11	0x100212694		71003edf		CMPW $15, R22										
  gc_access.go:12	0x100212698		540000a8		BHI 5(PC)										
  gc_access.go:16	0x10021269c		71003adf		CMPW $14, R22										
  gc_access.go:16	0x1002126a0		54000101		BNE 8(PC)										
  gc_access.go:16	0x1002126a4		b24007e1		ORR $3, ZR, R1										
  execution.go:400	0x1002126a8		14000009		JMP 9(PC)										
  gc_access.go:12	0x1002126ac		d10072d7		SUB $28, R22, R23									
  gc_access.go:12	0x1002126b0		71000aff		CMPW $2, R23										
  gc_access.go:12	0x1002126b4		54000069		BLS 3(PC)										
  gc_access.go:12	0x1002126b8		71008adf		CMPW $34, R22										
  gc_access.go:12	0x1002126bc		54000061		BNE 3(PC)										
  gc_access.go:12	0x1002126c0		b24003e1		ORR $1, ZR, R1										
  execution.go:400	0x1002126c4		14000002		JMP 2(PC)										
  execution.go:400	0x1002126c8		aa1f03e1		MOVD ZR, R1										
  execution.go:400	0x1002126cc		b40007e1		CBZ R1, 63(PC)										
  execution.go:402	0x1002126d0		b9400e96		MOVWU 12(R20), R22									
  execution.go:402	0x1002126d4		310006df		CMNW $1, R22										
  execution.go:402	0x1002126d8		540000c0		BEQ 6(PC)										
  execution.go:403	0x1002126dc		eb1302df		CMP R19, R22										
  execution.go:403	0x1002126e0		540102a2		BCS 2069(PC)										
  execution.go:403	0x1002126e4		8b161196		ADD R22<<4, R12, R22									
  execution.go:403	0x1002126e8		a94012c3		LDP (R22), (R3, R4)									
  execution.go:403	0x1002126ec		14000003		JMP 3(PC)										
  execution.go:403	0x1002126f0		aa1f03e4		MOVD ZR, R4										
  execution.go:403	0x1002126f4		aa1f03e3		MOVD ZR, R3										
  execution.go:405	0x1002126f8		b9401296		MOVWU 16(R20), R22									
  execution.go:405	0x1002126fc		310006df		CMNW $1, R22										
  execution.go:405	0x100212700		540000c0		BEQ 6(PC)										
  execution.go:406	0x100212704		eb1302df		CMP R19, R22										
  execution.go:406	0x100212708		54010102		BCS 2056(PC)										
  execution.go:406	0x10021270c		8b161196		ADD R22<<4, R12, R22									
  execution.go:406	0x100212710		a9401ac5		LDP (R22), (R5, R6)									
  execution.go:406	0x100212714		14000003		JMP 3(PC)										
  execution.go:406	0x100212718		aa1f03e6		MOVD ZR, R6										
  execution.go:406	0x10021271c		aa1f03e5		MOVD ZR, R5										
  execution.go:408	0x100212720		f100083f		CMP $2, R1										
  execution.go:408	0x100212724		540001ad		BLE 13(PC)										
  execution.go:409	0x100212728		a94cddd6		LDP 200(R14), (R22, R23)								
  execution.go:409	0x10021272c		b9401a98		MOVWU 24(R20), R24									
  execution.go:409	0x100212730		91000b18		ADD $2, R24, R24									
  execution.go:409	0x100212734		2a1803f8		MOVW R24, R24										
  execution.go:409	0x100212738		eb17031f		CMP R23, R24										
  execution.go:409	0x10021273c		5400ff02		BCS 2040(PC)										
  execution.go:409	0x100212740		b8787ad6		MOVWU (R22)(R24<<2), R22								
  execution.go:409	0x100212744		eb1302df		CMP R19, R22										
  execution.go:409	0x100212748		5400fe42		BCS 2034(PC)										
  execution.go:409	0x10021274c		8b161196		ADD R22<<4, R12, R22									
  execution.go:409	0x100212750		a94022c7		LDP (R22), (R7, R8)									
  execution.go:409	0x100212754		14000003		JMP 3(PC)										
  execution.go:409	0x100212758		aa1f03e7		MOVD ZR, R7										
  execution.go:409	0x10021275c		aa1f03e8		MOVD ZR, R8										
  execution.go:412	0x100212760		a947ddd6		LDP 120(R14), (R22, R23)								
  execution.go:412	0x100212764		b9400698		MOVWU 4(R20), R24									
  execution.go:412	0x100212768		aa1803f9		MOVD R24, R25										
  execution.go:412	0x10021276c		eb17033f		CMP R23, R25										
  execution.go:412	0x100212770		5400fca2		BCS 2021(PC)										
  execution.go:412	0x100212774		f9400000		MOVD (R0), R0										
  execution.go:412	0x100212778		d3787f09		UBFIZ $8, R24, $32, R9									
  execution.go:412	0x10021277c		cb191529		SUB R25<<5, R9, R9									
  execution.go:412	0x100212780		8b0902c2		ADD R9, R22, R2										
  execution.go:412	0x100212784		aa0d03e1		MOVD R13, R1										
  execution.go:412	0x100212788		97ffc37a		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess(SB)		
  execution.go:413	0x10021278c		b500b782		CBNZ R2, 1468(PC)									
  execution.go:420	0x100212790		f940c3e9		MOVD 384(RSP), R9									
  execution.go:420	0x100212794		b9400929		MOVWU 8(R9), R9										
  execution.go:420	0x100212798		3100053f		CMNW $1, R9										
  execution.go:420	0x10021279c		54000100		BEQ 8(PC)										
  execution.go:421	0x1002127a0		f94087ea		MOVD 264(RSP), R10									
  execution.go:421	0x1002127a4		eb0a013f		CMP R10, R9										
  execution.go:421	0x1002127a8		5400fac2		BCS 2006(PC)										
  execution.go:421	0x1002127ac		f9409beb		MOVD 304(RSP), R11									
  execution.go:421	0x1002127b0		8b091169		ADD R9<<4, R11, R9									
  execution.go:421	0x1002127b4		a9000520		STP (R0, R1), (R9)									
  execution.go:421	0x1002127b8		1400000a		JMP 10(PC)										
  execution.go:361	0x1002127bc		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x1002127c0		f9409beb		MOVD 304(RSP), R11									
  execution.go:420	0x1002127c4		14000007		JMP 7(PC)										
  execution.go:424	0x1002127c8		b9000951		MOVW R17, 8(R10)									
  execution.go:425	0x1002127cc		9400091d		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC(SB)		
  execution.go:425	0x1002127d0		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:425	0x1002127d4		3500b8c1		CBNZW R1, 1478(PC)									
  execution.go:361	0x1002127d8		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x1002127dc		f9409beb		MOVD 304(RSP), R11									
  execution.go:429	0x1002127e0		b94107e9		MOVWU 260(RSP), R9									
  execution.go:429	0x1002127e4		91000531		ADD $1, R9, R17										
  execution.go:430	0x1002127e8		f940b7e9		MOVD 360(RSP), R9									
  execution.go:430	0x1002127ec		b9000931		MOVW R17, 8(R9)										
  execution.go:209	0x1002127f0		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x1002127f4		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002127f8		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002127fc		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x100212800		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100212804		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100212808		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10021280c		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100212810		f9408bf0		MOVD 272(RSP), R16									
  execution.go:361	0x100212814		f94087f3		MOVD 264(RSP), R19									
  execution.go:341	0x100212818		f94093f5		MOVD 288(RSP), R21									
  execution.go:431	0x10021281c		17fffe62		JMP -414(PC)										
  execution.go:479	0x100212820		d1011437		SUB $69, R1, R23									
  execution.go:479	0x100212824		7101feff		CMPW $127, R23										
  execution.go:479	0x100212828		54005468		BHI 675(PC)										
  execution.go:480	0x10021282c		aa0103f6		MOVD R1, R22										
  execution.go:480	0x100212830		d10116d6		SUB $69, R22, R22									
  execution.go:480	0x100212834		f0000fc2		ADRP 2076672(PC), R2									
  execution.go:480	0x100212838		91390042		ADD $3648, R2, R2									
  execution.go:480	0x10021283c		f876785b		MOVD (R2)(R22<<3), R27									
  execution.go:480	0x100212840		d61f0360		JMP (R27)										
  execution.go:482	0x100212844		b9400e96		MOVWU 12(R20), R22									
  execution.go:482	0x100212848		eb1302df		CMP R19, R22										
  execution.go:482	0x10021284c		5400f542		BCS 1962(PC)										
  execution.go:482	0x100212850		8b161196		ADD R22<<4, R12, R22									
  execution.go:482	0x100212854		f94002d6		MOVD (R22), R22										
  integer.go:9		0x100212858		710002df		CMPW $0, R22										
  integer.go:9		0x10021285c		9a9f17f6		CSET EQ, R22										
  execution.go:482	0x100212860		14000293		JMP 659(PC)										
  execution.go:484	0x100212864		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:484	0x100212868		eb1302df		CMP R19, R22										
  execution.go:484	0x10021286c		5400f3e2		BCS 1951(PC)										
  execution.go:484	0x100212870		8b161196		ADD R22<<4, R12, R22									
  execution.go:484	0x100212874		eb1302ff		CMP R19, R23										
  execution.go:484	0x100212878		5400f322		BCS 1945(PC)										
  execution.go:484	0x10021287c		f94002d8		MOVD (R22), R24										
  execution.go:484	0x100212880		8b171197		ADD R23<<4, R12, R23									
  execution.go:484	0x100212884		f94002f7		MOVD (R23), R23										
  integer.go:10		0x100212888		6b1802ff		CMPW R24, R23										
  integer.go:10		0x10021288c		9a9f17f6		CSET EQ, R22										
  execution.go:484	0x100212890		14000287		JMP 647(PC)										
  execution.go:486	0x100212894		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:486	0x100212898		eb1302df		CMP R19, R22										
  execution.go:486	0x10021289c		5400f1a2		BCS 1933(PC)										
  execution.go:486	0x1002128a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:486	0x1002128a4		eb1302ff		CMP R19, R23										
  execution.go:486	0x1002128a8		5400f0e2		BCS 1927(PC)										
  execution.go:486	0x1002128ac		f94002d8		MOVD (R22), R24										
  execution.go:486	0x1002128b0		8b171197		ADD R23<<4, R12, R23									
  execution.go:486	0x1002128b4		f94002f7		MOVD (R23), R23										
  integer.go:11		0x1002128b8		6b1802ff		CMPW R24, R23										
  integer.go:11		0x1002128bc		9a9f07f6		CSET NE, R22										
  execution.go:486	0x1002128c0		1400027b		JMP 635(PC)										
  execution.go:488	0x1002128c4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:488	0x1002128c8		eb1302df		CMP R19, R22										
  execution.go:488	0x1002128cc		5400ef62		BCS 1915(PC)										
  execution.go:488	0x1002128d0		8b161196		ADD R22<<4, R12, R22									
  execution.go:488	0x1002128d4		eb1302ff		CMP R19, R23										
  execution.go:488	0x1002128d8		5400eea2		BCS 1909(PC)										
  execution.go:488	0x1002128dc		f94002d8		MOVD (R22), R24										
  execution.go:488	0x1002128e0		8b171197		ADD R23<<4, R12, R23									
  execution.go:488	0x1002128e4		f94002f7		MOVD (R23), R23										
  integer.go:12		0x1002128e8		6b1802ff		CMPW R24, R23										
  integer.go:12		0x1002128ec		9a9fd7f6		CSET GT, R22										
  execution.go:488	0x1002128f0		1400026f		JMP 623(PC)										
  execution.go:490	0x1002128f4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:490	0x1002128f8		eb1302df		CMP R19, R22										
  execution.go:490	0x1002128fc		5400ed22		BCS 1897(PC)										
  execution.go:490	0x100212900		8b161196		ADD R22<<4, R12, R22									
  execution.go:490	0x100212904		eb1302ff		CMP R19, R23										
  execution.go:490	0x100212908		5400ec62		BCS 1891(PC)										
  execution.go:490	0x10021290c		f94002d8		MOVD (R22), R24										
  execution.go:490	0x100212910		8b171197		ADD R23<<4, R12, R23									
  execution.go:490	0x100212914		f94002f7		MOVD (R23), R23										
  integer.go:13		0x100212918		6b1802ff		CMPW R24, R23										
  integer.go:13		0x10021291c		9a9f97f6		CSET HI, R22										
  execution.go:490	0x100212920		14000263		JMP 611(PC)										
  execution.go:492	0x100212924		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:492	0x100212928		eb1302df		CMP R19, R22										
  execution.go:492	0x10021292c		5400eae2		BCS 1879(PC)										
  execution.go:492	0x100212930		8b161196		ADD R22<<4, R12, R22									
  execution.go:492	0x100212934		eb1302ff		CMP R19, R23										
  execution.go:492	0x100212938		5400ea22		BCS 1873(PC)										
  execution.go:492	0x10021293c		f94002d8		MOVD (R22), R24										
  execution.go:492	0x100212940		8b171197		ADD R23<<4, R12, R23									
  execution.go:492	0x100212944		f94002f7		MOVD (R23), R23										
  integer.go:14		0x100212948		6b1802ff		CMPW R24, R23										
  integer.go:14		0x10021294c		9a9fa7f6		CSET LT, R22										
  execution.go:492	0x100212950		14000257		JMP 599(PC)										
  execution.go:494	0x100212954		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:494	0x100212958		eb1302df		CMP R19, R22										
  execution.go:494	0x10021295c		5400e8a2		BCS 1861(PC)										
  execution.go:494	0x100212960		8b161196		ADD R22<<4, R12, R22									
  execution.go:494	0x100212964		eb1302ff		CMP R19, R23										
  execution.go:494	0x100212968		5400e7e2		BCS 1855(PC)										
  execution.go:494	0x10021296c		f94002d8		MOVD (R22), R24										
  execution.go:494	0x100212970		8b171197		ADD R23<<4, R12, R23									
  execution.go:494	0x100212974		f94002f7		MOVD (R23), R23										
  integer.go:15		0x100212978		6b1802ff		CMPW R24, R23										
  integer.go:15		0x10021297c		9a9f27f6		CSET LO, R22										
  execution.go:494	0x100212980		1400024b		JMP 587(PC)										
  execution.go:496	0x100212984		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:496	0x100212988		eb1302df		CMP R19, R22										
  execution.go:496	0x10021298c		5400e662		BCS 1843(PC)										
  execution.go:496	0x100212990		8b161196		ADD R22<<4, R12, R22									
  execution.go:496	0x100212994		eb1302ff		CMP R19, R23										
  execution.go:496	0x100212998		5400e5a2		BCS 1837(PC)										
  execution.go:496	0x10021299c		f94002d8		MOVD (R22), R24										
  execution.go:496	0x1002129a0		8b171197		ADD R23<<4, R12, R23									
  execution.go:496	0x1002129a4		f94002f7		MOVD (R23), R23										
  integer.go:16		0x1002129a8		6b1802ff		CMPW R24, R23										
  integer.go:16		0x1002129ac		9a9fb7f6		CSET GE, R22										
  execution.go:496	0x1002129b0		1400023f		JMP 575(PC)										
  execution.go:498	0x1002129b4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:498	0x1002129b8		eb1302df		CMP R19, R22										
  execution.go:498	0x1002129bc		5400e422		BCS 1825(PC)										
  execution.go:498	0x1002129c0		8b161196		ADD R22<<4, R12, R22									
  execution.go:498	0x1002129c4		eb1302ff		CMP R19, R23										
  execution.go:498	0x1002129c8		5400e362		BCS 1819(PC)										
  execution.go:498	0x1002129cc		f94002d8		MOVD (R22), R24										
  execution.go:498	0x1002129d0		8b171197		ADD R23<<4, R12, R23									
  execution.go:498	0x1002129d4		f94002f7		MOVD (R23), R23										
  integer.go:17		0x1002129d8		6b1802ff		CMPW R24, R23										
  integer.go:17		0x1002129dc		9a9f37f6		CSET HS, R22										
  execution.go:498	0x1002129e0		14000233		JMP 563(PC)										
  execution.go:500	0x1002129e4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:500	0x1002129e8		eb1302df		CMP R19, R22										
  execution.go:500	0x1002129ec		5400e1e2		BCS 1807(PC)										
  execution.go:500	0x1002129f0		8b161196		ADD R22<<4, R12, R22									
  execution.go:500	0x1002129f4		eb1302ff		CMP R19, R23										
  execution.go:500	0x1002129f8		5400e122		BCS 1801(PC)										
  execution.go:500	0x1002129fc		f94002d8		MOVD (R22), R24										
  execution.go:500	0x100212a00		8b171197		ADD R23<<4, R12, R23									
  execution.go:500	0x100212a04		f94002f7		MOVD (R23), R23										
  integer.go:18		0x100212a08		6b1802ff		CMPW R24, R23										
  integer.go:18		0x100212a0c		9a9fc7f6		CSET LE, R22										
  execution.go:500	0x100212a10		14000227		JMP 551(PC)										
  execution.go:502	0x100212a14		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:502	0x100212a18		eb1302df		CMP R19, R22										
  execution.go:502	0x100212a1c		5400dfa2		BCS 1789(PC)										
  execution.go:502	0x100212a20		8b161196		ADD R22<<4, R12, R22									
  execution.go:502	0x100212a24		eb1302ff		CMP R19, R23										
  execution.go:502	0x100212a28		5400dee2		BCS 1783(PC)										
  execution.go:502	0x100212a2c		f94002d8		MOVD (R22), R24										
  execution.go:502	0x100212a30		8b171197		ADD R23<<4, R12, R23									
  execution.go:502	0x100212a34		f94002f7		MOVD (R23), R23										
  integer.go:19		0x100212a38		6b1802ff		CMPW R24, R23										
  integer.go:19		0x100212a3c		9a9f87f6		CSET LS, R22										
  execution.go:502	0x100212a40		1400021b		JMP 539(PC)										
  execution.go:504	0x100212a44		b9400e96		MOVWU 12(R20), R22									
  execution.go:504	0x100212a48		eb1302df		CMP R19, R22										
  execution.go:504	0x100212a4c		5400dd62		BCS 1771(PC)										
  execution.go:504	0x100212a50		8b161197		ADD R22<<4, R12, R23									
  execution.go:504	0x100212a54		f94002f7		MOVD (R23), R23										
  integer.go:20		0x100212a58		f10002ff		CMP $0, R23										
  integer.go:20		0x100212a5c		9a9f17f6		CSET EQ, R22										
  execution.go:504	0x100212a60		14000213		JMP 531(PC)										
  execution.go:506	0x100212a64		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:506	0x100212a68		eb1302df		CMP R19, R22										
  execution.go:506	0x100212a6c		5400dc02		BCS 1760(PC)										
  execution.go:506	0x100212a70		8b161196		ADD R22<<4, R12, R22									
  execution.go:506	0x100212a74		eb1302ff		CMP R19, R23										
  execution.go:506	0x100212a78		5400db42		BCS 1754(PC)										
  execution.go:506	0x100212a7c		f94002d8		MOVD (R22), R24										
  execution.go:506	0x100212a80		8b171197		ADD R23<<4, R12, R23									
  execution.go:506	0x100212a84		f94002f7		MOVD (R23), R23										
  integer.go:21		0x100212a88		eb1802ff		CMP R24, R23										
  integer.go:21		0x100212a8c		9a9f17f6		CSET EQ, R22										
  execution.go:506	0x100212a90		14000207		JMP 519(PC)										
  execution.go:508	0x100212a94		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:508	0x100212a98		eb1302df		CMP R19, R22										
  execution.go:508	0x100212a9c		5400d9c2		BCS 1742(PC)										
  execution.go:508	0x100212aa0		8b161196		ADD R22<<4, R12, R22									
  execution.go:508	0x100212aa4		eb1302ff		CMP R19, R23										
  execution.go:508	0x100212aa8		5400d902		BCS 1736(PC)										
  execution.go:508	0x100212aac		f94002d8		MOVD (R22), R24										
  execution.go:508	0x100212ab0		8b171197		ADD R23<<4, R12, R23									
  execution.go:508	0x100212ab4		f94002f7		MOVD (R23), R23										
  integer.go:22		0x100212ab8		eb1802ff		CMP R24, R23										
  integer.go:22		0x100212abc		9a9f07f6		CSET NE, R22										
  execution.go:508	0x100212ac0		140001fb		JMP 507(PC)										
  execution.go:510	0x100212ac4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:510	0x100212ac8		eb1302df		CMP R19, R22										
  execution.go:510	0x100212acc		5400d782		BCS 1724(PC)										
  execution.go:510	0x100212ad0		8b161196		ADD R22<<4, R12, R22									
  execution.go:510	0x100212ad4		eb1302ff		CMP R19, R23										
  execution.go:510	0x100212ad8		5400d6c2		BCS 1718(PC)										
  execution.go:510	0x100212adc		f94002d8		MOVD (R22), R24										
  execution.go:510	0x100212ae0		8b171197		ADD R23<<4, R12, R23									
  execution.go:510	0x100212ae4		f94002f7		MOVD (R23), R23										
  integer.go:23		0x100212ae8		eb1802ff		CMP R24, R23										
  integer.go:23		0x100212aec		9a9fd7f6		CSET GT, R22										
  execution.go:510	0x100212af0		140001ef		JMP 495(PC)										
  execution.go:512	0x100212af4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:512	0x100212af8		eb1302df		CMP R19, R22										
  execution.go:512	0x100212afc		5400d542		BCS 1706(PC)										
  execution.go:512	0x100212b00		8b161196		ADD R22<<4, R12, R22									
  execution.go:512	0x100212b04		eb1302ff		CMP R19, R23										
  execution.go:512	0x100212b08		5400d482		BCS 1700(PC)										
  execution.go:512	0x100212b0c		f94002d8		MOVD (R22), R24										
  execution.go:512	0x100212b10		8b171197		ADD R23<<4, R12, R23									
  execution.go:512	0x100212b14		f94002f7		MOVD (R23), R23										
  integer.go:24		0x100212b18		eb1802ff		CMP R24, R23										
  integer.go:24		0x100212b1c		9a9f97f6		CSET HI, R22										
  execution.go:512	0x100212b20		140001e3		JMP 483(PC)										
  execution.go:514	0x100212b24		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:514	0x100212b28		eb1302df		CMP R19, R22										
  execution.go:514	0x100212b2c		5400d302		BCS 1688(PC)										
  execution.go:514	0x100212b30		8b161196		ADD R22<<4, R12, R22									
  execution.go:514	0x100212b34		eb1302ff		CMP R19, R23										
  execution.go:514	0x100212b38		5400d242		BCS 1682(PC)										
  execution.go:514	0x100212b3c		f94002d8		MOVD (R22), R24										
  execution.go:514	0x100212b40		8b171197		ADD R23<<4, R12, R23									
  execution.go:514	0x100212b44		f94002f7		MOVD (R23), R23										
  integer.go:25		0x100212b48		eb1802ff		CMP R24, R23										
  integer.go:25		0x100212b4c		9a9fa7f6		CSET LT, R22										
  execution.go:514	0x100212b50		140001d7		JMP 471(PC)										
  execution.go:516	0x100212b54		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:516	0x100212b58		eb1302df		CMP R19, R22										
  execution.go:516	0x100212b5c		5400d0c2		BCS 1670(PC)										
  execution.go:516	0x100212b60		8b161196		ADD R22<<4, R12, R22									
  execution.go:516	0x100212b64		eb1302ff		CMP R19, R23										
  execution.go:516	0x100212b68		5400d002		BCS 1664(PC)										
  execution.go:516	0x100212b6c		f94002d8		MOVD (R22), R24										
  execution.go:516	0x100212b70		8b171197		ADD R23<<4, R12, R23									
  execution.go:516	0x100212b74		f94002f7		MOVD (R23), R23										
  integer.go:26		0x100212b78		eb1802ff		CMP R24, R23										
  integer.go:26		0x100212b7c		9a9f27f6		CSET LO, R22										
  execution.go:516	0x100212b80		140001cb		JMP 459(PC)										
  execution.go:518	0x100212b84		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:518	0x100212b88		eb1302df		CMP R19, R22										
  execution.go:518	0x100212b8c		5400ce82		BCS 1652(PC)										
  execution.go:518	0x100212b90		8b161196		ADD R22<<4, R12, R22									
  execution.go:518	0x100212b94		eb1302ff		CMP R19, R23										
  execution.go:518	0x100212b98		5400cdc2		BCS 1646(PC)										
  execution.go:518	0x100212b9c		f94002d8		MOVD (R22), R24										
  execution.go:518	0x100212ba0		8b171197		ADD R23<<4, R12, R23									
  execution.go:518	0x100212ba4		f94002f7		MOVD (R23), R23										
  integer.go:27		0x100212ba8		eb1802ff		CMP R24, R23										
  integer.go:27		0x100212bac		9a9fb7f6		CSET GE, R22										
  execution.go:518	0x100212bb0		140001bf		JMP 447(PC)										
  execution.go:520	0x100212bb4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:520	0x100212bb8		eb1302df		CMP R19, R22										
  execution.go:520	0x100212bbc		5400cc42		BCS 1634(PC)										
  execution.go:520	0x100212bc0		8b161196		ADD R22<<4, R12, R22									
  execution.go:520	0x100212bc4		eb1302ff		CMP R19, R23										
  execution.go:520	0x100212bc8		5400cb82		BCS 1628(PC)										
  execution.go:520	0x100212bcc		f94002d8		MOVD (R22), R24										
  execution.go:520	0x100212bd0		8b171197		ADD R23<<4, R12, R23									
  execution.go:520	0x100212bd4		f94002f7		MOVD (R23), R23										
  integer.go:28		0x100212bd8		eb1802ff		CMP R24, R23										
  integer.go:28		0x100212bdc		9a9f37f6		CSET HS, R22										
  execution.go:520	0x100212be0		140001b3		JMP 435(PC)										
  execution.go:522	0x100212be4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:522	0x100212be8		eb1302df		CMP R19, R22										
  execution.go:522	0x100212bec		5400ca02		BCS 1616(PC)										
  execution.go:522	0x100212bf0		8b161196		ADD R22<<4, R12, R22									
  execution.go:522	0x100212bf4		eb1302ff		CMP R19, R23										
  execution.go:522	0x100212bf8		5400c942		BCS 1610(PC)										
  execution.go:522	0x100212bfc		f94002d8		MOVD (R22), R24										
  execution.go:522	0x100212c00		8b171197		ADD R23<<4, R12, R23									
  execution.go:522	0x100212c04		f94002f7		MOVD (R23), R23										
  integer.go:29		0x100212c08		eb1802ff		CMP R24, R23										
  integer.go:29		0x100212c0c		9a9fc7f6		CSET LE, R22										
  execution.go:522	0x100212c10		140001a7		JMP 423(PC)										
  execution.go:524	0x100212c14		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:524	0x100212c18		eb1302df		CMP R19, R22										
  execution.go:524	0x100212c1c		5400c7c2		BCS 1598(PC)										
  execution.go:524	0x100212c20		8b161196		ADD R22<<4, R12, R22									
  execution.go:524	0x100212c24		eb1302ff		CMP R19, R23										
  execution.go:524	0x100212c28		5400c702		BCS 1592(PC)										
  execution.go:524	0x100212c2c		f94002d8		MOVD (R22), R24										
  execution.go:524	0x100212c30		8b171197		ADD R23<<4, R12, R23									
  execution.go:524	0x100212c34		f94002f7		MOVD (R23), R23										
  integer.go:30		0x100212c38		eb1802ff		CMP R24, R23										
  integer.go:30		0x100212c3c		9a9f87f6		CSET LS, R22										
  execution.go:524	0x100212c40		1400019b		JMP 411(PC)										
  execution.go:526	0x100212c44		b9400e96		MOVWU 12(R20), R22									
  execution.go:526	0x100212c48		eb1302df		CMP R19, R22										
  execution.go:526	0x100212c4c		5400c582		BCS 1580(PC)										
  execution.go:526	0x100212c50		8b161197		ADD R22<<4, R12, R23									
  execution.go:526	0x100212c54		f94002f7		MOVD (R23), R23										
  integer.go:31		0x100212c58		d503201f		NOOP											
  bits.go:34		0x100212c5c		5ac012f6		CLZW R23, R22										
  execution.go:526	0x100212c60		14000193		JMP 403(PC)										
  execution.go:528	0x100212c64		b9400e96		MOVWU 12(R20), R22									
  execution.go:528	0x100212c68		eb1302df		CMP R19, R22										
  execution.go:528	0x100212c6c		5400c422		BCS 1569(PC)										
  execution.go:528	0x100212c70		8b161197		ADD R22<<4, R12, R23									
  execution.go:528	0x100212c74		f94002f7		MOVD (R23), R23										
  integer.go:32		0x100212c78		5ac002f7		RBITW R23, R23										
  integer.go:32		0x100212c7c		5ac012f6		CLZW R23, R22										
  execution.go:528	0x100212c80		1400018b		JMP 395(PC)										
  execution.go:538	0x100212c84		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:538	0x100212c88		eb1302df		CMP R19, R22										
  execution.go:538	0x100212c8c		5400c2c2		BCS 1558(PC)										
  execution.go:538	0x100212c90		8b161196		ADD R22<<4, R12, R22									
  execution.go:538	0x100212c94		eb1302ff		CMP R19, R23										
  execution.go:538	0x100212c98		5400c202		BCS 1552(PC)										
  execution.go:538	0x100212c9c		f94002d8		MOVD (R22), R24										
  execution.go:538	0x100212ca0		8b171197		ADD R23<<4, R12, R23									
  execution.go:538	0x100212ca4		f94002f7		MOVD (R23), R23										
  integer.go:34		0x100212ca8		8b170317		ADD R23, R24, R23									
  integer.go:34		0x100212cac		2a1703f6		MOVW R23, R22										
  execution.go:538	0x100212cb0		1400017f		JMP 383(PC)										
  execution.go:540	0x100212cb4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:540	0x100212cb8		eb1302df		CMP R19, R22										
  execution.go:540	0x100212cbc		5400c082		BCS 1540(PC)										
  execution.go:540	0x100212cc0		8b161196		ADD R22<<4, R12, R22									
  execution.go:540	0x100212cc4		eb1302ff		CMP R19, R23										
  execution.go:540	0x100212cc8		5400bfc2		BCS 1534(PC)										
  execution.go:540	0x100212ccc		f94002d8		MOVD (R22), R24										
  execution.go:540	0x100212cd0		8b171197		ADD R23<<4, R12, R23									
  execution.go:540	0x100212cd4		f94002f7		MOVD (R23), R23										
  integer.go:35		0x100212cd8		cb170317		SUB R23, R24, R23									
  integer.go:35		0x100212cdc		2a1703f6		MOVW R23, R22										
  execution.go:540	0x100212ce0		14000173		JMP 371(PC)										
  execution.go:542	0x100212ce4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:542	0x100212ce8		eb1302df		CMP R19, R22										
  execution.go:542	0x100212cec		5400be42		BCS 1522(PC)										
  execution.go:542	0x100212cf0		8b161196		ADD R22<<4, R12, R22									
  execution.go:542	0x100212cf4		eb1302ff		CMP R19, R23										
  execution.go:542	0x100212cf8		5400bd82		BCS 1516(PC)										
  execution.go:542	0x100212cfc		f94002d8		MOVD (R22), R24										
  execution.go:542	0x100212d00		8b171197		ADD R23<<4, R12, R23									
  execution.go:542	0x100212d04		f94002f7		MOVD (R23), R23										
  integer.go:36		0x100212d08		1b177f16		MULW R23, R24, R22									
  execution.go:542	0x100212d0c		14000168		JMP 360(PC)										
  execution.go:544	0x100212d10		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:544	0x100212d14		eb1302df		CMP R19, R22										
  execution.go:544	0x100212d18		5400bc22		BCS 1505(PC)										
  execution.go:544	0x100212d1c		8b161196		ADD R22<<4, R12, R22									
  execution.go:544	0x100212d20		eb1302ff		CMP R19, R23										
  execution.go:544	0x100212d24		5400bb62		BCS 1499(PC)										
  execution.go:544	0x100212d28		f94002d8		MOVD (R22), R24										
  execution.go:544	0x100212d2c		8b171197		ADD R23<<4, R12, R23									
  execution.go:544	0x100212d30		f94002f7		MOVD (R23), R23										
  integer.go:37		0x100212d34		8a170317		AND R23, R24, R23									
  integer.go:37		0x100212d38		2a1703f6		MOVW R23, R22										
  execution.go:544	0x100212d3c		1400015c		JMP 348(PC)										
  execution.go:546	0x100212d40		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:546	0x100212d44		eb1302df		CMP R19, R22										
  execution.go:546	0x100212d48		5400b9e2		BCS 1487(PC)										
  execution.go:546	0x100212d4c		8b161196		ADD R22<<4, R12, R22									
  execution.go:546	0x100212d50		eb1302ff		CMP R19, R23										
  execution.go:546	0x100212d54		5400b922		BCS 1481(PC)										
  execution.go:546	0x100212d58		f94002d8		MOVD (R22), R24										
  execution.go:546	0x100212d5c		8b171197		ADD R23<<4, R12, R23									
  execution.go:546	0x100212d60		f94002f7		MOVD (R23), R23										
  integer.go:38		0x100212d64		aa170317		ORR R23, R24, R23									
  integer.go:38		0x100212d68		2a1703f6		MOVW R23, R22										
  execution.go:546	0x100212d6c		14000150		JMP 336(PC)										
  execution.go:548	0x100212d70		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:548	0x100212d74		eb1302df		CMP R19, R22										
  execution.go:548	0x100212d78		5400b7a2		BCS 1469(PC)										
  execution.go:548	0x100212d7c		8b161196		ADD R22<<4, R12, R22									
  execution.go:548	0x100212d80		eb1302ff		CMP R19, R23										
  execution.go:548	0x100212d84		5400b6e2		BCS 1463(PC)										
  execution.go:548	0x100212d88		f94002d8		MOVD (R22), R24										
  execution.go:548	0x100212d8c		8b171197		ADD R23<<4, R12, R23									
  execution.go:548	0x100212d90		f94002f7		MOVD (R23), R23										
  integer.go:39		0x100212d94		ca170317		EOR R23, R24, R23									
  integer.go:39		0x100212d98		2a1703f6		MOVW R23, R22										
  execution.go:548	0x100212d9c		14000144		JMP 324(PC)										
  execution.go:550	0x100212da0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:550	0x100212da4		eb1302df		CMP R19, R22										
  execution.go:550	0x100212da8		5400b562		BCS 1451(PC)										
  execution.go:550	0x100212dac		8b161196		ADD R22<<4, R12, R22									
  execution.go:550	0x100212db0		eb1302ff		CMP R19, R23										
  execution.go:550	0x100212db4		5400b4a2		BCS 1445(PC)										
  execution.go:550	0x100212db8		f94002d8		MOVD (R22), R24										
  execution.go:550	0x100212dbc		8b171197		ADD R23<<4, R12, R23									
  execution.go:550	0x100212dc0		f94002f7		MOVD (R23), R23										
  integer.go:40		0x100212dc4		924012f7		AND $31, R23, R23									
  integer.go:40		0x100212dc8		9ad72317		LSL R23, R24, R23									
  integer.go:40		0x100212dcc		2a1703f6		MOVW R23, R22										
  execution.go:550	0x100212dd0		14000137		JMP 311(PC)										
  execution.go:552	0x100212dd4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:552	0x100212dd8		eb1302df		CMP R19, R22										
  execution.go:552	0x100212ddc		5400b302		BCS 1432(PC)										
  execution.go:552	0x100212de0		8b161196		ADD R22<<4, R12, R22									
  execution.go:552	0x100212de4		eb1302ff		CMP R19, R23										
  execution.go:552	0x100212de8		5400b242		BCS 1426(PC)										
  execution.go:552	0x100212dec		f94002d8		MOVD (R22), R24										
  execution.go:552	0x100212df0		8b171197		ADD R23<<4, R12, R23									
  execution.go:552	0x100212df4		f94002f7		MOVD (R23), R23										
  integer.go:41		0x100212df8		93407f18		SXTW R24, R24										
  integer.go:41		0x100212dfc		924012f7		AND $31, R23, R23									
  integer.go:41		0x100212e00		9ad72b17		ASR R23, R24, R23									
  integer.go:41		0x100212e04		2a1703f6		MOVW R23, R22										
  execution.go:552	0x100212e08		14000129		JMP 297(PC)										
  execution.go:554	0x100212e0c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:554	0x100212e10		eb1302df		CMP R19, R22										
  execution.go:554	0x100212e14		5400b082		BCS 1412(PC)										
  execution.go:554	0x100212e18		8b161196		ADD R22<<4, R12, R22									
  execution.go:554	0x100212e1c		eb1302ff		CMP R19, R23										
  execution.go:554	0x100212e20		5400afc2		BCS 1406(PC)										
  execution.go:554	0x100212e24		f94002d8		MOVD (R22), R24										
  execution.go:554	0x100212e28		8b171197		ADD R23<<4, R12, R23									
  execution.go:554	0x100212e2c		f94002f7		MOVD (R23), R23										
  integer.go:42		0x100212e30		2a1803f8		MOVW R24, R24										
  integer.go:42		0x100212e34		924012f7		AND $31, R23, R23									
  integer.go:42		0x100212e38		9ad72717		LSR R23, R24, R23									
  integer.go:42		0x100212e3c		2a1703f6		MOVW R23, R22										
  execution.go:554	0x100212e40		1400011b		JMP 283(PC)										
  execution.go:556	0x100212e44		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:556	0x100212e48		eb1302df		CMP R19, R22										
  execution.go:556	0x100212e4c		5400ae02		BCS 1392(PC)										
  execution.go:556	0x100212e50		8b161196		ADD R22<<4, R12, R22									
  execution.go:556	0x100212e54		eb1302ff		CMP R19, R23										
  execution.go:556	0x100212e58		5400ad42		BCS 1386(PC)										
  execution.go:556	0x100212e5c		f94002d8		MOVD (R22), R24										
  execution.go:556	0x100212e60		8b171197		ADD R23<<4, R12, R23									
  execution.go:556	0x100212e64		f94002f7		MOVD (R23), R23										
  integer.go:43		0x100212e68		cb1703f7		NEG R23, R23										
  integer.go:43		0x100212e6c		1ad72f16		RORW R23, R24, R22									
  execution.go:556	0x100212e70		1400010f		JMP 271(PC)										
  execution.go:558	0x100212e74		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:558	0x100212e78		eb1302df		CMP R19, R22										
  execution.go:558	0x100212e7c		5400abc2		BCS 1374(PC)										
  execution.go:558	0x100212e80		8b161196		ADD R22<<4, R12, R22									
  execution.go:558	0x100212e84		eb1302ff		CMP R19, R23										
  execution.go:558	0x100212e88		5400ab02		BCS 1368(PC)										
  execution.go:558	0x100212e8c		f94002d8		MOVD (R22), R24										
  execution.go:558	0x100212e90		8b171197		ADD R23<<4, R12, R23									
  execution.go:558	0x100212e94		f94002f7		MOVD (R23), R23										
  integer.go:44		0x100212e98		1ad72f16		RORW R23, R24, R22									
  execution.go:558	0x100212e9c		14000104		JMP 260(PC)										
  execution.go:560	0x100212ea0		b9400e96		MOVWU 12(R20), R22									
  execution.go:560	0x100212ea4		eb1302df		CMP R19, R22										
  execution.go:560	0x100212ea8		5400a9a2		BCS 1357(PC)										
  execution.go:560	0x100212eac		8b161197		ADD R22<<4, R12, R23									
  execution.go:560	0x100212eb0		f94002f7		MOVD (R23), R23										
  integer.go:45		0x100212eb4		d503201f		NOOP											
  bits.go:37		0x100212eb8		dac012f6		CLZ R23, R22										
  execution.go:560	0x100212ebc		140000fc		JMP 252(PC)										
  execution.go:562	0x100212ec0		b9400e96		MOVWU 12(R20), R22									
  execution.go:562	0x100212ec4		eb1302df		CMP R19, R22										
  execution.go:562	0x100212ec8		5400a842		BCS 1346(PC)										
  execution.go:562	0x100212ecc		8b161197		ADD R22<<4, R12, R23									
  execution.go:562	0x100212ed0		f94002f7		MOVD (R23), R23										
  integer.go:46		0x100212ed4		dac002f7		RBIT R23, R23										
  integer.go:46		0x100212ed8		dac012f6		CLZ R23, R22										
  execution.go:562	0x100212edc		140000f4		JMP 244(PC)										
  execution.go:532	0x100212ee0		b9400e96		MOVWU 12(R20), R22									
  execution.go:532	0x100212ee4		eb1302df		CMP R19, R22										
  execution.go:532	0x100212ee8		5400a6e2		BCS 1335(PC)										
  execution.go:532	0x100212eec		8b161197		ADD R22<<4, R12, R23									
  execution.go:532	0x100212ef0		f94002f7		MOVD (R23), R23										
  execution.go:534	0x100212ef4		2a1703f8		MOVW R23, R24										
  execution.go:536	0x100212ef8		d503201f		NOOP											
  execution.go:533	0x100212efc		7101a43f		CMPW $105, R1										
  execution.go:534	0x100212f00		9a970317		CSEL EQ, R24, R23, R23									
  integer.go:47		0x100212f04		9e6702e0		FMOVD R23, F0										
  integer.go:47		0x100212f08		0e205800		VCNT V0.B8, V0.B8									
  integer.go:47		0x100212f0c		2e303800		VUADDLV V0.B8, V0									
  integer.go:47		0x100212f10		9e660016		FMOVD F0, R22										
  execution.go:533	0x100212f14		140000e6		JMP 230(PC)										
  execution.go:564	0x100212f18		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:564	0x100212f1c		eb1302df		CMP R19, R22										
  execution.go:564	0x100212f20		5400a4c2		BCS 1318(PC)										
  execution.go:564	0x100212f24		8b161196		ADD R22<<4, R12, R22									
  execution.go:564	0x100212f28		eb1302ff		CMP R19, R23										
  execution.go:564	0x100212f2c		5400a402		BCS 1312(PC)										
  execution.go:564	0x100212f30		f94002d8		MOVD (R22), R24										
  execution.go:564	0x100212f34		8b171197		ADD R23<<4, R12, R23									
  execution.go:564	0x100212f38		f94002f7		MOVD (R23), R23										
  integer.go:48		0x100212f3c		8b170316		ADD R23, R24, R22									
  execution.go:564	0x100212f40		140000db		JMP 219(PC)										
  execution.go:566	0x100212f44		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:566	0x100212f48		eb1302df		CMP R19, R22										
  execution.go:566	0x100212f4c		5400a2a2		BCS 1301(PC)										
  execution.go:566	0x100212f50		8b161196		ADD R22<<4, R12, R22									
  execution.go:566	0x100212f54		eb1302ff		CMP R19, R23										
  execution.go:566	0x100212f58		5400a1e2		BCS 1295(PC)										
  execution.go:566	0x100212f5c		f94002d8		MOVD (R22), R24										
  execution.go:566	0x100212f60		8b171197		ADD R23<<4, R12, R23									
  execution.go:566	0x100212f64		f94002f7		MOVD (R23), R23										
  integer.go:49		0x100212f68		cb170316		SUB R23, R24, R22									
  execution.go:566	0x100212f6c		140000d0		JMP 208(PC)										
  execution.go:568	0x100212f70		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:568	0x100212f74		eb1302df		CMP R19, R22										
  execution.go:568	0x100212f78		5400a082		BCS 1284(PC)										
  execution.go:568	0x100212f7c		8b161196		ADD R22<<4, R12, R22									
  execution.go:568	0x100212f80		eb1302ff		CMP R19, R23										
  execution.go:568	0x100212f84		54009fc2		BCS 1278(PC)										
  execution.go:568	0x100212f88		f94002d8		MOVD (R22), R24										
  execution.go:568	0x100212f8c		8b171197		ADD R23<<4, R12, R23									
  execution.go:568	0x100212f90		f94002f7		MOVD (R23), R23										
  integer.go:50		0x100212f94		9b187ef6		MUL R24, R23, R22									
  execution.go:568	0x100212f98		140000c5		JMP 197(PC)										
  execution.go:570	0x100212f9c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:570	0x100212fa0		eb1302df		CMP R19, R22										
  execution.go:570	0x100212fa4		54009e62		BCS 1267(PC)										
  execution.go:570	0x100212fa8		8b161196		ADD R22<<4, R12, R22									
  execution.go:570	0x100212fac		eb1302ff		CMP R19, R23										
  execution.go:570	0x100212fb0		54009da2		BCS 1261(PC)										
  execution.go:570	0x100212fb4		f94002d8		MOVD (R22), R24										
  execution.go:570	0x100212fb8		8b171197		ADD R23<<4, R12, R23									
  execution.go:570	0x100212fbc		f94002f7		MOVD (R23), R23										
  integer.go:51		0x100212fc0		8a170316		AND R23, R24, R22									
  execution.go:570	0x100212fc4		140000ba		JMP 186(PC)										
  execution.go:572	0x100212fc8		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:572	0x100212fcc		eb1302df		CMP R19, R22										
  execution.go:572	0x100212fd0		54009c42		BCS 1250(PC)										
  execution.go:572	0x100212fd4		8b161196		ADD R22<<4, R12, R22									
  execution.go:572	0x100212fd8		eb1302ff		CMP R19, R23										
  execution.go:572	0x100212fdc		54009b82		BCS 1244(PC)										
  execution.go:572	0x100212fe0		f94002d8		MOVD (R22), R24										
  execution.go:572	0x100212fe4		8b171197		ADD R23<<4, R12, R23									
  execution.go:572	0x100212fe8		f94002f7		MOVD (R23), R23										
  integer.go:52		0x100212fec		aa170316		ORR R23, R24, R22									
  execution.go:572	0x100212ff0		140000af		JMP 175(PC)										
  execution.go:574	0x100212ff4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:574	0x100212ff8		eb1302df		CMP R19, R22										
  execution.go:574	0x100212ffc		54009a22		BCS 1233(PC)										
  execution.go:574	0x100213000		8b161196		ADD R22<<4, R12, R22									
  execution.go:574	0x100213004		eb1302ff		CMP R19, R23										
  execution.go:574	0x100213008		54009962		BCS 1227(PC)										
  execution.go:574	0x10021300c		f94002d8		MOVD (R22), R24										
  execution.go:574	0x100213010		8b171197		ADD R23<<4, R12, R23									
  execution.go:574	0x100213014		f94002f7		MOVD (R23), R23										
  integer.go:53		0x100213018		ca170316		EOR R23, R24, R22									
  execution.go:574	0x10021301c		140000a4		JMP 164(PC)										
  execution.go:576	0x100213020		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:576	0x100213024		eb1302df		CMP R19, R22										
  execution.go:576	0x100213028		54009802		BCS 1216(PC)										
  execution.go:576	0x10021302c		8b161196		ADD R22<<4, R12, R22									
  execution.go:576	0x100213030		eb1302ff		CMP R19, R23										
  execution.go:576	0x100213034		54009742		BCS 1210(PC)										
  execution.go:576	0x100213038		f94002d8		MOVD (R22), R24										
  execution.go:576	0x10021303c		8b171197		ADD R23<<4, R12, R23									
  execution.go:576	0x100213040		f94002f7		MOVD (R23), R23										
  integer.go:54		0x100213044		9ad72316		LSL R23, R24, R22									
  execution.go:576	0x100213048		14000099		JMP 153(PC)										
  execution.go:578	0x10021304c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:578	0x100213050		eb1302df		CMP R19, R22										
  execution.go:578	0x100213054		540095e2		BCS 1199(PC)										
  execution.go:578	0x100213058		8b161196		ADD R22<<4, R12, R22									
  execution.go:578	0x10021305c		eb1302ff		CMP R19, R23										
  execution.go:578	0x100213060		54009522		BCS 1193(PC)										
  execution.go:578	0x100213064		f94002d8		MOVD (R22), R24										
  execution.go:578	0x100213068		8b171197		ADD R23<<4, R12, R23									
  execution.go:578	0x10021306c		f94002f7		MOVD (R23), R23										
  integer.go:55		0x100213070		9ad72b16		ASR R23, R24, R22									
  execution.go:578	0x100213074		1400008e		JMP 142(PC)										
  execution.go:580	0x100213078		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:580	0x10021307c		eb1302df		CMP R19, R22										
  execution.go:580	0x100213080		540093c2		BCS 1182(PC)										
  execution.go:580	0x100213084		8b161196		ADD R22<<4, R12, R22									
  execution.go:580	0x100213088		eb1302ff		CMP R19, R23										
  execution.go:580	0x10021308c		54009302		BCS 1176(PC)										
  execution.go:580	0x100213090		f94002d8		MOVD (R22), R24										
  execution.go:580	0x100213094		8b171197		ADD R23<<4, R12, R23									
  execution.go:580	0x100213098		f94002f7		MOVD (R23), R23										
  integer.go:56		0x10021309c		9ad72716		LSR R23, R24, R22									
  execution.go:580	0x1002130a0		14000083		JMP 131(PC)										
  execution.go:582	0x1002130a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:582	0x1002130a8		eb1302df		CMP R19, R22										
  execution.go:582	0x1002130ac		540091a2		BCS 1165(PC)										
  execution.go:582	0x1002130b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:582	0x1002130b4		eb1302ff		CMP R19, R23										
  execution.go:582	0x1002130b8		540090e2		BCS 1159(PC)										
  execution.go:582	0x1002130bc		f94002d8		MOVD (R22), R24										
  execution.go:582	0x1002130c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:582	0x1002130c4		f94002f7		MOVD (R23), R23										
  integer.go:57		0x1002130c8		cb1703f7		NEG R23, R23										
  integer.go:57		0x1002130cc		9ad72f16		ROR R23, R24, R22									
  execution.go:582	0x1002130d0		14000077		JMP 119(PC)										
  execution.go:584	0x1002130d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:584	0x1002130d8		eb1302df		CMP R19, R22										
  execution.go:584	0x1002130dc		54008f62		BCS 1147(PC)										
  execution.go:584	0x1002130e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:584	0x1002130e4		eb1302ff		CMP R19, R23										
  execution.go:584	0x1002130e8		54008ea2		BCS 1141(PC)										
  execution.go:584	0x1002130ec		f94002d8		MOVD (R22), R24										
  execution.go:584	0x1002130f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:584	0x1002130f4		f94002f7		MOVD (R23), R23										
  integer.go:58		0x1002130f8		9ad72f16		ROR R23, R24, R22									
  execution.go:584	0x1002130fc		1400006c		JMP 108(PC)										
  execution.go:586	0x100213100		b9400e96		MOVWU 12(R20), R22									
  execution.go:586	0x100213104		eb1302df		CMP R19, R22										
  execution.go:586	0x100213108		54008d42		BCS 1130(PC)										
  execution.go:586	0x10021310c		8b161197		ADD R22<<4, R12, R23									
  execution.go:586	0x100213110		f94002f7		MOVD (R23), R23										
  integer.go:59		0x100213114		2a1703f6		MOVW R23, R22										
  execution.go:586	0x100213118		14000065		JMP 101(PC)										
  execution.go:588	0x10021311c		b9400e96		MOVWU 12(R20), R22									
  execution.go:588	0x100213120		eb1302df		CMP R19, R22										
  execution.go:588	0x100213124		54008c02		BCS 1120(PC)										
  execution.go:588	0x100213128		8b161197		ADD R22<<4, R12, R23									
  execution.go:588	0x10021312c		f94002f7		MOVD (R23), R23										
  integer.go:60		0x100213130		93407ef6		SXTW R23, R22										
  execution.go:588	0x100213134		1400005e		JMP 94(PC)										
  execution.go:590	0x100213138		b9400e96		MOVWU 12(R20), R22									
  execution.go:590	0x10021313c		eb1302df		CMP R19, R22										
  execution.go:590	0x100213140		54008ac2		BCS 1110(PC)										
  execution.go:590	0x100213144		8b161197		ADD R22<<4, R12, R23									
  execution.go:590	0x100213148		f94002f7		MOVD (R23), R23										
  integer.go:61		0x10021314c		2a1703f6		MOVW R23, R22										
  execution.go:590	0x100213150		14000057		JMP 87(PC)										
  execution.go:611	0x100213154		b9401283		MOVWU 16(R20), R3									
  execution.go:611	0x100213158		3100047f		CMNW $1, R3										
  execution.go:611	0x10021315c		540000c0		BEQ 6(PC)										
  execution.go:612	0x100213160		eb13007f		CMP R19, R3										
  execution.go:612	0x100213164		54008962		BCS 1099(PC)										
  execution.go:612	0x100213168		8b031183		ADD R3<<4, R12, R3									
  execution.go:612	0x10021316c		f9400062		MOVD (R3), R2										
  execution.go:612	0x100213170		14000002		JMP 2(PC)										
  execution.go:612	0x100213174		aa1f03e2		MOVD ZR, R2										
  execution.go:614	0x100213178		b9400e83		MOVWU 12(R20), R3									
  execution.go:614	0x10021317c		eb13007f		CMP R19, R3										
  execution.go:614	0x100213180		54008842		BCS 1090(PC)										
  execution.go:614	0x100213184		8b031183		ADD R3<<4, R12, R3									
  execution.go:614	0x100213188		f9400063		MOVD (R3), R3										
  execution.go:614	0x10021318c		aa0103e0		MOVD R1, R0										
  execution.go:614	0x100213190		aa0303e1		MOVD R3, R1										
  execution.go:614	0x100213194		97ffa8c3		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:615	0x100213198		d3401c23		UBFX $0, R1, $8, R3									
  execution.go:615	0x10021319c		34000223		CBZW R3, 17(PC)										
  execution.go:342	0x1002131a0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002131a4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002131a8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x1002131ac		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002131b0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002131b4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002131b8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002131bc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002131c0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002131c4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002131c8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002131cc		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x1002131d0		aa1f03f7		MOVD ZR, R23										
  execution.go:395	0x1002131d4		aa0003f6		MOVD R0, R22										
  execution.go:209	0x1002131d8		f94127e0		MOVD 584(RSP), R0									
  execution.go:616	0x1002131dc		140002da		JMP 730(PC)										
  execution.go:342	0x1002131e0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002131e4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002131e8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x1002131ec		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002131f0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002131f4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002131f8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002131fc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213200		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213204		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213208		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021320c		f94093f5		MOVD 288(RSP), R21									
  execution.go:488	0x100213210		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100213214		f94127e0		MOVD 584(RSP), R0									
  execution.go:615	0x100213218		14000025		JMP 37(PC)										
  execution.go:592	0x10021321c		b9400e96		MOVWU 12(R20), R22									
  execution.go:592	0x100213220		eb1302df		CMP R19, R22										
  execution.go:592	0x100213224		540082c2		BCS 1046(PC)										
  execution.go:592	0x100213228		8b161196		ADD R22<<4, R12, R22									
  execution.go:592	0x10021322c		f94002d6		MOVD (R22), R22										
  integer.go:62		0x100213230		93401ed6		SXTB R22, R22										
  integer.go:62		0x100213234		2a1603f6		MOVW R22, R22										
  execution.go:592	0x100213238		1400001d		JMP 29(PC)										
  execution.go:594	0x10021323c		b9400e96		MOVWU 12(R20), R22									
  execution.go:594	0x100213240		eb1302df		CMP R19, R22										
  execution.go:594	0x100213244		54008162		BCS 1035(PC)										
  execution.go:594	0x100213248		8b161196		ADD R22<<4, R12, R22									
  execution.go:594	0x10021324c		f94002d6		MOVD (R22), R22										
  integer.go:63		0x100213250		93403ed6		SXTH R22, R22										
  integer.go:63		0x100213254		2a1603f6		MOVW R22, R22										
  execution.go:594	0x100213258		14000015		JMP 21(PC)										
  execution.go:596	0x10021325c		b9400e96		MOVWU 12(R20), R22									
  execution.go:596	0x100213260		eb1302df		CMP R19, R22										
  execution.go:596	0x100213264		54008002		BCS 1024(PC)										
  execution.go:596	0x100213268		8b161196		ADD R22<<4, R12, R22									
  execution.go:596	0x10021326c		f94002d6		MOVD (R22), R22										
  integer.go:64		0x100213270		93401ed6		SXTB R22, R22										
  execution.go:596	0x100213274		1400000e		JMP 14(PC)										
  execution.go:598	0x100213278		b9400e96		MOVWU 12(R20), R22									
  execution.go:598	0x10021327c		eb1302df		CMP R19, R22										
  execution.go:598	0x100213280		54007ec2		BCS 1014(PC)										
  execution.go:598	0x100213284		8b161196		ADD R22<<4, R12, R22									
  execution.go:598	0x100213288		f94002d6		MOVD (R22), R22										
  integer.go:65		0x10021328c		93403ed6		SXTH R22, R22										
  execution.go:598	0x100213290		14000007		JMP 7(PC)										
  execution.go:600	0x100213294		b9400e96		MOVWU 12(R20), R22									
  execution.go:600	0x100213298		eb1302df		CMP R19, R22										
  execution.go:600	0x10021329c		54007d82		BCS 1004(PC)										
  execution.go:600	0x1002132a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:600	0x1002132a4		f94002d6		MOVD (R22), R22										
  integer.go:66		0x1002132a8		93407ed6		SXTW R22, R22										
  execution.go:619	0x1002132ac		aa1f03f7		MOVD ZR, R23										
  execution.go:619	0x1002132b0		140002a7		JMP 679(PC)										
  execution.go:621	0x1002132b4		7100f83f		CMPW $62, R1										
  execution.go:706	0x1002132b8		54001e68		BHI 243(PC)										
  execution.go:621	0x1002132bc		7100803f		CMPW $32, R1										
  execution.go:676	0x1002132c0		540005c8		BHI 46(PC)										
  execution.go:621	0x1002132c4		7100283f		CMPW $10, R1										
  execution.go:663	0x1002132c8		54000108		BHI 8(PC)										
  execution.go:669	0x1002132cc		7100043f		CMPW $1, R1										
  execution.go:669	0x1002132d0		540001a0		BEQ 13(PC)										
  execution.go:663	0x1002132d4		7100203f		CMPW $8, R1										
  execution.go:663	0x1002132d8		54005560		BEQ 683(PC)										
  execution.go:621	0x1002132dc		7100283f		CMPW $10, R1										
  execution.go:663	0x1002132e0		540042e1		BNE 535(PC)										
  execution.go:663	0x1002132e4		140002a8		JMP 680(PC)										
  execution.go:621	0x1002132e8		7100683f		CMPW $26, R1										
  execution.go:669	0x1002132ec		54000148		BHI 10(PC)										
  execution.go:743	0x1002132f0		d1004036		SUB $16, R1, R22									
  execution.go:743	0x1002132f4		710016df		CMPW $5, R22										
  execution.go:743	0x1002132f8		54005509		BLS 680(PC)										
  execution.go:621	0x1002132fc		7100683f		CMPW $26, R1										
  execution.go:669	0x100213300		540041e1		BNE 527(PC)										
  execution.go:704	0x100213304		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213308		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x10021330c		aa1f03e1		MOVD ZR, R1										
  execution.go:669	0x100213310		1400028d		JMP 653(PC)										
  execution.go:670	0x100213314		7100703f		CMPW $28, R1										
  execution.go:670	0x100213318		540001e8		BHI 15(PC)										
  execution.go:671	0x10021331c		29425e96		LDPW 16(R20), (R22, R23)								
  execution.go:672	0x100213320		eb1302ff		CMP R19, R23										
  execution.go:672	0x100213324		540078e2		BCS 967(PC)										
  execution.go:672	0x100213328		8b171197		ADD R23<<4, R12, R23									
  execution.go:672	0x10021332c		f94002f7		MOVD (R23), R23										
  execution.go:672	0x100213330		34000057		CBZW R23, 2(PC)										
  execution.go:673	0x100213334		b9400e96		MOVWU 12(R20), R22									
  execution.go:675	0x100213338		2a1603f6		MOVW R22, R22										
  execution.go:675	0x10021333c		eb1302df		CMP R19, R22										
  execution.go:675	0x100213340		540077a2		BCS 957(PC)										
  execution.go:675	0x100213344		8b161196		ADD R22<<4, R12, R22									
  execution.go:675	0x100213348		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x10021334c		aa1f03e1		MOVD ZR, R1										
  execution.go:675	0x100213350		1400027d		JMP 637(PC)										
  execution.go:621	0x100213354		7100803f		CMPW $32, R1										
  execution.go:676	0x100213358		54003f21		BNE 505(PC)										
  execution.go:677	0x10021335c		b9401a96		MOVWU 24(R20), R22									
  execution.go:677	0x100213360		eb1302df		CMP R19, R22										
  execution.go:677	0x100213364		54007622		BCS 945(PC)										
  execution.go:677	0x100213368		8b161196		ADD R22<<4, R12, R22									
  execution.go:677	0x10021336c		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x100213370		aa1f03e1		MOVD ZR, R1										
  execution.go:677	0x100213374		14000274		JMP 628(PC)										
  execution.go:621	0x100213378		7100903f		CMPW $36, R1										
  execution.go:683	0x10021337c		54000548		BHI 42(PC)										
  execution.go:678	0x100213380		7100883f		CMPW $34, R1										
  execution.go:678	0x100213384		540001a8		BHI 13(PC)										
  execution.go:679	0x100213388		b9400e96		MOVWU 12(R20), R22									
  execution.go:679	0x10021338c		eb1302df		CMP R19, R22										
  execution.go:679	0x100213390		54007462		BCS 931(PC)										
  execution.go:679	0x100213394		8b161196		ADD R22<<4, R12, R22									
  execution.go:679	0x100213398		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:680	0x10021339c		b9401a98		MOVWU 24(R20), R24									
  execution.go:680	0x1002133a0		eb13031f		CMP R19, R24										
  execution.go:680	0x1002133a4		54007362		BCS 923(PC)										
  execution.go:680	0x1002133a8		8b181198		ADD R24<<4, R12, R24									
  execution.go:680	0x1002133ac		a9005f16		STP (R22, R23), (R24)									
  execution.go:708	0x1002133b0		aa1f03e1		MOVD ZR, R1										
  execution.go:680	0x1002133b4		14000264		JMP 612(PC)										
  execution.go:681	0x1002133b8		71008c3f		CMPW $35, R1										
  execution.go:681	0x1002133bc		54000121		BNE 9(PC)										
  execution.go:682	0x1002133c0		a948ddb6		LDP 136(R13), (R22, R23)								
  execution.go:682	0x1002133c4		b9401a98		MOVWU 24(R20), R24									
  execution.go:682	0x1002133c8		eb17031f		CMP R23, R24										
  execution.go:682	0x1002133cc		540071c2		BCS 910(PC)										
  execution.go:682	0x1002133d0		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:682	0x1002133d4		a9425ed6		LDP 32(R22), (R22, R23)									
  execution.go:708	0x1002133d8		aa1f03e1		MOVD ZR, R1										
  execution.go:682	0x1002133dc		1400025a		JMP 602(PC)										
  execution.go:621	0x1002133e0		7100903f		CMPW $36, R1										
  execution.go:683	0x1002133e4		54003ac1		BNE 470(PC)										
  execution.go:684	0x1002133e8		b9400e96		MOVWU 12(R20), R22									
  execution.go:684	0x1002133ec		eb1302df		CMP R19, R22										
  execution.go:684	0x1002133f0		54007042		BCS 898(PC)										
  execution.go:684	0x1002133f4		a948e1b7		LDP 136(R13), (R23, R24)								
  execution.go:684	0x1002133f8		b9401a99		MOVWU 24(R20), R25									
  execution.go:684	0x1002133fc		8b161196		ADD R22<<4, R12, R22									
  execution.go:684	0x100213400		a9406ad6		LDP (R22), (R22, R26)									
  execution.go:684	0x100213404		eb18033f		CMP R24, R25										
  execution.go:684	0x100213408		54006f22		BCS 889(PC)										
  execution.go:684	0x10021340c		f8797af7		MOVD (R23)(R25<<3), R23									
  execution.go:684	0x100213410		a9026af6		STP (R22, R26), 32(R23)									
  execution.go:704	0x100213414		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213418		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x10021341c		aa1f03e1		MOVD ZR, R1										
  execution.go:684	0x100213420		14000249		JMP 585(PC)										
  execution.go:621	0x100213424		7100983f		CMPW $38, R1										
  execution.go:693	0x100213428		54000708		BHI 56(PC)										
  execution.go:685	0x10021342c		7100943f		CMPW $37, R1										
  execution.go:685	0x100213430		54000321		BNE 25(PC)										
  execution.go:686	0x100213434		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:686	0x100213438		b9401a98		MOVWU 24(R20), R24									
  execution.go:686	0x10021343c		eb17031f		CMP R23, R24										
  execution.go:686	0x100213440		54006d02		BCS 872(PC)										
  execution.go:686	0x100213444		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:687	0x100213448		398002db		MOVB (R22), R27										
  execution.go:687	0x10021344c		b9400e97		MOVWU 12(R20), R23									
  execution.go:687	0x100213450		eb1302ff		CMP R19, R23										
  execution.go:687	0x100213454		54006c02		BCS 864(PC)										
  execution.go:687	0x100213458		8b171197		ADD R23<<4, R12, R23									
  execution.go:687	0x10021345c		f94002f7		MOVD (R23), R23										
  module.go:70		0x100213460		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x100213464		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x100213468		2a1703f7		MOVW R23, R23										
  execution.go:688	0x10021346c		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:688	0x100213470		eb1802ff		CMP R24, R23										
  execution.go:688	0x100213474		54000083		BCC 4(PC)										
  execution.go:688	0x100213478		b24007e1		ORR $3, ZR, R1										
  execution.go:691	0x10021347c		aa1f03f6		MOVD ZR, R22										
  execution.go:688	0x100213480		14000003		JMP 3(PC)										
  execution.go:691	0x100213484		f8777ad6		MOVD (R22)(R23<<3), R22									
  execution.go:689	0x100213488		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x10021348c		aa1f03f7		MOVD ZR, R23										
  execution.go:688	0x100213490		1400022d		JMP 557(PC)										
  execution.go:694	0x100213494		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:694	0x100213498		b9401a98		MOVWU 24(R20), R24									
  execution.go:694	0x10021349c		eb17031f		CMP R23, R24										
  execution.go:694	0x1002134a0		54006942		BCS 842(PC)										
  execution.go:694	0x1002134a4		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:695	0x1002134a8		398002db		MOVB (R22), R27										
  execution.go:695	0x1002134ac		b9400e97		MOVWU 12(R20), R23									
  execution.go:695	0x1002134b0		eb1302ff		CMP R19, R23										
  execution.go:695	0x1002134b4		54006842		BCS 834(PC)										
  execution.go:695	0x1002134b8		8b171197		ADD R23<<4, R12, R23									
  execution.go:695	0x1002134bc		f94002f7		MOVD (R23), R23										
  module.go:70		0x1002134c0		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x1002134c4		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x1002134c8		2a1703f7		MOVW R23, R23										
  execution.go:696	0x1002134cc		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:696	0x1002134d0		eb1802ff		CMP R24, R23										
  execution.go:696	0x1002134d4		54000063		BCC 3(PC)										
  execution.go:696	0x1002134d8		b24007e1		ORR $3, ZR, R1										
  execution.go:696	0x1002134dc		14000008		JMP 8(PC)										
  execution.go:699	0x1002134e0		b9401298		MOVWU 16(R20), R24									
  execution.go:699	0x1002134e4		eb13031f		CMP R19, R24										
  execution.go:699	0x1002134e8		54006642		BCS 818(PC)										
  execution.go:699	0x1002134ec		8b181198		ADD R24<<4, R12, R24									
  execution.go:699	0x1002134f0		f9400318		MOVD (R24), R24										
  execution.go:699	0x1002134f4		f8377ad8		MOVD R24, (R22)(R23<<3)									
  execution.go:697	0x1002134f8		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x1002134fc		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213500		aa1f03f6		MOVD ZR, R22										
  execution.go:696	0x100213504		14000210		JMP 528(PC)										
  execution.go:701	0x100213508		d100a036		SUB $40, R1, R22									
  execution.go:701	0x10021350c		710036df		CMPW $13, R22										
  execution.go:702	0x100213510		54000588		BHI 44(PC)										
  execution.go:703	0x100213514		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:703	0x100213518		b9400696		MOVWU 4(R20), R22									
  execution.go:703	0x10021351c		aa1603f7		MOVD R22, R23										
  execution.go:703	0x100213520		eb0802ff		CMP R8, R23										
  execution.go:703	0x100213524		54006422		BCS 801(PC)										
  execution.go:703	0x100213528		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:703	0x10021352c		cb171508		SUB R23<<5, R8, R8									
  execution.go:703	0x100213530		8b0800e7		ADD R8, R7, R7										
  execution.go:704	0x100213534		a94759a8		LDP 112(R13), (R8, R22)									
  module.go:178		0x100213538		2942e0f7		LDPW 20(R7), (R23, R24)									
  module.go:178		0x10021353c		b9401ce7		MOVWU 28(R7), R7									
  module.go:178		0x100213540		aa0782e3		ORR R7<<32, R23, R3									
  execution.go:704	0x100213544		eb16031f		CMP R22, R24										
  execution.go:704	0x100213548		540062a2		BCS 789(PC)										
  execution.go:704	0x10021354c		f8787907		MOVD (R8)(R24<<3), R7									
  execution.go:704	0x100213550		398000fb		MOVB (R7), R27										
  execution.go:704	0x100213554		b9400e88		MOVWU 12(R20), R8									
  execution.go:704	0x100213558		eb13011f		CMP R19, R8										
  execution.go:704	0x10021355c		540061c2		BCS 782(PC)										
  execution.go:704	0x100213560		f94008e0		MOVD 16(R7), R0										
  execution.go:704	0x100213564		8b081187		ADD R8<<4, R12, R7									
  execution.go:704	0x100213568		f94000e2		MOVD (R7), R2										
  execution.go:704	0x10021356c		aa1f03e4		MOVD ZR, R4										
  execution.go:704	0x100213570		aa1f03e5		MOVD ZR, R5										
  execution.go:704	0x100213574		aa1f03e6		MOVD ZR, R6										
  execution.go:704	0x100213578		97ff9f1e		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:342	0x10021357c		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213580		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213584		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100213588		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10021358c		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213590		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213594		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213598		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x10021359c		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002135a0		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002135a4		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002135a8		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002135ac		aa0103f7		MOVD R1, R23										
  execution.go:704	0x1002135b0		aa0003f6		MOVD R0, R22										
  execution.go:708	0x1002135b4		aa0203e1		MOVD R2, R1										
  execution.go:209	0x1002135b8		f94127e0		MOVD 584(RSP), R0									
  execution.go:704	0x1002135bc		140001e2		JMP 482(PC)										
  execution.go:705	0x1002135c0		7100d83f		CMPW $54, R1										
  execution.go:705	0x1002135c4		54002bc3		BCC 350(PC)										
  execution.go:707	0x1002135c8		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:707	0x1002135cc		b9400696		MOVWU 4(R20), R22									
  execution.go:707	0x1002135d0		aa1603f7		MOVD R22, R23										
  execution.go:707	0x1002135d4		eb0802ff		CMP R8, R23										
  execution.go:707	0x1002135d8		54005da2		BCS 749(PC)										
  execution.go:707	0x1002135dc		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:707	0x1002135e0		cb171508		SUB R23<<5, R8, R8									
  execution.go:707	0x1002135e4		8b0800e7		ADD R8, R7, R7										
  execution.go:708	0x1002135e8		b9401288		MOVWU 16(R20), R8									
  module.go:178		0x1002135ec		b94014f6		MOVWU 20(R7), R22									
  module.go:178		0x1002135f0		29435ce7		LDPW 24(R7), (R7, R23)									
  module.go:178		0x1002135f4		aa1782c3		ORR R23<<32, R22, R3									
  execution.go:708	0x1002135f8		eb13011f		CMP R19, R8										
  execution.go:708	0x1002135fc		54005c42		BCS 738(PC)										
  execution.go:708	0x100213600		a9475db6		LDP 112(R13), (R22, R23)								
  execution.go:708	0x100213604		8b081188		ADD R8<<4, R12, R8									
  execution.go:708	0x100213608		eb1700ff		CMP R23, R7										
  execution.go:708	0x10021360c		54005b82		BCS 732(PC)										
  execution.go:708	0x100213610		f8677ac7		MOVD (R22)(R7<<3), R7									
  execution.go:708	0x100213614		398000fb		MOVB (R7), R27										
  execution.go:708	0x100213618		b9400e96		MOVWU 12(R20), R22									
  execution.go:708	0x10021361c		eb1302df		CMP R19, R22										
  execution.go:708	0x100213620		54005a82		BCS 724(PC)										
  execution.go:708	0x100213624		f94008e0		MOVD 16(R7), R0										
  execution.go:708	0x100213628		8b161187		ADD R22<<4, R12, R7									
  execution.go:708	0x10021362c		f94000e2		MOVD (R7), R2										
  execution.go:708	0x100213630		f9400105		MOVD (R8), R5										
  execution.go:708	0x100213634		aa1f03e4		MOVD ZR, R4										
  execution.go:708	0x100213638		aa1f03e6		MOVD ZR, R6										
  execution.go:708	0x10021363c		97ff9f65		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:342	0x100213640		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213644		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213648		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021364c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213650		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213654		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213658		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021365c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213660		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213664		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213668		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021366c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100213670		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213674		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100213678		aa0003e1		MOVD R0, R1										
  execution.go:209	0x10021367c		f94127e0		MOVD 584(RSP), R0									
  execution.go:708	0x100213680		140001b1		JMP 433(PC)										
  execution.go:621	0x100213684		7103483f		CMPW $210, R1										
  execution.go:741	0x100213688		54000ec8		BHI 118(PC)										
  execution.go:621	0x10021368c		7101043f		CMPW $65, R1										
  execution.go:718	0x100213690		54000a28		BHI 81(PC)										
  execution.go:709	0x100213694		7100fc3f		CMPW $63, R1										
  execution.go:709	0x100213698		540006e0		BEQ 55(PC)										
  execution.go:711	0x10021369c		7101003f		CMPW $64, R1										
  execution.go:711	0x1002136a0		540000a0		BEQ 5(PC)										
  execution.go:719	0x1002136a4		b9401a96		MOVWU 24(R20), R22									
  execution.go:704	0x1002136a8		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x1002136ac		aa1f03e1		MOVD ZR, R1										
  execution.go:719	0x1002136b0		140001a5		JMP 421(PC)										
  execution.go:712	0x1002136b4		a94711a3		LDP 112(R13), (R3, R4)									
  execution.go:712	0x1002136b8		b9401a85		MOVWU 24(R20), R5									
  execution.go:712	0x1002136bc		eb0400bf		CMP R4, R5										
  execution.go:712	0x1002136c0		54005562		BCS 683(PC)										
  execution.go:712	0x1002136c4		f8657861		MOVD (R3)(R5<<3), R1									
  execution.go:713	0x1002136c8		f9400823		MOVD 16(R1), R3										
  memory.go:127		0x1002136cc		ad410460		FLDPQ 32(R3), (F0, F1)									
  execution.go:713	0x1002136d0		910623fb		ADD $392, RSP, R27									
  execution.go:713	0x1002136d4		ad000760		FSTPQ (F0, F1), (R27)									
  execution.go:713	0x1002136d8		b9400e83		MOVWU 12(R20), R3									
  execution.go:713	0x1002136dc		eb13007f		CMP R19, R3										
  execution.go:713	0x1002136e0		54005422		BCS 673(PC)										
  execution.go:713	0x1002136e4		8b031183		ADD R3<<4, R12, R3									
  execution.go:713	0x1002136e8		f9400062		MOVD (R3), R2										
  module.go:70		0x1002136ec		394667e3		MOVBU 409(RSP), R3									
  module.go:70		0x1002136f0		37000043		TBNZ $0, R3, 2(PC)									
  module.go:73		0x1002136f4		2a0203e2		MOVW R2, R2										
  execution.go:712	0x1002136f8		f900a3e1		MOVD R1, 320(RSP)									
  execution.go:713	0x1002136fc		f9400000		MOVD (R0), R0										
  execution.go:713	0x100213700		97ffe548		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory(SB)		
  execution.go:715	0x100213704		37000161		TBNZ $0, R1, 11(PC)									
  execution.go:716	0x100213708		f940a3e9		MOVD 320(RSP), R9									
  execution.go:716	0x10021370c		f9400929		MOVD 16(R9), R9										
  memory.go:127		0x100213710		ad410520		FLDPQ 32(R9), (F0, F1)									
  execution.go:716	0x100213714		910623fb		ADD $392, RSP, R27									
  execution.go:716	0x100213718		ad000760		FSTPQ (F0, F1), (R27)									
  module.go:77		0x10021371c		394667e9		MOVBU 409(RSP), R9									
  execution.go:716	0x100213720		7200013f		TSTW $1, R9										
  execution.go:716	0x100213724		92800009		MOVD $-1, R9										
  execution.go:716	0x100213728		b2407fea		MOVD $4294967295, R10									
  execution.go:716	0x10021372c		9a8a1120		CSEL NE, R9, R10, R0									
  execution.go:342	0x100213730		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213734		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213738		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021373c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213740		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213744		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213748		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021374c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213750		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213754		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213758		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021375c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100213760		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213764		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100213768		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x10021376c		f94127e0		MOVD 584(RSP), R0									
  execution.go:715	0x100213770		14000175		JMP 373(PC)										
  execution.go:710	0x100213774		a94709a1		LDP 112(R13), (R1, R2)									
  execution.go:710	0x100213778		b9401a83		MOVWU 24(R20), R3									
  execution.go:710	0x10021377c		eb02007f		CMP R2, R3										
  execution.go:710	0x100213780		54004f02		BCS 632(PC)										
  execution.go:710	0x100213784		f8637821		MOVD (R1)(R3<<3), R1									
  execution.go:710	0x100213788		f9400820		MOVD 16(R1), R0										
  execution.go:710	0x10021378c		97ff9c19		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages(SB)		
  execution.go:342	0x100213790		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213794		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213798		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021379c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002137a0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002137a4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002137a8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002137ac		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002137b0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002137b4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002137b8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002137bc		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002137c0		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002137c4		aa0003f6		MOVD R0, R22										
  execution.go:708	0x1002137c8		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x1002137cc		f94127e0		MOVD 584(RSP), R0									
  execution.go:710	0x1002137d0		1400015d		JMP 349(PC)										
  execution.go:621	0x1002137d4		7103403f		CMPW $208, R1										
  execution.go:730	0x1002137d8		540001c8		BHI 14(PC)										
  execution.go:721	0x1002137dc		7101103f		CMPW $68, R1										
  execution.go:721	0x1002137e0		540000c8		BHI 6(PC)										
  execution.go:722	0x1002137e4		b9401a97		MOVWU 24(R20), R23									
  execution.go:722	0x1002137e8		aa1682f6		ORR R22<<32, R23, R22									
  execution.go:704	0x1002137ec		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x1002137f0		aa1f03e1		MOVD ZR, R1										
  execution.go:722	0x1002137f4		14000154		JMP 340(PC)										
  execution.go:621	0x1002137f8		7103403f		CMPW $208, R1										
  execution.go:730	0x1002137fc		54001a01		BNE 208(PC)										
  execution.go:704	0x100213800		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213804		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100213808		aa1f03e1		MOVD ZR, R1										
  execution.go:730	0x10021380c		1400014e		JMP 334(PC)										
  execution.go:737	0x100213810		7103443f		CMPW $209, R1										
  execution.go:737	0x100213814		54000161		BNE 11(PC)										
  execution.go:738	0x100213818		b9400e96		MOVWU 12(R20), R22									
  execution.go:738	0x10021381c		eb1302df		CMP R19, R22										
  execution.go:738	0x100213820		540049a2		BCS 589(PC)										
  execution.go:738	0x100213824		8b161196		ADD R22<<4, R12, R22									
  execution.go:738	0x100213828		f94002d6		MOVD (R22), R22										
  execution.go:738	0x10021382c		f10002df		CMP $0, R22										
  execution.go:738	0x100213830		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x100213834		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100213838		aa1f03e1		MOVD ZR, R1										
  execution.go:738	0x10021383c		14000142		JMP 322(PC)										
  execution.go:742	0x100213840		a9445db6		LDP 64(R13), (R22, R23)									
  execution.go:742	0x100213844		b9401a98		MOVWU 24(R20), R24									
  execution.go:742	0x100213848		eb17031f		CMP R23, R24										
  execution.go:742	0x10021384c		540047e2		BCS 575(PC)										
  execution.go:742	0x100213850		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:704	0x100213854		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100213858		aa1f03e1		MOVD ZR, R1										
  execution.go:742	0x10021385c		1400013a		JMP 314(PC)										
  execution.go:621	0x100213860		d2800077		MOVD $3, R23										
  execution.go:621	0x100213864		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x100213868		6b17003f		CMPW R23, R1										
  execution.go:634	0x10021386c		54000808		BHI 64(PC)										
  execution.go:621	0x100213870		7103503f		CMPW $212, R1										
  execution.go:731	0x100213874		540003a8		BHI 29(PC)										
  execution.go:726	0x100213878		71034c3f		CMPW $211, R1										
  execution.go:726	0x10021387c		540001e1		BNE 15(PC)										
  execution.go:727	0x100213880		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:727	0x100213884		eb1302df		CMP R19, R22										
  execution.go:727	0x100213888		540045a2		BCS 557(PC)										
  execution.go:727	0x10021388c		8b161196		ADD R22<<4, R12, R22									
  execution.go:727	0x100213890		eb1302ff		CMP R19, R23										
  execution.go:727	0x100213894		540044e2		BCS 551(PC)										
  execution.go:727	0x100213898		f94002d6		MOVD (R22), R22										
  execution.go:727	0x10021389c		8b171197		ADD R23<<4, R12, R23									
  execution.go:727	0x1002138a0		f94002f7		MOVD (R23), R23										
  execution.go:727	0x1002138a4		eb1602ff		CMP R22, R23										
  execution.go:727	0x1002138a8		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x1002138ac		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x1002138b0		aa1f03e1		MOVD ZR, R1										
  execution.go:727	0x1002138b4		14000124		JMP 292(PC)										
  execution.go:732	0x1002138b8		b9400e96		MOVWU 12(R20), R22									
  execution.go:732	0x1002138bc		eb1302df		CMP R19, R22										
  execution.go:732	0x1002138c0		54004322		BCS 537(PC)										
  execution.go:732	0x1002138c4		8b161196		ADD R22<<4, R12, R22									
  execution.go:732	0x1002138c8		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:732	0x1002138cc		b50000b6		CBNZ R22, 5(PC)										
  execution.go:732	0x1002138d0		d2800121		MOVD $9, R1										
  execution.go:735	0x1002138d4		aa1f03f7		MOVD ZR, R23										
  execution.go:735	0x1002138d8		aa1f03f6		MOVD ZR, R22										
  execution.go:732	0x1002138dc		1400011a		JMP 282(PC)										
  execution.go:733	0x1002138e0		aa1f03e1		MOVD ZR, R1										
  execution.go:735	0x1002138e4		14000118		JMP 280(PC)										
  execution.go:723	0x1002138e8		d17f0037		SUB $(4032<<12), R1, R23								
  execution.go:723	0x1002138ec		71001eff		CMPW $7, R23										
  execution.go:724	0x1002138f0		540000c9		BLS 6(PC)										
  execution.go:634	0x1002138f4		d2800037		MOVD $1, R23										
  execution.go:634	0x1002138f8		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x1002138fc		6b17003f		CMPW R23, R1										
  execution.go:634	0x100213900		54000582		BCS 44(PC)										
  execution.go:634	0x100213904		1400008e		JMP 142(PC)										
  execution.go:725	0x100213908		b9400e83		MOVWU 12(R20), R3									
  execution.go:725	0x10021390c		eb13007f		CMP R19, R3										
  execution.go:725	0x100213910		54004062		BCS 515(PC)										
  execution.go:725	0x100213914		8b031183		ADD R3<<4, R12, R3									
  execution.go:725	0x100213918		f9400063		MOVD (R3), R3										
  execution.go:725	0x10021391c		aa0103e0		MOVD R1, R0										
  execution.go:725	0x100213920		aa0303e1		MOVD R3, R1										
  execution.go:725	0x100213924		aa1f03e2		MOVD ZR, R2										
  execution.go:725	0x100213928		97ffa6de		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:342	0x10021392c		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213930		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213934		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100213938		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10021393c		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213940		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213944		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213948		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x10021394c		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213950		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213954		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100213958		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x10021395c		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100213960		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100213964		f94127e0		MOVD 584(RSP), R0									
  execution.go:725	0x100213968		140000f7		JMP 247(PC)										
  execution.go:621	0x10021396c		d28000b7		MOVD $5, R23										
  execution.go:621	0x100213970		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x100213974		6b17003f		CMPW R23, R1										
  execution.go:634	0x100213978		540000c8		BHI 6(PC)										
  execution.go:622	0x10021397c		d2800097		MOVD $4, R23										
  execution.go:622	0x100213980		f2a02017		MOVK $(256<<16), R23									
  execution.go:622	0x100213984		6b17003f		CMPW R23, R1										
  execution.go:622	0x100213988		54000141		BNE 10(PC)										
  execution.go:622	0x10021398c		14000108		JMP 264(PC)										
  execution.go:628	0x100213990		d28000f7		MOVD $7, R23										
  execution.go:628	0x100213994		f2a02017		MOVK $(256<<16), R23									
  execution.go:628	0x100213998		6b17003f		CMPW R23, R1										
  execution.go:628	0x10021399c		54002120		BEQ 265(PC)										
  execution.go:634	0x1002139a0		d2800137		MOVD $9, R23										
  execution.go:634	0x1002139a4		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x1002139a8		6b17003f		CMPW R23, R1										
  execution.go:634	0x1002139ac		54000c81		BNE 100(PC)										
  execution.go:635	0x1002139b0		d2a02017		MOVD $16777216, R23									
  execution.go:635	0x1002139b4		cb170037		SUB R23, R1, R23									
  execution.go:636	0x1002139b8		d3401ef7		UBFX $0, R23, $8, R23									
  execution.go:636	0x1002139bc		710016ff		CMPW $5, R23										
  execution.go:636	0x1002139c0		540000a1		BNE 5(PC)										
  execution.go:704	0x1002139c4		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002139c8		aa1f03f6		MOVD ZR, R22										
  execution.go:704	0x1002139cc		b24003e1		ORR $1, ZR, R1										
  execution.go:638	0x1002139d0		140000dd		JMP 221(PC)										
  execution.go:641	0x1002139d4		710026ff		CMPW $9, R23										
  execution.go:641	0x1002139d8		54000121		BNE 9(PC)										
  execution.go:641	0x1002139dc		b9400e98		MOVWU 12(R20), R24									
  execution.go:641	0x1002139e0		eb13031f		CMP R19, R24										
  execution.go:641	0x1002139e4		54003962		BCS 459(PC)										
  execution.go:641	0x1002139e8		8b181198		ADD R24<<4, R12, R24									
  execution.go:641	0x1002139ec		f9400318		MOVD (R24), R24										
  execution.go:641	0x1002139f0		b4000078		CBZ R24, 3(PC)										
  execution.go:641	0x1002139f4		b24003f6		ORR $1, ZR, R22										
  execution.go:641	0x1002139f8		14000018		JMP 24(PC)										
  execution.go:643	0x1002139fc		71000aff		CMPW $2, R23										
  execution.go:643	0x100213a00		54000121		BNE 9(PC)										
  execution.go:643	0x100213a04		b9400e98		MOVWU 12(R20), R24									
  execution.go:643	0x100213a08		eb13031f		CMP R19, R24										
  execution.go:643	0x100213a0c		540037c2		BCS 446(PC)										
  execution.go:643	0x100213a10		8b181198		ADD R24<<4, R12, R24									
  execution.go:643	0x100213a14		f9400318		MOVD (R24), R24										
  execution.go:643	0x100213a18		35000078		CBNZW R24, 3(PC)									
  execution.go:643	0x100213a1c		b24003f6		ORR $1, ZR, R22										
  execution.go:643	0x100213a20		1400000e		JMP 14(PC)										
  execution.go:645	0x100213a24		71000eff		CMPW $3, R23										
  execution.go:645	0x100213a28		54000161		BNE 11(PC)										
  execution.go:646	0x100213a2c		b9400e97		MOVWU 12(R20), R23									
  execution.go:646	0x100213a30		eb1302ff		CMP R19, R23										
  execution.go:646	0x100213a34		54003622		BCS 433(PC)										
  execution.go:646	0x100213a38		8b171197		ADD R23<<4, R12, R23									
  execution.go:646	0x100213a3c		f94002f7		MOVD (R23), R23										
  execution.go:647	0x100213a40		d10006d6		SUB $1, R22, R22									
  execution.go:647	0x100213a44		6b1602ff		CMPW R22, R23										
  execution.go:647	0x100213a48		54000082		BCS 4(PC)										
  execution.go:648	0x100213a4c		aa1703f6		MOVD R23, R22										
  execution.go:647	0x100213a50		14000002		JMP 2(PC)										
  execution.go:647	0x100213a54		aa1f03f6		MOVD ZR, R22										
  execution.go:651	0x100213a58		a94e61d7		LDP 224(R14), (R23, R24)								
  execution.go:651	0x100213a5c		b9401a94		MOVWU 24(R20), R20									
  execution.go:651	0x100213a60		8b1402d4		ADD R20, R22, R20									
  execution.go:651	0x100213a64		2a1403f6		MOVW R20, R22										
  execution.go:651	0x100213a68		eb1802df		CMP R24, R22										
  execution.go:651	0x100213a6c		54003402		BCS 416(PC)										
  execution.go:651	0x100213a70		d37e7e94		UBFIZ $2, R20, $32, R20									
  execution.go:651	0x100213a74		8b140694		ADD R20<<1, R20, R20									
  execution.go:651	0x100213a78		b8746af6		MOVWU (R23)(R20), R22									
  execution.go:651	0x100213a7c		8b1402f4		ADD R20, R23, R20									
  execution.go:651	0x100213a80		2940de94		LDPW 4(R20), (R20, R23)									
  execution.go:652	0x100213a84		6b16023f		CMPW R22, R17										
  execution.go:652	0x100213a88		540003e3		BCC 31(PC)										
  execution.go:651	0x100213a8c		b90107f7		MOVW R23, 260(RSP)									
  execution.go:651	0x100213a90		b90103f4		MOVW R20, 256(RSP)									
  execution.go:651	0x100213a94		b900fff6		MOVW R22, 252(RSP)									
  execution.go:209	0x100213a98		f940b011		MOVD 352(R0), R17									
  execution.go:209	0x100213a9c		b40000d1		CBZ R17, 6(PC)										
  type.go:19		0x100213aa0		88dffe31		LDARW (R17), R17									
  execution.go:209	0x100213aa4		35000091		CBNZW R17, 4(PC)									
  execution.go:212	0x100213aa8		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x100213aac		aa1f03e2		MOVD ZR, R2										
  execution.go:653	0x100213ab0		14000014		JMP 20(PC)										
  execution.go:212	0x100213ab4		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100213ab8		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x100213abc		d63f0020		CALL (R1)										
  execution.go:342	0x100213ac0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213ac4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213ac8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:658	0x100213acc		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213ad0		f940abed		MOVD 336(RSP), R13									
  execution.go:657	0x100213ad4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213ad8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213adc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:658	0x100213ae0		f94087f3		MOVD 264(RSP), R19									
  execution.go:657	0x100213ae4		b94103f4		MOVWU 256(RSP), R20									
  execution.go:341	0x100213ae8		f94093f5		MOVD 288(RSP), R21									
  execution.go:460	0x100213aec		b940fff6		MOVWU 252(RSP), R22									
  execution.go:657	0x100213af0		b94107f7		MOVWU 260(RSP), R23									
  execution.go:212	0x100213af4		aa0103e2		MOVD R1, R2										
  execution.go:212	0x100213af8		aa0003e1		MOVD R0, R1										
  execution.go:654	0x100213afc		f94127e0		MOVD 584(RSP), R0									
  execution.go:653	0x100213b00		b5002161		CBNZ R1, 267(PC)									
  execution.go:657	0x100213b04		f94085d1		MOVD 264(R14), R17									
  execution.go:657	0x100213b08		8b170297		ADD R23, R20, R23									
  execution.go:657	0x100213b0c		2a1703f7		MOVW R23, R23										
  execution.go:657	0x100213b10		eb1102ff		CMP R17, R23										
  execution.go:657	0x100213b14		54002e68		BHI 371(PC)										
  execution.go:657	0x100213b18		eb17029f		CMP R23, R20										
  execution.go:657	0x100213b1c		54002dc8		BHI 366(PC)										
  execution.go:657	0x100213b20		f9407dd8		MOVD 248(R14), R24									
  execution.go:657	0x100213b24		cb110291		SUB R17, R20, R17									
  execution.go:657	0x100213b28		8a91fe91		AND R17->63, R20, R17									
  execution.go:657	0x100213b2c		cb1402f4		SUB R20, R23, R20									
  execution.go:657	0x100213b30		8b110f11		ADD R17<<3, R24, R17									
  execution.go:657	0x100213b34		aa1f03f7		MOVD ZR, R23										
  execution.go:657	0x100213b38		14000154		JMP 340(PC)										
  execution.go:751	0x100213b3c		b9400e96		MOVWU 12(R20), R22									
  execution.go:751	0x100213b40		310006df		CMNW $1, R22										
  execution.go:751	0x100213b44		540000c0		BEQ 6(PC)										
  execution.go:752	0x100213b48		eb1302df		CMP R19, R22										
  execution.go:752	0x100213b4c		54002922		BCS 329(PC)										
  execution.go:752	0x100213b50		8b161196		ADD R22<<4, R12, R22									
  execution.go:752	0x100213b54		f94002c2		MOVD (R22), R2										
  execution.go:752	0x100213b58		14000002		JMP 2(PC)										
  execution.go:752	0x100213b5c		aa1f03e2		MOVD ZR, R2										
  execution.go:754	0x100213b60		b9401296		MOVWU 16(R20), R22									
  execution.go:754	0x100213b64		310006df		CMNW $1, R22										
  execution.go:754	0x100213b68		540000c0		BEQ 6(PC)										
  execution.go:755	0x100213b6c		eb1302df		CMP R19, R22										
  execution.go:755	0x100213b70		540027a2		BCS 317(PC)										
  execution.go:755	0x100213b74		8b161196		ADD R22<<4, R12, R22									
  execution.go:755	0x100213b78		f94002c4		MOVD (R22), R4										
  execution.go:755	0x100213b7c		14000002		JMP 2(PC)										
  execution.go:755	0x100213b80		aa1f03e4		MOVD ZR, R4										
  execution.go:757	0x100213b84		b9401696		MOVWU 20(R20), R22									
  execution.go:757	0x100213b88		310006df		CMNW $1, R22										
  execution.go:757	0x100213b8c		540000c0		BEQ 6(PC)										
  execution.go:758	0x100213b90		eb1302df		CMP R19, R22										
  execution.go:758	0x100213b94		54002622		BCS 305(PC)										
  execution.go:758	0x100213b98		8b161196		ADD R22<<4, R12, R22									
  execution.go:758	0x100213b9c		f94002c6		MOVD (R22), R6										
  execution.go:758	0x100213ba0		14000002		JMP 2(PC)										
  execution.go:758	0x100213ba4		aa1f03e6		MOVD ZR, R6										
  execution.go:762	0x100213ba8		d3507c36		UBFX $16, R1, $16, R22									
  execution.go:762	0x100213bac		7103fadf		CMPW $254, R22										
  execution.go:762	0x100213bb0		54000501		BNE 40(PC)										
  execution.go:763	0x100213bb4		d3403c36		UBFX $0, R1, $16, R22									
  execution.go:763	0x100213bb8		71000edf		CMPW $3, R22										
  execution.go:763	0x100213bbc		54000101		BNE 8(PC)										
  execution.go:764	0x100213bc0		f9400001		MOVD (R0), R1										
  execution.go:764	0x100213bc4		f9400420		MOVD 8(R1), R0										
  execution.go:764	0x100213bc8		97ff9a36		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence(SB)		
  execution.go:770	0x100213bcc		aa1f03e2		MOVD ZR, R2										
  execution.go:770	0x100213bd0		aa1f03e1		MOVD ZR, R1										
  execution.go:770	0x100213bd4		aa1f03e0		MOVD ZR, R0										
  execution.go:765	0x100213bd8		1400004b		JMP 75(PC)										
  execution.go:767	0x100213bdc		a947e1d7		LDP 120(R14), (R23, R24)								
  execution.go:767	0x100213be0		b9400699		MOVWU 4(R20), R25									
  execution.go:767	0x100213be4		aa1903fa		MOVD R25, R26										
  execution.go:767	0x100213be8		eb18035f		CMP R24, R26										
  execution.go:767	0x100213bec		54002302		BCS 280(PC)										
  execution.go:767	0x100213bf0		d3787f38		UBFIZ $8, R25, $32, R24									
  execution.go:767	0x100213bf4		cb1a1718		SUB R26<<5, R24, R24									
  execution.go:767	0x100213bf8		8b1802f7		ADD R24, R23, R23									
  execution.go:769	0x100213bfc		a94765b8		LDP 112(R13), (R24, R25)								
  module.go:178		0x100213c00		2942fafa		LDPW 20(R23), (R26, R30)								
  module.go:178		0x100213c04		b9401ef7		MOVWU 28(R23), R23									
  module.go:178		0x100213c08		aa178357		ORR R23<<32, R26, R23									
  execution.go:769	0x100213c0c		eb1903df		CMP R25, R30										
  execution.go:769	0x100213c10		54002182		BCS 268(PC)										
  execution.go:769	0x100213c14		f87e7b09		MOVD (R24)(R30<<3), R9									
  execution.go:769	0x100213c18		f9400929		MOVD 16(R9), R9										
  execution.go:769	0x100213c1c		f940080a		MOVD 16(R0), R10									
  execution.go:769	0x100213c20		a940040b		LDP (R0), (R11, R1)									
  execution.go:769	0x100213c24		f9400563		MOVD 8(R11), R3										
  execution.go:769	0x100213c28		aa0903e0		MOVD R9, R0										
  execution.go:769	0x100213c2c		aa0203e5		MOVD R2, R5										
  execution.go:769	0x100213c30		aa0403e7		MOVD R4, R7										
  execution.go:769	0x100213c34		aa0603e8		MOVD R6, R8										
  execution.go:769	0x100213c38		aa0a03e2		MOVD R10, R2										
  execution.go:769	0x100213c3c		aa1603e4		MOVD R22, R4										
  execution.go:769	0x100213c40		aa1703e6		MOVD R23, R6										
  execution.go:769	0x100213c44		97ff9e57		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic(SB)		
  execution.go:770	0x100213c48		b40005e3		CBZ R3, 47(PC)										
  execution.go:770	0x100213c4c		140000bd		JMP 189(PC)										
  execution.go:773	0x100213c50		d2800108		MOVD $8, R8										
  execution.go:773	0x100213c54		f2a01f88		MOVK $(252<<16), R8									
  execution.go:773	0x100213c58		cb080028		SUB R8, R1, R8										
  execution.go:773	0x100213c5c		7100251f		CMPW $9, R8										
  execution.go:773	0x100213c60		54001e68		BHI 243(PC)										
  execution.go:774	0x100213c64		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:774	0x100213c68		b9400697		MOVWU 4(R20), R23									
  execution.go:774	0x100213c6c		aa1703f8		MOVD R23, R24										
  execution.go:774	0x100213c70		eb16031f		CMP R22, R24										
  execution.go:774	0x100213c74		54001d62		BCS 235(PC)										
  execution.go:774	0x100213c78		d3787ee9		UBFIZ $8, R23, $32, R9									
  execution.go:774	0x100213c7c		cb181529		SUB R24<<5, R9, R9									
  execution.go:774	0x100213c80		8b090108		ADD R9, R8, R8										
  execution.go:776	0x100213c84		910623e9		ADD $392, RSP, R9									
  execution.go:776	0x100213c88		ad404510		FLDPQ (R8), (F16, F17)									
  execution.go:776	0x100213c8c		ad004530		FSTPQ (F16, F17), (R9)									
  execution.go:776	0x100213c90		ad414510		FLDPQ 32(R8), (F16, F17)								
  execution.go:776	0x100213c94		ad014530		FSTPQ (F16, F17), 32(R9)								
  execution.go:776	0x100213c98		ad424510		FLDPQ 64(R8), (F16, F17)								
  execution.go:776	0x100213c9c		ad024530		FSTPQ (F16, F17), 64(R9)								
  execution.go:776	0x100213ca0		ad434510		FLDPQ 96(R8), (F16, F17)								
  execution.go:776	0x100213ca4		ad034530		FSTPQ (F16, F17), 96(R9)								
  execution.go:776	0x100213ca8		ad444510		FLDPQ 128(R8), (F16, F17)								
  execution.go:776	0x100213cac		ad044530		FSTPQ (F16, F17), 128(R9)								
  execution.go:776	0x100213cb0		f9405119		MOVD 160(R8), R25									
  execution.go:776	0x100213cb4		f9005139		MOVD R25, 160(R9)									
  execution.go:776	0x100213cb8		910023e8		ADD $8, RSP, R8										
  execution.go:776	0x100213cbc		ad404530		FLDPQ (R9), (F16, F17)									
  execution.go:776	0x100213cc0		ad004510		FSTPQ (F16, F17), (R8)									
  execution.go:776	0x100213cc4		ad414530		FLDPQ 32(R9), (F16, F17)								
  execution.go:776	0x100213cc8		ad014510		FSTPQ (F16, F17), 32(R8)								
  execution.go:776	0x100213ccc		ad424530		FLDPQ 64(R9), (F16, F17)								
  execution.go:776	0x100213cd0		ad024510		FSTPQ (F16, F17), 64(R8)								
  execution.go:776	0x100213cd4		ad434530		FLDPQ 96(R9), (F16, F17)								
  execution.go:776	0x100213cd8		ad034510		FSTPQ (F16, F17), 96(R8)								
  execution.go:776	0x100213cdc		ad444530		FLDPQ 128(R9), (F16, F17)								
  execution.go:776	0x100213ce0		ad044510		FSTPQ (F16, F17), 128(R8)								
  execution.go:776	0x100213ce4		f9405139		MOVD 160(R9), R25									
  execution.go:776	0x100213ce8		f9005119		MOVD R25, 160(R8)									
  execution.go:776	0x100213cec		aa0d03e1		MOVD R13, R1										
  execution.go:776	0x100213cf0		aa1f03e3		MOVD ZR, R3										
  execution.go:776	0x100213cf4		aa1f03e5		MOVD ZR, R5										
  execution.go:776	0x100213cf8		aa1f03e7		MOVD ZR, R7										
  execution.go:776	0x100213cfc		97fff0c1		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk(SB)		
  execution.go:777	0x100213d00		b5001703		CBNZ R3, 184(PC)									
  execution.go:342	0x100213d04		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100213d08		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100213d0c		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100213d10		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100213d14		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100213d18		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100213d1c		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100213d20		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100213d24		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100213d28		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100213d2c		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100213d30		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100213d34		aa0103f7		MOVD R1, R23										
  execution.go:704	0x100213d38		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100213d3c		aa0203e1		MOVD R2, R1										
  execution.go:209	0x100213d40		f94127e0		MOVD 584(RSP), R0									
  execution.go:785	0x100213d44		d3401c38		UBFX $0, R1, $8, R24									
  execution.go:785	0x100213d48		350010d8		CBNZW R24, 134(PC)									
  execution.go:789	0x100213d4c		b9400a94		MOVWU 8(R20), R20									
  execution.go:789	0x100213d50		3100069f		CMNW $1, R20										
  execution.go:789	0x100213d54		540000a0		BEQ 5(PC)										
  execution.go:790	0x100213d58		eb13029f		CMP R19, R20										
  execution.go:790	0x100213d5c		540015c2		BCS 174(PC)										
  execution.go:790	0x100213d60		8b141194		ADD R20<<4, R12, R20									
  execution.go:790	0x100213d64		a9005e96		STP (R22, R23), (R20)									
  execution.go:792	0x100213d68		91000631		ADD $1, R17, R17									
  execution.go:793	0x100213d6c		17fff90e		JMP -1778(PC)										
  execution.go:466	0x100213d70		b9000951		MOVW R17, 8(R10)									
  execution.go:467	0x100213d74		94000827		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:467	0x100213d78		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:467	0x100213d7c		34ff1d21		CBZW R1, -1815(PC)									
  execution.go:467	0x100213d80		1400003b		JMP 59(PC)										
  execution.go:664	0x100213d84		b9000951		MOVW R17, 8(R10)									
  execution.go:665	0x100213d88		94000dde		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow(SB)	
  execution.go:665	0x100213d8c		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:665	0x100213d90		34ff1c81		CBZW R1, -1820(PC)									
  execution.go:665	0x100213d94		1400005a		JMP 90(PC)										
  execution.go:744	0x100213d98		b9000951		MOVW R17, 8(R10)									
  execution.go:745	0x100213d9c		94000abd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB)		
  execution.go:745	0x100213da0		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:745	0x100213da4		34ff1be1		CBZW R1, -1825(PC)									
  execution.go:745	0x100213da8		14000059		JMP 89(PC)										
  execution.go:623	0x100213dac		b9000951		MOVW R17, 8(R10)									
  execution.go:624	0x100213db0		94000eb0		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame(SB)	
  execution.go:624	0x100213db4		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:624	0x100213db8		34ff1b41		CBZW R1, -1830(PC)									
  execution.go:624	0x100213dbc		14000058		JMP 88(PC)										
  execution.go:629	0x100213dc0		b9000951		MOVW R17, 8(R10)									
  execution.go:630	0x100213dc4		94000813		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:630	0x100213dc8		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:630	0x100213dcc		34ff1aa1		CBZW R1, -1835(PC)									
  execution.go:630	0x100213dd0		1400008c		JMP 140(PC)										
  execution.go:343	0x100213dd4		f9009ff5		MOVD R21, 312(RSP)									
  execution.go:341	0x100213dd8		f90097e1		MOVD R1, 296(RSP)									
  execution.go:346	0x100213ddc		d2800500		MOVD $40, R0										
  execution.go:346	0x100213de0		90001241		ADRP 2392064(PC), R1									
  execution.go:346	0x100213de4		910d0021		ADD $832, R1, R1									
  execution.go:346	0x100213de8		b24003e2		ORR $1, ZR, R2										
  execution.go:346	0x100213dec		97f82385		CALL runtime.mallocgcSmallScanNoHeaderSC5(SB)						
  execution.go:346	0x100213df0		9000139b		ADRP 2555904(PC), R27									
  execution.go:346	0x100213df4		9104437b		ADD $272, R27, R27									
  execution.go:346	0x100213df8		a9401363		LDP (R27), (R3, R4)									
  execution.go:346	0x100213dfc		f9000003		MOVD R3, (R0)										
  execution.go:346	0x100213e00		b00014fb		ADRP 2740224(PC), R27									
  execution.go:346	0x100213e04		b94ef363		MOVWU 3824(R27), R3									
  execution.go:346	0x100213e08		34000063		CBZW R3, 3(PC)										
  execution.go:346	0x100213e0c		97f9bd15		CALL runtime.gcWriteBarrier1(SB)							
  execution.go:346	0x100213e10		f9000324		MOVD R4, (R25)										
  execution.go:346	0x100213e14		f9000404		MOVD R4, 8(R0)										
  execution.go:346	0x100213e18		f9409fe3		MOVD 312(RSP), R3									
  execution.go:346	0x100213e1c		f9400463		MOVD 8(R3), R3										
  execution.go:346	0x100213e20		90000104		ADRP 131072(PC), R4									
  execution.go:346	0x100213e24		910e3c84		ADD $911, R4, R4									
  execution.go:346	0x100213e28		a9011003		STP (R3, R4), 16(R0)									
  execution.go:346	0x100213e2c		b27f0be3		ORR $14, ZR, R3										
  execution.go:346	0x100213e30		f9001003		MOVD R3, 32(R0)										
  execution.go:346	0x100213e34		b0001301		ADRP 2494464(PC), R1									
  execution.go:346	0x100213e38		9119a021		ADD $1640, R1, R1									
  execution.go:346	0x100213e3c		aa0003e2		MOVD R0, R2										
  execution.go:346	0x100213e40		f94127e0		MOVD 584(RSP), R0									
  execution.go:346	0x100213e44		97fff63f		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:346	0x100213e48		f94097e1		MOVD 296(RSP), R1									
  execution.go:346	0x100213e4c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:346	0x100213e50		910903ff		ADD $576, RSP, RSP									
  execution.go:346	0x100213e54		d65f03c0		RET											
  execution.go:353	0x100213e58		97fff63a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:353	0x100213e5c		f94097e1		MOVD 296(RSP), R1									
  execution.go:353	0x100213e60		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:353	0x100213e64		910903ff		ADD $576, RSP, RSP									
  execution.go:353	0x100213e68		d65f03c0		RET											
  execution.go:468	0x100213e6c		f94093e1		MOVD 288(RSP), R1									
  execution.go:468	0x100213e70		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:468	0x100213e74		910903ff		ADD $576, RSP, RSP									
  execution.go:468	0x100213e78		d65f03c0		RET											
  execution.go:412	0x100213e7c		f900bbe3		MOVD R3, 368(RSP)									
  execution.go:412	0x100213e80		f9008fe2		MOVD R2, 280(RSP)									
  execution.go:414	0x100213e84		b27d03e0		ORR $8, ZR, R0										
  execution.go:414	0x100213e88		d0001081		ADRP 2170880(PC), R1									
  execution.go:414	0x100213e8c		91056021		ADD $344, R1, R1									
  execution.go:414	0x100213e90		b24003e2		ORR $1, ZR, R2										
  execution.go:414	0x100213e94		97f82027		CALL runtime.mallocgcSmallScanNoHeaderSC1(SB)						
  execution.go:414	0x100213e98		f9011be0		MOVD R0, 560(RSP)									
  execution.go:415	0x100213e9c		f940bbe1		MOVD 368(RSP), R1									
  execution.go:415	0x100213ea0		f0000fc2		ADRP 2076672(PC), R2									
  execution.go:415	0x100213ea4		91276042		ADD $2520, R2, R2									
  execution.go:415	0x100213ea8		aa0003e3		MOVD R0, R3										
  execution.go:415	0x100213eac		f9408fe0		MOVD 280(RSP), R0									
  execution.go:415	0x100213eb0		97f9d0d0		CALL errors.As(SB)									
  execution.go:415	0x100213eb4		360000c0		TBZ $0, R0, 6(PC)									
  execution.go:416	0x100213eb8		f9411be3		MOVD 560(RSP), R3									
  execution.go:416	0x100213ebc		f9400063		MOVD (R3), R3										
  execution.go:416	0x100213ec0		f940b3e4		MOVD 352(RSP), R4									
  execution.go:416	0x100213ec4		b9405084		MOVWU 80(R4), R4									
  execution.go:416	0x100213ec8		b9000464		MOVW R4, 4(R3)										
  execution.go:418	0x100213ecc		f94127e0		MOVD 584(RSP), R0									
  execution.go:418	0x100213ed0		f9408fe1		MOVD 280(RSP), R1									
  execution.go:418	0x100213ed4		f940bbe2		MOVD 368(RSP), R2									
  execution.go:418	0x100213ed8		97fff61a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:418	0x100213edc		f94093e1		MOVD 288(RSP), R1									
  execution.go:418	0x100213ee0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:418	0x100213ee4		910903ff		ADD $576, RSP, RSP									
  execution.go:418	0x100213ee8		d65f03c0		RET											
  execution.go:426	0x100213eec		f94093e1		MOVD 288(RSP), R1									
  execution.go:426	0x100213ef0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:426	0x100213ef4		910903ff		ADD $576, RSP, RSP									
  execution.go:426	0x100213ef8		d65f03c0		RET											
  execution.go:666	0x100213efc		f94093e1		MOVD 288(RSP), R1									
  execution.go:666	0x100213f00		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:666	0x100213f04		910903ff		ADD $576, RSP, RSP									
  execution.go:666	0x100213f08		d65f03c0		RET											
  execution.go:746	0x100213f0c		f94093e1		MOVD 288(RSP), R1									
  execution.go:746	0x100213f10		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:746	0x100213f14		910903ff		ADD $576, RSP, RSP									
  execution.go:746	0x100213f18		d65f03c0		RET											
  execution.go:625	0x100213f1c		f94093e1		MOVD 288(RSP), R1									
  execution.go:625	0x100213f20		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:625	0x100213f24		910903ff		ADD $576, RSP, RSP									
  execution.go:625	0x100213f28		d65f03c0		RET											
  execution.go:654	0x100213f2c		97fff605		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:654	0x100213f30		f94093e1		MOVD 288(RSP), R1									
  execution.go:654	0x100213f34		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:654	0x100213f38		910903ff		ADD $576, RSP, RSP									
  execution.go:654	0x100213f3c		d65f03c0		RET											
  execution.go:771	0x100213f40		f94127e0		MOVD 584(RSP), R0									
  execution.go:771	0x100213f44		aa0303e1		MOVD R3, R1										
  execution.go:771	0x100213f48		aa0403e2		MOVD R4, R2										
  execution.go:771	0x100213f4c		97fff5fd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:771	0x100213f50		f94093e1		MOVD 288(RSP), R1									
  execution.go:771	0x100213f54		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:771	0x100213f58		910903ff		ADD $576, RSP, RSP									
  execution.go:771	0x100213f5c		d65f03c0		RET											
  execution.go:395	0x100213f60		3903dbe1		MOVB R1, 246(RSP)									
  execution.go:786	0x100213f64		b27c03e0		ORR $16, ZR, R0										
  execution.go:786	0x100213f68		90001241		ADRP 2392064(PC), R1									
  execution.go:786	0x100213f6c		910fa021		ADD $1000, R1, R1									
  execution.go:786	0x100213f70		b24003e2		ORR $1, ZR, R2										
  execution.go:786	0x100213f74		97f826a7		CALL runtime.mallocgcSmallNoScanSC2(SB)							
  execution.go:786	0x100213f78		3943dbe3		MOVBU 246(RSP), R3									
  execution.go:786	0x100213f7c		39000003		MOVB R3, (R0)										
  execution.go:786	0x100213f80		f940b3e3		MOVD 352(RSP), R3									
  execution.go:786	0x100213f84		b9405063		MOVWU 80(R3), R3									
  execution.go:786	0x100213f88		b9000403		MOVW R3, 4(R0)										
  execution.go:786	0x100213f8c		f940bfe3		MOVD 376(RSP), R3									
  execution.go:786	0x100213f90		a9479063		LDP 120(R3), (R3, R4)									
  execution.go:786	0x100213f94		f940c3e5		MOVD 384(RSP), R5									
  execution.go:786	0x100213f98		b94004a5		MOVWU 4(R5), R5										
  execution.go:786	0x100213f9c		aa0503e6		MOVD R5, R6										
  execution.go:786	0x100213fa0		eb0400df		CMP R4, R6										
  execution.go:786	0x100213fa4		54000362		BCS 27(PC)										
  execution.go:786	0x100213fa8		d3787ca4		UBFIZ $8, R5, $32, R4									
  execution.go:786	0x100213fac		cb061484		SUB R6<<5, R4, R4									
  execution.go:786	0x100213fb0		8b040063		ADD R4, R3, R3										
  execution.go:786	0x100213fb4		f9400463		MOVD 8(R3), R3										
  execution.go:786	0x100213fb8		f9000403		MOVD R3, 8(R0)										
  execution.go:786	0x100213fbc		b0001301		ADRP 2494464(PC), R1									
  execution.go:786	0x100213fc0		911aa021		ADD $1704, R1, R1									
  execution.go:786	0x100213fc4		aa0003e2		MOVD R0, R2										
  execution.go:786	0x100213fc8		f94127e0		MOVD 584(RSP), R0									
  execution.go:786	0x100213fcc		97fff5dd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:786	0x100213fd0		f94093e1		MOVD 288(RSP), R1									
  execution.go:786	0x100213fd4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:786	0x100213fd8		910903ff		ADD $576, RSP, RSP									
  execution.go:786	0x100213fdc		d65f03c0		RET											
  execution.go:778	0x100213fe0		f94127e0		MOVD 584(RSP), R0									
  execution.go:778	0x100213fe4		aa0303e1		MOVD R3, R1										
  execution.go:778	0x100213fe8		aa0403e2		MOVD R4, R2										
  execution.go:778	0x100213fec		97fff5d5		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:778	0x100213ff0		f94093e1		MOVD 288(RSP), R1									
  execution.go:778	0x100213ff4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:778	0x100213ff8		910903ff		ADD $576, RSP, RSP									
  execution.go:778	0x100213ffc		d65f03c0		RET											
  execution.go:631	0x100214000		f94093e1		MOVD 288(RSP), R1									
  execution.go:631	0x100214004		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:631	0x100214008		910903ff		ADD $576, RSP, RSP									
  execution.go:631	0x10021400c		d65f03c0		RET											
  execution.go:786	0x100214010		97f9bd4c		CALL runtime.panicBounds(SB)								
  execution.go:790	0x100214014		aa1403e0		MOVD R20, R0										
  execution.go:790	0x100214018		aa1303e1		MOVD R19, R1										
  execution.go:790	0x10021401c		97f9bd49		CALL runtime.panicBounds(SB)								
  execution.go:774	0x100214020		aa1803e0		MOVD R24, R0										
  execution.go:774	0x100214024		aa1603e1		MOVD R22, R1										
  execution.go:774	0x100214028		97f9bd46		CALL runtime.panicBounds(SB)								
  execution.go:781	0x10021402c		90001180		ADRP 2293760(PC), R0									
  execution.go:781	0x100214030		9128c000		ADD $2608, R0, R0									
  execution.go:781	0x100214034		90000fa1		ADRP 2048000(PC), R1									
  execution.go:781	0x100214038		91294021		ADD $2640, R1, R1									
  execution.go:781	0x10021403c		97f9a1d5		CALL runtime.gopanic(SB)								
  execution.go:769	0x100214040		aa1e03e0		MOVD R30, R0										
  execution.go:769	0x100214044		aa1903e1		MOVD R25, R1										
  execution.go:769	0x100214048		97f9bd3e		CALL runtime.panicBounds(SB)								
  execution.go:767	0x10021404c		aa1a03e0		MOVD R26, R0										
  execution.go:767	0x100214050		aa1803e1		MOVD R24, R1										
  execution.go:767	0x100214054		97f9bd3b		CALL runtime.panicBounds(SB)								
  execution.go:758	0x100214058		aa1603e0		MOVD R22, R0										
  execution.go:758	0x10021405c		aa1303e1		MOVD R19, R1										
  execution.go:758	0x100214060		97f9bd38		CALL runtime.panicBounds(SB)								
  execution.go:755	0x100214064		aa1603e0		MOVD R22, R0										
  execution.go:755	0x100214068		aa1303e1		MOVD R19, R1										
  execution.go:755	0x10021406c		97f9bd35		CALL runtime.panicBounds(SB)								
  execution.go:752	0x100214070		aa1603e0		MOVD R22, R0										
  execution.go:752	0x100214074		aa1303e1		MOVD R19, R1										
  execution.go:752	0x100214078		97f9bd32		CALL runtime.panicBounds(SB)								
  execution.go:658	0x10021407c		8b181198		ADD R24<<4, R12, R24									
  execution.go:658	0x100214080		a9006b19		STP (R25, R26), (R24)									
  execution.go:657	0x100214084		910006f7		ADD $1, R23, R23									
  execution.go:657	0x100214088		eb1402ff		CMP R20, R23										
  execution.go:657	0x10021408c		5400014a		BGE 10(PC)										
  execution.go:657	0x100214090		8b170e38		ADD R23<<3, R17, R24									
  execution.go:657	0x100214094		29406718		LDPW (R24), (R24, R25)									
  execution.go:658	0x100214098		eb13033f		CMP R19, R25										
  execution.go:658	0x10021409c		54000162		BCS 11(PC)										
  execution.go:658	0x1002140a0		8b191199		ADD R25<<4, R12, R25									
  execution.go:658	0x1002140a4		a9406b39		LDP (R25), (R25, R26)									
  execution.go:658	0x1002140a8		eb13031f		CMP R19, R24										
  execution.go:658	0x1002140ac		54fffe83		BCC -12(PC)										
  execution.go:658	0x1002140b0		14000003		JMP 3(PC)										
  execution.go:460	0x1002140b4		aa1603f1		MOVD R22, R17										
  execution.go:661	0x1002140b8		17fff83b		JMP -1989(PC)										
  execution.go:658	0x1002140bc		aa1803e0		MOVD R24, R0										
  execution.go:658	0x1002140c0		aa1303e1		MOVD R19, R1										
  execution.go:658	0x1002140c4		97f9bd1f		CALL runtime.panicBounds(SB)								
  execution.go:658	0x1002140c8		aa1903e0		MOVD R25, R0										
  execution.go:658	0x1002140cc		aa1303e1		MOVD R19, R1										
  execution.go:658	0x1002140d0		97f9bd1c		CALL runtime.panicBounds(SB)								
  execution.go:657	0x1002140d4		aa1403e0		MOVD R20, R0										
  execution.go:657	0x1002140d8		aa1703e1		MOVD R23, R1										
  execution.go:657	0x1002140dc		97f9bd19		CALL runtime.panicBounds(SB)								
  execution.go:657	0x1002140e0		aa1703e0		MOVD R23, R0										
  execution.go:657	0x1002140e4		aa1103e1		MOVD R17, R1										
  execution.go:657	0x1002140e8		97f9bd16		CALL runtime.panicBounds(SB)								
  execution.go:651	0x1002140ec		aa1603e0		MOVD R22, R0										
  execution.go:651	0x1002140f0		aa1803e1		MOVD R24, R1										
  execution.go:651	0x1002140f4		97f9bd13		CALL runtime.panicBounds(SB)								
  execution.go:646	0x1002140f8		aa1703e0		MOVD R23, R0										
  execution.go:646	0x1002140fc		aa1303e1		MOVD R19, R1										
  execution.go:646	0x100214100		97f9bd10		CALL runtime.panicBounds(SB)								
  execution.go:643	0x100214104		aa1803e0		MOVD R24, R0										
  execution.go:643	0x100214108		aa1303e1		MOVD R19, R1										
  execution.go:643	0x10021410c		97f9bd0d		CALL runtime.panicBounds(SB)								
  execution.go:641	0x100214110		aa1803e0		MOVD R24, R0										
  execution.go:641	0x100214114		aa1303e1		MOVD R19, R1										
  execution.go:641	0x100214118		97f9bd0a		CALL runtime.panicBounds(SB)								
  execution.go:725	0x10021411c		aa1303e0		MOVD R19, R0										
  execution.go:725	0x100214120		97f9bd08		CALL runtime.panicBounds(SB)								
  execution.go:732	0x100214124		aa1603e0		MOVD R22, R0										
  execution.go:732	0x100214128		aa1303e1		MOVD R19, R1										
  execution.go:732	0x10021412c		97f9bd05		CALL runtime.panicBounds(SB)								
  execution.go:727	0x100214130		aa1703e0		MOVD R23, R0										
  execution.go:727	0x100214134		aa1303e1		MOVD R19, R1										
  execution.go:727	0x100214138		97f9bd02		CALL runtime.panicBounds(SB)								
  execution.go:727	0x10021413c		aa1603e0		MOVD R22, R0										
  execution.go:727	0x100214140		aa1303e1		MOVD R19, R1										
  execution.go:727	0x100214144		97f9bcff		CALL runtime.panicBounds(SB)								
  execution.go:742	0x100214148		aa1803e0		MOVD R24, R0										
  execution.go:742	0x10021414c		aa1703e1		MOVD R23, R1										
  execution.go:742	0x100214150		97f9bcfc		CALL runtime.panicBounds(SB)								
  execution.go:738	0x100214154		aa1603e0		MOVD R22, R0										
  execution.go:738	0x100214158		aa1303e1		MOVD R19, R1										
  execution.go:738	0x10021415c		97f9bcf9		CALL runtime.panicBounds(SB)								
  execution.go:710	0x100214160		97f9bcf8		CALL runtime.panicBounds(SB)								
  execution.go:713	0x100214164		aa1303e0		MOVD R19, R0										
  execution.go:713	0x100214168		97f9bcf6		CALL runtime.panicBounds(SB)								
  execution.go:712	0x10021416c		97f9bcf5		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100214170		aa1603e0		MOVD R22, R0										
  execution.go:708	0x100214174		aa1303e1		MOVD R19, R1										
  execution.go:708	0x100214178		97f9bcf2		CALL runtime.panicBounds(SB)								
  execution.go:708	0x10021417c		aa1703e0		MOVD R23, R0										
  execution.go:708	0x100214180		97f9bcf0		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100214184		aa1303e0		MOVD R19, R0										
  execution.go:708	0x100214188		97f9bcee		CALL runtime.panicBounds(SB)								
  execution.go:707	0x10021418c		aa1703e0		MOVD R23, R0										
  execution.go:707	0x100214190		97f9bcec		CALL runtime.panicBounds(SB)								
  execution.go:704	0x100214194		aa1303e0		MOVD R19, R0										
  execution.go:704	0x100214198		97f9bcea		CALL runtime.panicBounds(SB)								
  execution.go:704	0x10021419c		aa1803e0		MOVD R24, R0										
  execution.go:704	0x1002141a0		aa1603e1		MOVD R22, R1										
  execution.go:704	0x1002141a4		97f9bce7		CALL runtime.panicBounds(SB)								
  execution.go:703	0x1002141a8		aa1703e0		MOVD R23, R0										
  execution.go:703	0x1002141ac		97f9bce5		CALL runtime.panicBounds(SB)								
  execution.go:699	0x1002141b0		aa1803e0		MOVD R24, R0										
  execution.go:699	0x1002141b4		aa1303e1		MOVD R19, R1										
  execution.go:699	0x1002141b8		97f9bce2		CALL runtime.panicBounds(SB)								
  execution.go:695	0x1002141bc		aa1703e0		MOVD R23, R0										
  execution.go:695	0x1002141c0		aa1303e1		MOVD R19, R1										
  execution.go:695	0x1002141c4		97f9bcdf		CALL runtime.panicBounds(SB)								
  execution.go:694	0x1002141c8		aa1803e0		MOVD R24, R0										
  execution.go:694	0x1002141cc		aa1703e1		MOVD R23, R1										
  execution.go:694	0x1002141d0		97f9bcdc		CALL runtime.panicBounds(SB)								
  execution.go:687	0x1002141d4		aa1703e0		MOVD R23, R0										
  execution.go:687	0x1002141d8		aa1303e1		MOVD R19, R1										
  execution.go:687	0x1002141dc		97f9bcd9		CALL runtime.panicBounds(SB)								
  execution.go:686	0x1002141e0		aa1803e0		MOVD R24, R0										
  execution.go:686	0x1002141e4		aa1703e1		MOVD R23, R1										
  execution.go:686	0x1002141e8		97f9bcd6		CALL runtime.panicBounds(SB)								
  execution.go:684	0x1002141ec		aa1903e0		MOVD R25, R0										
  execution.go:684	0x1002141f0		aa1803e1		MOVD R24, R1										
  execution.go:684	0x1002141f4		97f9bcd3		CALL runtime.panicBounds(SB)								
  execution.go:684	0x1002141f8		aa1603e0		MOVD R22, R0										
  execution.go:684	0x1002141fc		aa1303e1		MOVD R19, R1										
  execution.go:684	0x100214200		97f9bcd0		CALL runtime.panicBounds(SB)								
  execution.go:682	0x100214204		aa1803e0		MOVD R24, R0										
  execution.go:682	0x100214208		aa1703e1		MOVD R23, R1										
  execution.go:682	0x10021420c		97f9bccd		CALL runtime.panicBounds(SB)								
  execution.go:680	0x100214210		aa1803e0		MOVD R24, R0										
  execution.go:680	0x100214214		aa1303e1		MOVD R19, R1										
  execution.go:680	0x100214218		97f9bcca		CALL runtime.panicBounds(SB)								
  execution.go:679	0x10021421c		aa1603e0		MOVD R22, R0										
  execution.go:679	0x100214220		aa1303e1		MOVD R19, R1										
  execution.go:679	0x100214224		97f9bcc7		CALL runtime.panicBounds(SB)								
  execution.go:677	0x100214228		aa1603e0		MOVD R22, R0										
  execution.go:677	0x10021422c		aa1303e1		MOVD R19, R1										
  execution.go:677	0x100214230		97f9bcc4		CALL runtime.panicBounds(SB)								
  execution.go:675	0x100214234		aa1603e0		MOVD R22, R0										
  execution.go:675	0x100214238		aa1303e1		MOVD R19, R1										
  execution.go:675	0x10021423c		97f9bcc1		CALL runtime.panicBounds(SB)								
  execution.go:672	0x100214240		aa1703e0		MOVD R23, R0										
  execution.go:672	0x100214244		aa1303e1		MOVD R19, R1										
  execution.go:672	0x100214248		97f9bcbe		CALL runtime.panicBounds(SB)								
  execution.go:600	0x10021424c		aa1603e0		MOVD R22, R0										
  execution.go:600	0x100214250		aa1303e1		MOVD R19, R1										
  execution.go:600	0x100214254		97f9bcbb		CALL runtime.panicBounds(SB)								
  execution.go:598	0x100214258		aa1603e0		MOVD R22, R0										
  execution.go:598	0x10021425c		aa1303e1		MOVD R19, R1										
  execution.go:598	0x100214260		97f9bcb8		CALL runtime.panicBounds(SB)								
  execution.go:596	0x100214264		aa1603e0		MOVD R22, R0										
  execution.go:596	0x100214268		aa1303e1		MOVD R19, R1										
  execution.go:596	0x10021426c		97f9bcb5		CALL runtime.panicBounds(SB)								
  execution.go:594	0x100214270		aa1603e0		MOVD R22, R0										
  execution.go:594	0x100214274		aa1303e1		MOVD R19, R1										
  execution.go:594	0x100214278		97f9bcb2		CALL runtime.panicBounds(SB)								
  execution.go:592	0x10021427c		aa1603e0		MOVD R22, R0										
  execution.go:592	0x100214280		aa1303e1		MOVD R19, R1										
  execution.go:592	0x100214284		97f9bcaf		CALL runtime.panicBounds(SB)								
  execution.go:614	0x100214288		aa1303e0		MOVD R19, R0										
  execution.go:614	0x10021428c		97f9bcad		CALL runtime.panicBounds(SB)								
  execution.go:612	0x100214290		aa1303e0		MOVD R19, R0										
  execution.go:612	0x100214294		97f9bcab		CALL runtime.panicBounds(SB)								
  execution.go:590	0x100214298		aa1603e0		MOVD R22, R0										
  execution.go:590	0x10021429c		aa1303e1		MOVD R19, R1										
  execution.go:590	0x1002142a0		97f9bca8		CALL runtime.panicBounds(SB)								
  execution.go:588	0x1002142a4		aa1603e0		MOVD R22, R0										
  execution.go:588	0x1002142a8		aa1303e1		MOVD R19, R1										
  execution.go:588	0x1002142ac		97f9bca5		CALL runtime.panicBounds(SB)								
  execution.go:586	0x1002142b0		aa1603e0		MOVD R22, R0										
  execution.go:586	0x1002142b4		aa1303e1		MOVD R19, R1										
  execution.go:586	0x1002142b8		97f9bca2		CALL runtime.panicBounds(SB)								
  execution.go:584	0x1002142bc		aa1703e0		MOVD R23, R0										
  execution.go:584	0x1002142c0		aa1303e1		MOVD R19, R1										
  execution.go:584	0x1002142c4		97f9bc9f		CALL runtime.panicBounds(SB)								
  execution.go:584	0x1002142c8		aa1603e0		MOVD R22, R0										
  execution.go:584	0x1002142cc		aa1303e1		MOVD R19, R1										
  execution.go:584	0x1002142d0		97f9bc9c		CALL runtime.panicBounds(SB)								
  execution.go:582	0x1002142d4		aa1703e0		MOVD R23, R0										
  execution.go:582	0x1002142d8		aa1303e1		MOVD R19, R1										
  execution.go:582	0x1002142dc		97f9bc99		CALL runtime.panicBounds(SB)								
  execution.go:582	0x1002142e0		aa1603e0		MOVD R22, R0										
  execution.go:582	0x1002142e4		aa1303e1		MOVD R19, R1										
  execution.go:582	0x1002142e8		97f9bc96		CALL runtime.panicBounds(SB)								
  execution.go:580	0x1002142ec		aa1703e0		MOVD R23, R0										
  execution.go:580	0x1002142f0		aa1303e1		MOVD R19, R1										
  execution.go:580	0x1002142f4		97f9bc93		CALL runtime.panicBounds(SB)								
  execution.go:580	0x1002142f8		aa1603e0		MOVD R22, R0										
  execution.go:580	0x1002142fc		aa1303e1		MOVD R19, R1										
  execution.go:580	0x100214300		97f9bc90		CALL runtime.panicBounds(SB)								
  execution.go:578	0x100214304		aa1703e0		MOVD R23, R0										
  execution.go:578	0x100214308		aa1303e1		MOVD R19, R1										
  execution.go:578	0x10021430c		97f9bc8d		CALL runtime.panicBounds(SB)								
  execution.go:578	0x100214310		aa1603e0		MOVD R22, R0										
  execution.go:578	0x100214314		aa1303e1		MOVD R19, R1										
  execution.go:578	0x100214318		97f9bc8a		CALL runtime.panicBounds(SB)								
  execution.go:576	0x10021431c		aa1703e0		MOVD R23, R0										
  execution.go:576	0x100214320		aa1303e1		MOVD R19, R1										
  execution.go:576	0x100214324		97f9bc87		CALL runtime.panicBounds(SB)								
  execution.go:576	0x100214328		aa1603e0		MOVD R22, R0										
  execution.go:576	0x10021432c		aa1303e1		MOVD R19, R1										
  execution.go:576	0x100214330		97f9bc84		CALL runtime.panicBounds(SB)								
  execution.go:574	0x100214334		aa1703e0		MOVD R23, R0										
  execution.go:574	0x100214338		aa1303e1		MOVD R19, R1										
  execution.go:574	0x10021433c		97f9bc81		CALL runtime.panicBounds(SB)								
  execution.go:574	0x100214340		aa1603e0		MOVD R22, R0										
  execution.go:574	0x100214344		aa1303e1		MOVD R19, R1										
  execution.go:574	0x100214348		97f9bc7e		CALL runtime.panicBounds(SB)								
  execution.go:572	0x10021434c		aa1703e0		MOVD R23, R0										
  execution.go:572	0x100214350		aa1303e1		MOVD R19, R1										
  execution.go:572	0x100214354		97f9bc7b		CALL runtime.panicBounds(SB)								
  execution.go:572	0x100214358		aa1603e0		MOVD R22, R0										
  execution.go:572	0x10021435c		aa1303e1		MOVD R19, R1										
  execution.go:572	0x100214360		97f9bc78		CALL runtime.panicBounds(SB)								
  execution.go:570	0x100214364		aa1703e0		MOVD R23, R0										
  execution.go:570	0x100214368		aa1303e1		MOVD R19, R1										
  execution.go:570	0x10021436c		97f9bc75		CALL runtime.panicBounds(SB)								
  execution.go:570	0x100214370		aa1603e0		MOVD R22, R0										
  execution.go:570	0x100214374		aa1303e1		MOVD R19, R1										
  execution.go:570	0x100214378		97f9bc72		CALL runtime.panicBounds(SB)								
  execution.go:568	0x10021437c		aa1703e0		MOVD R23, R0										
  execution.go:568	0x100214380		aa1303e1		MOVD R19, R1										
  execution.go:568	0x100214384		97f9bc6f		CALL runtime.panicBounds(SB)								
  execution.go:568	0x100214388		aa1603e0		MOVD R22, R0										
  execution.go:568	0x10021438c		aa1303e1		MOVD R19, R1										
  execution.go:568	0x100214390		97f9bc6c		CALL runtime.panicBounds(SB)								
  execution.go:566	0x100214394		aa1703e0		MOVD R23, R0										
  execution.go:566	0x100214398		aa1303e1		MOVD R19, R1										
  execution.go:566	0x10021439c		97f9bc69		CALL runtime.panicBounds(SB)								
  execution.go:566	0x1002143a0		aa1603e0		MOVD R22, R0										
  execution.go:566	0x1002143a4		aa1303e1		MOVD R19, R1										
  execution.go:566	0x1002143a8		97f9bc66		CALL runtime.panicBounds(SB)								
  execution.go:564	0x1002143ac		aa1703e0		MOVD R23, R0										
  execution.go:564	0x1002143b0		aa1303e1		MOVD R19, R1										
  execution.go:564	0x1002143b4		97f9bc63		CALL runtime.panicBounds(SB)								
  execution.go:564	0x1002143b8		aa1603e0		MOVD R22, R0										
  execution.go:564	0x1002143bc		aa1303e1		MOVD R19, R1										
  execution.go:564	0x1002143c0		97f9bc60		CALL runtime.panicBounds(SB)								
  execution.go:532	0x1002143c4		aa1603e0		MOVD R22, R0										
  execution.go:532	0x1002143c8		aa1303e1		MOVD R19, R1										
  execution.go:532	0x1002143cc		97f9bc5d		CALL runtime.panicBounds(SB)								
  execution.go:562	0x1002143d0		aa1603e0		MOVD R22, R0										
  execution.go:562	0x1002143d4		aa1303e1		MOVD R19, R1										
  execution.go:562	0x1002143d8		97f9bc5a		CALL runtime.panicBounds(SB)								
  execution.go:560	0x1002143dc		aa1603e0		MOVD R22, R0										
  execution.go:560	0x1002143e0		aa1303e1		MOVD R19, R1										
  execution.go:560	0x1002143e4		97f9bc57		CALL runtime.panicBounds(SB)								
  execution.go:558	0x1002143e8		aa1703e0		MOVD R23, R0										
  execution.go:558	0x1002143ec		aa1303e1		MOVD R19, R1										
  execution.go:558	0x1002143f0		97f9bc54		CALL runtime.panicBounds(SB)								
  execution.go:558	0x1002143f4		aa1603e0		MOVD R22, R0										
  execution.go:558	0x1002143f8		aa1303e1		MOVD R19, R1										
  execution.go:558	0x1002143fc		97f9bc51		CALL runtime.panicBounds(SB)								
  execution.go:556	0x100214400		aa1703e0		MOVD R23, R0										
  execution.go:556	0x100214404		aa1303e1		MOVD R19, R1										
  execution.go:556	0x100214408		97f9bc4e		CALL runtime.panicBounds(SB)								
  execution.go:556	0x10021440c		aa1603e0		MOVD R22, R0										
  execution.go:556	0x100214410		aa1303e1		MOVD R19, R1										
  execution.go:556	0x100214414		97f9bc4b		CALL runtime.panicBounds(SB)								
  execution.go:554	0x100214418		aa1703e0		MOVD R23, R0										
  execution.go:554	0x10021441c		aa1303e1		MOVD R19, R1										
  execution.go:554	0x100214420		97f9bc48		CALL runtime.panicBounds(SB)								
  execution.go:554	0x100214424		aa1603e0		MOVD R22, R0										
  execution.go:554	0x100214428		aa1303e1		MOVD R19, R1										
  execution.go:554	0x10021442c		97f9bc45		CALL runtime.panicBounds(SB)								
  execution.go:552	0x100214430		aa1703e0		MOVD R23, R0										
  execution.go:552	0x100214434		aa1303e1		MOVD R19, R1										
  execution.go:552	0x100214438		97f9bc42		CALL runtime.panicBounds(SB)								
  execution.go:552	0x10021443c		aa1603e0		MOVD R22, R0										
  execution.go:552	0x100214440		aa1303e1		MOVD R19, R1										
  execution.go:552	0x100214444		97f9bc3f		CALL runtime.panicBounds(SB)								
  execution.go:550	0x100214448		aa1703e0		MOVD R23, R0										
  execution.go:550	0x10021444c		aa1303e1		MOVD R19, R1										
  execution.go:550	0x100214450		97f9bc3c		CALL runtime.panicBounds(SB)								
  execution.go:550	0x100214454		aa1603e0		MOVD R22, R0										
  execution.go:550	0x100214458		aa1303e1		MOVD R19, R1										
  execution.go:550	0x10021445c		97f9bc39		CALL runtime.panicBounds(SB)								
  execution.go:548	0x100214460		aa1703e0		MOVD R23, R0										
  execution.go:548	0x100214464		aa1303e1		MOVD R19, R1										
  execution.go:548	0x100214468		97f9bc36		CALL runtime.panicBounds(SB)								
  execution.go:548	0x10021446c		aa1603e0		MOVD R22, R0										
  execution.go:548	0x100214470		aa1303e1		MOVD R19, R1										
  execution.go:548	0x100214474		97f9bc33		CALL runtime.panicBounds(SB)								
  execution.go:546	0x100214478		aa1703e0		MOVD R23, R0										
  execution.go:546	0x10021447c		aa1303e1		MOVD R19, R1										
  execution.go:546	0x100214480		97f9bc30		CALL runtime.panicBounds(SB)								
  execution.go:546	0x100214484		aa1603e0		MOVD R22, R0										
  execution.go:546	0x100214488		aa1303e1		MOVD R19, R1										
  execution.go:546	0x10021448c		97f9bc2d		CALL runtime.panicBounds(SB)								
  execution.go:544	0x100214490		aa1703e0		MOVD R23, R0										
  execution.go:544	0x100214494		aa1303e1		MOVD R19, R1										
  execution.go:544	0x100214498		97f9bc2a		CALL runtime.panicBounds(SB)								
  execution.go:544	0x10021449c		aa1603e0		MOVD R22, R0										
  execution.go:544	0x1002144a0		aa1303e1		MOVD R19, R1										
  execution.go:544	0x1002144a4		97f9bc27		CALL runtime.panicBounds(SB)								
  execution.go:542	0x1002144a8		aa1703e0		MOVD R23, R0										
  execution.go:542	0x1002144ac		aa1303e1		MOVD R19, R1										
  execution.go:542	0x1002144b0		97f9bc24		CALL runtime.panicBounds(SB)								
  execution.go:542	0x1002144b4		aa1603e0		MOVD R22, R0										
  execution.go:542	0x1002144b8		aa1303e1		MOVD R19, R1										
  execution.go:542	0x1002144bc		97f9bc21		CALL runtime.panicBounds(SB)								
  execution.go:540	0x1002144c0		aa1703e0		MOVD R23, R0										
  execution.go:540	0x1002144c4		aa1303e1		MOVD R19, R1										
  execution.go:540	0x1002144c8		97f9bc1e		CALL runtime.panicBounds(SB)								
  execution.go:540	0x1002144cc		aa1603e0		MOVD R22, R0										
  execution.go:540	0x1002144d0		aa1303e1		MOVD R19, R1										
  execution.go:540	0x1002144d4		97f9bc1b		CALL runtime.panicBounds(SB)								
  execution.go:538	0x1002144d8		aa1703e0		MOVD R23, R0										
  execution.go:538	0x1002144dc		aa1303e1		MOVD R19, R1										
  execution.go:538	0x1002144e0		97f9bc18		CALL runtime.panicBounds(SB)								
  execution.go:538	0x1002144e4		aa1603e0		MOVD R22, R0										
  execution.go:538	0x1002144e8		aa1303e1		MOVD R19, R1										
  execution.go:538	0x1002144ec		97f9bc15		CALL runtime.panicBounds(SB)								
  execution.go:528	0x1002144f0		aa1603e0		MOVD R22, R0										
  execution.go:528	0x1002144f4		aa1303e1		MOVD R19, R1										
  execution.go:528	0x1002144f8		97f9bc12		CALL runtime.panicBounds(SB)								
  execution.go:526	0x1002144fc		aa1603e0		MOVD R22, R0										
  execution.go:526	0x100214500		aa1303e1		MOVD R19, R1										
  execution.go:526	0x100214504		97f9bc0f		CALL runtime.panicBounds(SB)								
  execution.go:524	0x100214508		aa1703e0		MOVD R23, R0										
  execution.go:524	0x10021450c		aa1303e1		MOVD R19, R1										
  execution.go:524	0x100214510		97f9bc0c		CALL runtime.panicBounds(SB)								
  execution.go:524	0x100214514		aa1603e0		MOVD R22, R0										
  execution.go:524	0x100214518		aa1303e1		MOVD R19, R1										
  execution.go:524	0x10021451c		97f9bc09		CALL runtime.panicBounds(SB)								
  execution.go:522	0x100214520		aa1703e0		MOVD R23, R0										
  execution.go:522	0x100214524		aa1303e1		MOVD R19, R1										
  execution.go:522	0x100214528		97f9bc06		CALL runtime.panicBounds(SB)								
  execution.go:522	0x10021452c		aa1603e0		MOVD R22, R0										
  execution.go:522	0x100214530		aa1303e1		MOVD R19, R1										
  execution.go:522	0x100214534		97f9bc03		CALL runtime.panicBounds(SB)								
  execution.go:520	0x100214538		aa1703e0		MOVD R23, R0										
  execution.go:520	0x10021453c		aa1303e1		MOVD R19, R1										
  execution.go:520	0x100214540		97f9bc00		CALL runtime.panicBounds(SB)								
  execution.go:520	0x100214544		aa1603e0		MOVD R22, R0										
  execution.go:520	0x100214548		aa1303e1		MOVD R19, R1										
  execution.go:520	0x10021454c		97f9bbfd		CALL runtime.panicBounds(SB)								
  execution.go:518	0x100214550		aa1703e0		MOVD R23, R0										
  execution.go:518	0x100214554		aa1303e1		MOVD R19, R1										
  execution.go:518	0x100214558		97f9bbfa		CALL runtime.panicBounds(SB)								
  execution.go:518	0x10021455c		aa1603e0		MOVD R22, R0										
  execution.go:518	0x100214560		aa1303e1		MOVD R19, R1										
  execution.go:518	0x100214564		97f9bbf7		CALL runtime.panicBounds(SB)								
  execution.go:516	0x100214568		aa1703e0		MOVD R23, R0										
  execution.go:516	0x10021456c		aa1303e1		MOVD R19, R1										
  execution.go:516	0x100214570		97f9bbf4		CALL runtime.panicBounds(SB)								
  execution.go:516	0x100214574		aa1603e0		MOVD R22, R0										
  execution.go:516	0x100214578		aa1303e1		MOVD R19, R1										
  execution.go:516	0x10021457c		97f9bbf1		CALL runtime.panicBounds(SB)								
  execution.go:514	0x100214580		aa1703e0		MOVD R23, R0										
  execution.go:514	0x100214584		aa1303e1		MOVD R19, R1										
  execution.go:514	0x100214588		97f9bbee		CALL runtime.panicBounds(SB)								
  execution.go:514	0x10021458c		aa1603e0		MOVD R22, R0										
  execution.go:514	0x100214590		aa1303e1		MOVD R19, R1										
  execution.go:514	0x100214594		97f9bbeb		CALL runtime.panicBounds(SB)								
  execution.go:512	0x100214598		aa1703e0		MOVD R23, R0										
  execution.go:512	0x10021459c		aa1303e1		MOVD R19, R1										
  execution.go:512	0x1002145a0		97f9bbe8		CALL runtime.panicBounds(SB)								
  execution.go:512	0x1002145a4		aa1603e0		MOVD R22, R0										
  execution.go:512	0x1002145a8		aa1303e1		MOVD R19, R1										
  execution.go:512	0x1002145ac		97f9bbe5		CALL runtime.panicBounds(SB)								
  execution.go:510	0x1002145b0		aa1703e0		MOVD R23, R0										
  execution.go:510	0x1002145b4		aa1303e1		MOVD R19, R1										
  execution.go:510	0x1002145b8		97f9bbe2		CALL runtime.panicBounds(SB)								
  execution.go:510	0x1002145bc		aa1603e0		MOVD R22, R0										
  execution.go:510	0x1002145c0		aa1303e1		MOVD R19, R1										
  execution.go:510	0x1002145c4		97f9bbdf		CALL runtime.panicBounds(SB)								
  execution.go:508	0x1002145c8		aa1703e0		MOVD R23, R0										
  execution.go:508	0x1002145cc		aa1303e1		MOVD R19, R1										
  execution.go:508	0x1002145d0		97f9bbdc		CALL runtime.panicBounds(SB)								
  execution.go:508	0x1002145d4		aa1603e0		MOVD R22, R0										
  execution.go:508	0x1002145d8		aa1303e1		MOVD R19, R1										
  execution.go:508	0x1002145dc		97f9bbd9		CALL runtime.panicBounds(SB)								
  execution.go:506	0x1002145e0		aa1703e0		MOVD R23, R0										
  execution.go:506	0x1002145e4		aa1303e1		MOVD R19, R1										
  execution.go:506	0x1002145e8		97f9bbd6		CALL runtime.panicBounds(SB)								
  execution.go:506	0x1002145ec		aa1603e0		MOVD R22, R0										
  execution.go:506	0x1002145f0		aa1303e1		MOVD R19, R1										
  execution.go:506	0x1002145f4		97f9bbd3		CALL runtime.panicBounds(SB)								
  execution.go:504	0x1002145f8		aa1603e0		MOVD R22, R0										
  execution.go:504	0x1002145fc		aa1303e1		MOVD R19, R1										
  execution.go:504	0x100214600		97f9bbd0		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100214604		aa1703e0		MOVD R23, R0										
  execution.go:502	0x100214608		aa1303e1		MOVD R19, R1										
  execution.go:502	0x10021460c		97f9bbcd		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100214610		aa1603e0		MOVD R22, R0										
  execution.go:502	0x100214614		aa1303e1		MOVD R19, R1										
  execution.go:502	0x100214618		97f9bbca		CALL runtime.panicBounds(SB)								
  execution.go:500	0x10021461c		aa1703e0		MOVD R23, R0										
  execution.go:500	0x100214620		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100214624		97f9bbc7		CALL runtime.panicBounds(SB)								
  execution.go:500	0x100214628		aa1603e0		MOVD R22, R0										
  execution.go:500	0x10021462c		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100214630		97f9bbc4		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100214634		aa1703e0		MOVD R23, R0										
  execution.go:498	0x100214638		aa1303e1		MOVD R19, R1										
  execution.go:498	0x10021463c		97f9bbc1		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100214640		aa1603e0		MOVD R22, R0										
  execution.go:498	0x100214644		aa1303e1		MOVD R19, R1										
  execution.go:498	0x100214648		97f9bbbe		CALL runtime.panicBounds(SB)								
  execution.go:496	0x10021464c		aa1703e0		MOVD R23, R0										
  execution.go:496	0x100214650		aa1303e1		MOVD R19, R1										
  execution.go:496	0x100214654		97f9bbbb		CALL runtime.panicBounds(SB)								
  execution.go:496	0x100214658		aa1603e0		MOVD R22, R0										
  execution.go:496	0x10021465c		aa1303e1		MOVD R19, R1										
  execution.go:496	0x100214660		97f9bbb8		CALL runtime.panicBounds(SB)								
  execution.go:494	0x100214664		aa1703e0		MOVD R23, R0										
  execution.go:494	0x100214668		aa1303e1		MOVD R19, R1										
  execution.go:494	0x10021466c		97f9bbb5		CALL runtime.panicBounds(SB)								
  execution.go:494	0x100214670		aa1603e0		MOVD R22, R0										
  execution.go:494	0x100214674		aa1303e1		MOVD R19, R1										
  execution.go:494	0x100214678		97f9bbb2		CALL runtime.panicBounds(SB)								
  execution.go:492	0x10021467c		aa1703e0		MOVD R23, R0										
  execution.go:492	0x100214680		aa1303e1		MOVD R19, R1										
  execution.go:492	0x100214684		97f9bbaf		CALL runtime.panicBounds(SB)								
  execution.go:492	0x100214688		aa1603e0		MOVD R22, R0										
  execution.go:492	0x10021468c		aa1303e1		MOVD R19, R1										
  execution.go:492	0x100214690		97f9bbac		CALL runtime.panicBounds(SB)								
  execution.go:490	0x100214694		aa1703e0		MOVD R23, R0										
  execution.go:490	0x100214698		aa1303e1		MOVD R19, R1										
  execution.go:490	0x10021469c		97f9bba9		CALL runtime.panicBounds(SB)								
  execution.go:490	0x1002146a0		aa1603e0		MOVD R22, R0										
  execution.go:490	0x1002146a4		aa1303e1		MOVD R19, R1										
  execution.go:490	0x1002146a8		97f9bba6		CALL runtime.panicBounds(SB)								
  execution.go:488	0x1002146ac		aa1703e0		MOVD R23, R0										
  execution.go:488	0x1002146b0		aa1303e1		MOVD R19, R1										
  execution.go:488	0x1002146b4		97f9bba3		CALL runtime.panicBounds(SB)								
  execution.go:488	0x1002146b8		aa1603e0		MOVD R22, R0										
  execution.go:488	0x1002146bc		aa1303e1		MOVD R19, R1										
  execution.go:488	0x1002146c0		97f9bba0		CALL runtime.panicBounds(SB)								
  execution.go:486	0x1002146c4		aa1703e0		MOVD R23, R0										
  execution.go:486	0x1002146c8		aa1303e1		MOVD R19, R1										
  execution.go:486	0x1002146cc		97f9bb9d		CALL runtime.panicBounds(SB)								
  execution.go:486	0x1002146d0		aa1603e0		MOVD R22, R0										
  execution.go:486	0x1002146d4		aa1303e1		MOVD R19, R1										
  execution.go:486	0x1002146d8		97f9bb9a		CALL runtime.panicBounds(SB)								
  execution.go:484	0x1002146dc		aa1703e0		MOVD R23, R0										
  execution.go:484	0x1002146e0		aa1303e1		MOVD R19, R1										
  execution.go:484	0x1002146e4		97f9bb97		CALL runtime.panicBounds(SB)								
  execution.go:484	0x1002146e8		aa1603e0		MOVD R22, R0										
  execution.go:484	0x1002146ec		aa1303e1		MOVD R19, R1										
  execution.go:484	0x1002146f0		97f9bb94		CALL runtime.panicBounds(SB)								
  execution.go:482	0x1002146f4		aa1603e0		MOVD R22, R0										
  execution.go:482	0x1002146f8		aa1303e1		MOVD R19, R1										
  execution.go:482	0x1002146fc		97f9bb91		CALL runtime.panicBounds(SB)								
  execution.go:421	0x100214700		97f9bb90		CALL runtime.panicBounds(SB)								
  execution.go:412	0x100214704		aa1903e0		MOVD R25, R0										
  execution.go:412	0x100214708		aa1703e1		MOVD R23, R1										
  execution.go:412	0x10021470c		97f9bb8d		CALL runtime.panicBounds(SB)								
  execution.go:409	0x100214710		aa1603e0		MOVD R22, R0										
  execution.go:409	0x100214714		aa1303e1		MOVD R19, R1										
  execution.go:409	0x100214718		97f9bb8a		CALL runtime.panicBounds(SB)								
  execution.go:409	0x10021471c		aa1803e0		MOVD R24, R0										
  execution.go:409	0x100214720		aa1703e1		MOVD R23, R1										
  execution.go:409	0x100214724		97f9bb87		CALL runtime.panicBounds(SB)								
  execution.go:406	0x100214728		aa1603e0		MOVD R22, R0										
  execution.go:406	0x10021472c		aa1303e1		MOVD R19, R1										
  execution.go:406	0x100214730		97f9bb84		CALL runtime.panicBounds(SB)								
  execution.go:403	0x100214734		aa1603e0		MOVD R22, R0										
  execution.go:403	0x100214738		aa1303e1		MOVD R19, R1										
  execution.go:403	0x10021473c		97f9bb81		CALL runtime.panicBounds(SB)								
  execution.go:391	0x100214740		aa1803e0		MOVD R24, R0										
  execution.go:391	0x100214744		aa1603e1		MOVD R22, R1										
  execution.go:391	0x100214748		97f9bb7e		CALL runtime.panicBounds(SB)								
  execution.go:389	0x10021474c		aa1803e0		MOVD R24, R0										
  execution.go:389	0x100214750		aa1603e1		MOVD R22, R1										
  execution.go:389	0x100214754		97f9bb7b		CALL runtime.panicBounds(SB)								
  execution.go:385	0x100214758		aa1803e0		MOVD R24, R0										
  execution.go:385	0x10021475c		aa1603e1		MOVD R22, R1										
  execution.go:385	0x100214760		97f9bb78		CALL runtime.panicBounds(SB)								
  execution.go:383	0x100214764		aa1303e0		MOVD R19, R0										
  execution.go:383	0x100214768		97f9bb76		CALL runtime.panicBounds(SB)								
  execution.go:379	0x10021476c		aa1303e0		MOVD R19, R0										
  execution.go:379	0x100214770		97f9bb74		CALL runtime.panicBounds(SB)								
  execution.go:376	0x100214774		aa1303e0		MOVD R19, R0										
  execution.go:376	0x100214778		97f9bb72		CALL runtime.panicBounds(SB)								
  execution.go:459	0x10021477c		aa1903e0		MOVD R25, R0										
  execution.go:459	0x100214780		aa1303e1		MOVD R19, R1										
  execution.go:459	0x100214784		97f9bb6f		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100214788		aa1403e0		MOVD R20, R0										
  execution.go:459	0x10021478c		aa1303e1		MOVD R19, R1										
  execution.go:459	0x100214790		97f9bb6c		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100214794		aa1603e0		MOVD R22, R0										
  execution.go:459	0x100214798		aa1403e1		MOVD R20, R1										
  execution.go:459	0x10021479c		97f9bb69		CALL runtime.panicBounds(SB)								
  execution.go:459	0x1002147a0		aa1903e0		MOVD R25, R0										
  execution.go:459	0x1002147a4		aa1403e1		MOVD R20, R1										
  execution.go:459	0x1002147a8		97f9bb66		CALL runtime.panicBounds(SB)								
  execution.go:439	0x1002147ac		aa1303e0		MOVD R19, R0										
  execution.go:439	0x1002147b0		97f9bb64		CALL runtime.panicBounds(SB)								
  execution.go:439	0x1002147b4		97f9bb63		CALL runtime.panicBounds(SB)								
  execution.go:439	0x1002147b8		aa1a03e0		MOVD R26, R0										
  execution.go:439	0x1002147bc		aa1303e1		MOVD R19, R1										
  execution.go:439	0x1002147c0		97f9bb60		CALL runtime.panicBounds(SB)								
  execution.go:439	0x1002147c4		97f9bb5f		CALL runtime.panicBounds(SB)								
  execution.go:435	0x1002147c8		aa1903e0		MOVD R25, R0										
  execution.go:435	0x1002147cc		aa1303e1		MOVD R19, R1										
  execution.go:435	0x1002147d0		97f9bb5c		CALL runtime.panicBounds(SB)								
  execution.go:435	0x1002147d4		97f9bb5b		CALL runtime.panicBounds(SB)								
  execution.go:435	0x1002147d8		aa1803e0		MOVD R24, R0										
  execution.go:435	0x1002147dc		aa1303e1		MOVD R19, R1										
  execution.go:435	0x1002147e0		97f9bb58		CALL runtime.panicBounds(SB)								
  execution.go:435	0x1002147e4		97f9bb57		CALL runtime.panicBounds(SB)								
  execution.go:434	0x1002147e8		aa1403e0		MOVD R20, R0										
  execution.go:434	0x1002147ec		aa1903e1		MOVD R25, R1										
  execution.go:434	0x1002147f0		97f9bb54		CALL runtime.panicBounds(SB)								
  execution.go:434	0x1002147f4		aa1903e0		MOVD R25, R0										
  execution.go:434	0x1002147f8		aa1803e1		MOVD R24, R1										
  execution.go:434	0x1002147fc		97f9bb51		CALL runtime.panicBounds(SB)								
  execution.go:364	0x100214800		aa1403e0		MOVD R20, R0										
  execution.go:364	0x100214804		aa1003e1		MOVD R16, R1										
  execution.go:364	0x100214808		97f9bb4e		CALL runtime.panicBounds(SB)								
  execution.go:361	0x10021480c		aa1603e0		MOVD R22, R0										
  execution.go:361	0x100214810		aa1303e1		MOVD R19, R1										
  execution.go:361	0x100214814		97f9bb4b		CALL runtime.panicBounds(SB)								
  execution.go:343	0x100214818		aa1803e0		MOVD R24, R0										
  execution.go:343	0x10021481c		aa1603e1		MOVD R22, R1										
  execution.go:343	0x100214820		97f9bb48		CALL runtime.panicBounds(SB)								
  execution.go:341	0x100214824		aa1403e0		MOVD R20, R0										
  execution.go:341	0x100214828		aa1003e1		MOVD R16, R1										
  execution.go:341	0x10021482c		97f9bb45		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100214830		aa1403e0		MOVD R20, R0										
  execution.go:337	0x100214834		97f9bb43		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100214838		aa1403e0		MOVD R20, R0										
  execution.go:337	0x10021483c		aa1103e1		MOVD R17, R1										
  execution.go:337	0x100214840		97f9bb40		CALL runtime.panicBounds(SB)								
  execution.go:797	0x100214844		90001180		ADRP 2293760(PC), R0									
  execution.go:797	0x100214848		9128c000		ADD $2608, R0, R0									
  execution.go:797	0x10021484c		90000fa1		ADRP 2048000(PC), R1									
  execution.go:797	0x100214850		91298021		ADD $2656, R1, R1									
  execution.go:797	0x100214854		97f99fcf		CALL runtime.gopanic(SB)								
  execution.go:797	0x100214858		d503201f		NOOP											
  execution.go:325	0x10021485c		a90087e0		STP (R0, R1), 8(RSP)									
  execution.go:325	0x100214860		aa1e03e3		MOVD R30, R3										
  execution.go:325	0x100214864		97f9b29f		CALL runtime.morestack_noctxt.abi0(SB)							
  execution.go:325	0x100214868		a94087e0		LDP 8(RSP), (R0, R1)									
  execution.go:325	0x10021486c		17fff621		JMP github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB)	
