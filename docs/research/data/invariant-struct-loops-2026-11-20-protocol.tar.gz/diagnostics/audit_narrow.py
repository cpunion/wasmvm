from pathlib import Path
import json,os,subprocess,hashlib
diag=Path(__file__).resolve().parent;root=diag.parent;repo=root.parent.parent;work=repo.with_name('wasmvm-source-cleanup')
env=dict(os.environ,PATH='/opt/homebrew/Cellar/go/1.27.3/libexec/bin:/opt/homebrew/opt/llvm@22/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly',GOMAXPROCS='4',CGO_ENABLED='1',CC='/opt/homebrew/opt/llvm@22/bin/clang')
audit=diag/'kernel-audit-common.go';audit.write_text((root/'kernel-audit.go').read_text().replace('"heapLoops":c.GuardedStructLoops,',''))
records={}
for role,cwd in [('base',repo),('head',work)]:
    overlay=diag/f'{role}-kernel-audit-overlay.json';overlay.write_text(json.dumps(dict(Replace={str(cwd/'cmd/wasmvm/main.go'):str(audit)})))
    prefix=diag/f'{role}-narrow';cmd=['go','run','-overlay',str(overlay),'./cmd/wasmvm',str(cwd/'benchmarks/native/memory-fixtures/narrow-unaligned.wasm'),str(prefix)]
    code=json.loads(subprocess.check_output(cmd,cwd=cwd,env=env,text=True))
    records[role]=dict(command=cmd,revision=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),functions=[dict(bytes=f['codeBytes'],sha256=hashlib.sha256(Path(f['binary']).read_bytes()).hexdigest()) for f in code])
print('Identical native function bytes',records['base']['functions']==records['head']['functions'],records['head']['functions'])
(diag/'narrow-native-code.json').write_text(json.dumps(records,indent=2)+'\n')
