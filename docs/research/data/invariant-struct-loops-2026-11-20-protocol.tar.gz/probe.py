from pathlib import Path
import hashlib,json,os,random,statistics,sys
p=Path(__file__).resolve().parent
w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup')
sys.path.insert(0,str(w/'benchmarks'))
import interleaved
prior=p.parent/'bounded-pure-call-20261120'
plan=json.loads((prior/'core-plan.json').read_text())
cases=[]
for case in plan['cases']:
 f=case['fixture']
 if f['id'] not in ['gc/struct-access','gc/struct-indirect-access']:continue
 cs=case['commands'];base=cs['head-go-native'];head=[str(p/'probe-go'),*base[1:]]
 cases.append((f,dict(base=base,head=head,wasmtime=cs['wasmtime-compiler'])))
frozen={'scope':'Untimed preflight then four fixed local screening blocks, independent of full comparison and acceptance.','blocks':4,'seed':20261120074,'cases':cases,'sha256':{cmd[0]:hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest() for f,cs in cases for cmd in cs.values()}}
(p/'probe-plan.json').write_text(json.dumps(frozen,indent=2)+'\n')
rng=random.Random(frozen['seed']);rows=[]
os.environ.update(GOMAXPROCS='1',GOGC='100')
for i in range(frozen['blocks']):
 for f,cs in cases:
  measurements,_=interleaved.invoke(cs|{k+'-aa':v for k,v in cs.items()},120,rng,samples=7)
  for role,ob in measurements.items():
   v=ob['record'];assert v['warmResults']==[f['expectedChecksum']]*7
   rows.append(dict(block=i,case=f['cohort']+'/'+f['id'],role=role,perIteration=statistics.median(v['warmCallNs'])/f['iterations'],record=v))
(p/'probe-rows.json').write_text(json.dumps(rows,indent=2)+'\n')
for case in sorted({r['case'] for r in rows}):
 print(case,{role:round(statistics.median(r['perIteration'] for r in rows if r['case']==case and r['role'] in [role,role+'-aa']),3) for role in ['base','head','wasmtime']},flush=True)
