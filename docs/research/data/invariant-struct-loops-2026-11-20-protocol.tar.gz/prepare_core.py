from pathlib import Path
import json,sys,hashlib,subprocess,os
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');R=W.parent/'wasmvm';P=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'benchmarks'));sys.path.insert(0,str(W/'benchmarks/native'));import routing_compare,runtime_fixtures
build=json.loads((P/'build.json').read_text());previous=R/'artifacts/ordered-optimizations-20261115';refs=json.loads((previous/'reference-build.json').read_text());runtimes={}
for role in ['base','head']:
 for compiler in ['go','llgo']:
  row=build['builds'][role+'-'+compiler+'-phase']
  for backend in ['native','interpreter']:
   runtimes[role+'-'+compiler+'-'+backend]=dict(binary=row['binary'],backend=backend,mode='api',source=row['source'],compiler='go1.27.3' if compiler=='go' else '3c6b33ecc62036b69605fa6492f27f97f858e47a')
for name,backend in [('wazero','compiler'),('wazero','interpreter'),('wasmtime','compiler'),('wasmer','compiler')]:
 binary=Path(refs[name]['command'][refs[name]['command'].index('-o')+1]);assert hashlib.sha256(binary.read_bytes()).hexdigest()==refs[name]['sha256'];runtimes[name+'-'+backend]=dict(binary=str(binary),backend=backend)
for backend in ['interpreter','compiler']:
 runtimes['wasmedge-'+backend]=dict(binary=str(R/'artifacts/pr200-complete-comparison-20261117'/('wasmedge-'+backend)),backend=backend)
fixtures=[]
for f in routing_compare.fixtures(W):fixtures.append(dict(f,cohort='original22-v1'))
for f in list(fixtures):
 if f['family']=='gc':fixtures.append(dict(routing_compare.measurement_fixture(W,f,sustained_gc=True),cohort='gc-sustained-v1'))
 if f['family']=='threads':fixtures.append(dict(routing_compare.measurement_fixture(W,f,sustained_threads=True),cohort='threads-sustained-v2'))
path=R/'artifacts/protocol-cost-20261112/native-frame-deltas-20261114/generic-calls.wasm';count=5000000;seed=17
fixtures.append(dict(id='core/generic-calls',cohort='generic-calls-v1',path=str(path),wasmSha256=hashlib.sha256(path.read_bytes()).hexdigest(),iterations=count,seed=seed,expectedChecksum=runtime_fixtures.checksum('nested-calls',seed,count*2),family='core',unit='ns/source iteration'))
plans=[]
for f in fixtures:
 commands={}
 for name,runtime in runtimes.items():
  cmd=[runtime['binary'],'--backend',runtime['backend'],'--wasm',f['path'],'--iterations',str(f['iterations']),'--seed',str(f['seed']),'--expected',str(f['expectedChecksum']),'--samples','7','--warmups','2']
  if runtime.get('mode'):cmd+=['--mode',runtime['mode']]
  commands[name]=cmd
 kind=f['id'].split('/')[-1]
 if f['id']=='core/generic-calls':cmd=[str(R/'artifacts/protocol-cost-20261112/transitive-leaves/native-llvm-control'),str(count*2),str(seed),str(f['expectedChecksum'])]
 elif f['family']=='application':cmd=[str(previous/'native-sha'),str(f['seed']),str(f['iterations']),str(f['expectedChecksum'])]
 elif kind in ['integer-loop','function-calls','memory-load-store','narrow-unaligned','dependent-address','float64-unaligned','simd-memory-full','simd-memory-widen','simd-memory-lanes']:cmd=[str(previous/'native-scalar'),kind,str(f['seed']),str(f['iterations']),str(f['expectedChecksum'])]
 else:cmd=None
 if cmd:commands['native-c']=cmd
 plans.append(dict(fixture=f,commands=commands,statistic='mean-including-pauses'if f['id']=='gc/struct-allocation'else'median'))
assert len(plans)==33,len(plans)
files={cmd[0]for case in plans for cmd in case['commands'].values()};hashes={name:hashlib.sha256(Path(name).read_bytes()).hexdigest()for name in sorted(files)}
qualification=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();subprocess.run(['git','diff','--exit-code',build['head'],qualification,'--','internal','pkg','cmd','go.mod','go.sum',':(exclude)*_test.go'],cwd=W,check=True)
plan=dict(blocks=6,samples=7,warmups=2,randomSeed=202611210101,base=build['base'],head=build['head'],qualificationHead=qualification,runtimes=runtimes,binarySHA256=hashes,cases=plans,scope='Invariant struct loop complete fresh event: original22 plus four sustained GC, six sustained Threads and generic calls. Six fixed blocks, seven warm samples, two warmups, symmetric same-binary AA for every supported participant. Go/LLGo interpreter/native; wazero both, Wasmtime/Wasmer Cranelift, WasmEdge interpreter and O3 AOT. Native C unchecked oracles separate. Source base/head use common LLGo3c6b33ec O3/fullLTO/defaultGC. Compile/validate/instantiate/first/warm phases separate with no subtraction. Check every result. No owned builds/tests/profiles/analysis/edits/pruning during timing; no extension or pooling; external desktop load recorded. Reused binary identities and engine-source equivalence are verified in build.json.')
(P/'core-plan.json').write_text(json.dumps(plan,indent=2)+'\n');print('Prepared',len(plans),'cases and',len(runtimes),'runtimes; no timing started.')
