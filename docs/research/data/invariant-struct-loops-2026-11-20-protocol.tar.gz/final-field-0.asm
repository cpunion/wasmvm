	stp	x29, x30, [sp, #-16]!
	mov	x29, sp
	stp	x19, x20, [sp, #-16]!
	stp	x21, x22, [sp, #-16]!
	stp	x23, x24, [sp, #-16]!
	stp	x25, x26, [sp, #-16]!
	stp	x27, x28, [sp, #-16]!
	stp	q8, q9, [sp, #-32]!
	stp	q10, q11, [sp, #-32]!
	stp	q12, q13, [sp, #-32]!
	stp	q14, q15, [sp, #-32]!
	ldr	x12, [x0, #8]
	ldr	x13, [x0, #32]
	ldr	x9, [x0, #16]
	sub	x9, x9, x13
	mov	w10, #128                       // =0x80
	cmp	x9, x10
	b.lo	#1560
	and	x9, x13, #0xf
	cmp	x9, #0
	b.ne	#1548
	add	x12, x12, x13
	mov	w9, #0                          // =0x0
	str	x9, [x0, #72]
	ldr	x9, [x0, #56]
	mov	w10, #26                        // =0x1a
	cmp	x9, x10
	b.hs	#1520
	ldr	x9, [x0, #128]
	cmp	x9, #0
	b.eq	#1508
	ldr	x9, [x0, #56]
	mov	w5, #26125                      // =0x660d
	movk	w5, #25, lsl #16
	mov	w6, #62303                      // =0xf35f
	movk	w6, #15470, lsl #16
	ldr	x9, [x0, #128]
	cmp	x9, #0
	b.eq	#28
	mov	x11, x9
	ldr	x9, [x11, #8]
	mov	x1, x9
	ldr	x9, [x11, #16]
	mov	x2, x9
	b	#12
	mov	w1, #0                          // =0x0
	mov	w2, #0                          // =0x0
	mov	w3, #0                          // =0x0
	ldr	x19, [x12, #96]
	ldr	x20, [x12]
	ldr	x21, [x12, #32]
	ldr	x22, [x12, #48]
	ldr	x23, [x12, #112]
	ldr	x24, [x12, #64]
	ldr	x25, [x12, #16]
	ldr	x26, [x12, #80]
	ldr	x9, [x0, #136]
	cmp	x9, #0
	b.ne	#1396
	ldr	x9, [x0, #56]
	adr	x13, #16
	ldrsw	x14, [x13, x9, lsl #2]
	add	x13, x13, x14
	br	x13
	udf	#104
	udf	#112
	udf	#340
	udf	#344
	udf	#356
	udf	#420
	udf	#556
	udf	#560
	udf	#568
	udf	#576
	udf	#584
	udf	#592
	udf	#672
	udf	#676
	udf	#756
	udf	#764
	udf	#768
	udf	#776
	udf	#784
	udf	#792
	udf	#796
	udf	#800
	udf	#812
	udf	#528
	udf	#528
	udf	#544
	ldr	x9, [x0, #144]
	cbnz	x9, #724
	ldr	x11, [x0, #128]
	ldr	x11, [x11, #24]
	cbz	x11, #156
	ldr	x9, [x11]
	ldr	x10, [x11, #8]
	cmp	x9, x10
	b.hs	#140
	ldr	x13, [x11, #32]
	adds	x14, x13, #4
	b.hs	#128
	ldr	x10, [x11, #40]
	cmp	x14, x10
	b.hi	#116
	ldr	x9, [x11, #48]
	cmp	x9, #68
	b.lo	#104
	str	x14, [x11, #32]
	sub	x9, x9, #68
	str	x9, [x11, #48]
	ldr	x9, [x11]
	ldr	x10, [x11, #16]
	ldr	x15, [x10, x9, lsl #3]
	ldr	x10, [x11, #56]
	mov	w14, w15
	add	x14, x10, x14, lsl #5
	str	x15, [x14]
	ldr	x9, [x11, #24]
	add	x13, x9, x13
	str	x13, [x14, #8]
	mov	w9, #1                          // =0x1
	str	x9, [x14, #16]
	mov	w9, #0                          // =0x0
	str	x9, [x14, #24]
	mov	x9, x20
	str	w9, [x13]
	ldr	x9, [x14]
	mov	x26, x9
	ldr	x9, [x11]
	add	x9, x9, #1
	str	x9, [x11]
	b	#68
	mov	w9, #46                         // =0x2e
	str	x9, [x0, #64]
	mov	w9, #2                          // =0x2
	str	x9, [x0, #56]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #9                          // =0x9
	b	#1140
	mov	x22, x26
	ldr	x9, [x0, #144]
	cbnz	x9, #544
	b	#68
	ldr	x9, [x0, #144]
	cbnz	x9, #592
	mov	w9, #4                          // =0x4
	str	x9, [x0, #56]
	mov	w9, #4                          // =0x4
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #1                          // =0x1
	b	#1060
	mov	x9, x22
	cmp	x9, #0
	b.eq	#400
	mov	x10, x1
	mov	w11, w9
	cmp	x11, x10
	b.hs	#384
	mov	x10, x2
	add	x11, x10, x11, lsl #5
	ldr	x10, [x11]
	cmp	x9, x10
	b.ne	#364
	ldr	x11, [x11, #8]
	mov	x4, x11
	mov	x3, x9
	mov	x23, x6
	madd	w19, w20, w5, w6
	str	w19, [x4]
	mov	x20, x19
	add	w21, w21, #1
	ldr	x9, [x0, #144]
	cbnz	x9, #508
	cmp	w21, w25
	b.lo	#-32
	mov	w9, #0                          // =0x0
	mov	x19, x9
	b	#20
	ldr	x9, [x0, #144]
	cbnz	x9, #548
	mov	x24, x20
	b	#-184
	ldr	x9, [x0, #144]
	cbnz	x9, #592
	b	#-24
	b	#4
	mov	x19, x5
	b	#4
	mul	w19, w20, w19
	b	#4
	mov	x23, x6
	b	#4
	add	w19, w19, w23
	b	#4
	cmp	x22, #0
	ccmp	x22, x3, #0, ne
	b.eq	#64
	mov	x9, x22
	cmp	x9, #0
	b.eq	#648
	mov	x10, x1
	mov	w11, w9
	cmp	x11, x10
	b.hs	#744
	mov	x10, x2
	add	x11, x10, x11, lsl #5
	ldr	x10, [x11]
	cmp	x9, x10
	b.ne	#724
	ldr	x11, [x11, #8]
	mov	x4, x11
	mov	x3, x9
	str	w19, [x4]
	b	#4
	b	#4
	cmp	x22, #0
	ccmp	x22, x3, #0, ne
	b.eq	#64
	mov	x9, x22
	cmp	x9, #0
	b.eq	#620
	mov	x10, x1
	mov	w11, w9
	cmp	x11, x10
	b.hs	#660
	mov	x10, x2
	add	x11, x10, x11, lsl #5
	ldr	x10, [x11]
	cmp	x9, x10
	b.ne	#640
	ldr	x11, [x11, #8]
	mov	x4, x11
	mov	x3, x9
	ldr	w19, [x4]
	b	#4
	mov	x20, x19
	b	#4
	b	#4
	mov	w19, #1                         // =0x1
	b	#4
	add	w19, w21, w19
	b	#4
	mov	x21, x19
	b	#4
	b	#4
	b	#4
	cmp	w21, w25
	cset	w19, lo
	b	#4
	ldr	x9, [x0, #144]
	cbnz	x9, #384
	cbnz	w19, #-400
	b	#-280
	b	#-272
	dmb	ishld
	mov	w9, #0                          // =0x0
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#588
	dmb	ishld
	mov	w9, #3                          // =0x3
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#528
	dmb	ishld
	mov	w9, #4                          // =0x4
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#468
	dmb	ishld
	cmp	w21, w25
	cset	w19, lo
	mov	w9, #22                         // =0x16
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#400
	dmb	ishld
	mov	w9, #24                         // =0x18
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#340
	dmb	ishld
	mov	w9, #25                         // =0x19
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#280
	dmb	ishld
	mov	w9, #22                         // =0x16
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #6                          // =0x6
	b	#220
	mov	w9, #70                         // =0x46
	str	x9, [x0, #64]
	mov	w9, #9                          // =0x9
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #2                          // =0x2
	b	#164
	mov	w9, #76                         // =0x4c
	str	x9, [x0, #64]
	mov	w9, #9                          // =0x9
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #2                          // =0x2
	b	#108
	mov	w0, #11                         // =0xb
	b	#100
	mov	w9, #7                          // =0x7
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #2                          // =0x2
	b	#52
	mov	w9, #6                          // =0x6
	str	x9, [x0, #112]
	str	x19, [x12, #96]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #112]
	str	x24, [x12, #64]
	str	x25, [x12, #16]
	str	x26, [x12, #80]
	mov	w0, #2                          // =0x2
	b	#4
	ldp	q14, q15, [sp], #32
	ldp	q12, q13, [sp], #32
	ldp	q10, q11, [sp], #32
	ldp	q8, q9, [sp], #32
	ldp	x27, x28, [sp], #16
	ldp	x25, x26, [sp], #16
	ldp	x23, x24, [sp], #16
	ldp	x21, x22, [sp], #16
	ldp	x19, x20, [sp], #16
	ldp	x29, x30, [sp], #16
	ret
