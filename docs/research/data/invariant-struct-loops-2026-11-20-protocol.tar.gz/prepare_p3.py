from pathlib import Path
import json,hashlib,subprocess
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');R=W.parent/'wasmvm';P=Path(__file__).resolve().parent
build=json.loads((P/'build.json').read_text());template=(R/'artifacts/canonical-invocation-frames-20261116/p3-go-16/measure.py').read_text();prefix=template[:template.index('import hashlib,time,signal,gzip')];body=template[template.index("plan['binarySHA256']"):]
sha=lambda name:hashlib.sha256(Path(name).read_bytes()).hexdigest()
variants={name[:-3]:row['binary']for name,row in build['builds'].items()if name.endswith('-p3') and not name.startswith('old-sdk-')}
variants['wasmtime']=str(R/'artifacts/protocol-cost-20261112/output-screen/wasmtime-go-runner');variants['native-go']=build['builds']['head-go-p3']['binary']
for size in [16,65536]:
 folder=P/('p3-'+str(size));folder.mkdir(exist_ok=False)
 plan=dict(blocks=6,samples=20,batchRequests=512,seed=202611210200+size,payloadBytes=size,hostCompiler='mixed',variants=variants,sourceBase=build['base'],sourceHead=build['head'],qualificationHead=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),scope='Source baseline event using a common SDK. Six roles with symmetric AA, six fixed fresh-process blocks, four workers/sixteen clients/twenty interleaved512-request windows plus a separate flush. Verify complete status/headers/body/trailers/CRC and guest join. Default production GC. CPU/instructions include complete driver and reply checks. Startup/setup/first/warmups/cleanup separate. Managed allocations omit foreign Rust/C/JIT allocation and cannot rank total allocation. Native-Go implements equivalent HTTP replies without Component/WASI and is only a host overhead oracle. No owned builds/tests/profiles/analysis/edits/pruning during timed cohorts, no extension or pooling. External load snapshots and AA qualify conclusions.')
 code=prefix+'import hashlib,time,signal,gzip\nvariants='+repr(variants)+'\nplan='+repr(plan)+'\n'+body
 start=code.index("   reference=name=='wasmtime';cmd=");end=code.index("   env=dict(os.environ",start)
 code=code[:start]+"""   reference=name=='wasmtime';native=name=='native-go'
   cmd=[str(variants[name]),'--engine','wasmtime'if reference else'native-go'if native else'wasmvm','--backend','compiler'if reference else'host'if native else'native']
   if not native:cmd+=['--wasm',str(ROOT/'pkg/wasi/preview3/testdata/world-rust-http.wasm')]
   cmd+=['--payload-bytes',str(plan['payloadBytes']),'--expected',str(1757737011 if plan['payloadBytes']==16 else 2629362236),'--workers','4','--clients','16','--requests','32','--samples','21','--warmups','2']
   if not reference and not native:cmd+=['--response-mode','buffered','--request-mode','snapshot']
"""+code[end:]
 code=code.replace("   err=(OUT/f'{block}-{name}{alias}.stderr')", "   spawnStart=time.perf_counter_ns();err=(OUT/f'{block}-{name}{alias}.stderr')")
 code=code.replace("assert json.loads(p.stdout.readline())=={'ready':True};p.stdin.write", "assert json.loads(p.stdout.readline())=={'ready':True};child['startupNs']=time.perf_counter_ns()-spawnStart;prepareStart=time.perf_counter_ns();p.stdin.write")
 code=code.replace("assert json.loads(p.stdout.readline())=={'sampleReady':0};time.sleep", "assert json.loads(p.stdout.readline())=={'sampleReady':0};child['prepareAndWarmupsNs']=time.perf_counter_ns()-prepareStart;time.sleep")
 code=code.replace("('llgo' if plan['hostCompiler']=='llgo' and c['id'].removesuffix('-aa') in ('base','head') else 'gc')", "('llgo' if 'llgo' in c['id'] else 'gc')")
 code=code.replace("row=dict(block=block,id=c['id'],command=c['command']", "row=dict(block=block,id=c['id'],startupNs=c['startupNs'],prepareAndWarmupsNs=c['prepareAndWarmupsNs'],command=c['command']")
 (folder/'measure.py').write_text(code)
 frozen=dict(plan,binarySHA256={k:sha(v)for k,v in variants.items()},fixtureSHA256=sha(R/'pkg/wasi/preview3/testdata/world-rust-http.wasm'))
 (folder/'frozen-plan.json').write_text(json.dumps(frozen,indent=2)+'\n')
print('Prepared two combined P3 payload cohorts; no timing started.')
