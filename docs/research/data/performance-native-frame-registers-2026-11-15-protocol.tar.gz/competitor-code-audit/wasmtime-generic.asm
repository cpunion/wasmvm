
/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-direct-resume-20261114/competitor-code-audit/wasmtime-generic.cwasm:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <wasm[0]::function[0]>:
       0:      	pacibz
       4:      	stp	x29, x30, [sp, #-0x10]!
       8:      	mov	x29, sp
       c:      	mov	w3, #0x0                // =0
      10:      	add	w3, w3, #0x1
      14:      	mov	w11, #0x660d            // =26125
      18:      	movk	w11, #0x19, lsl #16
      1c:      	mov	w12, #0xf35f            // =62303
      20:      	movk	w12, #0x3c6e, lsl #16
      24:      	madd	w2, w4, w11, w12
      28:      	cmp	w3, #0x2
      2c:      	b.hs	0x38 <wasm[0]::function[0]+0x38>
      30:      	mov	x4, x2
      34:      	b	0x10 <wasm[0]::function[0]+0x10>
      38:      	ldp	x29, x30, [sp], #0x10
      3c:      	autibz
      40:      	ret
		...

0000000000000060 <wasm[0]::function[1]>:
      60:      	pacibz
      64:      	stp	x29, x30, [sp, #-0x10]!
      68:      	mov	x29, sp
      6c:      	ldur	x16, [x2, #0x8]
      70:      	ldur	x16, [x16, #0x18]
      74:      	add	x16, x16, #0x30
      78:      	cmp	sp, x16
      7c:      	b.lo	0xd0 <wasm[0]::function[1]+0x70>
      80:      	str	x21, [sp, #-0x10]!
      84:      	stp	x19, x20, [sp, #-0x10]!
      88:      	mov	x20, x5
      8c:      	mov	x21, x2
      90:      	mov	w19, #0x0               // =0
      94:      	mov	x2, x21
      98:      	mov	x3, x21
      9c:      	bl	0x0 <wasm[0]::function[0]>
      a0:      	add	w19, w19, #0x1
      a4:      	mov	x5, x20
      a8:      	cmp	w19, w5
      ac:      	b.hs	0xbc <wasm[0]::function[1]+0x5c>
      b0:      	mov	x4, x2
      b4:      	mov	x20, x5
      b8:      	b	0x94 <wasm[0]::function[1]+0x34>
      bc:      	ldp	x19, x20, [sp], #0x10
      c0:      	ldr	x21, [sp], #0x10
      c4:      	ldp	x29, x30, [sp], #0x10
      c8:      	autibz
      cc:      	ret
      d0:      	udf	#0xc11f

00000000000000d4 <wasm[0]::array_to_wasm_trampoline[1]>:
      d4:      	pacibsp
      d8:      	stp	x29, x30, [sp, #-0x10]!
      dc:      	mov	x29, sp
      e0:      	stp	x27, x28, [sp, #-0x10]!
      e4:      	stp	x25, x26, [sp, #-0x10]!
      e8:      	stp	x23, x24, [sp, #-0x10]!
      ec:      	stp	x21, x22, [sp, #-0x10]!
      f0:      	stp	x19, x20, [sp, #-0x10]!
      f4:      	stp	d14, d15, [sp, #-0x10]!
      f8:      	stp	d12, d13, [sp, #-0x10]!
      fc:      	stp	d10, d11, [sp, #-0x10]!
     100:      	stp	d8, d9, [sp, #-0x10]!
     104:      	sub	sp, sp, #0x10
     108:      	ldr	w4, [x2]
     10c:      	ldr	w5, [x2, #0x10]
     110:      	stur	x2, [sp]
     114:      	mov	x3, x29
     118:      	ldr	x6, [x0, #0x8]
     11c:      	str	x3, [x6, #0x48]
     120:      	mov	x3, sp
     124:      	str	x3, [x6, #0x40]
     128:      	adr	x3, 0x17c <wasm[0]::array_to_wasm_trampoline[1]+0xa8>
     12c:      	str	x3, [x6, #0x50]
     130:      	mov	x2, x0
     134:      	mov	x3, x1
     138:      	stur	x6, [sp, #0x8]
     13c:      	bl	0x60 <wasm[0]::function[1]>
     140:      	ldur	x0, [sp]
     144:      	str	w2, [x0]
     148:      	mov	w0, #0x1                // =1
     14c:      	add	sp, sp, #0x10
     150:      	ldp	d8, d9, [sp], #0x10
     154:      	ldp	d10, d11, [sp], #0x10
     158:      	ldp	d12, d13, [sp], #0x10
     15c:      	ldp	d14, d15, [sp], #0x10
     160:      	ldp	x19, x20, [sp], #0x10
     164:      	ldp	x21, x22, [sp], #0x10
     168:      	ldp	x23, x24, [sp], #0x10
     16c:      	ldp	x25, x26, [sp], #0x10
     170:      	ldp	x27, x28, [sp], #0x10
     174:      	ldp	x29, x30, [sp], #0x10
     178:      	retab
     17c:      	mov	x0, #0x1                // =1
     180:      	ldur	x6, [sp, #0x8]
     184:      	str	x0, [x6, #0x88]
     188:      	mov	w0, #0x0                // =0
     18c:      	add	sp, sp, #0x10
     190:      	ldp	d8, d9, [sp], #0x10
     194:      	ldp	d10, d11, [sp], #0x10
     198:      	ldp	d12, d13, [sp], #0x10
     19c:      	ldp	d14, d15, [sp], #0x10
     1a0:      	ldp	x19, x20, [sp], #0x10
     1a4:      	ldp	x21, x22, [sp], #0x10
     1a8:      	ldp	x23, x24, [sp], #0x10
     1ac:      	ldp	x25, x26, [sp], #0x10
     1b0:      	ldp	x27, x28, [sp], #0x10
     1b4:      	ldp	x29, x30, [sp], #0x10
     1b8:      	retab

00000000000001bc <signatures[0]::wasm_to_array_trampoline>:
     1bc:      	pacibz
     1c0:      	stp	x29, x30, [sp, #-0x10]!
     1c4:      	mov	x29, sp
     1c8:      	str	x19, [sp, #-0x10]!
     1cc:      	sub	sp, sp, #0x10
     1d0:      	mov	x1, x2
     1d4:      	mov	x19, x3
     1d8:      	mov	x14, x29
     1dc:      	ldr	x13, [x3, #0x8]
     1e0:      	str	x14, [x13, #0x30]
     1e4:      	ldur	x30, [x29, #0x8]
     1e8:      	xpaclri
     1ec:      	mov	x0, x30
     1f0:      	str	x0, [x13, #0x38]
     1f4:      	mov	x2, sp
     1f8:      	stur	w4, [sp]
     1fc:      	mov	x0, x1
     200:      	ldr	x4, [x0, #0x8]
     204:      	mov	x3, #0x1                // =1
     208:      	mov	x1, x19
     20c:      	blr	x4
     210:      	tst	w0, #0xff
     214:      	b.eq	0x230 <signatures[0]::wasm_to_array_trampoline+0x74>
     218:      	ldur	w2, [sp]
     21c:      	add	sp, sp, #0x10
     220:      	ldr	x19, [sp], #0x10
     224:      	ldp	x29, x30, [sp], #0x10
     228:      	autibz
     22c:      	ret
     230:      	mov	x3, x19
     234:      	ldr	x0, [x3, #0x10]
     238:      	ldr	x1, [x0, #0x148]
     23c:      	mov	x0, x3
     240:      	blr	x1
     244:      	udf	#0xc11f

0000000000000248 <signatures[1]::wasm_to_array_trampoline>:
     248:      	pacibz
     24c:      	stp	x29, x30, [sp, #-0x10]!
     250:      	mov	x29, sp
     254:      	str	x19, [sp, #-0x10]!
     258:      	sub	sp, sp, #0x20
     25c:      	mov	x1, x2
     260:      	mov	x19, x3
     264:      	mov	x15, x29
     268:      	ldr	x14, [x3, #0x8]
     26c:      	str	x15, [x14, #0x30]
     270:      	ldur	x30, [x29, #0x8]
     274:      	xpaclri
     278:      	mov	x0, x30
     27c:      	str	x0, [x14, #0x38]
     280:      	mov	x2, sp
     284:      	stur	w4, [sp]
     288:      	stur	w5, [sp, #0x10]
     28c:      	mov	x0, x1
     290:      	ldr	x4, [x0, #0x8]
     294:      	mov	x3, #0x2                // =2
     298:      	mov	x1, x19
     29c:      	blr	x4
     2a0:      	tst	w0, #0xff
     2a4:      	b.eq	0x2c0 <signatures[1]::wasm_to_array_trampoline+0x78>
     2a8:      	ldur	w2, [sp]
     2ac:      	add	sp, sp, #0x20
     2b0:      	ldr	x19, [sp], #0x10
     2b4:      	ldp	x29, x30, [sp], #0x10
     2b8:      	autibz
     2bc:      	ret
     2c0:      	mov	x3, x19
     2c4:      	ldr	x0, [x3, #0x10]
     2c8:      	ldr	x1, [x0, #0x148]
     2cc:      	mov	x0, x3
     2d0:      	blr	x1
     2d4:      	udf	#0xc11f
		...
