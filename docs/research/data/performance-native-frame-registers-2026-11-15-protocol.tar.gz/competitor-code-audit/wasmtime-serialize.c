#include <wasmtime.h>
#include <stdio.h>
#include <stdlib.h>
static void check(wasmtime_error_t *error) {
  if (!error) return;
  wasm_byte_vec_t message;
  wasmtime_error_message(error, &message);
  fprintf(stderr, "%.*s\n", (int)message.size, message.data);
  exit(1);
}
int main(int argc, char **argv) {
  if (argc != 3) return 2;
  FILE *input = fopen(argv[1], "rb");
  if (!input || fseek(input, 0, SEEK_END)) return 3;
  long size = ftell(input);
  if (size <= 0 || fseek(input, 0, SEEK_SET)) return 4;
  unsigned char *bytes = malloc((size_t)size);
  if (!bytes || fread(bytes, 1, (size_t)size, input) != (size_t)size) return 5;
  fclose(input);
  wasm_config_t *config = wasm_config_new();
  wasmtime_config_strategy_set(config, WASMTIME_STRATEGY_CRANELIFT);
  wasmtime_config_cranelift_opt_level_set(config, WASMTIME_OPT_LEVEL_SPEED);
  wasm_engine_t *engine = wasm_engine_new_with_config(config);
  wasmtime_module_t *module = NULL;
  check(wasmtime_module_new(engine, bytes, (size_t)size, &module));
  wasm_byte_vec_t image;
  check(wasmtime_module_serialize(module, &image));
  FILE *output = fopen(argv[2], "wb");
  if (!output || fwrite(image.data, 1, image.size, output) != image.size || fclose(output)) return 6;
  printf("Serialized %zu bytes\n", image.size);
  wasm_byte_vec_delete(&image);
  wasmtime_module_delete(module);
  wasm_engine_delete(engine);
  free(bytes);
  return 0;
}
