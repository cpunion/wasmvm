from pathlib import Path
import gzip,hashlib,json,statistics,subprocess,tarfile
D=Path(__file__).resolve().parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');name='performance-native-frame-registers-2026-11-15'
cohorts=['counter-screen','p3-screen-16','p3-screen-65536','counter-final','core-final','final-16','final-65536','no-gc-16','no-gc-65536']
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def project(v):
 if isinstance(v,list):return[project(x)for x in v]
 if not isinstance(v,dict):return v
 return{k:(dict(count=len(x),minimum=min(x)if x else None,maximum=max(x)if x else None,canonicalJSONSHA256=hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest())if k in('RequestNs','PublicAPINs')and isinstance(x,list)else project(x))for k,x in v.items()}
evidence=W/'docs/research/evidence'/f'{name}.jsonl.gz';counts={};gc={}
with gzip.open(evidence,'wt',compresslevel=9)as output:
 for folder in cohorts:
  p=D/folder;compressed=p/'rows.jsonl.gz'
  with(gzip.open(compressed,'rt')if compressed.exists()else(p/'rows.jsonl').open())as stream:rows=[json.loads(l)for l in stream]
  counts[folder]=len(rows)
  for row in rows:output.write(json.dumps(dict(cohort=folder,**project(row)),separators=(',',':'))+'\n')
  if 'service'not in rows[0].get('record',{}):continue
  gc[folder]={};end=8 if folder.startswith('no-gc')else 23
  for role in sorted({r['id']for r in rows if not r['id'].endswith('-aa')}):
   rr=[r for r in rows if r['id']in(role,role+'-aa')];cc=[sum(b['GCAfter']-b['GCBefore']for b in r['record']['service']['Batches'][3:end])for r in rr];heaps=[r['record']['service']['Batches'][3]['HeapBefore']for r in rr];buckets={}
   for row,n in zip(rr,cc):buckets.setdefault(n,[]).append(row['cpuUs'])
   gc[folder][role]=dict(collectionsMedian=statistics.median(cc),collectionsRange=[min(cc),max(cc)],initialHeapMedian=statistics.median(heaps),cpuUsByCollectionCount={k:dict(processes=len(v),median=statistics.median(v))for k,v in sorted(buckets.items())})
assert sum(counts.values())==600,counts
protocol=W/'docs/research/data'/f'{name}-protocol.tar.gz'
with tarfile.open(protocol,'w:gz')as archive:
 for p in sorted(D.rglob('*')):
  if p.is_file()and p.suffix in('.go','.py','.json','.log','.txt'):archive.add(p,arcname=D.name+'/'+str(p.relative_to(D)))
 fixture=D.parent/'native-frame-deltas-20261114/generic-calls.wasm';archive.add(fixture,arcname='fixtures/'+fixture.name)
 audit=D.parent/'native-direct-resume-20261114/competitor-code-audit'
 for p in sorted(audit.iterdir()):
  if p.is_file()and p.suffix in('.c','.asm','.json','.cwasm'):archive.add(p,arcname='competitor-code-audit/'+p.name)
identity=read(D/'committed-identity.json')
report=dict(base=identity['base'],source=identity['head'],sourceTree=subprocess.check_output(['git','rev-parse',identity['head']+'^{tree}'],cwd=W,text=True).strip(),identityQualification='All production changes are frozen in seven-file symmetric Git overlays. Later report-only commits must retain this runtime. Prototype files and binaries remain distinct.',host='Apple M4 Max, darwin/arm64; independent user compiler/link and desktop activity observed, retained load snapshots and same-binary controls qualify claims.',profile=identity['toolchains'],productionGC='Default for every production event; GC_DONT_GC=1 only in two bounded separately labeled diagnostic cohorts.',references=dict(wazero='1.12.0',wasmtime='48.0.1',wasmer='7.3.0',nativeC='Frozen unchecked LLVM22 affine oracle, 2N steps normalized per guest iteration, without VM limits/cancellation/frame contract.'),identity=identity,comparisons=read(D/'analysis.json'),GCObservations=gc,validation=dict(Go='32 root test packages pass; all 31 measured executable packages >=90% statement coverage.',LLGo='Affected codegen/nativeexec tests execute with -O3 -lto=full. Complete Go/LLGo x Linux amd64/macOS arm64 CI required on final head before merge.',cases='Large frames beyond ARM immediate offsets, ordinary/invalid entries and state publication, register inventory, full existing value/root/cancellation/host-reentry/quotas/proposals suites.'),interpretation='General native-call Go CPU improves 11.16%; complete P3 Go CPU is nearly unchanged. LLGo normal64KiB P3 adverse point retained; zero-GC instruction reduction and CPU intervals crossing parity isolate collection work as a material contribution, without resolving cold heap sizing versus conservative roots. All unresolved controls and cold points remain advisory; no competitive parity or release acceptance.',evidence=dict(path='../evidence/'+evidence.name,records=sum(counts.values()),cohorts=counts,sha256=digest(evidence),projection='Only unused RequestNs/PublicAPINs vectors become count/extrema/canonical-JSON SHA256. Full originals retained locally. Every process result, phase, rusage, GC/allocation counter, output and order remains.'),protocol=dict(path=protocol.name,sha256=digest(protocol)))
p=W/'docs/research/data'/f'{name}.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(records=sum(counts.values()),reportBytes=p.stat().st_size,evidenceBytes=evidence.stat().st_size,protocolBytes=protocol.stat().st_size),indent=2))
