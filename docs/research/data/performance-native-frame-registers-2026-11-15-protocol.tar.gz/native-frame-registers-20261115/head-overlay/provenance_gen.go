package phase
func init(){sourceRevision="798e544305164684371449dc33a9ece80f957669+frame-registers-prototype";compilerRevision="go1.27.3"}
