from pathlib import Path
import hashlib,json,os,subprocess,time
D=Path(__file__).resolve().parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup')
base='798e544305164684371449dc33a9ece80f957669';head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
files=[p for p in subprocess.check_output(['git','diff','--name-only',base,head],cwd=W,text=True).splitlines()if p.endswith('.go')and not p.endswith('_test.go')]
assert len(files)==7,files
env=dict(os.environ,PATH='/opt/homebrew/Cellar/go/1.27.3/libexec/bin:/opt/homebrew/opt/llvm@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly',GOMAXPROCS='4',CGO_ENABLED='1',CC='/opt/homebrew/opt/llvm@22/bin/clang',LLGO_ROOT='/Users/lijie/source/goplus/llgo-external-link-options')
llgo='/Users/lijie/source/goplus/wasmvm/artifacts/components/llgo-6a482f7f';records=[];ident=dict(base=base,head=head,productionFiles=files,toolchains=dict(go='go1.27.3',llgo='6a482f7f6ad94e9f2d0a0fea97dd4cabd46b1130',llvm='22.1.8',llgoFlags=['-O3','-lto=full']),overlays={})
for compiler,exe in [('go','go'),('llgo',llgo)]:
 for role,rev in [('base',base),('head',head)]:
  p=D/f'{role}-{compiler}-committed-overlay';p.mkdir(exist_ok=True);mapping={};hashes={}
  for f in files:
   out=subprocess.run(['git','show',rev+':'+f],cwd=W,capture_output=True)
   if out.returncode:
    assert role=='base'and f.endswith('/call_state.go');mapping[str(W/f)]='';continue
   dest=p/Path(f).name;dest.write_bytes(out.stdout);mapping[str(W/f)]=str(dest);hashes[f]=hashlib.sha256(out.stdout).hexdigest()
  provenance=p/'provenance_gen.go';crev='go1.27.3'if compiler=='go'else env['LLGO_ROOT']
  if compiler=='llgo':crev='6a482f7f6ad94e9f2d0a0fea97dd4cabd46b1130'
  provenance.write_text('package phase\nfunc init(){sourceRevision="'+rev+'";compilerRevision="'+crev+'"}\n');mapping[str(W/'internal/bench/phase/provenance_gen.go')]=str(provenance)
  overlay=p/'overlay.json';overlay.write_text(json.dumps(dict(Replace=mapping),indent=2)+'\n');ident['overlays'][role+'-'+compiler]=dict(path=str(overlay),sourceHashes=hashes)
  for kind,cwd,target in [('phase',W,'./benchmarks/embedded/wasmvm'),('runner',W/'benchmarks/p3io','.')]:
   binary=D/f'{role}-{compiler}-{kind}-committed';cmd=[exe,'build']+([]if compiler=='go'else['-O3','-lto=full'])+['-overlay',str(overlay),'-o',str(binary),target]
   start=time.monotonic();proc=subprocess.run(cmd,cwd=cwd,env=env,capture_output=True,text=True);(D/f'{role}-{compiler}-{kind}-build.log').write_text(proc.stdout+proc.stderr);assert proc.returncode==0,(cmd,proc.stderr)
   rec=dict(compiler=compiler,role=role,kind=kind,command=cmd,cwd=str(cwd),seconds=time.monotonic()-start,sha256=hashlib.sha256(binary.read_bytes()).hexdigest());records.append(rec);print(role,compiler,kind,round(rec['seconds'],2),flush=True)
   (D/'committed-build.json').write_text(json.dumps(records,indent=2)+'\n')
ident['builds']=records;(D/'committed-identity.json').write_text(json.dumps(ident,indent=2)+'\n')
