from pathlib import Path
import subprocess,json,datetime,sys,traceback
p=Path(__file__).resolve().parent
stages=['p3-16/measure.py','p3-65536/measure.py','measure_core.py']
event={'startedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stages':stages,'completed':[],'noOwnedConcurrentBuildsTestsAnalysis':True}
assert not(p/'campaign.json').exists()
def save(): (p/'campaign.json').write_text(json.dumps(event,indent=2)+'\n')
save()
try:
 for stage in stages:
  event['active']=stage;save();print('start',stage,flush=True)
  with (p/(stage.replace('/','-')+'.log')).open('w')as log:subprocess.run([sys.executable,str(p/stage)],stdout=log,stderr=subprocess.STDOUT,check=True)
  event['completed'].append(stage);save();print('complete',stage,flush=True)
 event['completedUtc']=datetime.datetime.now(datetime.timezone.utc).isoformat();event.pop('active',None);save()
except BaseException:
 event['failure']=traceback.format_exc();save();raise
