from pathlib import Path
import json,subprocess,sys,os,hashlib
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');R=W.parent/'wasmvm';P=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'benchmarks'));sys.path.insert(0,str(W/'benchmarks/native'));import routing_compare,survey_modern,runtime_fixtures
plan=json.loads((P/'core-plan.json').read_text());env=dict(os.environ,GOMAXPROCS='4',GOGC='100',WASMVM_INTERLEAVE='0');checks=[];unsupported=[]
for path,digest in plan['binarySHA256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
for case in plan['cases']:
 f=case['fixture']
 if f['cohort'] not in ['original22-v1','generic-calls-v1']:continue
 count=1 if f['id']=='core/call-control'else 8
 expected=runtime_fixtures.checksum('nested-calls',f['seed'],count*2)if f['id']=='core/generic-calls'else routing_compare.oracle(W,f,f['seed'],count)
 for name,original in case['commands'].items():
  cmd=list(original)
  if '--iterations'in cmd:cmd[cmd.index('--iterations')+1]=str(count);cmd[cmd.index('--expected')+1]=str(expected);cmd[cmd.index('--samples')+1]='1';cmd[cmd.index('--warmups')+1]='0'
  elif f['id']=='core/generic-calls':cmd[1],cmd[3]=str(count*2),str(expected)
  elif f['family']=='application':cmd[2],cmd[3]=str(count),str(expected)
  else:cmd[3],cmd[4]=str(count),str(expected)
  run=subprocess.run(cmd,env=env,input='run\n'+'sample\n'*16,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=120)
  if run.returncode:
   error=RuntimeError('embedded runner exit '+str(run.returncode)+': '+run.stderr)
   alias='wasmer-cranelift'if name=='wasmer-compiler'else name
   if f['family']=='gc'and survey_modern.expected_gc_rejection(alias,error):unsupported.append(dict(case=f['id'],runtime=name,command=cmd,exitCode=run.returncode,stderr=run.stderr));continue
   raise RuntimeError((f['id'],name,cmd,run.returncode,run.stdout,run.stderr))
  records=[json.loads(line)for line in run.stdout.splitlines()if line.strip()];record=records[-1];assert record.get('result',record.get('checksum'))==expected,(name,f['id'],record)
  if 'warmResults'in record:assert all(x==expected for x in record['warmResults'])
  checks.append(dict(case=f['id'],runtime=name,result=expected,command=cmd))
 print('checked',f['id'],flush=True)
(P/'capability-smoke.json').write_text(json.dumps(dict(scope='Semantic/output checks only, with 1 or 8 iterations; no timing evidence.',checks=checks,unsupported=unsupported),indent=2)+'\n');print('checks',len(checks),'expected unsupported',len(unsupported))
