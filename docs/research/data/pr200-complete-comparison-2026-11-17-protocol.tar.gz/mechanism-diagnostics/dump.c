#include <wasmedge/wasmedge.h>
#include <stdio.h>
int main(int argc, char **argv) {
  if (argc != 3) return 2;
  WasmEdge_ConfigureContext *config = WasmEdge_ConfigureCreate();
  if (!config) return 3;
  WasmEdge_ConfigureSetRunMode(config, WasmEdge_RunMode_AOT);
  WasmEdge_ConfigureAddProposal(config, WasmEdge_Proposal_Threads);
  WasmEdge_ConfigureAddProposal(config, WasmEdge_Proposal_FunctionReferences);
  WasmEdge_ConfigureAddProposal(config, WasmEdge_Proposal_GC);
  WasmEdge_ConfigureCompilerSetOptimizationLevel(config, WasmEdge_CompilerOptimizationLevel_O3);
  WasmEdge_ConfigureCompilerSetOutputFormat(config, WasmEdge_CompilerOutputFormat_Native);
  WasmEdge_ConfigureCompilerSetDumpIR(config, true);
  WasmEdge_CompilerContext *compiler = WasmEdge_CompilerCreate(config);
  if (!compiler) return 4;
  WasmEdge_Result status = WasmEdge_CompilerCompile(compiler, argv[1], argv[2]);
  if (!WasmEdge_ResultOK(status)) fprintf(stderr, "%s\n", WasmEdge_ResultGetMessage(status));
  WasmEdge_CompilerDelete(compiler);
  WasmEdge_ConfigureDelete(config);
  return WasmEdge_ResultOK(status) ? 0 : 5;
}
