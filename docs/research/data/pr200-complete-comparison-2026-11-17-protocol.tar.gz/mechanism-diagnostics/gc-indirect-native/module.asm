
/Users/lijie/source/goplus/wasmvm/artifacts/pr200-complete-comparison-20261117/mechanism-diagnostics/gc-indirect-native/module.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000438 <_t0>:
     438:      	ret

000000000000043c <_t1>:
     43c:      	ret

0000000000000440 <_t2>:
     440:      	stp	x20, x19, [sp, #-0x20]!
     444:      	stp	x29, x30, [sp, #0x10]
     448:      	mov	x19, x3
     44c:      	mov	x8, x1
     450:      	ldr	w1, [x2]
     454:      	ldr	w2, [x2, #0x10]
     458:      	blr	x8
     45c:      	str	w0, [x19]
     460:      	ldp	x29, x30, [sp, #0x10]
     464:      	ldp	x20, x19, [sp], #0x20
     468:      	ret

000000000000046c <_f0>:
     46c:      	stp	x26, x25, [sp, #-0x50]!
     470:      	stp	x24, x23, [sp, #0x10]
     474:      	stp	x22, x21, [sp, #0x20]
     478:      	stp	x20, x19, [sp, #0x30]
     47c:      	stp	x29, x30, [sp, #0x40]
     480:      	add	x29, sp, #0x40
     484:      	sub	sp, sp, #0x40
     488:      	mov	x19, x2
     48c:      	mov	x20, x1
     490:      	ldr	x8, [x0, #0x8]
     494:      	ldr	x21, [x8]
     498:      	ldr	q0, [x21]
     49c:      	nop
     4a0:      	ldr	x22, 0x4000 <_intrinsics>
     4a4:      	ldr	x8, [x22, #0x58]
     4a8:      	sub	x3, x29, #0x50
     4ac:      	mov	w0, #0x1                ; =1
     4b0:      	mov	w1, #0x0                ; =0
     4b4:      	mov	w2, #0x0                ; =0
     4b8:      	blr	x8
     4bc:      	ldur	q0, [x29, #-0x50]
     4c0:      	stur	w20, [x29, #-0x60]
     4c4:      	ldr	x8, [x22, #0x38]
     4c8:      	sub	x2, x29, #0x60
     4cc:      	mov	w0, #0x0                ; =0
     4d0:      	mov	w1, #0x0                ; =0
     4d4:      	blr	x8
     4d8:      	ldr	q0, [x21]
     4dc:      	ldr	x8, [x22, #0x58]
     4e0:      	sub	x3, x29, #0x70
     4e4:      	mov	w0, #0x1                ; =1
     4e8:      	mov	w1, #0x1                ; =1
     4ec:      	mov	w2, #0x0                ; =0
     4f0:      	blr	x8
     4f4:      	ldur	q0, [x29, #-0x70]
     4f8:      	mov	w8, #0xbeef             ; =48879
     4fc:      	movk	w8, #0xdead, lsl #16
     500:      	eor	w8, w20, w8
     504:      	stur	w8, [x29, #-0x80]
     508:      	ldr	x8, [x22, #0x38]
     50c:      	sub	x2, x29, #0x80
     510:      	mov	w0, #0x0                ; =0
     514:      	mov	w1, #0x0                ; =0
     518:      	blr	x8
     51c:      	mov	w23, #0x0               ; =0
     520:      	mov	w24, #0x660d            ; =26125
     524:      	movk	w24, #0x19, lsl #16
     528:      	mov	w25, #0xf35f            ; =62303
     52c:      	movk	w25, #0x3c6e, lsl #16
     530:      	ldr	q0, [x21]
     534:      	mov	x26, sp
     538:      	sub	x8, x26, #0x10
     53c:      	mov	sp, x8
     540:      	ldr	x8, [x22, #0x58]
     544:      	and	w1, w20, #0x1
     548:      	sub	x3, x26, #0x10
     54c:      	mov	w0, #0x1                ; =1
     550:      	mov	w2, #0x0                ; =0
     554:      	blr	x8
     558:      	ldur	q0, [x26, #-0x10]
     55c:      	madd	w8, w20, w24, w25
     560:      	mov	x9, sp
     564:      	sub	x2, x9, #0x10
     568:      	mov	sp, x2
     56c:      	stur	w8, [x9, #-0x10]
     570:      	ldr	x8, [x22, #0x38]
     574:      	mov	w0, #0x0                ; =0
     578:      	mov	w1, #0x0                ; =0
     57c:      	blr	x8
     580:      	ldr	q0, [x21]
     584:      	ubfx	w1, w20, #1, #1
     588:      	mov	x20, sp
     58c:      	sub	x8, x20, #0x10
     590:      	mov	sp, x8
     594:      	ldr	x8, [x22, #0x58]
     598:      	sub	x3, x20, #0x10
     59c:      	mov	w0, #0x1                ; =1
     5a0:      	mov	w2, #0x0                ; =0
     5a4:      	blr	x8
     5a8:      	ldur	q0, [x20, #-0x10]
     5ac:      	mov	x20, sp
     5b0:      	sub	x8, x20, #0x10
     5b4:      	mov	sp, x8
     5b8:      	ldr	x8, [x22, #0x30]
     5bc:      	sub	x3, x20, #0x10
     5c0:      	mov	w0, #0x0                ; =0
     5c4:      	mov	w1, #0x0                ; =0
     5c8:      	mov	w2, #0x0                ; =0
     5cc:      	blr	x8
     5d0:      	ldur	w8, [x20, #-0x10]
     5d4:      	eor	w20, w8, w23
     5d8:      	add	w23, w23, #0x1
     5dc:      	cmp	w23, w19
     5e0:      	b.lo	0x530 <_f0+0xc4>
     5e4:      	mov	x0, x20
     5e8:      	sub	sp, x29, #0x40
     5ec:      	ldp	x29, x30, [sp, #0x40]
     5f0:      	ldp	x20, x19, [sp, #0x30]
     5f4:      	ldp	x22, x21, [sp, #0x20]
     5f8:      	ldp	x24, x23, [sp, #0x10]
     5fc:      	ldp	x26, x25, [sp], #0x50
     600:      	ret
