; ModuleID = 'wasm'
source_filename = "wasm"
target triple = "arm64-apple-darwin27.0.0"

@intrinsics = protected dllexport local_unnamed_addr global ptr null
@version = protected dllexport local_unnamed_addr constant i32 2
@wasm.code = protected dllexport constant [224 x i8] c"\00asm\01\00\00\00\01\0F\03_\01\7F\01^d\00\00`\02\7F\7F\01\7F\03\02\01\02\06\13\01d\01\00A\00\FB\00\00A\01\FB\00\00\FB\08\01\02\0B\07\07\01\03run\00\00\0Am\01k\01\01\7F#\00A\00\FB\0B\01 \00\FB\05\00\00#\00A\01\FB\0B\01 \00A\EF\FD\B6\F5}s\FB\05\00\00\03@#\00 \00A\01q\FB\0B\01 \00A\8D\CC\E5\00lA\DF\E6\BB\E3\03j\FB\05\00\00#\00 \00A\01vA\01q\FB\0B\01\FB\02\00\00 \02s!\00 \02A\01j!\02 \02 \01I\0D\00\0B \00\0B\004\04name\02\0C\01\00\03\00\01x\01\01n\02\01i\03\0A\01\00\01\00\05again\04\07\02\00\01t\01\01a\07\0A\01\00\07objects"
@wasm.size = protected dllexport constant i32 224

; Function Attrs: mustprogress nofree norecurse nosync nounwind strictfp willreturn memory(none) uwtable
define protected dllexport void @t0(ptr noalias readonly captures(none) %0, ptr noalias nofree readnone captures(none) %1, ptr noalias nofree readnone captures(none) %2, ptr noalias nofree readnone captures(none) %3) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind strictfp willreturn memory(none) uwtable
define protected dllexport void @t1(ptr noalias readonly captures(none) %0, ptr noalias nofree readnone captures(none) %1, ptr noalias nofree readnone captures(none) %2, ptr noalias nofree readnone captures(none) %3) local_unnamed_addr #0 {
entry:
  ret void
}

; Function Attrs: strictfp uwtable
define protected dllexport void @t2(ptr noalias readonly %0, ptr noalias nofree readonly captures(none) %1, ptr noalias nofree readonly captures(none) %2, ptr noalias nofree writeonly captures(none) initializes((0, 4)) %3) local_unnamed_addr #1 {
entry:
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %6 = load i32, ptr %5, align 4
  %7 = tail call i32 %1(ptr %0, i32 %4, i32 %6) #2
  store i32 %7, ptr %3, align 4
  ret void
}

; Function Attrs: strictfp uwtable
define protected dllexport i32 @f0(ptr noalias readonly captures(none) %0, i32 %1, i32 %2) local_unnamed_addr #1 {
entry:
  %.elt11 = getelementptr inbounds nuw i8, ptr %0, i64 8
  %.unpack12 = load ptr, ptr %.elt11, align 8
  %3 = load ptr, ptr %.unpack12, align 8, !invariant.group !2
  %4 = load <2 x i64>, ptr %3, align 16
  %5 = alloca <2 x i64>, align 16
  %6 = load ptr, ptr @intrinsics, align 8, !invariant.group !2
  %7 = getelementptr inbounds nuw i8, ptr %6, i64 88
  %8 = load ptr, ptr %7, align 8
  call void %8(<2 x i64> %4, i32 1, i32 0, i8 0, ptr nonnull %5) #2
  %9 = load <2 x i64>, ptr %5, align 16
  %10 = alloca <2 x i64>, align 16
  store i32 %1, ptr %10, align 16
  %11 = getelementptr inbounds nuw i8, ptr %6, i64 56
  %12 = load ptr, ptr %11, align 8
  call void %12(<2 x i64> %9, i32 0, i32 0, ptr nonnull %10) #2
  %13 = load <2 x i64>, ptr %3, align 16
  %14 = alloca <2 x i64>, align 16
  %15 = load ptr, ptr %7, align 8
  call void %15(<2 x i64> %13, i32 1, i32 1, i8 0, ptr nonnull %14) #2
  %16 = load <2 x i64>, ptr %14, align 16
  %17 = xor i32 %1, -559038737
  %18 = alloca <2 x i64>, align 16
  store i32 %17, ptr %18, align 16
  %19 = load ptr, ptr %11, align 8
  call void %19(<2 x i64> %16, i32 0, i32 0, ptr nonnull %18) #2
  %20 = getelementptr inbounds nuw i8, ptr %6, i64 48
  br label %loop

loop:                                             ; preds = %loop, %entry
  %.010 = phi i32 [ %1, %entry ], [ %39, %loop ]
  %.0 = phi i32 [ 0, %entry ], [ %40, %loop ]
  %21 = load <2 x i64>, ptr %3, align 16
  %22 = and i32 %.010, 1
  %23 = alloca <2 x i64>, align 16
  %24 = load ptr, ptr %7, align 8
  call void %24(<2 x i64> %21, i32 1, i32 %22, i8 0, ptr nonnull %23) #2
  %25 = load <2 x i64>, ptr %23, align 16
  %26 = mul i32 %.010, 1664525
  %27 = add i32 %26, 1013904223
  %28 = alloca <2 x i64>, align 16
  store i32 %27, ptr %28, align 16
  %29 = load ptr, ptr %11, align 8
  call void %29(<2 x i64> %25, i32 0, i32 0, ptr nonnull %28) #2
  %30 = load <2 x i64>, ptr %3, align 16
  %31 = lshr i32 %.010, 1
  %32 = and i32 %31, 1
  %33 = alloca <2 x i64>, align 16
  %34 = load ptr, ptr %7, align 8
  call void %34(<2 x i64> %30, i32 1, i32 %32, i8 0, ptr nonnull %33) #2
  %35 = load <2 x i64>, ptr %33, align 16
  %36 = alloca <2 x i64>, align 16
  %37 = load ptr, ptr %20, align 8
  call void %37(<2 x i64> %35, i32 0, i32 0, i8 0, ptr nonnull %36) #2
  %38 = load i32, ptr %36, align 16
  %39 = xor i32 %38, %.0
  %40 = add nuw i32 %.0, 1
  %41 = icmp ult i32 %40, %2
  br i1 %41, label %loop, label %br_if.end

br_if.end:                                        ; preds = %loop
  ret i32 %39
}

attributes #0 = { mustprogress nofree norecurse nosync nounwind strictfp willreturn memory(none) uwtable "no-stack-arg-probe" }
attributes #1 = { strictfp uwtable "no-stack-arg-probe" }
attributes #2 = { strictfp }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 1, !"PIC Level", i32 2}
!1 = !{i32 1, !"SDK Version", <2 x i32> <i32 12, i32 1>}
!2 = !{}
