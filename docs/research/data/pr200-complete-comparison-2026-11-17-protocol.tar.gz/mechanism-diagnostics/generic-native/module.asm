
/Users/lijie/source/goplus/wasmvm/artifacts/pr200-complete-comparison-20261117/mechanism-diagnostics/generic-native/module.dylib:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000438 <_t0>:
     438:      	stp	x20, x19, [sp, #-0x20]!
     43c:      	stp	x29, x30, [sp, #0x10]
     440:      	mov	x19, x3
     444:      	mov	x8, x1
     448:      	ldr	w1, [x2]
     44c:      	blr	x8
     450:      	str	w0, [x19]
     454:      	ldp	x29, x30, [sp, #0x10]
     458:      	ldp	x20, x19, [sp], #0x20
     45c:      	ret

0000000000000460 <_t1>:
     460:      	stp	x20, x19, [sp, #-0x20]!
     464:      	stp	x29, x30, [sp, #0x10]
     468:      	mov	x19, x3
     46c:      	mov	x8, x1
     470:      	ldr	w1, [x2]
     474:      	ldr	w2, [x2, #0x10]
     478:      	blr	x8
     47c:      	str	w0, [x19]
     480:      	ldp	x29, x30, [sp, #0x10]
     484:      	ldp	x20, x19, [sp], #0x20
     488:      	ret

000000000000048c <_f0>:
     48c:      	mov	w8, #0x5ca9             ; =23721
     490:      	movk	w8, #0x1738, lsl #16
     494:      	mov	w9, #0x2932             ; =10546
     498:      	movk	w9, #0x4750, lsl #16
     49c:      	madd	w0, w1, w8, w9
     4a0:      	ret

00000000000004a4 <_f1>:
     4a4:      	mov	x0, x1
     4a8:      	mov	w8, #0x0                ; =0
     4ac:      	mov	w9, #0x5ca9             ; =23721
     4b0:      	movk	w9, #0x1738, lsl #16
     4b4:      	mov	w10, #0x2932            ; =10546
     4b8:      	movk	w10, #0x4750, lsl #16
     4bc:      	madd	w0, w0, w9, w10
     4c0:      	add	w8, w8, #0x1
     4c4:      	cmp	w8, w2
     4c8:      	b.lo	0x4bc <_f1+0x18>
     4cc:      	ret
