; ModuleID = 'wasm'
source_filename = "wasm"
target triple = "arm64-apple-darwin27.0.0"

@version = protected dllexport local_unnamed_addr constant i32 2
@intrinsics = protected dllexport global ptr zeroinitializer
@wasm.code = protected dllexport constant [106 x i8] c"\00asm\01\00\00\00\01\0C\02`\01\7F\01\7F`\02\7F\7F\01\7F\03\03\02\00\01\07\07\01\03run\00\01\0AD\02&\01\01\7F\03@ \00A\8D\CC\E5\00lA\DF\E6\BB\E3\03j!\00 \01A\01j\22\01A\02I\0D\00\0B \00\0B\1B\01\01\7F\03@ \00\10\00!\00 \02A\01j\22\02 \01I\0D\00\0B \00\0B"
@wasm.size = protected dllexport constant i32 106

; Function Attrs: strictfp uwtable
define protected dllexport void @t0(ptr noalias readonly %0, ptr noalias nofree readonly captures(none) %1, ptr noalias nofree readonly captures(none) %2, ptr noalias nofree writeonly captures(none) initializes((0, 4)) %3) local_unnamed_addr #0 {
entry:
  %4 = load i32, ptr %2, align 4
  %5 = tail call i32 %1(ptr %0, i32 %4) #3
  store i32 %5, ptr %3, align 4
  ret void
}

; Function Attrs: strictfp uwtable
define protected dllexport void @t1(ptr noalias readonly %0, ptr noalias nofree readonly captures(none) %1, ptr noalias nofree readonly captures(none) %2, ptr noalias nofree writeonly captures(none) initializes((0, 4)) %3) local_unnamed_addr #0 {
entry:
  %4 = load i32, ptr %2, align 4
  %5 = getelementptr inbounds nuw i8, ptr %2, i64 16
  %6 = load i32, ptr %5, align 4
  %7 = tail call i32 %1(ptr %0, i32 %4, i32 %6) #3
  store i32 %7, ptr %3, align 4
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind strictfp willreturn memory(none) uwtable
define protected dllexport i32 @f0(ptr noalias readonly captures(none) %0, i32 %1) local_unnamed_addr #1 {
entry:
  %2 = mul i32 %1, 389569705
  %3 = add i32 %2, 1196435762
  ret i32 %3
}

; Function Attrs: nofree norecurse nosync nounwind strictfp memory(none) uwtable
define protected dllexport i32 @f1(ptr noalias readonly captures(none) %0, i32 %1, i32 %2) local_unnamed_addr #2 {
entry:
  br label %loop

loop:                                             ; preds = %loop, %entry
  %.04 = phi i32 [ %1, %entry ], [ %4, %loop ]
  %.0 = phi i32 [ 0, %entry ], [ %5, %loop ]
  %3 = mul i32 %.04, 389569705
  %4 = add i32 %3, 1196435762
  %5 = add nuw i32 %.0, 1
  %6 = icmp ult i32 %5, %2
  br i1 %6, label %loop, label %br_if.end

br_if.end:                                        ; preds = %loop
  ret i32 %4
}

attributes #0 = { strictfp uwtable "no-stack-arg-probe" }
attributes #1 = { mustprogress nofree norecurse nosync nounwind strictfp willreturn memory(none) uwtable "no-stack-arg-probe" }
attributes #2 = { nofree norecurse nosync nounwind strictfp memory(none) uwtable "no-stack-arg-probe" }
attributes #3 = { strictfp }

!llvm.module.flags = !{!0, !1}

!0 = !{i32 1, !"PIC Level", i32 2}
!1 = !{i32 1, !"SDK Version", <2 x i32> <i32 12, i32 1>}
