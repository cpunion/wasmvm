from pathlib import Path
import json,sys,os,random,hashlib,statistics,subprocess,gzip,time,traceback
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');P=Path(__file__).resolve().parent;D=P/'core';D.mkdir(exist_ok=False)
sys.path.insert(0,str(W/'benchmarks'));import interleaved
plan=json.loads((P/'core-plan.json').read_text());smoke=json.loads((P/'capability-smoke.json').read_text());unsupported={(x['case'],x['runtime'])for x in smoke['unsupported']}
assert plan['head']==json.loads((P/'build.json').read_text())['head'];subprocess.run(['git','diff','--exit-code',plan['head'],'HEAD','--','internal','pkg','cmd','go.mod','go.sum',':(exclude)*_test.go'],cwd=W,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
for path,digest in plan['binarySHA256'].items():assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==digest
os.environ['GOMAXPROCS']='1';os.environ['GOGC']='100'
for key in ['GC_DONT_GC','GC_FREE_SPACE_DIVISOR','GC_MARKERS','GC_PRINT_STATS','WASMVM_DIAGNOSTIC_JIT_MAP','WASMVM_WARM_PROFILE','WASMVM_WARM_ALLOC_PROFILE','WASMVM_COMPILE_PHASE']:os.environ.pop(key,None)
rng=random.Random(plan['randomSeed']);rows=D/'rows.jsonl.gz';orders=[]
(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');(D/'unsupported.json').write_text(json.dumps(smoke['unsupported'],indent=2)+'\n')
try:
 for block in range(plan['blocks']):
  load={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadAverage':os.getloadavg(),'processes':subprocess.check_output(['ps','-axo','pid,ppid,etime,%cpu,command'],text=True)};(D/f'load-{block}.json').write_text(json.dumps(load,indent=2)+'\n')
  cases=list(plan['cases']);rng.shuffle(cases);orders.append([x['fixture']['cohort']+'/'+x['fixture']['id']for x in cases]);(D/'case-orders.json').write_text(json.dumps(orders,indent=2)+'\n')
  for case in cases:
   f=case['fixture'];assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['wasmSha256'];commands={}
   for name,cmd in case['commands'].items():
    if (f['id'],name)in unsupported:continue
    commands[name]=cmd;commands[name+'-aa']=cmd
   observations,sampleOrders=interleaved.invoke(commands,180,rng,samples=plan['samples'])
   for name,ob in observations.items():
    record=ob['record'];assert ob['exitCode']==0 and record.get('result',record.get('checksum'))==f['expectedChecksum'] and len(record['warmCallNs'])==7
    if 'warmResults'in record:assert record['warmResults']==[f['expectedChecksum']]*7
    role=name.removesuffix('-aa')
    if role in plan['runtimes'] and 'source'in plan['runtimes'][role]:assert record['sourceRevision']==plan['runtimes'][role]['source'] and record['compilerRevision']==plan['runtimes'][role]['compiler']
    warm=record['warmCallNs'];reduce=statistics.mean if case['statistic']=='mean-including-pauses'else statistics.median
    row=dict(block=block,id=name,case=f['id'],cohort=f['cohort'],statistic=case['statistic'],nsPerIteration=reduce(warm)/f['iterations'],medianDiagnosticNs=statistics.median(warm)/f['iterations'],observation=ob,orders=sampleOrders)
    with gzip.open(rows,'at',compresslevel=1)as stream:stream.write(json.dumps(row)+'\n')
   print('checked',block,f['cohort'],f['id'],len(observations),flush=True)
 (D/'complete.json').write_text(json.dumps({'blocks':plan['blocks'],'cases':len(plan['cases']),'status':'Every frozen process and result checked.'})+'\n')
except BaseException:
 (D/'failure.txt').write_text(traceback.format_exc());raise
finally:
 (D/'load-after.json').write_text(json.dumps({'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadAverage':os.getloadavg(),'processes':subprocess.check_output(['ps','-axo','pid,ppid,etime,%cpu,command'],text=True)},indent=2)+'\n')
