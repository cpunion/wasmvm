from pathlib import Path
import json
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');stem='pr200-complete-comparison-2026-11-17';data=json.loads((w/'docs/research/data'/f'{stem}.json').read_text());core=data['core']['results'];p3=data['p3']['results'];out=[]
def add(s=''):out.append(s)
def table(headers,rows):
 add('| '+' | '.join(headers)+' |');add('| '+' | '.join(['---']+['---:']*(len(headers)-1))+' |')
 for row in rows:add('| '+' | '.join(map(str,row))+' |')
 add()
def num(v):return f'{v:,.3f}'if abs(v)<100 else f'{v:,.2f}'
def ratio(v):return f"{v['ratio']:.3f} [{v['ci95'][0]:.3f}, {v['ci95'][1]:.3f}]; "+('pass'if v.get('controlsResolve')else'unresolved')
headers=['Workload / metric','wasmvm Go','wasmvm LLGo','wazero','Wasmtime','Wasmer','WasmEdge']
roles={'native':['head-go-native','head-llgo-native','wazero-compiler','wasmtime-compiler','wasmer-compiler','wasmedge-compiler'],'interpreter':['head-go-interpreter','head-llgo-interpreter','wazero-interpreter',None,None,'wasmedge-interpreter']}
failed={(x['cohort']+'/'+x['case'],x['runtime'])for x in data['failures']['failures']}
def unavailable(key,role):
 if role is None:return 'NM'
 if (key,role)in failed:return '**FAIL: SIGSEGV**'
 return 'US'
def cell(key,role,phase=None):
 v=core[key]
 if role not in v['mediansNsPerIteration']:return unavailable(key,role)
 if phase is not None:
  n=v['phasesMedianNs'][role].get(phase);return 'N/A'if n is None else num(n/1000)
 value=num(v['mediansNsPerIteration'][role]);return value+(' †'if not v['AA'][role]['resolves2_5Percent']else'')
add('# PR #200: complete runtime comparison, 2026-11-17')
add()
add('This event measures PR #200 against its own source baseline and four independent runtimes. It adds WasmEdge O3 AOT alongside its interpreter. All **33 declared core workloads** and **two complete P3 HTTP payloads** are reported below, with separate wasmvm Go and LLGo columns. Competitive parity remains open. General native calls, SHA, GC field access, shared memory and P3 still show substantial observed gaps; unresolved controls limit precise rankings.')
add()
add('Source CPU improvements with resolving controls in this event: **Go 64 KiB P3 −7.61%**, **LLGo 16 B −4.62%**, and **LLGo 64 KiB −2.90%**. These are new independent measurements, not pooled with the original PR #200 event. The Go 16 B CPU control is unresolved. Against Wasmtime, both P3 payloads have unresolved controls; the observed CPU ratios are approximately **1.76–2.05× for Go** and **4.89–4.99× for LLGo**, not accepted exact competitive ratios.')
add()
add('## Revisions, profiles and protocol')
add()
add('- Engine source: base `b3925191`, head/merged PR #200 `c8936b9`. Harness/policy head `34c3a5e0` has identical engine inputs. Reused binaries retain their actual producer revisions; `build.json` records verified production-source equivalence to the qualified source. No full source copies or new worktrees were created.')
add('- Go **1.27.3**; LLGo **114c98b4**, **`-O3 -lto=full`**, LLVM **22.1.8**, default production GC. Source base/head share the compiler profile. LLGo **2e3e02f4** on the same source baseline measures the SDK upgrade independently.')
add('- wazero **1.12.0**, native compiler/interpreter; Wasmtime **48.0.1**, Cranelift speed; Wasmer **7.3.0**, Cranelift; WasmEdge **0.17.1**, interpreter and **O3 AOT**. These are explicit pinned profiles, not a claim that every available backend or configuration was measured.')
add('- Local Apple M4 Max, macOS arm64, 128 GiB RAM. External desktop load is uncontrolled and recorded; no owned builds, tests, profiles, analysis or edits overlap timing. This is not a Linux amd64 performance result.')
add('- Core: six fixed fresh-process blocks, each with symmetric same-binary A/A, two warmups and seven interleaved measured calls. **6,156 successful process records** after excluding exactly three failing sustained WasmEdge AOT cells. All 33 workloads remain represented. Allocation workloads use means including pauses; others use medians.')
add('- P3: **84 processes per payload**, seven roles with A/A, six fixed blocks, four workers, sixteen clients and twenty interleaved 512-request windows plus a separate flush. Verify status, headers, full body, trailers, CRC and joined guest completion. CPU/instruction counters include the driver and checks. Mach ticks use the recorded timebase.')
add('- Ratios use paired block geometric means and 20,000 fixed-seed bootstrap resamples with marginal 95% intervals. Both relevant A/A intervals must fit `[0.975, 1.025]`. No simultaneous portfolio-acceptance claim, adaptive extension, phase subtraction or cross-event pooling.')
add()
add('**Legend:** `†` means that role’s same-binary timing control is unresolved. Values are observations; a qualified comparison additionally needs both controls and its ratio interval. `US` means this pinned profile rejected the feature in semantic preflight. `NM` means this benchmark adapter/profile was not measured; it does not claim the engine lacks the capability. `N/A` means the metric does not apply. `FAIL` is an execution failure, never an unsupported-feature classification or performance win.')
add()
for backend in roles:
 add('## '+('Native compiled execution'if backend=='native'else'Interpreter execution'));add()
 add('Warm **ns/source iteration**, except SHA uses **ns/message block**. Cohorts distinguish the original 22 cases from four sustained GC, six sustained Threads, and the general-call workload.');add()
 table(headers,[[key]+[cell(key,r)for r in roles[backend]]for key in core])
add('## Complete P3 HTTP requests');add()
add('P3 competitor cells marked `NM` have no measured adapter for the pinned component/WASI workload. Wasmtime uses the same validated workload. Managed allocation counts exclude foreign Rust/C/JIT allocations and cannot compare total allocation across engines.');add()
rows=[]
for size,v in p3.items():
 for metric,label in [('cpuUs','CPU, us/request'),('instructions','instructions/request'),('throughput','requests/s')]:
  cells=[]
  for role in ['head-go','head-llgo',None,'wasmtime',None,None]:
   cells.append('NM'if role is None else num(v['medians'][role][metric])+(' †'if not v['AA'][role][metric]['resolves2_5Percent']else''))
  rows.append([size+' B '+label]+cells)
table(headers,rows)
add('### P3 source and SDK contrasts');add()
rows=[]
for size,v in p3.items():
 for metric in ['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest']:
  rows.append([size+' B '+metric,ratio(v['comparisons']['head-go/base-go'][metric]),ratio(v['comparisons']['head-llgo/base-llgo'][metric]),ratio(v['comparisons']['base-llgo/old-sdk-base-llgo'][metric])])
table(['Metric','Go source head/base','LLGo source head/base','LLGo SDK114/SDK2e on fixed base'],rows)
add('Throughput ratios above one improve; CPU/instructions/allocation ratios below one improve. The JSON also retains the combined PR source+SDK contrast, all own-baseline observations and every per-role A/A interval.');add()
add('### Competitive P3 ratios');add()
table(['Payload / compiler','CPU ratio to Wasmtime [95% CI]; controls','Throughput ratio to Wasmtime [95% CI]; controls'],[[size+' B '+compiler,ratio(v['comparisons']['head-'+compiler+'/wasmtime']['cpuUs']),ratio(v['comparisons']['head-'+compiler+'/wasmtime']['throughput'])]for size,v in p3.items()for compiler in ['go','llgo']])
add('## Core source baseline and SDK contrasts');add()
add('Head/base ratios below one improve. These marginal intervals describe this event; an apparent change in an unchanged mechanism requires diagnosis before being attributed to source changes. The machine-readable report includes every competitor ratio and A/A interval.');add()
for backend in roles:
 add('### '+backend);add()
 table(['Workload','Go source head/base','LLGo source head/base','LLGo SDK114/SDK2e on fixed base'],[[key]+[ratio(v['comparisons'][pair])for pair in [f'head-go-{backend}/base-go-{backend}',f'head-llgo-{backend}/base-llgo-{backend}',f'base-llgo-{backend}/old-sdk-base-llgo-{backend}']]for key,v in core.items()])
add('## Preparation, first call and cleanup');add()
add('All entries below are **microseconds per process or invocation**, including unresolved observations. Phase intervals are not inferred from warm-call controls. Startup is independently observed process readiness. Native compile/validate boundaries differ by API; WasmEdge AOT includes validation and artifact I/O, plus separately recorded native-image loading. Every process creates a fresh native image. First-call and warm execution have their own boundaries; values are never subtracted to invent pure costs.');add()
for backend in roles:
 add('<details>');add('<summary>'+backend.title()+': all 33 workloads and phase observations</summary>');add()
 for phase in ['processStartup','load','engineSetup','compileValidate','instantiate','exportLookup','firstCall','cleanup']:
  add('### '+phase);add();table(headers,[[key]+[cell(key,r,phase)for r in roles[backend]]for key in core])
 add('</details>');add()
add('### WasmEdge AOT preparation detail');add()
table(['Workload','Compile + validation + artifact I/O, us','Native image load, us','Post-load validation, us'],[[key]+[cell(key,'wasmedge-compiler',phase)for phase in ['aotPreparationNs/compileValidateArtifactIO','aotPreparationNs/compiledArtifactLoad','preparationPartsNs/validate']]for key in core])
add('### P3 phase observations');add()
rows=[]
for size,v in p3.items():
 for phase in sorted({k for role in ['head-go','head-llgo','wasmtime']for k in v['phasesMedianNs'][role]}):
  cells=[]
  for role in ['head-go','head-llgo',None,'wasmtime',None,None]:
   value=None if role is None else v['phasesMedianNs'][role].get(phase);cells.append('NM'if role is None else'N/A'if value is None else num(value/1000))
  rows.append([size+' B / '+phase]+cells)
table(headers,rows)
add('## Native controls (different contracts)');add()
add('Unchecked C kernels omit runtime safety/lifetime contracts; native Go implements HTTP replies without Component/WASI. These are overhead oracles, not equivalent competitors, and are never subtracted from runtime timings.');add()
table(['Workload','Unchecked native C, ns/iteration'],[[key,num(v['mediansNsPerIteration']['native-c'])]for key,v in core.items()if'native-c'in v['mediansNsPerIteration']])
table(['Payload','Native Go CPU, us/request','Native Go requests/s'],[[size+' B',num(v['medians']['native-go']['cpuUs']),num(v['medians']['native-go']['throughput'])]for size,v in p3.items()])
add('## WasmEdge sustained AOT failures');add()
add('The initial core campaign stopped on sustained indirect struct access. All incomplete timing rows are retained separately and excluded. Full-size semantic checks then found SIGSEGV in three AOT cells: sustained struct access, struct allocation and indirect struct access. Their small original cases pass. The indirect case reproduces three times in the C harness; WasmEdge’s own CLI also fails at 1,000,000 iterations (SIGILL in that invocation), while its interpreter returns the expected checksum. LLDB catches `EXC_BAD_ACCESS` in `WasmEdge::Executor::Executor::arrayGet`, on `strb w12, [x8]`. This identifies a failure site, not a proven root cause. The complete core cohort was restarted once with those exact cells labeled failed; independently completed P3 cohorts were retained unchanged.');add()
add('## Post-campaign generated-code evidence');add()
add('Separate untimed diagnostic builds use the same WasmEdge native-output/O3 configuration. Their LLVM IR, ARM64 assembly, compiler helper and provenance are included in the protocol archive. They do not replace any timed binary.');add()
add('**General calls:** WasmEdge fully unrolls the two-iteration callee, inlines it into the outer loop, and folds the two affine updates into `x * 389569705 + 1196435762` modulo 2^32. Its outer loop at `_f1+0x18` is exactly `madd; add; cmp; b.lo`, with no call instruction. wasmvm’s current `planLeafExpressions` rejects conditional/backward edges, so this fixture retains its general native call. The observed gap therefore includes bounded-loop expansion, inlining and algebraic simplification; it is not an isolated call-ABI benchmark across all engines. The fixture name is historical and describes the wasmvm route it forces.');add()
add('**Sustained GC failure:** optimized WasmEdge IR places four 16-byte `alloca` instructions inside the indirect-access loop. Its native code decreases SP four times per iteration at offsets `0x538`, `0x564`, `0x58c` and `0x5b0`, and branches back at `0x5e0` without restoring SP. Restoration occurs only on function exit. This establishes 64 bytes of cumulative stack growth per source iteration (about 64 MB at one million), consistent with the observed stack-boundary access failure. No wasmvm frame/GC change is justified by this competitor failure.');add()
add('## Next implementation work');add()
add('1. General native calls: inspect actual emitted frame/parameter/root bookkeeping versus competitor output. Previous record-cursor variants regressed and remain rejected. WasmEdge AOT is now a measured strong reference on this case; the measured gap includes its proven full inlining and affine simplification, so bounded expression expansion should be addressed alongside ABI costs.')
add('2. SHA and field access: improve compiler range/region coverage and invariant heap-reference guards while preserving trap order, cold resumes, full reference metadata and GC roots.')
add('3. Shared memory: investigate the measured code and execution counters. The current short loop polls control state every iteration; the parked four-copy grouping experiment did not demonstrate a qualified gain. No mutex-only explanation is established.')
add('4. P3: retain PR #200’s reduced ready-source work and continue canonical/host-transition work. These measurements show a large instruction gap; Go’s scheduler alone does not guarantee a faster complete Component/WASI request. Separate LLGo generated host code, allocation, runtime synchronization and guest-native execution before filing compiler issues.')
add()
add('## Reproducible evidence');add()
add(f'- [Machine-readable results, all controls and source/SDK contrasts](data/{stem}.json).')
add(f'- [All 6,324 verified process records](data/{stem}-raw.jsonl.gz), SHA-256 `{data["raw"]["sha256"]}`.')
add(f'- [Frozen plans, commands, hashes, analysis/export scripts, semantic checks and failure evidence](data/{stem}-protocol.tar.gz), SHA-256 `{data["protocol"]["sha256"]}`.')
add('- Per-request vectors unused by these metrics are projected to count/extrema/hash; no latency-tail claim. Public load records omit unrelated desktop command arguments. The incomplete first core run is retained locally with its source hash in the JSON.')
(w/'docs/research'/f'performance-{stem}.md').write_text('\n'.join(out)+'\n')
print('Rendered',len(out),'lines')
