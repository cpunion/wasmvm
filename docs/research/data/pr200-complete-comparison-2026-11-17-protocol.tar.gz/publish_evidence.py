from pathlib import Path
import json,gzip,hashlib,tarfile,io,statistics,math,collections
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');dest=w/'docs/research/data';stem='pr200-complete-comparison-2026-11-17'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
core=json.loads((p/'core-analysis.json').read_text());p3=json.loads((p/'p3-analysis.json').read_text());plan=json.loads((p/'core-plan.json').read_text());cases={(c['fixture']['cohort'],c['fixture']['id']):c for c in plan['cases']};counts={};sources={};core_rows=[]
raw=dest/(stem+'-raw.jsonl.gz')
with raw.open('wb')as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as stream:
 for cohort in ['core','p3-16','p3-65536']:
  f=p/cohort/'rows.jsonl.gz';sources[cohort]=sha(f);count=0
  for line in gzip.open(f,'rt'):
   r=json.loads(line);count+=1
   if cohort=='core':
    c=cases[(r['cohort'],r['case'])];fxt=c['fixture'];record=r['observation']['record'];assert record.get('result',record.get('checksum'))==fxt['expectedChecksum'];warm=record['warmCallNs'];assert len(warm)==7
    if 'warmResults'in record:assert record['warmResults']==[fxt['expectedChecksum']]*7
    reduce=statistics.mean if c['statistic']=='mean-including-pauses'else statistics.median;assert math.isclose(r['nsPerIteration'],reduce(warm)/fxt['iterations'],rel_tol=1e-12)
    core_rows.append(r)
   else:
    record=r['record'];size=16 if cohort=='p3-16'else 65536;expected=1757737011 if size==16 else 2629362236;assert record['warmResults']==[expected]*21
    total={k:sum(x['after'][k]-x['before'][k]for x in r['rounds'])for k in r['totals']};assert total==r['totals'];clock=json.loads((p/cohort/'plan.json').read_text())['machTimebase'];tick=clock['numer']/clock['denom']
    assert math.isclose(r['cpuUs'],(total['ri_user_time']+total['ri_system_time'])*tick/r['windowRequests']/1000,rel_tol=1e-12)
    assert math.isclose(r['instructions'],total['ri_instructions']/r['windowRequests'],rel_tol=1e-12)
    assert math.isclose(r['throughput'],512e9/statistics.median(record['warmCallNs'][:20]),rel_tol=1e-12)
    for batch in record['service']['Batches']:
     for key in ['RequestNs','PublicAPINs']:
      if key in batch:
       values=batch.pop(key);batch[key+'Projection']=dict(count=len(values),minimum=min(values)if values else None,maximum=max(values)if values else None,sha256=hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest())
   stream.write((json.dumps(dict(cohort=cohort,row=r),separators=(',',':'))+'\n').encode())
  counts[cohort]=count
assert counts=={'core':6156,'p3-16':84,'p3-65536':84}
# Recompute every phase median from raw records, including independently observed startup.
for key,result in core['results'].items():
 selected=[r for r in core_rows if r['cohort']+'/'+r['case']==key]
 for role,phases in result['phasesMedianNs'].items():
  rr=[r for r in selected if r['id']in[role,role+'-aa']];phases['processStartup']=statistics.median(r['observation']['processReadyNs']for r in rr)
  for family in ['preparationPartsNs','aotPreparationNs']:
   for k in {k for r in rr for k in r['observation']['record'].get(family,{})}:
    phases[family+'/'+k]=statistics.median(r['observation']['record'][family][k]for r in rr)
files=['render_report.py','publish_evidence.py','build.py','build.json','reuse.json','build-complete.json','prepare_core.py','prepare_p3.py','measure_core.py','measure_core-aborted.py','run_campaign.py','run_core_restart.py','campaign.json','campaign-aborted.json','core-plan.json','core-plan-aborted.json','qualification.json','machine.json','analyze_core.py','analyze_p3.py','capability_smoke.py','capability-smoke.json','smoke.py','smoke.json','p3-capability-smoke.json','reference-build.json','wasmedge-builds.json','wasmedge.c','common.h','wasmedge-full-size-smoke.json','wasmedge-sustained-indirect-reproducer.json','wasmedge-cli-reproducer.json','wasmedge-lldb-input.log','runtime-failures.json','harness-tests.log','measure_core-aborted.log']
for cohort in ['p3-16','p3-65536']:
 files +=[cohort+'/'+n for n in ['measure.py','plan.json','frozen-plan.json']]
files+=['core/case-orders.json','core/unsupported.json','core/runtime-failures.json','core/complete.json']
extras={}
for cohort in ['core','p3-16','p3-65536']:
 for f in sorted((p/cohort).glob('*load*.json')):
  data=json.loads(f.read_text());original=sha(f)
  if isinstance(data,dict)and isinstance(data.get('processes'),str):
   rows=[]
   for line in data.pop('processes').splitlines()[1:]:
    fields=line.split(None,4)
    if len(fields)==5:rows.append(dict(pid=fields[0],ppid=fields[1],elapsed=fields[2],cpuPercent=fields[3],commandName=Path(fields[4].split()[0]).name))
   data['processes']=rows
  elif isinstance(data,list):
   for r in data:
    if 'command'in r:r['commandName']=Path(r.pop('command')).name
  extras[str(f.relative_to(p))]=json.dumps(dict(fullLocalSHA256=original,sanitizedLoad=data),separators=(',',':')).encode()
extras['REPRODUCE.md']=b'Rebase local checkout/output paths. Use source base b3925191 and head c8936b9; Go1.27.3; LLGo114c98b4 O3/fullLTO/defaultGC; fixed-base old SDK2e3e02f4. build.json and reuse.json retain actual producer revisions and qualified byte-identical engine sources. Rebuild reusable binaries from their qualified sources with the common instrument_own harness, provenance labels, and compiler flags; build.py reconstructs changed-file overlays without source archives. Reference source/library/fixture hashes and commands are recorded. Prepare/hash/check all binaries before running six fixed blocks with no concurrent owned work. Core first attempt was aborted on WasmEdge AOT GC crashes; exclude it entirely from timing analysis. runtime-failures.json identifies exactly three sustained AOT failure cells; the remaining 33-case portfolio is remeasured in full, with no statistical extension. P3 completed independently before that failure and is unchanged. Analyze_core.py, analyze_p3.py and publish_evidence.py recreate summaries and phase medians. Raw projection removes only unused per-request vectors, preserving count/extrema/hash; no latency-tail inference. Unrelated desktop command arguments are omitted. Native C/Go controls are unchecked/host-only oracles, not equivalent runtimes. No source or SDK performance acceptance is implied by unresolved AA controls.\n'
protocol=dest/(stem+'-protocol.tar.gz')
with protocol.open('wb')as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for name in files:
  data=(p/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 for name,data in extras.items():
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
summary=dict(machine=json.loads((p/'machine.json').read_text()),qualification=json.loads((p/'qualification.json').read_text()),campaign=json.loads((p/'campaign.json').read_text()),firstCampaign=json.loads((p/'campaign-aborted.json').read_text()),builds=json.loads((p/'build.json').read_text()),core=core,p3=p3,failures=json.loads((p/'runtime-failures.json').read_text()),processCounts=counts,fullLocalRowsSHA256=sources,abortedCore=dict(sha256=sha(p/'core-aborted/rows.jsonl.gz'),scope='Incomplete attempt retained locally, excluded entirely from analysis.'),raw=dict(file=raw.name,sha256=sha(raw)),protocol=dict(file=protocol.name,sha256=sha(protocol)))
(dest/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
print('Verified and exported',counts,[(f.name,f.stat().st_size)for f in [raw,protocol,dest/(stem+'.json')]])
