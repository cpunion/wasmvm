from pathlib import Path
import json,gzip,random,statistics,math
P=Path(__file__).resolve().parent;rng=random.Random(202611169903);n=6;indices=[rng.choices(range(n),k=n)for _ in range(20000)]
def ratio(values):
 logs=[math.log(x)for x in values];samples=sorted(math.exp(sum(logs[i]for i in sample)/n)for sample in indices);return dict(ratio=math.exp(statistics.mean(logs)),ci95=[samples[500],samples[19499]])
result={}
for size in [16,65536]:
 folder=P/f'p3-{size}';rows=[json.loads(x)for x in gzip.open(folder/'rows.jsonl.gz','rt')];blocks={}
 for r in rows:assert r['id']not in blocks.setdefault(r['block'],{});blocks[r['block']][r['id']]=r
 assert len(blocks)==n;roles=sorted(name for name in blocks[0]if not name.endswith('-aa'));assert len(roles)==7 and all(set(block)==set(blocks[0])for block in blocks.values())
 metrics=['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest'];aa={}
 for role in roles:
  aa[role]={}
  for metric in metrics:
   if any(blocks[i][role][metric]<=0 or blocks[i][role+'-aa'][metric]<=0 for i in range(n)):continue
   value=ratio([blocks[i][role+'-aa'][metric]/blocks[i][role][metric]for i in range(n)]);value['resolves2_5Percent']=value['ci95'][0]>=.975 and value['ci95'][1]<=1.025;aa[role][metric]=value
 pairs=[('head-go','base-go'),('head-llgo','base-llgo'),('head-llgo','head-go'),('base-llgo','old-sdk-base-llgo'),('head-llgo','old-sdk-base-llgo')]+[(head,peer)for head in ['head-go','head-llgo']for peer in ['wasmtime','native-go']];comparisons={}
 for a,b in pairs:
  values={}
  for metric in metrics:
   # Managed counters omit Rust/C/JIT allocations; do not rank total engine
   # allocation against the independent native provider.
   if metric in ['allocsPerRequest','bytesPerRequest']and b in ['wasmtime','native-go']:continue
   if any(blocks[i][role][metric]<=0 for i in range(n)for role in [a,a+'-aa',b,b+'-aa']):
    values[metric]={'unavailable':'At least one counter is zero; no logarithmic ratio or total-allocation inference.'};continue
   value=ratio([math.sqrt(blocks[i][a][metric]*blocks[i][a+'-aa'][metric])/math.sqrt(blocks[i][b][metric]*blocks[i][b+'-aa'][metric])for i in range(n)])
   value['controlsResolve']=aa[a].get(metric,{}).get('resolves2_5Percent',False)and aa[b].get(metric,{}).get('resolves2_5Percent',False);values[metric]=value
  comparisons[a+'/'+b]=values
 medians={role:{metric:statistics.median(r[metric]for r in rows if r['id']in[role,role+'-aa'])for metric in metrics}for role in roles}
 phases={}
 for role in roles:
  selected=[r for r in rows if r['id']in[role,role+'-aa']];keys={k for r in selected for k in r['record'].get('phasesNs',{})};phases[role]={k:statistics.median(r['record']['phasesNs'][k]for r in selected if k in r['record'].get('phasesNs',{}))for k in keys};phases[role]['processStartup']=statistics.median(r['startupNs']for r in selected)
 result[str(size)]=dict(processes=len(rows),medians=medians,AA=aa,comparisons=comparisons,phasesMedianNs=phases)
 print('checked',size,len(rows),flush=True)
(P/'p3-analysis.json').write_text(json.dumps(dict(scope='Complete request/driver counters with mach timebase conversion, per-role symmetric AA and fixed-block marginal bootstrap95 intervals. Native-Go is a host overhead oracle without Component/WASI. No timing subtraction or cross-event pooling.',results=result),indent=2)+'\n')
