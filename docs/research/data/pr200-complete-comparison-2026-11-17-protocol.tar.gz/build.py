from pathlib import Path
import json,hashlib,subprocess,os,time,sys,re
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');R=W.parent/'wasmvm';P=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'benchmarks'));import own_build,routing_compare
GIT=lambda *args:subprocess.check_output(['git',*args],cwd=W)
head=GIT('rev-parse','c8936b9').decode().strip();base=GIT('rev-parse','b3925191').decode().strip()
assert not GIT('status','--porcelain')
assert not(P/'build.json').exists()
env=dict(os.environ,PATH='/opt/homebrew/Cellar/go/1.27.3/libexec/bin:/opt/homebrew/opt/llvm@22/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly',GOMAXPROCS='4',CGO_ENABLED='1',CC='/opt/homebrew/opt/llvm@22/bin/clang',LLGO_ROOT=str(W.parent/'llgo-external-link-options'))
llgo=R/'artifacts/components/llgo-114c98b4';assert '114c98b4d51d' in subprocess.check_output([str(llgo),'version'],env=env,text=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
changed=GIT('diff','--name-only',base,head,'--','*.go').decode().splitlines();base_map={};overlay_dir=P/'base-overrides';overlay_dir.mkdir()
for path in changed:
 if path.endswith('_test.go') or not path.startswith(('internal/','pkg/','cmd/')):continue
 current=W/path
 if not current.exists():raise ValueError('removed production file requires an explicit overlay audit: '+path)
 result=subprocess.run(['git','show',base+':'+path],cwd=W,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 data=result.stdout if result.returncode==0 else ('package '+re.search(r'^package (\w+)',current.read_text(),re.M)[1]+'\n').encode()
 target=overlay_dir/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);base_map[str(current)]=str(target)
result={'base':base,'head':head,'scope':'Pinned common harness; one checkout and changed-file overlays, no source archives/worktrees. No timing in this build step.','toolchains':{'go':subprocess.check_output(['go','version'],env=env,text=True).strip(),'llgo':subprocess.check_output([str(llgo),'version'],env=env,text=True).strip(),'llgoFlags':['-O3','-lto=full']},'builds':{}}
result['builds']=json.loads((P/'reuse.json').read_text())['builds']
for compiler,cmd in [('llgo',[str(llgo)])]:
 for role,revision in [('base',base)]:
  phase=routing_compare.instrument_own((W/'internal/bench/phase/phase.go').read_text())
  phase=phase.replace('var sourceRevision = "development"','var sourceRevision = '+json.dumps(revision)).replace('var compilerRevision = "development"','var compilerRevision = '+json.dumps('go1.27.3' if compiler=='go' else own_build.LLGO_REVISION))
  phase_file=P/(role+'-'+compiler+'-phase.go');phase_file.write_text(phase)
  provenance=P/(role+'-'+compiler+'-provenance.go');provenance.write_text('package phase\nconst SourceRevision = '+json.dumps(revision)+'\n')
  replacements=dict(base_map) if role=='base' else {}
  replacements[str(W/'internal/bench/phase/phase.go')]=str(phase_file);replacements[str(W/'internal/bench/phase/provenance_gen.go')]=str(provenance)
  overlay=P/(role+'-'+compiler+'-overlay.json');overlay.write_text(json.dumps({'Replace':replacements}))
  for kind,directory in [('phase',W/'benchmarks/embedded/wasmvm')]:
   name=role+'-'+compiler+'-'+kind;binary=P/name;command=cmd+['build']+([] if compiler=='go' else ['-O3','-lto=full'])+['-overlay',str(overlay),'-o',str(binary),'.'];started=time.monotonic()
   with (P/(name+'-build.log')).open('w') as log:subprocess.run(command,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=600)
   result['builds'][name]=dict(command=command,cwd=str(directory),source=revision,binary=str(binary),sha256=sha(binary),seconds=time.monotonic()-started,overlaySha256=sha(overlay),replacementSha256={k:sha(v)for k,v in replacements.items()})
   (P/'build.json').write_text(json.dumps(result,indent=2)+'\n');print('built',name,flush=True)
assert not GIT('status','--porcelain')
for name,row in result['builds'].items():
 assert sha(row['binary'])==row['sha256']
 row.setdefault('qualifiedEngineSource',base if 'base' in name else head)
 subprocess.run(['git','diff','--exit-code',row['source'],row['qualifiedEngineSource'],'--','internal','pkg','cmd','go.mod','go.sum',':(exclude)*_test.go'],cwd=W,check=True)
(P/'build.json').write_text(json.dumps(result,indent=2)+'\n')
(P/'build-complete.json').write_text(json.dumps({'head':head,'base':base,'builds':len(result['builds'])})+'\n')
