import json
from pathlib import Path

p = Path(__file__).resolve().parent
raw = json.loads((p.parent/"core-plan.json").read_text())
stats = json.loads((p.parent/"core-analysis.json").read_text())["results"]
cases = []
for entry in raw["cases"]:
    fixture = entry["fixture"]
    key = fixture["cohort"] + "/" + fixture["id"]
    commands = {}
    selected = {}
    for pair, comparison in stats[key]["comparisons"].items():
        if "/base-" not in pair:
            continue
        affected = key.endswith("narrow-unaligned") and "interpreter" in pair
        if comparison["ci95"][0] <= 1 and not affected:
            continue
        selected[pair] = comparison
        for role in pair.split("/"):
            command = entry["commands"][role].copy()
            command[command.index("--samples") + 1] = "6"
            commands[role] = command
    if commands:
        cases.append(dict(fixture=fixture,id=key,commands=commands,primary=selected))
assert sum(len(c["primary"])for c in cases)==12
plan = dict(blocks=6,samples=5,seed=202611218762,cases=cases,binarySHA256=raw["binarySHA256"],
            scope="Fresh exact-binary checks for every initially worse Core interval and both fixed narrow interpreter arms. Shared-thread timings use the same fixture and independent single-host-P counter replay.")
(p/"frozen-plan.json").write_text(json.dumps(plan,indent=2)+"\n")
