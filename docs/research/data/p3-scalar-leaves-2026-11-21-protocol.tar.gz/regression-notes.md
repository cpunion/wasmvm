## Independent diagnostics

The warm Go allocation profile uses 8,192 fully validated requests per payload.
The largest recorded 16 B allocation sites include reference allocation
(25.31 MiB), endpoint allocation (22 MiB), codecs (20 MiB), new host call
transactions (19.88 MiB), and component and Core callers (19.25 and 18.50 MiB).
This allocation profile uses a sample rate of one and forced collection at its
boundaries. It contributes no throughput or CPU observations.

The first transaction-frame version added ten allocations and around 320 bytes
per request relative to the scalar-leaf-only build. Go escape output attributes
the extra copies to the returned local and the separate storage target. Writing
the clone into its final storage and reusing frame-owned internal results removes
that regression. In the corrected screen, the 64 KiB instruction ratio versus
scalar leaves alone is 0.9961 [0.9925, 0.9994] with both A/A checks resolved.
The 16 B instruction interval crosses one. CPU and throughput controls in this
comparison remain unresolved.

A narrower native entry ABI experiment replaced two typed off-heap pointer
arguments with numeric addresses. Go assembly confirms elimination of two cgo
pointer checks per entry. It leaves the cgo transition itself in place. The
16 B instruction interval improves, while the 64 KiB instruction interval crosses
one and its throughput point is lower. The numeric ABI remains on its diagnostic
branch and is absent from the measured implementation.

Local Linux/amd64 Docker Go tests omit one stable-memory test after reproducing
the Rosetta address-space fatal error on the clean source base with the same
container. The exact test remains enabled in hosted CI. Local Go race and LLGo
preflight cover the affected packages. Hosted CI covers the full matrix.

### Native boundary and HTTP control

Wasmtime 48.0.1 emits typed trampolines for waitable operations that
call built-in runtime functions through the component context. Cranelift
passes these scalar arguments in registers, and the host libcall returns
through the guest activation. The measured wasmvm leaf path keeps the frame
and drops the public callback transaction. It still returns through the Go
native-entry driver for each such operation. The trace counts establish
the crossing frequency. A matched boundary-only benchmark is required to
attribute CPU time to this design difference.

- [Wasmtime 48.0.1 component trampoline generator](https://github.com/bytecodealliance/wasmtime/blob/v48.0.1/crates/cranelift/src/compiler/component.rs#L250-L289)
- [Wasmtime 48.0.1 component runtime builtins](https://github.com/bytecodealliance/wasmtime/blob/v48.0.1/crates/wasmtime/src/runtime/vm/component/libcalls.rs#L73-L101)

The native Go HTTP control materializes the incoming request body and outgoing
response body with two growing-buffer reads. The Wasmtime provider reuses
an immutable refcounted snapshot on request construction. The scoped
wasmvm runs use the immutable snapshot and buffered response API. The
native Go control is a separate HTTP path. Its 64 KiB CPU time cannot
be used as a lower bound on VM overhead.

- [Native Go control and benchmark response read](https://github.com/cpunion/wasmvm/blob/57e67995b4122ca8d73540eee525c804c12c6b55/benchmarks/p3io/main.go#L125-L174)
- [Wasmtime HTTP provider](https://github.com/cpunion/wasmvm/blob/57e67995b4122ca8d73540eee525c804c12c6b55/benchmarks/p3io/rust/src/lib.rs#L211-L250)


### Narrow memory investigation

The initial PR revision exposed a +3.09% CPU time increase in the LLGo
interpreter for narrow unaligned accesses. Retired instructions differed
by +0.002%, and cycles per instruction increased 3.30%. Matching the
interpreter loop address left a +3.03% increase in CPU time. The initial
report links both counter replays and the disassembly.

A scalar load descriptor records the width, extension shift and result mask.
The range helper validates both unsigned address additions and checks the
exclusive endpoint against the current logical size. Existing exhaustive
tests cover widths, signed results, carry, logical limits, and rejected stores.

The independent 288-process screen uses identical guest inputs and checksums
across both compilers, the initial PR build, and main. It reports **+1.37% CPU
speed** for Go and **+2.46%** for LLGo against main in the previously regressing
narrow case, with resolved A/A controls. The four fixtures each retire fewer
instructions with both compilers. The separate shape-only arm leaves the
LLGo narrow CPU interval crossing parity. The screen, its exact source
overlay, and initial diagnosis are archived independently from this report's
fresh full comparison.

- [Initial PR revision and adverse evidence](https://github.com/cpunion/wasmvm/blob/d4c62f8f790eb402119e309d20c21d7d78edd173/docs/research/performance-p3-scalar-leaves-2026-11-21.md)

### Earlier full-candidate follow-up

The independently rebuilt exact candidate passed a 408-process counter replay.
Go and LLGo respectively reduced CPU time in the narrow unaligned interpreter
by 0.71% and 2.58% versus main. Both controls resolved. The primary LLGo
empty-notify interval indicated a slowdown. The replay measured 1.47% lower
CPU time, alongside 0.44% fewer retired instructions.

The same replay resolves excess work in two call profiles. Go nested
interpretation uses 1.06% more CPU and retires 0.81% more instructions. LLGo
generic-call interpretation uses 0.96% more CPU and retires 0.31% more
instructions. Go interpretation of sustained GC indirect access uses 1.24%
more CPU and retires 0.003% more instructions. Its extra cycles remain a
separate observation. The source now classifies scalar descriptors only on the host path. An
independent 216-process screen removes 1.04% of Go nested-call instructions
and 0.83% of LLGo generic-call instructions relative to the previous source.
Both equivalent guest call profiles return to near the main branch's CPU
time. Narrow accesses retain their gains. The screen keeps CPU, wall time,
retired instructions and cycles separate.

### Final candidate verification

A fresh 288-process check investigates all ten unresolved adverse Core
intervals from the final primary event along with both narrow-memory
interpreter arms. Narrow-memory CPU speed improves 1.58% with Go and 2.81%
with LLGo against main. Both controls resolve. The adverse primary cases
remain unresolved in the replay. Go shared-memory interpreter CPU has a
+2.27% time point with unresolved controls and a resolved −0.26% retired
instruction change. The measured runtime cost there remains open.

A separate 96-process linker experiment examines GC indirect access. The
sustained Go interpreter's default-link CPU interval is +1.66%
[+1.04%, +2.29%]. With both source revisions linked at 64-byte
function alignment, the CPU difference is −0.24% [−0.60%, +0.31%].
Retired instructions match within 0.01% in both comparisons. The linker
intervention moves several code and data addresses. It identifies layout
sensitivity and leaves the exact microarchitectural cause open. The primary
matrix uses the default linker.
