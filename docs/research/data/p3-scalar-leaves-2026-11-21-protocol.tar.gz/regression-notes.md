## Independent diagnostics

The warm Go allocation profile uses 8,192 fully validated requests per payload.
The largest recorded 16 B allocation sites include reference allocation
(25.31 MiB), endpoint allocation (22 MiB), codecs (20 MiB), new host call
transactions (19.88 MiB), and component and Core callers (19.25 and 18.50 MiB).
This allocation profile uses a sample rate of one and forced collection at its
boundaries. It contributes no throughput or CPU observations.

The first transaction-frame version added ten allocations and around 320 bytes
per request relative to the scalar-leaf-only build. Go escape output attributes
the extra copies to the returned local and the separate storage target. Writing
the clone into its final storage and reusing frame-owned internal results removes
that regression. In the corrected screen, the 64 KiB instruction ratio versus
scalar leaves alone is 0.9961 [0.9925, 0.9994] with both A/A checks resolved.
The 16 B instruction interval crosses one. CPU and throughput controls in this
comparison remain unresolved.

A narrower native entry ABI experiment replaced two typed off-heap pointer
arguments with numeric addresses. Go assembly confirms elimination of two cgo
pointer checks per entry. It leaves the cgo transition itself in place. The
16 B instruction interval improves, while the 64 KiB instruction interval crosses
one and its throughput point is lower. The numeric ABI remains on its diagnostic
branch and is absent from the measured implementation.

Local Linux/amd64 Docker Go tests omit one stable-memory test after reproducing
the Rosetta address-space fatal error on the clean source base with the same
container. The exact test remains enabled in hosted CI. Local Go race and LLGo
preflight cover the affected packages. Hosted CI covers the full matrix.

### Native boundary and HTTP control

Wasmtime 48.0.1 emits typed trampolines for waitable operations that
call built-in runtime functions through the component context. Cranelift
passes these scalar arguments in registers, and the host libcall returns
through the guest activation. The measured wasmvm leaf path keeps the frame
and drops the public callback transaction. It still returns through the Go
native-entry driver for each such operation. The trace counts establish
the crossing frequency. A matched boundary-only benchmark is required to
attribute CPU time to this design difference.

- [Wasmtime 48.0.1 component trampoline generator](https://github.com/bytecodealliance/wasmtime/blob/v48.0.1/crates/cranelift/src/compiler/component.rs#L250-L289)
- [Wasmtime 48.0.1 component runtime builtins](https://github.com/bytecodealliance/wasmtime/blob/v48.0.1/crates/wasmtime/src/runtime/vm/component/libcalls.rs#L73-L101)

The native Go HTTP control materializes the incoming request body and outgoing
response body with two growing-buffer reads. The Wasmtime provider reuses
an immutable refcounted snapshot on request construction. The scoped
wasmvm runs use the immutable snapshot and buffered response API. The
native Go control is a separate HTTP path. Its 64 KiB CPU time cannot
be used as a lower bound on VM overhead.

- [Native Go control and benchmark response read](https://github.com/cpunion/wasmvm/blob/57e67995b4122ca8d73540eee525c804c12c6b55/benchmarks/p3io/main.go#L125-L174)
- [Wasmtime HTTP provider](https://github.com/cpunion/wasmvm/blob/57e67995b4122ca8d73540eee525c804c12c6b55/benchmarks/p3io/rust/src/lib.rs#L211-L250)


### Core source replay

The primary Core event produced ten apparent source slowdowns. All ten had
unresolved same-binary controls. A separate 240-process replay checked those
ten intervals with CPU, retired-instruction and cycle counters on the exact
primary binaries. Only LLGo interpretation of narrow unaligned memory retained
a resolved higher CPU time.

| Narrow unaligned memory, LLGo interpreter | Head/base CPU time Δ | Head/base retired instructions Δ | Head/base cycles per instruction Δ |
| --- | ---: | ---: | ---: |
| Independent replay, original binaries | +3.09% [1.81%, 4.49%] | +0.002% [−0.015%, 0.026%] | +3.30% [2.29%, 4.32%] |
| Matched interpreter entry address | +3.03% [2.42%, 3.79%] | +0.000% [−0.002%, 0.001%] | +3.24% [2.66%, 3.76%] |

The default links emit 2,052 instructions and the same opcode sequence in
`runSlotsLoop`. The changed encodings occur at linked data references and
call sites. The second replay reordered six interpreter and memory functions
for both sources. Both `runSlotsLoop` entries landed at `0x100000a40`.
The integer-loop signal flipped direction with that intervention. The
unaligned-memory signal persisted, and some callee and data locations still
differ. The exact cause of the extra cycles remains open. The contribution
remains under review pending resolution. Both diagnostic replays and the
disassembly are archived separately from the primary event.
