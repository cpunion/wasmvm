from pathlib import Path
import json
import re
import subprocess
import sys

p = Path(__file__).resolve().parent
root = Path("/Users/lijie/source/goplus/wasmvm-source-cleanup")
build = json.loads((p/"build.json").read_text())
done = json.loads((p/"build-complete.json").read_text())
assert done["builds"] == 8 and done["head"] == build["head"]
assert len(json.loads((p/"runtime-failures.json").read_text())["failures"]) == 3
assert len(json.loads((p/"capability-smoke.json").read_text())["checks"]) == 322
assert json.loads((p/"core2.json").read_text())["passed"]
ci = (root/".github/workflows/ci.yml").read_text()
gate = ci.split("name: Enforce per-package core coverage",1)[1].split("name: Preserve core coverage",1)[0]
packages = re.findall(r"--require (github\.com/cpunion/wasmvm/\S+)",gate)
assert len(packages)>=25
command=[sys.executable,str(root/"scripts/check_coverage.py"),str(p/"coverage.out"),"--minimum","90"]
for package in packages:
    command.extend(["--require",package])
with (p/"coverage-gates.log").open("w") as record:
    subprocess.run(command,stdout=record,stderr=subprocess.STDOUT,check=True)
record={
    "sourceBase": build["base"], "measuredHead": build["head"],
    "benchmarkLLGo": "3c6b33ecc62036b69605fa6492f27f97f858e47a",
    "independentLatestLLGo": (p/"latest-sdk/version.log").read_text().split()[1].removeprefix("devel-"),
    "engineInputsVerified": True, "referenceBinaryHashesVerified": True,
    "reusedBinaries": [dict(role=k,producer=v["source"],qualified=v["qualifiedEngineSource"]) for k,v in build["builds"].items() if "qualifiedEngineSource"in v],
    "validation": {
        "darwinArm64Go": "all internal and public package suites with cross-package coverage and Core 2 report",
        "darwinArm64LLGo": "state, execute, nativeexec, memory, vm, component and Preview 3",
        "darwinArm64LatestLLGo": "independent compatibility check on 19a6779f with execute, vm, component and Preview 3 tests",
        "linuxAMD64DockerGo": "native, execute, nativeexec, memory, vm, component and Preview 3. Stable-memory Rosetta reproducer archived on main and omitted from this local check only.",
        "quality": "all coverage gates, scoped race, vet, cgocheck2, 98 benchmark unit tests"
    }
}
(p/"qualification.json").write_text(json.dumps(record,indent=2)+"\n")
print("Qualified",build["head"])
