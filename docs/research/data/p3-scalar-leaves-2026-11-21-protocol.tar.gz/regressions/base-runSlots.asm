
/Users/lijie/source/goplus/wasmvm/artifacts/sha-hot-path-20261121/full/head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000385e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlots>:
1000385e0: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
1000385e4: a9017bfd    	stp	x29, x30, [sp, #0x10]
1000385e8: 910043fd    	add	x29, sp, #0x10
1000385ec: f940ac01    	ldr	x1, [x0, #0x158]
1000385f0: aa0003f3    	mov	x19, x0
1000385f4: 97ffdc5c    	bl	0x10002f764 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>
1000385f8: a9417bfd    	ldp	x29, x30, [sp, #0x10]
1000385fc: f900ae61    	str	x1, [x19, #0x158]
100038600: a8c24ff4    	ldp	x20, x19, [sp], #0x20
100038604: d65f03c0    	ret
