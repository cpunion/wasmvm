
/Users/lijie/source/goplus/wasmvm/artifacts/sha-hot-path-20261121/full/head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000325ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>:
1000325ac: d10783ff    	sub	sp, sp, #0x1e0
1000325b0: a9186ffc    	stp	x28, x27, [sp, #0x180]
1000325b4: a91967fa    	stp	x26, x25, [sp, #0x190]
1000325b8: a91a5ff8    	stp	x24, x23, [sp, #0x1a0]
1000325bc: a91b57f6    	stp	x22, x21, [sp, #0x1b0]
1000325c0: a91c4ff4    	stp	x20, x19, [sp, #0x1c0]
1000325c4: a91d7bfd    	stp	x29, x30, [sp, #0x1d0]
1000325c8: 910743fd    	add	x29, sp, #0x1d0
1000325cc: b4002220    	cbz	x0, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000325d0: f9402408    	ldr	x8, [x0, #0x48]
1000325d4: d1000514    	sub	x20, x8, #0x1
1000325d8: b4004f88    	cbz	x8, 0x100032fc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa1c>
1000325dc: f9402008    	ldr	x8, [x0, #0x40]
1000325e0: ab141916    	adds	x22, x8, x20, lsl #6
1000325e4: 54002160    	b.eq	0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000325e8: f94002dc    	ldr	x28, [x22]
1000325ec: b400213c    	cbz	x28, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000325f0: f9402799    	ldr	x25, [x28, #0x48]
1000325f4: b40020f9    	cbz	x25, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000325f8: b9400acb    	ldr	w11, [x22, #0x8]
1000325fc: f9405f21    	ldr	x1, [x25, #0xb8]
100032600: eb0b003f    	cmp	x1, x11
100032604: 54004ec9    	b.ls	0x100032fdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa30>
100032608: f9400ec8    	ldr	x8, [x22, #0x18]
10003260c: f9404f2e    	ldr	x14, [x25, #0x98]
100032610: f9404402    	ldr	x2, [x0, #0x88]
100032614: f90027e8    	str	x8, [sp, #0x48]
100032618: 8b0801c8    	add	x8, x14, x8
10003261c: eb02011f    	cmp	x8, x2
100032620: 54004e28    	b.hi	0x100032fe4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa38>
100032624: f94027e9    	ldr	x9, [sp, #0x48]
100032628: eb08013f    	cmp	x9, x8
10003262c: 54004e48    	b.hi	0x100032ff4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa48>
100032630: f9405b28    	ldr	x8, [x25, #0xb0]
100032634: f94027e9    	ldr	x9, [sp, #0x48]
100032638: f9403c18    	ldr	x24, [x0, #0x78]
10003263c: f940238d    	ldr	x13, [x28, #0x40]
100032640: f9001beb    	str	x11, [sp, #0x30]
100032644: 8b0b1515    	add	x21, x8, x11, lsl #5
100032648: cb090048    	sub	x8, x2, x9
10003264c: d37ced2a    	lsl	x10, x9, #4
100032650: f100011f    	cmp	x8, #0x0
100032654: f9400329    	ldr	x9, [x25]
100032658: 294022ba    	ldp	w26, w8, [x21]
10003265c: 9a9fc15b    	csel	x27, x10, xzr, gt
100032660: b4000109    	cbz	x9, 0x100032680 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xd4>
100032664: f9400521    	ldr	x1, [x9, #0x8]
100032668: eb08003f    	cmp	x1, x8
10003266c: 54004b49    	b.ls	0x100032fd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa28>
100032670: 52800f0a    	mov	w10, #0x78              ; =120
100032674: f9400129    	ldr	x9, [x9]
100032678: 9baa2508    	umaddl	x8, w8, w10, x9
10003267c: 14000008    	b	0x10003269c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xf0>
100032680: f9404321    	ldr	x1, [x25, #0x80]
100032684: eb08003f    	cmp	x1, x8
100032688: 54004a69    	b.ls	0x100032fd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa28>
10003268c: 52801c09    	mov	w9, #0xe0               ; =224
100032690: f9403f2a    	ldr	x10, [x25, #0x78]
100032694: 9ba92908    	umaddl	x8, w8, w9, x10
100032698: b4001548    	cbz	x8, 0x100032940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x394>
10003269c: f9400904    	ldr	x4, [x8, #0x10]
1000326a0: 294346a8    	ldp	w8, w17, [x21, #0x18]
1000326a4: f9406f22    	ldr	x2, [x25, #0xd8]
1000326a8: 71005b5f    	cmp	w26, #0x16
1000326ac: 1a9f27e3    	cset	w3, lo
1000326b0: 0b110109    	add	w9, w8, w17
1000326b4: eb09005f    	cmp	x2, x9
1000326b8: 54004a83    	b.lo	0x100033008 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa5c>
1000326bc: 6b09011f    	cmp	w8, w9
1000326c0: 54004ac8    	b.hi	0x100033018 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa6c>
1000326c4: cb080050    	sub	x16, x2, x8
1000326c8: d37ef50a    	lsl	x10, x8, #2
1000326cc: f940672b    	ldr	x11, [x25, #0xc8]
1000326d0: f100021f    	cmp	x16, #0x0
1000326d4: 5100534c    	sub	w12, w26, #0x14
1000326d8: 8b1b0313    	add	x19, x24, x27
1000326dc: 9a9fc14a    	csel	x10, x10, xzr, gt
1000326e0: 7100099f    	cmp	w12, #0x2
1000326e4: cb080128    	sub	x8, x9, x8
1000326e8: 8b0a016f    	add	x15, x11, x10
1000326ec: f90023e8    	str	x8, [sp, #0x40]
1000326f0: 54000243    	b.lo	0x100032738 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x18c>
1000326f4: 7100435f    	cmp	w26, #0x10
1000326f8: 54000060    	b.eq	0x100032704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x158>
1000326fc: 71004b5f    	cmp	w26, #0x12
100032700: 54000581    	b.ne	0x1000327b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x204>
100032704: b400186d    	cbz	x13, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
100032708: f94025a1    	ldr	x1, [x13, #0x48]
10003270c: 2a0403e8    	mov	w8, w4
100032710: eb01011f    	cmp	x8, x1
100032714: 54004602    	b.hs	0x100032fd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa28>
100032718: f94021a9    	ldr	x9, [x13, #0x40]
10003271c: f8687928    	ldr	x8, [x9, x8, lsl #3]
100032720: 2a1103e9    	mov	w9, w17
100032724: f90017e9    	str	x9, [sp, #0x28]
100032728: b4000388    	cbz	x8, 0x100032798 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1ec>
10003272c: f9400009    	ldr	x9, [x0]
100032730: 2a1103ea    	mov	w10, w17
100032734: 1400000c    	b	0x100032764 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1b8>
100032738: f94023e8    	ldr	x8, [sp, #0x40]
10003273c: 5100062a    	sub	w10, w17, #0x1
100032740: eb0a011f    	cmp	x8, x10
100032744: 540047a9    	b.ls	0x100033038 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa8c>
100032748: b86a79e8    	ldr	w8, [x15, x10, lsl #2]
10003274c: eb0801df    	cmp	x14, x8
100032750: 540046e9    	b.ls	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa80>
100032754: d37ced08    	lsl	x8, x8, #4
100032758: f8686a68    	ldr	x8, [x19, x8]
10003275c: b4000ea8    	cbz	x8, 0x100032930 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x384>
100032760: f9400009    	ldr	x9, [x0]
100032764: f90017ea    	str	x10, [sp, #0x28]
100032768: b4000629    	cbz	x9, 0x10003282c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x280>
10003276c: f9406d2a    	ldr	x10, [x9, #0xd8]
100032770: eb0a011f    	cmp	x8, x10
100032774: 54000122    	b.hs	0x100032798 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1ec>
100032778: f9406929    	ldr	x9, [x9, #0xd0]
10003277c: f868792a    	ldr	x10, [x9, x8, lsl #3]
100032780: b40000ca    	cbz	x10, 0x100032798 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1ec>
100032784: 52800028    	mov	w8, #0x1                ; =1
100032788: 36000088    	tbz	w8, #0x0, 0x100032798 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1ec>
10003278c: f9001fe0    	str	x0, [sp, #0x38]
100032790: b90007ff    	str	wzr, [sp, #0x4]
100032794: 14000039    	b	0x100032878 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x2cc>
100032798: d0001c48    	adrp	x8, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
10003279c: 9134c108    	add	x8, x8, #0xd30
1000327a0: a9400901    	ldp	x1, x2, [x8]
1000327a4: 97fff06a    	bl	0x10002e94c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
1000327a8: 52800074    	mov	w20, #0x3               ; =3
1000327ac: 1400009b    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
1000327b0: b400130d    	cbz	x13, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000327b4: d360fc88    	lsr	x8, x4, #32
1000327b8: f94031a1    	ldr	x1, [x13, #0x60]
1000327bc: eb01011f    	cmp	x8, x1
1000327c0: 540040a2    	b.hs	0x100032fd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa28>
1000327c4: f9402da9    	ldr	x9, [x13, #0x58]
1000327c8: ab080d28    	adds	x8, x9, x8, lsl #3
1000327cc: 54001220    	b.eq	0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000327d0: f940010a    	ldr	x10, [x8]
1000327d4: b40011ea    	cbz	x10, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
1000327d8: f94023e8    	ldr	x8, [sp, #0x40]
1000327dc: 51000629    	sub	w9, w17, #0x1
1000327e0: eb09011f    	cmp	x8, x9
1000327e4: 54004369    	b.ls	0x100033050 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaa4>
1000327e8: b86979e8    	ldr	w8, [x15, x9, lsl #2]
1000327ec: eb0801df    	cmp	x14, x8
1000327f0: 540041e9    	b.ls	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa80>
1000327f4: d37ced08    	lsl	x8, x8, #4
1000327f8: 3940a54b    	ldrb	w11, [x10, #0x29]
1000327fc: f8686a68    	ldr	x8, [x19, x8]
100032800: 7100017f    	cmp	w11, #0x0
100032804: f940214b    	ldr	x11, [x10, #0x40]
100032808: 2a0803ec    	mov	w12, w8
10003280c: 9a8c1108    	csel	x8, x8, x12, ne
100032810: eb0b011f    	cmp	x8, x11
100032814: 54001142    	b.hs	0x100032a3c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x490>
100032818: f9401d4a    	ldr	x10, [x10, #0x38]
10003281c: f8687948    	ldr	x8, [x10, x8, lsl #3]
100032820: b4001608    	cbz	x8, 0x100032ae0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x534>
100032824: 2a0903ea    	mov	w10, w9
100032828: 17ffffce    	b	0x100032760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1b4>
10003282c: f9001fe0    	str	x0, [sp, #0x38]
100032830: 52800020    	mov	w0, #0x1                ; =1
100032834: aa0d03f8    	mov	x24, x13
100032838: f90013f3    	str	x19, [sp, #0x20]
10003283c: aa0e03fb    	mov	x27, x14
100032840: aa1003f7    	mov	x23, x16
100032844: a900bff4    	stp	x20, x15, [sp, #0x8]
100032848: 2a0303f4    	mov	w20, w3
10003284c: aa0403f3    	mov	x19, x4
100032850: b9001bf1    	str	w17, [sp, #0x18]
100032854: 9407666f    	bl	0x10020c210 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100032858: 2a1403e3    	mov	w3, w20
10003285c: a940bff4    	ldp	x20, x15, [sp, #0x8]
100032860: aa1303e4    	mov	x4, x19
100032864: b9401bf1    	ldr	w17, [sp, #0x18]
100032868: f94013f3    	ldr	x19, [sp, #0x20]
10003286c: aa1703f0    	mov	x16, x23
100032870: aa1b03ee    	mov	x14, x27
100032874: aa1803ed    	mov	x13, x24
100032878: 7100575f    	cmp	w26, #0x15
10003287c: 54000428    	b.hi	0x100032900 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x354>
100032880: 52a00748    	mov	w8, #0x3a0000           ; =3801088
100032884: 1ada2508    	lsr	w8, w8, w26
100032888: 360003c8    	tbz	w8, #0x0, 0x100032900 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x354>
10003288c: b4000c2d    	cbz	x13, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
100032890: f94019a1    	ldr	x1, [x13, #0x30]
100032894: 2a0403e0    	mov	w0, w4
100032898: b9000be3    	str	w3, [sp, #0x8]
10003289c: b9001bf1    	str	w17, [sp, #0x18]
1000328a0: eb01001f    	cmp	x0, x1
1000328a4: f9000bf0    	str	x16, [sp, #0x10]
1000328a8: f90013f3    	str	x19, [sp, #0x20]
1000328ac: 54003d62    	b.hs	0x100033058 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaac>
1000328b0: f9401fe8    	ldr	x8, [sp, #0x38]
1000328b4: f94015a9    	ldr	x9, [x13, #0x28]
1000328b8: aa0f03f3    	mov	x19, x15
1000328bc: b9403941    	ldr	w1, [x10, #0x38]
1000328c0: aa0e03fb    	mov	x27, x14
1000328c4: aa0d03f8    	mov	x24, x13
1000328c8: f9400108    	ldr	x8, [x8]
1000328cc: b8607922    	ldr	w2, [x9, x0, lsl #2]
1000328d0: aa0a03f7    	mov	x23, x10
1000328d4: aa0803e0    	mov	x0, x8
1000328d8: 94003ece    	bl	0x100042410 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).FunctionSubtype>
1000328dc: aa1303ef    	mov	x15, x19
1000328e0: f94013f3    	ldr	x19, [sp, #0x20]
1000328e4: f9400bf0    	ldr	x16, [sp, #0x10]
1000328e8: b9401bf1    	ldr	w17, [sp, #0x18]
1000328ec: b9400be3    	ldr	w3, [sp, #0x8]
1000328f0: aa1703ea    	mov	x10, x23
1000328f4: aa1803ed    	mov	x13, x24
1000328f8: aa1b03ee    	mov	x14, x27
1000328fc: 36000360    	tbz	w0, #0x0, 0x100032968 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3bc>
100032900: 52a00588    	mov	w8, #0x2c0000           ; =2883584
100032904: 1ada2508    	lsr	w8, w8, w26
100032908: 0a080078    	and	w24, w3, w8
10003290c: 340003d8    	cbz	w24, 0x100032984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3d8>
100032910: a942e6c8    	ldp	x8, x25, [x22, #0x28]
100032914: 2a1103fa    	mov	w26, w17
100032918: aa0a03f7    	mov	x23, x10
10003291c: aa0f03fc    	mov	x28, x15
100032920: aa0e03fb    	mov	x27, x14
100032924: 910082d5    	add	x21, x22, #0x20
100032928: a90137f0    	stp	x16, x13, [sp, #0x10]
10003292c: 1400002b    	b	0x1000329d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x42c>
100032930: b94006a2    	ldr	w2, [x21, #0x4]
100032934: aa1c03e1    	mov	x1, x28
100032938: 52800123    	mov	w3, #0x9                ; =9
10003293c: 1400000f    	b	0x100032978 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3cc>
100032940: f9001fe0    	str	x0, [sp, #0x38]
100032944: 52800020    	mov	w0, #0x1                ; =1
100032948: aa0d03f3    	mov	x19, x13
10003294c: aa0e03f7    	mov	x23, x14
100032950: 94076630    	bl	0x10020c210 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100032954: f9401fe0    	ldr	x0, [sp, #0x38]
100032958: aa1703ee    	mov	x14, x23
10003295c: aa1303ed    	mov	x13, x19
100032960: aa1f03e4    	mov	x4, xzr
100032964: 17ffff4f    	b	0x1000326a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xf4>
100032968: b94006a2    	ldr	w2, [x21, #0x4]
10003296c: f9401fe0    	ldr	x0, [sp, #0x38]
100032970: aa1c03e1    	mov	x1, x28
100032974: 528000a3    	mov	w3, #0x5                ; =5
100032978: 94000637    	bl	0x100034254 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
10003297c: 52800074    	mov	w20, #0x3               ; =3
100032980: 14000026    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032984: b94007e8    	ldr	w8, [sp, #0x4]
100032988: 37000448    	tbnz	w8, #0x0, 0x100032a10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x464>
10003298c: 294326a8    	ldp	w8, w9, [x21, #0x18]
100032990: aa0a03f7    	mov	x23, x10
100032994: b940294a    	ldr	w10, [x10, #0x28]
100032998: f9406721    	ldr	x1, [x25, #0xc8]
10003299c: f9406f23    	ldr	x3, [x25, #0xd8]
1000329a0: 2a1f03e6    	mov	w6, wzr
1000329a4: 2a1f03e7    	mov	w7, wzr
1000329a8: 0b080124    	add	w4, w9, w8
1000329ac: 910383e0    	add	x0, sp, #0xe0
1000329b0: 52800082    	mov	w2, #0x4                ; =4
1000329b4: 0b0a0085    	add	w5, w4, w10
1000329b8: 2a1103fa    	mov	w26, w17
1000329bc: a90137f0    	stp	x16, x13, [sp, #0x10]
1000329c0: aa0f03fc    	mov	x28, x15
1000329c4: aa0e03fb    	mov	x27, x14
1000329c8: 390003ff    	strb	wzr, [sp]
1000329cc: 910383f5    	add	x21, sp, #0xe0
1000329d0: 94079e70    	bl	0x10021a390 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000329d4: a94ee7e8    	ldp	x8, x25, [sp, #0xe8]
1000329d8: f90013e8    	str	x8, [sp, #0x20]
1000329dc: f9401fe0    	ldr	x0, [sp, #0x38]
1000329e0: f94002b5    	ldr	x21, [x21]
1000329e4: 940005f2    	bl	0x1000341ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
1000329e8: b4000100    	cbz	x0, 0x100032a08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x45c>
1000329ec: f9400409    	ldr	x9, [x0, #0x8]
1000329f0: aa0003e8    	mov	x8, x0
1000329f4: b40000a9    	cbz	x9, 0x100032a08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x45c>
1000329f8: f9401fe0    	ldr	x0, [sp, #0x38]
1000329fc: aa0103e2    	mov	x2, x1
100032a00: aa0803e1    	mov	x1, x8
100032a04: 17ffff68    	b	0x1000327a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f8>
100032a08: b94007e8    	ldr	w8, [sp, #0x4]
100032a0c: 36000248    	tbz	w8, #0x0, 0x100032a54 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x4a8>
100032a10: 52800020    	mov	w0, #0x1                ; =1
100032a14: 940765ff    	bl	0x10020c210 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100032a18: 2a1403e0    	mov	w0, w20
100032a1c: a95d7bfd    	ldp	x29, x30, [sp, #0x1d0]
100032a20: a95c4ff4    	ldp	x20, x19, [sp, #0x1c0]
100032a24: a95b57f6    	ldp	x22, x21, [sp, #0x1b0]
100032a28: a95a5ff8    	ldp	x24, x23, [sp, #0x1a0]
100032a2c: a95967fa    	ldp	x26, x25, [sp, #0x190]
100032a30: a9586ffc    	ldp	x28, x27, [sp, #0x180]
100032a34: 910783ff    	add	sp, sp, #0x1e0
100032a38: d65f03c0    	ret
100032a3c: b94006a2    	ldr	w2, [x21, #0x4]
100032a40: aa1c03e1    	mov	x1, x28
100032a44: 52800063    	mov	w3, #0x3                ; =3
100032a48: 52800074    	mov	w20, #0x3               ; =3
100032a4c: 94000602    	bl	0x100034254 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
100032a50: 17fffff2    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032a54: f9402ee8    	ldr	x8, [x23, #0x58]
100032a58: f00014e9    	adrp	x9, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xd8>
100032a5c: 91066129    	add	x9, x9, #0x198
100032a60: aa1703ec    	mov	x12, x23
100032a64: eb09011f    	cmp	x8, x9
100032a68: 54000440    	b.eq	0x100032af0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x544>
100032a6c: f9401fe9    	ldr	x9, [sp, #0x38]
100032a70: f94017ea    	ldr	x10, [sp, #0x28]
100032a74: aa1b03e1    	mov	x1, x27
100032a78: 37000458    	tbnz	w24, #0x0, 0x100032b00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x554>
100032a7c: f9401beb    	ldr	x11, [sp, #0x30]
100032a80: f9415d2a    	ldr	x10, [x9, #0x2b8]
100032a84: aa1503f3    	mov	x19, x21
100032a88: 11000568    	add	w8, w11, #0x1
100032a8c: f9001eca    	str	x10, [x22, #0x38]
100032a90: 29012ec8    	stp	w8, w11, [x22, #0x8]
100032a94: 52800028    	mov	w8, #0x1                ; =1
100032a98: 390042c8    	strb	w8, [x22, #0x10]
100032a9c: f9402588    	ldr	x8, [x12, #0x48]
100032aa0: b4002168    	cbz	x8, 0x100032ecc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x920>
100032aa4: f94013e8    	ldr	x8, [sp, #0x20]
100032aa8: 910323e2    	add	x2, sp, #0xc8
100032aac: aa0903e0    	mov	x0, x9
100032ab0: aa0c03e1    	mov	x1, x12
100032ab4: f9006ff9    	str	x25, [sp, #0xd8]
100032ab8: aa0903f4    	mov	x20, x9
100032abc: a90ca3f3    	stp	x19, x8, [sp, #0xc8]
100032ac0: 94001325    	bl	0x100037754 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push>
100032ac4: b4001ca0    	cbz	x0, 0x100032e58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x8ac>
100032ac8: f9400409    	ldr	x9, [x0, #0x8]
100032acc: aa0003e8    	mov	x8, x0
100032ad0: b4001c49    	cbz	x9, 0x100032e58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x8ac>
100032ad4: aa0103e2    	mov	x2, x1
100032ad8: aa1403e0    	mov	x0, x20
100032adc: 17ffffc9    	b	0x100032a00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x454>
100032ae0: b94006a2    	ldr	w2, [x21, #0x4]
100032ae4: aa1c03e1    	mov	x1, x28
100032ae8: 52800083    	mov	w3, #0x4                ; =4
100032aec: 17ffffa3    	b	0x100032978 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3cc>
100032af0: f9401fe9    	ldr	x9, [sp, #0x38]
100032af4: f94017ea    	ldr	x10, [sp, #0x28]
100032af8: aa1b03e1    	mov	x1, x27
100032afc: 36000558    	tbz	w24, #0x0, 0x100032ba4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f8>
100032b00: f9402588    	ldr	x8, [x12, #0x48]
100032b04: aa1c03fb    	mov	x27, x28
100032b08: b40002e8    	cbz	x8, 0x100032b64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5b8>
100032b0c: f9404d08    	ldr	x8, [x8, #0x98]
100032b10: f94027eb    	ldr	x11, [sp, #0x48]
100032b14: b9401d2a    	ldr	w10, [x9, #0x1c]
100032b18: 8b0b0108    	add	x8, x8, x11
100032b1c: eb0a011f    	cmp	x8, x10
100032b20: f94017ea    	ldr	x10, [sp, #0x28]
100032b24: 54000209    	b.ls	0x100032b64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5b8>
100032b28: 52800500    	mov	w0, #0x28               ; =40
100032b2c: aa0903f3    	mov	x19, x9
100032b30: 9407652c    	bl	0x10020bfe0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
100032b34: d0001c48    	adrp	x8, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
100032b38: 52800229    	mov	w9, #0x11               ; =17
100032b3c: aa0003e2    	mov	x2, x0
100032b40: 3dc38500    	ldr	q0, [x8, #0xe10]
100032b44: f0001308    	adrp	x8, 0x100295000 <dyld_stub_binder+0x100295000>
100032b48: 9126f508    	add	x8, x8, #0x9bd
100032b4c: a901a408    	stp	x8, x9, [x0, #0x18]
100032b50: 900015e1    	adrp	x1, 0x1002ee000 <__llgo_github.com/cpunion/wasmvm/internal/core/validate.visitorFailure+0x68>
100032b54: 91216021    	add	x1, x1, #0x858
100032b58: 3d800000    	str	q0, [x0]
100032b5c: aa1303e0    	mov	x0, x19
100032b60: 17ffff11    	b	0x1000327a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f8>
100032b64: f9405d23    	ldr	x3, [x9, #0xb8]
100032b68: 2a0a03f8    	mov	w24, w10
100032b6c: aa0c03fc    	mov	x28, x12
100032b70: aa0103f7    	mov	x23, x1
100032b74: f90023f5    	str	x21, [sp, #0x40]
100032b78: eb18007f    	cmp	x3, x24
100032b7c: 5400030a    	b.ge	0x100032bdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x630>
100032b80: 9101a3e0    	add	x0, sp, #0x68
100032b84: aa1803e1    	mov	x1, x24
100032b88: aa1803e2    	mov	x2, x24
100032b8c: 52800203    	mov	w3, #0x10               ; =16
100032b90: 2a1f03e4    	mov	w4, wzr
100032b94: aa0903f5    	mov	x21, x9
100032b98: 9101a3f6    	add	x22, sp, #0x68
100032b9c: 940798f1    	bl	0x100218f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MakeSlice>
100032ba0: 1400001a    	b	0x100032c08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x65c>
100032ba4: aa1303f8    	mov	x24, x19
100032ba8: f9403193    	ldr	x19, [x12, #0x60]
100032bac: 39406268    	ldrb	w8, [x19, #0x18]
100032bb0: 36001ce8    	tbz	w8, #0x0, 0x100032f4c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9a0>
100032bb4: 3400269a    	cbz	w26, 0x100033084 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad8>
100032bb8: b9400380    	ldr	w0, [x28]
100032bbc: eb00003f    	cmp	x1, x0
100032bc0: 54002669    	b.ls	0x10003308c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae0>
100032bc4: d37cec08    	lsl	x8, x0, #4
100032bc8: aa1503f9    	mov	x25, x21
100032bcc: aa0103f5    	mov	x21, x1
100032bd0: aa0903f4    	mov	x20, x9
100032bd4: f8686b01    	ldr	x1, [x24, x8]
100032bd8: 140000e1    	b	0x100032f5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9b0>
100032bdc: f9405521    	ldr	x1, [x9, #0xa8]
100032be0: aa1f03e4    	mov	x4, xzr
100032be4: 2a1f03e7    	mov	w7, wzr
100032be8: d10363a0    	sub	x0, x29, #0xd8
100032bec: 52800202    	mov	w2, #0x10               ; =16
100032bf0: aa1803e5    	mov	x5, x24
100032bf4: 52800026    	mov	w6, #0x1                ; =1
100032bf8: aa0903f5    	mov	x21, x9
100032bfc: 390003ff    	strb	wzr, [sp]
100032c00: d10363b6    	sub	x22, x29, #0xd8
100032c04: 94079de3    	bl	0x10021a390 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100032c08: f94002c8    	ldr	x8, [x22]
100032c0c: 3cc082c0    	ldur	q0, [x22, #0x8]
100032c10: 910203e0    	add	x0, sp, #0x80
100032c14: f9400be3    	ldr	x3, [sp, #0x10]
100032c18: aa1b03e1    	mov	x1, x27
100032c1c: 52800082    	mov	w2, #0x4                ; =4
100032c20: aa1f03e4    	mov	x4, xzr
100032c24: aa1803e5    	mov	x5, x24
100032c28: 52800026    	mov	w6, #0x1                ; =1
100032c2c: 2a1f03e7    	mov	w7, wzr
100032c30: aa1503f6    	mov	x22, x21
100032c34: f90056a8    	str	x8, [x21, #0xa8]
100032c38: 3d802ea0    	str	q0, [x21, #0xb0]
100032c3c: 390003ff    	strb	wzr, [sp]
100032c40: 94079dd4    	bl	0x10021a390 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100032c44: f94047e9    	ldr	x9, [sp, #0x88]
100032c48: f100053f    	cmp	x9, #0x1
100032c4c: 5400020b    	b.lt	0x100032c8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x6e0>
100032c50: f94043ea    	ldr	x10, [sp, #0x80]
100032c54: aa1703ec    	mov	x12, x23
100032c58: aa1f03e0    	mov	x0, xzr
100032c5c: b8607948    	ldr	w8, [x10, x0, lsl #2]
100032c60: eb08019f    	cmp	x12, x8
100032c64: 54001f09    	b.ls	0x100033044 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa98>
100032c68: f9405ac1    	ldr	x1, [x22, #0xb0]
100032c6c: eb01001f    	cmp	x0, x1
100032c70: 540020e2    	b.hs	0x10003308c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae0>
100032c74: f94056cb    	ldr	x11, [x22, #0xa8]
100032c78: 3ce87a60    	ldr	q0, [x19, x8, lsl #4]
100032c7c: 3ca07960    	str	q0, [x11, x0, lsl #4]
100032c80: 91000400    	add	x0, x0, #0x1
100032c84: eb00013f    	cmp	x9, x0
100032c88: 54fffea1    	b.ne	0x100032c5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x6b0>
100032c8c: f9403ec1    	ldr	x1, [x22, #0x78]
100032c90: f94046c3    	ldr	x3, [x22, #0x88]
100032c94: d10303a0    	sub	x0, x29, #0xc0
100032c98: f94027e5    	ldr	x5, [sp, #0x48]
100032c9c: 52800202    	mov	w2, #0x10               ; =16
100032ca0: aa1f03e4    	mov	x4, xzr
100032ca4: 52800026    	mov	w6, #0x1                ; =1
100032ca8: 52800027    	mov	w7, #0x1                ; =1
100032cac: d10303b5    	sub	x21, x29, #0xc0
100032cb0: 390003ff    	strb	wzr, [sp]
100032cb4: 94079db7    	bl	0x10021a390 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100032cb8: f94026c1    	ldr	x1, [x22, #0x48]
100032cbc: f85403a9    	ldur	x9, [x29, #-0xc0]
100032cc0: 3cc082a0    	ldur	q0, [x21, #0x8]
100032cc4: eb01029f    	cmp	x20, x1
100032cc8: f9003ec9    	str	x9, [x22, #0x78]
100032ccc: 3d8022c0    	str	q0, [x22, #0x80]
100032cd0: 54001d62    	b.hs	0x10003307c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad0>
100032cd4: f94022c9    	ldr	x9, [x22, #0x40]
100032cd8: 6f00e400    	movi.2d	v0, #0000000000000000
100032cdc: d102a3a0    	sub	x0, x29, #0xa8
100032ce0: 52800802    	mov	w2, #0x40               ; =64
100032ce4: aa1f03e4    	mov	x4, xzr
100032ce8: aa1403e5    	mov	x5, x20
100032cec: 8b141929    	add	x9, x9, x20, lsl #6
100032cf0: 52800026    	mov	w6, #0x1                ; =1
100032cf4: 52800027    	mov	w7, #0x1                ; =1
100032cf8: ad000120    	stp	q0, q0, [x9]
100032cfc: ad010120    	stp	q0, q0, [x9, #0x20]
100032d00: f94022c1    	ldr	x1, [x22, #0x40]
100032d04: f9402ac3    	ldr	x3, [x22, #0x50]
100032d08: 390003ff    	strb	wzr, [sp]
100032d0c: 94079da1    	bl	0x10021a390 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100032d10: f85583a8    	ldur	x8, [x29, #-0xa8]
100032d14: 3cc202a0    	ldur	q0, [x21, #0x20]
100032d18: aa1603e0    	mov	x0, x22
100032d1c: aa1c03e1    	mov	x1, x28
100032d20: f90022c8    	str	x8, [x22, #0x40]
100032d24: 3c8482c0    	stur	q0, [x22, #0x48]
100032d28: f9402788    	ldr	x8, [x28, #0x48]
100032d2c: b4000548    	cbz	x8, 0x100032dd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x828>
100032d30: f94023e9    	ldr	x9, [sp, #0x40]
100032d34: f94013e8    	ldr	x8, [sp, #0x20]
100032d38: 910263e2    	add	x2, sp, #0x98
100032d3c: f90057f9    	str	x25, [sp, #0xa8]
100032d40: a909a3e9    	stp	x9, x8, [sp, #0x98]
100032d44: 94001284    	bl	0x100037754 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push>
100032d48: b40000e0    	cbz	x0, 0x100032d64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x7b8>
100032d4c: f9400409    	ldr	x9, [x0, #0x8]
100032d50: aa0003e8    	mov	x8, x0
100032d54: b4000089    	cbz	x9, 0x100032d64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x7b8>
100032d58: aa0103e2    	mov	x2, x1
100032d5c: aa1603e0    	mov	x0, x22
100032d60: 17ffff28    	b	0x100032a00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x454>
100032d64: a94796c1    	ldp	x1, x5, [x22, #0x78]
100032d68: d101e3a0    	sub	x0, x29, #0x78
100032d6c: f94046c3    	ldr	x3, [x22, #0x88]
100032d70: f94027e4    	ldr	x4, [sp, #0x48]
100032d74: 52800202    	mov	w2, #0x10               ; =16
100032d78: 52800026    	mov	w6, #0x1                ; =1
100032d7c: 52800027    	mov	w7, #0x1                ; =1
100032d80: 390003ff    	strb	wzr, [sp]
100032d84: 94079d83    	bl	0x10021a390 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100032d88: a94aa6c8    	ldp	x8, x9, [x22, #0xa8]
100032d8c: f85903aa    	ldur	x10, [x29, #-0x70]
100032d90: eb09015f    	cmp	x10, x9
100032d94: 9a89b14a    	csel	x10, x10, x9, lt
100032d98: f100055f    	cmp	x10, #0x1
100032d9c: 540000cb    	b.lt	0x100032db4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x808>
100032da0: f85883a0    	ldur	x0, [x29, #-0x78]
100032da4: d37ced42    	lsl	x2, x10, #4
100032da8: aa0803e1    	mov	x1, x8
100032dac: 9407b6f7    	bl	0x100220988 <dyld_stub_binder+0x100220988>
100032db0: f94056c8    	ldr	x8, [x22, #0xa8]
100032db4: aa1603e9    	mov	x9, x22
100032db8: f9405aca    	ldr	x10, [x22, #0xb0]
100032dbc: aa0803e0    	mov	x0, x8
100032dc0: aa0903f3    	mov	x19, x9
100032dc4: d37ced41    	lsl	x1, x10, #4
100032dc8: 9407b738    	bl	0x100220aa8 <dyld_stub_binder+0x100220aa8>
100032dcc: 2a1f03f4    	mov	w20, wzr
100032dd0: 1400001d    	b	0x100032e44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x898>
100032dd4: f9405803    	ldr	x3, [x0, #0xb0]
100032dd8: f9400fe2    	ldr	x2, [sp, #0x18]
100032ddc: d10243a8    	sub	x8, x29, #0x90
100032de0: aa1603e0    	mov	x0, x22
100032de4: 9400132a    	bl	0x100037a8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).prepareHost>
100032de8: a94aa6c8    	ldp	x8, x9, [x22, #0xa8]
100032dec: f85783aa    	ldur	x10, [x29, #-0x88]
100032df0: f94023f3    	ldr	x19, [sp, #0x40]
100032df4: eb09015f    	cmp	x10, x9
100032df8: 9a89b14a    	csel	x10, x10, x9, lt
100032dfc: f100055f    	cmp	x10, #0x1
100032e00: 540000cb    	b.lt	0x100032e18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x86c>
100032e04: f85703a0    	ldur	x0, [x29, #-0x90]
100032e08: d37ced42    	lsl	x2, x10, #4
100032e0c: aa0803e1    	mov	x1, x8
100032e10: 9407b6de    	bl	0x100220988 <dyld_stub_binder+0x100220988>
100032e14: f94056c8    	ldr	x8, [x22, #0xa8]
100032e18: aa1603e9    	mov	x9, x22
100032e1c: f9405aca    	ldr	x10, [x22, #0xb0]
100032e20: f94013eb    	ldr	x11, [sp, #0x20]
100032e24: 52800054    	mov	w20, #0x2               ; =2
100032e28: aa0803e0    	mov	x0, x8
100032e2c: f9009ad9    	str	x25, [x22, #0x130]
100032e30: d37ced41    	lsl	x1, x10, #4
100032e34: a9122ed3    	stp	x19, x11, [x22, #0x120]
100032e38: aa0903f3    	mov	x19, x9
100032e3c: 3904e2d4    	strb	w20, [x22, #0x138]
100032e40: 9407b71a    	bl	0x100220aa8 <dyld_stub_binder+0x100220aa8>
100032e44: 6f00e400    	movi.2d	v0, #0000000000000000
100032e48: 9102e268    	add	x8, x19, #0xb8
100032e4c: 4d408500    	ld1.d	{ v0 }[1], [x8]
100032e50: 3d802e60    	str	q0, [x19, #0xb0]
100032e54: 17fffef1    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032e58: f9402688    	ldr	x8, [x20, #0x48]
100032e5c: d1000500    	sub	x0, x8, #0x1
100032e60: b4001188    	cbz	x8, 0x100033090 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae4>
100032e64: f94017ea    	ldr	x10, [sp, #0x28]
100032e68: 34000aca    	cbz	w10, 0x100032fc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa14>
100032e6c: f9402288    	ldr	x8, [x20, #0x40]
100032e70: f94023eb    	ldr	x11, [sp, #0x40]
100032e74: aa1403e9    	mov	x9, x20
100032e78: 2a0a03ea    	mov	w10, w10
100032e7c: 8b001908    	add	x8, x8, x0, lsl #6
100032e80: f9400d00    	ldr	x0, [x8, #0x18]
100032e84: b4000ecb    	cbz	x11, 0x10003305c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xab0>
100032e88: b8404788    	ldr	w8, [x28], #0x4
100032e8c: f94027ec    	ldr	x12, [sp, #0x48]
100032e90: f9404121    	ldr	x1, [x9, #0x80]
100032e94: 8b080188    	add	x8, x12, x8
100032e98: eb01011f    	cmp	x8, x1
100032e9c: 54000e62    	b.hs	0x100033068 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xabc>
100032ea0: eb01001f    	cmp	x0, x1
100032ea4: 54000f42    	b.hs	0x10003308c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae0>
100032ea8: f9403d2c    	ldr	x12, [x9, #0x78]
100032eac: 2a1f03f4    	mov	w20, wzr
100032eb0: d100054a    	sub	x10, x10, #0x1
100032eb4: d100056b    	sub	x11, x11, #0x1
100032eb8: 3ce87980    	ldr	q0, [x12, x8, lsl #4]
100032ebc: 3ca07980    	str	q0, [x12, x0, lsl #4]
100032ec0: 91000400    	add	x0, x0, #0x1
100032ec4: b5fffe0a    	cbnz	x10, 0x100032e84 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x8d8>
100032ec8: 17fffed4    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032ecc: f94017e8    	ldr	x8, [sp, #0x28]
100032ed0: f9400fe2    	ldr	x2, [sp, #0x18]
100032ed4: aa0903e0    	mov	x0, x9
100032ed8: aa0c03e1    	mov	x1, x12
100032edc: aa0903f4    	mov	x20, x9
100032ee0: 2a0803e3    	mov	w3, w8
100032ee4: 9102c3e8    	add	x8, sp, #0xb0
100032ee8: 940012e9    	bl	0x100037a8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).prepareHost>
100032eec: f9405fe9    	ldr	x9, [sp, #0xb8]
100032ef0: aa1403e8    	mov	x8, x20
100032ef4: f100053f    	cmp	x9, #0x1
100032ef8: 540001eb    	b.lt	0x100032f34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x988>
100032efc: a94437eb    	ldp	x11, x13, [sp, #0x40]
100032f00: f9405bea    	ldr	x10, [sp, #0xb0]
100032f04: b4000b6b    	cbz	x11, 0x100033070 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xac4>
100032f08: b840478c    	ldr	w12, [x28], #0x4
100032f0c: f9404101    	ldr	x1, [x8, #0x80]
100032f10: 8b0c01a0    	add	x0, x13, x12
100032f14: eb01001f    	cmp	x0, x1
100032f18: 54000ba2    	b.hs	0x10003308c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae0>
100032f1c: f9403d0c    	ldr	x12, [x8, #0x78]
100032f20: d1000529    	sub	x9, x9, #0x1
100032f24: d100056b    	sub	x11, x11, #0x1
100032f28: 3ce07980    	ldr	q0, [x12, x0, lsl #4]
100032f2c: 3c810540    	str	q0, [x10], #0x10
100032f30: b5fffea9    	cbnz	x9, 0x100032f04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x958>
100032f34: f94013e9    	ldr	x9, [sp, #0x20]
100032f38: 52800054    	mov	w20, #0x2               ; =2
100032f3c: f9009919    	str	x25, [x8, #0x130]
100032f40: 3904e114    	strb	w20, [x8, #0x138]
100032f44: a9122513    	stp	x19, x9, [x8, #0x120]
100032f48: 17fffeb4    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032f4c: aa1503f9    	mov	x25, x21
100032f50: aa0103f5    	mov	x21, x1
100032f54: aa0903f4    	mov	x20, x9
100032f58: aa1f03e1    	mov	x1, xzr
100032f5c: f9401bf7    	ldr	x23, [sp, #0x30]
100032f60: 910143e8    	add	x8, sp, #0x50
100032f64: aa1303e0    	mov	x0, x19
100032f68: 94004692    	bl	0x1000449b0 <_github.com/cpunion/wasmvm/internal/engine/state.(*ScalarAccess).Access>
100032f6c: a94507e8    	ldp	x8, x1, [sp, #0x50]
100032f70: b40000c1    	cbz	x1, 0x100032f88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9dc>
100032f74: f9400429    	ldr	x9, [x1, #0x8]
100032f78: b4000089    	cbz	x9, 0x100032f88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9dc>
100032f7c: f94033e2    	ldr	x2, [sp, #0x60]
100032f80: aa1403e0    	mov	x0, x20
100032f84: 17fffe08    	b	0x1000327a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f8>
100032f88: 39406269    	ldrb	w9, [x19, #0x18]
100032f8c: 37000129    	tbnz	w9, #0x0, 0x100032fb0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa04>
100032f90: f94013e9    	ldr	x9, [sp, #0x20]
100032f94: b4000789    	cbz	x9, 0x100033084 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad8>
100032f98: b9400320    	ldr	w0, [x25]
100032f9c: aa1503e1    	mov	x1, x21
100032fa0: eb0002bf    	cmp	x21, x0
100032fa4: 54000749    	b.ls	0x10003308c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae0>
100032fa8: 8b001309    	add	x9, x24, x0, lsl #4
100032fac: a9007d28    	stp	x8, xzr, [x9]
100032fb0: 110006e8    	add	w8, w23, #0x1
100032fb4: 2a1f03f4    	mov	w20, wzr
100032fb8: b9000ac8    	str	w8, [x22, #0x8]
100032fbc: 17fffe97    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032fc0: 2a1f03f4    	mov	w20, wzr
100032fc4: 17fffe95    	b	0x100032a18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x46c>
100032fc8: aa1403e0    	mov	x0, x20
100032fcc: aa1f03e1    	mov	x1, xzr
100032fd0: 94075381    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100032fd4: aa0803e0    	mov	x0, x8
100032fd8: 940758ec    	bl	0x100209388 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100032fdc: aa0b03e0    	mov	x0, x11
100032fe0: 940758ea    	bl	0x100209388 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100032fe4: aa0803e0    	mov	x0, x8
100032fe8: 52800021    	mov	w1, #0x1                ; =1
100032fec: 52800043    	mov	w3, #0x2                ; =2
100032ff0: 940756bf    	bl	0x100208aec <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100032ff4: f94027e0    	ldr	x0, [sp, #0x48]
100032ff8: 52800021    	mov	w1, #0x1                ; =1
100032ffc: aa0803e2    	mov	x2, x8
100033000: 52800063    	mov	w3, #0x3                ; =3
100033004: 940756ba    	bl	0x100208aec <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033008: aa0903e0    	mov	x0, x9
10003300c: 2a1f03e1    	mov	w1, wzr
100033010: 52800043    	mov	w3, #0x2                ; =2
100033014: 940756b6    	bl	0x100208aec <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033018: aa0803e0    	mov	x0, x8
10003301c: 2a1f03e1    	mov	w1, wzr
100033020: aa0903e2    	mov	x2, x9
100033024: 52800063    	mov	w3, #0x3                ; =3
100033028: 940756b1    	bl	0x100208aec <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003302c: aa0803e0    	mov	x0, x8
100033030: aa0e03e1    	mov	x1, x14
100033034: 94075368    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033038: f94023e1    	ldr	x1, [sp, #0x40]
10003303c: aa0a03e0    	mov	x0, x10
100033040: 940758d2    	bl	0x100209388 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033044: aa0803e0    	mov	x0, x8
100033048: aa0c03e1    	mov	x1, x12
10003304c: 94075362    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033050: f94023e1    	ldr	x1, [sp, #0x40]
100033054: aa0903e0    	mov	x0, x9
100033058: 940758cc    	bl	0x100209388 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003305c: f94023e0    	ldr	x0, [sp, #0x40]
100033060: aa0003e1    	mov	x1, x0
100033064: 940758c9    	bl	0x100209388 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033068: aa0803e0    	mov	x0, x8
10003306c: 9407535a    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033070: f94023e0    	ldr	x0, [sp, #0x40]
100033074: aa0003e1    	mov	x1, x0
100033078: 94075357    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003307c: aa1403e0    	mov	x0, x20
100033080: 94075355    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033084: aa1f03e0    	mov	x0, xzr
100033088: aa1f03e1    	mov	x1, xzr
10003308c: 94075352    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033090: aa1f03e1    	mov	x1, xzr
100033094: 94075350    	bl	0x100207dd4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
