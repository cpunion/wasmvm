
/Users/lijie/source/goplus/wasmvm/artifacts/p3-leaf-boundaries-20261121/full/head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010002ffe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>:
10002ffe8: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10002ffec: a90167fa    	stp	x26, x25, [sp, #0x10]
10002fff0: a9025ff8    	stp	x24, x23, [sp, #0x20]
10002fff4: a90357f6    	stp	x22, x21, [sp, #0x30]
10002fff8: a9044ff4    	stp	x20, x19, [sp, #0x40]
10002fffc: a9057bfd    	stp	x29, x30, [sp, #0x50]
100030000: 910143fd    	add	x29, sp, #0x50
100030004: d10743ff    	sub	sp, sp, #0x1d0
100030008: b400e9c0    	cbz	x0, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003000c: f9402408    	ldr	x8, [x0, #0x48]
100030010: aa0003f5    	mov	x21, x0
100030014: f100051f    	cmp	x8, #0x1
100030018: 5400fceb    	b.lt	0x100031fb4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
10003001c: 394082bb    	ldrb	w27, [x21, #0x20]
100030020: aa0103f3    	mov	x19, x1
100030024: b90027fb    	str	w27, [sp, #0x24]
100030028: f94022a9    	ldr	x9, [x21, #0x40]
10003002c: 8b081929    	add	x9, x9, x8, lsl #6
100030030: aa0903e8    	mov	x8, x9
100030034: f9001be9    	str	x9, [sp, #0x30]
100030038: f85c0d0a    	ldr	x10, [x8, #-0x40]!
10003003c: 381d013f    	sturb	wzr, [x9, #-0x30]
100030040: b400e808    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030044: b400e7ea    	cbz	x10, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030048: f940254f    	ldr	x15, [x10, #0x48]
10003004c: b400e7af    	cbz	x15, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030050: f9401be8    	ldr	x8, [sp, #0x30]
100030054: f9404df4    	ldr	x20, [x15, #0x98]
100030058: f94046a2    	ldr	x2, [x21, #0x88]
10003005c: f85d8108    	ldur	x8, [x8, #-0x28]
100030060: 8b080289    	add	x9, x20, x8
100030064: eb02013f    	cmp	x9, x2
100030068: 5400f548    	b.hi	0x100031f10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
10003006c: eb09011f    	cmp	x8, x9
100030070: 5400f468    	b.hi	0x100031efc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f14>
100030074: f9401be9    	ldr	x9, [sp, #0x30]
100030078: f9405df6    	ldr	x22, [x15, #0xb8]
10003007c: b85c8120    	ldur	w0, [x9, #-0x38]
100030080: cb080049    	sub	x9, x2, x8
100030084: d37ced08    	lsl	x8, x8, #4
100030088: f100013f    	cmp	x9, #0x0
10003008c: 9a9fc108    	csel	x8, x8, xzr, gt
100030090: eb0002df    	cmp	x22, x0
100030094: 5400f209    	b.ls	0x100031ed4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
100030098: f9403ea9    	ldr	x9, [x21, #0x78]
10003009c: f94059fa    	ldr	x26, [x15, #0xb0]
1000300a0: 2a0003f8    	mov	w24, w0
1000300a4: f9000fea    	str	x10, [sp, #0x18]
1000300a8: f940214a    	ldr	x10, [x10, #0x40]
1000300ac: 8b080137    	add	x23, x9, x8
1000300b0: f9001fef    	str	x15, [sp, #0x38]
1000300b4: f90017ea    	str	x10, [sp, #0x28]
1000300b8: 14000006    	b	0x1000300d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe8>
1000300bc: 1100071c    	add	w28, w24, #0x1
1000300c0: 2a1c03e0    	mov	w0, w28
1000300c4: 2a1c03f8    	mov	w24, w28
1000300c8: eb0002df    	cmp	x22, x0
1000300cc: 5400f049    	b.ls	0x100031ed4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
1000300d0: 8b00175c    	add	x28, x26, x0, lsl #5
1000300d4: 3600021b    	tbz	w27, #0x0, 0x100030114 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x12c>
1000300d8: f94041e1    	ldr	x1, [x15, #0x80]
1000300dc: b9400780    	ldr	w0, [x28, #0x4]
1000300e0: eb00003f    	cmp	x1, x0
1000300e4: 5400efa9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000300e8: 52801c09    	mov	w9, #0xe0               ; =224
1000300ec: f9403de8    	ldr	x8, [x15, #0x78]
1000300f0: 9ba92019    	umaddl	x25, w0, w9, x8
1000300f4: b9400328    	ldr	w8, [x25]
1000300f8: 7100151f    	cmp	w8, #0x5
1000300fc: 7a4b1904    	ccmp	w8, #0xb, #0x4, ne
100030100: f940aaa8    	ldr	x8, [x21, #0x150]
100030104: 1a9f07e9    	cset	w9, ne
100030108: eb090108    	subs	x8, x8, x9
10003010c: 5400e223    	b.lo	0x100031d50 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d68>
100030110: f900aaa8    	str	x8, [x21, #0x150]
100030114: 91000673    	add	x19, x19, #0x1
100030118: f240167f    	tst	x19, #0x3f
10003011c: 54000381    	b.ne	0x10003018c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
100030120: f940b2a8    	ldr	x8, [x21, #0x160]
100030124: b4000068    	cbz	x8, 0x100030130 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x148>
100030128: 88dffd08    	ldar	w8, [x8]
10003012c: 34000268    	cbz	w8, 0x100030178 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x190>
100030130: f94006a8    	ldr	x8, [x21, #0x8]
100030134: b400f348    	cbz	x8, 0x100031f9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
100030138: f9400509    	ldr	x9, [x8, #0x8]
10003013c: f9400aa0    	ldr	x0, [x21, #0x10]
100030140: 39405d29    	ldrb	w9, [x9, #0x17]
100030144: 1200112a    	and	w10, w9, #0x1f
100030148: 121b0129    	and	w9, w9, #0x20
10003014c: 7100595f    	cmp	w10, #0x16
100030150: 7a401924    	ccmp	w9, #0x0, #0x4, ne
100030154: 54000060    	b.eq	0x100030160 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
100030158: f81883a0    	stur	x0, [x29, #-0x78]
10003015c: d101e3a0    	sub	x0, x29, #0x78
100030160: f9401508    	ldr	x8, [x8, #0x28]
100030164: d63f0100    	blr	x8
100030168: f9401fef    	ldr	x15, [sp, #0x38]
10003016c: aa0103e2    	mov	x2, x1
100030170: b50000a0    	cbnz	x0, 0x100030184 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x19c>
100030174: 14000006    	b	0x10003018c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
100030178: aa1f03e0    	mov	x0, xzr
10003017c: aa1f03e2    	mov	x2, xzr
100030180: 14000003    	b	0x10003018c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
100030184: f9400408    	ldr	x8, [x0, #0x8]
100030188: b500e368    	cbnz	x8, 0x100031df4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e0c>
10003018c: b9401f88    	ldr	w8, [x28, #0x1c]
100030190: 340003e8    	cbz	w8, 0x10003020c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
100030194: 360000fb    	tbz	w27, #0x0, 0x1000301b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
100030198: b9400389    	ldr	w9, [x28]
10003019c: 7100813f    	cmp	w9, #0x20
1000301a0: 54000360    	b.eq	0x10003020c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
1000301a4: 7101053f    	cmp	w9, #0x41
1000301a8: 54000320    	b.eq	0x10003020c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
1000301ac: 14000019    	b	0x100030210 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
1000301b0: b9400389    	ldr	w9, [x28]
1000301b4: 7100813f    	cmp	w9, #0x20
1000301b8: 54000060    	b.eq	0x1000301c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dc>
1000301bc: 7101053f    	cmp	w9, #0x41
1000301c0: 54000281    	b.ne	0x100030210 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
1000301c4: 2a3303e8    	mvn	w8, w19
1000301c8: f240151f    	tst	x8, #0x3f
1000301cc: 54000200    	b.eq	0x10003020c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
1000301d0: 7101053f    	cmp	w9, #0x41
1000301d4: 540000e1    	b.ne	0x1000301f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x208>
1000301d8: b9400b80    	ldr	w0, [x28, #0x8]
1000301dc: eb00029f    	cmp	x20, x0
1000301e0: 5400e709    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
1000301e4: b9401b88    	ldr	w8, [x28, #0x18]
1000301e8: 8b0012e9    	add	x9, x23, x0, lsl #4
1000301ec: a9007d28    	stp	x8, xzr, [x9]
1000301f0: 11000718    	add	w24, w24, #0x1
1000301f4: eb1802df    	cmp	x22, x24
1000301f8: 5400e5e9    	b.ls	0x100031eb4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ecc>
1000301fc: 8b18175c    	add	x28, x26, x24, lsl #5
100030200: 91000673    	add	x19, x19, #0x1
100030204: b9401f88    	ldr	w8, [x28, #0x1c]
100030208: 35fffd48    	cbnz	w8, 0x1000301b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
10003020c: b9400389    	ldr	w9, [x28]
100030210: 529fe40a    	mov	w10, #0xff20            ; =65312
100030214: 51038128    	sub	w8, w9, #0xe0
100030218: 72a01fea    	movk	w10, #0xff, lsl #16
10003021c: 6b0a011f    	cmp	w8, w10
100030220: 54000482    	b.hs	0x1000302b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c8>
100030224: 53107d28    	lsr	w8, w9, #16
100030228: 7103ed1f    	cmp	w8, #0xfb
10003022c: 54000ea0    	b.eq	0x100030400 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x418>
100030230: 7103f11f    	cmp	w8, #0xfc
100030234: 540006a0    	b.eq	0x100030308 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x320>
100030238: 7103f51f    	cmp	w8, #0xfd
10003023c: 54001361    	b.ne	0x1000304a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c0>
100030240: b9400f80    	ldr	w0, [x28, #0xc]
100030244: 3100041f    	cmn	w0, #0x1
100030248: 54002140    	b.eq	0x100030670 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x688>
10003024c: eb00029f    	cmp	x20, x0
100030250: 5400e389    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030254: 8b0012e8    	add	x8, x23, x0, lsl #4
100030258: a9402102    	ldp	x2, x8, [x8]
10003025c: b9401380    	ldr	w0, [x28, #0x10]
100030260: 3100041f    	cmn	w0, #0x1
100030264: 54002100    	b.eq	0x100030684 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x69c>
100030268: eb00029f    	cmp	x20, x0
10003026c: 5400e2a9    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030270: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
100030274: 3d801fe0    	str	q0, [sp, #0x70]
100030278: a9471be5    	ldp	x5, x6, [sp, #0x70]
10003027c: b9401780    	ldr	w0, [x28, #0x14]
100030280: 3100041f    	cmn	w0, #0x1
100030284: 540020a0    	b.eq	0x100030698 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6b0>
100030288: eb00029f    	cmp	x20, x0
10003028c: 5400e1a9    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030290: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
100030294: 3d8023e0    	str	q0, [sp, #0x80]
100030298: a9482fea    	ldp	x10, x11, [sp, #0x80]
10003029c: f94041e1    	ldr	x1, [x15, #0x80]
1000302a0: b9400780    	ldr	w0, [x28, #0x4]
1000302a4: eb00003f    	cmp	x1, x0
1000302a8: 54002048    	b.hi	0x1000306b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6c8>
1000302ac: 1400070b    	b	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000302b0: 51011528    	sub	w8, w9, #0x45
1000302b4: 7102011f    	cmp	w8, #0x80
1000302b8: 54000fc2    	b.hs	0x1000304b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
1000302bc: 7101fd1f    	cmp	w8, #0x7f
1000302c0: 5400bc08    	b.hi	0x100031a40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a58>
1000302c4: f0000f8c    	adrp	x12, 0x100223000 <dyld_stub_binder+0x100223000>
1000302c8: 912d818c    	add	x12, x12, #0xb60
1000302cc: 1000008a    	adr	x10, 0x1000302dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
1000302d0: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
1000302d4: 8b0b094a    	add	x10, x10, x11, lsl #2
1000302d8: d61f0140    	br	x10
1000302dc: b9401380    	ldr	w0, [x28, #0x10]
1000302e0: 3100041f    	cmn	w0, #0x1
1000302e4: 54003d60    	b.eq	0x100030a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
1000302e8: eb00029f    	cmp	x20, x0
1000302ec: 5400dfa9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000302f0: d37cec08    	lsl	x8, x0, #4
1000302f4: f8686ae2    	ldr	x2, [x23, x8]
1000302f8: b9400f80    	ldr	w0, [x28, #0xc]
1000302fc: eb00029f    	cmp	x20, x0
100030300: 54003d08    	b.hi	0x100030aa0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xab8>
100030304: 140006f7    	b	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030308: 529ffda8    	mov	w8, #0xffed             ; =65517
10003030c: 72bfe068    	movk	w8, #0xff03, lsl #16
100030310: 0b08012c    	add	w12, w9, w8
100030314: 7100119f    	cmp	w12, #0x4
100030318: 54000cc2    	b.hs	0x1000304b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
10003031c: 29430388    	ldp	w8, w0, [x28, #0x18]
100030320: f9406dea    	ldr	x10, [x15, #0xd8]
100030324: 0b00010b    	add	w11, w8, w0
100030328: 11000962    	add	w2, w11, #0x2
10003032c: eb02015f    	cmp	x10, x2
100030330: 5400e103    	b.lo	0x100031f50 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f68>
100030334: 6b02011f    	cmp	w8, w2
100030338: 5400e048    	b.hi	0x100031f40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f58>
10003033c: cb08014a    	sub	x10, x10, x8
100030340: d37ef50b    	lsl	x11, x8, #2
100030344: f100015f    	cmp	x10, #0x0
100030348: 9a9fc16a    	csel	x10, x11, xzr, gt
10003034c: 6b08005f    	cmp	w2, w8
100030350: 5400df20    	b.eq	0x100031f34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030354: f94065eb    	ldr	x11, [x15, #0xc8]
100030358: 8b0a016b    	add	x11, x11, x10
10003035c: b940016a    	ldr	w10, [x11]
100030360: eb0a029f    	cmp	x20, x10
100030364: 5400dc69    	b.ls	0x100031ef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
100030368: cb080041    	sub	x1, x2, x8
10003036c: f100043f    	cmp	x1, #0x1
100030370: 5400dde0    	b.eq	0x100031f2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f44>
100030374: b9400568    	ldr	w8, [x11, #0x4]
100030378: eb08029f    	cmp	x20, x8
10003037c: 5400db09    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030380: d37ced4a    	lsl	x10, x10, #4
100030384: d37ced08    	lsl	x8, x8, #4
100030388: 7100099f    	cmp	w12, #0x2
10003038c: f86a6aee    	ldr	x14, [x23, x10]
100030390: f8686aed    	ldr	x13, [x23, x8]
100030394: 540020c2    	b.hs	0x1000307ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7c4>
100030398: f1000c3f    	cmp	x1, #0x3
10003039c: 5400dfa3    	b.lo	0x100031f90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa8>
1000303a0: b9400968    	ldr	w8, [x11, #0x8]
1000303a4: eb08029f    	cmp	x20, x8
1000303a8: 5400d9a9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000303ac: f1000c3f    	cmp	x1, #0x3
1000303b0: 5400dec0    	b.eq	0x100031f88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
1000303b4: b9400d6a    	ldr	w10, [x11, #0xc]
1000303b8: eb0a029f    	cmp	x20, x10
1000303bc: 5400d9a9    	b.ls	0x100031ef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
1000303c0: d37ced08    	lsl	x8, x8, #4
1000303c4: d37ced4a    	lsl	x10, x10, #4
1000303c8: f8686aec    	ldr	x12, [x23, x8]
1000303cc: f86a6ae8    	ldr	x8, [x23, x10]
1000303d0: 5280026a    	mov	w10, #0x13              ; =19
1000303d4: 72a01f8a    	movk	w10, #0xfc, lsl #16
1000303d8: 6b0a013f    	cmp	w9, w10
1000303dc: 54002c61    	b.ne	0x100030968 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x980>
1000303e0: 8b0e018a    	add	x10, x12, x14
1000303e4: aa0e0189    	orr	x9, x12, x14
1000303e8: 8a0e018c    	and	x12, x12, x14
1000303ec: 8a2a0129    	bic	x9, x9, x10
1000303f0: 8b0d0108    	add	x8, x8, x13
1000303f4: aa0c0129    	orr	x9, x9, x12
1000303f8: 8b49fd0c    	add	x12, x8, x9, lsr #63
1000303fc: 14000162    	b	0x100030984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
100030400: 51000928    	sub	w8, w9, #0x2
100030404: 12003d09    	and	w9, w8, #0xffff
100030408: 7100853f    	cmp	w9, #0x21
10003040c: d287c1e9    	mov	x9, #0x3e0f             ; =15887
100030410: f2a38009    	movk	x9, #0x1c00, lsl #16
100030414: 1a9f27ea    	cset	w10, lo
100030418: f2c00029    	movk	x9, #0x1, lsl #32
10003041c: 9ac82529    	lsr	x9, x9, x8
100030420: 0a090149    	and	w9, w10, w9
100030424: 36001169    	tbz	w9, #0x0, 0x100030650 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x668>
100030428: b9400f80    	ldr	w0, [x28, #0xc]
10003042c: 3100041f    	cmn	w0, #0x1
100030430: 54002160    	b.eq	0x10003085c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
100030434: eb00029f    	cmp	x20, x0
100030438: 5400d449    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10003043c: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
100030440: 3d8013e0    	str	q0, [sp, #0x40]
100030444: a94413e3    	ldp	x3, x4, [sp, #0x40]
100030448: b9401380    	ldr	w0, [x28, #0x10]
10003044c: 3100041f    	cmn	w0, #0x1
100030450: 54002100    	b.eq	0x100030870 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
100030454: eb00029f    	cmp	x20, x0
100030458: 5400d349    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10003045c: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
100030460: 3d8017e0    	str	q0, [sp, #0x50]
100030464: a9451be5    	ldp	x5, x6, [sp, #0x50]
100030468: 12003d08    	and	w8, w8, #0xffff
10003046c: 7100311f    	cmp	w8, #0xc
100030470: 540020a1    	b.ne	0x100030884 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x89c>
100030474: b9401b88    	ldr	w8, [x28, #0x18]
100030478: f94069e1    	ldr	x1, [x15, #0xd0]
10003047c: 11000900    	add	w0, w8, #0x2
100030480: eb00003f    	cmp	x1, x0
100030484: 5400d2a9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030488: f94065e8    	ldr	x8, [x15, #0xc8]
10003048c: b8607900    	ldr	w0, [x8, x0, lsl #2]
100030490: eb00029f    	cmp	x20, x0
100030494: 5400d169    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030498: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10003049c: 3d801be0    	str	q0, [sp, #0x60]
1000304a0: a94627e7    	ldp	x7, x9, [sp, #0x60]
1000304a4: 140000fa    	b	0x10003088c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8a4>
1000304a8: 71039d3f    	cmp	w9, #0xe7
1000304ac: 5400c123    	b.lo	0x100031cd0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
1000304b0: 51000528    	sub	w8, w9, #0x1
1000304b4: 71034d1f    	cmp	w8, #0xd3
1000304b8: 540005e8    	b.hi	0x100030574 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x58c>
1000304bc: f0000f8c    	adrp	x12, 0x100223000 <dyld_stub_binder+0x100223000>
1000304c0: 9131818c    	add	x12, x12, #0xc60
1000304c4: aa1f03e0    	mov	x0, xzr
1000304c8: 100000aa    	adr	x10, 0x1000304dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f4>
1000304cc: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
1000304d0: 8b0b094a    	add	x10, x10, x11, lsl #2
1000304d4: aa1f03e1    	mov	x1, xzr
1000304d8: d61f0140    	br	x10
1000304dc: f94041e1    	ldr	x1, [x15, #0x80]
1000304e0: b9400780    	ldr	w0, [x28, #0x4]
1000304e4: eb00003f    	cmp	x1, x0
1000304e8: 5400cf89    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000304ec: 52801c0a    	mov	w10, #0xe0              ; =224
1000304f0: f9403de8    	ldr	x8, [x15, #0x78]
1000304f4: 9baa200a    	umaddl	x10, w0, w10, x8
1000304f8: b400c24a    	cbz	x10, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304fc: f94017e8    	ldr	x8, [sp, #0x28]
100030500: b400c208    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030504: f9403d01    	ldr	x1, [x8, #0x78]
100030508: b9401940    	ldr	w0, [x10, #0x18]
10003050c: eb00003f    	cmp	x1, x0
100030510: 5400ce49    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030514: f9403908    	ldr	x8, [x8, #0x70]
100030518: ab000d08    	adds	x8, x8, x0, lsl #3
10003051c: 5400c120    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030520: f940010b    	ldr	x11, [x8]
100030524: b400c0eb    	cbz	x11, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030528: b9400f88    	ldr	w8, [x28, #0xc]
10003052c: eb08029f    	cmp	x20, x8
100030530: 5400cd69    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030534: f9400960    	ldr	x0, [x11, #0x10]
100030538: d37ced08    	lsl	x8, x8, #4
10003053c: b940154b    	ldr	w11, [x10, #0x14]
100030540: b9401d4a    	ldr	w10, [x10, #0x1c]
100030544: f940200c    	ldr	x12, [x0, #0x40]
100030548: f8686ae2    	ldr	x2, [x23, x8]
10003054c: aa0a8163    	orr	x3, x11, x10, lsl #32
100030550: b400006c    	cbz	x12, 0x10003055c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x574>
100030554: f9403008    	ldr	x8, [x0, #0x60]
100030558: b4001d68    	cbz	x8, 0x100030904 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x91c>
10003055c: d101e3a8    	sub	x8, x29, #0x78
100030560: 2a0903e1    	mov	w1, w9
100030564: 2a1f03e4    	mov	w4, wzr
100030568: aa1f03e5    	mov	x5, xzr
10003056c: aa1f03e6    	mov	x6, xzr
100030570: 14000073    	b	0x10003073c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x754>
100030574: 517f0128    	sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
100030578: 7100211f    	cmp	w8, #0x8
10003057c: 54000e62    	b.hs	0x100030748 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x760>
100030580: b9400f80    	ldr	w0, [x28, #0xc]
100030584: eb00029f    	cmp	x20, x0
100030588: 5400cac9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003058c: d37cec08    	lsl	x8, x0, #4
100030590: 2a0903e0    	mov	w0, w9
100030594: aa1f03e2    	mov	x2, xzr
100030598: f8686ae1    	ldr	x1, [x23, x8]
10003059c: 94009c38    	bl	0x10005767c <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
1000305a0: aa0103f9    	mov	x25, x1
1000305a4: aa1f03e1    	mov	x1, xzr
1000305a8: 140000e5    	b	0x10003093c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
1000305ac: f94041e1    	ldr	x1, [x15, #0x80]
1000305b0: b9400780    	ldr	w0, [x28, #0x4]
1000305b4: eb00003f    	cmp	x1, x0
1000305b8: 5400c909    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000305bc: 52801c0a    	mov	w10, #0xe0              ; =224
1000305c0: f9403de8    	ldr	x8, [x15, #0x78]
1000305c4: 9baa200b    	umaddl	x11, w0, w10, x8
1000305c8: b400bbcb    	cbz	x11, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000305cc: f94017e8    	ldr	x8, [sp, #0x28]
1000305d0: b400bb88    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000305d4: f9403d01    	ldr	x1, [x8, #0x78]
1000305d8: b9401960    	ldr	w0, [x11, #0x18]
1000305dc: eb00003f    	cmp	x1, x0
1000305e0: 5400c7c9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000305e4: f9403908    	ldr	x8, [x8, #0x70]
1000305e8: ab000d08    	adds	x8, x8, x0, lsl #3
1000305ec: 5400baa0    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000305f0: f940010c    	ldr	x12, [x8]
1000305f4: b400ba6c    	cbz	x12, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000305f8: b9400f88    	ldr	w8, [x28, #0xc]
1000305fc: eb08029f    	cmp	x20, x8
100030600: 5400c6e9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030604: b940138a    	ldr	w10, [x28, #0x10]
100030608: eb0a029f    	cmp	x20, x10
10003060c: 5400c729    	b.ls	0x100031ef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
100030610: f9400980    	ldr	x0, [x12, #0x10]
100030614: b940156c    	ldr	w12, [x11, #0x14]
100030618: d37ced08    	lsl	x8, x8, #4
10003061c: b9401d6b    	ldr	w11, [x11, #0x1c]
100030620: d37ced4a    	lsl	x10, x10, #4
100030624: f940200d    	ldr	x13, [x0, #0x40]
100030628: f8686ae2    	ldr	x2, [x23, x8]
10003062c: aa0b8183    	orr	x3, x12, x11, lsl #32
100030630: f86a6ae5    	ldr	x5, [x23, x10]
100030634: b400006d    	cbz	x13, 0x100030640 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x658>
100030638: f9403008    	ldr	x8, [x0, #0x60]
10003063c: b4001fc8    	cbz	x8, 0x100030a34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
100030640: 2a0903e1    	mov	w1, w9
100030644: 2a1f03e4    	mov	w4, wzr
100030648: aa1f03e6    	mov	x6, xzr
10003064c: 1400007e    	b	0x100030844 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x85c>
100030650: f9401be8    	ldr	x8, [sp, #0x30]
100030654: aa1503e0    	mov	x0, x21
100030658: b81c8118    	stur	w24, [x8, #-0x38]
10003065c: 940006e1    	bl	0x1000321e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
100030660: f9401fef    	ldr	x15, [sp, #0x38]
100030664: 72001c1f    	tst	w0, #0xff
100030668: 54001440    	b.eq	0x1000308f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
10003066c: 140005cb    	b	0x100031d98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
100030670: aa1f03e8    	mov	x8, xzr
100030674: aa1f03e2    	mov	x2, xzr
100030678: b9401380    	ldr	w0, [x28, #0x10]
10003067c: 3100041f    	cmn	w0, #0x1
100030680: 54ffdf41    	b.ne	0x100030268 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x280>
100030684: aa1f03e5    	mov	x5, xzr
100030688: aa1f03e6    	mov	x6, xzr
10003068c: b9401780    	ldr	w0, [x28, #0x14]
100030690: 3100041f    	cmn	w0, #0x1
100030694: 54ffdfa1    	b.ne	0x100030288 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2a0>
100030698: aa1f03ea    	mov	x10, xzr
10003069c: aa1f03eb    	mov	x11, xzr
1000306a0: f94041e1    	ldr	x1, [x15, #0x80]
1000306a4: b9400780    	ldr	w0, [x28, #0x4]
1000306a8: eb00003f    	cmp	x1, x0
1000306ac: 5400c169    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000306b0: 52801c0d    	mov	w13, #0xe0              ; =224
1000306b4: f9403dec    	ldr	x12, [x15, #0x78]
1000306b8: 9bad3000    	umaddl	x0, w0, w13, x12
1000306bc: b400b420    	cbz	x0, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000306c0: 121e352c    	and	w12, w9, #0xfffc
1000306c4: 12003d2d    	and	w13, w9, #0xffff
1000306c8: 7101519f    	cmp	w12, #0x54
1000306cc: 7a4b19a0    	ccmp	w13, #0xb, #0x0, ne
1000306d0: 54000083    	b.lo	0x1000306e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6f8>
1000306d4: 510171ae    	sub	w14, w13, #0x5c
1000306d8: 710009df    	cmp	w14, #0x2
1000306dc: 54000802    	b.hs	0x1000307dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f4>
1000306e0: f94017ea    	ldr	x10, [sp, #0x28]
1000306e4: b400b2ea    	cbz	x10, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000306e8: f9403d41    	ldr	x1, [x10, #0x78]
1000306ec: b9401808    	ldr	w8, [x0, #0x18]
1000306f0: eb08003f    	cmp	x1, x8
1000306f4: 5400bfa9    	b.ls	0x100031ee8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
1000306f8: f940394a    	ldr	x10, [x10, #0x70]
1000306fc: ab080d48    	adds	x8, x10, x8, lsl #3
100030700: 5400b200    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030704: f9400108    	ldr	x8, [x8]
100030708: b400b1c8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003070c: f940090a    	ldr	x10, [x8, #0x10]
100030710: b9401408    	ldr	w8, [x0, #0x14]
100030714: b9401c0b    	ldr	w11, [x0, #0x1c]
100030718: 39410004    	ldrb	w4, [x0, #0x40]
10003071c: f940214c    	ldr	x12, [x10, #0x40]
100030720: aa0b8103    	orr	x3, x8, x11, lsl #32
100030724: b400006c    	cbz	x12, 0x100030730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x748>
100030728: f9403148    	ldr	x8, [x10, #0x60]
10003072c: b4000f88    	cbz	x8, 0x10003091c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x934>
100030730: d101e3a8    	sub	x8, x29, #0x78
100030734: aa0a03e0    	mov	x0, x10
100030738: 2a0903e1    	mov	w1, w9
10003073c: d101e3bb    	sub	x27, x29, #0x78
100030740: 94007bb9    	bl	0x10004f624 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
100030744: 1400007b    	b	0x100030930 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
100030748: 12a02008    	mov	w8, #-0x1000001         ; =-16777217
10003074c: 0b080128    	add	w8, w9, w8
100030750: 7100211f    	cmp	w8, #0x8
100030754: 54003e08    	b.hi	0x100030f14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf2c>
100030758: 528022ea    	mov	w10, #0x117             ; =279
10003075c: 1ac8254a    	lsr	w10, w10, w8
100030760: 36003d2a    	tbz	w10, #0x0, 0x100030f04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf1c>
100030764: 12001d29    	and	w9, w9, #0xff
100030768: 2a1f03e8    	mov	w8, wzr
10003076c: 7100113f    	cmp	w9, #0x4
100030770: 540016ac    	b.gt	0x100030a44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa5c>
100030774: 7100093f    	cmp	w9, #0x2
100030778: 54001a80    	b.eq	0x100030ac8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xae0>
10003077c: 71000d3f    	cmp	w9, #0x3
100030780: 54003621    	b.ne	0x100030e44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
100030784: b9400f80    	ldr	w0, [x28, #0xc]
100030788: eb00029f    	cmp	x20, x0
10003078c: 5400baa9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030790: d37cec08    	lsl	x8, x0, #4
100030794: b9401f89    	ldr	w9, [x28, #0x1c]
100030798: b8686ae8    	ldr	w8, [x23, x8]
10003079c: 51000529    	sub	w9, w9, #0x1
1000307a0: 6b08013f    	cmp	w9, w8
1000307a4: 1a883128    	csel	w8, w9, w8, lo
1000307a8: 140001a7    	b	0x100030e44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
1000307ac: 9bce7dac    	umulh	x12, x13, x14
1000307b0: 52800268    	mov	w8, #0x13               ; =19
1000307b4: 72a01f88    	movk	w8, #0xfc, lsl #16
1000307b8: 9b0e7daa    	mul	x10, x13, x14
1000307bc: 11000908    	add	w8, w8, #0x2
1000307c0: 6b08013f    	cmp	w9, w8
1000307c4: 54000e01    	b.ne	0x100030984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
1000307c8: 8a8efda8    	and	x8, x13, x14, asr #63
1000307cc: 8a8dfdc9    	and	x9, x14, x13, asr #63
1000307d0: 8b080128    	add	x8, x9, x8
1000307d4: cb08018c    	sub	x12, x12, x8
1000307d8: 1400006b    	b	0x100030984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
1000307dc: 71002dbf    	cmp	w13, #0xb
1000307e0: f94017ed    	ldr	x13, [sp, #0x28]
1000307e4: 54000060    	b.eq	0x1000307f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x808>
1000307e8: 7101619f    	cmp	w12, #0x58
1000307ec: 54001ca1    	b.ne	0x100030b80 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb98>
1000307f0: b400aa8d    	cbz	x13, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000307f4: f9403da1    	ldr	x1, [x13, #0x78]
1000307f8: b9401808    	ldr	w8, [x0, #0x18]
1000307fc: eb08003f    	cmp	x1, x8
100030800: 5400b749    	b.ls	0x100031ee8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
100030804: f94039aa    	ldr	x10, [x13, #0x70]
100030808: ab080d48    	adds	x8, x10, x8, lsl #3
10003080c: 5400a9a0    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030810: f9400108    	ldr	x8, [x8]
100030814: b400a968    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030818: f9400908    	ldr	x8, [x8, #0x10]
10003081c: b940140a    	ldr	w10, [x0, #0x14]
100030820: b9401c0b    	ldr	w11, [x0, #0x1c]
100030824: 39410004    	ldrb	w4, [x0, #0x40]
100030828: f940210c    	ldr	x12, [x8, #0x40]
10003082c: aa0b8143    	orr	x3, x10, x11, lsl #32
100030830: b400006c    	cbz	x12, 0x10003083c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x854>
100030834: f940310a    	ldr	x10, [x8, #0x60]
100030838: b4002f4a    	cbz	x10, 0x100030e20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe38>
10003083c: aa0803e0    	mov	x0, x8
100030840: 2a0903e1    	mov	w1, w9
100030844: 94007185    	bl	0x10004ce58 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
100030848: 2a0003e8    	mov	w8, w0
10003084c: aa1f03e0    	mov	x0, xzr
100030850: aa1f03e1    	mov	x1, xzr
100030854: 12001d19    	and	w25, w8, #0xff
100030858: 14000039    	b	0x10003093c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10003085c: aa1f03e3    	mov	x3, xzr
100030860: aa1f03e4    	mov	x4, xzr
100030864: b9401380    	ldr	w0, [x28, #0x10]
100030868: 3100041f    	cmn	w0, #0x1
10003086c: 54ffdf41    	b.ne	0x100030454 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x46c>
100030870: aa1f03e5    	mov	x5, xzr
100030874: aa1f03e6    	mov	x6, xzr
100030878: 12003d08    	and	w8, w8, #0xffff
10003087c: 7100311f    	cmp	w8, #0xc
100030880: 54ffdfa0    	b.eq	0x100030474 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x48c>
100030884: aa1f03e7    	mov	x7, xzr
100030888: aa1f03e9    	mov	x9, xzr
10003088c: f94041e1    	ldr	x1, [x15, #0x80]
100030890: b9400780    	ldr	w0, [x28, #0x4]
100030894: eb00003f    	cmp	x1, x0
100030898: 5400b209    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10003089c: 52801c0a    	mov	w10, #0xe0              ; =224
1000308a0: f9403de8    	ldr	x8, [x15, #0x78]
1000308a4: 9baa2002    	umaddl	x2, w0, w10, x8
1000308a8: b400a4c2    	cbz	x2, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000308ac: f94002a0    	ldr	x0, [x21]
1000308b0: f94017e1    	ldr	x1, [sp, #0x28]
1000308b4: 910243e8    	add	x8, sp, #0x90
1000308b8: f90003e9    	str	x9, [sp]
1000308bc: 94002f7a    	bl	0x10003c6a4 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
1000308c0: f94053f9    	ldr	x25, [sp, #0xa0]
1000308c4: 3dc027e0    	ldr	q0, [sp, #0x90]
1000308c8: b4000079    	cbz	x25, 0x1000308d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8ec>
1000308cc: f9400728    	ldr	x8, [x25, #0x8]
1000308d0: b500a688    	cbnz	x8, 0x100031da0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db8>
1000308d4: b9400b80    	ldr	w0, [x28, #0x8]
1000308d8: f9401fef    	ldr	x15, [sp, #0x38]
1000308dc: 3100041f    	cmn	w0, #0x1
1000308e0: 54000080    	b.eq	0x1000308f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
1000308e4: eb00029f    	cmp	x20, x0
1000308e8: 5400aec9    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
1000308ec: 3ca07ae0    	str	q0, [x23, x0, lsl #4]
1000308f0: 1100071c    	add	w28, w24, #0x1
1000308f4: 14000034    	b	0x1000309c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9dc>
1000308f8: f9400f80    	ldr	x0, [x28, #0x18]
1000308fc: aa1f03e1    	mov	x1, xzr
100030900: 14000012    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030904: d101e3a8    	sub	x8, x29, #0x78
100030908: 2a0903e1    	mov	w1, w9
10003090c: 2a1f03e4    	mov	w4, wzr
100030910: aa1f03e5    	mov	x5, xzr
100030914: aa1f03e6    	mov	x6, xzr
100030918: 14000004    	b	0x100030928 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x940>
10003091c: d101e3a8    	sub	x8, x29, #0x78
100030920: aa0a03e0    	mov	x0, x10
100030924: 2a0903e1    	mov	w1, w9
100030928: d101e3bb    	sub	x27, x29, #0x78
10003092c: 94007b88    	bl	0x10004f74c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
100030930: a9400760    	ldp	x0, x1, [x27]
100030934: 39404379    	ldrb	w25, [x27, #0x10]
100030938: b94027fb    	ldr	w27, [sp, #0x24]
10003093c: f9401fef    	ldr	x15, [sp, #0x38]
100030940: 72001f3f    	tst	w25, #0xff
100030944: 5400a641    	b.ne	0x100031e0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
100030948: b9400b88    	ldr	w8, [x28, #0x8]
10003094c: 3100051f    	cmn	w8, #0x1
100030950: 54ffbb60    	b.eq	0x1000300bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
100030954: eb08029f    	cmp	x20, x8
100030958: 5400ab89    	b.ls	0x100031ec8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
10003095c: 8b0812e8    	add	x8, x23, x8, lsl #4
100030960: a9000500    	stp	x0, x1, [x8]
100030964: 17fffdd6    	b	0x1000300bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
100030968: cb0c01ca    	sub	x10, x14, x12
10003096c: ca2c01c9    	eon	x9, x14, x12
100030970: 8a2e018c    	bic	x12, x12, x14
100030974: 8a090149    	and	x9, x10, x9
100030978: aa0c0129    	orr	x9, x9, x12
10003097c: 8b49fd08    	add	x8, x8, x9, lsr #63
100030980: cb0801ac    	sub	x12, x13, x8
100030984: eb00003f    	cmp	x1, x0
100030988: 5400aa89    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10003098c: 11000408    	add	w8, w0, #0x1
100030990: eb08003f    	cmp	x1, x8
100030994: 5400aaa9    	b.ls	0x100031ee8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
100030998: b8607969    	ldr	w9, [x11, x0, lsl #2]
10003099c: eb09029f    	cmp	x20, x9
1000309a0: 5400ac09    	b.ls	0x100031f20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f38>
1000309a4: b8687960    	ldr	w0, [x11, x8, lsl #2]
1000309a8: 8b0912e8    	add	x8, x23, x9, lsl #4
1000309ac: eb00029f    	cmp	x20, x0
1000309b0: a9007d0a    	stp	x10, xzr, [x8]
1000309b4: 5400a969    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000309b8: 8b0012e8    	add	x8, x23, x0, lsl #4
1000309bc: 1100071c    	add	w28, w24, #0x1
1000309c0: a9007d0c    	stp	x12, xzr, [x8]
1000309c4: f9401be8    	ldr	x8, [sp, #0x30]
1000309c8: b81c811c    	stur	w28, [x8, #-0x38]
1000309cc: 17fffdbd    	b	0x1000300c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
1000309d0: b9400f80    	ldr	w0, [x28, #0xc]
1000309d4: eb00029f    	cmp	x20, x0
1000309d8: 5400a749    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
1000309dc: b9401b88    	ldr	w8, [x28, #0x18]
1000309e0: eb08029f    	cmp	x20, x8
1000309e4: 5400a729    	b.ls	0x100031ec8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
1000309e8: 8b0012e9    	add	x9, x23, x0, lsl #4
1000309ec: 3dc00120    	ldr	q0, [x9]
1000309f0: f9400521    	ldr	x1, [x9, #0x8]
1000309f4: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
1000309f8: 9e660000    	fmov	x0, d0
1000309fc: 17ffffd3    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a00: b9401780    	ldr	w0, [x28, #0x14]
100030a04: eb00029f    	cmp	x20, x0
100030a08: 5400a6c9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a0c: d37cec08    	lsl	x8, x0, #4
100030a10: 52800209    	mov	w9, #0x10               ; =16
100030a14: b8686ae8    	ldr	w8, [x23, x8]
100030a18: 7100011f    	cmp	w8, #0x0
100030a1c: 52800188    	mov	w8, #0xc                ; =12
100030a20: 9a880128    	csel	x8, x9, x8, eq
100030a24: b8686b80    	ldr	w0, [x28, x8]
100030a28: eb00029f    	cmp	x20, x0
100030a2c: 54001ce8    	b.hi	0x100030dc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xde0>
100030a30: 1400052c    	b	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a34: 2a0903e1    	mov	w1, w9
100030a38: 2a1f03e4    	mov	w4, wzr
100030a3c: aa1f03e6    	mov	x6, xzr
100030a40: 140000fa    	b	0x100030e28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
100030a44: 7100253f    	cmp	w9, #0x9
100030a48: 54001fa1    	b.ne	0x100030e3c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe54>
100030a4c: b9400f80    	ldr	w0, [x28, #0xc]
100030a50: eb00029f    	cmp	x20, x0
100030a54: 5400a469    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a58: d37cec08    	lsl	x8, x0, #4
100030a5c: f8686ae8    	ldr	x8, [x23, x8]
100030a60: f100011f    	cmp	x8, #0x0
100030a64: 1a9f07e8    	cset	w8, ne
100030a68: 140000f7    	b	0x100030e44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
100030a6c: b9400f80    	ldr	w0, [x28, #0xc]
100030a70: eb00029f    	cmp	x20, x0
100030a74: 5400a369    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a78: d37cec08    	lsl	x8, x0, #4
100030a7c: aa1f03e1    	mov	x1, xzr
100030a80: f8686ae8    	ldr	x8, [x23, x8]
100030a84: f100011f    	cmp	x8, #0x0
100030a88: 1a9f17e0    	cset	w0, eq
100030a8c: 17ffffaf    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a90: aa1f03e2    	mov	x2, xzr
100030a94: b9400f80    	ldr	w0, [x28, #0xc]
100030a98: eb00029f    	cmp	x20, x0
100030a9c: 5400a229    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030aa0: d37cec08    	lsl	x8, x0, #4
100030aa4: 2a0903e0    	mov	w0, w9
100030aa8: f8686ae1    	ldr	x1, [x23, x8]
100030aac: 94009af4    	bl	0x10005767c <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
100030ab0: aa0103f9    	mov	x25, x1
100030ab4: f9401fef    	ldr	x15, [sp, #0x38]
100030ab8: 72001f3f    	tst	w25, #0xff
100030abc: 54009a81    	b.ne	0x100031e0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
100030ac0: aa1f03e1    	mov	x1, xzr
100030ac4: 17ffffa1    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ac8: b9400f80    	ldr	w0, [x28, #0xc]
100030acc: eb00029f    	cmp	x20, x0
100030ad0: 5400a089    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ad4: d37cec08    	lsl	x8, x0, #4
100030ad8: b8686ae8    	ldr	w8, [x23, x8]
100030adc: 7100011f    	cmp	w8, #0x0
100030ae0: 1a9f17e8    	cset	w8, eq
100030ae4: 140000d8    	b	0x100030e44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
100030ae8: b9400f80    	ldr	w0, [x28, #0xc]
100030aec: eb00029f    	cmp	x20, x0
100030af0: 54009f89    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030af4: d37cec08    	lsl	x8, x0, #4
100030af8: 7101a53f    	cmp	w9, #0x69
100030afc: aa1f03e1    	mov	x1, xzr
100030b00: f8686ae8    	ldr	x8, [x23, x8]
100030b04: 2a0803e9    	mov	w9, w8
100030b08: 9a880128    	csel	x8, x9, x8, eq
100030b0c: d341fd09    	lsr	x9, x8, #1
100030b10: 9200f108    	and	x8, x8, #0x5555555555555555
100030b14: 9200f129    	and	x9, x9, #0x5555555555555555
100030b18: 8b080128    	add	x8, x9, x8
100030b1c: d342fd09    	lsr	x9, x8, #2
100030b20: 9200e508    	and	x8, x8, #0x3333333333333333
100030b24: 9200e529    	and	x9, x9, #0x3333333333333333
100030b28: 8b080128    	add	x8, x9, x8
100030b2c: 8b481108    	add	x8, x8, x8, lsr #4
100030b30: 9200cd08    	and	x8, x8, #0xf0f0f0f0f0f0f0f
100030b34: 8b482108    	add	x8, x8, x8, lsr #8
100030b38: 8b484108    	add	x8, x8, x8, lsr #16
100030b3c: 8b488108    	add	x8, x8, x8, lsr #32
100030b40: 92401900    	and	x0, x8, #0x7f
100030b44: 17ffff81    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b48: b9400f80    	ldr	w0, [x28, #0xc]
100030b4c: eb00029f    	cmp	x20, x0
100030b50: 54009c89    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b54: d37cec08    	lsl	x8, x0, #4
100030b58: aa1f03e1    	mov	x1, xzr
100030b5c: b8a86ae0    	ldrsw	x0, [x23, x8]
100030b60: 17ffff7a    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b64: b9400f80    	ldr	w0, [x28, #0xc]
100030b68: eb00029f    	cmp	x20, x0
100030b6c: 54009ba9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b70: d37cec08    	lsl	x8, x0, #4
100030b74: aa1f03e1    	mov	x1, xzr
100030b78: b8686ae0    	ldr	w0, [x23, x8]
100030b7c: 17ffff73    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b80: aa0203e1    	mov	x1, x2
100030b84: aa0803e2    	mov	x2, x8
100030b88: aa0503e3    	mov	x3, x5
100030b8c: aa0603e4    	mov	x4, x6
100030b90: aa0a03e5    	mov	x5, x10
100030b94: aa0b03e6    	mov	x6, x11
100030b98: 940093eb    	bl	0x100055b44 <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100030b9c: f9401fef    	ldr	x15, [sp, #0x38]
100030ba0: 17ffff6a    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ba4: b9400f80    	ldr	w0, [x28, #0xc]
100030ba8: eb00029f    	cmp	x20, x0
100030bac: 540099a9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030bb0: b9401388    	ldr	w8, [x28, #0x10]
100030bb4: eb08029f    	cmp	x20, x8
100030bb8: 54006208    	b.hi	0x1000317f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1810>
100030bbc: 140004c8    	b	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030bc0: f94017e8    	ldr	x8, [sp, #0x28]
100030bc4: b4008be8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030bc8: f9403d01    	ldr	x1, [x8, #0x78]
100030bcc: b9401b80    	ldr	w0, [x28, #0x18]
100030bd0: eb00003f    	cmp	x1, x0
100030bd4: 54009829    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030bd8: f9403908    	ldr	x8, [x8, #0x70]
100030bdc: ab000d08    	adds	x8, x8, x0, lsl #3
100030be0: 54008b00    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030be4: f9400119    	ldr	x25, [x8]
100030be8: b4008ad9    	cbz	x25, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030bec: f9400b28    	ldr	x8, [x25, #0x10]
100030bf0: f94002ab    	ldr	x11, [x21]
100030bf4: b4007d68    	cbz	x8, 0x100031ba0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bb8>
100030bf8: 3940c508    	ldrb	w8, [x8, #0x31]
100030bfc: 140003ed    	b	0x100031bb0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
100030c00: f94017e8    	ldr	x8, [sp, #0x28]
100030c04: b40089e8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030c08: f9403101    	ldr	x1, [x8, #0x60]
100030c0c: b9401b80    	ldr	w0, [x28, #0x18]
100030c10: eb00003f    	cmp	x1, x0
100030c14: 54009629    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030c18: f9402d08    	ldr	x8, [x8, #0x58]
100030c1c: ab000d08    	adds	x8, x8, x0, lsl #3
100030c20: 54008900    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030c24: f9400108    	ldr	x8, [x8]
100030c28: b40088c8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030c2c: b9400f80    	ldr	w0, [x28, #0xc]
100030c30: eb00029f    	cmp	x20, x0
100030c34: 54009569    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c38: d37cec09    	lsl	x9, x0, #4
100030c3c: 3940a50a    	ldrb	w10, [x8, #0x29]
100030c40: f8696ae9    	ldr	x9, [x23, x9]
100030c44: 7100015f    	cmp	w10, #0x0
100030c48: f940210a    	ldr	x10, [x8, #0x40]
100030c4c: 2a0903eb    	mov	w11, w9
100030c50: 9a8b1129    	csel	x9, x9, x11, ne
100030c54: eb0a013f    	cmp	x9, x10
100030c58: 54008c82    	b.hs	0x100031de8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
100030c5c: f9401d08    	ldr	x8, [x8, #0x38]
100030c60: aa1f03e1    	mov	x1, xzr
100030c64: f8697900    	ldr	x0, [x8, x9, lsl #3]
100030c68: 17ffff38    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c6c: f94017e8    	ldr	x8, [sp, #0x28]
100030c70: b4008688    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030c74: f9402501    	ldr	x1, [x8, #0x48]
100030c78: b9401b80    	ldr	w0, [x28, #0x18]
100030c7c: eb00003f    	cmp	x1, x0
100030c80: 540092c9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030c84: f9402108    	ldr	x8, [x8, #0x40]
100030c88: aa1f03e1    	mov	x1, xzr
100030c8c: f8607900    	ldr	x0, [x8, x0, lsl #3]
100030c90: 17ffff2e    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c94: b9400f80    	ldr	w0, [x28, #0xc]
100030c98: eb00029f    	cmp	x20, x0
100030c9c: 54009229    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ca0: 8b0012e8    	add	x8, x23, x0, lsl #4
100030ca4: f9400100    	ldr	x0, [x8]
100030ca8: b4008b00    	cbz	x0, 0x100031e08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e20>
100030cac: f9400501    	ldr	x1, [x8, #0x8]
100030cb0: 17ffff26    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030cb4: f94017e8    	ldr	x8, [sp, #0x28]
100030cb8: b4008448    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030cbc: f9404901    	ldr	x1, [x8, #0x90]
100030cc0: b9401b80    	ldr	w0, [x28, #0x18]
100030cc4: eb00003f    	cmp	x1, x0
100030cc8: 54009089    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030ccc: b9400f88    	ldr	w8, [x28, #0xc]
100030cd0: eb08029f    	cmp	x20, x8
100030cd4: 54008fa9    	b.ls	0x100031ec8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030cd8: f94017e9    	ldr	x9, [sp, #0x28]
100030cdc: f9404529    	ldr	x9, [x9, #0x88]
100030ce0: 8b000d29    	add	x9, x9, x0, lsl #3
100030ce4: b40082e9    	cbz	x9, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030ce8: f9400129    	ldr	x9, [x9]
100030cec: b40082a9    	cbz	x9, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030cf0: 3ce87ae0    	ldr	q0, [x23, x8, lsl #4]
100030cf4: aa1f03e0    	mov	x0, xzr
100030cf8: aa1f03e1    	mov	x1, xzr
100030cfc: 3d800920    	str	q0, [x9, #0x20]
100030d00: 17ffff12    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030d04: f94017e8    	ldr	x8, [sp, #0x28]
100030d08: b40081c8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030d0c: f9404901    	ldr	x1, [x8, #0x90]
100030d10: b9401b80    	ldr	w0, [x28, #0x18]
100030d14: eb00003f    	cmp	x1, x0
100030d18: 54008e09    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030d1c: f9404508    	ldr	x8, [x8, #0x88]
100030d20: ab000d08    	adds	x8, x8, x0, lsl #3
100030d24: 540080e0    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030d28: f9400108    	ldr	x8, [x8]
100030d2c: b40080a8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030d30: a9420500    	ldp	x0, x1, [x8, #0x20]
100030d34: 17ffff05    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030d38: f94017e8    	ldr	x8, [sp, #0x28]
100030d3c: b4008028    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030d40: f9403101    	ldr	x1, [x8, #0x60]
100030d44: b9401b80    	ldr	w0, [x28, #0x18]
100030d48: eb00003f    	cmp	x1, x0
100030d4c: 54008c69    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030d50: f9402d08    	ldr	x8, [x8, #0x58]
100030d54: ab000d08    	adds	x8, x8, x0, lsl #3
100030d58: 54007f40    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030d5c: f9400109    	ldr	x9, [x8]
100030d60: b4007f09    	cbz	x9, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030d64: b9400f80    	ldr	w0, [x28, #0xc]
100030d68: eb00029f    	cmp	x20, x0
100030d6c: 54008ba9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d70: d37cec08    	lsl	x8, x0, #4
100030d74: 3940a52a    	ldrb	w10, [x9, #0x29]
100030d78: f940212c    	ldr	x12, [x9, #0x40]
100030d7c: f8686ae8    	ldr	x8, [x23, x8]
100030d80: 7100015f    	cmp	w10, #0x0
100030d84: 2a0803eb    	mov	w11, w8
100030d88: 9a8b110a    	csel	x10, x8, x11, ne
100030d8c: eb0c015f    	cmp	x10, x12
100030d90: 540082c2    	b.hs	0x100031de8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
100030d94: b9401388    	ldr	w8, [x28, #0x10]
100030d98: eb08029f    	cmp	x20, x8
100030d9c: 54008a09    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030da0: d37ced08    	lsl	x8, x8, #4
100030da4: f9401d29    	ldr	x9, [x9, #0x38]
100030da8: aa1f03e0    	mov	x0, xzr
100030dac: aa1f03e1    	mov	x1, xzr
100030db0: f8686ae8    	ldr	x8, [x23, x8]
100030db4: f82a7928    	str	x8, [x9, x10, lsl #3]
100030db8: 17fffee4    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030dbc: b9401b80    	ldr	w0, [x28, #0x18]
100030dc0: eb00029f    	cmp	x20, x0
100030dc4: 540087e9    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030dc8: 8b0012e8    	add	x8, x23, x0, lsl #4
100030dcc: a9400500    	ldp	x0, x1, [x8]
100030dd0: 17fffede    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030dd4: f94017e8    	ldr	x8, [sp, #0x28]
100030dd8: b4007b48    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030ddc: f9403d01    	ldr	x1, [x8, #0x78]
100030de0: b9401b80    	ldr	w0, [x28, #0x18]
100030de4: eb00003f    	cmp	x1, x0
100030de8: 54008789    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030dec: f9403908    	ldr	x8, [x8, #0x70]
100030df0: ab000d08    	adds	x8, x8, x0, lsl #3
100030df4: 54007a60    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030df8: f9400108    	ldr	x8, [x8]
100030dfc: b4007a28    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030e00: f9400900    	ldr	x0, [x8, #0x10]
100030e04: 94006e12    	bl	0x10004c64c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages>
100030e08: f9401fef    	ldr	x15, [sp, #0x38]
100030e0c: aa1f03e1    	mov	x1, xzr
100030e10: 17fffece    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e14: b9401b80    	ldr	w0, [x28, #0x18]
100030e18: aa1f03e1    	mov	x1, xzr
100030e1c: 17fffecb    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e20: aa0803e0    	mov	x0, x8
100030e24: 2a0903e1    	mov	w1, w9
100030e28: 9400709e    	bl	0x10004d0a0 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
100030e2c: 2a0003f9    	mov	w25, w0
100030e30: aa1f03e0    	mov	x0, xzr
100030e34: aa1f03e1    	mov	x1, xzr
100030e38: 17fffec1    	b	0x10003093c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
100030e3c: 7100153f    	cmp	w9, #0x5
100030e40: 54007e00    	b.eq	0x100031e00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
100030e44: b9401b89    	ldr	w9, [x28, #0x18]
100030e48: f94075e1    	ldr	x1, [x15, #0xe8]
100030e4c: 0b080120    	add	w0, w9, w8
100030e50: eb00003f    	cmp	x1, x0
100030e54: 54008429    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030e58: f94071e8    	ldr	x8, [x15, #0xe0]
100030e5c: 52800189    	mov	w9, #0xc                ; =12
100030e60: 9ba92008    	umaddl	x8, w0, w9, x8
100030e64: 2940651c    	ldp	w28, w25, [x8]
100030e68: b940091b    	ldr	w27, [x8, #0x8]
100030e6c: 6b18039f    	cmp	w28, w24
100030e70: 540000e8    	b.hi	0x100030e8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
100030e74: aa1503e0    	mov	x0, x21
100030e78: 94000f23    	bl	0x100034b04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
100030e7c: f9401fef    	ldr	x15, [sp, #0x38]
100030e80: b4000060    	cbz	x0, 0x100030e8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
100030e84: f9400408    	ldr	x8, [x0, #0x8]
100030e88: b5007b48    	cbnz	x8, 0x100031df0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e08>
100030e8c: f94085e8    	ldr	x8, [x15, #0x108]
100030e90: 0b190362    	add	w2, w27, w25
100030e94: eb02011f    	cmp	x8, x2
100030e98: 540086e3    	b.lo	0x100031f74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f8c>
100030e9c: 6b02033f    	cmp	w25, w2
100030ea0: 54008628    	b.hi	0x100031f64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f7c>
100030ea4: cb190108    	sub	x8, x8, x25
100030ea8: d37df329    	lsl	x9, x25, #3
100030eac: f100011f    	cmp	x8, #0x0
100030eb0: 9a9fc128    	csel	x8, x9, xzr, gt
100030eb4: 3400025b    	cbz	w27, 0x100030efc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
100030eb8: f9407de9    	ldr	x9, [x15, #0xf8]
100030ebc: b94027fb    	ldr	w27, [sp, #0x24]
100030ec0: 8b080128    	add	x8, x9, x8
100030ec4: cb190049    	sub	x9, x2, x25
100030ec8: 9100110a    	add	x10, x8, #0x4
100030ecc: b9400140    	ldr	w0, [x10]
100030ed0: eb00029f    	cmp	x20, x0
100030ed4: 54007f69    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030ed8: b85fc148    	ldur	w8, [x10, #-0x4]
100030edc: eb08029f    	cmp	x20, x8
100030ee0: 54007f49    	b.ls	0x100031ec8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030ee4: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
100030ee8: f1000529    	subs	x9, x9, #0x1
100030eec: 9100214a    	add	x10, x10, #0x8
100030ef0: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
100030ef4: 54fffec1    	b.ne	0x100030ecc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xee4>
100030ef8: 17fffc72    	b	0x1000300c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
100030efc: b94027fb    	ldr	w27, [sp, #0x24]
100030f00: 17fffc70    	b	0x1000300c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
100030f04: 71000d1f    	cmp	w8, #0x3
100030f08: 540070c0    	b.eq	0x100031d20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d38>
100030f0c: 7100191f    	cmp	w8, #0x6
100030f10: 54006e00    	b.eq	0x100031cd0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
100030f14: 51004928    	sub	w8, w9, #0x12
100030f18: 7100111f    	cmp	w8, #0x4
100030f1c: 54006ee3    	b.lo	0x100031cf8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d10>
100030f20: b9400f80    	ldr	w0, [x28, #0xc]
100030f24: 3100041f    	cmn	w0, #0x1
100030f28: 54005b00    	b.eq	0x100031a88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aa0>
100030f2c: eb00029f    	cmp	x20, x0
100030f30: 54007d89    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f34: d37cec08    	lsl	x8, x0, #4
100030f38: f8686ae5    	ldr	x5, [x23, x8]
100030f3c: b9401380    	ldr	w0, [x28, #0x10]
100030f40: 3100041f    	cmn	w0, #0x1
100030f44: 54005aa0    	b.eq	0x100031a98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ab0>
100030f48: eb00029f    	cmp	x20, x0
100030f4c: 54007ca9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f50: d37cec08    	lsl	x8, x0, #4
100030f54: f8686ae7    	ldr	x7, [x23, x8]
100030f58: b9401780    	ldr	w0, [x28, #0x14]
100030f5c: 3100041f    	cmn	w0, #0x1
100030f60: 54005a40    	b.eq	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ac0>
100030f64: eb00029f    	cmp	x20, x0
100030f68: 54007ac9    	b.ls	0x100031ec0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030f6c: d37cec08    	lsl	x8, x0, #4
100030f70: f8686aea    	ldr	x10, [x23, x8]
100030f74: 12103d28    	and	w8, w9, #0xffff0000
100030f78: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100030f7c: 540059e1    	b.ne	0x100031ab8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ad0>
100030f80: 12003d24    	and	w4, w9, #0xffff
100030f84: 71000c9f    	cmp	w4, #0x3
100030f88: 54006441    	b.ne	0x100031c10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c28>
100030f8c: f94002a8    	ldr	x8, [x21]
100030f90: b4006d88    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030f94: f9400500    	ldr	x0, [x8, #0x8]
100030f98: 94006afc    	bl	0x10004bb88 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
100030f9c: f9401fef    	ldr	x15, [sp, #0x38]
100030fa0: aa1f03e0    	mov	x0, xzr
100030fa4: aa1f03e1    	mov	x1, xzr
100030fa8: 17fffe68    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030fac: b9400f80    	ldr	w0, [x28, #0xc]
100030fb0: eb00029f    	cmp	x20, x0
100030fb4: 54007969    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030fb8: b9401388    	ldr	w8, [x28, #0x10]
100030fbc: eb08029f    	cmp	x20, x8
100030fc0: 540078e9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030fc4: d37cec09    	lsl	x9, x0, #4
100030fc8: d37ced08    	lsl	x8, x8, #4
100030fcc: aa1f03e1    	mov	x1, xzr
100030fd0: f8696ae9    	ldr	x9, [x23, x9]
100030fd4: f8686ae8    	ldr	x8, [x23, x8]
100030fd8: ca090100    	eor	x0, x8, x9
100030fdc: 17fffe5b    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030fe0: b9400f80    	ldr	w0, [x28, #0xc]
100030fe4: eb00029f    	cmp	x20, x0
100030fe8: 540077c9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030fec: b9401388    	ldr	w8, [x28, #0x10]
100030ff0: eb08029f    	cmp	x20, x8
100030ff4: 54007749    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030ff8: d37cec09    	lsl	x9, x0, #4
100030ffc: d37ced08    	lsl	x8, x8, #4
100031000: aa1f03e1    	mov	x1, xzr
100031004: f8696ae9    	ldr	x9, [x23, x9]
100031008: f8686ae8    	ldr	x8, [x23, x8]
10003100c: 9ac82520    	lsr	x0, x9, x8
100031010: 17fffe4e    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031014: b9400f80    	ldr	w0, [x28, #0xc]
100031018: eb00029f    	cmp	x20, x0
10003101c: 54007629    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031020: b9401388    	ldr	w8, [x28, #0x10]
100031024: eb08029f    	cmp	x20, x8
100031028: 540075a9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003102c: d37cec09    	lsl	x9, x0, #4
100031030: d37ced08    	lsl	x8, x8, #4
100031034: aa1f03e1    	mov	x1, xzr
100031038: b8696ae9    	ldr	w9, [x23, x9]
10003103c: b8686ae8    	ldr	w8, [x23, x8]
100031040: 1ac82920    	asr	w0, w9, w8
100031044: 17fffe41    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031048: b9400f80    	ldr	w0, [x28, #0xc]
10003104c: eb00029f    	cmp	x20, x0
100031050: 54007489    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031054: b9401388    	ldr	w8, [x28, #0x10]
100031058: eb08029f    	cmp	x20, x8
10003105c: 54007409    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031060: d37cec09    	lsl	x9, x0, #4
100031064: d37ced08    	lsl	x8, x8, #4
100031068: aa1f03e1    	mov	x1, xzr
10003106c: f8696ae9    	ldr	x9, [x23, x9]
100031070: f8686ae8    	ldr	x8, [x23, x8]
100031074: aa090100    	orr	x0, x8, x9
100031078: 17fffe34    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003107c: b9400f80    	ldr	w0, [x28, #0xc]
100031080: eb00029f    	cmp	x20, x0
100031084: 540072e9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031088: b9401388    	ldr	w8, [x28, #0x10]
10003108c: eb08029f    	cmp	x20, x8
100031090: 54007269    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031094: d37cec09    	lsl	x9, x0, #4
100031098: d37ced08    	lsl	x8, x8, #4
10003109c: aa1f03e1    	mov	x1, xzr
1000310a0: b8696ae9    	ldr	w9, [x23, x9]
1000310a4: b8686ae8    	ldr	w8, [x23, x8]
1000310a8: 1ac82120    	lsl	w0, w9, w8
1000310ac: 17fffe27    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310b0: b9400f80    	ldr	w0, [x28, #0xc]
1000310b4: eb00029f    	cmp	x20, x0
1000310b8: 54007149    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000310bc: b9401388    	ldr	w8, [x28, #0x10]
1000310c0: eb08029f    	cmp	x20, x8
1000310c4: 540070c9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000310c8: d37cec09    	lsl	x9, x0, #4
1000310cc: d37ced08    	lsl	x8, x8, #4
1000310d0: aa1f03e1    	mov	x1, xzr
1000310d4: b8696ae9    	ldr	w9, [x23, x9]
1000310d8: b8686ae8    	ldr	w8, [x23, x8]
1000310dc: 2a090100    	orr	w0, w8, w9
1000310e0: 17fffe1a    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310e4: b9400f80    	ldr	w0, [x28, #0xc]
1000310e8: eb00029f    	cmp	x20, x0
1000310ec: 54006fa9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000310f0: d37cec08    	lsl	x8, x0, #4
1000310f4: aa1f03e1    	mov	x1, xzr
1000310f8: f8686ae8    	ldr	x8, [x23, x8]
1000310fc: dac00108    	rbit	x8, x8
100031100: dac01100    	clz	x0, x8
100031104: 17fffe11    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031108: b9400f80    	ldr	w0, [x28, #0xc]
10003110c: eb00029f    	cmp	x20, x0
100031110: 54006e89    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031114: b9401388    	ldr	w8, [x28, #0x10]
100031118: eb08029f    	cmp	x20, x8
10003111c: 54006e09    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031120: d37cec09    	lsl	x9, x0, #4
100031124: d37ced08    	lsl	x8, x8, #4
100031128: aa1f03e1    	mov	x1, xzr
10003112c: f8696ae9    	ldr	x9, [x23, x9]
100031130: f8686ae8    	ldr	x8, [x23, x8]
100031134: eb08013f    	cmp	x9, x8
100031138: 1a9f27e0    	cset	w0, lo
10003113c: 17fffe03    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031140: b9400f80    	ldr	w0, [x28, #0xc]
100031144: eb00029f    	cmp	x20, x0
100031148: 54006cc9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003114c: b9401388    	ldr	w8, [x28, #0x10]
100031150: eb08029f    	cmp	x20, x8
100031154: 54006c49    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031158: d37cec09    	lsl	x9, x0, #4
10003115c: d37ced08    	lsl	x8, x8, #4
100031160: aa1f03e1    	mov	x1, xzr
100031164: f8696ae9    	ldr	x9, [x23, x9]
100031168: f8686ae8    	ldr	x8, [x23, x8]
10003116c: eb08013f    	cmp	x9, x8
100031170: 1a9f87e0    	cset	w0, ls
100031174: 17fffdf5    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031178: b9400f80    	ldr	w0, [x28, #0xc]
10003117c: eb00029f    	cmp	x20, x0
100031180: 54006b09    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031184: b9401388    	ldr	w8, [x28, #0x10]
100031188: eb08029f    	cmp	x20, x8
10003118c: 54006a89    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031190: d37cec09    	lsl	x9, x0, #4
100031194: d37ced08    	lsl	x8, x8, #4
100031198: aa1f03e1    	mov	x1, xzr
10003119c: f8696ae9    	ldr	x9, [x23, x9]
1000311a0: f8686ae8    	ldr	x8, [x23, x8]
1000311a4: eb08013f    	cmp	x9, x8
1000311a8: 1a9f97e0    	cset	w0, hi
1000311ac: 17fffde7    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000311b0: b9400f80    	ldr	w0, [x28, #0xc]
1000311b4: eb00029f    	cmp	x20, x0
1000311b8: 54006949    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000311bc: b9401388    	ldr	w8, [x28, #0x10]
1000311c0: eb08029f    	cmp	x20, x8
1000311c4: 540068c9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000311c8: d37cec09    	lsl	x9, x0, #4
1000311cc: d37ced08    	lsl	x8, x8, #4
1000311d0: aa1f03e1    	mov	x1, xzr
1000311d4: b8696ae9    	ldr	w9, [x23, x9]
1000311d8: b8686ae8    	ldr	w8, [x23, x8]
1000311dc: 4b080120    	sub	w0, w9, w8
1000311e0: 17fffdda    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000311e4: b9400f80    	ldr	w0, [x28, #0xc]
1000311e8: eb00029f    	cmp	x20, x0
1000311ec: 540067a9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000311f0: d37cec08    	lsl	x8, x0, #4
1000311f4: 5280040b    	mov	w11, #0x20              ; =32
1000311f8: 5280030c    	mov	w12, #0x18              ; =24
1000311fc: aa1f03e1    	mov	x1, xzr
100031200: b8686ae8    	ldr	w8, [x23, x8]
100031204: 53107d09    	lsr	w9, w8, #16
100031208: 7100013f    	cmp	w9, #0x0
10003120c: 1a881128    	csel	w8, w9, w8, ne
100031210: 928001e9    	mov	x9, #-0x10              ; =-16
100031214: 53087d0a    	lsr	w10, w8, #8
100031218: 9a9f1129    	csel	x9, x9, xzr, ne
10003121c: 7103fd1f    	cmp	w8, #0xff
100031220: 1a888148    	csel	w8, w10, w8, hi
100031224: 9000140a    	adrp	x10, 0x1002b1000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xf78>
100031228: 9120754a    	add	x10, x10, #0x81d
10003122c: 92401d08    	and	x8, x8, #0xff
100031230: 38686948    	ldrb	w8, [x10, x8]
100031234: 9a8b818a    	csel	x10, x12, x11, hi
100031238: 8b090149    	add	x9, x10, x9
10003123c: cb080120    	sub	x0, x9, x8
100031240: 17fffdc2    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031244: b9400f80    	ldr	w0, [x28, #0xc]
100031248: eb00029f    	cmp	x20, x0
10003124c: 540064a9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031250: b9401388    	ldr	w8, [x28, #0x10]
100031254: eb08029f    	cmp	x20, x8
100031258: 54006429    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003125c: d37cec09    	lsl	x9, x0, #4
100031260: d37ced08    	lsl	x8, x8, #4
100031264: aa1f03e1    	mov	x1, xzr
100031268: b8696ae9    	ldr	w9, [x23, x9]
10003126c: b8686ae8    	ldr	w8, [x23, x8]
100031270: 1ac82520    	lsr	w0, w9, w8
100031274: 17fffdb5    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031278: b9400f80    	ldr	w0, [x28, #0xc]
10003127c: eb00029f    	cmp	x20, x0
100031280: 54006309    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031284: b9401388    	ldr	w8, [x28, #0x10]
100031288: eb08029f    	cmp	x20, x8
10003128c: 54006289    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031290: d37cec09    	lsl	x9, x0, #4
100031294: d37ced08    	lsl	x8, x8, #4
100031298: aa1f03e1    	mov	x1, xzr
10003129c: f8696ae9    	ldr	x9, [x23, x9]
1000312a0: f8686ae8    	ldr	x8, [x23, x8]
1000312a4: eb08013f    	cmp	x9, x8
1000312a8: 1a9fd7e0    	cset	w0, gt
1000312ac: 17fffda7    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000312b0: b9400f80    	ldr	w0, [x28, #0xc]
1000312b4: eb00029f    	cmp	x20, x0
1000312b8: 54006149    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000312bc: b9401388    	ldr	w8, [x28, #0x10]
1000312c0: eb08029f    	cmp	x20, x8
1000312c4: 540060c9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000312c8: d37cec09    	lsl	x9, x0, #4
1000312cc: d37ced08    	lsl	x8, x8, #4
1000312d0: aa1f03e1    	mov	x1, xzr
1000312d4: b8696ae9    	ldr	w9, [x23, x9]
1000312d8: b8686ae8    	ldr	w8, [x23, x8]
1000312dc: 6b08013f    	cmp	w9, w8
1000312e0: 1a9fa7e0    	cset	w0, lt
1000312e4: 17fffd99    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000312e8: b9400f80    	ldr	w0, [x28, #0xc]
1000312ec: eb00029f    	cmp	x20, x0
1000312f0: 54005f89    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000312f4: b9401388    	ldr	w8, [x28, #0x10]
1000312f8: eb08029f    	cmp	x20, x8
1000312fc: 54005f09    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031300: d37cec09    	lsl	x9, x0, #4
100031304: d37ced08    	lsl	x8, x8, #4
100031308: aa1f03e1    	mov	x1, xzr
10003130c: f8696ae9    	ldr	x9, [x23, x9]
100031310: f8686ae8    	ldr	x8, [x23, x8]
100031314: eb08013f    	cmp	x9, x8
100031318: 1a9f07e0    	cset	w0, ne
10003131c: 17fffd8b    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031320: b9400f80    	ldr	w0, [x28, #0xc]
100031324: eb00029f    	cmp	x20, x0
100031328: 54005dc9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003132c: d37cec08    	lsl	x8, x0, #4
100031330: b8686ae8    	ldr	w8, [x23, x8]
100031334: 34004b88    	cbz	w8, 0x100031ca4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cbc>
100031338: 5ac00108    	rbit	w8, w8
10003133c: aa1f03e1    	mov	x1, xzr
100031340: 5ac01100    	clz	w0, w8
100031344: 17fffd81    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031348: b9400f80    	ldr	w0, [x28, #0xc]
10003134c: eb00029f    	cmp	x20, x0
100031350: 54005c89    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031354: b9401388    	ldr	w8, [x28, #0x10]
100031358: eb08029f    	cmp	x20, x8
10003135c: 54005c09    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031360: d37cec09    	lsl	x9, x0, #4
100031364: d37ced08    	lsl	x8, x8, #4
100031368: aa1f03e1    	mov	x1, xzr
10003136c: b8696ae9    	ldr	w9, [x23, x9]
100031370: b8686ae8    	ldr	w8, [x23, x8]
100031374: 6b08013f    	cmp	w9, w8
100031378: 1a9f07e0    	cset	w0, ne
10003137c: 17fffd73    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031380: b9400f80    	ldr	w0, [x28, #0xc]
100031384: eb00029f    	cmp	x20, x0
100031388: 54005ac9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003138c: b9401388    	ldr	w8, [x28, #0x10]
100031390: eb08029f    	cmp	x20, x8
100031394: 54005a49    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031398: d37cec09    	lsl	x9, x0, #4
10003139c: d37ced08    	lsl	x8, x8, #4
1000313a0: aa1f03e1    	mov	x1, xzr
1000313a4: f8696ae9    	ldr	x9, [x23, x9]
1000313a8: f8686ae8    	ldr	x8, [x23, x8]
1000313ac: eb08013f    	cmp	x9, x8
1000313b0: 1a9fc7e0    	cset	w0, le
1000313b4: 17fffd65    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000313b8: b9400f80    	ldr	w0, [x28, #0xc]
1000313bc: eb00029f    	cmp	x20, x0
1000313c0: 54005909    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000313c4: b9401388    	ldr	w8, [x28, #0x10]
1000313c8: eb08029f    	cmp	x20, x8
1000313cc: 54005889    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000313d0: d37ced08    	lsl	x8, x8, #4
1000313d4: d37cec09    	lsl	x9, x0, #4
1000313d8: aa1f03e1    	mov	x1, xzr
1000313dc: b8686ae8    	ldr	w8, [x23, x8]
1000313e0: b8696ae9    	ldr	w9, [x23, x9]
1000313e4: 4b0803e8    	neg	w8, w8
1000313e8: 1ac82d20    	ror	w0, w9, w8
1000313ec: 17fffd57    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000313f0: b9400f80    	ldr	w0, [x28, #0xc]
1000313f4: eb00029f    	cmp	x20, x0
1000313f8: 54005749    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000313fc: b9401388    	ldr	w8, [x28, #0x10]
100031400: eb08029f    	cmp	x20, x8
100031404: 540056c9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031408: d37cec09    	lsl	x9, x0, #4
10003140c: d37ced08    	lsl	x8, x8, #4
100031410: aa1f03e1    	mov	x1, xzr
100031414: b8696ae9    	ldr	w9, [x23, x9]
100031418: b8686ae8    	ldr	w8, [x23, x8]
10003141c: 6b08013f    	cmp	w9, w8
100031420: 1a9f87e0    	cset	w0, ls
100031424: 17fffd49    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031428: b9400f80    	ldr	w0, [x28, #0xc]
10003142c: eb00029f    	cmp	x20, x0
100031430: 54005589    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031434: b9401388    	ldr	w8, [x28, #0x10]
100031438: eb08029f    	cmp	x20, x8
10003143c: 54005509    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031440: d37cec09    	lsl	x9, x0, #4
100031444: d37ced08    	lsl	x8, x8, #4
100031448: aa1f03e1    	mov	x1, xzr
10003144c: b8696ae9    	ldr	w9, [x23, x9]
100031450: b8686ae8    	ldr	w8, [x23, x8]
100031454: 6b08013f    	cmp	w9, w8
100031458: 1a9fb7e0    	cset	w0, ge
10003145c: 17fffd3b    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031460: b9400f80    	ldr	w0, [x28, #0xc]
100031464: eb00029f    	cmp	x20, x0
100031468: 540053c9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003146c: d37cec08    	lsl	x8, x0, #4
100031470: aa1f03e1    	mov	x1, xzr
100031474: b8686ae8    	ldr	w8, [x23, x8]
100031478: 7100011f    	cmp	w8, #0x0
10003147c: 1a9f17e0    	cset	w0, eq
100031480: 17fffd32    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031484: b9400f80    	ldr	w0, [x28, #0xc]
100031488: eb00029f    	cmp	x20, x0
10003148c: 540052a9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031490: b9401388    	ldr	w8, [x28, #0x10]
100031494: eb08029f    	cmp	x20, x8
100031498: 54005229    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003149c: d37cec09    	lsl	x9, x0, #4
1000314a0: d37ced08    	lsl	x8, x8, #4
1000314a4: aa1f03e1    	mov	x1, xzr
1000314a8: b8696ae9    	ldr	w9, [x23, x9]
1000314ac: b8686ae8    	ldr	w8, [x23, x8]
1000314b0: 6b08013f    	cmp	w9, w8
1000314b4: 1a9f27e0    	cset	w0, lo
1000314b8: 17fffd24    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000314bc: b9400f80    	ldr	w0, [x28, #0xc]
1000314c0: eb00029f    	cmp	x20, x0
1000314c4: 540050e9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000314c8: b9401388    	ldr	w8, [x28, #0x10]
1000314cc: eb08029f    	cmp	x20, x8
1000314d0: 54005069    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000314d4: d37cec09    	lsl	x9, x0, #4
1000314d8: d37ced08    	lsl	x8, x8, #4
1000314dc: aa1f03e1    	mov	x1, xzr
1000314e0: f8696ae9    	ldr	x9, [x23, x9]
1000314e4: f8686ae8    	ldr	x8, [x23, x8]
1000314e8: 8b090100    	add	x0, x8, x9
1000314ec: 17fffd17    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000314f0: b9400f80    	ldr	w0, [x28, #0xc]
1000314f4: eb00029f    	cmp	x20, x0
1000314f8: 54004f49    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000314fc: b9401388    	ldr	w8, [x28, #0x10]
100031500: eb08029f    	cmp	x20, x8
100031504: 54004ec9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031508: d37cec09    	lsl	x9, x0, #4
10003150c: d37ced08    	lsl	x8, x8, #4
100031510: aa1f03e1    	mov	x1, xzr
100031514: b8696ae9    	ldr	w9, [x23, x9]
100031518: b8686ae8    	ldr	w8, [x23, x8]
10003151c: 4a090100    	eor	w0, w8, w9
100031520: 17fffd0a    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031524: b9400f80    	ldr	w0, [x28, #0xc]
100031528: eb00029f    	cmp	x20, x0
10003152c: 54004da9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031530: b9401388    	ldr	w8, [x28, #0x10]
100031534: eb08029f    	cmp	x20, x8
100031538: 54004d29    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003153c: d37cec09    	lsl	x9, x0, #4
100031540: d37ced08    	lsl	x8, x8, #4
100031544: aa1f03e1    	mov	x1, xzr
100031548: f8696ae9    	ldr	x9, [x23, x9]
10003154c: f8686ae8    	ldr	x8, [x23, x8]
100031550: 8a090100    	and	x0, x8, x9
100031554: 17fffcfd    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031558: b9400f80    	ldr	w0, [x28, #0xc]
10003155c: eb00029f    	cmp	x20, x0
100031560: 54004c09    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031564: b9401388    	ldr	w8, [x28, #0x10]
100031568: eb08029f    	cmp	x20, x8
10003156c: 54004b89    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031570: d37cec09    	lsl	x9, x0, #4
100031574: d37ced08    	lsl	x8, x8, #4
100031578: aa1f03e1    	mov	x1, xzr
10003157c: f8696ae9    	ldr	x9, [x23, x9]
100031580: f8686ae8    	ldr	x8, [x23, x8]
100031584: cb080120    	sub	x0, x9, x8
100031588: 17fffcf0    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003158c: b9400f80    	ldr	w0, [x28, #0xc]
100031590: eb00029f    	cmp	x20, x0
100031594: 54004a69    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031598: b9401388    	ldr	w8, [x28, #0x10]
10003159c: eb08029f    	cmp	x20, x8
1000315a0: 540049e9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000315a4: d37ced08    	lsl	x8, x8, #4
1000315a8: d37cec09    	lsl	x9, x0, #4
1000315ac: b8686ae8    	ldr	w8, [x23, x8]
1000315b0: f8696ae9    	ldr	x9, [x23, x9]
1000315b4: 4b0803e8    	neg	w8, w8
1000315b8: 1400006b    	b	0x100031764 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x177c>
1000315bc: b9400f80    	ldr	w0, [x28, #0xc]
1000315c0: eb00029f    	cmp	x20, x0
1000315c4: 540048e9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000315c8: b9401388    	ldr	w8, [x28, #0x10]
1000315cc: eb08029f    	cmp	x20, x8
1000315d0: 54004869    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000315d4: d37cec09    	lsl	x9, x0, #4
1000315d8: d37ced08    	lsl	x8, x8, #4
1000315dc: aa1f03e1    	mov	x1, xzr
1000315e0: b8696ae9    	ldr	w9, [x23, x9]
1000315e4: b8686ae8    	ldr	w8, [x23, x8]
1000315e8: 6b08013f    	cmp	w9, w8
1000315ec: 1a9f17e0    	cset	w0, eq
1000315f0: 17fffcd6    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000315f4: b9400f80    	ldr	w0, [x28, #0xc]
1000315f8: eb00029f    	cmp	x20, x0
1000315fc: 54004729    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031600: b9401388    	ldr	w8, [x28, #0x10]
100031604: eb08029f    	cmp	x20, x8
100031608: 540046a9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003160c: d37cec09    	lsl	x9, x0, #4
100031610: d37ced08    	lsl	x8, x8, #4
100031614: aa1f03e1    	mov	x1, xzr
100031618: b8696ae9    	ldr	w9, [x23, x9]
10003161c: b8686ae8    	ldr	w8, [x23, x8]
100031620: 6b08013f    	cmp	w9, w8
100031624: 1a9f37e0    	cset	w0, hs
100031628: 17fffcc8    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003162c: b9400f80    	ldr	w0, [x28, #0xc]
100031630: eb00029f    	cmp	x20, x0
100031634: 54004569    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031638: b9401388    	ldr	w8, [x28, #0x10]
10003163c: eb08029f    	cmp	x20, x8
100031640: 540044e9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031644: d37cec09    	lsl	x9, x0, #4
100031648: d37ced08    	lsl	x8, x8, #4
10003164c: aa1f03e1    	mov	x1, xzr
100031650: b8696ae9    	ldr	w9, [x23, x9]
100031654: b8686ae8    	ldr	w8, [x23, x8]
100031658: 1b097d00    	mul	w0, w8, w9
10003165c: 17fffcbb    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031660: b9400f80    	ldr	w0, [x28, #0xc]
100031664: eb00029f    	cmp	x20, x0
100031668: 540043c9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003166c: b9401388    	ldr	w8, [x28, #0x10]
100031670: eb08029f    	cmp	x20, x8
100031674: 54004349    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031678: d37cec09    	lsl	x9, x0, #4
10003167c: d37ced08    	lsl	x8, x8, #4
100031680: aa1f03e1    	mov	x1, xzr
100031684: b8696ae9    	ldr	w9, [x23, x9]
100031688: b8686ae8    	ldr	w8, [x23, x8]
10003168c: 6b08013f    	cmp	w9, w8
100031690: 1a9fc7e0    	cset	w0, le
100031694: 17fffcad    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031698: b9400f80    	ldr	w0, [x28, #0xc]
10003169c: eb00029f    	cmp	x20, x0
1000316a0: 54004209    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000316a4: b9401388    	ldr	w8, [x28, #0x10]
1000316a8: eb08029f    	cmp	x20, x8
1000316ac: 54004189    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000316b0: d37cec09    	lsl	x9, x0, #4
1000316b4: d37ced08    	lsl	x8, x8, #4
1000316b8: aa1f03e1    	mov	x1, xzr
1000316bc: b8696ae9    	ldr	w9, [x23, x9]
1000316c0: b8686ae8    	ldr	w8, [x23, x8]
1000316c4: 6b08013f    	cmp	w9, w8
1000316c8: 1a9fd7e0    	cset	w0, gt
1000316cc: 17fffc9f    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000316d0: b9400f80    	ldr	w0, [x28, #0xc]
1000316d4: eb00029f    	cmp	x20, x0
1000316d8: 54004049    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000316dc: b9401388    	ldr	w8, [x28, #0x10]
1000316e0: eb08029f    	cmp	x20, x8
1000316e4: 54003fc9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000316e8: d37cec09    	lsl	x9, x0, #4
1000316ec: d37ced08    	lsl	x8, x8, #4
1000316f0: aa1f03e1    	mov	x1, xzr
1000316f4: b8696ae9    	ldr	w9, [x23, x9]
1000316f8: b8686ae8    	ldr	w8, [x23, x8]
1000316fc: 1ac82d20    	ror	w0, w9, w8
100031700: 17fffc92    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031704: b9400f80    	ldr	w0, [x28, #0xc]
100031708: eb00029f    	cmp	x20, x0
10003170c: 54003ea9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031710: b9401388    	ldr	w8, [x28, #0x10]
100031714: eb08029f    	cmp	x20, x8
100031718: 54003e29    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003171c: d37cec09    	lsl	x9, x0, #4
100031720: d37ced08    	lsl	x8, x8, #4
100031724: aa1f03e1    	mov	x1, xzr
100031728: f8696ae9    	ldr	x9, [x23, x9]
10003172c: f8686ae8    	ldr	x8, [x23, x8]
100031730: eb08013f    	cmp	x9, x8
100031734: 1a9fa7e0    	cset	w0, lt
100031738: 17fffc84    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003173c: b9400f80    	ldr	w0, [x28, #0xc]
100031740: eb00029f    	cmp	x20, x0
100031744: 54003ce9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031748: b9401388    	ldr	w8, [x28, #0x10]
10003174c: eb08029f    	cmp	x20, x8
100031750: 54003c69    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031754: d37cec09    	lsl	x9, x0, #4
100031758: d37ced08    	lsl	x8, x8, #4
10003175c: f8696ae9    	ldr	x9, [x23, x9]
100031760: f8686ae8    	ldr	x8, [x23, x8]
100031764: 9ac82d20    	ror	x0, x9, x8
100031768: aa1f03e1    	mov	x1, xzr
10003176c: 17fffc77    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031770: b9400f80    	ldr	w0, [x28, #0xc]
100031774: eb00029f    	cmp	x20, x0
100031778: 54003b49    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003177c: b9401388    	ldr	w8, [x28, #0x10]
100031780: eb08029f    	cmp	x20, x8
100031784: 54003ac9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031788: d37cec09    	lsl	x9, x0, #4
10003178c: d37ced08    	lsl	x8, x8, #4
100031790: aa1f03e1    	mov	x1, xzr
100031794: b8696ae9    	ldr	w9, [x23, x9]
100031798: b8686ae8    	ldr	w8, [x23, x8]
10003179c: 6b08013f    	cmp	w9, w8
1000317a0: 1a9f97e0    	cset	w0, hi
1000317a4: 17fffc69    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000317a8: b9400f80    	ldr	w0, [x28, #0xc]
1000317ac: eb00029f    	cmp	x20, x0
1000317b0: 54003989    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000317b4: d37cec08    	lsl	x8, x0, #4
1000317b8: aa1f03e1    	mov	x1, xzr
1000317bc: 38a86ae0    	ldrsb	x0, [x23, x8]
1000317c0: 17fffc62    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000317c4: b9400f80    	ldr	w0, [x28, #0xc]
1000317c8: eb00029f    	cmp	x20, x0
1000317cc: 540038a9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000317d0: d37cec08    	lsl	x8, x0, #4
1000317d4: aa1f03e1    	mov	x1, xzr
1000317d8: 78a86ae0    	ldrsh	x0, [x23, x8]
1000317dc: 17fffc5b    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000317e0: b9400f80    	ldr	w0, [x28, #0xc]
1000317e4: eb00029f    	cmp	x20, x0
1000317e8: 540037c9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000317ec: b9401388    	ldr	w8, [x28, #0x10]
1000317f0: eb08029f    	cmp	x20, x8
1000317f4: 54003749    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000317f8: d37cec09    	lsl	x9, x0, #4
1000317fc: d37ced08    	lsl	x8, x8, #4
100031800: aa1f03e1    	mov	x1, xzr
100031804: f8696ae9    	ldr	x9, [x23, x9]
100031808: f8686ae8    	ldr	x8, [x23, x8]
10003180c: eb08013f    	cmp	x9, x8
100031810: 1a9f17e0    	cset	w0, eq
100031814: 17fffc4d    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031818: b9400f80    	ldr	w0, [x28, #0xc]
10003181c: eb00029f    	cmp	x20, x0
100031820: 54003609    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031824: b9401388    	ldr	w8, [x28, #0x10]
100031828: eb08029f    	cmp	x20, x8
10003182c: 54003589    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031830: d37cec09    	lsl	x9, x0, #4
100031834: d37ced08    	lsl	x8, x8, #4
100031838: aa1f03e1    	mov	x1, xzr
10003183c: f8696ae9    	ldr	x9, [x23, x9]
100031840: f8686ae8    	ldr	x8, [x23, x8]
100031844: eb08013f    	cmp	x9, x8
100031848: 1a9f37e0    	cset	w0, hs
10003184c: 17fffc3f    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031850: b9400f80    	ldr	w0, [x28, #0xc]
100031854: eb00029f    	cmp	x20, x0
100031858: 54003449    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003185c: b9401388    	ldr	w8, [x28, #0x10]
100031860: eb08029f    	cmp	x20, x8
100031864: 540033c9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031868: d37cec09    	lsl	x9, x0, #4
10003186c: d37ced08    	lsl	x8, x8, #4
100031870: aa1f03e1    	mov	x1, xzr
100031874: f8696ae9    	ldr	x9, [x23, x9]
100031878: f8686ae8    	ldr	x8, [x23, x8]
10003187c: eb08013f    	cmp	x9, x8
100031880: 1a9fb7e0    	cset	w0, ge
100031884: 17fffc31    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031888: b9400f80    	ldr	w0, [x28, #0xc]
10003188c: eb00029f    	cmp	x20, x0
100031890: 54003289    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031894: b9401388    	ldr	w8, [x28, #0x10]
100031898: eb08029f    	cmp	x20, x8
10003189c: 54003209    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000318a0: d37cec09    	lsl	x9, x0, #4
1000318a4: d37ced08    	lsl	x8, x8, #4
1000318a8: aa1f03e1    	mov	x1, xzr
1000318ac: f8696ae9    	ldr	x9, [x23, x9]
1000318b0: f8686ae8    	ldr	x8, [x23, x8]
1000318b4: 9ac82920    	asr	x0, x9, x8
1000318b8: 17fffc24    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000318bc: b9400f80    	ldr	w0, [x28, #0xc]
1000318c0: eb00029f    	cmp	x20, x0
1000318c4: 540030e9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000318c8: b9401388    	ldr	w8, [x28, #0x10]
1000318cc: eb08029f    	cmp	x20, x8
1000318d0: 54003069    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000318d4: d37cec09    	lsl	x9, x0, #4
1000318d8: d37ced08    	lsl	x8, x8, #4
1000318dc: aa1f03e1    	mov	x1, xzr
1000318e0: b8696ae9    	ldr	w9, [x23, x9]
1000318e4: b8686ae8    	ldr	w8, [x23, x8]
1000318e8: 0a080120    	and	w0, w9, w8
1000318ec: 17fffc17    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000318f0: b9400f80    	ldr	w0, [x28, #0xc]
1000318f4: eb00029f    	cmp	x20, x0
1000318f8: 54002f49    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000318fc: b9401388    	ldr	w8, [x28, #0x10]
100031900: eb08029f    	cmp	x20, x8
100031904: 54002ec9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031908: d37cec09    	lsl	x9, x0, #4
10003190c: d37ced08    	lsl	x8, x8, #4
100031910: aa1f03e1    	mov	x1, xzr
100031914: b8696ae9    	ldr	w9, [x23, x9]
100031918: b8686ae8    	ldr	w8, [x23, x8]
10003191c: 0b090100    	add	w0, w8, w9
100031920: 17fffc0a    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031924: b9400f80    	ldr	w0, [x28, #0xc]
100031928: eb00029f    	cmp	x20, x0
10003192c: 54002da9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031930: b9401388    	ldr	w8, [x28, #0x10]
100031934: eb08029f    	cmp	x20, x8
100031938: 54002d29    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003193c: d37cec09    	lsl	x9, x0, #4
100031940: d37ced08    	lsl	x8, x8, #4
100031944: aa1f03e1    	mov	x1, xzr
100031948: f8696ae9    	ldr	x9, [x23, x9]
10003194c: f8686ae8    	ldr	x8, [x23, x8]
100031950: 9b097d00    	mul	x0, x8, x9
100031954: 17fffbfd    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031958: b9400f80    	ldr	w0, [x28, #0xc]
10003195c: eb00029f    	cmp	x20, x0
100031960: 54002c09    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031964: d37cec08    	lsl	x8, x0, #4
100031968: aa1f03e1    	mov	x1, xzr
10003196c: 38a86ae8    	ldrsb	x8, [x23, x8]
100031970: 2a0803e0    	mov	w0, w8
100031974: 17fffbf5    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031978: b9400f80    	ldr	w0, [x28, #0xc]
10003197c: eb00029f    	cmp	x20, x0
100031980: 54002b09    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031984: d37cec08    	lsl	x8, x0, #4
100031988: 5280040a    	mov	w10, #0x20              ; =32
10003198c: aa1f03e1    	mov	x1, xzr
100031990: f8686ae8    	ldr	x8, [x23, x8]
100031994: d360fd09    	lsr	x9, x8, #32
100031998: f100013f    	cmp	x9, #0x0
10003199c: 9a881128    	csel	x8, x9, x8, ne
1000319a0: 9a9f114a    	csel	x10, x10, xzr, ne
1000319a4: d350fd09    	lsr	x9, x8, #16
1000319a8: f100013f    	cmp	x9, #0x0
1000319ac: 9a881128    	csel	x8, x9, x8, ne
1000319b0: b27c0149    	orr	x9, x10, #0x10
1000319b4: d348fd0b    	lsr	x11, x8, #8
1000319b8: 9a8a1129    	csel	x9, x9, x10, ne
1000319bc: f103fd1f    	cmp	x8, #0xff
1000319c0: b27d012a    	orr	x10, x9, #0x8
1000319c4: 9a888168    	csel	x8, x11, x8, hi
1000319c8: 9000140b    	adrp	x11, 0x1002b1000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xf78>
1000319cc: 9120756b    	add	x11, x11, #0x81d
1000319d0: 92401d08    	and	x8, x8, #0xff
1000319d4: 9a898149    	csel	x9, x10, x9, hi
1000319d8: 5280080a    	mov	w10, #0x40              ; =64
1000319dc: 38686968    	ldrb	w8, [x11, x8]
1000319e0: cb090149    	sub	x9, x10, x9
1000319e4: cb080120    	sub	x0, x9, x8
1000319e8: 17fffbd8    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000319ec: b9400f80    	ldr	w0, [x28, #0xc]
1000319f0: eb00029f    	cmp	x20, x0
1000319f4: 54002769    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000319f8: b9401388    	ldr	w8, [x28, #0x10]
1000319fc: eb08029f    	cmp	x20, x8
100031a00: 540026e9    	b.ls	0x100031edc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031a04: d37cec09    	lsl	x9, x0, #4
100031a08: d37ced08    	lsl	x8, x8, #4
100031a0c: aa1f03e1    	mov	x1, xzr
100031a10: f8696ae9    	ldr	x9, [x23, x9]
100031a14: f8686ae8    	ldr	x8, [x23, x8]
100031a18: 9ac82120    	lsl	x0, x9, x8
100031a1c: 17fffbcb    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031a20: b9400f80    	ldr	w0, [x28, #0xc]
100031a24: eb00029f    	cmp	x20, x0
100031a28: 540025c9    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031a2c: d37cec08    	lsl	x8, x0, #4
100031a30: aa1f03e1    	mov	x1, xzr
100031a34: 78a86ae8    	ldrsh	x8, [x23, x8]
100031a38: 2a0803e0    	mov	w0, w8
100031a3c: 17fffbc3    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031a40: 51022d28    	sub	w8, w9, #0x8b
100031a44: 7100d11f    	cmp	w8, #0x34
100031a48: 540000c8    	b.hi	0x100031a60 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a78>
100031a4c: 92a2000a    	mov	x10, #-0x10000001       ; =-268435457
100031a50: f2dfff2a    	movk	x10, #0xfff9, lsl #32
100031a54: f2e003ea    	movk	x10, #0x1f, lsl #48
100031a58: 9ac82548    	lsr	x8, x10, x8
100031a5c: 37074408    	tbnz	w8, #0x0, 0x1000302dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
100031a60: 51018528    	sub	w8, w9, #0x61
100031a64: aa1f03e0    	mov	x0, xzr
100031a68: 7100851f    	cmp	w8, #0x21
100031a6c: 540012e8    	b.hi	0x100031cc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce0>
100031a70: b2620fea    	mov	x10, #0x3c0000000       ; =16106127360
100031a74: aa0003e1    	mov	x1, x0
100031a78: f29e07ea    	movk	x10, #0xf03f
100031a7c: 9ac82548    	lsr	x8, x10, x8
100031a80: 370742e8    	tbnz	w8, #0x0, 0x1000302dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
100031a84: 17fffbb1    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031a88: aa1f03e5    	mov	x5, xzr
100031a8c: b9401380    	ldr	w0, [x28, #0x10]
100031a90: 3100041f    	cmn	w0, #0x1
100031a94: 54ffa5a1    	b.ne	0x100030f48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf60>
100031a98: aa1f03e7    	mov	x7, xzr
100031a9c: b9401780    	ldr	w0, [x28, #0x14]
100031aa0: 3100041f    	cmn	w0, #0x1
100031aa4: 54ffa601    	b.ne	0x100030f64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf7c>
100031aa8: aa1f03ea    	mov	x10, xzr
100031aac: 12103d28    	and	w8, w9, #0xffff0000
100031ab0: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100031ab4: 54ffa660    	b.eq	0x100030f80 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf98>
100031ab8: 529ffda8    	mov	w8, #0xffed             ; =65517
100031abc: 72bfe068    	movk	w8, #0xff03, lsl #16
100031ac0: 0b090108    	add	w8, w8, w9
100031ac4: 11002d08    	add	w8, w8, #0xb
100031ac8: 7100291f    	cmp	w8, #0xa
100031acc: 54002802    	b.hs	0x100031fcc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
100031ad0: f94041e1    	ldr	x1, [x15, #0x80]
100031ad4: b9400780    	ldr	w0, [x28, #0x4]
100031ad8: eb00003f    	cmp	x1, x0
100031adc: 54001fe9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100031ae0: f9403de8    	ldr	x8, [x15, #0x78]
100031ae4: 52801c09    	mov	w9, #0xe0               ; =224
100031ae8: 9ba92008    	umaddl	x8, w0, w9, x8
100031aec: b40012a8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100031af0: b9400109    	ldr	w9, [x8]
100031af4: f940050b    	ldr	x11, [x8, #0x8]
100031af8: 910363ec    	add	x12, sp, #0xd8
100031afc: 3dc00500    	ldr	q0, [x8, #0x10]
100031b00: 3cc48101    	ldur	q1, [x8, #0x48]
100031b04: 910363e2    	add	x2, sp, #0xd8
100031b08: b900dbe9    	str	w9, [sp, #0xd8]
100031b0c: 3cc68102    	ldur	q2, [x8, #0x68]
100031b10: aa1503e0    	mov	x0, x21
100031b14: f90073eb    	str	x11, [sp, #0xe0]
100031b18: a9422d09    	ldp	x9, x11, [x8, #0x20]
100031b1c: 3d800580    	str	q0, [x12, #0x10]
100031b20: aa0503e3    	mov	x3, x5
100031b24: aa1f03e4    	mov	x4, xzr
100031b28: 3dc00d00    	ldr	q0, [x8, #0x30]
100031b2c: 3c848181    	stur	q1, [x12, #0x48]
100031b30: aa0703e5    	mov	x5, x7
100031b34: a90fafe9    	stp	x9, x11, [sp, #0xf8]
100031b38: 39410109    	ldrb	w9, [x8, #0x40]
100031b3c: aa1f03e6    	mov	x6, xzr
100031b40: 3d800d80    	str	q0, [x12, #0x30]
100031b44: 3cc58100    	ldur	q0, [x8, #0x58]
100031b48: aa0a03e7    	mov	x7, x10
100031b4c: 390463e9    	strb	w9, [sp, #0x118]
100031b50: 3cc78101    	ldur	q1, [x8, #0x78]
100031b54: f94017e1    	ldr	x1, [sp, #0x28]
100031b58: 3c858180    	stur	q0, [x12, #0x58]
100031b5c: 3cc88100    	ldur	q0, [x8, #0x88]
100031b60: a949a109    	ldp	x9, x8, [x8, #0x98]
100031b64: 3c868182    	stur	q2, [x12, #0x68]
100031b68: 3c878181    	stur	q1, [x12, #0x78]
100031b6c: 3c888180    	stur	q0, [x12, #0x88]
100031b70: a91723e9    	stp	x9, x8, [sp, #0x170]
100031b74: 9102c3e8    	add	x8, sp, #0xb0
100031b78: f90003ff    	str	xzr, [sp]
100031b7c: 940011d2    	bl	0x1000362c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
100031b80: a94b07e0    	ldp	x0, x1, [sp, #0xb0]
100031b84: f94067e8    	ldr	x8, [sp, #0xc8]
100031b88: 394303f9    	ldrb	w25, [sp, #0xc0]
100031b8c: b4ff6d88    	cbz	x8, 0x10003093c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
100031b90: f9400509    	ldr	x9, [x8, #0x8]
100031b94: f9401fef    	ldr	x15, [sp, #0x38]
100031b98: b4ff6d49    	cbz	x9, 0x100030940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
100031b9c: 140000c0    	b	0x100031e9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eb4>
100031ba0: 52800020    	mov	w0, #0x1                ; =1
100031ba4: f9000beb    	str	x11, [sp, #0x10]
100031ba8: 94076c90    	bl	0x10020cde8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031bac: f9400beb    	ldr	x11, [sp, #0x10]
100031bb0: b9400f80    	ldr	w0, [x28, #0xc]
100031bb4: eb00029f    	cmp	x20, x0
100031bb8: 54001949    	b.ls	0x100031ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031bbc: d37cec09    	lsl	x9, x0, #4
100031bc0: 7200011f    	tst	w8, #0x1
100031bc4: aa0b03e0    	mov	x0, x11
100031bc8: aa1903e1    	mov	x1, x25
100031bcc: f8696ae9    	ldr	x9, [x23, x9]
100031bd0: 2a0903ea    	mov	w10, w9
100031bd4: 9a8a1122    	csel	x2, x9, x10, ne
100031bd8: 94005f72    	bl	0x1000499a0 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
100031bdc: 36000081    	tbz	w1, #0x0, 0x100031bec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100031be0: f9401fef    	ldr	x15, [sp, #0x38]
100031be4: aa1f03e1    	mov	x1, xzr
100031be8: 17fffb58    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031bec: f9400b28    	ldr	x8, [x25, #0x10]
100031bf0: f9401fef    	ldr	x15, [sp, #0x38]
100031bf4: b40005e8    	cbz	x8, 0x100031cb0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cc8>
100031bf8: 3940c508    	ldrb	w8, [x8, #0x31]
100031bfc: aa1f03e1    	mov	x1, xzr
100031c00: 7100011f    	cmp	w8, #0x0
100031c04: 12800008    	mov	w8, #-0x1               ; =-1
100031c08: da9f0100    	csinv	x0, x8, xzr, eq
100031c0c: 17fffb4f    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031c10: f94041e1    	ldr	x1, [x15, #0x80]
100031c14: b9400780    	ldr	w0, [x28, #0x4]
100031c18: eb00003f    	cmp	x1, x0
100031c1c: 540015e9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100031c20: f9403de8    	ldr	x8, [x15, #0x78]
100031c24: 52801c09    	mov	w9, #0xe0               ; =224
100031c28: 9ba92008    	umaddl	x8, w0, w9, x8
100031c2c: b40008a8    	cbz	x8, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100031c30: f94017e9    	ldr	x9, [sp, #0x28]
100031c34: b4000869    	cbz	x9, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100031c38: f9403d21    	ldr	x1, [x9, #0x78]
100031c3c: b9401900    	ldr	w0, [x8, #0x18]
100031c40: eb00003f    	cmp	x1, x0
100031c44: 540014a9    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100031c48: f9403929    	ldr	x9, [x9, #0x70]
100031c4c: ab000d29    	adds	x9, x9, x0, lsl #3
100031c50: 54000780    	b.eq	0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100031c54: f9400129    	ldr	x9, [x9]
100031c58: b4000749    	cbz	x9, 0x100031d40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100031c5c: a94006ab    	ldp	x11, x1, [x21]
100031c60: b940150c    	ldr	w12, [x8, #0x14]
100031c64: b9401d08    	ldr	w8, [x8, #0x1c]
100031c68: f9400920    	ldr	x0, [x9, #0x10]
100031c6c: f9400aa2    	ldr	x2, [x21, #0x10]
100031c70: f9400563    	ldr	x3, [x11, #0x8]
100031c74: aa088186    	orr	x6, x12, x8, lsl #32
100031c78: d10283a8    	sub	x8, x29, #0xa0
100031c7c: f90003ea    	str	x10, [sp]
100031c80: 94007002    	bl	0x10004dc88 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
100031c84: a97607a0    	ldp	x0, x1, [x29, #-0xa0]
100031c88: f85783a8    	ldur	x8, [x29, #-0x88]
100031c8c: 385703b9    	ldurb	w25, [x29, #-0x90]
100031c90: b4ff6568    	cbz	x8, 0x10003093c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
100031c94: f9400509    	ldr	x9, [x8, #0x8]
100031c98: f9401fef    	ldr	x15, [sp, #0x38]
100031c9c: b4ff6529    	cbz	x9, 0x100030940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
100031ca0: 14000081    	b	0x100031ea4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ebc>
100031ca4: aa1f03e1    	mov	x1, xzr
100031ca8: 52800400    	mov	w0, #0x20               ; =32
100031cac: 17fffb27    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031cb0: 52800020    	mov	w0, #0x1                ; =1
100031cb4: 94076c4d    	bl	0x10020cde8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031cb8: f9401fef    	ldr	x15, [sp, #0x38]
100031cbc: aa1f03e1    	mov	x1, xzr
100031cc0: 12800000    	mov	w0, #-0x1               ; =-1
100031cc4: 17fffb21    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031cc8: aa0003e1    	mov	x1, x0
100031ccc: 17fffb1f    	b	0x100030948 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031cd0: f9401be8    	ldr	x8, [sp, #0x30]
100031cd4: aa1503e0    	mov	x0, x21
100031cd8: b81c8118    	stur	w24, [x8, #-0x38]
100031cdc: 94000842    	bl	0x100033de4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
100031ce0: 72001c1f    	tst	w0, #0xff
100031ce4: 540005a1    	b.ne	0x100031d98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
100031ce8: f94026a8    	ldr	x8, [x21, #0x48]
100031cec: f100011f    	cmp	x8, #0x0
100031cf0: 54ff19cc    	b.gt	0x100030028 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x40>
100031cf4: 140000b0    	b	0x100031fb4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
100031cf8: f9401be8    	ldr	x8, [sp, #0x30]
100031cfc: aa1503e0    	mov	x0, x21
100031d00: b81c8118    	stur	w24, [x8, #-0x38]
100031d04: 9400044b    	bl	0x100032e30 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
100031d08: 17fffff6    	b	0x100031ce0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
100031d0c: f9401be8    	ldr	x8, [sp, #0x30]
100031d10: aa1503e0    	mov	x0, x21
100031d14: b81c8118    	stur	w24, [x8, #-0x38]
100031d18: 94000736    	bl	0x1000339f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
100031d1c: 17fffff1    	b	0x100031ce0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
100031d20: f9401be8    	ldr	x8, [sp, #0x30]
100031d24: aa1503e0    	mov	x0, x21
100031d28: b81c8118    	stur	w24, [x8, #-0x38]
100031d2c: 94000348    	bl	0x100032a4c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
100031d30: 72001c1f    	tst	w0, #0xff
100031d34: 54fffda0    	b.eq	0x100031ce8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d00>
100031d38: 52800020    	mov	w0, #0x1                ; =1
100031d3c: 1400004f    	b	0x100031e78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
100031d40: 52800020    	mov	w0, #0x1                ; =1
100031d44: 94076c29    	bl	0x10020cde8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031d48: aa1f03e0    	mov	x0, xzr
100031d4c: 1400004b    	b	0x100031e78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
100031d50: 52800500    	mov	w0, #0x28               ; =40
100031d54: 9407be51    	bl	0x100221698 <dyld_stub_binder+0x100221698>
100031d58: b4001460    	cbz	x0, 0x100031fe4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
100031d5c: aa0003f4    	mov	x20, x0
100031d60: 52800500    	mov	w0, #0x28               ; =40
100031d64: 94075ad4    	bl	0x1002088b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100031d68: f9400728    	ldr	x8, [x25, #0x8]
100031d6c: f0001c49    	adrp	x9, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
100031d70: b000132a    	adrp	x10, 0x100296000 <dyld_stub_binder+0x100296000>
100031d74: 9122ad4a    	add	x10, x10, #0x8ab
100031d78: 3dc38520    	ldr	q0, [x9, #0xe10]
100031d7c: b00015e1    	adrp	x1, 0x1002ee000 <__llgo_struct$IjaMTlBusI6Vzz2BLhvn1zSVeFyKXdIPkn8c9So1YdM+0x38>
100031d80: 91314021    	add	x1, x1, #0xc50
100031d84: a9012a88    	stp	x8, x10, [x20, #0x10]
100031d88: 528001c8    	mov	w8, #0xe                ; =14
100031d8c: 3d800280    	str	q0, [x20]
100031d90: f9001288    	str	x8, [x20, #0x20]
100031d94: 14000035    	b	0x100031e68 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
100031d98: 92401c00    	and	x0, x0, #0xff
100031d9c: 14000037    	b	0x100031e78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
100031da0: f94057f4    	ldr	x20, [sp, #0xa8]
100031da4: 52800100    	mov	w0, #0x8                ; =8
100031da8: 94076b84    	bl	0x10020cbb8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
100031dac: aa0003f6    	mov	x22, x0
100031db0: 90001502    	adrp	x2, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
100031db4: 9127a042    	add	x2, x2, #0x9e8
100031db8: aa1903e0    	mov	x0, x25
100031dbc: aa1403e1    	mov	x1, x20
100031dc0: aa1603e3    	mov	x3, x22
100031dc4: 9406d7ac    	bl	0x1001e7c74 <_errors.As>
100031dc8: 360000a0    	tbz	w0, #0x0, 0x100031ddc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1df4>
100031dcc: f9400fe9    	ldr	x9, [sp, #0x18]
100031dd0: f94002c8    	ldr	x8, [x22]
100031dd4: b9405129    	ldr	w9, [x9, #0x50]
100031dd8: b9000509    	str	w9, [x8, #0x4]
100031ddc: aa1503e0    	mov	x0, x21
100031de0: aa1903e1    	mov	x1, x25
100031de4: 14000022    	b	0x100031e6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e84>
100031de8: 52800079    	mov	w25, #0x3               ; =3
100031dec: 14000008    	b	0x100031e0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
100031df0: aa0103e2    	mov	x2, x1
100031df4: aa0003e1    	mov	x1, x0
100031df8: aa1503e0    	mov	x0, x21
100031dfc: 1400001d    	b	0x100031e70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
100031e00: 52800039    	mov	w25, #0x1               ; =1
100031e04: 14000002    	b	0x100031e0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
100031e08: 52800139    	mov	w25, #0x9               ; =9
100031e0c: 52800200    	mov	w0, #0x10               ; =16
100031e10: 9407be1f    	bl	0x10022168c <dyld_stub_binder+0x10022168c>
100031e14: b4000e80    	cbz	x0, 0x100031fe4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
100031e18: aa0003f4    	mov	x20, x0
100031e1c: 52800200    	mov	w0, #0x10               ; =16
100031e20: 94075aa5    	bl	0x1002088b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100031e24: f9401fe9    	ldr	x9, [sp, #0x38]
100031e28: a9007e9f    	stp	xzr, xzr, [x20]
100031e2c: b9400780    	ldr	w0, [x28, #0x4]
100031e30: f9404121    	ldr	x1, [x9, #0x80]
100031e34: eb00003f    	cmp	x1, x0
100031e38: 54000509    	b.ls	0x100031ed8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100031e3c: 52801c08    	mov	w8, #0xe0               ; =224
100031e40: f9403d29    	ldr	x9, [x9, #0x78]
100031e44: 90001501    	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
100031e48: 91354021    	add	x1, x1, #0xd50
100031e4c: 9ba82408    	umaddl	x8, w0, w8, x9
100031e50: f9400fe9    	ldr	x9, [sp, #0x18]
100031e54: b9405129    	ldr	w9, [x9, #0x50]
100031e58: f9400508    	ldr	x8, [x8, #0x8]
100031e5c: 39000299    	strb	w25, [x20]
100031e60: b9000689    	str	w9, [x20, #0x4]
100031e64: f9000688    	str	x8, [x20, #0x8]
100031e68: aa1503e0    	mov	x0, x21
100031e6c: aa1403e2    	mov	x2, x20
100031e70: 97fff4d8    	bl	0x10002f1d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
100031e74: 52800060    	mov	w0, #0x3                ; =3
100031e78: aa1303e1    	mov	x1, x19
100031e7c: 910743ff    	add	sp, sp, #0x1d0
100031e80: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100031e84: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100031e88: a94357f6    	ldp	x22, x21, [sp, #0x30]
100031e8c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100031e90: a94167fa    	ldp	x26, x25, [sp, #0x10]
100031e94: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100031e98: d65f03c0    	ret
100031e9c: f9406be2    	ldr	x2, [sp, #0xd0]
100031ea0: 14000002    	b	0x100031ea8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ec0>
100031ea4: f85803a2    	ldur	x2, [x29, #-0x80]
100031ea8: aa1503e0    	mov	x0, x21
100031eac: aa0803e1    	mov	x1, x8
100031eb0: 17fffff0    	b	0x100031e70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
100031eb4: aa1803e0    	mov	x0, x24
100031eb8: aa1603e1    	mov	x1, x22
100031ebc: 94076029    	bl	0x100209f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031ec0: aa1403e1    	mov	x1, x20
100031ec4: 94075aba    	bl	0x1002089ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031ec8: aa0803e0    	mov	x0, x8
100031ecc: aa1403e1    	mov	x1, x20
100031ed0: 94075ab7    	bl	0x1002089ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031ed4: aa1603e1    	mov	x1, x22
100031ed8: 94076022    	bl	0x100209f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031edc: aa0803e0    	mov	x0, x8
100031ee0: aa1403e1    	mov	x1, x20
100031ee4: 9407601f    	bl	0x100209f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031ee8: aa0803e0    	mov	x0, x8
100031eec: 9407601d    	bl	0x100209f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031ef0: aa0a03e0    	mov	x0, x10
100031ef4: aa1403e1    	mov	x1, x20
100031ef8: 9407601a    	bl	0x100209f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031efc: aa0803e0    	mov	x0, x8
100031f00: 52800021    	mov	w1, #0x1                ; =1
100031f04: aa0903e2    	mov	x2, x9
100031f08: 52800063    	mov	w3, #0x3                ; =3
100031f0c: 94075dee    	bl	0x1002096c4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031f10: aa0903e0    	mov	x0, x9
100031f14: 52800021    	mov	w1, #0x1                ; =1
100031f18: 52800043    	mov	w3, #0x2                ; =2
100031f1c: 94075dea    	bl	0x1002096c4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031f20: aa0903e0    	mov	x0, x9
100031f24: aa1403e1    	mov	x1, x20
100031f28: 9407600e    	bl	0x100209f60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031f2c: 52800020    	mov	w0, #0x1                ; =1
100031f30: 94075a9f    	bl	0x1002089ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031f34: aa1f03e0    	mov	x0, xzr
100031f38: aa1f03e1    	mov	x1, xzr
100031f3c: 94075a9c    	bl	0x1002089ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031f40: aa0803e0    	mov	x0, x8
100031f44: 2a1f03e1    	mov	w1, wzr
100031f48: 52800063    	mov	w3, #0x3                ; =3
100031f4c: 94075dde    	bl	0x1002096c4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031f50: aa0203e0    	mov	x0, x2
100031f54: 2a1f03e1    	mov	w1, wzr
100031f58: aa0a03e2    	mov	x2, x10
100031f5c: 52800043    	mov	w3, #0x2                ; =2
100031f60: 94075dd9    	bl	0x1002096c4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031f64: aa1903e0    	mov	x0, x25
100031f68: 2a1f03e1    	mov	w1, wzr
100031f6c: 52800063    	mov	w3, #0x3                ; =3
100031f70: 94075dd5    	bl	0x1002096c4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031f74: aa0203e0    	mov	x0, x2
100031f78: 2a1f03e1    	mov	w1, wzr
100031f7c: aa0803e2    	mov	x2, x8
100031f80: 52800043    	mov	w3, #0x2                ; =2
100031f84: 94075dd0    	bl	0x1002096c4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031f88: 52800060    	mov	w0, #0x3                ; =3
100031f8c: 94075a88    	bl	0x1002089ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031f90: 52800040    	mov	w0, #0x2                ; =2
100031f94: 52800041    	mov	w1, #0x2                ; =2
100031f98: 94075a85    	bl	0x1002089ac <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031f9c: b00018a0    	adrp	x0, 0x100346000 <_*_llgo_internal/chacha8rand.errUnmarshalChaCha8+0x78>
100031fa0: 910c6000    	add	x0, x0, #0x318
100031fa4: b00018a1    	adrp	x1, 0x100346000 <_*_llgo_internal/chacha8rand.errUnmarshalChaCha8+0x78>
100031fa8: 91166021    	add	x1, x1, #0x598
100031fac: 940759bd    	bl	0x1002086a0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031fb0: d4200020    	brk	#0x1
100031fb4: d00018e0    	adrp	x0, 0x10034f000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.struct$uhsLJBkBw6Xal5IghAh85eRnhTFSw6d7HxVjbyS6Ec0$fields+0x30>
100031fb8: 91314000    	add	x0, x0, #0xc50
100031fbc: 90001501    	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
100031fc0: 9128e021    	add	x1, x1, #0xa38
100031fc4: 940759b7    	bl	0x1002086a0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031fc8: d4200020    	brk	#0x1
100031fcc: d00018e0    	adrp	x0, 0x10034f000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.struct$uhsLJBkBw6Xal5IghAh85eRnhTFSw6d7HxVjbyS6Ec0$fields+0x30>
100031fd0: 91314000    	add	x0, x0, #0xc50
100031fd4: 90001501    	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
100031fd8: 91292021    	add	x1, x1, #0xa48
100031fdc: 940759b1    	bl	0x1002086a0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031fe0: d4200020    	brk	#0x1
100031fe4: d00018e0    	adrp	x0, 0x10034f000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.struct$uhsLJBkBw6Xal5IghAh85eRnhTFSw6d7HxVjbyS6Ec0$fields+0x30>
100031fe8: 91314000    	add	x0, x0, #0xc50
100031fec: b00018a1    	adrp	x1, 0x100346000 <_*_llgo_internal/chacha8rand.errUnmarshalChaCha8+0x78>
100031ff0: 910c2021    	add	x1, x1, #0x308
100031ff4: 940759ab    	bl	0x1002086a0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031ff8: d4200020    	brk	#0x1
