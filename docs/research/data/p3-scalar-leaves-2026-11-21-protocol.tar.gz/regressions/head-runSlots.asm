
/Users/lijie/source/goplus/wasmvm/artifacts/p3-leaf-boundaries-20261121/full/head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100038f38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlots>:
100038f38: a9be4ff4    	stp	x20, x19, [sp, #-0x20]!
100038f3c: a9017bfd    	stp	x29, x30, [sp, #0x10]
100038f40: 910043fd    	add	x29, sp, #0x10
100038f44: f940ac01    	ldr	x1, [x0, #0x158]
100038f48: aa0003f3    	mov	x19, x0
100038f4c: 97ffdc27    	bl	0x10002ffe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>
100038f50: a9417bfd    	ldp	x29, x30, [sp, #0x10]
100038f54: f900ae61    	str	x1, [x19, #0x158]
100038f58: a8c24ff4    	ldp	x20, x19, [sp], #0x20
100038f5c: d65f03c0    	ret
