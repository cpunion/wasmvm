from collections import Counter
from pathlib import Path
import json
import re

root = Path(__file__).resolve().parent
pattern = r"^([a-f0-9]+): ([a-f0-9]{8}) +\t(\S+)(?:\s+(.*))?$"
summaries = {}
for name in ("runSlotsLoop", "runSlots", "runCall"):
    records = [re.findall(pattern, (root/f"{side}-{name}.asm").read_text(), re.M) for side in ("base","head")]
    summary = {"baseInstructions":len(records[0]),"headInstructions":len(records[1]),
               "baseAddress":records[0][0][0],"headAddress":records[1][0][0]}
    if len(records[0]) == len(records[1]):
        differences = [(a,b)for a,b in zip(*records)if a[1]!=b[1]]
        summary["differentEncodings"] = len(differences)
        summary["differenceByOpcode"] = dict(Counter(a[2] for a,b in differences))
        summary["opcodeSequenceMatches"] = all(a[2]==b[2]for a,b in zip(*records))
        summary["changedEncodings"] = differences
    summaries[name] = summary
(root/"assembly-comparison.json").write_text(json.dumps(summaries,indent=2)+"\n")
for name, stats in summaries.items():
    print(name,{k:v for k,v in stats.items()if k!="changedEncodings"})
