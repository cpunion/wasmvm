import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
original = json.loads((root.parent/"regressions/frozen-plan.json").read_text())
cases = []
ordered = {}
for role in ("base","head"):
    executable = root/(role+"-ordered")
    data = subprocess.check_output(["/opt/homebrew/opt/llvm@22/bin/llvm-nm","-n",str(executable)],text=True)
    hot = data.split(".(*Execution).runSlotsLoop",1)[0].splitlines()[-1].split()[0]
    ordered[role] = dict(binary=str(executable),sha256=hashlib.sha256(executable.read_bytes()).hexdigest(),runSlotsLoop=hot)
(root/"ordered-symbols.json").write_text(json.dumps(ordered,indent=2)+"\n")
hashes = original["binarySHA256"]
for role, value in ordered.items():
    hashes[value["binary"]] = value["sha256"]
ids = {"original22-v1/memory/narrow-unaligned","original22-v1/core/integer-loop","gc-sustained-v1/gc/i31-roundtrip"}
for case in original["cases"]:
    if case["id"] not in ids:
        continue
    commands = case["commands"].copy()
    for role in ("base","head"):
        command = commands[role+"-llgo-interpreter"].copy()
        command[0] = ordered[role]["binary"]
        commands[role+"-llgo-ordered"] = command
    cases.append(dict(case,commands=commands))
assert len(cases)==len(ids)
plan=dict(blocks=6,samples=5,seed=202611216839,cases=cases,binarySHA256=hashes,
          scope="Layout intervention. Same pinned LLGo and source on each arm. Reorder the same six interpreter and memory symbols in both test images. Counter replay independent of primary and prior diagnostic observations.")
(root/"frozen-plan.json").write_text(json.dumps(plan,indent=2)+"\n")
