from pathlib import Path
import json, subprocess

out = Path(__file__).resolve().parent
w = Path("/Users/lijie/source/goplus/wasmvm-source-cleanup")
original = w/"internal/engine/memory/memory.go"
source = original.read_text()
old = "var scalarLoadWidths = [...]uint8{4, 8, 4, 8, 1, 1, 2, 2, 1, 1, 2, 2, 4, 4}"
new = """type scalarLoadShape struct {
	mask uint64
	width, signShift uint8
}

const untrimmed = ^uint64(0)

var scalarLoadShapes = [...]scalarLoadShape{
	{mask: untrimmed, width: 4}, // i32.load
	{mask: untrimmed, width: 8}, // i64.load
	{mask: untrimmed, width: 4}, // f32.load
	{mask: untrimmed, width: 8}, // f64.load
	{mask: 0xffffffff, width: 1, signShift: 56},
	{mask: untrimmed, width: 1},
	{mask: 0xffffffff, width: 2, signShift: 48},
	{mask: untrimmed, width: 2},
	{mask: untrimmed, width: 1, signShift: 56},
	{mask: untrimmed, width: 1},
	{mask: untrimmed, width: 2, signShift: 48},
	{mask: untrimmed, width: 2},
	{mask: untrimmed, width: 4, signShift: 32},
	{mask: untrimmed, width: 4},
}"""
assert source.count(old) == 1
source = source.replace(old,new)
start = source.index("\t\tn := uint(scalarLoadWidths")
end = source.index("\n\t}",start)
source = source[:start]+"""		shape := scalarLoadShapes[op-0x28]
		n := uint(shape.width)
		b, ok := m.access(address, offset, n)
		if !ok {
			return value.Value{}, wasm.TrapMemoryBounds
		}
		x := m.readAccess(b, n)
		shift := shape.signShift
		x = uint64(int64(x<<shift)>>shift) & shape.mask
		return value.Value{Lo: x}, wasm.NoTrap"""+source[end:]
patched = out/"memory.go"
patched.write_text(source)
subprocess.run(["gofmt","-w",str(patched)],check=True)
for compiler in ["go","llgo"]:
    overlay = json.loads((out.parent/("head-"+compiler+"-overlay.json")).read_text())
    overlay["Replace"][str(original)] = str(patched)
    path = out/(compiler+"-overlay.json")
    path.write_text(json.dumps(overlay,indent=2)+"\n")
    binary=out/(compiler+"-phase")
    tool = ["go"] if compiler=="go" else ["/Users/lijie/source/goplus/wasmvm/artifacts/components/llgo-3c6b33ec"]
    flags = [] if compiler=="go" else ["-O3","-lto=full"]
    subprocess.run(tool+["build",*flags,"-overlay",str(path),"-o",str(binary),"."],
                   cwd=w/"benchmarks/embedded/wasmvm",check=True,timeout=240)
    print("built",compiler,flush=True)
