
head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100032e30 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>:
100032e30: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100032e34: a90167fa    	stp	x26, x25, [sp, #0x10]
100032e38: a9025ff8    	stp	x24, x23, [sp, #0x20]
100032e3c: a90357f6    	stp	x22, x21, [sp, #0x30]
100032e40: a9044ff4    	stp	x20, x19, [sp, #0x40]
100032e44: a9057bfd    	stp	x29, x30, [sp, #0x50]
100032e48: 910143fd    	add	x29, sp, #0x50
100032e4c: d108c3ff    	sub	sp, sp, #0x230
100032e50: b4002240    	cbz	x0, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100032e54: f9402408    	ldr	x8, [x0, #0x48]
100032e58: d1000515    	sub	x21, x8, #0x1
100032e5c: b4005628    	cbz	x8, 0x100033920 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaf0>
100032e60: f9402008    	ldr	x8, [x0, #0x40]
100032e64: ab151919    	adds	x25, x8, x21, lsl #6
100032e68: 54002180    	b.eq	0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100032e6c: f940033c    	ldr	x28, [x25]
100032e70: b400215c    	cbz	x28, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100032e74: f9402794    	ldr	x20, [x28, #0x48]
100032e78: b4002114    	cbz	x20, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100032e7c: b9400b29    	ldr	w9, [x25, #0x8]
100032e80: f9405e81    	ldr	x1, [x20, #0xb8]
100032e84: eb09003f    	cmp	x1, x9
100032e88: 54005569    	b.ls	0x100033934 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb04>
100032e8c: f9400f28    	ldr	x8, [x25, #0x18]
100032e90: f9404e8d    	ldr	x13, [x20, #0x98]
100032e94: f9404402    	ldr	x2, [x0, #0x88]
100032e98: f90033e8    	str	x8, [sp, #0x60]
100032e9c: 8b0801a8    	add	x8, x13, x8
100032ea0: eb02011f    	cmp	x8, x2
100032ea4: 540054c8    	b.hi	0x10003393c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb0c>
100032ea8: f94033ea    	ldr	x10, [sp, #0x60]
100032eac: eb08015f    	cmp	x10, x8
100032eb0: 540054e8    	b.hi	0x10003394c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb1c>
100032eb4: f9405a88    	ldr	x8, [x20, #0xb0]
100032eb8: f9001fe9    	str	x9, [sp, #0x38]
100032ebc: f9403c1b    	ldr	x27, [x0, #0x78]
100032ec0: f940238e    	ldr	x14, [x28, #0x40]
100032ec4: 8b09151a    	add	x26, x8, x9, lsl #5
100032ec8: f94033e8    	ldr	x8, [sp, #0x60]
100032ecc: f9400289    	ldr	x9, [x20]
100032ed0: cb08004b    	sub	x11, x2, x8
100032ed4: d37ced0a    	lsl	x10, x8, #4
100032ed8: 29402356    	ldp	w22, w8, [x26]
100032edc: f100017f    	cmp	x11, #0x0
100032ee0: f90023eb    	str	x11, [sp, #0x40]
100032ee4: 9a9fc157    	csel	x23, x10, xzr, gt
100032ee8: b4000109    	cbz	x9, 0x100032f08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xd8>
100032eec: f9400521    	ldr	x1, [x9, #0x8]
100032ef0: eb08003f    	cmp	x1, x8
100032ef4: 540051c9    	b.ls	0x10003392c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xafc>
100032ef8: 52800f0a    	mov	w10, #0x78              ; =120
100032efc: f9400129    	ldr	x9, [x9]
100032f00: 9baa2508    	umaddl	x8, w8, w10, x9
100032f04: 14000008    	b	0x100032f24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xf4>
100032f08: f9404281    	ldr	x1, [x20, #0x80]
100032f0c: eb08003f    	cmp	x1, x8
100032f10: 540050e9    	b.ls	0x10003392c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xafc>
100032f14: 52801c09    	mov	w9, #0xe0               ; =224
100032f18: f9403e8a    	ldr	x10, [x20, #0x78]
100032f1c: 9ba92908    	umaddl	x8, w8, w9, x10
100032f20: b4001568    	cbz	x8, 0x1000331cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x39c>
100032f24: f9400903    	ldr	x3, [x8, #0x10]
100032f28: 29434348    	ldp	w8, w16, [x26, #0x18]
100032f2c: f9406e82    	ldr	x2, [x20, #0xd8]
100032f30: 71005adf    	cmp	w22, #0x16
100032f34: 1a9f27f1    	cset	w17, lo
100032f38: 0b100109    	add	w9, w8, w16
100032f3c: eb09005f    	cmp	x2, x9
100032f40: 54005103    	b.lo	0x100033960 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb30>
100032f44: 6b09011f    	cmp	w8, w9
100032f48: 54005148    	b.hi	0x100033970 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb40>
100032f4c: cb08004f    	sub	x15, x2, x8
100032f50: d37ef50a    	lsl	x10, x8, #2
100032f54: f940668b    	ldr	x11, [x20, #0xc8]
100032f58: f10001ff    	cmp	x15, #0x0
100032f5c: 510052cc    	sub	w12, w22, #0x14
100032f60: 8b170373    	add	x19, x27, x23
100032f64: 9a9fc14a    	csel	x10, x10, xzr, gt
100032f68: 7100099f    	cmp	w12, #0x2
100032f6c: cb080128    	sub	x8, x9, x8
100032f70: 8b0a017b    	add	x27, x11, x10
100032f74: f9002be8    	str	x8, [sp, #0x50]
100032f78: 54000243    	b.lo	0x100032fc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x190>
100032f7c: 710042df    	cmp	w22, #0x10
100032f80: 54000060    	b.eq	0x100032f8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x15c>
100032f84: 71004adf    	cmp	w22, #0x12
100032f88: 54000581    	b.ne	0x100033038 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x208>
100032f8c: b400186e    	cbz	x14, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100032f90: f94025c1    	ldr	x1, [x14, #0x48]
100032f94: 2a0303e8    	mov	w8, w3
100032f98: eb01011f    	cmp	x8, x1
100032f9c: 54004c82    	b.hs	0x10003392c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xafc>
100032fa0: f94021c9    	ldr	x9, [x14, #0x40]
100032fa4: f8687928    	ldr	x8, [x9, x8, lsl #3]
100032fa8: 2a1003e9    	mov	w9, w16
100032fac: f9001be9    	str	x9, [sp, #0x30]
100032fb0: b4000388    	cbz	x8, 0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
100032fb4: f9400009    	ldr	x9, [x0]
100032fb8: 2a1003ea    	mov	w10, w16
100032fbc: 1400000c    	b	0x100032fec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1bc>
100032fc0: f9402be8    	ldr	x8, [sp, #0x50]
100032fc4: 5100060a    	sub	w10, w16, #0x1
100032fc8: eb0a011f    	cmp	x8, x10
100032fcc: 54004e29    	b.ls	0x100033990 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb60>
100032fd0: b86a7b68    	ldr	w8, [x27, x10, lsl #2]
100032fd4: eb0801bf    	cmp	x13, x8
100032fd8: 54004d69    	b.ls	0x100033984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb54>
100032fdc: d37ced08    	lsl	x8, x8, #4
100032fe0: f8686a68    	ldr	x8, [x19, x8]
100032fe4: b4000ec8    	cbz	x8, 0x1000331bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x38c>
100032fe8: f9400009    	ldr	x9, [x0]
100032fec: f9001bea    	str	x10, [sp, #0x30]
100032ff0: b4000669    	cbz	x9, 0x1000330bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x28c>
100032ff4: f9406d2a    	ldr	x10, [x9, #0xd8]
100032ff8: eb0a011f    	cmp	x8, x10
100032ffc: 54000122    	b.hs	0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
100033000: f9406929    	ldr	x9, [x9, #0xd0]
100033004: f868792a    	ldr	x10, [x9, x8, lsl #3]
100033008: b40000ca    	cbz	x10, 0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
10003300c: 52800028    	mov	w8, #0x1                ; =1
100033010: 36000088    	tbz	w8, #0x0, 0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
100033014: f90027e0    	str	x0, [sp, #0x48]
100033018: b9000fff    	str	wzr, [sp, #0xc]
10003301c: 1400003b    	b	0x100033108 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x2d8>
100033020: b0001c48    	adrp	x8, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
100033024: 9134c108    	add	x8, x8, #0xd30
100033028: a9400901    	ldp	x1, x2, [x8]
10003302c: 97fff069    	bl	0x10002f1d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
100033030: 52800074    	mov	w20, #0x3               ; =3
100033034: 1400009b    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
100033038: b400130e    	cbz	x14, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
10003303c: d360fc68    	lsr	x8, x3, #32
100033040: f94031c1    	ldr	x1, [x14, #0x60]
100033044: eb01011f    	cmp	x8, x1
100033048: 54004722    	b.hs	0x10003392c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xafc>
10003304c: f9402dc9    	ldr	x9, [x14, #0x58]
100033050: ab080d28    	adds	x8, x9, x8, lsl #3
100033054: 54001220    	b.eq	0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100033058: f9400109    	ldr	x9, [x8]
10003305c: b40011e9    	cbz	x9, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100033060: f9402be8    	ldr	x8, [sp, #0x50]
100033064: aa1b03ec    	mov	x12, x27
100033068: 5100061b    	sub	w27, w16, #0x1
10003306c: eb1b011f    	cmp	x8, x27
100033070: 540049c9    	b.ls	0x1000339a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb78>
100033074: b87b7988    	ldr	w8, [x12, x27, lsl #2]
100033078: eb0801bf    	cmp	x13, x8
10003307c: 54004849    	b.ls	0x100033984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb54>
100033080: d37ced08    	lsl	x8, x8, #4
100033084: 3940a52a    	ldrb	w10, [x9, #0x29]
100033088: f8686a68    	ldr	x8, [x19, x8]
10003308c: 7100015f    	cmp	w10, #0x0
100033090: f940212a    	ldr	x10, [x9, #0x40]
100033094: 2a0803eb    	mov	w11, w8
100033098: 9a8b1108    	csel	x8, x8, x11, ne
10003309c: eb0a011f    	cmp	x8, x10
1000330a0: 54001122    	b.hs	0x1000332c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x494>
1000330a4: f9401d29    	ldr	x9, [x9, #0x38]
1000330a8: f8687928    	ldr	x8, [x9, x8, lsl #3]
1000330ac: b4001fe8    	cbz	x8, 0x1000334a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x678>
1000330b0: 2a1b03ea    	mov	w10, w27
1000330b4: aa0c03fb    	mov	x27, x12
1000330b8: 17ffffcc    	b	0x100032fe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1b8>
1000330bc: f90027e0    	str	x0, [sp, #0x48]
1000330c0: 52800020    	mov	w0, #0x1                ; =1
1000330c4: aa0d03f7    	mov	x23, x13
1000330c8: f90017f3    	str	x19, [sp, #0x28]
1000330cc: aa0f03f8    	mov	x24, x15
1000330d0: aa0303f3    	mov	x19, x3
1000330d4: a9016ff5    	stp	x21, x27, [sp, #0x10]
1000330d8: aa0e03fb    	mov	x27, x14
1000330dc: 2a1103f5    	mov	w21, w17
1000330e0: b90023f0    	str	w16, [sp, #0x20]
1000330e4: 9407672b    	bl	0x10020cd90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000330e8: 2a1503f1    	mov	w17, w21
1000330ec: aa1b03ee    	mov	x14, x27
1000330f0: aa1303e3    	mov	x3, x19
1000330f4: a9416ff5    	ldp	x21, x27, [sp, #0x10]
1000330f8: b94023f0    	ldr	w16, [sp, #0x20]
1000330fc: f94017f3    	ldr	x19, [sp, #0x28]
100033100: aa1803ef    	mov	x15, x24
100033104: aa1703ed    	mov	x13, x23
100033108: 710056df    	cmp	w22, #0x15
10003310c: 54000428    	b.hi	0x100033190 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x360>
100033110: 52a00748    	mov	w8, #0x3a0000           ; =3801088
100033114: 1ad62508    	lsr	w8, w8, w22
100033118: 360003c8    	tbz	w8, #0x0, 0x100033190 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x360>
10003311c: b4000bee    	cbz	x14, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100033120: f94019c1    	ldr	x1, [x14, #0x30]
100033124: 2a0303e0    	mov	w0, w3
100033128: b90013f1    	str	w17, [sp, #0x10]
10003312c: b90023f0    	str	w16, [sp, #0x20]
100033130: eb01001f    	cmp	x0, x1
100033134: f9000fef    	str	x15, [sp, #0x18]
100033138: f90017f3    	str	x19, [sp, #0x28]
10003313c: 540043a2    	b.hs	0x1000339b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb80>
100033140: f94027e8    	ldr	x8, [sp, #0x48]
100033144: f94015c9    	ldr	x9, [x14, #0x28]
100033148: aa1b03f3    	mov	x19, x27
10003314c: b9403941    	ldr	w1, [x10, #0x38]
100033150: aa0d03f7    	mov	x23, x13
100033154: aa0e03fb    	mov	x27, x14
100033158: f9400108    	ldr	x8, [x8]
10003315c: b8607922    	ldr	w2, [x9, x0, lsl #2]
100033160: aa0a03f8    	mov	x24, x10
100033164: aa0803e0    	mov	x0, x8
100033168: 94003f05    	bl	0x100042d7c <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).FunctionSubtype>
10003316c: aa1b03ee    	mov	x14, x27
100033170: aa1303fb    	mov	x27, x19
100033174: f94017f3    	ldr	x19, [sp, #0x28]
100033178: f9400fef    	ldr	x15, [sp, #0x18]
10003317c: b94023f0    	ldr	w16, [sp, #0x20]
100033180: b94013f1    	ldr	w17, [sp, #0x10]
100033184: aa1803ea    	mov	x10, x24
100033188: aa1703ed    	mov	x13, x23
10003318c: 36000340    	tbz	w0, #0x0, 0x1000331f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3c4>
100033190: 52a00588    	mov	w8, #0x2c0000           ; =2883584
100033194: 1ad62508    	lsr	w8, w8, w22
100033198: 0a080237    	and	w23, w17, w8
10003319c: 340003b7    	cbz	w23, 0x100033210 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3e0>
1000331a0: a942a33a    	ldp	x26, x8, [x25, #0x28]
1000331a4: 2a1003fc    	mov	w28, w16
1000331a8: aa0a03f8    	mov	x24, x10
1000331ac: aa0d03f6    	mov	x22, x13
1000331b0: 91008334    	add	x20, x25, #0x20
1000331b4: a901bbef    	stp	x15, x14, [sp, #0x18]
1000331b8: 1400002a    	b	0x100033260 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x430>
1000331bc: b9400742    	ldr	w2, [x26, #0x4]
1000331c0: aa1c03e1    	mov	x1, x28
1000331c4: 52800123    	mov	w3, #0x9                ; =9
1000331c8: 1400000f    	b	0x100033204 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3d4>
1000331cc: f90027e0    	str	x0, [sp, #0x48]
1000331d0: 52800020    	mov	w0, #0x1                ; =1
1000331d4: aa0d03f3    	mov	x19, x13
1000331d8: aa0e03f8    	mov	x24, x14
1000331dc: 940766ed    	bl	0x10020cd90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000331e0: f94027e0    	ldr	x0, [sp, #0x48]
1000331e4: aa1803ee    	mov	x14, x24
1000331e8: aa1303ed    	mov	x13, x19
1000331ec: aa1f03e3    	mov	x3, xzr
1000331f0: 17ffff4e    	b	0x100032f28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xf8>
1000331f4: b9400742    	ldr	w2, [x26, #0x4]
1000331f8: f94027e0    	ldr	x0, [sp, #0x48]
1000331fc: aa1c03e1    	mov	x1, x28
100033200: 528000a3    	mov	w3, #0x5                ; =5
100033204: 9400066a    	bl	0x100034bac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
100033208: 52800074    	mov	w20, #0x3               ; =3
10003320c: 14000025    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
100033210: b9400fe8    	ldr	w8, [sp, #0xc]
100033214: 37000428    	tbnz	w8, #0x0, 0x100033298 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x468>
100033218: 29432748    	ldp	w8, w9, [x26, #0x18]
10003321c: aa0a03f8    	mov	x24, x10
100033220: b940294a    	ldr	w10, [x10, #0x28]
100033224: f9406681    	ldr	x1, [x20, #0xc8]
100033228: f9406e83    	ldr	x3, [x20, #0xd8]
10003322c: 2a1f03e6    	mov	w6, wzr
100033230: 2a1f03e7    	mov	w7, wzr
100033234: 0b080124    	add	w4, w9, w8
100033238: 910403e0    	add	x0, sp, #0x100
10003323c: 52800082    	mov	w2, #0x4                ; =4
100033240: 0b0a0085    	add	w5, w4, w10
100033244: 2a1003fc    	mov	w28, w16
100033248: a901bbef    	stp	x15, x14, [sp, #0x18]
10003324c: aa0d03f6    	mov	x22, x13
100033250: 390003ff    	strb	wzr, [sp]
100033254: 910403f4    	add	x20, sp, #0x100
100033258: 94079f2e    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10003325c: a950a3fa    	ldp	x26, x8, [sp, #0x108]
100033260: f90017e8    	str	x8, [sp, #0x28]
100033264: f94027e0    	ldr	x0, [sp, #0x48]
100033268: f9400294    	ldr	x20, [x20]
10003326c: 94000626    	bl	0x100034b04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
100033270: b4000100    	cbz	x0, 0x100033290 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x460>
100033274: f9400409    	ldr	x9, [x0, #0x8]
100033278: aa0003e8    	mov	x8, x0
10003327c: b40000a9    	cbz	x9, 0x100033290 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x460>
100033280: f94027e0    	ldr	x0, [sp, #0x48]
100033284: aa0103e2    	mov	x2, x1
100033288: aa0803e1    	mov	x1, x8
10003328c: 17ffff68    	b	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1fc>
100033290: b9400fe8    	ldr	w8, [sp, #0xc]
100033294: 36000248    	tbz	w8, #0x0, 0x1000332dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x4ac>
100033298: 52800020    	mov	w0, #0x1                ; =1
10003329c: 940766bd    	bl	0x10020cd90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000332a0: 2a1403e0    	mov	w0, w20
1000332a4: 9108c3ff    	add	sp, sp, #0x230
1000332a8: a9457bfd    	ldp	x29, x30, [sp, #0x50]
1000332ac: a9444ff4    	ldp	x20, x19, [sp, #0x40]
1000332b0: a94357f6    	ldp	x22, x21, [sp, #0x30]
1000332b4: a9425ff8    	ldp	x24, x23, [sp, #0x20]
1000332b8: a94167fa    	ldp	x26, x25, [sp, #0x10]
1000332bc: a8c66ffc    	ldp	x28, x27, [sp], #0x60
1000332c0: d65f03c0    	ret
1000332c4: b9400742    	ldr	w2, [x26, #0x4]
1000332c8: aa1c03e1    	mov	x1, x28
1000332cc: 52800063    	mov	w3, #0x3                ; =3
1000332d0: 52800074    	mov	w20, #0x3               ; =3
1000332d4: 94000636    	bl	0x100034bac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
1000332d8: 17fffff2    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
1000332dc: f9000bfa    	str	x26, [sp, #0x10]
1000332e0: a945eb08    	ldp	x8, x26, [x24, #0x58]
1000332e4: d00014e9    	adrp	x9, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
1000332e8: 91086129    	add	x9, x9, #0x218
1000332ec: aa1803ec    	mov	x12, x24
1000332f0: 910463f8    	add	x24, sp, #0x118
1000332f4: eb09011f    	cmp	x8, x9
1000332f8: 1a9f06e9    	csinc	w9, w23, wzr, eq
1000332fc: 36000789    	tbz	w9, #0x0, 0x1000333ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5bc>
100033300: d00014e9    	adrp	x9, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
100033304: 91164129    	add	x9, x9, #0x590
100033308: f9401bea    	ldr	x10, [sp, #0x30]
10003330c: eb09011f    	cmp	x8, x9
100033310: 54000d40    	b.eq	0x1000334b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x688>
100033314: f94027e9    	ldr	x9, [sp, #0x48]
100033318: aa1603e1    	mov	x1, x22
10003331c: 37000d57    	tbnz	w23, #0x0, 0x1000334c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x694>
100033320: f9401feb    	ldr	x11, [sp, #0x38]
100033324: f9415d2a    	ldr	x10, [x9, #0x2b8]
100033328: 11000568    	add	w8, w11, #0x1
10003332c: f9001f2a    	str	x10, [x25, #0x38]
100033330: 29012f28    	stp	w8, w11, [x25, #0x8]
100033334: 52800028    	mov	w8, #0x1                ; =1
100033338: 39004328    	strb	w8, [x25, #0x10]
10003333c: f9402588    	ldr	x8, [x12, #0x48]
100033340: b4002688    	cbz	x8, 0x100033810 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9e0>
100033344: f9400be8    	ldr	x8, [sp, #0x10]
100033348: 9103a3e2    	add	x2, sp, #0xe8
10003334c: aa0903e0    	mov	x0, x9
100033350: aa0c03e1    	mov	x1, x12
100033354: a90ea3f4    	stp	x20, x8, [sp, #0xe8]
100033358: f94017e8    	ldr	x8, [sp, #0x28]
10003335c: aa0903f4    	mov	x20, x9
100033360: f9007fe8    	str	x8, [sp, #0xf8]
100033364: 94001352    	bl	0x1000380ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push>
100033368: b4000080    	cbz	x0, 0x100033378 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x548>
10003336c: f9400409    	ldr	x9, [x0, #0x8]
100033370: aa0003e8    	mov	x8, x0
100033374: b5001ce9    	cbnz	x9, 0x100033710 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x8e0>
100033378: f9402688    	ldr	x8, [x20, #0x48]
10003337c: d1000500    	sub	x0, x8, #0x1
100033380: b4003348    	cbz	x8, 0x1000339e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbb8>
100033384: f9401bea    	ldr	x10, [sp, #0x30]
100033388: 34002c8a    	cbz	w10, 0x100033918 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae8>
10003338c: f9402288    	ldr	x8, [x20, #0x40]
100033390: f9402beb    	ldr	x11, [sp, #0x50]
100033394: aa1403e9    	mov	x9, x20
100033398: 2a0a03ea    	mov	w10, w10
10003339c: 8b001908    	add	x8, x8, x0, lsl #6
1000333a0: f9400d00    	ldr	x0, [x8, #0x18]
1000333a4: b400308b    	cbz	x11, 0x1000339b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb84>
1000333a8: b8404768    	ldr	w8, [x27], #0x4
1000333ac: f94033ec    	ldr	x12, [sp, #0x60]
1000333b0: f9404121    	ldr	x1, [x9, #0x80]
1000333b4: 8b080188    	add	x8, x12, x8
1000333b8: eb01011f    	cmp	x8, x1
1000333bc: 54003022    	b.hs	0x1000339c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb90>
1000333c0: eb01001f    	cmp	x0, x1
1000333c4: 54003102    	b.hs	0x1000339e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbb4>
1000333c8: f9403d2c    	ldr	x12, [x9, #0x78]
1000333cc: 2a1f03f4    	mov	w20, wzr
1000333d0: d100054a    	sub	x10, x10, #0x1
1000333d4: d100056b    	sub	x11, x11, #0x1
1000333d8: 3ce87980    	ldr	q0, [x12, x8, lsl #4]
1000333dc: 3ca07980    	str	q0, [x12, x0, lsl #4]
1000333e0: 91000400    	add	x0, x0, #0x1
1000333e4: b5fffe0a    	cbnz	x10, 0x1000333a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x574>
1000333e8: 17ffffae    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
1000333ec: f9401be8    	ldr	x8, [sp, #0x30]
1000333f0: 3cc08181    	ldur	q1, [x12, #0x8]
1000333f4: aa1303f5    	mov	x21, x19
1000333f8: 3cc18180    	ldur	q0, [x12, #0x18]
1000333fc: aa1403f7    	mov	x23, x20
100033400: f9400fe3    	ldr	x3, [sp, #0x18]
100033404: a942d193    	ldp	x19, x20, [x12, #0x28]
100033408: 2a0803e5    	mov	w5, w8
10003340c: 910463e0    	add	x0, sp, #0x118
100033410: aa1b03e1    	mov	x1, x27
100033414: 52800082    	mov	w2, #0x4                ; =4
100033418: aa1f03e4    	mov	x4, xzr
10003341c: 52800026    	mov	w6, #0x1                ; =1
100033420: 2a1f03e7    	mov	w7, wzr
100033424: ad0287e0    	stp	q0, q1, [sp, #0x50]
100033428: 390003ff    	strb	wzr, [sp]
10003342c: 94079eb9    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100033430: f9400be8    	ldr	x8, [sp, #0x10]
100033434: ad4287e0    	ldp	q0, q1, [sp, #0x50]
100033438: f9408fe9    	ldr	x9, [sp, #0x118]
10003343c: 9105e3e1    	add	x1, sp, #0x178
100033440: 910583e2    	add	x2, sp, #0x160
100033444: a914a3f7    	stp	x23, x8, [sp, #0x148]
100033448: f94017e8    	ldr	x8, [sp, #0x28]
10003344c: 910523e3    	add	x3, sp, #0x148
100033450: ad030301    	stp	q1, q0, [x24, #0x60]
100033454: 3cc08300    	ldur	q0, [x24, #0x8]
100033458: 9104c3e4    	add	x4, sp, #0x130
10003345c: a915a7e8    	stp	x8, x9, [sp, #0x158]
100033460: f94023e8    	ldr	x8, [sp, #0x40]
100033464: aa1a03e0    	mov	x0, x26
100033468: a919d3f3    	stp	x19, x20, [sp, #0x198]
10003346c: 3c850300    	stur	q0, [x24, #0x50]
100033470: a9135bf5    	stp	x21, x22, [sp, #0x130]
100033474: f900a3e8    	str	x8, [sp, #0x140]
100033478: 9400481e    	bl	0x1000454f0 <_github.com/cpunion/wasmvm/internal/engine/state.(*ScalarLeaf).CallSlots>
10003347c: b4000080    	cbz	x0, 0x10003348c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x65c>
100033480: f9400409    	ldr	x9, [x0, #0x8]
100033484: aa0003e8    	mov	x8, x0
100033488: b5ffefc9    	cbnz	x9, 0x100033280 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x450>
10003348c: f94027e0    	ldr	x0, [sp, #0x48]
100033490: 9400059d    	bl	0x100034b04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
100033494: b4002380    	cbz	x0, 0x100033904 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad4>
100033498: f9400409    	ldr	x9, [x0, #0x8]
10003349c: aa0003e8    	mov	x8, x0
1000334a0: b5ffef09    	cbnz	x9, 0x100033280 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x450>
1000334a4: 14000118    	b	0x100033904 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad4>
1000334a8: b9400742    	ldr	w2, [x26, #0x4]
1000334ac: aa1c03e1    	mov	x1, x28
1000334b0: 52800083    	mov	w3, #0x4                ; =4
1000334b4: 17ffff54    	b	0x100033204 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3d4>
1000334b8: f94027e9    	ldr	x9, [sp, #0x48]
1000334bc: aa1603e1    	mov	x1, x22
1000334c0: 36000517    	tbz	w23, #0x0, 0x100033560 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x730>
1000334c4: f9402588    	ldr	x8, [x12, #0x48]
1000334c8: b40002c8    	cbz	x8, 0x100033520 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x6f0>
1000334cc: f9404d08    	ldr	x8, [x8, #0x98]
1000334d0: f94033eb    	ldr	x11, [sp, #0x60]
1000334d4: b9401d2a    	ldr	w10, [x9, #0x1c]
1000334d8: 8b0b0108    	add	x8, x8, x11
1000334dc: eb0a011f    	cmp	x8, x10
1000334e0: f9401bea    	ldr	x10, [sp, #0x30]
1000334e4: 540001e9    	b.ls	0x100033520 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x6f0>
1000334e8: 52800500    	mov	w0, #0x28               ; =40
1000334ec: aa0903f3    	mov	x19, x9
1000334f0: 9407659c    	bl	0x10020cb60 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
1000334f4: b0001c48    	adrp	x8, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
1000334f8: 52800229    	mov	w9, #0x11               ; =17
1000334fc: aa0003e2    	mov	x2, x0
100033500: 3dc38500    	ldr	q0, [x8, #0xe10]
100033504: f0001308    	adrp	x8, 0x100296000 <dyld_stub_binder+0x100296000>
100033508: 911e3908    	add	x8, x8, #0x78e
10003350c: a901a408    	stp	x8, x9, [x0, #0x18]
100033510: f00015c1    	adrp	x1, 0x1002ee000 <__llgo_struct$IjaMTlBusI6Vzz2BLhvn1zSVeFyKXdIPkn8c9So1YdM+0x38>
100033514: 91314021    	add	x1, x1, #0xc50
100033518: 3d800000    	str	q0, [x0]
10003351c: 140000ee    	b	0x1000338d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaa4>
100033520: f9405d23    	ldr	x3, [x9, #0xb8]
100033524: 2a0a03f7    	mov	w23, w10
100033528: aa1403f9    	mov	x25, x20
10003352c: aa0103f6    	mov	x22, x1
100033530: f9002bec    	str	x12, [sp, #0x50]
100033534: eb17007f    	cmp	x3, x23
100033538: 540002ea    	b.ge	0x100033594 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x764>
10003353c: 910223e0    	add	x0, sp, #0x88
100033540: aa1703e1    	mov	x1, x23
100033544: aa1703e2    	mov	x2, x23
100033548: 52800203    	mov	w3, #0x10               ; =16
10003354c: 2a1f03e4    	mov	w4, wzr
100033550: aa0903f4    	mov	x20, x9
100033554: 910223f8    	add	x24, sp, #0x88
100033558: 94079962    	bl	0x100219ae0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MakeSlice>
10003355c: 14000019    	b	0x1000335c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x790>
100033560: 39406348    	ldrb	w8, [x26, #0x18]
100033564: 360019e8    	tbz	w8, #0x0, 0x1000338a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa70>
100033568: 340023bc    	cbz	w28, 0x1000339dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbac>
10003356c: b9400360    	ldr	w0, [x27]
100033570: eb00003f    	cmp	x1, x0
100033574: 54002389    	b.ls	0x1000339e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbb4>
100033578: d37cec08    	lsl	x8, x0, #4
10003357c: aa1303f5    	mov	x21, x19
100033580: aa1403f6    	mov	x22, x20
100033584: aa0103f4    	mov	x20, x1
100033588: aa0903f3    	mov	x19, x9
10003358c: f8686aa1    	ldr	x1, [x21, x8]
100033590: 140000c9    	b	0x1000338b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa84>
100033594: f9405521    	ldr	x1, [x9, #0xa8]
100033598: aa1f03e4    	mov	x4, xzr
10003359c: 2a1f03e7    	mov	w7, wzr
1000335a0: d10363a0    	sub	x0, x29, #0xd8
1000335a4: 52800202    	mov	w2, #0x10               ; =16
1000335a8: aa1703e5    	mov	x5, x23
1000335ac: 52800026    	mov	w6, #0x1                ; =1
1000335b0: aa0903f4    	mov	x20, x9
1000335b4: 390003ff    	strb	wzr, [sp]
1000335b8: d10363b8    	sub	x24, x29, #0xd8
1000335bc: 94079e55    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000335c0: f9400308    	ldr	x8, [x24]
1000335c4: 3cc08300    	ldur	q0, [x24, #0x8]
1000335c8: 910283e0    	add	x0, sp, #0xa0
1000335cc: f9400fe3    	ldr	x3, [sp, #0x18]
1000335d0: aa1b03e1    	mov	x1, x27
1000335d4: 52800082    	mov	w2, #0x4                ; =4
1000335d8: aa1f03e4    	mov	x4, xzr
1000335dc: aa1703e5    	mov	x5, x23
1000335e0: 52800026    	mov	w6, #0x1                ; =1
1000335e4: 2a1f03e7    	mov	w7, wzr
1000335e8: f9005688    	str	x8, [x20, #0xa8]
1000335ec: 3d802e80    	str	q0, [x20, #0xb0]
1000335f0: 390003ff    	strb	wzr, [sp]
1000335f4: 94079e47    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000335f8: f94057e9    	ldr	x9, [sp, #0xa8]
1000335fc: f9400bfa    	ldr	x26, [sp, #0x10]
100033600: aa1603ec    	mov	x12, x22
100033604: aa1903f6    	mov	x22, x25
100033608: 910463f7    	add	x23, sp, #0x118
10003360c: f100053f    	cmp	x9, #0x1
100033610: 540001eb    	b.lt	0x10003364c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x81c>
100033614: f94053ea    	ldr	x10, [sp, #0xa0]
100033618: aa1f03e0    	mov	x0, xzr
10003361c: b8607948    	ldr	w8, [x10, x0, lsl #2]
100033620: eb08019f    	cmp	x12, x8
100033624: 54001bc9    	b.ls	0x10003399c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb6c>
100033628: f9405a81    	ldr	x1, [x20, #0xb0]
10003362c: eb01001f    	cmp	x0, x1
100033630: 54001da2    	b.hs	0x1000339e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbb4>
100033634: f940568b    	ldr	x11, [x20, #0xa8]
100033638: 3ce87a60    	ldr	q0, [x19, x8, lsl #4]
10003363c: 3ca07960    	str	q0, [x11, x0, lsl #4]
100033640: 91000400    	add	x0, x0, #0x1
100033644: eb00013f    	cmp	x9, x0
100033648: 54fffea1    	b.ne	0x10003361c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x7ec>
10003364c: f9403e81    	ldr	x1, [x20, #0x78]
100033650: f9404683    	ldr	x3, [x20, #0x88]
100033654: d10303a0    	sub	x0, x29, #0xc0
100033658: f94033e5    	ldr	x5, [sp, #0x60]
10003365c: 52800202    	mov	w2, #0x10               ; =16
100033660: aa1f03e4    	mov	x4, xzr
100033664: 52800026    	mov	w6, #0x1                ; =1
100033668: 52800027    	mov	w7, #0x1                ; =1
10003366c: 390003ff    	strb	wzr, [sp]
100033670: 94079e28    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100033674: f9402681    	ldr	x1, [x20, #0x48]
100033678: f85403a9    	ldur	x9, [x29, #-0xc0]
10003367c: 3ccb02e0    	ldur	q0, [x23, #0xb0]
100033680: eb0102bf    	cmp	x21, x1
100033684: f9003e89    	str	x9, [x20, #0x78]
100033688: 3d802280    	str	q0, [x20, #0x80]
10003368c: 54001a42    	b.hs	0x1000339d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xba4>
100033690: f9402289    	ldr	x9, [x20, #0x40]
100033694: 6f00e400    	movi.2d	v0, #0000000000000000
100033698: d102a3a0    	sub	x0, x29, #0xa8
10003369c: 52800802    	mov	w2, #0x40               ; =64
1000336a0: aa1f03e4    	mov	x4, xzr
1000336a4: aa1503e5    	mov	x5, x21
1000336a8: 8b151929    	add	x9, x9, x21, lsl #6
1000336ac: 52800026    	mov	w6, #0x1                ; =1
1000336b0: 52800027    	mov	w7, #0x1                ; =1
1000336b4: ad000120    	stp	q0, q0, [x9]
1000336b8: ad010120    	stp	q0, q0, [x9, #0x20]
1000336bc: f9402281    	ldr	x1, [x20, #0x40]
1000336c0: f9402a83    	ldr	x3, [x20, #0x50]
1000336c4: 390003ff    	strb	wzr, [sp]
1000336c8: 94079e12    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000336cc: f85583a8    	ldur	x8, [x29, #-0xa8]
1000336d0: 3ccc82e0    	ldur	q0, [x23, #0xc8]
1000336d4: aa1403e0    	mov	x0, x20
1000336d8: f9402be1    	ldr	x1, [sp, #0x50]
1000336dc: f9002288    	str	x8, [x20, #0x40]
1000336e0: 3c848280    	stur	q0, [x20, #0x48]
1000336e4: f9402428    	ldr	x8, [x1, #0x48]
1000336e8: b4000548    	cbz	x8, 0x100033790 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x960>
1000336ec: f94017e8    	ldr	x8, [sp, #0x28]
1000336f0: 9102e3e2    	add	x2, sp, #0xb8
1000336f4: a90bebf6    	stp	x22, x26, [sp, #0xb8]
1000336f8: f90067e8    	str	x8, [sp, #0xc8]
1000336fc: 9400126c    	bl	0x1000380ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push>
100033700: b4000100    	cbz	x0, 0x100033720 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x8f0>
100033704: f9400409    	ldr	x9, [x0, #0x8]
100033708: aa0003e8    	mov	x8, x0
10003370c: b40000a9    	cbz	x9, 0x100033720 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x8f0>
100033710: aa0103e2    	mov	x2, x1
100033714: aa1403e0    	mov	x0, x20
100033718: aa0803e1    	mov	x1, x8
10003371c: 17fffe44    	b	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1fc>
100033720: a9479681    	ldp	x1, x5, [x20, #0x78]
100033724: d101e3a0    	sub	x0, x29, #0x78
100033728: f9404683    	ldr	x3, [x20, #0x88]
10003372c: f94033e4    	ldr	x4, [sp, #0x60]
100033730: 52800202    	mov	w2, #0x10               ; =16
100033734: 52800026    	mov	w6, #0x1                ; =1
100033738: 52800027    	mov	w7, #0x1                ; =1
10003373c: 390003ff    	strb	wzr, [sp]
100033740: 94079df4    	bl	0x10021af10 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100033744: a94aa688    	ldp	x8, x9, [x20, #0xa8]
100033748: f85903aa    	ldur	x10, [x29, #-0x70]
10003374c: eb09015f    	cmp	x10, x9
100033750: 9a89b14a    	csel	x10, x10, x9, lt
100033754: f100055f    	cmp	x10, #0x1
100033758: 540000cb    	b.lt	0x100033770 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x940>
10003375c: f85883a0    	ldur	x0, [x29, #-0x78]
100033760: d37ced42    	lsl	x2, x10, #4
100033764: aa0803e1    	mov	x1, x8
100033768: 9407b768    	bl	0x100221508 <dyld_stub_binder+0x100221508>
10003376c: f9405688    	ldr	x8, [x20, #0xa8]
100033770: aa1403e9    	mov	x9, x20
100033774: f9405a8a    	ldr	x10, [x20, #0xb0]
100033778: aa0803e0    	mov	x0, x8
10003377c: aa0903f3    	mov	x19, x9
100033780: d37ced41    	lsl	x1, x10, #4
100033784: 9407b7a9    	bl	0x100221628 <dyld_stub_binder+0x100221628>
100033788: 2a1f03f4    	mov	w20, wzr
10003378c: 1400001c    	b	0x1000337fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9cc>
100033790: f9405803    	ldr	x3, [x0, #0xb0]
100033794: f94013e2    	ldr	x2, [sp, #0x20]
100033798: d10243a8    	sub	x8, x29, #0x90
10003379c: aa1403e0    	mov	x0, x20
1000337a0: 94001311    	bl	0x1000383e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).prepareHost>
1000337a4: a94aa688    	ldp	x8, x9, [x20, #0xa8]
1000337a8: f85783aa    	ldur	x10, [x29, #-0x88]
1000337ac: eb09015f    	cmp	x10, x9
1000337b0: 9a89b14a    	csel	x10, x10, x9, lt
1000337b4: f100055f    	cmp	x10, #0x1
1000337b8: 540000cb    	b.lt	0x1000337d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x9a0>
1000337bc: f85703a0    	ldur	x0, [x29, #-0x90]
1000337c0: d37ced42    	lsl	x2, x10, #4
1000337c4: aa0803e1    	mov	x1, x8
1000337c8: 9407b750    	bl	0x100221508 <dyld_stub_binder+0x100221508>
1000337cc: f9405688    	ldr	x8, [x20, #0xa8]
1000337d0: aa1403e9    	mov	x9, x20
1000337d4: f9405a8a    	ldr	x10, [x20, #0xb0]
1000337d8: f94017eb    	ldr	x11, [sp, #0x28]
1000337dc: 52800054    	mov	w20, #0x2               ; =2
1000337e0: aa0803e0    	mov	x0, x8
1000337e4: a9126936    	stp	x22, x26, [x9, #0x120]
1000337e8: aa0903f3    	mov	x19, x9
1000337ec: d37ced41    	lsl	x1, x10, #4
1000337f0: f900992b    	str	x11, [x9, #0x130]
1000337f4: 3904e134    	strb	w20, [x9, #0x138]
1000337f8: 9407b78c    	bl	0x100221628 <dyld_stub_binder+0x100221628>
1000337fc: 6f00e400    	movi.2d	v0, #0000000000000000
100033800: 9102e268    	add	x8, x19, #0xb8
100033804: 4d408500    	ld1.d	{ v0 }[1], [x8]
100033808: 3d802e60    	str	q0, [x19, #0xb0]
10003380c: 17fffea5    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
100033810: f9401be8    	ldr	x8, [sp, #0x30]
100033814: f94013e2    	ldr	x2, [sp, #0x20]
100033818: aa0903e0    	mov	x0, x9
10003381c: aa0c03e1    	mov	x1, x12
100033820: aa1403f3    	mov	x19, x20
100033824: aa0903f4    	mov	x20, x9
100033828: 2a0803e3    	mov	w3, w8
10003382c: 910343e8    	add	x8, sp, #0xd0
100033830: 940012ed    	bl	0x1000383e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).prepareHost>
100033834: f9406fe9    	ldr	x9, [sp, #0xd8]
100033838: f9400bfa    	ldr	x26, [sp, #0x10]
10003383c: aa1403e8    	mov	x8, x20
100033840: aa1303ee    	mov	x14, x19
100033844: f100053f    	cmp	x9, #0x1
100033848: 5400020b    	b.lt	0x100033888 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa58>
10003384c: f9406bea    	ldr	x10, [sp, #0xd0]
100033850: f9402beb    	ldr	x11, [sp, #0x50]
100033854: f94033ed    	ldr	x13, [sp, #0x60]
100033858: b4000b8b    	cbz	x11, 0x1000339c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb98>
10003385c: b840476c    	ldr	w12, [x27], #0x4
100033860: f9404101    	ldr	x1, [x8, #0x80]
100033864: 8b0c01a0    	add	x0, x13, x12
100033868: eb01001f    	cmp	x0, x1
10003386c: 54000bc2    	b.hs	0x1000339e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbb4>
100033870: f9403d0c    	ldr	x12, [x8, #0x78]
100033874: d1000529    	sub	x9, x9, #0x1
100033878: d100056b    	sub	x11, x11, #0x1
10003387c: 3ce07980    	ldr	q0, [x12, x0, lsl #4]
100033880: 3c810540    	str	q0, [x10], #0x10
100033884: b5fffea9    	cbnz	x9, 0x100033858 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa28>
100033888: f94017e9    	ldr	x9, [sp, #0x28]
10003388c: 52800054    	mov	w20, #0x2               ; =2
100033890: a912690e    	stp	x14, x26, [x8, #0x120]
100033894: 3904e114    	strb	w20, [x8, #0x138]
100033898: f9009909    	str	x9, [x8, #0x130]
10003389c: 17fffe81    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
1000338a0: aa1403f6    	mov	x22, x20
1000338a4: aa1303f5    	mov	x21, x19
1000338a8: aa0103f4    	mov	x20, x1
1000338ac: aa0903f3    	mov	x19, x9
1000338b0: aa1f03e1    	mov	x1, xzr
1000338b4: 9101c3e8    	add	x8, sp, #0x70
1000338b8: aa1a03e0    	mov	x0, x26
1000338bc: 94004698    	bl	0x10004531c <_github.com/cpunion/wasmvm/internal/engine/state.(*ScalarAccess).Access>
1000338c0: a94707e8    	ldp	x8, x1, [sp, #0x70]
1000338c4: b40000c1    	cbz	x1, 0x1000338dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaac>
1000338c8: f9400429    	ldr	x9, [x1, #0x8]
1000338cc: b4000089    	cbz	x9, 0x1000338dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaac>
1000338d0: f94043e2    	ldr	x2, [sp, #0x80]
1000338d4: aa1303e0    	mov	x0, x19
1000338d8: 17fffdd5    	b	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1fc>
1000338dc: 39406349    	ldrb	w9, [x26, #0x18]
1000338e0: 37000129    	tbnz	w9, #0x0, 0x100033904 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad4>
1000338e4: f9400be9    	ldr	x9, [sp, #0x10]
1000338e8: b40007a9    	cbz	x9, 0x1000339dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbac>
1000338ec: b94002c0    	ldr	w0, [x22]
1000338f0: aa1403e1    	mov	x1, x20
1000338f4: eb00029f    	cmp	x20, x0
1000338f8: 54000769    	b.ls	0x1000339e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xbb4>
1000338fc: 8b0012a9    	add	x9, x21, x0, lsl #4
100033900: a9007d28    	stp	x8, xzr, [x9]
100033904: f9401fe8    	ldr	x8, [sp, #0x38]
100033908: 2a1f03f4    	mov	w20, wzr
10003390c: 11000508    	add	w8, w8, #0x1
100033910: b9000b28    	str	w8, [x25, #0x8]
100033914: 17fffe63    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
100033918: 2a1f03f4    	mov	w20, wzr
10003391c: 17fffe61    	b	0x1000332a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x470>
100033920: aa1503e0    	mov	x0, x21
100033924: aa1f03e1    	mov	x1, xzr
100033928: 9407540b    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003392c: aa0803e0    	mov	x0, x8
100033930: 94075976    	bl	0x100209f08 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033934: aa0903e0    	mov	x0, x9
100033938: 94075974    	bl	0x100209f08 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003393c: aa0803e0    	mov	x0, x8
100033940: 52800021    	mov	w1, #0x1                ; =1
100033944: 52800043    	mov	w3, #0x2                ; =2
100033948: 94075749    	bl	0x10020966c <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003394c: f94033e0    	ldr	x0, [sp, #0x60]
100033950: 52800021    	mov	w1, #0x1                ; =1
100033954: aa0803e2    	mov	x2, x8
100033958: 52800063    	mov	w3, #0x3                ; =3
10003395c: 94075744    	bl	0x10020966c <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033960: aa0903e0    	mov	x0, x9
100033964: 2a1f03e1    	mov	w1, wzr
100033968: 52800043    	mov	w3, #0x2                ; =2
10003396c: 94075740    	bl	0x10020966c <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033970: aa0803e0    	mov	x0, x8
100033974: 2a1f03e1    	mov	w1, wzr
100033978: aa0903e2    	mov	x2, x9
10003397c: 52800063    	mov	w3, #0x3                ; =3
100033980: 9407573b    	bl	0x10020966c <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033984: aa0803e0    	mov	x0, x8
100033988: aa0d03e1    	mov	x1, x13
10003398c: 940753f2    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033990: f9402be1    	ldr	x1, [sp, #0x50]
100033994: aa0a03e0    	mov	x0, x10
100033998: 9407595c    	bl	0x100209f08 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003399c: aa0803e0    	mov	x0, x8
1000339a0: aa0c03e1    	mov	x1, x12
1000339a4: 940753ec    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339a8: f9402be1    	ldr	x1, [sp, #0x50]
1000339ac: aa1b03e0    	mov	x0, x27
1000339b0: 94075956    	bl	0x100209f08 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000339b4: f9402be0    	ldr	x0, [sp, #0x50]
1000339b8: aa0003e1    	mov	x1, x0
1000339bc: 94075953    	bl	0x100209f08 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000339c0: aa0803e0    	mov	x0, x8
1000339c4: 940753e4    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339c8: f9402be0    	ldr	x0, [sp, #0x50]
1000339cc: aa0003e1    	mov	x1, x0
1000339d0: 940753e1    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339d4: aa1503e0    	mov	x0, x21
1000339d8: 940753df    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339dc: aa1f03e0    	mov	x0, xzr
1000339e0: aa1f03e1    	mov	x1, xzr
1000339e4: 940753dc    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339e8: aa1f03e1    	mov	x1, xzr
1000339ec: 940753da    	bl	0x100208954 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
