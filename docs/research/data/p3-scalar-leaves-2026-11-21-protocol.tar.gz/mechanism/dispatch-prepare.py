from pathlib import Path
import hashlib
import json

out = Path(__file__).resolve().parent
plan = json.loads((out.parent/"core-plan.json").read_text())
scope = {
 "original22-v1/core/function-calls": ["go"],
 "original22-v1/core/integer-loop":["llgo"],
 "original22-v1/memory/narrow-unaligned":["go","llgo"],
 "gc-sustained-v1/gc/struct-indirect-access":["go"],
 "generic-calls-v1/core/generic-calls":["llgo"],
}
hashes=plan["binarySHA256"].copy()
cases=[]
for record in plan["cases"]:
    f=record["fixture"]
    name=f["cohort"]+"/"+f["id"]
    if name not in scope:
        continue
    commands={}
    for compiler in scope[name]:
        candidate=out/(compiler+"-phase")
        hashes[str(candidate)]=hashlib.sha256(candidate.read_bytes()).hexdigest()
        current=record["commands"]["head-"+compiler+"-interpreter"]
        base=record["commands"]["base-"+compiler+"-interpreter"]
        for label,template in [(f"head-{compiler}-dispatch",current),(f"base-{compiler}-dispatch",current),(f"base-{compiler}-main",base)]:
            command=template.copy()
            command[command.index("--samples")+1]="6"
            if label.startswith("head-"):
                command[0]=str(candidate)
            commands[label]=command
    cases.append(dict(id=name,fixture=f,commands=commands))
assert len(cases)==len(scope)
result=dict(blocks=6,samples=5,seed=202611218237,cases=cases,binarySHA256=hashes,
    scope="Host-only scalar classification screen on Go and pinned LLGo, with main and the unchanged P3 and memory candidate as separate references. Same fixtures, independent process blocks, fixed A/A.")
(out/"frozen-plan.json").write_text(json.dumps(result,indent=2)+"\n")
