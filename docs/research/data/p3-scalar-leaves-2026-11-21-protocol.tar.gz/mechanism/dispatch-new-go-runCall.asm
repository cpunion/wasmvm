TEXT github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB) /Users/lijie/source/goplus/wasmvm-source-cleanup/internal/engine/execute/runtime_calls.go
  runtime_calls.go:11	0x1002181b0		f9400b90		MOVD 16(R28), R16									
  runtime_calls.go:11	0x1002181b4		d10543f1		SUB $336, RSP, R17									
  runtime_calls.go:11	0x1002181b8		eb10023f		CMP R16, R17										
  runtime_calls.go:11	0x1002181bc		54006bc9		BLS 862(PC)										
  runtime_calls.go:11	0x1002181c0		d10743f4		SUB $464, RSP, R20									
  runtime_calls.go:11	0x1002181c4		a93ffa9d		STP (R29, R30), -8(R20)									
  runtime_calls.go:11	0x1002181c8		9100029f		MOVD R20, RSP										
  runtime_calls.go:11	0x1002181cc		d10023fd		SUB $8, RSP, R29									
  runtime_calls.go:12	0x1002181d0		a9444410		LDP 64(R0), (R16, R17)									
  runtime_calls.go:12	0x1002181d4		d1000633		SUB $1, R17, R19									
  runtime_calls.go:13	0x1002181d8		eb13023f		CMP R19, R17										
  runtime_calls.go:13	0x1002181dc		54006a49		BLS 850(PC)										
  runtime_calls.go:13	0x1002181e0		8b131a10		ADD R19<<6, R16, R16									
  runtime_calls.go:14	0x1002181e4		f9400201		MOVD (R16), R1										
  runtime_calls.go:15	0x1002181e8		f9402431		MOVD 72(R1), R17									
  runtime_calls.go:16	0x1002181ec		b9400a14		MOVWU 8(R16), R20									
  runtime_calls.go:17	0x1002181f0		a94b5a35		LDP 176(R17), (R21, R22)								
  runtime_calls.go:17	0x1002181f4		aa1403f7		MOVD R20, R23										
  runtime_calls.go:17	0x1002181f8		eb1602ff		CMP R22, R23										
  runtime_calls.go:17	0x1002181fc		540068e2		BCS 839(PC)										
  runtime_calls.go:18	0x100218200		f9400e16		MOVD 24(R16), R22									
  runtime_calls.go:19	0x100218204		f9404418		MOVD 136(R0), R24									
  runtime_calls.go:19	0x100218208		f9404e2e		MOVD 152(R17), R14									
  runtime_calls.go:19	0x10021820c		8b0e02d9		ADD R14, R22, R25									
  runtime_calls.go:17	0x100218210		8b1716b5		ADD R23<<5, R21, R21									
  runtime_calls.go:19	0x100218214		eb19031f		CMP R25, R24										
  runtime_calls.go:19	0x100218218		540067a3		BCC 829(PC)										
  runtime_calls.go:19	0x10021821c		eb1902df		CMP R25, R22										
  runtime_calls.go:19	0x100218220		54006708		BHI 824(PC)										
  runtime_calls.go:19	0x100218224		f9403c17		MOVD 120(R0), R23									
  runtime_calls.go:19	0x100218228		cb1802d9		SUB R24, R22, R25									
  runtime_calls.go:19	0x10021822c		8a99fed9		AND R25->63, R22, R25									
  runtime_calls.go:21	0x100218230		29400aba		LDPW (R21), (R26, R2)									
  runtime_calls.go:19	0x100218234		8b1912ed		ADD R25<<4, R23, R13									
  runtime_calls.go:19	0x100218238		cb16030f		SUB R22, R24, R15									
  source_image.go:111	0x10021823c		f9400237		MOVD (R17), R23										
  source_image.go:111	0x100218240		b4000157		CBZ R23, 10(PC)										
  source_image.go:112	0x100218244		a94062f7		LDP (R23), (R23, R24)									
  source_image.go:112	0x100218248		aa0203f9		MOVD R2, R25										
  source_image.go:112	0x10021824c		eb18033f		CMP R24, R25										
  source_image.go:112	0x100218250		54006522		BCS 809(PC)										
  source_image.go:112	0x100218254		d3797c58		UBFIZ $7, R2, $32, R24									
  source_image.go:112	0x100218258		cb190f18		SUB R25<<3, R24, R24									
  source_image.go:112	0x10021825c		8b1802f7		ADD R24, R23, R23									
  source_image.go:113	0x100218260		294262f7		LDPW 16(R23), (R23, R24)								
  runtime_calls.go:22	0x100218264		14000009		JMP 9(PC)										
  source_image.go:115	0x100218268		a947e237		LDP 120(R17), (R23, R24)								
  source_image.go:115	0x10021826c		aa0203f9		MOVD R2, R25										
  source_image.go:115	0x100218270		eb18033f		CMP R24, R25										
  source_image.go:115	0x100218274		540063a2		BCS 797(PC)										
  source_image.go:115	0x100218278		d3787c5e		UBFIZ $8, R2, $32, R30									
  source_image.go:115	0x10021827c		cb1917d9		SUB R25<<5, R30, R25									
  source_image.go:115	0x100218280		8b1902f9		ADD R25, R23, R25									
  source_image.go:116	0x100218284		29426337		LDPW 16(R25), (R23, R24)								
  module.go:224		0x100218288		b2400359		ORR $1, R26, R25									
  module.go:224		0x10021828c		71004f3f		CMPW $19, R25										
  module.go:224		0x100218290		54000061		BNE 3(PC)										
  module.go:224		0x100218294		b24003fe		ORR $1, ZR, R30										
  module.go:224		0x100218298		14000003		JMP 3(PC)										
  module.go:224		0x10021829c		7100575f		CMPW $21, R26										
  module.go:224		0x1002182a0		9a9f17fe		CSET EQ, R30										
  runtime_calls.go:25	0x1002182a4		f9406e23		MOVD 216(R17), R3									
  runtime_calls.go:25	0x1002182a8		294316a4		LDPW 24(R21), (R4, R5)									
  runtime_calls.go:25	0x1002182ac		8b050086		ADD R5, R4, R6										
  runtime_calls.go:25	0x1002182b0		2a0603e6		MOVW R6, R6										
  runtime_calls.go:25	0x1002182b4		eb0300df		CMP R3, R6										
  runtime_calls.go:25	0x1002182b8		54006168		BHI 779(PC)										
  runtime_calls.go:25	0x1002182bc		eb06009f		CMP R6, R4										
  runtime_calls.go:25	0x1002182c0		54006108		BHI 776(PC)										
  runtime_calls.go:25	0x1002182c4		f9406627		MOVD 200(R17), R7									
  runtime_calls.go:25	0x1002182c8		cb030088		SUB R3, R4, R8										
  runtime_calls.go:25	0x1002182cc		8a88fc88		AND R8->63, R4, R8									
  module.go:224		0x1002182d0		b27f035a		ORR $2, R26, R26									
  runtime_calls.go:20	0x1002182d4		f9402029		MOVD 64(R1), R9										
  runtime_calls.go:25	0x1002182d8		cb0400c6		SUB R4, R6, R6										
  runtime_calls.go:25	0x1002182dc		8b0808ea		ADD R8<<2, R7, R10									
  runtime_calls.go:25	0x1002182e0		cb040063		SUB R4, R3, R3										
  module.go:224		0x1002182e4		71004b5f		CMPW $18, R26										
  runtime_calls.go:27	0x1002182e8		540000e1		BNE 7(PC)										
  runtime_calls.go:28	0x1002182ec		a9440938		LDP 64(R9), (R24, R2)									
  runtime_calls.go:28	0x1002182f0		2a1703e4		MOVW R23, R4										
  runtime_calls.go:28	0x1002182f4		eb02009f		CMP R2, R4										
  runtime_calls.go:28	0x1002182f8		54005f22		BCS 761(PC)										
  runtime_calls.go:28	0x1002182fc		f8647b18		MOVD (R24)(R4<<3), R24									
  runtime_calls.go:28	0x100218300		1400002e		JMP 46(PC)										
  runtime_calls.go:29	0x100218304		7100573f		CMPW $21, R25										
  runtime_calls.go:29	0x100218308		54000201		BNE 16(PC)										
  runtime_calls.go:30	0x10021830c		d10004b8		SUB $1, R5, R24										
  runtime_calls.go:31	0x100218310		2a1803e4		MOVW R24, R4										
  runtime_calls.go:31	0x100218314		eb06009f		CMP R6, R4										
  runtime_calls.go:31	0x100218318		54005e02		BCS 752(PC)										
  runtime_calls.go:31	0x10021831c		b8647944		MOVWU (R10)(R4<<2), R4									
  runtime_calls.go:31	0x100218320		eb0e009f		CMP R14, R4										
  runtime_calls.go:31	0x100218324		54005d82		BCS 748(PC)										
  runtime_calls.go:31	0x100218328		8b0411a4		ADD R4<<4, R13, R4									
  runtime_calls.go:31	0x10021832c		f9400084		MOVD (R4), R4										
  runtime_calls.go:32	0x100218330		b5000404		CBNZ R4, 32(PC)										
  runtime_calls.go:33	0x100218334		d2800123		MOVD $9, R3										
  runtime_calls.go:33	0x100218338		97fffcbe		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:33	0x10021833c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:33	0x100218340		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:33	0x100218344		d65f03c0		RET											
  runtime_calls.go:37	0x100218348		a9459122		LDP 88(R9), (R2, R4)									
  runtime_calls.go:37	0x10021834c		2a1803f8		MOVW R24, R24										
  runtime_calls.go:37	0x100218350		eb04031f		CMP R4, R24										
  runtime_calls.go:37	0x100218354		54005bc2		BCS 734(PC)										
  runtime_calls.go:36	0x100218358		d10004a4		SUB $1, R5, R4										
  runtime_calls.go:37	0x10021835c		f8787858		MOVD (R2)(R24<<3), R24									
  runtime_calls.go:38	0x100218360		3980031b		MOVB (R24), R27										
  runtime_calls.go:38	0x100218364		2a0403e2		MOVW R4, R2										
  runtime_calls.go:38	0x100218368		eb06005f		CMP R6, R2										
  runtime_calls.go:38	0x10021836c		54005ae2		BCS 727(PC)										
  runtime_calls.go:38	0x100218370		b8627942		MOVWU (R10)(R2<<2), R2									
  runtime_calls.go:38	0x100218374		eb0e005f		CMP R14, R2										
  runtime_calls.go:38	0x100218378		54005a62		BCS 723(PC)										
  runtime_calls.go:38	0x10021837c		8b0211a2		ADD R2<<4, R13, R2									
  runtime_calls.go:38	0x100218380		f9400042		MOVD (R2), R2										
  module.go:70		0x100218384		3940a705		MOVBU 41(R24), R5									
  module.go:70		0x100218388		37000045		TBNZ $0, R5, 2(PC)									
  module.go:73		0x10021838c		2a0203e2		MOVW R2, R2										
  runtime_calls.go:39	0x100218390		a9439718		LDP 56(R24), (R24, R5)									
  runtime_calls.go:39	0x100218394		eb05005f		CMP R5, R2										
  runtime_calls.go:39	0x100218398		54003722		BCS 441(PC)										
  runtime_calls.go:42	0x10021839c		f8627b18		MOVD (R24)(R2<<3), R24									
  runtime_calls.go:43	0x1002183a0		b4003638		CBZ R24, 433(PC)									
  runtime_calls.go:43	0x1002183a4		aa1803e2		MOVD R24, R2										
  runtime_calls.go:43	0x1002183a8		aa0403f8		MOVD R4, R24										
  runtime_calls.go:43	0x1002183ac		aa0203e4		MOVD R2, R4										
  runtime_calls.go:47	0x1002183b0		aa1803e5		MOVD R24, R5										
  runtime_calls.go:47	0x1002183b4		aa0403f8		MOVD R4, R24										
  state.go:177		0x1002183b8		b4003498		CBZ R24, 420(PC)									
  runtime_calls.go:47	0x1002183bc		f9400002		MOVD (R0), R2										
  state.go:177		0x1002183c0		a94d2c44		LDP 208(R2), (R4, R11)									
  state.go:177		0x1002183c4		eb0b031f		CMP R11, R24										
  state.go:177		0x1002183c8		54003402		BCS 416(PC)										
  state.go:177		0x1002183cc		f8787898		MOVD (R4)(R24<<3), R24									
  state.go:177		0x1002183d0		b40033d8		CBZ R24, 414(PC)									
  runtime_calls.go:13	0x1002183d4		f900efe0		MOVD R0, 472(RSP)									
  runtime_calls.go:12	0x1002183d8		f9005ff3		MOVD R19, 184(RSP)									
  runtime_calls.go:13	0x1002183dc		f90097f0		MOVD R16, 296(RSP)									
  runtime_calls.go:16	0x1002183e0		b90093f4		MOVW R20, 144(RSP)									
  runtime_calls.go:18	0x1002183e4		f90077f6		MOVD R22, 232(RSP)									
  runtime_calls.go:19	0x1002183e8		f90053ef		MOVD R15, 160(RSP)									
  runtime_calls.go:19	0x1002183ec		f90083ed		MOVD R13, 256(RSP)									
  runtime_calls.go:20	0x1002183f0		f90087e9		MOVD R9, 264(RSP)									
  runtime_calls.go:23	0x1002183f4		39023ffe		MOVB R30, 143(RSP)									
  runtime_calls.go:25	0x1002183f8		f90057e6		MOVD R6, 168(RSP)									
  runtime_calls.go:25	0x1002183fc		f9005be3		MOVD R3, 176(RSP)									
  runtime_calls.go:25	0x100218400		f9008bea		MOVD R10, 272(RSP)									
  state.go:177		0x100218404		f900bbf8		MOVD R24, 368(RSP)									
  runtime_calls.go:25	0x100218408		f900b7e7		MOVD R7, 360(RSP)									
  runtime_calls.go:25	0x10021840c		f9007fe8		MOVD R8, 248(RSP)									
  runtime_calls.go:19	0x100218410		f9004fee		MOVD R14, 152(RSP)									
  runtime_calls.go:47	0x100218414		b90097e5		MOVW R5, 148(RSP)									
  runtime_calls.go:51	0x100218418		71004f5f		CMPW $19, R26										
  state.go:180		0x10021841c		54000060		BEQ 3(PC)										
  runtime_calls.go:51	0x100218420		7100573f		CMPW $21, R25										
  runtime_calls.go:51	0x100218424		54000421		BNE 33(PC)										
  runtime_calls.go:51	0x100218428		a942ad24		LDP 40(R9), (R4, R11)									
  runtime_calls.go:51	0x10021842c		2a1703ec		MOVW R23, R12										
  runtime_calls.go:51	0x100218430		eb0b019f		CMP R11, R12										
  runtime_calls.go:51	0x100218434		54005462		BCS 675(PC)										
  runtime_calls.go:14	0x100218438		f90093e1		MOVD R1, 288(RSP)									
  runtime_calls.go:15	0x10021843c		f9009ff1		MOVD R17, 312(RSP)									
  runtime_calls.go:17	0x100218440		f9008ff5		MOVD R21, 280(RSP)									
  runtime_calls.go:51	0x100218444		b9403b01		MOVWU 56(R24), R1									
  runtime_calls.go:51	0x100218448		b86c7883		MOVWU (R4)(R12<<2), R3									
  state.go:565		0x10021844c		91058040		ADD $352, R2, R0									
  state.go:565		0x100218450		aa0303e2		MOVD R3, R2										
  state.go:565		0x100218454		97fc43b7		CALL github.com/cpunion/wasmvm/internal/core/module.(*TypeRegistry).FunctionSubtype(SB)	
  runtime_calls.go:51	0x100218458		36002e60		TBZ $0, R0, 371(PC)									
  execution.go:209	0x10021845c		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:75	0x100218460		f9405be3		MOVD 176(RSP), R3									
  runtime_calls.go:70	0x100218464		b94097e5		MOVWU 148(RSP), R5									
  runtime_calls.go:111	0x100218468		f94057e6		MOVD 168(RSP), R6									
  runtime_calls.go:111	0x10021846c		f940b7e7		MOVD 360(RSP), R7									
  runtime_calls.go:111	0x100218470		f9407fe8		MOVD 248(RSP), R8									
  host.go:21		0x100218474		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:100	0x100218478		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:100	0x10021847c		f94083ed		MOVD 256(RSP), R13									
  runtime_calls.go:100	0x100218480		f9404fee		MOVD 152(RSP), R14									
  runtime_calls.go:100	0x100218484		f94053ef		MOVD 160(RSP), R15									
  runtime_calls.go:56	0x100218488		f94097f0		MOVD 296(RSP), R16									
  runtime_calls.go:58	0x10021848c		f9409ff1		MOVD 312(RSP), R17									
  runtime_calls.go:79	0x100218490		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:127	0x100218494		b94093f4		MOVWU 144(RSP), R20									
  runtime_calls.go:58	0x100218498		f9408ff5		MOVD 280(RSP), R21									
  runtime_calls.go:67	0x10021849c		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:58	0x1002184a0		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:55	0x1002184a4		39423ffe		MOVBU 143(RSP), R30									
  runtime_calls.go:55	0x1002184a8		3600009e		TBZ $0, R30, 4(PC)									
  runtime_calls.go:56	0x1002184ac		a9422e02		LDP 32(R16), (R2, R11)									
  runtime_calls.go:56	0x1002184b0		f9401a04		MOVD 48(R16), R4									
  runtime_calls.go:56	0x1002184b4		14000012		JMP 18(PC)										
  runtime_calls.go:58	0x1002184b8		f9406e37		MOVD 216(R17), R23									
  runtime_calls.go:58	0x1002184bc		294366b5		LDPW 24(R21), (R21, R25)								
  runtime_calls.go:58	0x1002184c0		8b150335		ADD R21, R25, R21									
  runtime_calls.go:58	0x1002184c4		f9401719		MOVD 40(R24), R25									
  runtime_calls.go:58	0x1002184c8		8b1902b9		ADD R25, R21, R25									
  runtime_calls.go:58	0x1002184cc		2a1903f9		MOVW R25, R25										
  runtime_calls.go:58	0x1002184d0		eb17033f		CMP R23, R25										
  runtime_calls.go:58	0x1002184d4		54004f08		BHI 632(PC)										
  runtime_calls.go:58	0x1002184d8		2a1503f5		MOVW R21, R21										
  runtime_calls.go:58	0x1002184dc		eb1902bf		CMP R25, R21										
  runtime_calls.go:58	0x1002184e0		54004e48		BHI 626(PC)										
  runtime_calls.go:58	0x1002184e4		f9406631		MOVD 200(R17), R17									
  runtime_calls.go:58	0x1002184e8		cb1702ba		SUB R23, R21, R26									
  runtime_calls.go:58	0x1002184ec		8a9afeba		AND R26->63, R21, R26									
  runtime_calls.go:58	0x1002184f0		cb15032b		SUB R21, R25, R11									
  runtime_calls.go:58	0x1002184f4		cb1502e4		SUB R21, R23, R4									
  runtime_calls.go:58	0x1002184f8		8b1a0a22		ADD R26<<2, R17, R2									
  runtime_calls.go:60	0x1002184fc		f90063eb		MOVD R11, 192(RSP)									
  runtime_calls.go:60	0x100218500		f90067e4		MOVD R4, 200(RSP)									
  runtime_calls.go:60	0x100218504		f9009be2		MOVD R2, 304(RSP)									
  execution.go:209	0x100218508		f940b011		MOVD 352(R0), R17									
  execution.go:209	0x10021850c		b40000d1		CBZ R17, 6(PC)										
  type.go:19		0x100218510		88dffe31		LDARW (R17), R17									
  execution.go:209	0x100218514		35000091		CBNZW R17, 4(PC)									
  runtime_calls.go:60	0x100218518		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:60	0x10021851c		aa1f03ec		MOVD ZR, R12										
  runtime_calls.go:60	0x100218520		1400001a		JMP 26(PC)										
  execution.go:212	0x100218524		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100218528		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10021852c		d63f0020		CALL (R1)										
  runtime_calls.go:100	0x100218530		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:75	0x100218534		f9405be3		MOVD 176(RSP), R3									
  runtime_calls.go:100	0x100218538		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:70	0x10021853c		b94097e5		MOVWU 148(RSP), R5									
  runtime_calls.go:111	0x100218540		f94057e6		MOVD 168(RSP), R6									
  runtime_calls.go:111	0x100218544		f940b7e7		MOVD 360(RSP), R7									
  runtime_calls.go:111	0x100218548		f9407fe8		MOVD 248(RSP), R8									
  host.go:21		0x10021854c		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:100	0x100218550		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:100	0x100218554		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:100	0x100218558		f94083ed		MOVD 256(RSP), R13									
  runtime_calls.go:100	0x10021855c		f9404fee		MOVD 152(RSP), R14									
  runtime_calls.go:100	0x100218560		f94053ef		MOVD 160(RSP), R15									
  runtime_calls.go:126	0x100218564		f94097f0		MOVD 296(RSP), R16									
  runtime_calls.go:79	0x100218568		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:127	0x10021856c		b94093f4		MOVWU 144(RSP), R20									
  runtime_calls.go:67	0x100218570		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:67	0x100218574		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:63	0x100218578		39423ffe		MOVBU 143(RSP), R30									
  runtime_calls.go:60	0x10021857c		aa0103ec		MOVD R1, R12										
  runtime_calls.go:60	0x100218580		aa0003e1		MOVD R0, R1										
  runtime_calls.go:67	0x100218584		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:60	0x100218588		b5002441		CBNZ R1, 290(PC)									
  runtime_calls.go:63	0x10021858c		3600093e		TBZ $0, R30, 73(PC)									
  runtime_calls.go:67	0x100218590		f9402706		MOVD 72(R24), R6									
  runtime_calls.go:67	0x100218594		b4000426		CBZ R6, 33(PC)										
  runtime_calls.go:67	0x100218598		f9404cc6		MOVD 152(R6), R6									
  runtime_calls.go:67	0x10021859c		8b0602c6		ADD R6, R22, R6										
  runtime_calls.go:67	0x1002185a0		b9401c07		MOVWU 28(R0), R7									
  runtime_calls.go:67	0x1002185a4		eb0600ff		CMP R6, R7										
  runtime_calls.go:67	0x1002185a8		54000382		BCS 28(PC)										
  runtime_calls.go:68	0x1002185ac		d2800500		MOVD $40, R0										
  runtime_calls.go:68	0x1002185b0		f0001221		ADRP 2387968(PC), R1									
  runtime_calls.go:68	0x1002185b4		9113c021		ADD $1264, R1, R1									
  runtime_calls.go:68	0x1002185b8		b24003e2		ORR $1, ZR, R2										
  runtime_calls.go:68	0x1002185bc		97f81191		CALL runtime.mallocgcSmallScanNoHeaderSC5(SB)						
  runtime_calls.go:68	0x1002185c0		f000137b		ADRP 2551808(PC), R27									
  runtime_calls.go:68	0x1002185c4		9107c37b		ADD $496, R27, R27									
  runtime_calls.go:68	0x1002185c8		a9401363		LDP (R27), (R3, R4)									
  runtime_calls.go:68	0x1002185cc		f9000003		MOVD R3, (R0)										
  runtime_calls.go:68	0x1002185d0		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:68	0x1002185d4		b94fd363		MOVWU 4048(R27), R3									
  runtime_calls.go:68	0x1002185d8		34000063		CBZW R3, 3(PC)										
  runtime_calls.go:68	0x1002185dc		97f9ab21		CALL runtime.gcWriteBarrier1(SB)							
  runtime_calls.go:68	0x1002185e0		f9000324		MOVD R4, (R25)										
  runtime_calls.go:68	0x1002185e4		f9000404		MOVD R4, 8(R0)										
  runtime_calls.go:68	0x1002185e8		b00000e3		ADRP 118784(PC), R3									
  runtime_calls.go:68	0x1002185ec		91384463		ADD $3601, R3, R3									
  runtime_calls.go:68	0x1002185f0		d2800224		MOVD $17, R4										
  runtime_calls.go:68	0x1002185f4		a9019003		STP (R3, R4), 24(R0)									
  runtime_calls.go:68	0x1002185f8		90001301		ADRP 2490368(PC), R1									
  runtime_calls.go:68	0x1002185fc		91272021		ADD $2504, R1, R1									
  runtime_calls.go:68	0x100218600		aa0003e2		MOVD R0, R2										
  runtime_calls.go:68	0x100218604		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:68	0x100218608		97ffea96		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:68	0x10021860c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:68	0x100218610		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:68	0x100218614		d65f03c0		RET											
  runtime_calls.go:70	0x100218618		2a0503e1		MOVW R5, R1										
  runtime_calls.go:70	0x10021861c		f9405c05		MOVD 184(R0), R5									
  runtime_calls.go:70	0x100218620		eb05003f		CMP R5, R1										
  runtime_calls.go:70	0x100218624		5400006c		BGT 3(PC)										
  runtime_calls.go:73	0x100218628		f9005801		MOVD R1, 176(R0)									
  runtime_calls.go:73	0x10021862c		1400001d		JMP 29(PC)										
  runtime_calls.go:70	0x100218630		f9007fe1		MOVD R1, 248(RSP)									
  runtime_calls.go:71	0x100218634		b0001200		ADRP 2363392(PC), R0									
  runtime_calls.go:71	0x100218638		9120c000		ADD $2096, R0, R0									
  runtime_calls.go:71	0x10021863c		aa0103e2		MOVD R1, R2										
  runtime_calls.go:71	0x100218640		97f99894		CALL runtime.makeslice(SB)								
  runtime_calls.go:71	0x100218644		f9407fe3		MOVD 248(RSP), R3									
  runtime_calls.go:71	0x100218648		f940efe4		MOVD 472(RSP), R4									
  runtime_calls.go:71	0x10021864c		a90b0c83		STP (R3, R3), 176(R4)									
  runtime_calls.go:71	0x100218650		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:71	0x100218654		b94fd365		MOVWU 4048(R27), R5									
  runtime_calls.go:71	0x100218658		34000085		CBZW R5, 4(PC)										
  runtime_calls.go:71	0x10021865c		f9405485		MOVD 168(R4), R5									
  runtime_calls.go:71	0x100218660		97f9ab04		CALL runtime.gcWriteBarrier2(SB)							
  runtime_calls.go:71	0x100218664		a9001720		STP (R0, R5), (R25)									
  runtime_calls.go:71	0x100218668		f9005480		MOVD R0, 168(R4)									
  runtime_calls.go:76	0x10021866c		aa0403e0		MOVD R4, R0										
  runtime_calls.go:75	0x100218670		aa0303e1		MOVD R3, R1										
  runtime_calls.go:83	0x100218674		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:75	0x100218678		f9405be3		MOVD 176(RSP), R3									
  runtime_calls.go:83	0x10021867c		f94067e4		MOVD 200(RSP), R4									
  host.go:21		0x100218680		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:75	0x100218684		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:83	0x100218688		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:76	0x10021868c		f94083ed		MOVD 256(RSP), R13									
  runtime_calls.go:76	0x100218690		f9404fee		MOVD 152(RSP), R14									
  runtime_calls.go:79	0x100218694		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:78	0x100218698		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:81	0x10021869c		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:75	0x1002186a0		eb03003f		CMP R3, R1										
  runtime_calls.go:75	0x1002186a4		54004008		BHI 512(PC)										
  runtime_calls.go:75	0x1002186a8		aa1f03e5		MOVD ZR, R5										
  runtime_calls.go:75	0x1002186ac		1400013d		JMP 317(PC)										
  runtime_calls.go:96	0x1002186b0		f9402711		MOVD 72(R24), R17									
  runtime_calls.go:97	0x1002186b4		b5000dd1		CBNZ R17, 110(PC)									
  runtime_calls.go:98	0x1002186b8		a945d713		LDP 88(R24), (R19, R21)									
  runtime_calls.go:98	0x1002186bc		b4000d93		CBZ R19, 108(PC)									
  runtime_calls.go:98	0x1002186c0		b9401277		MOVWU 16(R19), R23									
  runtime_calls.go:98	0x1002186c4		d2925999		MOVD $37580, R25									
  runtime_calls.go:98	0x1002186c8		f2aea4d9		MOVK $(29990<<16), R25									
  runtime_calls.go:98	0x1002186cc		6b1902ff		CMPW R25, R23										
  runtime_calls.go:98	0x1002186d0		540006e1		BNE 55(PC)										
  runtime_calls.go:99	0x1002186d4		b0001077		ADRP 2150400(PC), R23									
  runtime_calls.go:99	0x1002186d8		9102e2f7		ADD $184, R23, R23									
  runtime_calls.go:99	0x1002186dc		eb17027f		CMP R23, R19										
  runtime_calls.go:99	0x1002186e0		54000c61		BNE 99(PC)										
  runtime_calls.go:100	0x1002186e4		2a0503e8		MOVW R5, R8										
  runtime_calls.go:100	0x1002186e8		eb03011f		CMP R3, R8										
  runtime_calls.go:100	0x1002186ec		54002528		BHI 297(PC)										
  runtime_calls.go:100	0x1002186f0		a940c301		LDP 8(R24), (R1, R16)									
  runtime_calls.go:100	0x1002186f4		a941cf11		LDP 24(R24), (R17, R19)									
  runtime_calls.go:100	0x1002186f8		a9429b05		LDP 40(R24), (R5, R6)									
  runtime_calls.go:100	0x1002186fc		aa1503e0		MOVD R21, R0										
  runtime_calls.go:100	0x100218700		aa0a03e7		MOVD R10, R7										
  runtime_calls.go:100	0x100218704		aa0303e9		MOVD R3, R9										
  runtime_calls.go:100	0x100218708		aa0203ea		MOVD R2, R10										
  runtime_calls.go:100	0x10021870c		aa0403ec		MOVD R4, R12										
  runtime_calls.go:100	0x100218710		aa1003e2		MOVD R16, R2										
  runtime_calls.go:100	0x100218714		aa1103e3		MOVD R17, R3										
  runtime_calls.go:100	0x100218718		aa1303e4		MOVD R19, R4										
  runtime_calls.go:100	0x10021871c		97ffd53d		CALL github.com/cpunion/wasmvm/internal/engine/state.(*ScalarLeaf).CallSlots(SB)	
  runtime_calls.go:100	0x100218720		b5000380		CBNZ R0, 28(PC)										
  execution.go:209	0x100218724		f940efe0		MOVD 472(RSP), R0									
  execution.go:209	0x100218728		f940b003		MOVD 352(R0), R3									
  execution.go:209	0x10021872c		b40000c3		CBZ R3, 6(PC)										
  type.go:19		0x100218730		88dffc63		LDARW (R3), R3										
  execution.go:209	0x100218734		35000083		CBNZW R3, 4(PC)										
  runtime_calls.go:103	0x100218738		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:103	0x10021873c		aa1f03e2		MOVD ZR, R2										
  runtime_calls.go:103	0x100218740		14000007		JMP 7(PC)										
  execution.go:212	0x100218744		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100218748		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10021874c		d63f0020		CALL (R1)										
  runtime_calls.go:103	0x100218750		aa0103e2		MOVD R1, R2										
  runtime_calls.go:103	0x100218754		aa0003e1		MOVD R0, R1										
  runtime_calls.go:104	0x100218758		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:103	0x10021875c		b40000a1		CBZ R1, 5(PC)										
  runtime_calls.go:104	0x100218760		97ffea40		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:104	0x100218764		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:104	0x100218768		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:104	0x10021876c		d65f03c0		RET											
  runtime_calls.go:106	0x100218770		b94093e1		MOVWU 144(RSP), R1									
  runtime_calls.go:106	0x100218774		91000421		ADD $1, R1, R1										
  runtime_calls.go:106	0x100218778		f94097e2		MOVD 296(RSP), R2									
  runtime_calls.go:106	0x10021877c		b9000841		MOVW R1, 8(R2)										
  runtime_calls.go:107	0x100218780		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:107	0x100218784		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:107	0x100218788		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:107	0x10021878c		d65f03c0		RET											
  runtime_calls.go:101	0x100218790		aa0103e2		MOVD R1, R2										
  runtime_calls.go:101	0x100218794		aa0003e1		MOVD R0, R1										
  runtime_calls.go:101	0x100218798		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:101	0x10021879c		97ffea31		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:101	0x1002187a0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:101	0x1002187a4		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:101	0x1002187a8		d65f03c0		RET											
  runtime_calls.go:98	0x1002187ac		d29ffd4c		MOVD $65514, R12									
  runtime_calls.go:98	0x1002187b0		f2aaf48c		MOVK $(22436<<16), R12									
  runtime_calls.go:98	0x1002187b4		2b0c02ff		CMNW R12, R23										
  runtime_calls.go:98	0x1002187b8		540005a1		BNE 45(PC)										
  runtime_calls.go:108	0x1002187bc		b000106c		ADRP 2150400(PC), R12									
  runtime_calls.go:108	0x1002187c0		9101818c		ADD $96, R12, R12									
  runtime_calls.go:108	0x1002187c4		eb0c027f		CMP R12, R19										
  runtime_calls.go:108	0x1002187c8		54000521		BNE 41(PC)										
  runtime_calls.go:110	0x1002187cc		394062a3		MOVBU 24(R21), R3									
  runtime_calls.go:110	0x1002187d0		36000103		TBZ $0, R3, 8(PC)									
  runtime_calls.go:111	0x1002187d4		b4001dc6		CBZ R6, 238(PC)										
  runtime_calls.go:111	0x1002187d8		b86878e3		MOVWU (R7)(R8<<2), R3									
  runtime_calls.go:111	0x1002187dc		eb0e007f		CMP R14, R3										
  runtime_calls.go:111	0x1002187e0		54001d42		BCS 234(PC)										
  runtime_calls.go:111	0x1002187e4		8b0311a3		ADD R3<<4, R13, R3									
  runtime_calls.go:111	0x1002187e8		f9400061		MOVD (R3), R1										
  runtime_calls.go:111	0x1002187ec		14000002		JMP 2(PC)										
  runtime_calls.go:113	0x1002187f0		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:98	0x1002187f4		f900b3f5		MOVD R21, 352(RSP)									
  runtime_calls.go:113	0x1002187f8		aa1503e0		MOVD R21, R0										
  runtime_calls.go:113	0x1002187fc		97ffd551		CALL github.com/cpunion/wasmvm/internal/engine/state.(*ScalarAccess).Access(SB)		
  runtime_calls.go:114	0x100218800		b50002c1		CBNZ R1, 22(PC)										
  runtime_calls.go:117	0x100218804		f940b3e1		MOVD 352(RSP), R1									
  runtime_calls.go:117	0x100218808		39406021		MOVBU 24(R1), R1									
  runtime_calls.go:117	0x10021880c		37000161		TBNZ $0, R1, 11(PC)									
  runtime_calls.go:118	0x100218810		f94063e1		MOVD 192(RSP), R1									
  runtime_calls.go:118	0x100218814		b4001b81		CBZ R1, 220(PC)										
  runtime_calls.go:118	0x100218818		f9409be1		MOVD 304(RSP), R1									
  runtime_calls.go:118	0x10021881c		b9400021		MOVWU (R1), R1										
  runtime_calls.go:118	0x100218820		f9404fe2		MOVD 152(RSP), R2									
  runtime_calls.go:118	0x100218824		eb02003f		CMP R2, R1										
  runtime_calls.go:118	0x100218828		54001ac2		BCS 214(PC)										
  runtime_calls.go:118	0x10021882c		f94083e2		MOVD 256(RSP), R2									
  runtime_calls.go:118	0x100218830		8b011041		ADD R1<<4, R2, R1									
  runtime_calls.go:118	0x100218834		a9007c20		STP (R0, ZR), (R1)									
  runtime_calls.go:120	0x100218838		b94093e1		MOVWU 144(RSP), R1									
  runtime_calls.go:120	0x10021883c		91000421		ADD $1, R1, R1										
  runtime_calls.go:120	0x100218840		f94097e2		MOVD 296(RSP), R2									
  runtime_calls.go:120	0x100218844		b9000841		MOVW R1, 8(R2)										
  runtime_calls.go:121	0x100218848		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:121	0x10021884c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:121	0x100218850		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:121	0x100218854		d65f03c0		RET											
  runtime_calls.go:115	0x100218858		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:115	0x10021885c		97ffea01		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:115	0x100218860		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:115	0x100218864		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:115	0x100218868		d65f03c0		RET											
  runtime_calls.go:126	0x10021886c		f9415c07		MOVD 696(R0), R7									
  runtime_calls.go:126	0x100218870		f9001e07		MOVD R7, 56(R16)									
  runtime_calls.go:127	0x100218874		91000687		ADD $1, R20, R7										
  runtime_calls.go:127	0x100218878		29015207		STPW (R7, R20), 8(R16)									
  runtime_calls.go:128	0x10021887c		b24003e7		ORR $1, ZR, R7										
  runtime_calls.go:128	0x100218880		39004207		MOVB R7, 16(R16)									
  runtime_calls.go:129	0x100218884		b5000971		CBNZ R17, 75(PC)									
  runtime_calls.go:130	0x100218888		2a0503e3		MOVW R5, R3										
  runtime_calls.go:130	0x10021888c		f9006be3		MOVD R3, 208(RSP)									
  host.go:14		0x100218890		f9401705		MOVD 40(R24), R5									
  host.go:15		0x100218894		f9408807		MOVD 272(R0), R7									
  host.go:14		0x100218898		eb05007f		CMP R5, R3										
  host.go:15		0x10021889c		9a83b0a1		CSEL LT, R5, R3, R1									
  host.go:15		0x1002188a0		eb07003f		CMP R7, R1										
  host.go:14		0x1002188a4		5400006c		BGT 3(PC)										
  host.go:18		0x1002188a8		f9008401		MOVD R1, 264(R0)									
  host.go:18		0x1002188ac		1400001a		JMP 26(PC)										
  host.go:15		0x1002188b0		f9006fe1		MOVD R1, 216(RSP)									
  host.go:16		0x1002188b4		b0001200		ADRP 2363392(PC), R0									
  host.go:16		0x1002188b8		9120c000		ADD $2096, R0, R0									
  host.go:16		0x1002188bc		aa0103e2		MOVD R1, R2										
  host.go:16		0x1002188c0		97f997f4		CALL runtime.makeslice(SB)								
  host.go:16		0x1002188c4		f9406fe3		MOVD 216(RSP), R3									
  host.go:16		0x1002188c8		f940efe4		MOVD 472(RSP), R4									
  host.go:16		0x1002188cc		a9108c83		STP (R3, R3), 264(R4)									
  host.go:16		0x1002188d0		900014fb		ADRP 2736128(PC), R27									
  host.go:16		0x1002188d4		b94fd363		MOVWU 4048(R27), R3									
  host.go:16		0x1002188d8		34000083		CBZW R3, 4(PC)										
  host.go:16		0x1002188dc		f9408083		MOVD 256(R4), R3									
  host.go:16		0x1002188e0		97f9aa64		CALL runtime.gcWriteBarrier2(SB)							
  host.go:16		0x1002188e4		a9000f20		STP (R0, R3), (R25)									
  host.go:16		0x1002188e8		f9008080		MOVD R0, 256(R4)									
  host.go:20		0x1002188ec		aa0403e0		MOVD R4, R0										
  runtime_calls.go:134	0x1002188f0		f9409be2		MOVD 304(RSP), R2									
  host.go:20		0x1002188f4		f9406be3		MOVD 208(RSP), R3									
  runtime_calls.go:134	0x1002188f8		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:132	0x1002188fc		f94057e6		MOVD 168(RSP), R6									
  host.go:21		0x100218900		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:132	0x100218904		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:134	0x100218908		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:132	0x10021890c		f94077f6		MOVD 232(RSP), R22									
  host.go:21		0x100218910		f940bbf8		MOVD 368(RSP), R24									
  host.go:20		0x100218914		f9408805		MOVD 272(R0), R5									
  host.go:20		0x100218918		eb05007f		CMP R5, R3										
  host.go:20		0x10021891c		54001308		BHI 152(PC)										
  host.go:20		0x100218920		f9408007		MOVD 256(R0), R7									
  host.go:21		0x100218924		a917a7f8		STP (R24, R9), 376(RSP)									
  host.go:21		0x100218928		a9188fe7		STP (R7, R3), 392(RSP)									
  host.go:21		0x10021892c		f900cfe5		MOVD R5, 408(RSP)									
  host.go:22		0x100218930		91036001		ADD $216, R0, R1									
  host.go:21		0x100218934		900014fb		ADRP 2736128(PC), R27									
  host.go:21		0x100218938		b94fd365		MOVWU 4048(R27), R5									
  host.go:21		0x10021893c		34000285		CBZW R5, 20(PC)										
  host.go:20		0x100218940		f900a3e7		MOVD R7, 320(RSP)									
  host.go:22		0x100218944		f900afe1		MOVD R1, 344(RSP)									
  host.go:22		0x100218948		f9408c03		MOVD 280(R0), R3									
  host.go:21		0x10021894c		97f9aa49		CALL runtime.gcWriteBarrier2(SB)							
  host.go:22		0x100218950		a9000f21		STP (R1, R3), (R25)									
  host.go:21		0x100218954		d0001220		ADRP 2383872(PC), R0									
  host.go:21		0x100218958		913ec000		ADD $4016, R0, R0									
  host.go:21		0x10021895c		9105e3e2		ADD $376, RSP, R2									
  host.go:21		0x100218960		97f81b54		CALL runtime.wbMove(SB)									
  host.go:21		0x100218964		f940efe0		MOVD 472(RSP), R0									
  host.go:22		0x100218968		f940afe1		MOVD 344(RSP), R1									
  runtime_calls.go:134	0x10021896c		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:131	0x100218970		f9406be3		MOVD 208(RSP), R3									
  runtime_calls.go:134	0x100218974		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:132	0x100218978		f94057e6		MOVD 168(RSP), R6									
  runtime_calls.go:132	0x10021897c		f940a3e7		MOVD 320(RSP), R7									
  runtime_calls.go:132	0x100218980		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:134	0x100218984		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:132	0x100218988		f94077f6		MOVD 232(RSP), R22									
  host.go:21		0x10021898c		9105e3fb		ADD $376, RSP, R27									
  host.go:21		0x100218990		ad400760		FLDPQ (R27), (F0, F1)									
  host.go:21		0x100218994		f940cfe5		MOVD 408(RSP), R5									
  host.go:21		0x100218998		9103601b		ADD $216, R0, R27									
  host.go:21		0x10021899c		ad000760		FSTPQ (F0, F1), (R27)									
  host.go:21		0x1002189a0		f9007c05		MOVD R5, 248(R0)									
  host.go:22		0x1002189a4		f9008c01		MOVD R1, 280(R0)									
  runtime_calls.go:131	0x1002189a8		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:131	0x1002189ac		1400005a		JMP 90(PC)										
  runtime_calls.go:138	0x1002189b0		aa1803e1		MOVD R24, R1										
  runtime_calls.go:138	0x1002189b4		aa0b03e3		MOVD R11, R3										
  runtime_calls.go:138	0x1002189b8		97ffe8a6		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push(SB)		
  runtime_calls.go:138	0x1002189bc		b50001c0		CBNZ R0, 14(PC)										
  runtime_calls.go:141	0x1002189c0		f940efe1		MOVD 472(RSP), R1									
  runtime_calls.go:141	0x1002189c4		a9440c22		LDP 64(R1), (R2, R3)									
  runtime_calls.go:141	0x1002189c8		d1000464		SUB $1, R3, R4										
  runtime_calls.go:141	0x1002189cc		eb04007f		CMP R4, R3										
  runtime_calls.go:141	0x1002189d0		54000969		BLS 75(PC)										
  runtime_calls.go:141	0x1002189d4		8b041842		ADD R4<<6, R2, R2									
  runtime_calls.go:141	0x1002189d8		f9400c42		MOVD 24(R2), R2										
  runtime_calls.go:142	0x1002189dc		aa1f03e3		MOVD ZR, R3										
  runtime_calls.go:142	0x1002189e0		b94097e4		MOVWU 148(RSP), R4									
  runtime_calls.go:142	0x1002189e4		f94057e5		MOVD 168(RSP), R5									
  runtime_calls.go:142	0x1002189e8		f9408be6		MOVD 272(RSP), R6									
  runtime_calls.go:142	0x1002189ec		f94077e7		MOVD 232(RSP), R7									
  runtime_calls.go:142	0x1002189f0		1400002c		JMP 44(PC)										
  runtime_calls.go:139	0x1002189f4		aa0103e2		MOVD R1, R2										
  runtime_calls.go:139	0x1002189f8		aa0003e1		MOVD R0, R1										
  runtime_calls.go:139	0x1002189fc		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:139	0x100218a00		97ffe998		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:139	0x100218a04		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:139	0x100218a08		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:139	0x100218a0c		d65f03c0		RET											
  runtime_calls.go:61	0x100218a10		aa0c03e2		MOVD R12, R2										
  runtime_calls.go:61	0x100218a14		97ffe993		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:61	0x100218a18		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:61	0x100218a1c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:61	0x100218a20		d65f03c0		RET											
  runtime_calls.go:52	0x100218a24		f9408fe4		MOVD 280(RSP), R4									
  runtime_calls.go:52	0x100218a28		b9400482		MOVWU 4(R4), R2										
  runtime_calls.go:52	0x100218a2c		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:52	0x100218a30		f94093e1		MOVD 288(RSP), R1									
  runtime_calls.go:52	0x100218a34		d28000a3		MOVD $5, R3										
  runtime_calls.go:52	0x100218a38		97fffafe		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:52	0x100218a3c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:52	0x100218a40		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:52	0x100218a44		d65f03c0		RET											
  runtime_calls.go:49	0x100218a48		f000137b		ADRP 2551808(PC), R27									
  runtime_calls.go:49	0x100218a4c		9103037b		ADD $192, R27, R27									
  runtime_calls.go:49	0x100218a50		a9400b61		LDP (R27), (R1, R2)									
  runtime_calls.go:49	0x100218a54		97ffe983		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:49	0x100218a58		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:49	0x100218a5c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:49	0x100218a60		d65f03c0		RET											
  runtime_calls.go:44	0x100218a64		b94006a2		MOVWU 4(R21), R2									
  runtime_calls.go:44	0x100218a68		b27e03e3		ORR $4, ZR, R3										
  runtime_calls.go:44	0x100218a6c		97fffaf1		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:44	0x100218a70		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:44	0x100218a74		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:44	0x100218a78		d65f03c0		RET											
  runtime_calls.go:40	0x100218a7c		b94006a2		MOVWU 4(R21), R2									
  runtime_calls.go:40	0x100218a80		b24007e3		ORR $3, ZR, R3										
  runtime_calls.go:40	0x100218a84		97fffaeb		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:40	0x100218a88		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:40	0x100218a8c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:40	0x100218a90		d65f03c0		RET											
  runtime_calls.go:143	0x100218a94		8b0b1129		ADD R11<<4, R9, R9									
  runtime_calls.go:143	0x100218a98		a9003128		STP (R8, R12), (R9)									
  runtime_calls.go:142	0x100218a9c		91000463		ADD $1, R3, R3										
  runtime_calls.go:142	0x100218aa0		6b04007f		CMPW R4, R3										
  runtime_calls.go:142	0x100218aa4		540001e2		BCS 15(PC)										
  runtime_calls.go:143	0x100218aa8		2a0303e8		MOVW R3, R8										
  runtime_calls.go:143	0x100218aac		a947a829		LDP 120(R1), (R9, R10)									
  runtime_calls.go:143	0x100218ab0		8b08004b		ADD R8, R2, R11										
  runtime_calls.go:143	0x100218ab4		eb05011f		CMP R5, R8										
  runtime_calls.go:143	0x100218ab8		54000202		BCS 16(PC)										
  runtime_calls.go:143	0x100218abc		b86878c8		MOVWU (R6)(R8<<2), R8									
  runtime_calls.go:143	0x100218ac0		8b070108		ADD R7, R8, R8										
  runtime_calls.go:143	0x100218ac4		eb08015f		CMP R8, R10										
  runtime_calls.go:143	0x100218ac8		54000169		BLS 11(PC)										
  runtime_calls.go:143	0x100218acc		8b081128		ADD R8<<4, R9, R8									
  runtime_calls.go:143	0x100218ad0		a9403108		LDP (R8), (R8, R12)									
  runtime_calls.go:143	0x100218ad4		eb0b015f		CMP R11, R10										
  runtime_calls.go:143	0x100218ad8		54fffde8		BHI -17(PC)										
  runtime_calls.go:143	0x100218adc		14000005		JMP 5(PC)										
  runtime_calls.go:145	0x100218ae0		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:145	0x100218ae4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:145	0x100218ae8		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:145	0x100218aec		d65f03c0		RET											
  runtime_calls.go:143	0x100218af0		97f9aa94		CALL runtime.panicBounds(SB)								
  runtime_calls.go:143	0x100218af4		97f9aa93		CALL runtime.panicBounds(SB)								
  runtime_calls.go:143	0x100218af8		97f9aa92		CALL runtime.panicBounds(SB)								
  runtime_calls.go:141	0x100218afc		97f9aa91		CALL runtime.panicBounds(SB)								
  runtime_calls.go:132	0x100218b00		8b0110e8		ADD R1<<4, R7, R8									
  runtime_calls.go:132	0x100218b04		8b0910a5		ADD R9<<4, R5, R5									
  runtime_calls.go:132	0x100218b08		a94024a5		LDP (R5), (R5, R9)									
  runtime_calls.go:132	0x100218b0c		a9002505		STP (R5, R9), (R8)									
  runtime_calls.go:131	0x100218b10		91000421		ADD $1, R1, R1										
  runtime_calls.go:131	0x100218b14		eb03003f		CMP R3, R1										
  runtime_calls.go:131	0x100218b18		5400012a		BGE 9(PC)										
  runtime_calls.go:132	0x100218b1c		a947a005		LDP 120(R0), (R5, R8)									
  runtime_calls.go:132	0x100218b20		eb06003f		CMP R6, R1										
  runtime_calls.go:132	0x100218b24		540002a2		BCS 21(PC)										
  runtime_calls.go:132	0x100218b28		b8617949		MOVWU (R10)(R1<<2), R9									
  runtime_calls.go:132	0x100218b2c		8b160129		ADD R22, R9, R9										
  runtime_calls.go:132	0x100218b30		eb09011f		CMP R9, R8										
  runtime_calls.go:132	0x100218b34		54fffe68		BHI -13(PC)										
  runtime_calls.go:132	0x100218b38		1400000f		JMP 15(PC)										
  runtime_calls.go:134	0x100218b3c		a912900b		STP (R11, R4), 296(R0)									
  runtime_calls.go:134	0x100218b40		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:134	0x100218b44		b94fd361		MOVWU 4048(R27), R1									
  runtime_calls.go:134	0x100218b48		34000081		CBZW R1, 4(PC)										
  runtime_calls.go:134	0x100218b4c		f9409001		MOVD 288(R0), R1									
  runtime_calls.go:134	0x100218b50		97f9a9c8		CALL runtime.gcWriteBarrier2(SB)							
  runtime_calls.go:134	0x100218b54		a9000722		STP (R2, R1), (R25)									
  runtime_calls.go:134	0x100218b58		f9009002		MOVD R2, 288(R0)									
  runtime_calls.go:135	0x100218b5c		b27f03e1		ORR $2, ZR, R1										
  runtime_calls.go:135	0x100218b60		3904e001		MOVB R1, 312(R0)									
  runtime_calls.go:136	0x100218b64		aa0103e0		MOVD R1, R0										
  runtime_calls.go:136	0x100218b68		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:136	0x100218b6c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:136	0x100218b70		d65f03c0		RET											
  runtime_calls.go:132	0x100218b74		97f9aa73		CALL runtime.panicBounds(SB)								
  runtime_calls.go:132	0x100218b78		97f9aa72		CALL runtime.panicBounds(SB)								
  host.go:20		0x100218b7c		97f9aa71		CALL runtime.panicBounds(SB)								
  runtime_calls.go:118	0x100218b80		97f9aa70		CALL runtime.panicBounds(SB)								
  runtime_calls.go:118	0x100218b84		97f9aa6f		CALL runtime.panicBounds(SB)								
  runtime_calls.go:111	0x100218b88		97f9aa6e		CALL runtime.panicBounds(SB)								
  runtime_calls.go:111	0x100218b8c		97f9aa6d		CALL runtime.panicBounds(SB)								
  runtime_calls.go:100	0x100218b90		97f9aa6c		CALL runtime.panicBounds(SB)								
  runtime_calls.go:76	0x100218b94		8b0510e7		ADD R5<<4, R7, R7									
  runtime_calls.go:76	0x100218b98		a90030e6		STP (R6, R12), (R7)									
  runtime_calls.go:75	0x100218b9c		910004a5		ADD $1, R5, R5										
  runtime_calls.go:75	0x100218ba0		eb0100bf		CMP R1, R5										
  runtime_calls.go:75	0x100218ba4		5400014a		BGE 10(PC)										
  runtime_calls.go:75	0x100218ba8		b8657946		MOVWU (R10)(R5<<2), R6									
  runtime_calls.go:76	0x100218bac		eb0e00df		CMP R14, R6										
  runtime_calls.go:76	0x100218bb0		54001782		BCS 188(PC)										
  runtime_calls.go:76	0x100218bb4		a94aa007		LDP 168(R0), (R7, R8)									
  runtime_calls.go:76	0x100218bb8		8b0611a6		ADD R6<<4, R13, R6									
  runtime_calls.go:76	0x100218bbc		a94030c6		LDP (R6), (R6, R12)									
  runtime_calls.go:76	0x100218bc0		eb0800bf		CMP R8, R5										
  runtime_calls.go:76	0x100218bc4		54fffe83		BCC -12(PC)										
  runtime_calls.go:76	0x100218bc8		140000b5		JMP 181(PC)										
  runtime_calls.go:78	0x100218bcc		f9404405		MOVD 136(R0), R5									
  runtime_calls.go:78	0x100218bd0		eb1600bf		CMP R22, R5										
  runtime_calls.go:78	0x100218bd4		54001603		BCC 176(PC)										
  runtime_calls.go:78	0x100218bd8		f9004016		MOVD R22, 128(R0)									
  runtime_calls.go:79	0x100218bdc		a9441805		LDP 64(R0), (R5, R6)									
  runtime_calls.go:79	0x100218be0		eb1300df		CMP R19, R6										
  runtime_calls.go:79	0x100218be4		54001549		BLS 170(PC)										
  runtime_calls.go:79	0x100218be8		8b1318a1		ADD R19<<6, R5, R1									
  runtime_calls.go:79	0x100218bec		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:79	0x100218bf0		b94fd365		MOVWU 4048(R27), R5									
  runtime_calls.go:79	0x100218bf4		340001c5		CBZW R5, 14(PC)										
  runtime_calls.go:79	0x100218bf8		f900abe1		MOVD R1, 336(RSP)									
  runtime_calls.go:79	0x100218bfc		f0001280		ADRP 2437120(PC), R0									
  runtime_calls.go:79	0x100218c00		91104000		ADD $1040, R0, R0									
  runtime_calls.go:79	0x100218c04		97f81a9f		CALL runtime.wbZero(SB)									
  runtime_calls.go:80	0x100218c08		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:79	0x100218c0c		f940abe1		MOVD 336(RSP), R1									
  runtime_calls.go:83	0x100218c10		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:83	0x100218c14		f94067e4		MOVD 200(RSP), R4									
  host.go:21		0x100218c18		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:83	0x100218c1c		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:80	0x100218c20		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:91	0x100218c24		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:81	0x100218c28		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:79	0x100218c2c		a9007c3f		STP (ZR, ZR), (R1)									
  runtime_calls.go:79	0x100218c30		a9017c3f		STP (ZR, ZR), 16(R1)									
  runtime_calls.go:79	0x100218c34		a9027c3f		STP (ZR, ZR), 32(R1)									
  runtime_calls.go:79	0x100218c38		a9037c3f		STP (ZR, ZR), 48(R1)									
  runtime_calls.go:80	0x100218c3c		f9402805		MOVD 80(R0), R5										
  runtime_calls.go:80	0x100218c40		eb1300bf		CMP R19, R5										
  runtime_calls.go:80	0x100218c44		54001203		BCC 144(PC)										
  runtime_calls.go:80	0x100218c48		f9002413		MOVD R19, 72(R0)									
  runtime_calls.go:81	0x100218c4c		f9402705		MOVD 72(R24), R5									
  runtime_calls.go:81	0x100218c50		b5000c85		CBNZ R5, 100(PC)									
  runtime_calls.go:82	0x100218c54		f9405803		MOVD 176(R0), R3									
  runtime_calls.go:82	0x100218c58		f9007be3		MOVD R3, 240(RSP)									
  host.go:14		0x100218c5c		f9401705		MOVD 40(R24), R5									
  host.go:15		0x100218c60		f9408806		MOVD 272(R0), R6									
  host.go:14		0x100218c64		eb0300bf		CMP R3, R5										
  host.go:15		0x100218c68		9a83c0a1		CSEL GT, R5, R3, R1									
  host.go:15		0x100218c6c		eb06003f		CMP R6, R1										
  host.go:14		0x100218c70		5400006c		BGT 3(PC)										
  host.go:18		0x100218c74		f9008401		MOVD R1, 264(R0)									
  host.go:18		0x100218c78		14000017		JMP 23(PC)										
  host.go:15		0x100218c7c		f90073e1		MOVD R1, 224(RSP)									
  host.go:16		0x100218c80		b0001200		ADRP 2363392(PC), R0									
  host.go:16		0x100218c84		9120c000		ADD $2096, R0, R0									
  host.go:16		0x100218c88		aa0103e2		MOVD R1, R2										
  host.go:16		0x100218c8c		97f99701		CALL runtime.makeslice(SB)								
  host.go:16		0x100218c90		f94073e3		MOVD 224(RSP), R3									
  host.go:16		0x100218c94		f940efe4		MOVD 472(RSP), R4									
  host.go:16		0x100218c98		a9108c83		STP (R3, R3), 264(R4)									
  host.go:16		0x100218c9c		900014fb		ADRP 2736128(PC), R27									
  host.go:16		0x100218ca0		b94fd363		MOVWU 4048(R27), R3									
  host.go:16		0x100218ca4		34000083		CBZW R3, 4(PC)										
  host.go:16		0x100218ca8		f9408083		MOVD 256(R4), R3									
  host.go:16		0x100218cac		97f9a971		CALL runtime.gcWriteBarrier2(SB)							
  host.go:16		0x100218cb0		a9000f20		STP (R0, R3), (R25)									
  host.go:16		0x100218cb4		f9008080		MOVD R0, 256(R4)									
  host.go:20		0x100218cb8		aa0403e0		MOVD R4, R0										
  runtime_calls.go:83	0x100218cbc		f9409be2		MOVD 304(RSP), R2									
  host.go:20		0x100218cc0		f9407be3		MOVD 240(RSP), R3									
  runtime_calls.go:83	0x100218cc4		f94067e4		MOVD 200(RSP), R4									
  host.go:21		0x100218cc8		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:83	0x100218ccc		f94063eb		MOVD 192(RSP), R11									
  host.go:21		0x100218cd0		f940bbf8		MOVD 368(RSP), R24									
  host.go:20		0x100218cd4		f9408805		MOVD 272(R0), R5									
  host.go:20		0x100218cd8		eb0300bf		CMP R3, R5										
  host.go:20		0x100218cdc		54000d23		BCC 105(PC)										
  host.go:20		0x100218ce0		f9408006		MOVD 256(R0), R6									
  host.go:21		0x100218ce4		a91a27f8		STP (R24, R9), 416(RSP)									
  host.go:21		0x100218ce8		a91b0fe6		STP (R6, R3), 432(RSP)									
  host.go:21		0x100218cec		f900e3e5		MOVD R5, 448(RSP)									
  host.go:22		0x100218cf0		91036001		ADD $216, R0, R1									
  host.go:21		0x100218cf4		900014fb		ADRP 2736128(PC), R27									
  host.go:21		0x100218cf8		b94fd365		MOVWU 4048(R27), R5									
  host.go:21		0x100218cfc		34000225		CBZW R5, 17(PC)										
  host.go:22		0x100218d00		f900afe1		MOVD R1, 344(RSP)									
  host.go:20		0x100218d04		f900a7e6		MOVD R6, 328(RSP)									
  host.go:22		0x100218d08		f9408c03		MOVD 280(R0), R3									
  host.go:21		0x100218d0c		97f9a959		CALL runtime.gcWriteBarrier2(SB)							
  host.go:22		0x100218d10		a9000f21		STP (R1, R3), (R25)									
  host.go:21		0x100218d14		d0001220		ADRP 2383872(PC), R0									
  host.go:21		0x100218d18		913ec000		ADD $4016, R0, R0									
  host.go:21		0x100218d1c		910683e2		ADD $416, RSP, R2									
  host.go:21		0x100218d20		97f81a64		CALL runtime.wbMove(SB)									
  host.go:21		0x100218d24		f940efe0		MOVD 472(RSP), R0									
  host.go:22		0x100218d28		f940afe1		MOVD 344(RSP), R1									
  runtime_calls.go:83	0x100218d2c		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:82	0x100218d30		f9407be3		MOVD 240(RSP), R3									
  runtime_calls.go:83	0x100218d34		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:82	0x100218d38		f940a7e6		MOVD 328(RSP), R6									
  runtime_calls.go:83	0x100218d3c		f94063eb		MOVD 192(RSP), R11									
  host.go:21		0x100218d40		ad4d07e0		FLDPQ 416(RSP), (F0, F1)								
  host.go:21		0x100218d44		f940e3e5		MOVD 448(RSP), R5									
  host.go:21		0x100218d48		9103601b		ADD $216, R0, R27									
  host.go:21		0x100218d4c		ad000760		FSTPQ (F0, F1), (R27)									
  host.go:21		0x100218d50		f9007c05		MOVD R5, 248(R0)									
  host.go:22		0x100218d54		f9008c01		MOVD R1, 280(R0)									
  runtime_calls.go:82	0x100218d58		a94a9401		LDP 168(R0), (R1, R5)									
  runtime_calls.go:82	0x100218d5c		eb05007f		CMP R5, R3										
  runtime_calls.go:82	0x100218d60		9a83c0a3		CSEL GT, R5, R3, R3									
  runtime_calls.go:82	0x100218d64		eb0100df		CMP R1, R6										
  runtime_calls.go:82	0x100218d68		54000100		BEQ 8(PC)										
  runtime_calls.go:82	0x100218d6c		d37cec62		LSL $4, R3, R2										
  runtime_calls.go:82	0x100218d70		aa0603e0		MOVD R6, R0										
  runtime_calls.go:82	0x100218d74		97f9aa77		CALL runtime.memmove(SB)								
  runtime_calls.go:83	0x100218d78		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:83	0x100218d7c		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:83	0x100218d80		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:83	0x100218d84		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:83	0x100218d88		a912900b		STP (R11, R4), 296(R0)									
  runtime_calls.go:83	0x100218d8c		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:83	0x100218d90		b94fd363		MOVWU 4048(R27), R3									
  runtime_calls.go:83	0x100218d94		34000083		CBZW R3, 4(PC)										
  runtime_calls.go:83	0x100218d98		f9409003		MOVD 288(R0), R3									
  runtime_calls.go:83	0x100218d9c		97f9a935		CALL runtime.gcWriteBarrier2(SB)							
  runtime_calls.go:83	0x100218da0		a9000f22		STP (R2, R3), (R25)									
  runtime_calls.go:83	0x100218da4		f9009002		MOVD R2, 288(R0)									
  runtime_calls.go:83	0x100218da8		b27f03e2		ORR $2, ZR, R2										
  runtime_calls.go:83	0x100218dac		3904e002		MOVB R2, 312(R0)									
  runtime_calls.go:84	0x100218db0		a94a9003		LDP 168(R0), (R3, R4)									
  runtime_calls.go:84	0x100218db4		b40000c4		CBZ R4, 6(PC)										
  runtime_calls.go:84	0x100218db8		d37cec81		LSL $4, R4, R1										
  runtime_calls.go:84	0x100218dbc		aa0303e0		MOVD R3, R0										
  runtime_calls.go:84	0x100218dc0		97f9a9f8		CALL runtime.memclrNoHeapPointers(SB)							
  runtime_calls.go:85	0x100218dc4		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:85	0x100218dc8		b27f03e2		ORR $2, ZR, R2										
  runtime_calls.go:85	0x100218dcc		f900581f		MOVD ZR, 176(R0)									
  runtime_calls.go:86	0x100218dd0		aa0203e0		MOVD R2, R0										
  runtime_calls.go:86	0x100218dd4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:86	0x100218dd8		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:86	0x100218ddc		d65f03c0		RET											
  runtime_calls.go:88	0x100218de0		aa1803e1		MOVD R24, R1										
  runtime_calls.go:88	0x100218de4		aa0b03e3		MOVD R11, R3										
  runtime_calls.go:88	0x100218de8		97ffe79a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push(SB)		
  runtime_calls.go:88	0x100218dec		b50003a0		CBNZ R0, 29(PC)										
  runtime_calls.go:91	0x100218df0		f940efe3		MOVD 472(RSP), R3									
  runtime_calls.go:91	0x100218df4		a9479464		LDP 120(R3), (R4, R5)									
  runtime_calls.go:91	0x100218df8		f94077e6		MOVD 232(RSP), R6									
  runtime_calls.go:91	0x100218dfc		eb0600bf		CMP R6, R5										
  runtime_calls.go:91	0x100218e00		540003e3		BCC 31(PC)										
  runtime_calls.go:91	0x100218e04		f9404467		MOVD 136(R3), R7									
  runtime_calls.go:91	0x100218e08		cb0600a5		SUB R6, R5, R5										
  runtime_calls.go:91	0x100218e0c		cb0700c7		SUB R7, R6, R7										
  runtime_calls.go:91	0x100218e10		8a87fcc6		AND R7->63, R6, R6									
  runtime_calls.go:91	0x100218e14		8b061080		ADD R6<<4, R4, R0									
  runtime_calls.go:91	0x100218e18		a94a9061		LDP 168(R3), (R1, R4)									
  runtime_calls.go:91	0x100218e1c		eb05009f		CMP R5, R4										
  runtime_calls.go:91	0x100218e20		9a85b084		CSEL LT, R4, R5, R4									
  runtime_calls.go:91	0x100218e24		eb00003f		CMP R0, R1										
  runtime_calls.go:91	0x100218e28		54000080		BEQ 4(PC)										
  runtime_calls.go:91	0x100218e2c		d37cec82		LSL $4, R4, R2										
  runtime_calls.go:91	0x100218e30		97f9aa48		CALL runtime.memmove(SB)								
  runtime_calls.go:92	0x100218e34		f940efe3		MOVD 472(RSP), R3									
  runtime_calls.go:92	0x100218e38		a94a8860		LDP 168(R3), (R0, R2)									
  runtime_calls.go:92	0x100218e3c		b4000082		CBZ R2, 4(PC)										
  runtime_calls.go:92	0x100218e40		d37cec41		LSL $4, R2, R1										
  runtime_calls.go:92	0x100218e44		97f9a9d7		CALL runtime.memclrNoHeapPointers(SB)							
  runtime_calls.go:93	0x100218e48		f940efe3		MOVD 472(RSP), R3									
  runtime_calls.go:93	0x100218e4c		f900587f		MOVD ZR, 176(R3)									
  runtime_calls.go:94	0x100218e50		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:94	0x100218e54		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:94	0x100218e58		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:94	0x100218e5c		d65f03c0		RET											
  runtime_calls.go:89	0x100218e60		aa0103e2		MOVD R1, R2										
  runtime_calls.go:89	0x100218e64		aa0003e1		MOVD R0, R1										
  runtime_calls.go:89	0x100218e68		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:89	0x100218e6c		97ffe87d		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:89	0x100218e70		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:89	0x100218e74		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:89	0x100218e78		d65f03c0		RET											
  runtime_calls.go:91	0x100218e7c		97f9a9b1		CALL runtime.panicBounds(SB)								
  host.go:20		0x100218e80		97f9a9b0		CALL runtime.panicBounds(SB)								
  runtime_calls.go:80	0x100218e84		aa1303e0		MOVD R19, R0										
  runtime_calls.go:80	0x100218e88		97f9a9ae		CALL runtime.panicBounds(SB)								
  runtime_calls.go:79	0x100218e8c		aa1303e0		MOVD R19, R0										
  runtime_calls.go:79	0x100218e90		97f9a9ac		CALL runtime.panicBounds(SB)								
  runtime_calls.go:78	0x100218e94		aa1603e0		MOVD R22, R0										
  runtime_calls.go:78	0x100218e98		97f9a9aa		CALL runtime.panicBounds(SB)								
  runtime_calls.go:76	0x100218e9c		97f9a9a9		CALL runtime.panicBounds(SB)								
  runtime_calls.go:76	0x100218ea0		97f9a9a8		CALL runtime.panicBounds(SB)								
  runtime_calls.go:75	0x100218ea4		97f9a9a7		CALL runtime.panicBounds(SB)								
  runtime_calls.go:58	0x100218ea8		aa1503e0		MOVD R21, R0										
  runtime_calls.go:58	0x100218eac		aa1903e1		MOVD R25, R1										
  runtime_calls.go:58	0x100218eb0		97f9a9a4		CALL runtime.panicBounds(SB)								
  runtime_calls.go:58	0x100218eb4		aa1903e0		MOVD R25, R0										
  runtime_calls.go:58	0x100218eb8		aa1703e1		MOVD R23, R1										
  runtime_calls.go:58	0x100218ebc		97f9a9a1		CALL runtime.panicBounds(SB)								
  runtime_calls.go:51	0x100218ec0		97f9a9a0		CALL runtime.panicBounds(SB)								
  runtime_calls.go:38	0x100218ec4		97f9a99f		CALL runtime.panicBounds(SB)								
  runtime_calls.go:38	0x100218ec8		97f9a99e		CALL runtime.panicBounds(SB)								
  runtime_calls.go:37	0x100218ecc		aa1803e0		MOVD R24, R0										
  runtime_calls.go:37	0x100218ed0		97f9a99c		CALL runtime.panicBounds(SB)								
  runtime_calls.go:31	0x100218ed4		97f9a99b		CALL runtime.panicBounds(SB)								
  runtime_calls.go:31	0x100218ed8		97f9a99a		CALL runtime.panicBounds(SB)								
  runtime_calls.go:28	0x100218edc		97f9a999		CALL runtime.panicBounds(SB)								
  runtime_calls.go:25	0x100218ee0		97f9a998		CALL runtime.panicBounds(SB)								
  runtime_calls.go:25	0x100218ee4		97f9a997		CALL runtime.panicBounds(SB)								
  source_image.go:115	0x100218ee8		aa1903e0		MOVD R25, R0										
  source_image.go:115	0x100218eec		aa1803e1		MOVD R24, R1										
  source_image.go:115	0x100218ef0		97f9a994		CALL runtime.panicBounds(SB)								
  source_image.go:112	0x100218ef4		aa1903e0		MOVD R25, R0										
  source_image.go:112	0x100218ef8		aa1803e1		MOVD R24, R1										
  source_image.go:112	0x100218efc		97f9a991		CALL runtime.panicBounds(SB)								
  runtime_calls.go:19	0x100218f00		aa1603e0		MOVD R22, R0										
  runtime_calls.go:19	0x100218f04		aa1903e1		MOVD R25, R1										
  runtime_calls.go:19	0x100218f08		97f9a98e		CALL runtime.panicBounds(SB)								
  runtime_calls.go:19	0x100218f0c		aa1903e0		MOVD R25, R0										
  runtime_calls.go:19	0x100218f10		aa1803e1		MOVD R24, R1										
  runtime_calls.go:19	0x100218f14		97f9a98b		CALL runtime.panicBounds(SB)								
  runtime_calls.go:17	0x100218f18		aa1703e0		MOVD R23, R0										
  runtime_calls.go:17	0x100218f1c		aa1603e1		MOVD R22, R1										
  runtime_calls.go:17	0x100218f20		97f9a988		CALL runtime.panicBounds(SB)								
  runtime_calls.go:13	0x100218f24		aa1303e0		MOVD R19, R0										
  runtime_calls.go:13	0x100218f28		aa1103e1		MOVD R17, R1										
  runtime_calls.go:13	0x100218f2c		97f9a985		CALL runtime.panicBounds(SB)								
  runtime_calls.go:13	0x100218f30		d503201f		NOOP											
  runtime_calls.go:11	0x100218f34		f90007e0		MOVD R0, 8(RSP)										
  runtime_calls.go:11	0x100218f38		aa1e03e3		MOVD R30, R3										
  runtime_calls.go:11	0x100218f3c		97f9a0e9		CALL runtime.morestack_noctxt.abi0(SB)							
  runtime_calls.go:11	0x100218f40		f94007e0		MOVD 8(RSP), R0										
  runtime_calls.go:11	0x100218f44		17fffc9b		JMP github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB)		
  runtime_calls.go:11	0x100218f48		00000000		?											
  runtime_calls.go:11	0x100218f4c		00000000		?											
