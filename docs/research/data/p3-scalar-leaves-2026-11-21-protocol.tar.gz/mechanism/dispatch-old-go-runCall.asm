TEXT github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB) /Users/lijie/source/goplus/wasmvm-source-cleanup/internal/engine/execute/runtime_calls.go
  runtime_calls.go:11	0x1002181b0		f9400b90		MOVD 16(R28), R16									
  runtime_calls.go:11	0x1002181b4		d10543f1		SUB $336, RSP, R17									
  runtime_calls.go:11	0x1002181b8		eb10023f		CMP R16, R17										
  runtime_calls.go:11	0x1002181bc		54006ba9		BLS 861(PC)										
  runtime_calls.go:11	0x1002181c0		d10743f4		SUB $464, RSP, R20									
  runtime_calls.go:11	0x1002181c4		a93ffa9d		STP (R29, R30), -8(R20)									
  runtime_calls.go:11	0x1002181c8		9100029f		MOVD R20, RSP										
  runtime_calls.go:11	0x1002181cc		d10023fd		SUB $8, RSP, R29									
  runtime_calls.go:12	0x1002181d0		a9444410		LDP 64(R0), (R16, R17)									
  runtime_calls.go:12	0x1002181d4		d1000633		SUB $1, R17, R19									
  runtime_calls.go:13	0x1002181d8		eb13023f		CMP R19, R17										
  runtime_calls.go:13	0x1002181dc		54006a29		BLS 849(PC)										
  runtime_calls.go:13	0x1002181e0		8b131a10		ADD R19<<6, R16, R16									
  runtime_calls.go:14	0x1002181e4		f9400201		MOVD (R16), R1										
  runtime_calls.go:15	0x1002181e8		f9402431		MOVD 72(R1), R17									
  runtime_calls.go:16	0x1002181ec		b9400a14		MOVWU 8(R16), R20									
  runtime_calls.go:17	0x1002181f0		a94b5a35		LDP 176(R17), (R21, R22)								
  runtime_calls.go:17	0x1002181f4		aa1403f7		MOVD R20, R23										
  runtime_calls.go:17	0x1002181f8		eb1602ff		CMP R22, R23										
  runtime_calls.go:17	0x1002181fc		540068c2		BCS 838(PC)										
  runtime_calls.go:18	0x100218200		f9400e16		MOVD 24(R16), R22									
  runtime_calls.go:19	0x100218204		f9404418		MOVD 136(R0), R24									
  runtime_calls.go:19	0x100218208		f9404e2e		MOVD 152(R17), R14									
  runtime_calls.go:19	0x10021820c		8b0e02d9		ADD R14, R22, R25									
  runtime_calls.go:17	0x100218210		8b1716b5		ADD R23<<5, R21, R21									
  runtime_calls.go:19	0x100218214		eb19031f		CMP R25, R24										
  runtime_calls.go:19	0x100218218		54006783		BCC 828(PC)										
  runtime_calls.go:19	0x10021821c		eb1902df		CMP R25, R22										
  runtime_calls.go:19	0x100218220		540066e8		BHI 823(PC)										
  runtime_calls.go:19	0x100218224		f9403c17		MOVD 120(R0), R23									
  runtime_calls.go:19	0x100218228		cb1802d9		SUB R24, R22, R25									
  runtime_calls.go:19	0x10021822c		8a99fed9		AND R25->63, R22, R25									
  runtime_calls.go:21	0x100218230		29400aba		LDPW (R21), (R26, R2)									
  runtime_calls.go:19	0x100218234		8b1912ed		ADD R25<<4, R23, R13									
  runtime_calls.go:19	0x100218238		cb16030f		SUB R22, R24, R15									
  source_image.go:111	0x10021823c		f9400237		MOVD (R17), R23										
  source_image.go:111	0x100218240		b4000157		CBZ R23, 10(PC)										
  source_image.go:112	0x100218244		a94062f7		LDP (R23), (R23, R24)									
  source_image.go:112	0x100218248		aa0203f9		MOVD R2, R25										
  source_image.go:112	0x10021824c		eb18033f		CMP R24, R25										
  source_image.go:112	0x100218250		54006502		BCS 808(PC)										
  source_image.go:112	0x100218254		d3797c58		UBFIZ $7, R2, $32, R24									
  source_image.go:112	0x100218258		cb190f18		SUB R25<<3, R24, R24									
  source_image.go:112	0x10021825c		8b1802f7		ADD R24, R23, R23									
  source_image.go:113	0x100218260		294262f7		LDPW 16(R23), (R23, R24)								
  runtime_calls.go:22	0x100218264		14000009		JMP 9(PC)										
  source_image.go:115	0x100218268		a947e237		LDP 120(R17), (R23, R24)								
  source_image.go:115	0x10021826c		aa0203f9		MOVD R2, R25										
  source_image.go:115	0x100218270		eb18033f		CMP R24, R25										
  source_image.go:115	0x100218274		54006382		BCS 796(PC)										
  source_image.go:115	0x100218278		d3787c5e		UBFIZ $8, R2, $32, R30									
  source_image.go:115	0x10021827c		cb1917d9		SUB R25<<5, R30, R25									
  source_image.go:115	0x100218280		8b1902f9		ADD R25, R23, R25									
  source_image.go:116	0x100218284		29426337		LDPW 16(R25), (R23, R24)								
  module.go:224		0x100218288		b2400359		ORR $1, R26, R25									
  module.go:224		0x10021828c		71004f3f		CMPW $19, R25										
  module.go:224		0x100218290		54000061		BNE 3(PC)										
  module.go:224		0x100218294		b24003fe		ORR $1, ZR, R30										
  module.go:224		0x100218298		14000003		JMP 3(PC)										
  module.go:224		0x10021829c		7100575f		CMPW $21, R26										
  module.go:224		0x1002182a0		9a9f17fe		CSET EQ, R30										
  runtime_calls.go:25	0x1002182a4		f9406e23		MOVD 216(R17), R3									
  runtime_calls.go:25	0x1002182a8		294316a4		LDPW 24(R21), (R4, R5)									
  runtime_calls.go:25	0x1002182ac		8b050086		ADD R5, R4, R6										
  runtime_calls.go:25	0x1002182b0		2a0603e6		MOVW R6, R6										
  runtime_calls.go:25	0x1002182b4		eb0300df		CMP R3, R6										
  runtime_calls.go:25	0x1002182b8		54006148		BHI 778(PC)										
  runtime_calls.go:25	0x1002182bc		eb06009f		CMP R6, R4										
  runtime_calls.go:25	0x1002182c0		540060e8		BHI 775(PC)										
  runtime_calls.go:25	0x1002182c4		f9406627		MOVD 200(R17), R7									
  runtime_calls.go:25	0x1002182c8		cb030088		SUB R3, R4, R8										
  runtime_calls.go:25	0x1002182cc		8a88fc88		AND R8->63, R4, R8									
  module.go:224		0x1002182d0		b27f035a		ORR $2, R26, R26									
  runtime_calls.go:20	0x1002182d4		f9402029		MOVD 64(R1), R9										
  runtime_calls.go:25	0x1002182d8		cb0400c6		SUB R4, R6, R6										
  runtime_calls.go:25	0x1002182dc		8b0808ea		ADD R8<<2, R7, R10									
  runtime_calls.go:25	0x1002182e0		cb040063		SUB R4, R3, R3										
  module.go:224		0x1002182e4		71004b5f		CMPW $18, R26										
  runtime_calls.go:27	0x1002182e8		540000e1		BNE 7(PC)										
  runtime_calls.go:28	0x1002182ec		a9440938		LDP 64(R9), (R24, R2)									
  runtime_calls.go:28	0x1002182f0		2a1703e4		MOVW R23, R4										
  runtime_calls.go:28	0x1002182f4		eb02009f		CMP R2, R4										
  runtime_calls.go:28	0x1002182f8		54005f02		BCS 760(PC)										
  runtime_calls.go:28	0x1002182fc		f8647b18		MOVD (R24)(R4<<3), R24									
  runtime_calls.go:28	0x100218300		1400002e		JMP 46(PC)										
  runtime_calls.go:29	0x100218304		7100573f		CMPW $21, R25										
  runtime_calls.go:29	0x100218308		54000201		BNE 16(PC)										
  runtime_calls.go:30	0x10021830c		d10004b8		SUB $1, R5, R24										
  runtime_calls.go:31	0x100218310		2a1803e4		MOVW R24, R4										
  runtime_calls.go:31	0x100218314		eb06009f		CMP R6, R4										
  runtime_calls.go:31	0x100218318		54005de2		BCS 751(PC)										
  runtime_calls.go:31	0x10021831c		b8647944		MOVWU (R10)(R4<<2), R4									
  runtime_calls.go:31	0x100218320		eb0e009f		CMP R14, R4										
  runtime_calls.go:31	0x100218324		54005d62		BCS 747(PC)										
  runtime_calls.go:31	0x100218328		8b0411a4		ADD R4<<4, R13, R4									
  runtime_calls.go:31	0x10021832c		f9400084		MOVD (R4), R4										
  runtime_calls.go:32	0x100218330		b5000404		CBNZ R4, 32(PC)										
  runtime_calls.go:33	0x100218334		d2800123		MOVD $9, R3										
  runtime_calls.go:33	0x100218338		97fffcbe		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:33	0x10021833c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:33	0x100218340		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:33	0x100218344		d65f03c0		RET											
  runtime_calls.go:37	0x100218348		a9459122		LDP 88(R9), (R2, R4)									
  runtime_calls.go:37	0x10021834c		2a1803f8		MOVW R24, R24										
  runtime_calls.go:37	0x100218350		eb04031f		CMP R4, R24										
  runtime_calls.go:37	0x100218354		54005ba2		BCS 733(PC)										
  runtime_calls.go:36	0x100218358		d10004a4		SUB $1, R5, R4										
  runtime_calls.go:37	0x10021835c		f8787858		MOVD (R2)(R24<<3), R24									
  runtime_calls.go:38	0x100218360		3980031b		MOVB (R24), R27										
  runtime_calls.go:38	0x100218364		2a0403e2		MOVW R4, R2										
  runtime_calls.go:38	0x100218368		eb06005f		CMP R6, R2										
  runtime_calls.go:38	0x10021836c		54005ac2		BCS 726(PC)										
  runtime_calls.go:38	0x100218370		b8627942		MOVWU (R10)(R2<<2), R2									
  runtime_calls.go:38	0x100218374		eb0e005f		CMP R14, R2										
  runtime_calls.go:38	0x100218378		54005a42		BCS 722(PC)										
  runtime_calls.go:38	0x10021837c		8b0211a2		ADD R2<<4, R13, R2									
  runtime_calls.go:38	0x100218380		f9400042		MOVD (R2), R2										
  module.go:70		0x100218384		3940a705		MOVBU 41(R24), R5									
  module.go:70		0x100218388		37000045		TBNZ $0, R5, 2(PC)									
  module.go:73		0x10021838c		2a0203e2		MOVW R2, R2										
  runtime_calls.go:39	0x100218390		a9439718		LDP 56(R24), (R24, R5)									
  runtime_calls.go:39	0x100218394		eb05005f		CMP R5, R2										
  runtime_calls.go:39	0x100218398		54003702		BCS 440(PC)										
  runtime_calls.go:42	0x10021839c		f8627b18		MOVD (R24)(R2<<3), R24									
  runtime_calls.go:43	0x1002183a0		b4003618		CBZ R24, 432(PC)									
  runtime_calls.go:43	0x1002183a4		aa1803e2		MOVD R24, R2										
  runtime_calls.go:43	0x1002183a8		aa0403f8		MOVD R4, R24										
  runtime_calls.go:43	0x1002183ac		aa0203e4		MOVD R2, R4										
  runtime_calls.go:47	0x1002183b0		aa1803e5		MOVD R24, R5										
  runtime_calls.go:47	0x1002183b4		aa0403f8		MOVD R4, R24										
  state.go:177		0x1002183b8		b4003478		CBZ R24, 419(PC)									
  runtime_calls.go:47	0x1002183bc		f9400002		MOVD (R0), R2										
  state.go:177		0x1002183c0		a94d2c44		LDP 208(R2), (R4, R11)									
  state.go:177		0x1002183c4		eb0b031f		CMP R11, R24										
  state.go:177		0x1002183c8		540033e2		BCS 415(PC)										
  state.go:177		0x1002183cc		f8787898		MOVD (R4)(R24<<3), R24									
  state.go:177		0x1002183d0		b40033b8		CBZ R24, 413(PC)									
  runtime_calls.go:13	0x1002183d4		f900efe0		MOVD R0, 472(RSP)									
  runtime_calls.go:12	0x1002183d8		f9005ff3		MOVD R19, 184(RSP)									
  runtime_calls.go:13	0x1002183dc		f90097f0		MOVD R16, 296(RSP)									
  runtime_calls.go:16	0x1002183e0		b90093f4		MOVW R20, 144(RSP)									
  runtime_calls.go:18	0x1002183e4		f90077f6		MOVD R22, 232(RSP)									
  runtime_calls.go:19	0x1002183e8		f90053ef		MOVD R15, 160(RSP)									
  runtime_calls.go:19	0x1002183ec		f90083ed		MOVD R13, 256(RSP)									
  runtime_calls.go:20	0x1002183f0		f90087e9		MOVD R9, 264(RSP)									
  runtime_calls.go:23	0x1002183f4		39023ffe		MOVB R30, 143(RSP)									
  runtime_calls.go:25	0x1002183f8		f90057e6		MOVD R6, 168(RSP)									
  runtime_calls.go:25	0x1002183fc		f9005be3		MOVD R3, 176(RSP)									
  runtime_calls.go:25	0x100218400		f9008bea		MOVD R10, 272(RSP)									
  runtime_calls.go:25	0x100218404		f9007fe8		MOVD R8, 248(RSP)									
  state.go:177		0x100218408		f900bbf8		MOVD R24, 368(RSP)									
  runtime_calls.go:25	0x10021840c		f900b7e7		MOVD R7, 360(RSP)									
  runtime_calls.go:19	0x100218410		f9004fee		MOVD R14, 152(RSP)									
  runtime_calls.go:47	0x100218414		b90097e5		MOVW R5, 148(RSP)									
  runtime_calls.go:51	0x100218418		71004f5f		CMPW $19, R26										
  state.go:180		0x10021841c		54000060		BEQ 3(PC)										
  runtime_calls.go:51	0x100218420		7100573f		CMPW $21, R25										
  runtime_calls.go:51	0x100218424		54000421		BNE 33(PC)										
  runtime_calls.go:51	0x100218428		a942ad24		LDP 40(R9), (R4, R11)									
  runtime_calls.go:51	0x10021842c		2a1703ec		MOVW R23, R12										
  runtime_calls.go:51	0x100218430		eb0b019f		CMP R11, R12										
  runtime_calls.go:51	0x100218434		54005442		BCS 674(PC)										
  runtime_calls.go:14	0x100218438		f90093e1		MOVD R1, 288(RSP)									
  runtime_calls.go:15	0x10021843c		f9009ff1		MOVD R17, 312(RSP)									
  runtime_calls.go:17	0x100218440		f9008ff5		MOVD R21, 280(RSP)									
  runtime_calls.go:51	0x100218444		b9403b01		MOVWU 56(R24), R1									
  runtime_calls.go:51	0x100218448		b86c7883		MOVWU (R4)(R12<<2), R3									
  state.go:565		0x10021844c		91058040		ADD $352, R2, R0									
  state.go:565		0x100218450		aa0303e2		MOVD R3, R2										
  state.go:565		0x100218454		97fc43b7		CALL github.com/cpunion/wasmvm/internal/core/module.(*TypeRegistry).FunctionSubtype(SB)	
  runtime_calls.go:51	0x100218458		36002e40		TBZ $0, R0, 370(PC)									
  execution.go:209	0x10021845c		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:100	0x100218460		f9405be3		MOVD 176(RSP), R3									
  runtime_calls.go:127	0x100218464		b94097e5		MOVWU 148(RSP), R5									
  runtime_calls.go:129	0x100218468		f94057e6		MOVD 168(RSP), R6									
  runtime_calls.go:76	0x10021846c		f940b7e7		MOVD 360(RSP), R7									
  runtime_calls.go:76	0x100218470		f9407fe8		MOVD 248(RSP), R8									
  host.go:21		0x100218474		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:100	0x100218478		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:101	0x10021847c		f94083ed		MOVD 256(RSP), R13									
  runtime_calls.go:101	0x100218480		f9404fee		MOVD 152(RSP), R14									
  runtime_calls.go:64	0x100218484		f94053ef		MOVD 160(RSP), R15									
  runtime_calls.go:56	0x100218488		f94097f0		MOVD 296(RSP), R16									
  runtime_calls.go:58	0x10021848c		f9409ff1		MOVD 312(RSP), R17									
  runtime_calls.go:104	0x100218490		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:124	0x100218494		b94093f4		MOVWU 144(RSP), R20									
  runtime_calls.go:58	0x100218498		f9408ff5		MOVD 280(RSP), R21									
  runtime_calls.go:92	0x10021849c		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:58	0x1002184a0		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:55	0x1002184a4		39423ffe		MOVBU 143(RSP), R30									
  runtime_calls.go:55	0x1002184a8		3600009e		TBZ $0, R30, 4(PC)									
  runtime_calls.go:56	0x1002184ac		a9422e02		LDP 32(R16), (R2, R11)									
  runtime_calls.go:56	0x1002184b0		f9401a04		MOVD 48(R16), R4									
  runtime_calls.go:56	0x1002184b4		14000012		JMP 18(PC)										
  runtime_calls.go:58	0x1002184b8		f9406e37		MOVD 216(R17), R23									
  runtime_calls.go:58	0x1002184bc		294366b5		LDPW 24(R21), (R21, R25)								
  runtime_calls.go:58	0x1002184c0		8b150335		ADD R21, R25, R21									
  runtime_calls.go:58	0x1002184c4		f9401719		MOVD 40(R24), R25									
  runtime_calls.go:58	0x1002184c8		8b1902b9		ADD R25, R21, R25									
  runtime_calls.go:58	0x1002184cc		2a1903f9		MOVW R25, R25										
  runtime_calls.go:58	0x1002184d0		eb17033f		CMP R23, R25										
  runtime_calls.go:58	0x1002184d4		54004ee8		BHI 631(PC)										
  runtime_calls.go:58	0x1002184d8		2a1503f5		MOVW R21, R21										
  runtime_calls.go:58	0x1002184dc		eb1902bf		CMP R25, R21										
  runtime_calls.go:58	0x1002184e0		54004e28		BHI 625(PC)										
  runtime_calls.go:58	0x1002184e4		f9406631		MOVD 200(R17), R17									
  runtime_calls.go:58	0x1002184e8		cb1702ba		SUB R23, R21, R26									
  runtime_calls.go:58	0x1002184ec		8a9afeba		AND R26->63, R21, R26									
  runtime_calls.go:58	0x1002184f0		cb15032b		SUB R21, R25, R11									
  runtime_calls.go:58	0x1002184f4		cb1502e4		SUB R21, R23, R4									
  runtime_calls.go:58	0x1002184f8		8b1a0a22		ADD R26<<2, R17, R2									
  runtime_calls.go:60	0x1002184fc		f90067e4		MOVD R4, 200(RSP)									
  runtime_calls.go:60	0x100218500		f90063eb		MOVD R11, 192(RSP)									
  runtime_calls.go:60	0x100218504		f9009be2		MOVD R2, 304(RSP)									
  execution.go:209	0x100218508		f940b011		MOVD 352(R0), R17									
  execution.go:209	0x10021850c		b40000d1		CBZ R17, 6(PC)										
  type.go:19		0x100218510		88dffe31		LDARW (R17), R17									
  execution.go:209	0x100218514		35000091		CBNZW R17, 4(PC)									
  runtime_calls.go:60	0x100218518		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:60	0x10021851c		aa1f03ec		MOVD ZR, R12										
  runtime_calls.go:60	0x100218520		1400001a		JMP 26(PC)										
  execution.go:212	0x100218524		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100218528		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10021852c		d63f0020		CALL (R1)										
  runtime_calls.go:64	0x100218530		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:100	0x100218534		f9405be3		MOVD 176(RSP), R3									
  runtime_calls.go:64	0x100218538		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:127	0x10021853c		b94097e5		MOVWU 148(RSP), R5									
  runtime_calls.go:129	0x100218540		f94057e6		MOVD 168(RSP), R6									
  runtime_calls.go:76	0x100218544		f940b7e7		MOVD 360(RSP), R7									
  runtime_calls.go:76	0x100218548		f9407fe8		MOVD 248(RSP), R8									
  host.go:21		0x10021854c		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:100	0x100218550		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:64	0x100218554		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:101	0x100218558		f94083ed		MOVD 256(RSP), R13									
  runtime_calls.go:101	0x10021855c		f9404fee		MOVD 152(RSP), R14									
  runtime_calls.go:64	0x100218560		f94053ef		MOVD 160(RSP), R15									
  runtime_calls.go:123	0x100218564		f94097f0		MOVD 296(RSP), R16									
  runtime_calls.go:104	0x100218568		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:124	0x10021856c		b94093f4		MOVWU 144(RSP), R20									
  runtime_calls.go:92	0x100218570		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:63	0x100218574		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:63	0x100218578		39423ffe		MOVBU 143(RSP), R30									
  runtime_calls.go:60	0x10021857c		aa0103ec		MOVD R1, R12										
  runtime_calls.go:60	0x100218580		aa0003e1		MOVD R0, R1										
  runtime_calls.go:123	0x100218584		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:60	0x100218588		b5002421		CBNZ R1, 289(PC)									
  runtime_calls.go:63	0x10021858c		a945d711		LDP 88(R24), (R17, R21)									
  runtime_calls.go:63	0x100218590		b0001077		ADRP 2150400(PC), R23									
  runtime_calls.go:63	0x100218594		9102e2f7		ADD $184, R23, R23									
  runtime_calls.go:63	0x100218598		eb17023f		CMP R23, R17										
  runtime_calls.go:63	0x10021859c		54000061		BNE 3(PC)										
  runtime_calls.go:63	0x1002185a0		aa1503e1		MOVD R21, R1										
  runtime_calls.go:63	0x1002185a4		14000003		JMP 3(PC)										
  runtime_calls.go:73	0x1002185a8		aa1503e1		MOVD R21, R1										
  runtime_calls.go:63	0x1002185ac		aa1f03f5		MOVD ZR, R21										
  runtime_calls.go:63	0x1002185b0		54000681		BNE 52(PC)										
  runtime_calls.go:63	0x1002185b4		3700067e		TBNZ $0, R30, 51(PC)									
  runtime_calls.go:64	0x1002185b8		2a0503e8		MOVW R5, R8										
  runtime_calls.go:64	0x1002185bc		eb03011f		CMP R3, R8										
  runtime_calls.go:64	0x1002185c0		54004708		BHI 568(PC)										
  runtime_calls.go:64	0x1002185c4		a940c301		LDP 8(R24), (R1, R16)									
  runtime_calls.go:64	0x1002185c8		a941cf11		LDP 24(R24), (R17, R19)									
  runtime_calls.go:64	0x1002185cc		a9429b05		LDP 40(R24), (R5, R6)									
  runtime_calls.go:64	0x1002185d0		aa1503e0		MOVD R21, R0										
  runtime_calls.go:64	0x1002185d4		aa0a03e7		MOVD R10, R7										
  runtime_calls.go:64	0x1002185d8		aa0303e9		MOVD R3, R9										
  runtime_calls.go:64	0x1002185dc		aa0203ea		MOVD R2, R10										
  runtime_calls.go:64	0x1002185e0		aa0403ec		MOVD R4, R12										
  runtime_calls.go:64	0x1002185e4		aa1003e2		MOVD R16, R2										
  runtime_calls.go:64	0x1002185e8		aa1103e3		MOVD R17, R3										
  runtime_calls.go:64	0x1002185ec		aa1303e4		MOVD R19, R4										
  runtime_calls.go:64	0x1002185f0		97ffd588		CALL github.com/cpunion/wasmvm/internal/engine/state.(*ScalarLeaf).CallSlots(SB)	
  runtime_calls.go:64	0x1002185f4		b5000380		CBNZ R0, 28(PC)										
  execution.go:209	0x1002185f8		f940efe0		MOVD 472(RSP), R0									
  execution.go:209	0x1002185fc		f940b003		MOVD 352(R0), R3									
  execution.go:209	0x100218600		b40000c3		CBZ R3, 6(PC)										
  type.go:19		0x100218604		88dffc63		LDARW (R3), R3										
  execution.go:209	0x100218608		35000083		CBNZW R3, 4(PC)										
  runtime_calls.go:67	0x10021860c		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:67	0x100218610		aa1f03e2		MOVD ZR, R2										
  runtime_calls.go:67	0x100218614		14000007		JMP 7(PC)										
  execution.go:212	0x100218618		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x10021861c		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x100218620		d63f0020		CALL (R1)										
  runtime_calls.go:67	0x100218624		aa0103e2		MOVD R1, R2										
  runtime_calls.go:67	0x100218628		aa0003e1		MOVD R0, R1										
  runtime_calls.go:68	0x10021862c		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:67	0x100218630		b40000a1		CBZ R1, 5(PC)										
  runtime_calls.go:68	0x100218634		97ffea8b		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:68	0x100218638		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:68	0x10021863c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:68	0x100218640		d65f03c0		RET											
  runtime_calls.go:70	0x100218644		b94093e1		MOVWU 144(RSP), R1									
  runtime_calls.go:70	0x100218648		91000421		ADD $1, R1, R1										
  runtime_calls.go:70	0x10021864c		f94097e2		MOVD 296(RSP), R2									
  runtime_calls.go:70	0x100218650		b9000841		MOVW R1, 8(R2)										
  runtime_calls.go:71	0x100218654		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:71	0x100218658		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:71	0x10021865c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:71	0x100218660		d65f03c0		RET											
  runtime_calls.go:65	0x100218664		aa0103e2		MOVD R1, R2										
  runtime_calls.go:65	0x100218668		aa0003e1		MOVD R0, R1										
  runtime_calls.go:65	0x10021866c		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:65	0x100218670		97ffea7c		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:65	0x100218674		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:65	0x100218678		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:65	0x10021867c		d65f03c0		RET											
  runtime_calls.go:73	0x100218680		b000106c		ADRP 2150400(PC), R12									
  runtime_calls.go:73	0x100218684		9101818c		ADD $96, R12, R12									
  runtime_calls.go:73	0x100218688		eb0c023f		CMP R12, R17										
  runtime_calls.go:73	0x10021868c		54000040		BEQ 2(PC)										
  runtime_calls.go:73	0x100218690		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:73	0x100218694		54000561		BNE 43(PC)										
  runtime_calls.go:73	0x100218698		3700057e		TBNZ $0, R30, 43(PC)									
  runtime_calls.go:75	0x10021869c		39406023		MOVBU 24(R1), R3									
  runtime_calls.go:75	0x1002186a0		36000103		TBZ $0, R3, 8(PC)									
  runtime_calls.go:76	0x1002186a4		b4003fc6		CBZ R6, 510(PC)										
  runtime_calls.go:76	0x1002186a8		b86878e3		MOVWU (R7)(R8<<2), R3									
  runtime_calls.go:76	0x1002186ac		eb0e007f		CMP R14, R3										
  runtime_calls.go:76	0x1002186b0		54003f42		BCS 506(PC)										
  runtime_calls.go:76	0x1002186b4		8b0311a3		ADD R3<<4, R13, R3									
  runtime_calls.go:76	0x1002186b8		f9400063		MOVD (R3), R3										
  runtime_calls.go:76	0x1002186bc		14000002		JMP 2(PC)										
  runtime_calls.go:78	0x1002186c0		aa1f03e3		MOVD ZR, R3										
  runtime_calls.go:73	0x1002186c4		f900abe1		MOVD R1, 336(RSP)									
  runtime_calls.go:78	0x1002186c8		aa0103e0		MOVD R1, R0										
  runtime_calls.go:78	0x1002186cc		aa0303e1		MOVD R3, R1										
  runtime_calls.go:78	0x1002186d0		97ffd59c		CALL github.com/cpunion/wasmvm/internal/engine/state.(*ScalarAccess).Access(SB)		
  runtime_calls.go:79	0x1002186d4		b50002c1		CBNZ R1, 22(PC)										
  runtime_calls.go:82	0x1002186d8		f940abe1		MOVD 336(RSP), R1									
  runtime_calls.go:82	0x1002186dc		39406021		MOVBU 24(R1), R1									
  runtime_calls.go:82	0x1002186e0		37000161		TBNZ $0, R1, 11(PC)									
  runtime_calls.go:83	0x1002186e4		f94063e1		MOVD 192(RSP), R1									
  runtime_calls.go:83	0x1002186e8		b4003d61		CBZ R1, 491(PC)										
  runtime_calls.go:83	0x1002186ec		f9409be1		MOVD 304(RSP), R1									
  runtime_calls.go:83	0x1002186f0		b9400021		MOVWU (R1), R1										
  runtime_calls.go:83	0x1002186f4		f9404fe2		MOVD 152(RSP), R2									
  runtime_calls.go:83	0x1002186f8		eb02003f		CMP R2, R1										
  runtime_calls.go:83	0x1002186fc		54003ca2		BCS 485(PC)										
  runtime_calls.go:83	0x100218700		f94083e2		MOVD 256(RSP), R2									
  runtime_calls.go:83	0x100218704		8b011041		ADD R1<<4, R2, R1									
  runtime_calls.go:83	0x100218708		a9007c20		STP (R0, ZR), (R1)									
  runtime_calls.go:85	0x10021870c		b94093e1		MOVWU 144(RSP), R1									
  runtime_calls.go:85	0x100218710		91000421		ADD $1, R1, R1										
  runtime_calls.go:85	0x100218714		f94097e2		MOVD 296(RSP), R2									
  runtime_calls.go:85	0x100218718		b9000841		MOVW R1, 8(R2)										
  runtime_calls.go:86	0x10021871c		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:86	0x100218720		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:86	0x100218724		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:86	0x100218728		d65f03c0		RET											
  runtime_calls.go:80	0x10021872c		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:80	0x100218730		97ffea4c		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:80	0x100218734		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:80	0x100218738		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:80	0x10021873c		d65f03c0		RET											
  runtime_calls.go:88	0x100218740		3600093e		TBZ $0, R30, 73(PC)									
  runtime_calls.go:92	0x100218744		f9402706		MOVD 72(R24), R6									
  runtime_calls.go:92	0x100218748		b4000426		CBZ R6, 33(PC)										
  runtime_calls.go:92	0x10021874c		f9404cc6		MOVD 152(R6), R6									
  runtime_calls.go:92	0x100218750		8b0602c6		ADD R6, R22, R6										
  runtime_calls.go:92	0x100218754		b9401c07		MOVWU 28(R0), R7									
  runtime_calls.go:92	0x100218758		eb0600ff		CMP R6, R7										
  runtime_calls.go:92	0x10021875c		54000382		BCS 28(PC)										
  runtime_calls.go:93	0x100218760		d2800500		MOVD $40, R0										
  runtime_calls.go:93	0x100218764		f0001221		ADRP 2387968(PC), R1									
  runtime_calls.go:93	0x100218768		9113c021		ADD $1264, R1, R1									
  runtime_calls.go:93	0x10021876c		b24003e2		ORR $1, ZR, R2										
  runtime_calls.go:93	0x100218770		97f81124		CALL runtime.mallocgcSmallScanNoHeaderSC5(SB)						
  runtime_calls.go:93	0x100218774		f000137b		ADRP 2551808(PC), R27									
  runtime_calls.go:93	0x100218778		9107c37b		ADD $496, R27, R27									
  runtime_calls.go:93	0x10021877c		a9401363		LDP (R27), (R3, R4)									
  runtime_calls.go:93	0x100218780		f9000003		MOVD R3, (R0)										
  runtime_calls.go:93	0x100218784		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:93	0x100218788		b94fd363		MOVWU 4048(R27), R3									
  runtime_calls.go:93	0x10021878c		34000063		CBZW R3, 3(PC)										
  runtime_calls.go:93	0x100218790		97f9aab4		CALL runtime.gcWriteBarrier1(SB)							
  runtime_calls.go:93	0x100218794		f9000324		MOVD R4, (R25)										
  runtime_calls.go:93	0x100218798		f9000404		MOVD R4, 8(R0)										
  runtime_calls.go:93	0x10021879c		b00000e3		ADRP 118784(PC), R3									
  runtime_calls.go:93	0x1002187a0		91384463		ADD $3601, R3, R3									
  runtime_calls.go:93	0x1002187a4		d2800224		MOVD $17, R4										
  runtime_calls.go:93	0x1002187a8		a9019003		STP (R3, R4), 24(R0)									
  runtime_calls.go:93	0x1002187ac		90001301		ADRP 2490368(PC), R1									
  runtime_calls.go:93	0x1002187b0		91272021		ADD $2504, R1, R1									
  runtime_calls.go:93	0x1002187b4		aa0003e2		MOVD R0, R2										
  runtime_calls.go:93	0x1002187b8		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:93	0x1002187bc		97ffea29		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:93	0x1002187c0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:93	0x1002187c4		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:93	0x1002187c8		d65f03c0		RET											
  runtime_calls.go:95	0x1002187cc		2a0503e1		MOVW R5, R1										
  runtime_calls.go:95	0x1002187d0		f9405c05		MOVD 184(R0), R5									
  runtime_calls.go:95	0x1002187d4		eb05003f		CMP R5, R1										
  runtime_calls.go:95	0x1002187d8		5400006c		BGT 3(PC)										
  runtime_calls.go:98	0x1002187dc		f9005801		MOVD R1, 176(R0)									
  runtime_calls.go:98	0x1002187e0		1400001d		JMP 29(PC)										
  runtime_calls.go:95	0x1002187e4		f9007fe1		MOVD R1, 248(RSP)									
  runtime_calls.go:96	0x1002187e8		b0001200		ADRP 2363392(PC), R0									
  runtime_calls.go:96	0x1002187ec		9120c000		ADD $2096, R0, R0									
  runtime_calls.go:96	0x1002187f0		aa0103e2		MOVD R1, R2										
  runtime_calls.go:96	0x1002187f4		97f99827		CALL runtime.makeslice(SB)								
  runtime_calls.go:96	0x1002187f8		f9407fe3		MOVD 248(RSP), R3									
  runtime_calls.go:96	0x1002187fc		f940efe4		MOVD 472(RSP), R4									
  runtime_calls.go:96	0x100218800		a90b0c83		STP (R3, R3), 176(R4)									
  runtime_calls.go:96	0x100218804		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:96	0x100218808		b94fd365		MOVWU 4048(R27), R5									
  runtime_calls.go:96	0x10021880c		34000085		CBZW R5, 4(PC)										
  runtime_calls.go:96	0x100218810		f9405485		MOVD 168(R4), R5									
  runtime_calls.go:96	0x100218814		97f9aa97		CALL runtime.gcWriteBarrier2(SB)							
  runtime_calls.go:96	0x100218818		a9001720		STP (R0, R5), (R25)									
  runtime_calls.go:96	0x10021881c		f9005480		MOVD R0, 168(R4)									
  runtime_calls.go:101	0x100218820		aa0403e0		MOVD R4, R0										
  runtime_calls.go:100	0x100218824		aa0303e1		MOVD R3, R1										
  runtime_calls.go:108	0x100218828		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:100	0x10021882c		f9405be3		MOVD 176(RSP), R3									
  runtime_calls.go:108	0x100218830		f94067e4		MOVD 200(RSP), R4									
  host.go:21		0x100218834		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:100	0x100218838		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:108	0x10021883c		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:101	0x100218840		f94083ed		MOVD 256(RSP), R13									
  runtime_calls.go:101	0x100218844		f9404fee		MOVD 152(RSP), R14									
  runtime_calls.go:104	0x100218848		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:103	0x10021884c		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:106	0x100218850		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:100	0x100218854		eb03003f		CMP R3, R1										
  runtime_calls.go:100	0x100218858		540031a8		BHI 397(PC)										
  runtime_calls.go:100	0x10021885c		aa1f03e5		MOVD ZR, R5										
  runtime_calls.go:100	0x100218860		140000ca		JMP 202(PC)										
  runtime_calls.go:123	0x100218864		f9415c07		MOVD 696(R0), R7									
  runtime_calls.go:123	0x100218868		f9001e07		MOVD R7, 56(R16)									
  runtime_calls.go:124	0x10021886c		91000687		ADD $1, R20, R7										
  runtime_calls.go:124	0x100218870		29015207		STPW (R7, R20), 8(R16)									
  runtime_calls.go:125	0x100218874		b24003e7		ORR $1, ZR, R7										
  runtime_calls.go:125	0x100218878		39004207		MOVB R7, 16(R16)									
  runtime_calls.go:126	0x10021887c		f9402707		MOVD 72(R24), R7									
  runtime_calls.go:126	0x100218880		b5000967		CBNZ R7, 75(PC)										
  runtime_calls.go:127	0x100218884		2a0503e3		MOVW R5, R3										
  runtime_calls.go:127	0x100218888		f9006be3		MOVD R3, 208(RSP)									
  host.go:14		0x10021888c		f9401705		MOVD 40(R24), R5									
  host.go:15		0x100218890		f9408807		MOVD 272(R0), R7									
  host.go:14		0x100218894		eb05007f		CMP R5, R3										
  host.go:15		0x100218898		9a83b0a1		CSEL LT, R5, R3, R1									
  host.go:15		0x10021889c		eb07003f		CMP R7, R1										
  host.go:14		0x1002188a0		5400006c		BGT 3(PC)										
  host.go:18		0x1002188a4		f9008401		MOVD R1, 264(R0)									
  host.go:18		0x1002188a8		1400001a		JMP 26(PC)										
  host.go:15		0x1002188ac		f9006fe1		MOVD R1, 216(RSP)									
  host.go:16		0x1002188b0		b0001200		ADRP 2363392(PC), R0									
  host.go:16		0x1002188b4		9120c000		ADD $2096, R0, R0									
  host.go:16		0x1002188b8		aa0103e2		MOVD R1, R2										
  host.go:16		0x1002188bc		97f997f5		CALL runtime.makeslice(SB)								
  host.go:16		0x1002188c0		f9406fe3		MOVD 216(RSP), R3									
  host.go:16		0x1002188c4		f940efe4		MOVD 472(RSP), R4									
  host.go:16		0x1002188c8		a9108c83		STP (R3, R3), 264(R4)									
  host.go:16		0x1002188cc		900014fb		ADRP 2736128(PC), R27									
  host.go:16		0x1002188d0		b94fd363		MOVWU 4048(R27), R3									
  host.go:16		0x1002188d4		34000083		CBZW R3, 4(PC)										
  host.go:16		0x1002188d8		f9408083		MOVD 256(R4), R3									
  host.go:16		0x1002188dc		97f9aa65		CALL runtime.gcWriteBarrier2(SB)							
  host.go:16		0x1002188e0		a9000f20		STP (R0, R3), (R25)									
  host.go:16		0x1002188e4		f9008080		MOVD R0, 256(R4)									
  host.go:20		0x1002188e8		aa0403e0		MOVD R4, R0										
  runtime_calls.go:131	0x1002188ec		f9409be2		MOVD 304(RSP), R2									
  host.go:20		0x1002188f0		f9406be3		MOVD 208(RSP), R3									
  runtime_calls.go:131	0x1002188f4		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:129	0x1002188f8		f94057e6		MOVD 168(RSP), R6									
  host.go:21		0x1002188fc		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:129	0x100218900		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:131	0x100218904		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:129	0x100218908		f94077f6		MOVD 232(RSP), R22									
  host.go:21		0x10021890c		f940bbf8		MOVD 368(RSP), R24									
  host.go:20		0x100218910		f9408805		MOVD 272(R0), R5									
  host.go:20		0x100218914		eb05007f		CMP R5, R3										
  host.go:20		0x100218918		54001308		BHI 152(PC)										
  host.go:20		0x10021891c		f9408007		MOVD 256(R0), R7									
  host.go:21		0x100218920		a917a7f8		STP (R24, R9), 376(RSP)									
  host.go:21		0x100218924		a9188fe7		STP (R7, R3), 392(RSP)									
  host.go:21		0x100218928		f900cfe5		MOVD R5, 408(RSP)									
  host.go:22		0x10021892c		91036001		ADD $216, R0, R1									
  host.go:21		0x100218930		900014fb		ADRP 2736128(PC), R27									
  host.go:21		0x100218934		b94fd365		MOVWU 4048(R27), R5									
  host.go:21		0x100218938		34000285		CBZW R5, 20(PC)										
  host.go:20		0x10021893c		f900a3e7		MOVD R7, 320(RSP)									
  host.go:22		0x100218940		f900b3e1		MOVD R1, 352(RSP)									
  host.go:22		0x100218944		f9408c03		MOVD 280(R0), R3									
  host.go:21		0x100218948		97f9aa4a		CALL runtime.gcWriteBarrier2(SB)							
  host.go:22		0x10021894c		a9000f21		STP (R1, R3), (R25)									
  host.go:21		0x100218950		d0001220		ADRP 2383872(PC), R0									
  host.go:21		0x100218954		913ec000		ADD $4016, R0, R0									
  host.go:21		0x100218958		9105e3e2		ADD $376, RSP, R2									
  host.go:21		0x10021895c		97f81b55		CALL runtime.wbMove(SB)									
  host.go:21		0x100218960		f940efe0		MOVD 472(RSP), R0									
  host.go:22		0x100218964		f940b3e1		MOVD 352(RSP), R1									
  runtime_calls.go:131	0x100218968		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:128	0x10021896c		f9406be3		MOVD 208(RSP), R3									
  runtime_calls.go:131	0x100218970		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:129	0x100218974		f94057e6		MOVD 168(RSP), R6									
  runtime_calls.go:129	0x100218978		f940a3e7		MOVD 320(RSP), R7									
  runtime_calls.go:129	0x10021897c		f9408bea		MOVD 272(RSP), R10									
  runtime_calls.go:131	0x100218980		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:129	0x100218984		f94077f6		MOVD 232(RSP), R22									
  host.go:21		0x100218988		9105e3fb		ADD $376, RSP, R27									
  host.go:21		0x10021898c		ad400760		FLDPQ (R27), (F0, F1)									
  host.go:21		0x100218990		f940cfe5		MOVD 408(RSP), R5									
  host.go:21		0x100218994		9103601b		ADD $216, R0, R27									
  host.go:21		0x100218998		ad000760		FSTPQ (F0, F1), (R27)									
  host.go:21		0x10021899c		f9007c05		MOVD R5, 248(R0)									
  host.go:22		0x1002189a0		f9008c01		MOVD R1, 280(R0)									
  runtime_calls.go:128	0x1002189a4		aa1f03e1		MOVD ZR, R1										
  runtime_calls.go:128	0x1002189a8		1400005a		JMP 90(PC)										
  runtime_calls.go:135	0x1002189ac		aa1803e1		MOVD R24, R1										
  runtime_calls.go:135	0x1002189b0		aa0b03e3		MOVD R11, R3										
  runtime_calls.go:135	0x1002189b4		97ffe8a7		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push(SB)		
  runtime_calls.go:135	0x1002189b8		b50001c0		CBNZ R0, 14(PC)										
  runtime_calls.go:138	0x1002189bc		f940efe1		MOVD 472(RSP), R1									
  runtime_calls.go:138	0x1002189c0		a9440c22		LDP 64(R1), (R2, R3)									
  runtime_calls.go:138	0x1002189c4		d1000464		SUB $1, R3, R4										
  runtime_calls.go:138	0x1002189c8		eb04007f		CMP R4, R3										
  runtime_calls.go:138	0x1002189cc		54000969		BLS 75(PC)										
  runtime_calls.go:138	0x1002189d0		8b041842		ADD R4<<6, R2, R2									
  runtime_calls.go:138	0x1002189d4		f9400c42		MOVD 24(R2), R2										
  runtime_calls.go:139	0x1002189d8		aa1f03e3		MOVD ZR, R3										
  runtime_calls.go:139	0x1002189dc		b94097e4		MOVWU 148(RSP), R4									
  runtime_calls.go:139	0x1002189e0		f94057e5		MOVD 168(RSP), R5									
  runtime_calls.go:139	0x1002189e4		f9408be6		MOVD 272(RSP), R6									
  runtime_calls.go:139	0x1002189e8		f94077e7		MOVD 232(RSP), R7									
  runtime_calls.go:139	0x1002189ec		1400002c		JMP 44(PC)										
  runtime_calls.go:136	0x1002189f0		aa0103e2		MOVD R1, R2										
  runtime_calls.go:136	0x1002189f4		aa0003e1		MOVD R0, R1										
  runtime_calls.go:136	0x1002189f8		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:136	0x1002189fc		97ffe999		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:136	0x100218a00		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:136	0x100218a04		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:136	0x100218a08		d65f03c0		RET											
  runtime_calls.go:61	0x100218a0c		aa0c03e2		MOVD R12, R2										
  runtime_calls.go:61	0x100218a10		97ffe994		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:61	0x100218a14		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:61	0x100218a18		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:61	0x100218a1c		d65f03c0		RET											
  runtime_calls.go:52	0x100218a20		f9408fe4		MOVD 280(RSP), R4									
  runtime_calls.go:52	0x100218a24		b9400482		MOVWU 4(R4), R2										
  runtime_calls.go:52	0x100218a28		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:52	0x100218a2c		f94093e1		MOVD 288(RSP), R1									
  runtime_calls.go:52	0x100218a30		d28000a3		MOVD $5, R3										
  runtime_calls.go:52	0x100218a34		97fffaff		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:52	0x100218a38		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:52	0x100218a3c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:52	0x100218a40		d65f03c0		RET											
  runtime_calls.go:49	0x100218a44		f000137b		ADRP 2551808(PC), R27									
  runtime_calls.go:49	0x100218a48		9103037b		ADD $192, R27, R27									
  runtime_calls.go:49	0x100218a4c		a9400b61		LDP (R27), (R1, R2)									
  runtime_calls.go:49	0x100218a50		97ffe984		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:49	0x100218a54		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:49	0x100218a58		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:49	0x100218a5c		d65f03c0		RET											
  runtime_calls.go:44	0x100218a60		b94006a2		MOVWU 4(R21), R2									
  runtime_calls.go:44	0x100218a64		b27e03e3		ORR $4, ZR, R3										
  runtime_calls.go:44	0x100218a68		97fffaf2		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:44	0x100218a6c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:44	0x100218a70		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:44	0x100218a74		d65f03c0		RET											
  runtime_calls.go:40	0x100218a78		b94006a2		MOVWU 4(R21), R2									
  runtime_calls.go:40	0x100218a7c		b24007e3		ORR $3, ZR, R3										
  runtime_calls.go:40	0x100218a80		97fffaec		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap(SB)	
  runtime_calls.go:40	0x100218a84		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:40	0x100218a88		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:40	0x100218a8c		d65f03c0		RET											
  runtime_calls.go:140	0x100218a90		8b0b1129		ADD R11<<4, R9, R9									
  runtime_calls.go:140	0x100218a94		a9003128		STP (R8, R12), (R9)									
  runtime_calls.go:139	0x100218a98		91000463		ADD $1, R3, R3										
  runtime_calls.go:139	0x100218a9c		6b04007f		CMPW R4, R3										
  runtime_calls.go:139	0x100218aa0		540001e2		BCS 15(PC)										
  runtime_calls.go:140	0x100218aa4		2a0303e8		MOVW R3, R8										
  runtime_calls.go:140	0x100218aa8		a947a829		LDP 120(R1), (R9, R10)									
  runtime_calls.go:140	0x100218aac		8b08004b		ADD R8, R2, R11										
  runtime_calls.go:140	0x100218ab0		eb05011f		CMP R5, R8										
  runtime_calls.go:140	0x100218ab4		54000202		BCS 16(PC)										
  runtime_calls.go:140	0x100218ab8		b86878c8		MOVWU (R6)(R8<<2), R8									
  runtime_calls.go:140	0x100218abc		8b070108		ADD R7, R8, R8										
  runtime_calls.go:140	0x100218ac0		eb08015f		CMP R8, R10										
  runtime_calls.go:140	0x100218ac4		54000169		BLS 11(PC)										
  runtime_calls.go:140	0x100218ac8		8b081128		ADD R8<<4, R9, R8									
  runtime_calls.go:140	0x100218acc		a9403108		LDP (R8), (R8, R12)									
  runtime_calls.go:140	0x100218ad0		eb0b015f		CMP R11, R10										
  runtime_calls.go:140	0x100218ad4		54fffde8		BHI -17(PC)										
  runtime_calls.go:140	0x100218ad8		14000005		JMP 5(PC)										
  runtime_calls.go:142	0x100218adc		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:142	0x100218ae0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:142	0x100218ae4		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:142	0x100218ae8		d65f03c0		RET											
  runtime_calls.go:140	0x100218aec		97f9aa95		CALL runtime.panicBounds(SB)								
  runtime_calls.go:140	0x100218af0		97f9aa94		CALL runtime.panicBounds(SB)								
  runtime_calls.go:140	0x100218af4		97f9aa93		CALL runtime.panicBounds(SB)								
  runtime_calls.go:138	0x100218af8		97f9aa92		CALL runtime.panicBounds(SB)								
  runtime_calls.go:129	0x100218afc		8b0110e8		ADD R1<<4, R7, R8									
  runtime_calls.go:129	0x100218b00		8b0910a5		ADD R9<<4, R5, R5									
  runtime_calls.go:129	0x100218b04		a94024a5		LDP (R5), (R5, R9)									
  runtime_calls.go:129	0x100218b08		a9002505		STP (R5, R9), (R8)									
  runtime_calls.go:128	0x100218b0c		91000421		ADD $1, R1, R1										
  runtime_calls.go:128	0x100218b10		eb03003f		CMP R3, R1										
  runtime_calls.go:128	0x100218b14		5400012a		BGE 9(PC)										
  runtime_calls.go:129	0x100218b18		a947a005		LDP 120(R0), (R5, R8)									
  runtime_calls.go:129	0x100218b1c		eb06003f		CMP R6, R1										
  runtime_calls.go:129	0x100218b20		540002a2		BCS 21(PC)										
  runtime_calls.go:129	0x100218b24		b8617949		MOVWU (R10)(R1<<2), R9									
  runtime_calls.go:129	0x100218b28		8b160129		ADD R22, R9, R9										
  runtime_calls.go:129	0x100218b2c		eb09011f		CMP R9, R8										
  runtime_calls.go:129	0x100218b30		54fffe68		BHI -13(PC)										
  runtime_calls.go:129	0x100218b34		1400000f		JMP 15(PC)										
  runtime_calls.go:131	0x100218b38		a912900b		STP (R11, R4), 296(R0)									
  runtime_calls.go:131	0x100218b3c		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:131	0x100218b40		b94fd361		MOVWU 4048(R27), R1									
  runtime_calls.go:131	0x100218b44		34000081		CBZW R1, 4(PC)										
  runtime_calls.go:131	0x100218b48		f9409001		MOVD 288(R0), R1									
  runtime_calls.go:131	0x100218b4c		97f9a9c9		CALL runtime.gcWriteBarrier2(SB)							
  runtime_calls.go:131	0x100218b50		a9000722		STP (R2, R1), (R25)									
  runtime_calls.go:131	0x100218b54		f9009002		MOVD R2, 288(R0)									
  runtime_calls.go:132	0x100218b58		b27f03e1		ORR $2, ZR, R1										
  runtime_calls.go:132	0x100218b5c		3904e001		MOVB R1, 312(R0)									
  runtime_calls.go:133	0x100218b60		aa0103e0		MOVD R1, R0										
  runtime_calls.go:133	0x100218b64		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:133	0x100218b68		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:133	0x100218b6c		d65f03c0		RET											
  runtime_calls.go:129	0x100218b70		97f9aa74		CALL runtime.panicBounds(SB)								
  runtime_calls.go:129	0x100218b74		97f9aa73		CALL runtime.panicBounds(SB)								
  host.go:20		0x100218b78		97f9aa72		CALL runtime.panicBounds(SB)								
  runtime_calls.go:101	0x100218b7c		8b0510e7		ADD R5<<4, R7, R7									
  runtime_calls.go:101	0x100218b80		a90030e6		STP (R6, R12), (R7)									
  runtime_calls.go:100	0x100218b84		910004a5		ADD $1, R5, R5										
  runtime_calls.go:100	0x100218b88		eb0100bf		CMP R1, R5										
  runtime_calls.go:100	0x100218b8c		5400014a		BGE 10(PC)										
  runtime_calls.go:100	0x100218b90		b8657946		MOVWU (R10)(R5<<2), R6									
  runtime_calls.go:101	0x100218b94		eb0e00df		CMP R14, R6										
  runtime_calls.go:101	0x100218b98		54001782		BCS 188(PC)										
  runtime_calls.go:101	0x100218b9c		a94aa007		LDP 168(R0), (R7, R8)									
  runtime_calls.go:101	0x100218ba0		8b0611a6		ADD R6<<4, R13, R6									
  runtime_calls.go:101	0x100218ba4		a94030c6		LDP (R6), (R6, R12)									
  runtime_calls.go:101	0x100218ba8		eb0800bf		CMP R8, R5										
  runtime_calls.go:101	0x100218bac		54fffe83		BCC -12(PC)										
  runtime_calls.go:101	0x100218bb0		140000b5		JMP 181(PC)										
  runtime_calls.go:103	0x100218bb4		f9404405		MOVD 136(R0), R5									
  runtime_calls.go:103	0x100218bb8		eb1600bf		CMP R22, R5										
  runtime_calls.go:103	0x100218bbc		54001603		BCC 176(PC)										
  runtime_calls.go:103	0x100218bc0		f9004016		MOVD R22, 128(R0)									
  runtime_calls.go:104	0x100218bc4		a9441805		LDP 64(R0), (R5, R6)									
  runtime_calls.go:104	0x100218bc8		eb1300df		CMP R19, R6										
  runtime_calls.go:104	0x100218bcc		54001549		BLS 170(PC)										
  runtime_calls.go:104	0x100218bd0		8b1318a1		ADD R19<<6, R5, R1									
  runtime_calls.go:104	0x100218bd4		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:104	0x100218bd8		b94fd365		MOVWU 4048(R27), R5									
  runtime_calls.go:104	0x100218bdc		340001c5		CBZW R5, 14(PC)										
  runtime_calls.go:104	0x100218be0		f900afe1		MOVD R1, 344(RSP)									
  runtime_calls.go:104	0x100218be4		f0001280		ADRP 2437120(PC), R0									
  runtime_calls.go:104	0x100218be8		91104000		ADD $1040, R0, R0									
  runtime_calls.go:104	0x100218bec		97f81aa5		CALL runtime.wbZero(SB)									
  runtime_calls.go:105	0x100218bf0		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:104	0x100218bf4		f940afe1		MOVD 344(RSP), R1									
  runtime_calls.go:108	0x100218bf8		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:108	0x100218bfc		f94067e4		MOVD 200(RSP), R4									
  host.go:21		0x100218c00		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:108	0x100218c04		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:105	0x100218c08		f9405ff3		MOVD 184(RSP), R19									
  runtime_calls.go:116	0x100218c0c		f94077f6		MOVD 232(RSP), R22									
  runtime_calls.go:106	0x100218c10		f940bbf8		MOVD 368(RSP), R24									
  runtime_calls.go:104	0x100218c14		a9007c3f		STP (ZR, ZR), (R1)									
  runtime_calls.go:104	0x100218c18		a9017c3f		STP (ZR, ZR), 16(R1)									
  runtime_calls.go:104	0x100218c1c		a9027c3f		STP (ZR, ZR), 32(R1)									
  runtime_calls.go:104	0x100218c20		a9037c3f		STP (ZR, ZR), 48(R1)									
  runtime_calls.go:105	0x100218c24		f9402805		MOVD 80(R0), R5										
  runtime_calls.go:105	0x100218c28		eb1300bf		CMP R19, R5										
  runtime_calls.go:105	0x100218c2c		54001203		BCC 144(PC)										
  runtime_calls.go:105	0x100218c30		f9002413		MOVD R19, 72(R0)									
  runtime_calls.go:106	0x100218c34		f9402705		MOVD 72(R24), R5									
  runtime_calls.go:106	0x100218c38		b5000c85		CBNZ R5, 100(PC)									
  runtime_calls.go:107	0x100218c3c		f9405803		MOVD 176(R0), R3									
  runtime_calls.go:107	0x100218c40		f9007be3		MOVD R3, 240(RSP)									
  host.go:14		0x100218c44		f9401705		MOVD 40(R24), R5									
  host.go:15		0x100218c48		f9408806		MOVD 272(R0), R6									
  host.go:14		0x100218c4c		eb0300bf		CMP R3, R5										
  host.go:15		0x100218c50		9a83c0a1		CSEL GT, R5, R3, R1									
  host.go:15		0x100218c54		eb06003f		CMP R6, R1										
  host.go:14		0x100218c58		5400006c		BGT 3(PC)										
  host.go:18		0x100218c5c		f9008401		MOVD R1, 264(R0)									
  host.go:18		0x100218c60		14000017		JMP 23(PC)										
  host.go:15		0x100218c64		f90073e1		MOVD R1, 224(RSP)									
  host.go:16		0x100218c68		b0001200		ADRP 2363392(PC), R0									
  host.go:16		0x100218c6c		9120c000		ADD $2096, R0, R0									
  host.go:16		0x100218c70		aa0103e2		MOVD R1, R2										
  host.go:16		0x100218c74		97f99707		CALL runtime.makeslice(SB)								
  host.go:16		0x100218c78		f94073e3		MOVD 224(RSP), R3									
  host.go:16		0x100218c7c		f940efe4		MOVD 472(RSP), R4									
  host.go:16		0x100218c80		a9108c83		STP (R3, R3), 264(R4)									
  host.go:16		0x100218c84		900014fb		ADRP 2736128(PC), R27									
  host.go:16		0x100218c88		b94fd363		MOVWU 4048(R27), R3									
  host.go:16		0x100218c8c		34000083		CBZW R3, 4(PC)										
  host.go:16		0x100218c90		f9408083		MOVD 256(R4), R3									
  host.go:16		0x100218c94		97f9a977		CALL runtime.gcWriteBarrier2(SB)							
  host.go:16		0x100218c98		a9000f20		STP (R0, R3), (R25)									
  host.go:16		0x100218c9c		f9008080		MOVD R0, 256(R4)									
  host.go:20		0x100218ca0		aa0403e0		MOVD R4, R0										
  runtime_calls.go:108	0x100218ca4		f9409be2		MOVD 304(RSP), R2									
  host.go:20		0x100218ca8		f9407be3		MOVD 240(RSP), R3									
  runtime_calls.go:108	0x100218cac		f94067e4		MOVD 200(RSP), R4									
  host.go:21		0x100218cb0		f94087e9		MOVD 264(RSP), R9									
  runtime_calls.go:108	0x100218cb4		f94063eb		MOVD 192(RSP), R11									
  host.go:21		0x100218cb8		f940bbf8		MOVD 368(RSP), R24									
  host.go:20		0x100218cbc		f9408805		MOVD 272(R0), R5									
  host.go:20		0x100218cc0		eb0300bf		CMP R3, R5										
  host.go:20		0x100218cc4		54000d23		BCC 105(PC)										
  host.go:20		0x100218cc8		f9408006		MOVD 256(R0), R6									
  host.go:21		0x100218ccc		a91a27f8		STP (R24, R9), 416(RSP)									
  host.go:21		0x100218cd0		a91b0fe6		STP (R6, R3), 432(RSP)									
  host.go:21		0x100218cd4		f900e3e5		MOVD R5, 448(RSP)									
  host.go:22		0x100218cd8		91036001		ADD $216, R0, R1									
  host.go:21		0x100218cdc		900014fb		ADRP 2736128(PC), R27									
  host.go:21		0x100218ce0		b94fd365		MOVWU 4048(R27), R5									
  host.go:21		0x100218ce4		34000225		CBZW R5, 17(PC)										
  host.go:22		0x100218ce8		f900b3e1		MOVD R1, 352(RSP)									
  host.go:20		0x100218cec		f900a7e6		MOVD R6, 328(RSP)									
  host.go:22		0x100218cf0		f9408c03		MOVD 280(R0), R3									
  host.go:21		0x100218cf4		97f9a95f		CALL runtime.gcWriteBarrier2(SB)							
  host.go:22		0x100218cf8		a9000f21		STP (R1, R3), (R25)									
  host.go:21		0x100218cfc		d0001220		ADRP 2383872(PC), R0									
  host.go:21		0x100218d00		913ec000		ADD $4016, R0, R0									
  host.go:21		0x100218d04		910683e2		ADD $416, RSP, R2									
  host.go:21		0x100218d08		97f81a6a		CALL runtime.wbMove(SB)									
  host.go:21		0x100218d0c		f940efe0		MOVD 472(RSP), R0									
  host.go:22		0x100218d10		f940b3e1		MOVD 352(RSP), R1									
  runtime_calls.go:108	0x100218d14		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:107	0x100218d18		f9407be3		MOVD 240(RSP), R3									
  runtime_calls.go:108	0x100218d1c		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:107	0x100218d20		f940a7e6		MOVD 328(RSP), R6									
  runtime_calls.go:108	0x100218d24		f94063eb		MOVD 192(RSP), R11									
  host.go:21		0x100218d28		ad4d07e0		FLDPQ 416(RSP), (F0, F1)								
  host.go:21		0x100218d2c		f940e3e5		MOVD 448(RSP), R5									
  host.go:21		0x100218d30		9103601b		ADD $216, R0, R27									
  host.go:21		0x100218d34		ad000760		FSTPQ (F0, F1), (R27)									
  host.go:21		0x100218d38		f9007c05		MOVD R5, 248(R0)									
  host.go:22		0x100218d3c		f9008c01		MOVD R1, 280(R0)									
  runtime_calls.go:107	0x100218d40		a94a9401		LDP 168(R0), (R1, R5)									
  runtime_calls.go:107	0x100218d44		eb0300bf		CMP R3, R5										
  runtime_calls.go:107	0x100218d48		9a83b0a3		CSEL LT, R5, R3, R3									
  runtime_calls.go:107	0x100218d4c		eb0100df		CMP R1, R6										
  runtime_calls.go:107	0x100218d50		54000100		BEQ 8(PC)										
  runtime_calls.go:107	0x100218d54		d37cec62		LSL $4, R3, R2										
  runtime_calls.go:107	0x100218d58		aa0603e0		MOVD R6, R0										
  runtime_calls.go:107	0x100218d5c		97f9aa7d		CALL runtime.memmove(SB)								
  runtime_calls.go:108	0x100218d60		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:108	0x100218d64		f9409be2		MOVD 304(RSP), R2									
  runtime_calls.go:108	0x100218d68		f94067e4		MOVD 200(RSP), R4									
  runtime_calls.go:108	0x100218d6c		f94063eb		MOVD 192(RSP), R11									
  runtime_calls.go:108	0x100218d70		a912900b		STP (R11, R4), 296(R0)									
  runtime_calls.go:108	0x100218d74		900014fb		ADRP 2736128(PC), R27									
  runtime_calls.go:108	0x100218d78		b94fd363		MOVWU 4048(R27), R3									
  runtime_calls.go:108	0x100218d7c		34000083		CBZW R3, 4(PC)										
  runtime_calls.go:108	0x100218d80		f9409003		MOVD 288(R0), R3									
  runtime_calls.go:108	0x100218d84		97f9a93b		CALL runtime.gcWriteBarrier2(SB)							
  runtime_calls.go:108	0x100218d88		a9000f22		STP (R2, R3), (R25)									
  runtime_calls.go:108	0x100218d8c		f9009002		MOVD R2, 288(R0)									
  runtime_calls.go:108	0x100218d90		b27f03e2		ORR $2, ZR, R2										
  runtime_calls.go:108	0x100218d94		3904e002		MOVB R2, 312(R0)									
  runtime_calls.go:109	0x100218d98		a94a9003		LDP 168(R0), (R3, R4)									
  runtime_calls.go:109	0x100218d9c		b40000c4		CBZ R4, 6(PC)										
  runtime_calls.go:109	0x100218da0		d37cec81		LSL $4, R4, R1										
  runtime_calls.go:109	0x100218da4		aa0303e0		MOVD R3, R0										
  runtime_calls.go:109	0x100218da8		97f9a9fe		CALL runtime.memclrNoHeapPointers(SB)							
  runtime_calls.go:110	0x100218dac		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:110	0x100218db0		b27f03e2		ORR $2, ZR, R2										
  runtime_calls.go:110	0x100218db4		f900581f		MOVD ZR, 176(R0)									
  runtime_calls.go:111	0x100218db8		aa0203e0		MOVD R2, R0										
  runtime_calls.go:111	0x100218dbc		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:111	0x100218dc0		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:111	0x100218dc4		d65f03c0		RET											
  runtime_calls.go:113	0x100218dc8		aa1803e1		MOVD R24, R1										
  runtime_calls.go:113	0x100218dcc		aa0b03e3		MOVD R11, R3										
  runtime_calls.go:113	0x100218dd0		97ffe7a0		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push(SB)		
  runtime_calls.go:113	0x100218dd4		b50003a0		CBNZ R0, 29(PC)										
  runtime_calls.go:116	0x100218dd8		f940efe3		MOVD 472(RSP), R3									
  runtime_calls.go:116	0x100218ddc		a9479464		LDP 120(R3), (R4, R5)									
  runtime_calls.go:116	0x100218de0		f94077e6		MOVD 232(RSP), R6									
  runtime_calls.go:116	0x100218de4		eb0600bf		CMP R6, R5										
  runtime_calls.go:116	0x100218de8		540003e3		BCC 31(PC)										
  runtime_calls.go:116	0x100218dec		f9404467		MOVD 136(R3), R7									
  runtime_calls.go:116	0x100218df0		cb0600a5		SUB R6, R5, R5										
  runtime_calls.go:116	0x100218df4		cb0700c7		SUB R7, R6, R7										
  runtime_calls.go:116	0x100218df8		8a87fcc6		AND R7->63, R6, R6									
  runtime_calls.go:116	0x100218dfc		8b061080		ADD R6<<4, R4, R0									
  runtime_calls.go:116	0x100218e00		a94a9061		LDP 168(R3), (R1, R4)									
  runtime_calls.go:116	0x100218e04		eb05009f		CMP R5, R4										
  runtime_calls.go:116	0x100218e08		9a85b084		CSEL LT, R4, R5, R4									
  runtime_calls.go:116	0x100218e0c		eb00003f		CMP R0, R1										
  runtime_calls.go:116	0x100218e10		54000080		BEQ 4(PC)										
  runtime_calls.go:116	0x100218e14		d37cec82		LSL $4, R4, R2										
  runtime_calls.go:116	0x100218e18		97f9aa4e		CALL runtime.memmove(SB)								
  runtime_calls.go:117	0x100218e1c		f940efe3		MOVD 472(RSP), R3									
  runtime_calls.go:117	0x100218e20		a94a8860		LDP 168(R3), (R0, R2)									
  runtime_calls.go:117	0x100218e24		b4000082		CBZ R2, 4(PC)										
  runtime_calls.go:117	0x100218e28		d37cec41		LSL $4, R2, R1										
  runtime_calls.go:117	0x100218e2c		97f9a9dd		CALL runtime.memclrNoHeapPointers(SB)							
  runtime_calls.go:118	0x100218e30		f940efe3		MOVD 472(RSP), R3									
  runtime_calls.go:118	0x100218e34		f900587f		MOVD ZR, 176(R3)									
  runtime_calls.go:119	0x100218e38		aa1f03e0		MOVD ZR, R0										
  runtime_calls.go:119	0x100218e3c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:119	0x100218e40		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:119	0x100218e44		d65f03c0		RET											
  runtime_calls.go:114	0x100218e48		aa0103e2		MOVD R1, R2										
  runtime_calls.go:114	0x100218e4c		aa0003e1		MOVD R0, R1										
  runtime_calls.go:114	0x100218e50		f940efe0		MOVD 472(RSP), R0									
  runtime_calls.go:114	0x100218e54		97ffe883		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  runtime_calls.go:114	0x100218e58		a97ffbfd		LDP -8(RSP), (R29, R30)									
  runtime_calls.go:114	0x100218e5c		910743ff		ADD $464, RSP, RSP									
  runtime_calls.go:114	0x100218e60		d65f03c0		RET											
  runtime_calls.go:116	0x100218e64		97f9a9b7		CALL runtime.panicBounds(SB)								
  host.go:20		0x100218e68		97f9a9b6		CALL runtime.panicBounds(SB)								
  runtime_calls.go:105	0x100218e6c		aa1303e0		MOVD R19, R0										
  runtime_calls.go:105	0x100218e70		97f9a9b4		CALL runtime.panicBounds(SB)								
  runtime_calls.go:104	0x100218e74		aa1303e0		MOVD R19, R0										
  runtime_calls.go:104	0x100218e78		97f9a9b2		CALL runtime.panicBounds(SB)								
  runtime_calls.go:103	0x100218e7c		aa1603e0		MOVD R22, R0										
  runtime_calls.go:103	0x100218e80		97f9a9b0		CALL runtime.panicBounds(SB)								
  runtime_calls.go:101	0x100218e84		97f9a9af		CALL runtime.panicBounds(SB)								
  runtime_calls.go:101	0x100218e88		97f9a9ae		CALL runtime.panicBounds(SB)								
  runtime_calls.go:100	0x100218e8c		97f9a9ad		CALL runtime.panicBounds(SB)								
  runtime_calls.go:83	0x100218e90		97f9a9ac		CALL runtime.panicBounds(SB)								
  runtime_calls.go:83	0x100218e94		97f9a9ab		CALL runtime.panicBounds(SB)								
  runtime_calls.go:76	0x100218e98		97f9a9aa		CALL runtime.panicBounds(SB)								
  runtime_calls.go:76	0x100218e9c		97f9a9a9		CALL runtime.panicBounds(SB)								
  runtime_calls.go:64	0x100218ea0		97f9a9a8		CALL runtime.panicBounds(SB)								
  runtime_calls.go:58	0x100218ea4		aa1503e0		MOVD R21, R0										
  runtime_calls.go:58	0x100218ea8		aa1903e1		MOVD R25, R1										
  runtime_calls.go:58	0x100218eac		97f9a9a5		CALL runtime.panicBounds(SB)								
  runtime_calls.go:58	0x100218eb0		aa1903e0		MOVD R25, R0										
  runtime_calls.go:58	0x100218eb4		aa1703e1		MOVD R23, R1										
  runtime_calls.go:58	0x100218eb8		97f9a9a2		CALL runtime.panicBounds(SB)								
  runtime_calls.go:51	0x100218ebc		97f9a9a1		CALL runtime.panicBounds(SB)								
  runtime_calls.go:38	0x100218ec0		97f9a9a0		CALL runtime.panicBounds(SB)								
  runtime_calls.go:38	0x100218ec4		97f9a99f		CALL runtime.panicBounds(SB)								
  runtime_calls.go:37	0x100218ec8		aa1803e0		MOVD R24, R0										
  runtime_calls.go:37	0x100218ecc		97f9a99d		CALL runtime.panicBounds(SB)								
  runtime_calls.go:31	0x100218ed0		97f9a99c		CALL runtime.panicBounds(SB)								
  runtime_calls.go:31	0x100218ed4		97f9a99b		CALL runtime.panicBounds(SB)								
  runtime_calls.go:28	0x100218ed8		97f9a99a		CALL runtime.panicBounds(SB)								
  runtime_calls.go:25	0x100218edc		97f9a999		CALL runtime.panicBounds(SB)								
  runtime_calls.go:25	0x100218ee0		97f9a998		CALL runtime.panicBounds(SB)								
  source_image.go:115	0x100218ee4		aa1903e0		MOVD R25, R0										
  source_image.go:115	0x100218ee8		aa1803e1		MOVD R24, R1										
  source_image.go:115	0x100218eec		97f9a995		CALL runtime.panicBounds(SB)								
  source_image.go:112	0x100218ef0		aa1903e0		MOVD R25, R0										
  source_image.go:112	0x100218ef4		aa1803e1		MOVD R24, R1										
  source_image.go:112	0x100218ef8		97f9a992		CALL runtime.panicBounds(SB)								
  runtime_calls.go:19	0x100218efc		aa1603e0		MOVD R22, R0										
  runtime_calls.go:19	0x100218f00		aa1903e1		MOVD R25, R1										
  runtime_calls.go:19	0x100218f04		97f9a98f		CALL runtime.panicBounds(SB)								
  runtime_calls.go:19	0x100218f08		aa1903e0		MOVD R25, R0										
  runtime_calls.go:19	0x100218f0c		aa1803e1		MOVD R24, R1										
  runtime_calls.go:19	0x100218f10		97f9a98c		CALL runtime.panicBounds(SB)								
  runtime_calls.go:17	0x100218f14		aa1703e0		MOVD R23, R0										
  runtime_calls.go:17	0x100218f18		aa1603e1		MOVD R22, R1										
  runtime_calls.go:17	0x100218f1c		97f9a989		CALL runtime.panicBounds(SB)								
  runtime_calls.go:13	0x100218f20		aa1303e0		MOVD R19, R0										
  runtime_calls.go:13	0x100218f24		aa1103e1		MOVD R17, R1										
  runtime_calls.go:13	0x100218f28		97f9a986		CALL runtime.panicBounds(SB)								
  runtime_calls.go:13	0x100218f2c		d503201f		NOOP											
  runtime_calls.go:11	0x100218f30		f90007e0		MOVD R0, 8(RSP)										
  runtime_calls.go:11	0x100218f34		aa1e03e3		MOVD R30, R3										
  runtime_calls.go:11	0x100218f38		97f9a0ea		CALL runtime.morestack_noctxt.abi0(SB)							
  runtime_calls.go:11	0x100218f3c		f94007e0		MOVD 8(RSP), R0										
  runtime_calls.go:11	0x100218f40		17fffc9c		JMP github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB)		
  runtime_calls.go:11	0x100218f44		00000000		?											
  runtime_calls.go:11	0x100218f48		00000000		?											
  runtime_calls.go:11	0x100218f4c		00000000		?											
