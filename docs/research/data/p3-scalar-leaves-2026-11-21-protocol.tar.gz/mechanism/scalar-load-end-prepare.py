from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
plan = json.loads((root.parent/"core-plan.json").read_text())
fixtures = {"original22-v1/memory/narrow-unaligned", "original22-v1/core/memory-load-store",
            "original22-v1/memory/float64-unaligned", "original22-v1/memory/dependent-address"}
hashes = plan["binarySHA256"].copy()
cases = []
for item in plan["cases"]:
    fixture = item["fixture"]
    key = fixture["cohort"]+"/"+fixture["id"]
    if key not in fixtures:
        continue
    commands={}
    for compiler in ("go","llgo"):
        candidate=root/(compiler+"-phase")
        hashes[str(candidate)]=hashlib.sha256(candidate.read_bytes()).hexdigest()
        for label,original in ((f"head-{compiler}-shape",f"head-{compiler}-interpreter"),
                               (f"base-{compiler}-shape",f"head-{compiler}-interpreter"),
                               (f"base-{compiler}-main",f"base-{compiler}-interpreter")):
            command=item["commands"][original].copy()
            command[command.index("--samples")+1]="6"
            if label.startswith("head-"):
                command[0]=str(candidate)
            commands[label]=command
    cases.append(dict(fixture=fixture,id=key,commands=commands))
assert len(cases)==len(fixtures)
output=dict(blocks=6,samples=5,seed=202611217042,cases=cases,binarySHA256=hashes,
            scope="Scalar load descriptor and checked endpoint overlay against the draft and upstream main. Both compilers, all four memory workloads, checked arithmetic, exact same binaries for A/A.")
(root/"frozen-plan.json").write_text(json.dumps(output,indent=2)+"\n")
