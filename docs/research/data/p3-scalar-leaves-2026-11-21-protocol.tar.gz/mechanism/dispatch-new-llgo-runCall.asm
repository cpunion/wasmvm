
dispatch/llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100032e30 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>:
100032e30: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
100032e34: a90167fa    	stp	x26, x25, [sp, #0x10]
100032e38: a9025ff8    	stp	x24, x23, [sp, #0x20]
100032e3c: a90357f6    	stp	x22, x21, [sp, #0x30]
100032e40: a9044ff4    	stp	x20, x19, [sp, #0x40]
100032e44: a9057bfd    	stp	x29, x30, [sp, #0x50]
100032e48: 910143fd    	add	x29, sp, #0x50
100032e4c: d108c3ff    	sub	sp, sp, #0x230
100032e50: b4002e60    	cbz	x0, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100032e54: f9402408    	ldr	x8, [x0, #0x48]
100032e58: d1000515    	sub	x21, x8, #0x1
100032e5c: b4005488    	cbz	x8, 0x1000338ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xabc>
100032e60: f9402008    	ldr	x8, [x0, #0x40]
100032e64: ab151919    	adds	x25, x8, x21, lsl #6
100032e68: 54002da0    	b.eq	0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100032e6c: f940033c    	ldr	x28, [x25]
100032e70: b4002d7c    	cbz	x28, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100032e74: f9402794    	ldr	x20, [x28, #0x48]
100032e78: b4002d34    	cbz	x20, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100032e7c: b9400b29    	ldr	w9, [x25, #0x8]
100032e80: f9405e81    	ldr	x1, [x20, #0xb8]
100032e84: eb09003f    	cmp	x1, x9
100032e88: 540053c9    	b.ls	0x100033900 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad0>
100032e8c: f9400f28    	ldr	x8, [x25, #0x18]
100032e90: f9404e8d    	ldr	x13, [x20, #0x98]
100032e94: f9404402    	ldr	x2, [x0, #0x88]
100032e98: f90033e8    	str	x8, [sp, #0x60]
100032e9c: 8b0801a8    	add	x8, x13, x8
100032ea0: eb02011f    	cmp	x8, x2
100032ea4: 54005328    	b.hi	0x100033908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xad8>
100032ea8: f94033ea    	ldr	x10, [sp, #0x60]
100032eac: eb08015f    	cmp	x10, x8
100032eb0: 54005348    	b.hi	0x100033918 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xae8>
100032eb4: f9405a88    	ldr	x8, [x20, #0xb0]
100032eb8: f90023e9    	str	x9, [sp, #0x40]
100032ebc: f9403c18    	ldr	x24, [x0, #0x78]
100032ec0: f940238e    	ldr	x14, [x28, #0x40]
100032ec4: 8b091516    	add	x22, x8, x9, lsl #5
100032ec8: f94033e8    	ldr	x8, [sp, #0x60]
100032ecc: f9400289    	ldr	x9, [x20]
100032ed0: cb08004b    	sub	x11, x2, x8
100032ed4: d37ced0a    	lsl	x10, x8, #4
100032ed8: 294022d7    	ldp	w23, w8, [x22]
100032edc: f100017f    	cmp	x11, #0x0
100032ee0: f9001feb    	str	x11, [sp, #0x38]
100032ee4: 9a9fc15b    	csel	x27, x10, xzr, gt
100032ee8: b4000109    	cbz	x9, 0x100032f08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xd8>
100032eec: f9400521    	ldr	x1, [x9, #0x8]
100032ef0: eb08003f    	cmp	x1, x8
100032ef4: 54005029    	b.ls	0x1000338f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xac8>
100032ef8: 52800f0a    	mov	w10, #0x78              ; =120
100032efc: f9400129    	ldr	x9, [x9]
100032f00: 9baa2508    	umaddl	x8, w8, w10, x9
100032f04: 14000008    	b	0x100032f24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xf4>
100032f08: f9404281    	ldr	x1, [x20, #0x80]
100032f0c: eb08003f    	cmp	x1, x8
100032f10: 54004f49    	b.ls	0x1000338f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xac8>
100032f14: 52801c09    	mov	w9, #0xe0               ; =224
100032f18: f9403e8a    	ldr	x10, [x20, #0x78]
100032f1c: 9ba92908    	umaddl	x8, w8, w9, x10
100032f20: b40014e8    	cbz	x8, 0x1000331bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x38c>
100032f24: f9400903    	ldr	x3, [x8, #0x10]
100032f28: 294342c8    	ldp	w8, w16, [x22, #0x18]
100032f2c: f9406e82    	ldr	x2, [x20, #0xd8]
100032f30: 71005aff    	cmp	w23, #0x16
100032f34: 1a9f27f1    	cset	w17, lo
100032f38: 0b100109    	add	w9, w8, w16
100032f3c: eb09005f    	cmp	x2, x9
100032f40: 54004f63    	b.lo	0x10003392c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xafc>
100032f44: 6b09011f    	cmp	w8, w9
100032f48: 54004fa8    	b.hi	0x10003393c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb0c>
100032f4c: cb08004f    	sub	x15, x2, x8
100032f50: d37ef50a    	lsl	x10, x8, #2
100032f54: f940668b    	ldr	x11, [x20, #0xc8]
100032f58: f10001ff    	cmp	x15, #0x0
100032f5c: 510052ec    	sub	w12, w23, #0x14
100032f60: 8b1b0313    	add	x19, x24, x27
100032f64: 9a9fc14a    	csel	x10, x10, xzr, gt
100032f68: 7100099f    	cmp	w12, #0x2
100032f6c: cb080128    	sub	x8, x9, x8
100032f70: 8b0a0178    	add	x24, x11, x10
100032f74: f9002be8    	str	x8, [sp, #0x50]
100032f78: 54000243    	b.lo	0x100032fc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x190>
100032f7c: 710042ff    	cmp	w23, #0x10
100032f80: 54000060    	b.eq	0x100032f8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x15c>
100032f84: 71004aff    	cmp	w23, #0x12
100032f88: 54000581    	b.ne	0x100033038 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x208>
100032f8c: b400248e    	cbz	x14, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100032f90: f94025c1    	ldr	x1, [x14, #0x48]
100032f94: 2a0303e8    	mov	w8, w3
100032f98: eb01011f    	cmp	x8, x1
100032f9c: 54004ae2    	b.hs	0x1000338f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xac8>
100032fa0: f94021c9    	ldr	x9, [x14, #0x40]
100032fa4: f8687928    	ldr	x8, [x9, x8, lsl #3]
100032fa8: 2a1003e9    	mov	w9, w16
100032fac: f9001be9    	str	x9, [sp, #0x30]
100032fb0: b4000388    	cbz	x8, 0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
100032fb4: f9400009    	ldr	x9, [x0]
100032fb8: 2a1003ea    	mov	w10, w16
100032fbc: 1400000c    	b	0x100032fec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1bc>
100032fc0: f9402be8    	ldr	x8, [sp, #0x50]
100032fc4: 5100060a    	sub	w10, w16, #0x1
100032fc8: eb0a011f    	cmp	x8, x10
100032fcc: 54004c89    	b.ls	0x10003395c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb2c>
100032fd0: b86a7b08    	ldr	w8, [x24, x10, lsl #2]
100032fd4: eb0801bf    	cmp	x13, x8
100032fd8: 54004bc9    	b.ls	0x100033950 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb20>
100032fdc: d37ced08    	lsl	x8, x8, #4
100032fe0: f8686a68    	ldr	x8, [x19, x8]
100032fe4: b4000e48    	cbz	x8, 0x1000331ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x37c>
100032fe8: f9400009    	ldr	x9, [x0]
100032fec: f9001bea    	str	x10, [sp, #0x30]
100032ff0: b4000629    	cbz	x9, 0x1000330b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x284>
100032ff4: f9406d2a    	ldr	x10, [x9, #0xd8]
100032ff8: eb0a011f    	cmp	x8, x10
100032ffc: 54000122    	b.hs	0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
100033000: f9406929    	ldr	x9, [x9, #0xd0]
100033004: f868792a    	ldr	x10, [x9, x8, lsl #3]
100033008: b40000ca    	cbz	x10, 0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
10003300c: 52800028    	mov	w8, #0x1                ; =1
100033010: 36000088    	tbz	w8, #0x0, 0x100033020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1f0>
100033014: f90027e0    	str	x0, [sp, #0x48]
100033018: b9000fff    	str	wzr, [sp, #0xc]
10003301c: 14000037    	b	0x1000330f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x2c8>
100033020: b0001c48    	adrp	x8, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
100033024: 9134c108    	add	x8, x8, #0xd30
100033028: a9400901    	ldp	x1, x2, [x8]
10003302c: 97fff069    	bl	0x10002f1d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
100033030: 52800074    	mov	w20, #0x3               ; =3
100033034: 140000fc    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
100033038: b4001f2e    	cbz	x14, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
10003303c: d360fc68    	lsr	x8, x3, #32
100033040: f94031c1    	ldr	x1, [x14, #0x60]
100033044: eb01011f    	cmp	x8, x1
100033048: 54004582    	b.hs	0x1000338f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xac8>
10003304c: f9402dc9    	ldr	x9, [x14, #0x58]
100033050: ab080d28    	adds	x8, x9, x8, lsl #3
100033054: 54001e40    	b.eq	0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100033058: f940010a    	ldr	x10, [x8]
10003305c: b4001e0a    	cbz	x10, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100033060: f9402be8    	ldr	x8, [sp, #0x50]
100033064: 51000609    	sub	w9, w16, #0x1
100033068: eb09011f    	cmp	x8, x9
10003306c: 540048e9    	b.ls	0x100033988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb58>
100033070: b8697b08    	ldr	w8, [x24, x9, lsl #2]
100033074: eb0801bf    	cmp	x13, x8
100033078: 540046c9    	b.ls	0x100033950 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb20>
10003307c: d37ced08    	lsl	x8, x8, #4
100033080: 3940a54b    	ldrb	w11, [x10, #0x29]
100033084: f8686a68    	ldr	x8, [x19, x8]
100033088: 7100017f    	cmp	w11, #0x0
10003308c: f940214b    	ldr	x11, [x10, #0x40]
100033090: 2a0803ec    	mov	w12, w8
100033094: 9a8c1108    	csel	x8, x8, x12, ne
100033098: eb0b011f    	cmp	x8, x11
10003309c: 54001282    	b.hs	0x1000332ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x4bc>
1000330a0: f9401d4a    	ldr	x10, [x10, #0x38]
1000330a4: f8687948    	ldr	x8, [x10, x8, lsl #3]
1000330a8: b4001ae8    	cbz	x8, 0x100033404 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5d4>
1000330ac: 2a0903ea    	mov	w10, w9
1000330b0: 17ffffce    	b	0x100032fe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1b8>
1000330b4: f90027e0    	str	x0, [sp, #0x48]
1000330b8: 52800020    	mov	w0, #0x1                ; =1
1000330bc: aa0d03fb    	mov	x27, x13
1000330c0: f90017f3    	str	x19, [sp, #0x28]
1000330c4: aa0f03fa    	mov	x26, x15
1000330c8: 2a1103f3    	mov	w19, w17
1000330cc: a90163e3    	stp	x3, x24, [sp, #0x10]
1000330d0: aa0e03f8    	mov	x24, x14
1000330d4: b90023f0    	str	w16, [sp, #0x20]
1000330d8: 94076723    	bl	0x10020cd64 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000330dc: aa1803ee    	mov	x14, x24
1000330e0: a94163e3    	ldp	x3, x24, [sp, #0x10]
1000330e4: 2a1303f1    	mov	w17, w19
1000330e8: b94023f0    	ldr	w16, [sp, #0x20]
1000330ec: f94017f3    	ldr	x19, [sp, #0x28]
1000330f0: aa1a03ef    	mov	x15, x26
1000330f4: aa1b03ed    	mov	x13, x27
1000330f8: 710056ff    	cmp	w23, #0x15
1000330fc: 54000428    	b.hi	0x100033180 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x350>
100033100: 52a00748    	mov	w8, #0x3a0000           ; =3801088
100033104: 1ad72508    	lsr	w8, w8, w23
100033108: 360003c8    	tbz	w8, #0x0, 0x100033180 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x350>
10003310c: b400188e    	cbz	x14, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100033110: f94019c1    	ldr	x1, [x14, #0x30]
100033114: 2a0303e0    	mov	w0, w3
100033118: b90013f1    	str	w17, [sp, #0x10]
10003311c: b90023f0    	str	w16, [sp, #0x20]
100033120: eb01001f    	cmp	x0, x1
100033124: f9000fef    	str	x15, [sp, #0x18]
100033128: f90017f3    	str	x19, [sp, #0x28]
10003312c: 54004322    	b.hs	0x100033990 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb60>
100033130: f94027e8    	ldr	x8, [sp, #0x48]
100033134: f94015c9    	ldr	x9, [x14, #0x28]
100033138: aa1803f3    	mov	x19, x24
10003313c: b9403941    	ldr	w1, [x10, #0x38]
100033140: aa0d03fb    	mov	x27, x13
100033144: aa0e03f8    	mov	x24, x14
100033148: f9400108    	ldr	x8, [x8]
10003314c: b8607922    	ldr	w2, [x9, x0, lsl #2]
100033150: aa0a03fa    	mov	x26, x10
100033154: aa0803e0    	mov	x0, x8
100033158: 94003efe    	bl	0x100042d50 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).FunctionSubtype>
10003315c: aa1803ee    	mov	x14, x24
100033160: aa1303f8    	mov	x24, x19
100033164: f94017f3    	ldr	x19, [sp, #0x28]
100033168: f9400fef    	ldr	x15, [sp, #0x18]
10003316c: b94023f0    	ldr	w16, [sp, #0x20]
100033170: b94013f1    	ldr	w17, [sp, #0x10]
100033174: aa1a03ea    	mov	x10, x26
100033178: aa1b03ed    	mov	x13, x27
10003317c: 36000340    	tbz	w0, #0x0, 0x1000331e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3b4>
100033180: 52a00588    	mov	w8, #0x2c0000           ; =2883584
100033184: 1ad72508    	lsr	w8, w8, w23
100033188: 0a080237    	and	w23, w17, w8
10003318c: 340003b7    	cbz	w23, 0x100033200 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3d0>
100033190: a942db28    	ldp	x8, x22, [x25, #0x28]
100033194: 2a1003fb    	mov	w27, w16
100033198: aa0a03fa    	mov	x26, x10
10003319c: aa0f03fc    	mov	x28, x15
1000331a0: 91008334    	add	x20, x25, #0x20
1000331a4: a901b7ee    	stp	x14, x13, [sp, #0x18]
1000331a8: 1400002a    	b	0x100033250 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x420>
1000331ac: b94006c2    	ldr	w2, [x22, #0x4]
1000331b0: aa1c03e1    	mov	x1, x28
1000331b4: 52800123    	mov	w3, #0x9                ; =9
1000331b8: 1400000f    	b	0x1000331f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3c4>
1000331bc: f90027e0    	str	x0, [sp, #0x48]
1000331c0: 52800020    	mov	w0, #0x1                ; =1
1000331c4: aa0d03f3    	mov	x19, x13
1000331c8: aa0e03fa    	mov	x26, x14
1000331cc: 940766e6    	bl	0x10020cd64 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000331d0: f94027e0    	ldr	x0, [sp, #0x48]
1000331d4: aa1a03ee    	mov	x14, x26
1000331d8: aa1303ed    	mov	x13, x19
1000331dc: aa1f03e3    	mov	x3, xzr
1000331e0: 17ffff52    	b	0x100032f28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xf8>
1000331e4: b94006c2    	ldr	w2, [x22, #0x4]
1000331e8: f94027e0    	ldr	x0, [sp, #0x48]
1000331ec: aa1c03e1    	mov	x1, x28
1000331f0: 528000a3    	mov	w3, #0x5                ; =5
1000331f4: 94000663    	bl	0x100034b80 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
1000331f8: 52800074    	mov	w20, #0x3               ; =3
1000331fc: 1400008a    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
100033200: b9400fe8    	ldr	w8, [sp, #0xc]
100033204: 370010c8    	tbnz	w8, #0x0, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100033208: 294326c8    	ldp	w8, w9, [x22, #0x18]
10003320c: aa0a03fa    	mov	x26, x10
100033210: b940294a    	ldr	w10, [x10, #0x28]
100033214: f9406681    	ldr	x1, [x20, #0xc8]
100033218: f9406e83    	ldr	x3, [x20, #0xd8]
10003321c: 2a1f03e6    	mov	w6, wzr
100033220: 2a1f03e7    	mov	w7, wzr
100033224: 0b080124    	add	w4, w9, w8
100033228: 910403e0    	add	x0, sp, #0x100
10003322c: 52800082    	mov	w2, #0x4                ; =4
100033230: 0b0a0085    	add	w5, w4, w10
100033234: 2a1003fb    	mov	w27, w16
100033238: aa0f03fc    	mov	x28, x15
10003323c: a901b7ee    	stp	x14, x13, [sp, #0x18]
100033240: 910403f4    	add	x20, sp, #0x100
100033244: 390003ff    	strb	wzr, [sp]
100033248: 94079f27    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10003324c: a950dbe8    	ldp	x8, x22, [sp, #0x108]
100033250: f90017e8    	str	x8, [sp, #0x28]
100033254: f94027e0    	ldr	x0, [sp, #0x48]
100033258: f9400294    	ldr	x20, [x20]
10003325c: 9400061f    	bl	0x100034ad8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
100033260: b40000e0    	cbz	x0, 0x10003327c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x44c>
100033264: f9400409    	ldr	x9, [x0, #0x8]
100033268: aa0003e8    	mov	x8, x0
10003326c: b4000089    	cbz	x9, 0x10003327c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x44c>
100033270: f94027e0    	ldr	x0, [sp, #0x48]
100033274: aa0103e2    	mov	x2, x1
100033278: 140000d4    	b	0x1000335c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x798>
10003327c: f9402749    	ldr	x9, [x26, #0x48]
100033280: aa1a03e1    	mov	x1, x26
100033284: 34000417    	cbz	w23, 0x100033304 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x4d4>
100033288: f94027e8    	ldr	x8, [sp, #0x48]
10003328c: b40009c9    	cbz	x9, 0x1000333c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x594>
100033290: b9400fea    	ldr	w10, [sp, #0xc]
100033294: 37000c4a    	tbnz	w10, #0x0, 0x10003341c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5ec>
100033298: f9404d29    	ldr	x9, [x9, #0x98]
10003329c: f94033eb    	ldr	x11, [sp, #0x60]
1000332a0: b9401d0a    	ldr	w10, [x8, #0x1c]
1000332a4: 8b0b0129    	add	x9, x9, x11
1000332a8: eb0a013f    	cmp	x9, x10
1000332ac: 540008c9    	b.ls	0x1000333c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x594>
1000332b0: 52800500    	mov	w0, #0x28               ; =40
1000332b4: aa0803f3    	mov	x19, x8
1000332b8: 9407661f    	bl	0x10020cb34 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
1000332bc: b0001c48    	adrp	x8, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
1000332c0: 52800229    	mov	w9, #0x11               ; =17
1000332c4: aa0003e2    	mov	x2, x0
1000332c8: 3dc38500    	ldr	q0, [x8, #0xe10]
1000332cc: f0001308    	adrp	x8, 0x100296000 <dyld_stub_binder+0x100296000>
1000332d0: 911d7908    	add	x8, x8, #0x75e
1000332d4: a901a408    	stp	x8, x9, [x0, #0x18]
1000332d8: f00015c1    	adrp	x1, 0x1002ee000 <__llgo_struct$IjaMTlBusI6Vzz2BLhvn1zSVeFyKXdIPkn8c9So1YdM+0x38>
1000332dc: 91314021    	add	x1, x1, #0xc50
1000332e0: 3d800000    	str	q0, [x0]
1000332e4: aa1303e0    	mov	x0, x19
1000332e8: 17ffff51    	b	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1fc>
1000332ec: b94006c2    	ldr	w2, [x22, #0x4]
1000332f0: aa1c03e1    	mov	x1, x28
1000332f4: 52800063    	mov	w3, #0x3                ; =3
1000332f8: 52800074    	mov	w20, #0x3               ; =3
1000332fc: 94000621    	bl	0x100034b80 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
100033300: 14000049    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
100033304: f94027e0    	ldr	x0, [sp, #0x48]
100033308: b4000869    	cbz	x9, 0x100033414 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5e4>
10003330c: f94023ea    	ldr	x10, [sp, #0x40]
100033310: f9415c09    	ldr	x9, [x0, #0x2b8]
100033314: 9103a3e2    	add	x2, sp, #0xe8
100033318: f9007ff6    	str	x22, [sp, #0xf8]
10003331c: 11000548    	add	w8, w10, #0x1
100033320: f9001f29    	str	x9, [x25, #0x38]
100033324: 29012b28    	stp	w8, w10, [x25, #0x8]
100033328: 52800028    	mov	w8, #0x1                ; =1
10003332c: 39004328    	strb	w8, [x25, #0x10]
100033330: f94017e8    	ldr	x8, [sp, #0x28]
100033334: a90ea3f4    	stp	x20, x8, [sp, #0xe8]
100033338: aa0003f4    	mov	x20, x0
10003333c: 94001351    	bl	0x100038080 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push>
100033340: b4000080    	cbz	x0, 0x100033350 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x520>
100033344: f9400409    	ldr	x9, [x0, #0x8]
100033348: aa0003e8    	mov	x8, x0
10003334c: b50013a9    	cbnz	x9, 0x1000335c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x790>
100033350: f9402688    	ldr	x8, [x20, #0x48]
100033354: d1000500    	sub	x0, x8, #0x1
100033358: b4003288    	cbz	x8, 0x1000339a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb78>
10003335c: f9401bea    	ldr	x10, [sp, #0x30]
100033360: 3400214a    	cbz	w10, 0x100033788 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x958>
100033364: f9402288    	ldr	x8, [x20, #0x40]
100033368: f9402beb    	ldr	x11, [sp, #0x50]
10003336c: aa1403e9    	mov	x9, x20
100033370: 2a0a03ea    	mov	w10, w10
100033374: 8b001908    	add	x8, x8, x0, lsl #6
100033378: f9400d00    	ldr	x0, [x8, #0x18]
10003337c: b4002fcb    	cbz	x11, 0x100033974 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb44>
100033380: b8404708    	ldr	w8, [x24], #0x4
100033384: f94033ec    	ldr	x12, [sp, #0x60]
100033388: f9404121    	ldr	x1, [x9, #0x80]
10003338c: 8b080188    	add	x8, x12, x8
100033390: eb01011f    	cmp	x8, x1
100033394: 54002f62    	b.hs	0x100033980 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb50>
100033398: eb01001f    	cmp	x0, x1
10003339c: 54003122    	b.hs	0x1000339c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb90>
1000333a0: f9403d2c    	ldr	x12, [x9, #0x78]
1000333a4: 2a1f03f4    	mov	w20, wzr
1000333a8: d100054a    	sub	x10, x10, #0x1
1000333ac: d100056b    	sub	x11, x11, #0x1
1000333b0: 3ce87980    	ldr	q0, [x12, x8, lsl #4]
1000333b4: 3ca07980    	str	q0, [x12, x0, lsl #4]
1000333b8: 91000400    	add	x0, x0, #0x1
1000333bc: b5fffe0a    	cbnz	x10, 0x10003337c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x54c>
1000333c0: 14000019    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
1000333c4: f9401be9    	ldr	x9, [sp, #0x30]
1000333c8: f9405d03    	ldr	x3, [x8, #0xb8]
1000333cc: aa0103fa    	mov	x26, x1
1000333d0: f9002bf4    	str	x20, [sp, #0x50]
1000333d4: 2a0903f7    	mov	w23, w9
1000333d8: eb17007f    	cmp	x3, x23
1000333dc: 5400036a    	b.ge	0x100033448 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x618>
1000333e0: 9101c3e0    	add	x0, sp, #0x70
1000333e4: aa1703e1    	mov	x1, x23
1000333e8: aa1703e2    	mov	x2, x23
1000333ec: 52800203    	mov	w3, #0x10               ; =16
1000333f0: 2a1f03e4    	mov	w4, wzr
1000333f4: aa0803f4    	mov	x20, x8
1000333f8: 9101c3f9    	add	x25, sp, #0x70
1000333fc: 940799ae    	bl	0x100219ab4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.MakeSlice>
100033400: 1400001d    	b	0x100033474 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x644>
100033404: b94006c2    	ldr	w2, [x22, #0x4]
100033408: aa1c03e1    	mov	x1, x28
10003340c: 52800083    	mov	w3, #0x4                ; =4
100033410: 17ffff79    	b	0x1000331f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x3c4>
100033414: b9400fe8    	ldr	w8, [sp, #0xc]
100033418: 36001588    	tbz	w8, #0x0, 0x1000336c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x898>
10003341c: 52800020    	mov	w0, #0x1                ; =1
100033420: 94076651    	bl	0x10020cd64 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100033424: 2a1403e0    	mov	w0, w20
100033428: 9108c3ff    	add	sp, sp, #0x230
10003342c: a9457bfd    	ldp	x29, x30, [sp, #0x50]
100033430: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100033434: a94357f6    	ldp	x22, x21, [sp, #0x30]
100033438: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10003343c: a94167fa    	ldp	x26, x25, [sp, #0x10]
100033440: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100033444: d65f03c0    	ret
100033448: f9405501    	ldr	x1, [x8, #0xa8]
10003344c: aa1f03e4    	mov	x4, xzr
100033450: 2a1f03e7    	mov	w7, wzr
100033454: d10363a0    	sub	x0, x29, #0xd8
100033458: 52800202    	mov	w2, #0x10               ; =16
10003345c: aa1703e5    	mov	x5, x23
100033460: 52800026    	mov	w6, #0x1                ; =1
100033464: aa0803f4    	mov	x20, x8
100033468: 390003ff    	strb	wzr, [sp]
10003346c: d10363b9    	sub	x25, x29, #0xd8
100033470: 94079e9d    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100033474: f9400328    	ldr	x8, [x25]
100033478: 3cc08320    	ldur	q0, [x25, #0x8]
10003347c: 910223e0    	add	x0, sp, #0x88
100033480: aa1803e1    	mov	x1, x24
100033484: 52800082    	mov	w2, #0x4                ; =4
100033488: aa1c03e3    	mov	x3, x28
10003348c: aa1f03e4    	mov	x4, xzr
100033490: aa1703e5    	mov	x5, x23
100033494: 52800026    	mov	w6, #0x1                ; =1
100033498: 2a1f03e7    	mov	w7, wzr
10003349c: f9005688    	str	x8, [x20, #0xa8]
1000334a0: 3d802e80    	str	q0, [x20, #0xb0]
1000334a4: 390003ff    	strb	wzr, [sp]
1000334a8: 94079e8f    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000334ac: f9404be9    	ldr	x9, [sp, #0x90]
1000334b0: f94013fb    	ldr	x27, [sp, #0x20]
1000334b4: f100053f    	cmp	x9, #0x1
1000334b8: 540001eb    	b.lt	0x1000334f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x6c4>
1000334bc: f94047ea    	ldr	x10, [sp, #0x88]
1000334c0: aa1f03e0    	mov	x0, xzr
1000334c4: b8607948    	ldr	w8, [x10, x0, lsl #2]
1000334c8: eb08037f    	cmp	x27, x8
1000334cc: 540024e9    	b.ls	0x100033968 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb38>
1000334d0: f9405a81    	ldr	x1, [x20, #0xb0]
1000334d4: eb01001f    	cmp	x0, x1
1000334d8: 54002742    	b.hs	0x1000339c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb90>
1000334dc: f940568b    	ldr	x11, [x20, #0xa8]
1000334e0: 3ce87a60    	ldr	q0, [x19, x8, lsl #4]
1000334e4: 3ca07960    	str	q0, [x11, x0, lsl #4]
1000334e8: 91000400    	add	x0, x0, #0x1
1000334ec: eb00013f    	cmp	x9, x0
1000334f0: 54fffea1    	b.ne	0x1000334c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x694>
1000334f4: f9403e81    	ldr	x1, [x20, #0x78]
1000334f8: f9404683    	ldr	x3, [x20, #0x88]
1000334fc: d10303a0    	sub	x0, x29, #0xc0
100033500: f94033e5    	ldr	x5, [sp, #0x60]
100033504: 52800202    	mov	w2, #0x10               ; =16
100033508: aa1f03e4    	mov	x4, xzr
10003350c: 52800026    	mov	w6, #0x1                ; =1
100033510: 52800027    	mov	w7, #0x1                ; =1
100033514: 390003ff    	strb	wzr, [sp]
100033518: 94079e73    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
10003351c: f9402681    	ldr	x1, [x20, #0x48]
100033520: 910463f3    	add	x19, sp, #0x118
100033524: f85403a9    	ldur	x9, [x29, #-0xc0]
100033528: 3ccb0260    	ldur	q0, [x19, #0xb0]
10003352c: eb0102bf    	cmp	x21, x1
100033530: f9003e89    	str	x9, [x20, #0x78]
100033534: 3d802280    	str	q0, [x20, #0x80]
100033538: 54002342    	b.hs	0x1000339a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb70>
10003353c: f9402289    	ldr	x9, [x20, #0x40]
100033540: 6f00e400    	movi.2d	v0, #0000000000000000
100033544: d102a3a0    	sub	x0, x29, #0xa8
100033548: 52800802    	mov	w2, #0x40               ; =64
10003354c: aa1f03e4    	mov	x4, xzr
100033550: aa1503e5    	mov	x5, x21
100033554: 8b151929    	add	x9, x9, x21, lsl #6
100033558: 52800026    	mov	w6, #0x1                ; =1
10003355c: 52800027    	mov	w7, #0x1                ; =1
100033560: ad000120    	stp	q0, q0, [x9]
100033564: ad010120    	stp	q0, q0, [x9, #0x20]
100033568: f9402281    	ldr	x1, [x20, #0x40]
10003356c: f9402a83    	ldr	x3, [x20, #0x50]
100033570: 390003ff    	strb	wzr, [sp]
100033574: 94079e5c    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
100033578: f85583a8    	ldur	x8, [x29, #-0xa8]
10003357c: 3ccc8260    	ldur	q0, [x19, #0xc8]
100033580: aa1403e0    	mov	x0, x20
100033584: f9002288    	str	x8, [x20, #0x40]
100033588: 3c848280    	stur	q0, [x20, #0x48]
10003358c: f9402748    	ldr	x8, [x26, #0x48]
100033590: b4000588    	cbz	x8, 0x100033640 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x810>
100033594: f9402be9    	ldr	x9, [sp, #0x50]
100033598: f94017e8    	ldr	x8, [sp, #0x28]
10003359c: 910283e2    	add	x2, sp, #0xa0
1000335a0: aa1a03e1    	mov	x1, x26
1000335a4: f9005bf6    	str	x22, [sp, #0xb0]
1000335a8: a90a23e9    	stp	x9, x8, [sp, #0xa0]
1000335ac: 940012b5    	bl	0x100038080 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).push>
1000335b0: b4000100    	cbz	x0, 0x1000335d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x7a0>
1000335b4: f9400409    	ldr	x9, [x0, #0x8]
1000335b8: aa0003e8    	mov	x8, x0
1000335bc: b40000a9    	cbz	x9, 0x1000335d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x7a0>
1000335c0: aa0103e2    	mov	x2, x1
1000335c4: aa1403e0    	mov	x0, x20
1000335c8: aa0803e1    	mov	x1, x8
1000335cc: 17fffe98    	b	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1fc>
1000335d0: a9479681    	ldp	x1, x5, [x20, #0x78]
1000335d4: d101e3a0    	sub	x0, x29, #0x78
1000335d8: f9404683    	ldr	x3, [x20, #0x88]
1000335dc: f94033e4    	ldr	x4, [sp, #0x60]
1000335e0: 52800202    	mov	w2, #0x10               ; =16
1000335e4: 52800026    	mov	w6, #0x1                ; =1
1000335e8: 52800027    	mov	w7, #0x1                ; =1
1000335ec: 390003ff    	strb	wzr, [sp]
1000335f0: 94079e3d    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000335f4: a94aa688    	ldp	x8, x9, [x20, #0xa8]
1000335f8: f85903aa    	ldur	x10, [x29, #-0x70]
1000335fc: eb09015f    	cmp	x10, x9
100033600: 9a89b14a    	csel	x10, x10, x9, lt
100033604: f100055f    	cmp	x10, #0x1
100033608: 540000cb    	b.lt	0x100033620 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x7f0>
10003360c: f85883a0    	ldur	x0, [x29, #-0x78]
100033610: d37ced42    	lsl	x2, x10, #4
100033614: aa0803e1    	mov	x1, x8
100033618: 9407b7b1    	bl	0x1002214dc <dyld_stub_binder+0x1002214dc>
10003361c: f9405688    	ldr	x8, [x20, #0xa8]
100033620: aa1403e9    	mov	x9, x20
100033624: f9405a8a    	ldr	x10, [x20, #0xb0]
100033628: aa0803e0    	mov	x0, x8
10003362c: aa0903f3    	mov	x19, x9
100033630: d37ced41    	lsl	x1, x10, #4
100033634: 9407b7f2    	bl	0x1002215fc <dyld_stub_binder+0x1002215fc>
100033638: 2a1f03f4    	mov	w20, wzr
10003363c: 1400001e    	b	0x1000336b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x884>
100033640: f9405803    	ldr	x3, [x0, #0xb0]
100033644: f9400fe2    	ldr	x2, [sp, #0x18]
100033648: d10243a8    	sub	x8, x29, #0x90
10003364c: aa1403e0    	mov	x0, x20
100033650: aa1a03e1    	mov	x1, x26
100033654: 94001359    	bl	0x1000383b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).prepareHost>
100033658: a94aa688    	ldp	x8, x9, [x20, #0xa8]
10003365c: f85783aa    	ldur	x10, [x29, #-0x88]
100033660: eb09015f    	cmp	x10, x9
100033664: 9a89b14a    	csel	x10, x10, x9, lt
100033668: f100055f    	cmp	x10, #0x1
10003366c: 540000cb    	b.lt	0x100033684 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x854>
100033670: f85703a0    	ldur	x0, [x29, #-0x90]
100033674: d37ced42    	lsl	x2, x10, #4
100033678: aa0803e1    	mov	x1, x8
10003367c: 9407b798    	bl	0x1002214dc <dyld_stub_binder+0x1002214dc>
100033680: f9405688    	ldr	x8, [x20, #0xa8]
100033684: aa1403e9    	mov	x9, x20
100033688: f9405a8a    	ldr	x10, [x20, #0xb0]
10003368c: f9402beb    	ldr	x11, [sp, #0x50]
100033690: 52800054    	mov	w20, #0x2               ; =2
100033694: aa0803e0    	mov	x0, x8
100033698: 3904e134    	strb	w20, [x9, #0x138]
10003369c: aa0903f3    	mov	x19, x9
1000336a0: f900912b    	str	x11, [x9, #0x120]
1000336a4: f94017eb    	ldr	x11, [sp, #0x28]
1000336a8: d37ced41    	lsl	x1, x10, #4
1000336ac: a912d92b    	stp	x11, x22, [x9, #0x128]
1000336b0: 9407b7d3    	bl	0x1002215fc <dyld_stub_binder+0x1002215fc>
1000336b4: 6f00e400    	movi.2d	v0, #0000000000000000
1000336b8: 9102e268    	add	x8, x19, #0xb8
1000336bc: 4d408500    	ld1.d	{ v0 }[1], [x8]
1000336c0: 3d802e60    	str	q0, [x19, #0xb0]
1000336c4: 17ffff58    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
1000336c8: a945d428    	ldp	x8, x21, [x1, #0x58]
1000336cc: d00014e9    	adrp	x9, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
1000336d0: 91086129    	add	x9, x9, #0x218
1000336d4: eb09011f    	cmp	x8, x9
1000336d8: 540005c0    	b.eq	0x100033790 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x960>
1000336dc: d00014e9    	adrp	x9, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0x58>
1000336e0: 91164129    	add	x9, x9, #0x590
1000336e4: aa1403f7    	mov	x23, x20
1000336e8: eb09011f    	cmp	x8, x9
1000336ec: 54000b20    	b.eq	0x100033850 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa20>
1000336f0: f94023ea    	ldr	x10, [sp, #0x40]
1000336f4: f9415c09    	ldr	x9, [x0, #0x2b8]
1000336f8: aa0003f4    	mov	x20, x0
1000336fc: f9400fe2    	ldr	x2, [sp, #0x18]
100033700: 11000548    	add	w8, w10, #0x1
100033704: f9001f29    	str	x9, [x25, #0x38]
100033708: f9401be9    	ldr	x9, [sp, #0x30]
10003370c: 29012b28    	stp	w8, w10, [x25, #0x8]
100033710: 52800028    	mov	w8, #0x1                ; =1
100033714: 2a0903e3    	mov	w3, w9
100033718: 39004328    	strb	w8, [x25, #0x10]
10003371c: 910343e8    	add	x8, sp, #0xd0
100033720: 94001326    	bl	0x1000383b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).prepareHost>
100033724: f9406fe9    	ldr	x9, [sp, #0xd8]
100033728: aa1403e8    	mov	x8, x20
10003372c: f100053f    	cmp	x9, #0x1
100033730: 5400020b    	b.lt	0x100033770 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x940>
100033734: f9406bea    	ldr	x10, [sp, #0xd0]
100033738: f9402beb    	ldr	x11, [sp, #0x50]
10003373c: f94033ed    	ldr	x13, [sp, #0x60]
100033740: b40012ab    	cbz	x11, 0x100033994 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb64>
100033744: b840470c    	ldr	w12, [x24], #0x4
100033748: f9404101    	ldr	x1, [x8, #0x80]
10003374c: 8b0c01a0    	add	x0, x13, x12
100033750: eb01001f    	cmp	x0, x1
100033754: 54001362    	b.hs	0x1000339c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb90>
100033758: f9403d0c    	ldr	x12, [x8, #0x78]
10003375c: d1000529    	sub	x9, x9, #0x1
100033760: d100056b    	sub	x11, x11, #0x1
100033764: 3ce07980    	ldr	q0, [x12, x0, lsl #4]
100033768: 3c810540    	str	q0, [x10], #0x10
10003376c: b5fffea9    	cbnz	x9, 0x100033740 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x910>
100033770: f94017e9    	ldr	x9, [sp, #0x28]
100033774: 52800054    	mov	w20, #0x2               ; =2
100033778: f9009916    	str	x22, [x8, #0x130]
10003377c: 3904e114    	strb	w20, [x8, #0x138]
100033780: a9122517    	stp	x23, x9, [x8, #0x120]
100033784: 17ffff28    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
100033788: 2a1f03f4    	mov	w20, wzr
10003378c: 17ffff26    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
100033790: f9401be8    	ldr	x8, [sp, #0x30]
100033794: aa1303fa    	mov	x26, x19
100033798: 3cc08021    	ldur	q1, [x1, #0x8]
10003379c: 3cc18020    	ldur	q0, [x1, #0x18]
1000337a0: aa1403f3    	mov	x19, x20
1000337a4: f90027e0    	str	x0, [sp, #0x48]
1000337a8: a942dc34    	ldp	x20, x23, [x1, #0x28]
1000337ac: 2a0803e5    	mov	w5, w8
1000337b0: 910463e0    	add	x0, sp, #0x118
1000337b4: aa1803e1    	mov	x1, x24
1000337b8: 52800082    	mov	w2, #0x4                ; =4
1000337bc: aa1c03e3    	mov	x3, x28
1000337c0: aa1f03e4    	mov	x4, xzr
1000337c4: 52800026    	mov	w6, #0x1                ; =1
1000337c8: 2a1f03e7    	mov	w7, wzr
1000337cc: ad0287e0    	stp	q0, q1, [sp, #0x50]
1000337d0: 910463f8    	add	x24, sp, #0x118
1000337d4: 390003ff    	strb	wzr, [sp]
1000337d8: 94079dc3    	bl	0x10021aee4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.NewSlice2>
1000337dc: f9408fe8    	ldr	x8, [sp, #0x118]
1000337e0: ad4287e0    	ldp	q0, q1, [sp, #0x50]
1000337e4: 9105e3e1    	add	x1, sp, #0x178
1000337e8: 910583e2    	add	x2, sp, #0x160
1000337ec: 910523e3    	add	x3, sp, #0x148
1000337f0: a915a3f6    	stp	x22, x8, [sp, #0x158]
1000337f4: a94227e8    	ldp	x8, x9, [sp, #0x20]
1000337f8: ad030301    	stp	q1, q0, [x24, #0x60]
1000337fc: 3cc08300    	ldur	q0, [x24, #0x8]
100033800: 9104c3e4    	add	x4, sp, #0x130
100033804: aa1503e0    	mov	x0, x21
100033808: a919dff4    	stp	x20, x23, [sp, #0x198]
10003380c: a91323fa    	stp	x26, x8, [sp, #0x130]
100033810: f9401fe8    	ldr	x8, [sp, #0x38]
100033814: 3c850300    	stur	q0, [x24, #0x50]
100033818: a914a7f3    	stp	x19, x9, [sp, #0x148]
10003381c: f900a3e8    	str	x8, [sp, #0x140]
100033820: 94004729    	bl	0x1000454c4 <_github.com/cpunion/wasmvm/internal/engine/state.(*ScalarLeaf).CallSlots>
100033824: b4000080    	cbz	x0, 0x100033834 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa04>
100033828: f9400409    	ldr	x9, [x0, #0x8]
10003382c: aa0003e8    	mov	x8, x0
100033830: b5ffd209    	cbnz	x9, 0x100033270 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x440>
100033834: f94027e0    	ldr	x0, [sp, #0x48]
100033838: 940004a8    	bl	0x100034ad8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
10003383c: b40004e0    	cbz	x0, 0x1000338d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaa8>
100033840: f9400409    	ldr	x9, [x0, #0x8]
100033844: aa0003e8    	mov	x8, x0
100033848: b5ffd149    	cbnz	x9, 0x100033270 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x440>
10003384c: 14000023    	b	0x1000338d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaa8>
100033850: 394062a8    	ldrb	w8, [x21, #0x18]
100033854: aa1303f4    	mov	x20, x19
100033858: 34000148    	cbz	w8, 0x100033880 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa50>
10003385c: 34000abb    	cbz	w27, 0x1000339b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb80>
100033860: aa0003f3    	mov	x19, x0
100033864: b9400300    	ldr	w0, [x24]
100033868: f94013e8    	ldr	x8, [sp, #0x20]
10003386c: eb00011f    	cmp	x8, x0
100033870: 54000a69    	b.ls	0x1000339bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb8c>
100033874: d37cec08    	lsl	x8, x0, #4
100033878: f8686a81    	ldr	x1, [x20, x8]
10003387c: 14000003    	b	0x100033888 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa58>
100033880: aa0003f3    	mov	x19, x0
100033884: aa1f03e1    	mov	x1, xzr
100033888: 9102e3e8    	add	x8, sp, #0xb8
10003388c: aa1503e0    	mov	x0, x21
100033890: 94004698    	bl	0x1000452f0 <_github.com/cpunion/wasmvm/internal/engine/state.(*ScalarAccess).Access>
100033894: a94b87e8    	ldp	x8, x1, [sp, #0xb8]
100033898: b40000c1    	cbz	x1, 0x1000338b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa80>
10003389c: f9400429    	ldr	x9, [x1, #0x8]
1000338a0: b4000089    	cbz	x9, 0x1000338b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xa80>
1000338a4: f94067e2    	ldr	x2, [sp, #0xc8]
1000338a8: aa1303e0    	mov	x0, x19
1000338ac: 17fffde0    	b	0x10003302c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x1fc>
1000338b0: 394062a9    	ldrb	w9, [x21, #0x18]
1000338b4: 37000129    	tbnz	w9, #0x0, 0x1000338d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xaa8>
1000338b8: f94017e9    	ldr	x9, [sp, #0x28]
1000338bc: b40007a9    	cbz	x9, 0x1000339b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb80>
1000338c0: b94002e0    	ldr	w0, [x23]
1000338c4: f94013e9    	ldr	x9, [sp, #0x20]
1000338c8: eb00013f    	cmp	x9, x0
1000338cc: 54000789    	b.ls	0x1000339bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0xb8c>
1000338d0: 8b001289    	add	x9, x20, x0, lsl #4
1000338d4: a9007d28    	stp	x8, xzr, [x9]
1000338d8: f94023e8    	ldr	x8, [sp, #0x40]
1000338dc: 2a1f03f4    	mov	w20, wzr
1000338e0: 11000508    	add	w8, w8, #0x1
1000338e4: b9000b28    	str	w8, [x25, #0x8]
1000338e8: 17fffecf    	b	0x100033424 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall+0x5f4>
1000338ec: aa1503e0    	mov	x0, x21
1000338f0: aa1f03e1    	mov	x1, xzr
1000338f4: 9407540d    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000338f8: aa0803e0    	mov	x0, x8
1000338fc: 94075978    	bl	0x100209edc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033900: aa0903e0    	mov	x0, x9
100033904: 94075976    	bl	0x100209edc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033908: aa0803e0    	mov	x0, x8
10003390c: 52800021    	mov	w1, #0x1                ; =1
100033910: 52800043    	mov	w3, #0x2                ; =2
100033914: 9407574b    	bl	0x100209640 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033918: f94033e0    	ldr	x0, [sp, #0x60]
10003391c: 52800021    	mov	w1, #0x1                ; =1
100033920: aa0803e2    	mov	x2, x8
100033924: 52800063    	mov	w3, #0x3                ; =3
100033928: 94075746    	bl	0x100209640 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003392c: aa0903e0    	mov	x0, x9
100033930: 2a1f03e1    	mov	w1, wzr
100033934: 52800043    	mov	w3, #0x2                ; =2
100033938: 94075742    	bl	0x100209640 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003393c: aa0803e0    	mov	x0, x8
100033940: 2a1f03e1    	mov	w1, wzr
100033944: aa0903e2    	mov	x2, x9
100033948: 52800063    	mov	w3, #0x3                ; =3
10003394c: 9407573d    	bl	0x100209640 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100033950: aa0803e0    	mov	x0, x8
100033954: aa0d03e1    	mov	x1, x13
100033958: 940753f4    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003395c: f9402be1    	ldr	x1, [sp, #0x50]
100033960: aa0a03e0    	mov	x0, x10
100033964: 9407595e    	bl	0x100209edc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033968: aa0803e0    	mov	x0, x8
10003396c: aa1b03e1    	mov	x1, x27
100033970: 940753ee    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033974: f9402be0    	ldr	x0, [sp, #0x50]
100033978: aa0003e1    	mov	x1, x0
10003397c: 94075958    	bl	0x100209edc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033980: aa0803e0    	mov	x0, x8
100033984: 940753e9    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100033988: f9402be1    	ldr	x1, [sp, #0x50]
10003398c: aa0903e0    	mov	x0, x9
100033990: 94075953    	bl	0x100209edc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100033994: f9402be0    	ldr	x0, [sp, #0x50]
100033998: aa0003e1    	mov	x1, x0
10003399c: 940753e3    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339a0: aa1503e0    	mov	x0, x21
1000339a4: 940753e1    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339a8: aa1f03e1    	mov	x1, xzr
1000339ac: 940753df    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339b0: aa1f03e0    	mov	x0, xzr
1000339b4: aa1f03e1    	mov	x1, xzr
1000339b8: 940753dc    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000339bc: f94013e1    	ldr	x1, [sp, #0x20]
1000339c0: 940753da    	bl	0x100208928 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
