from pathlib import Path
import hashlib,json,subprocess
out=Path(__file__).resolve().parent
previous=Path("/Users/lijie/source/goplus/wasmvm/artifacts/p3-leaf-boundaries-20261121/full-v2")
plan=json.loads((previous/"core-plan.json").read_text())
cases=[]
sha={}
for source in plan["cases"]:
    f=source["fixture"]
    key=f["cohort"]+"/"+f["id"]
    if key not in ("gc-sustained-v1/gc/struct-indirect-access","original22-v1/gc/struct-indirect-access"):
        continue
    commands={}
    for side in ("base","head"):
        original=source["commands"][side+"-go-interpreter"].copy()
        if side=="head":
            original[0]=str(out.parent/"head-go-phase")
        original[original.index("--samples")+1]="6"
        commands[side+"-go-default"]=original
        aligned=original.copy()
        aligned[0]=str(out/(side+"-alignment"))
        commands[side+"-go-aligned"]=aligned
        for cmd in (original,aligned):
            sha[cmd[0]]=hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()
    cases.append(dict(fixture=f,id=key,commands=commands))
assert len(cases)==2
infos={}
for path in sha:
    result=subprocess.check_output(["go","tool","nm",path],text=True)
    names=("runSlotsLoop","GCAccess","StructGet")
    infos[path]=[line.strip() for line in result.splitlines() if any(line.endswith("."+name) for name in names)]
(out/"symbols.json").write_text(json.dumps(infos,indent=2)+"\n")
(out/"frozen-plan.json").write_text(json.dumps(dict(blocks=6,samples=5,seed=202611218741,cases=cases,binarySHA256=sha,
    scope="Separate source-paired GC interpreter layout diagnostic. Both source revisions are linked with either default flags or -funcalign=64."),indent=2)+"\n")
