from pathlib import Path
import json, subprocess

out=Path(__file__).resolve().parent
v2=Path("/Users/lijie/source/goplus/wasmvm/artifacts/p3-leaf-boundaries-20261121/full-v2")
w=Path("/Users/lijie/source/goplus/wasmvm-source-cleanup")
data=json.loads((v2/"head-go-overlay.json").read_text())
changes={str(w/f.relative_to(v2/"base-overrides")):str(f) for f in (v2/"base-overrides").rglob("*.go")}
prior=Path("/Users/lijie/source/goplus/wasmvm")/"artifacts/sha-hot-path-20261121/full"
for role in ("base","head"):
    overlay=json.loads(json.dumps(data))
    if role=="base":
        overlay["Replace"].update(changes)
        for name, file in [("phase","phase.go"),("provenance","provenance_gen.go")]:
            overlay["Replace"][str(w/"internal/bench/phase"/file)]=str(prior/("head-go-"+name+".go"))
    path=out/(role+"-overlay.json")
    path.write_text(json.dumps(overlay,indent=2)+"\n")
    args=["go","build","-ldflags=-funcalign=64","-overlay",str(path),"-o",str(out/(role+"-alignment")),"."]
    (out/(role+"-command.json")).write_text(json.dumps(args)+"\n")
    with (out/(role+"-build.log")).open("w")as log:
        subprocess.run(args,cwd=w/"benchmarks/embedded/wasmvm",stdout=log,stderr=subprocess.STDOUT,check=True,timeout=200)
    print(role,"aligned")
