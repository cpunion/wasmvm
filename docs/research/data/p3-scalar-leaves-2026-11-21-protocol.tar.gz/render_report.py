from pathlib import Path
import json,sys
sys.path.insert(0,"/Users/lijie/source/goplus/wasmvm-source-cleanup/benchmarks")
import comparison_format as fmt
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');stem='p3-scalar-leaves-2026-11-21';data=json.loads((w/'docs/research/data'/f'{stem}.json').read_text());core=data['core']['results'];p3=data['p3']['results'];out=[]
def add(s=''):out.append(s)
def table(headers,rows):
 add('| '+' | '.join(headers)+' |');add('| '+' | '.join(['---']+['---:']*(len(headers)-1))+' |')
 for row in rows:add('| '+' | '.join(map(str,row))+' |')
 add()
def num(v):return f'{v:,.3f}'if abs(v)<100 else f'{v:,.2f}'
def ratio(v, **kwargs):return fmt.comparison(v, **kwargs)
headers=['Workload / metric','wasmvm Go','wasmvm LLGo','wazero','Wasmtime','Wasmer','WasmEdge']
roles={'native':['head-go-native','head-llgo-native','wazero-compiler','wasmtime-compiler','wasmer-compiler','wasmedge-compiler'],'interpreter':['head-go-interpreter','head-llgo-interpreter','wazero-interpreter',None,None,'wasmedge-interpreter']}
failed={(x['cohort']+'/'+x['case'],x['runtime'])for x in data['failures']['failures']}
def unavailable(key,role):
 if role is None:return 'NM'
 if (key,role)in failed:return '**FAIL: SIGSEGV**'
 return 'US'
def cell(key,role,phase=None):
 v=core[key]
 if role not in v['mediansNsPerIteration']:return unavailable(key,role)
 if phase is not None:
  n=v['phasesMedianNs'][role].get(phase);return 'N/A'if n is None else num(n/1000)
 backend='native' if role in roles['native'] else 'interpreter'
 reference='wasmtime-compiler' if backend=='native' else 'wazero-interpreter'
 if reference not in v['mediansNsPerIteration']:reference='wasmedge-interpreter'
 value=v['mediansNsPerIteration'][role];baseline=v['mediansNsPerIteration'][reference]
 unresolved=not(v['AA'][role]['resolves2_5Percent'] and v['AA'][reference]['resolves2_5Percent'])
 return num(value)+' ('+('ref' if role==reference else fmt.observed(value,baseline)+' speed')+')'+(' †' if unresolved else '')
add('# P3 scalar scheduler leaves and synchronous host transactions, 2026-11-21');add()
add('Core scalar leaves update serialized host metadata inside the active frame. Snapshot-based synchronous component calls and ready-source reads reuse private transaction and result storage. The changes preserve public result ownership, resource accounting, cancellation and the suspendable call path.');add()
for size,v in p3.items():
 for compiler in ['go','llgo']:
  role='head-'+compiler;base='base-'+compiler;med=v['medians']
  add(f'- P3 {int(size):,} B, {compiler.upper()}. CPU {num(med[base]["cpuUs"])} → {num(med[role]["cpuUs"])} µs/request and throughput {num(med[base]["throughput"])} → {num(med[role]["throughput"])} requests/s. Paired CPU comparison against source base {ratio(v["comparisons"][role+"/"+base]["cpuUs"])}. Against Wasmtime {ratio(v["comparisons"][role+"/wasmtime"]["cpuUs"])}.')
add()
add('All 33 core workloads and two complete P3 payloads are measured on the same pinned toolchains. Tables give preparation and steady execution independently. The performance acceptance gate remains open.');add()
add('## Percentage differences');add()
add('Cells show `absolute observation (signed speed Δ%)`. Positive speed change means faster. Native execution and P3 use **Wasmtime** as a fixed reference; interpreter execution uses **wazero**, with **WasmEdge** explicitly named for GC rows where wazero rejects the feature. Using a fixed reference keeps the percentages comparable across revisions. The fastest observed runtime varies by workload.');add()
add('For time, speed Δ = `(reference / candidate - 1) * 100%`; for throughput, speed Δ = `(candidate / reference - 1) * 100%`. Thus 100 ns to 50 ns is **−50% time**, **+100% speed**. P3 CPU percentages mean work per CPU time, separate from wall-clock throughput. Instruction/allocation/byte counters show quantity Δ rather than speed. Source comparisons retain paired ratio intervals and report quantity Δ plus speed Δ where applicable; reciprocal interval endpoints are reversed.');add()
add('Competitive cell percentages are descriptive quotients of the displayed medians. Paired block estimates below can differ. `†` on these cells means either the candidate or the named reference has unresolved A/A controls; qualified conclusions require resolved controls. Phase boundaries with different contracts have separate absolute observations. The percentages apply to the frozen event and measured revision.');add()
add('## Revisions, profiles and protocol')
add()
add(f'- Engine source: base `{data["builds"]["base"][:8]}` (merged PR #204), measured head `{data["builds"]["head"][:8]}`. Reused binaries retain their producer revisions. The build records verify production-source equivalence for each reused binary.')
add('- Go **1.27.3**; LLGo **3c6b33ec**, **`-O3 -lto=full`**, LLVM **22.1.8**, default production GC. Source base/head share the compiler profile.')
add('- wazero **1.12.0**, native compiler/interpreter; Wasmtime **48.0.1**, Cranelift speed; Wasmer **7.3.0**, Cranelift; WasmEdge **0.17.1**, interpreter and **O3 AOT**. Comparison scope is the named profile of each runtime.')
add('- Local Apple M4 Max, macOS arm64, 128 GiB RAM. External desktop load is uncontrolled and recorded; no owned builds, tests, profiles, analysis or edits overlap timing. The timing scope is macOS arm64.')
add('- Core uses six fixed fresh-process blocks, each with symmetric same-binary A/A, two warmups and seven interleaved measured calls. **5,364 successful process records** after excluding exactly three failing sustained WasmEdge AOT cells. All 33 workloads remain represented. Allocation workloads use means including pauses; others use medians.')
add('- P3 uses **72 processes per payload**, six roles with A/A, six fixed blocks, four workers, sixteen clients and twenty interleaved 512-request windows plus a separate flush. Verify status, headers, full body, trailers, CRC and joined guest completion. CPU/instruction counters include the driver and checks. Mach ticks use the recorded timebase.')
add('- Ratios use paired block geometric means and 20,000 fixed-seed bootstrap resamples with marginal 95% intervals. Both relevant A/A intervals must fit `[0.975, 1.025]`. Each interval applies to its own comparison. The protocol fixes the sample size in advance and measures each phase directly.')

add()
add('**Legend:** `†` means the role or its percentage reference has an unresolved same-binary timing control. Values are observations; a qualified comparison additionally needs both controls and its ratio interval. `US` means this pinned profile rejected the feature in semantic preflight. `NM` means this benchmark adapter/profile was not measured; this status applies only to this measurement. `N/A` means the metric does not apply. `FAIL` is an execution failure in the named profile.')
add()
for backend in roles:
 add('## '+('Native compiled execution'if backend=='native'else'Interpreter execution'));add()
 add('Warm **ns/source iteration**, except SHA uses **ns/message block**. Cohorts distinguish the original 22 cases from four sustained GC, six sustained Threads, and the general-call workload.');add()
 add('The reference runtime is **Wasmtime**.' if backend=='native' else 'The reference runtime is **wazero**. GC rows use **WasmEdge**.');add()
 table(headers,[[key+(' (vs WasmEdge)' if backend=='interpreter' and 'wazero-interpreter'not in core[key]['mediansNsPerIteration'] else '')]+[cell(key,r)for r in roles[backend]]for key in core])
add('### Warm speed against the fastest observed competitor');add()
add('Each row selects the fastest measured competitor median for that backend and workload. The observed percentages remain descriptive when the selected reference or candidate has unresolved controls.');add()
for backend in roles:
 winners=[]
 for key,v in core.items():
  measured=v['mediansNsPerIteration']
  time,reference=min((measured[role],role) for role in roles[backend][2:] if role in measured)
  def relative(role):
   unresolved=not(v['AA'][role]['resolves2_5Percent'] and v['AA'][reference]['resolves2_5Percent'])
   return fmt.observed(measured[role],time)+(' †' if unresolved else '')
  winners.append([key,reference,relative(roles[backend][0]),relative(roles[backend][1])])
 add('#### '+backend.title());add()
 table(['Workload','Fastest observed competitor','wasmvm Go speed Δ','wasmvm LLGo speed Δ'],winners)
add('## Complete P3 HTTP requests');add()
add('P3 competitor cells marked `NM` have no measured adapter for the pinned component/WASI workload. Wasmtime uses the same validated workload. Managed allocation counts exclude foreign Rust/C/JIT allocations and cover only the managed share of allocation.');add()
rows=[]
for size,v in p3.items():
 for metric,label in [('cpuUs','CPU, us/request'),('instructions','instructions/request'),('throughput','requests/s')]:
  cells=[]
  for role in ['head-go','head-llgo',None,'wasmtime',None,None]:
   if role is None:cells.append('NM');continue
   value=v['medians'][role][metric];reference=v['medians']['wasmtime'][metric]
   delta=fmt.signed(100*(value/reference-1))+' Δ' if metric=='instructions' else fmt.observed(value,reference,higher_is_better=metric=='throughput')+' speed'
   unresolved=not(v['AA'][role][metric]['resolves2_5Percent'] and v['AA']['wasmtime'][metric]['resolves2_5Percent'])
   cells.append(num(value)+' ('+('ref'if role=='wasmtime'else delta)+')'+(' †'if unresolved else ''))
  rows.append([size+' B '+label]+cells)
table(headers,rows)
add('### P3 source contrasts');add()
rows=[]
for size,v in p3.items():
 for metric in ['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest']:
  rows.append([size+' B '+metric,ratio(v['comparisons']['head-go/base-go'][metric],higher_is_better=metric=='throughput',speed=metric in ['cpuUs','throughput']),ratio(v['comparisons']['head-llgo/base-llgo'][metric],higher_is_better=metric=='throughput',speed=metric in ['cpuUs','throughput'])])
table(['Metric','Go source head/base','LLGo source head/base'],rows)
add('Throughput ratios above one improve. CPU, instruction and allocation ratios below one improve. The JSON retains all own-baseline observations and every per-role A/A interval.');add()
add('### Competitive P3 ratios');add()
table(['Payload / compiler','CPU ratio to Wasmtime [95% CI]; controls','Throughput ratio to Wasmtime [95% CI]; controls'],[[size+' B '+compiler,ratio(v['comparisons']['head-'+compiler+'/wasmtime']['cpuUs']),ratio(v['comparisons']['head-'+compiler+'/wasmtime']['throughput'],higher_is_better=True)]for size,v in p3.items()for compiler in ['go','llgo']])
add('## Core source baseline');add()
add('Head/base ratios below one improve. These marginal intervals describe this event; an apparent change in an unchanged mechanism requires diagnosis before being attributed to source changes. The machine-readable report includes every competitor ratio and A/A interval.');add()
for backend in roles:
 add('### '+backend);add()
 table(['Workload','Go source head/base','LLGo source head/base'],[[key]+[ratio(v['comparisons'][pair])for pair in [f'head-go-{backend}/base-go-{backend}',f'head-llgo-{backend}/base-llgo-{backend}']]for key,v in core.items()])
add('## Preparation, first call and cleanup');add()
add('All entries below are **microseconds per process or invocation**, including unresolved observations. Phase intervals are not inferred from warm-call controls. Startup is independently observed process readiness. Native compile/validate boundaries differ by API; WasmEdge AOT includes validation and artifact I/O, plus separately recorded native-image loading. Every process creates a fresh native image. First-call and warm execution have their own boundaries; values are never subtracted to invent pure costs.');add()
for backend in roles:
 add('<details>');add('<summary>'+backend.title()+': all 33 workloads and phase observations</summary>');add()
 for phase in ['processStartup','load','engineSetup','compileValidate','instantiate','exportLookup','firstCall','cleanup']:
  add('### '+phase);add();table(headers,[[key]+[cell(key,r,phase)for r in roles[backend]]for key in core])
 add('</details>');add()
add('### WasmEdge AOT preparation detail');add()
table(['Workload','Compile + validation + artifact I/O, us','Native image load, us','Post-load validation, us'],[[key]+[cell(key,'wasmedge-compiler',phase)for phase in ['aotPreparationNs/compileValidateArtifactIO','aotPreparationNs/compiledArtifactLoad','preparationPartsNs/validate']]for key in core])
add('### P3 phase observations');add()
rows=[]
for size,v in p3.items():
 for phase in sorted({k for role in ['head-go','head-llgo','wasmtime']for k in v['phasesMedianNs'][role]}):
  cells=[]
  for role in ['head-go','head-llgo',None,'wasmtime',None,None]:
   value=None if role is None else v['phasesMedianNs'][role].get(phase);cells.append('NM'if role is None else'N/A'if value is None else num(value/1000))
  rows.append([size+' B / '+phase]+cells)
table(headers,rows)
add('## Native controls (different contracts)');add()
add('Unchecked C kernels omit runtime safety/lifetime contracts; native Go implements HTTP replies without Component/WASI. These are overhead controls with different contracts. The table reports their measured timing directly. The general-call C control runs twice as many iterations of one recurrence; The optimized Wasm combines two recurrence updates into one affine operation.');add()
table(['Workload','Unchecked native C, ns/iteration'],[[key,num(v['mediansNsPerIteration']['native-c'])]for key,v in core.items()if'native-c'in v['mediansNsPerIteration']])
table(['Payload','Native Go CPU, us/request','Native Go requests/s'],[[size+' B',num(v['medians']['native-go']['cpuUs']),num(v['medians']['native-go']['throughput'])]for size,v in p3.items()])
add('## WasmEdge sustained AOT failures');add()
add('Full-size WasmEdge0.17.1 O3 AOT preflight freshly reproduces SIGSEGV in sustained struct access, allocation and indirect access. Small original cases pass. Only those exact three cells remain failures in the timing matrix. The original investigation and the observed cumulative stack growth are retained in the [PR #200 report](performance-pr200-complete-comparison-2026-11-17.md). All table timings come from the current event.');add()
add('## Mechanism evidence');add()
add('An independent instrumented replay counts eleven direct scalar leaves per P3 request. General host handoffs fall from 34 to 23 at 16 B and from 46 to 35 at 64 KiB. Native machine-code entries stay at 38 and 50 per request. The corrected frame variant removes seven allocations and approximately 768 bytes per request relative to the scalar-leaf-only build. The instrumented replays and source screens in the protocol archive are separate from the primary timing event.');add()
add('## Resolved adverse primary intervals');add()
rows=[]
for key,result in core.items():
 for name,stats in result['comparisons'].items():
  if '/base-' in name and stats['resolvedRegression']:
   rows.append([key,name,ratio(stats)])
for size,result in p3.items():
 for name,metrics in result['comparisons'].items():
  if '/base-' not in name:continue
  for metric,stats in metrics.items():
   if 'ratio' not in stats or not stats['controlsResolve']:continue
   worse=stats['ci95'][1]<1 if metric=='throughput' else stats['ci95'][0]>1
   if worse:rows.append([f'P3 {size} B {metric}',name,ratio(stats,higher_is_better=metric=='throughput',speed=metric in ['cpuUs','throughput'])])
if rows:table(['Workload or metric','Source comparison','Head/base ratio and delta'],rows)
else:add('No source comparison has a resolved adverse interval in this event.');add()
diagnostics=p/'regression-notes.md'
if diagnostics.is_file():
 add(diagnostics.read_text().strip());add()
add('## Reproducible evidence');add()
add(f'- [Machine-readable results, all controls and source contrasts](data/{stem}.json).')
add(f'- [All 5,508 primary process records](data/{stem}-raw.jsonl.gz), SHA-256 `{data["raw"]["sha256"]}`.')
add(f'- [Frozen plans, commands, hashes, analysis/export scripts, semantic checks and failure evidence](data/{stem}-protocol.tar.gz), SHA-256 `{data["protocol"]["sha256"]}`.')

add('- Per-request vectors unused by these metrics are projected to count/extrema/hash; no latency-tail claim. Public load records omit unrelated desktop command arguments. The separately archived screening observations are excluded from primary ratios.')
(w/'docs/research'/f'performance-{stem}.md').write_text('\n'.join(out)+'\n')
print('Rendered',len(out),'lines')
