package main
import("context";"testing";"runtime";"runtime/pprof";"encoding/json";"os";"path/filepath")
func TestDiagnosticWarmAllocations(t *testing.T){
 old:=runtime.MemProfileRate;runtime.MemProfileRate=1;defer func(){runtime.MemProfileRate=old}()
 args:=largeOptions();if os.Getenv("PAYLOAD_BYTES")=="16" {args.payload=args.payload[:16];args.Expected=1757737011};args.engine,args.backend,args.path="wasmvm","native",p3Fixture("world-rust-http");args.Workers=4;args.responseMode,args.requestMode="buffered","snapshot"
 out:=report{Phases:map[string]int64{}};calls,close,err:=ownedKernels(context.Background(),args,&out);if err!=nil{t.Fatal(err)};defer close()
 for range 20{for _,call:=range calls{if _,value,err:=call();err!=nil||value!=args.Expected{t.Fatal(value,err)}}}
 write:=func(name string){t.Helper();runtime.GC();runtime.GC();f,err:=os.Create(filepath.Join(os.Getenv("ALLOC_DIR"),name));if err!=nil{t.Fatal(err)};if err:=pprof.Lookup("allocs").WriteTo(f,0);err!=nil{t.Fatal(err)};if err:=f.Close();err!=nil{t.Fatal(err)}}
 write("before.pprof");var before,after runtime.MemStats;runtime.ReadMemStats(&before)
 for i:=0;i<4096;i++{if _,value,err:=calls[i%len(calls)]();err!=nil||value!=args.Expected{t.Fatal(value,err)}}
 runtime.ReadMemStats(&after);write("after.pprof")
 b,err:=json.MarshalIndent(map[string]any{"requests":4096,"allocsPerRequest":float64(after.Mallocs-before.Mallocs)/4096,"bytesPerRequest":float64(after.TotalAlloc-before.TotalAlloc)/4096,"scope":"Allocs differential only, exact sampling rate1, setup and80warm requests excluded using cumulative before/after profiles. Sequential checked calls through4Stores. No CPU/throughput acceptance."},"","  ");if err!=nil{t.Fatal(err)};if err:=os.WriteFile(filepath.Join(os.Getenv("ALLOC_DIR"),"counts.json"),b,0600);err!=nil{t.Fatal(err)}
}
