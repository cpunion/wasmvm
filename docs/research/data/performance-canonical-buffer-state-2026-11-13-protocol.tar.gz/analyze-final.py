from pathlib import Path
import json,random,math,statistics,sys
p=Path(sys.argv[1]);rows=[json.loads(x)for x in(p/'rows.jsonl').read_text().splitlines()];groups={}
for r in rows:groups.setdefault(r['block'],{})[r['id']]=r
assert len(rows)==json.loads((p/'plan.json').read_text())['blocks']*8
rng=random.Random(202611134032)
def ratio(values):
 logs=[math.log(x)for x in values];point=math.exp(statistics.mean(logs));boots=sorted(math.exp(statistics.mean(rng.choices(logs,k=len(logs))))for _ in range(20000));return dict(ratio=point,ci95=[boots[500],boots[19499]])
result={}
for key in ['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest']:
 r={}
 if key!='allocsPerRequest':
  for control in (['base'] if key=='bytesPerRequest' else ['base','llgo','wasmtime']):
   r['headOver'+control.title()]=ratio([statistics.geometric_mean([b['head'][key],b['head-aa'][key]])/statistics.geometric_mean([b[control][key],b[control+'-aa'][key]])for b in groups.values()])
 r['AA']={}
 if key in ['cpuUs','instructions','throughput']:
  for name in ['base','head','llgo','wasmtime']:
   v=ratio([b[name+'-aa'][key]/b[name][key]for b in groups.values()]);v['resolves2_5Percent']=v['ci95'][0]>=.975 and v['ci95'][1]<=1.025;r['AA'][name]=v
 result[key]=r
(p/'paired.json').write_text(json.dumps(result,indent=2)+'\n')
print(p.name,json.dumps(result))
