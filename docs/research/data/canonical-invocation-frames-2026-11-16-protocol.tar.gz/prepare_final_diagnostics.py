from pathlib import Path
import json, hashlib, subprocess
p=Path(__file__).resolve().parent;r=p.parents[1];w=r.parent/'wasmvm-source-cleanup'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert head=='121dff14e19f3d43cc739da49ec2d5367a7372f8';assert not subprocess.check_output(['git','status','--porcelain'],cwd=w)
template=(p/'p3-llgo-65536/measure.py').read_text();prefix=template[:template.index('import hashlib,time,signal,gzip')];body=template[template.index("plan['binarySHA256']"):]
body=body.replace("'--requests','32','--samples','21'","'--requests',str(plan['batchRequests']//16),'--samples',str(plan['samples']+1)")
body=body.replace("child=dict(id=name+alias,", "env['GC_DONT_GC']='1' if name.endswith('-nogc') else '0';child_gc_disabled=name.endswith('-nogc');child=dict(id=name+alias,")
# Default roles must use the normal collector environment, not GC_DONT_GC=0.
body=body.replace("env['GC_DONT_GC']='1' if name.endswith('-nogc') else '0';child_gc_disabled=name.endswith('-nogc');", "\n   if name.endswith('-nogc'):env['GC_DONT_GC']='1'\n   ")
body=body.replace("err=(OUT/f'{block}-{name}{alias}.stderr').open('w');p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=env);\n", "err=(OUT/f'{block}-{name}{alias}.stderr').open('w')\n") if False else body
# Environment is modified immediately before Popen, rather than after it.
body=body.replace("err=(OUT/f'{block}-{name}{alias}.stderr').open('w');p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=env);\n   if name.endswith('-nogc'):env['GC_DONT_GC']='1'\n   child=dict", "if name.endswith('-nogc'):env['GC_DONT_GC']='1'\n   err=(OUT/f'{block}-{name}{alias}.stderr').open('w');p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=env);child=dict")
assert "if name.endswith('-nogc'):env['GC_DONT_GC']='1'\n   err=" in body
body=body.replace('threading.Timer(120,p.kill)','threading.Timer(300,p.kill)')
body=body.replace("('llgo' if plan['hostCompiler']=='llgo' and c['id'].removesuffix('-aa') in ('base','head') else 'gc')", "('llgo' if plan['hostCompiler']=='llgo' else 'gc')")
body=body.replace(']*21;counts=plan[\'samples\']*512',"]*(plan['samples']+1);counts=plan['samples']*plan['batchRequests']")
body=body.replace("[3:23];assert len(batches)==20", "[3:3+plan['samples']];assert len(batches)==plan['samples']\n   gc_delta=sum(b['GCAfter']-b['GCBefore'] for b in batches)\n   if c['id'].removesuffix('-aa').endswith('-nogc'):assert gc_delta==0\n   ")
body=body.replace("throughput=512e9/statistics.median(record['warmCallNs'][:20])", "gcCollections=gc_delta,peakFootprint=max(x['after']['ri_lifetime_max_phys_footprint'] for x in c['rounds']),throughput=plan['batchRequests']*1e9/statistics.median(record['warmCallNs'][:plan['samples']])")
body=body.replace("'allocsPerRequest','bytesPerRequest']", "'allocsPerRequest','bytesPerRequest','gcCollections','peakFootprint']")
base=r/'artifacts/latest-main-gap-20261116';variants={}
for name,binary in [('base',base/'qualified-head-llgo-p3'),('prototype',p/'p3/head-llgo'),('head',p/'final/p3-llgo')]:
 variants[name]=str(binary);variants[name+'-nogc']=str(binary)
plans=[('final-llgo-65536-gc',dict(blocks=6,samples=10,batchRequests=128,seed=202611166401,payloadBytes=65536,variants=variants,hostCompiler='llgo'))]
for compiler,size,blocks in [('go',16,10),('go',65536,10),('llgo',16,6)]:
 plans.append((f'final-{compiler}-{size}',dict(blocks=blocks,samples=20 if compiler=='go' else 10,batchRequests=512 if compiler=='go' else 128,seed=202611163000+size+(0 if compiler=='go'else 100),payloadBytes=size,variants={'base':str(base/('final-go-p3'if compiler=='go'else'qualified-head-llgo-p3')),'head':str(p/f'final/p3-{compiler}')},hostCompiler=compiler)))
for name,plan in plans:
 d=p/name;d.mkdir(exist_ok=False)
 plan.update(base='8c8d4a759ecdf6c826e4df6078a98ee376dab9e0',prototype='b4bcc4523fc4ca6799c0a790f6b806036ccd438a',head=head,compilerProfiles={'Go':'1.27.3','LLGo':'5860fb6f9c13371f6cdb456a987a8e95844066d4 -O3 -lto=full'},scope='Fixed source-regression diagnostic, not a competitor or portfolio acceptance. Complete P3 requests, independent status/header/trailer/body/CRC verification and guest join. Symmetric AA, no source changes/builds/tests/profile/analysis/pruning during timed cohorts. Preserve inconclusive and adverse observations; no extension/pooling. GC_DONT_GC interventions are diagnostic only. Startup/load/compile/instantiate/first/warmup/cleanup separate. Complete driver counters are not exclusive guest/component costs. GC counters, memory footprint and external load retained.')
 code=prefix+'import hashlib,time,signal,gzip\nvariants='+repr(plan['variants'])+'\nplan='+repr(plan)+'\n'+body
 compile(code,str(d/'measure.py'),'exec');(d/'measure.py').write_text(code)
 frozen=dict(plan,binarySHA256={k:hashlib.sha256(Path(v).read_bytes()).hexdigest()for k,v in plan['variants'].items()},fixtureSHA256=hashlib.sha256((r/'pkg/wasi/preview3/testdata/world-rust-http.wasm').read_bytes()).hexdigest());(d/'frozen-plan.json').write_text(json.dumps(frozen,indent=2)+'\n')
(p/'run_final_diagnostics.py').write_text('''from pathlib import Path
import subprocess,time,json
p=Path(__file__).resolve().parent
names='''+repr([n for n,_ in plans])+'''
status=[]
for name in names:
 d=p/name;started=time.monotonic()
 with(d/'driver.log').open('w') as f:r=subprocess.run(['python3','-u',str(d/'measure.py')],stdout=f,stderr=subprocess.STDOUT)
 status.append(dict(cohort=name,exitCode=r.returncode,seconds=time.monotonic()-started));(p/'final-diagnostic-status.json').write_text(json.dumps(status,indent=2)+'\\n');print(status[-1],flush=True);r.check_returncode()
''')
print('Frozen diagnostic plans:',[n for n,_ in plans])
