from pathlib import Path
import subprocess,json,time
p=Path(__file__).resolve().parent
scripts=[p/'measure_micro.py']+[p/f'p3-{compiler}-{size}'/'measure.py'for compiler in ['go','llgo']for size in [16,65536]]
status=[]
for script in scripts:
 started=time.monotonic()
 with(script.with_name('driver.log')).open('w')as f:run=subprocess.run(['python3','-u',str(script)],stdout=f,stderr=subprocess.STDOUT)
 status.append({'script':str(script.relative_to(p)),'exitCode':run.returncode,'seconds':time.monotonic()-started});(p/'fixed-cohort-status.json').write_text(json.dumps(status,indent=2)+'\n');print(status[-1],flush=True)
 run.check_returncode()
