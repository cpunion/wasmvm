from pathlib import Path
import json,hashlib,subprocess
r=Path('/Users/lijie/source/goplus/wasmvm');w=r.parent/'wasmvm-source-cleanup';p=r/'artifacts/canonical-invocation-frames-20261116';old=r/'artifacts/p3-mechanism-costs-20261116/micro';previous=r/'artifacts/latest-main-gap-20261116'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip();assert head=='b4bcc4523fc4ca6799c0a790f6b806036ccd438a';assert not subprocess.check_output(['git','status','--porcelain'],cwd=w)
for commit in ['9c271a3e419c6add13522dce52fe3bbd649569d3','5ab3bcce9a1d1d916a2866a8fca2e796fb0eb60b']:
 subprocess.run(['git','diff','--exit-code',commit,'8c8d4a759ecdf6c826e4df6078a98ee376dab9e0','--','*.go','go.mod','go.sum'],cwd=w,stdout=subprocess.DEVNULL,check=True)
def sha(file):return hashlib.sha256(Path(file).read_bytes()).hexdigest()
plan={'sourceBase':'8c8d4a759ecdf6c826e4df6078a98ee376dab9e0','sourceHead':head,'compilers':{'Go':'1.27.3','LLGo':'5860fb6f9c13371f6cdb456a987a8e95844066d4','LLGoProfile':'-O3 -lto=full'},'blocks':10,'samples':7,'warmups':2,'case':'component-host','iterations':100000,'seeds':[7,4294967295,19,2147483648,43,123456789,71,314159265,101,4000000001],'rngSeed':2026111607,'sameBinaryAA':True,'participants':{'go-base':str(old/'own-go'),'go-head':str(p/'micro/head-go'),'llgo-base':str(old/'own-llgo'),'llgo-head':str(p/'micro/head-llgo'),'wasmtime-typed':str(old/'wasmtime'),'wasmtime-dynamic':str(old/'wasmtime')},'scope':'Fixed advisory mechanism cohort, independently checked output and callback count. Fresh process medians, paired block geometric ratios, 20,000 block bootstrap resamples seed2026111608; full same-binary 95% AA interval inside[.975,1.025]. No subtraction, no portfolio acceptance. No owned build/test/profile/analysis/edit/pruning during any timed cohort; external load retained. Do not extend or pool.'}
plan['binarySHA256']={k:sha(v)for k,v in plan['participants'].items()};plan['fixtureSHA256']=sha(old/'component-host.wasm');(p/'micro-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
s=(r/'artifacts/p3-mechanism-costs-20261116/run_micro_timing.py').read_text();s=s[:s.index('plan=json.loads')]+'''plan=json.loads((p/'micro-plan.json').read_text());d=p/'micro-timing';d.mkdir(exist_ok=False);rng=random.Random(plan['rngSeed']);os.environ['GOMAXPROCS']='4'
def load():
 return {'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadAverage':os.getloadavg(),'processes':subprocess.check_output(['ps','-axo','pid,ppid,etime,%cpu,command'],text=True)}
(d/'load-before.json').write_text(json.dumps(load(),indent=2)+'\\n')
try:
 for block,seed in enumerate(plan['seeds']):
  commands={}
  for participant,binary in plan['participants'].items():
   kind='dynamic-host'if participant=='wasmtime-dynamic'else'component-host'
   for alias in ['A','B']:commands[participant+'-'+alias]=[binary,kind,str(m/'component-host.wasm'),str(plan['iterations']),str(seed)]
  started=time.monotonic();observations,orders=interleaved.invoke(commands,timeout=90,rng=rng)
  (d/(str(block)+'.json')).write_text(json.dumps({'block':block,'seed':seed,'iterations':plan['iterations'],'observations':observations,'orders':orders,'seconds':time.monotonic()-started,'loadAverage':os.getloadavg()},indent=2)+'\\n');print('micro',block,'complete',flush=True)
 (d/'status.json').write_text(json.dumps({'complete':True,'blocks':10})+'\\n')
except BaseException:
 (d/'failure.txt').write_text(traceback.format_exc());raise
finally:(d/'load-after.json').write_text(json.dumps(load(),indent=2)+'\\n')
'''
s=s.replace("p=r/'artifacts/p3-mechanism-costs-20261116';m=p/'micro'","p=r/'artifacts/canonical-invocation-frames-20261116';m=r/'artifacts/p3-mechanism-costs-20261116/micro'")
(p/'measure_micro.py').write_text(s)
template=(previous/'final-go-16/measure.py').read_text();prefix=template[:template.index('import hashlib,time,signal,gzip')];body=template[template.index("plan['binarySHA256']"):]
for compiler in ['go','llgo']:
 for size in [16,65536]:
  folder=p/f'p3-{compiler}-{size}';folder.mkdir(exist_ok=False)
  variants={'base':str(previous/('final-go-p3'if compiler=='go'else'qualified-head-llgo-p3')),'head':str(p/'p3'/('head-'+compiler)),'wasmtime':str(r/'artifacts/protocol-cost-20261112/output-screen/wasmtime-go-runner')}
  if compiler=='llgo':variants['go']=str(p/'p3/head-go')
  plan={'blocks':10,'samples':20,'batchRequests':512,'seed':202611162000+(0 if compiler=='go'else 100)+size,'payloadBytes':size,'variants':variants,'hostCompiler':compiler,'base':'8c8d4a759ecdf6c826e4df6078a98ee376dab9e0','head':head,'source':'Canonical private frame/value-plan implementation. Go base9c and LLGo base5ab Go/module sources verified equal to8c. Head build b4bcc452; Go1.27.3; LLGo5860fb6f O3/fullLTO/defaultGC; Wasmtime48.0.1 pinned retained independent provider.','scope':'Fixed 10 blocks per compiler/payload, symmetric AA for every role, 4Stores16clients20interleaved512request batches plusflush. Full bodies/status/headers/trailers/CRC and guestjoin. Complete driver CPU/instructions are not pure guest/exclusive component costs. Startup/load/compile/instantiate/first/warmups/cleanup separate. Managed allocation scopes cannot rank total Rust/C/JIT allocation. No owned build/test/profile/analysis/edit/pruning during timed cohorts. External load snapshots retained. Paired block geometric ratios with20000 bootstrap95 intervals, AA full interval mustfit[.975,1.025]. Preserve failures; no extension/pooling or portfolio acceptance.'}
  code=prefix+'import hashlib,time,signal,gzip\nvariants='+repr(variants)+'\nplan='+repr(plan)+'\n'+body;(folder/'measure.py').write_text(code)
  frozen=dict(plan,binarySHA256={k:sha(v)for k,v in variants.items()},fixtureSHA256=sha(r/'pkg/wasi/preview3/testdata/world-rust-http.wasm'));(folder/'frozen-plan.json').write_text(json.dumps(frozen,indent=2)+'\n')
print('Frozen ten-block micro and four ten-block full-request cohorts.')
