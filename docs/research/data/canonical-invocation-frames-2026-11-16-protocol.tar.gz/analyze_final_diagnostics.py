from pathlib import Path
import gzip,json,math,random,statistics
p=Path(__file__).resolve().parent;rng=random.Random(202611166402)
def ratio(values):
 logs=[math.log(x)for x in values];n=len(logs);boots=sorted(math.exp(sum(rng.choices(logs,k=n))/n)for _ in range(20000));return dict(ratio=math.exp(sum(logs)/n),ci95=[boots[500],boots[19499]])
results={}
for name in ['final-llgo-65536-gc','final-go-16','final-go-65536','final-llgo-16']:
 d=p/name;plan=json.loads((d/'plan.json').read_text());rows=[json.loads(x)for x in gzip.open(d/'rows.jsonl.gz','rt')];groups={};roles=list(plan['variants']);assert len(rows)==plan['blocks']*2*len(roles)
 for row in rows:
  groups.setdefault(row['block'],{})[row['id']]=row
  scale=plan['machTimebase']['numer']/plan['machTimebase']['denom']/row['windowRequests']/1000
  row['userCPUUs']=row['totals']['ri_user_time']*scale;row['systemCPUUs']=row['totals']['ri_system_time']*scale;row['cycles']=row['totals']['ri_cycles']/row['windowRequests'];row['cpi']=row['cycles']/row['instructions']
 keys=['cpuUs','userCPUUs','systemCPUUs','instructions','cycles','cpi','throughput','allocsPerRequest','bytesPerRequest','gcCollections','peakFootprint']
 result={'processes':len(rows),'medians':{role:{k:statistics.median(row[k]for row in rows if row['id']in (role,role+'-aa'))for k in keys}for role in roles},'comparisons':{}}
 pairs=[('head','base'),('prototype','base'),('head','prototype'),('head-nogc','base-nogc'),('prototype-nogc','base-nogc'),('head-nogc','prototype-nogc'),('base','base-nogc'),('head','head-nogc'),('prototype','prototype-nogc')]
 for k in keys:
  available=[n for n in roles if all(g[n][k]>0 and g[n+'-aa'][k]>0 for g in groups.values())];out={'AA':{}}
  for role in available:
   v=ratio([g[role+'-aa'][k]/g[role][k]for g in groups.values()]);v['resolves2_5Percent']=v['ci95'][0]>=.975 and v['ci95'][1]<=1.025;out['AA'][role]=v
  for a,b in pairs:
   if a not in available or b not in available:continue
   v=ratio([math.sqrt(g[a][k]*g[a+'-aa'][k])/math.sqrt(g[b][k]*g[b+'-aa'][k])for g in groups.values()]);v['matchingAAPasses']=all(out['AA'][x]['resolves2_5Percent']for x in [a,b]);out[a+'/'+b]=v
  result['comparisons'][k]=out
 (d/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');results[name]=result
 print(name, json.dumps({'medians':result['medians'],'comparisons':{k:{n:v for n,v in result['comparisons'][k].items()if n!='AA'}for k in ['cpuUs','instructions','throughput']}}))
(p/'final-diagnostic-analysis.json').write_text(json.dumps(results,indent=2)+'\n')
