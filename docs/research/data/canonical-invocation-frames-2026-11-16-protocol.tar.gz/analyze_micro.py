from pathlib import Path
import json,statistics,math,random
p=Path(__file__).resolve().parent;rng=random.Random(2026111608);plan=json.loads((p/'micro-plan.json').read_text());blocks=[json.loads((p/'micro-timing'/f'{b}.json').read_text())for b in range(10)]
def gm(x):return math.exp(statistics.mean(map(math.log,x)))
def ratio(x):
 draws=sorted(gm(rng.choices(x,k=len(x)))for _ in range(20000));return {'ratio':gm(x),'ci95':[draws[499],draws[19499]]}
metrics=['nsPerIteration','allocsPerIteration','bytesPerIteration'];values={};medians={};controls={}
for name in plan['participants']:
 values[name]={k:[]for k in metrics};controls[name]={};aa={k:[]for k in metrics};cold={k:[]for k in ['load','prepare','cleanup','firstCallNs']}
 for block in blocks:
  records=[block['observations'][name+'-'+alias]['record']for alias in ['A','B']];n=block['iterations']
  for row in records:
   assert row['iterations']==n and row['hostCallsPerRun']==n
   for k in cold:cold[k].append(row[k]if k=='firstCallNs'else row['phasesNs'][k])
  for key,field in [('nsPerIteration','warmCallNs'),('allocsPerIteration','mallocs'),('bytesPerIteration','allocatedBytes')]:
   if records[0][field]is None:continue
   a,b=[statistics.median(row[field])/n for row in records];values[name][key].append(math.sqrt(a*b));aa[key].append(b/a)
 medians[name]={k:statistics.median(v)for k,v in values[name].items()if v};medians[name]['phasesMedianNs']={k:statistics.median(v)for k,v in cold.items()}
 for key,x in aa.items():
  if x:controls[name][key]=ratio(x);controls[name][key]['resolves2_5Percent']=controls[name][key]['ci95'][0]>=.975 and controls[name][key]['ci95'][1]<=1.025
comparisons={}
for key in metrics:
 comparisons[key]={}
 for a,b in [('go-head','go-base'),('llgo-head','llgo-base'),('llgo-head','go-head'),('go-head','wasmtime-typed'),('llgo-head','wasmtime-typed'),('wasmtime-dynamic','wasmtime-typed')]:
  if not values[a][key]or not values[b][key]:continue
  s=ratio([x/y for x,y in zip(values[a][key],values[b][key])]);s['controlsResolve']=controls[a][key]['resolves2_5Percent']and controls[b][key]['resolves2_5Percent'];comparisons[key][a+'/'+b]=s
out={'medians':medians,'controls':controls,'comparisons':comparisons,'processes':120,'fixedBlocks':10};(p/'micro-analysis.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
