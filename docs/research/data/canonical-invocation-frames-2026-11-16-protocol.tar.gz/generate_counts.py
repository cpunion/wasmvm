from pathlib import Path
import subprocess,json,hashlib,os,time,re
R=Path('/Users/lijie/source/goplus/wasmvm');W=R.parent/'wasmvm-source-cleanup';P=R/'artifacts/canonical-invocation-frames-20261116';D=P/'counts';D.mkdir(exist_ok=True)
changed={};original={}
def get(rel):
 if rel not in changed:
  original[rel]=(W/rel).read_text();changed[rel]=original[rel]
 return changed[rel]
def setcode(rel,s):changed[rel]=s

def imports(s):
 if '"github.com/cpunion/wasmvm/pkg/wasm"' in s:return s
 if 'import (' in s:return s.replace('import (','import (\n "github.com/cpunion/wasmvm/pkg/wasm"',1)
 if re.search(r'^import "[^\n]+"$',s,re.M):return re.sub(r'^import ("[^\n]+")$',lambda m:'import (\n"github.com/cpunion/wasmvm/pkg/wasm"\n'+m.group(1)+'\n)',s,count=1,flags=re.M)
 raise RuntimeError('Unexpected imports')

def hook(rel,prefix,key,extra=''):
 s=get(rel);start=s.index(prefix);end=s.index('\n',start);assert s[start:end].rstrip().endswith('{'),(rel,prefix)
 s=s[:end+1]+'\twasm.DiagnosticP3Count('+json.dumps(key)+',1)\n'+extra+s[end+1:];setcode(rel,imports(s))

sites=[
 ('pkg/vm/call.go','func (op *operation) newCaller(','vm/caller/new'),
 ('pkg/vm/call.go','func (c *Caller) enter(','vm/caller/enter'),
 ('pkg/vm/call.go','func (op *operation) host(','vm/host/dispatch'),
 ('pkg/vm/continuation.go','func (c *Caller) Start(','vm/continuation/start'),
 ('pkg/vm/continuation.go','func (c *Caller) Poll(','vm/continuation/poll'),
 ('pkg/component/call.go','func newCallbackCaller(','component/caller/new'),
 ('pkg/component/call.go','func (in *Instance) codec(','component/codec/new'),
 ('pkg/component/call.go','func (in *Instance) initBufferCodec(','component/codec/bufferInit'),
 ('pkg/component/call.go','func (f *Function) enterCall(','component/function/enter'),
 ('pkg/component/host_call.go','func (f *Function) hostCall(','component/hostCall/new'),
 ('pkg/component/host_call.go','func (h *hostCall) accept(','component/hostCall/accept'),
 ('pkg/component/host_call.go','func (h *hostCall) finish(','component/hostCall/finish'),
 ('pkg/component/scheduler.go','func (in *Instance) makeTask(','component/task/new'),
 ('pkg/component/scheduler.go','func (t *componentTask) resume(','component/task/resume'),
 ('pkg/component/scheduler.go','func (in *Instance) stepTasks(','component/scheduler/step'),
 ('pkg/component/scheduler.go','func (in *Instance) awaitTasksContexts(','component/scheduler/await'),
 ('pkg/component/host_completion.go','func NewHostCompletion(','component/completion/new'),
 ('pkg/component/host_completion.go','func (p *HostCompletion) Resolve(','component/completion/resolve'),
 ('pkg/component/host_completion.go','func (p *HostCompletion) notify(','component/completion/notify'),
 ('pkg/component/host_completion.go','func (p *HostCompletion) bind(','component/completion/bind'),
 ('pkg/component/host_completion.go','func (p *HostCompletion) ready(','component/completion/ready'),
 ('pkg/component/host_completion.go','func (p *HostCompletion) take(','component/completion/take'),
 ('pkg/component/ownership.go','func (r *resourceCodec) Validate(','ownership/validate'),
 ('pkg/component/ownership.go','func (r *resourceCodec) Lift(','ownership/lift'),
 ('pkg/component/ownership.go','func (r *resourceCodec) Lower(','ownership/lower'),
 ('pkg/component/ownership.go','func (r *resourceCodec) Accept(','ownership/accept'),
 ('pkg/component/ownership.go','func (r *resourceCodec) Finish(','ownership/finish'),
 ('internal/component/canonical/value.go','func (c *Codec) Clone(','canonical/clone/root'),
 ('internal/component/canonical/value.go','func (c *Codec) clone(','canonical/clone/node'),
 ('internal/component/canonical/value.go','func (c *Codec) visit(','canonical/visit'),
 ('internal/component/canonical/value.go','func (c *Codec) load(','canonical/load/node'),
 ('internal/component/canonical/layout.go','func (b *Builder) Build(','canonical/layout/build'),
 ('internal/component/canonical/string.go','func (c *Transfer) check(','canonical/transfer/check'),
 ('internal/component/canonical/string.go','func (c *Transfer) rangeCheck(','canonical/transfer/rangeCheck'),
 ('internal/engine/nativeexec/execution.go','func (e *Execution) run(','native/state/init'),
 ('internal/engine/nativeexec/calls.go','func (e *Execution) prepareCalls(','native/frames/prepare'),
 ('internal/engine/nativeexec/calls.go','func (e *Execution) publishCallFrames(','native/frames/publish'),
]
sites += [
 ('pkg/component/canonical_frame.go','func (in *Instance) acquireCanonicalFrame(','component/frame/acquire'),
 ('pkg/component/canonical_frame.go','func (in *Instance) releaseCanonicalFrame(','component/frame/release'),
 ('pkg/component/call.go','func (in *Instance) configureCanonicalCodec(','component/codec/session'),
 ('pkg/component/host_call.go','func (in *Instance) newHostCall(','component/hostCall/allCreations'),
 ('internal/component/canonical/plan.go','func (p *ValuePlan) Clone(','canonical/clone/root'),
]
# The one-line constructor is counted at its call-site constructor expansion below.
for rel,prefix,key in sites:
 if prefix=='func NewHostCompletion(':continue
 hook(rel,prefix,key)
for method,extra in [('Read','wasm.DiagnosticP3Count("canonical/memory/readBytes",uint64(len(bytes)))\n'),('Write','wasm.DiagnosticP3Count("canonical/memory/writeBytes",uint64(len(bytes)))\n'),('ReadString','wasm.DiagnosticP3Count("canonical/memory/readStringBytes",n)\n'),('WriteString','wasm.DiagnosticP3Count("canonical/memory/writeStringBytes",uint64(len(data)))\n')]:hook('pkg/component/call.go','func (m memory) '+method+'(','canonical/memory/'+method,extra)
hook('internal/component/canonical/string.go','func (c *Transfer) charge(','canonical/transfer/charge','wasm.DiagnosticP3Count("canonical/transfer/budgetBytes",n)\n')
s=get('pkg/component/host_completion.go').replace('func NewHostCompletion() *HostCompletion { return &HostCompletion{} }','func NewHostCompletion() *HostCompletion { wasm.DiagnosticP3Count("component/completion/new",1); return &HostCompletion{} }');setcode('pkg/component/host_completion.go',s)
s=get('internal/engine/nativeexec/execution.go');needle='exit, err := e.native.RunState(module.code, entry, s)';assert s.count(needle)==1;s=s.replace(needle,'wasm.DiagnosticP3Count("native/entry",1)\n'+needle+'\nwasm.DiagnosticP3Kind("native/exit",uint32(exit))');setcode('internal/engine/nativeexec/execution.go',s)
s=get('internal/engine/execute/runtime_calls.go');needle='var dest []slots.Slot';assert s.count(needle)==1;s=s.replace(needle,'if callee.Code == nil { wasm.DiagnosticP3Count("dispatch/host",1) } else if callee.Instance == instance { wasm.DiagnosticP3Count("dispatch/guestSame",1) } else { wasm.DiagnosticP3Count("dispatch/guestCross",1) }\n'+needle);setcode('internal/engine/execute/runtime_calls.go',imports(s))
s=get('pkg/component/instance.go');needle='e.function = &Function{instance: in, typ: expected.Type, host: fn, asyncHost: async}';assert s.count(needle)==1;s=s.replace(needle,'''if fn != nil { implementation:=fn; label:="import/sync/"+name; fn=func(c *Caller,args []Value)(*Value,error){wasm.DiagnosticP3Count(label,1);return implementation(c,args)} }
if async != nil { implementation:=async; label:="import/async/"+name;async=func(c *Caller,args []Value)(*HostCompletion,error){wasm.DiagnosticP3Count(label,1);return implementation(c,args)} }
'''+needle);setcode('pkg/component/instance.go',imports(s))
for rel,var in [('pkg/component/async_builtin.go','p'),('pkg/component/task.go','plan'),('pkg/component/waitable.go','plan')]:
 s=get(rel);needle='func(c *vm.Caller, args scalarOperands) (scalarStep, error) {' if var=='p' else 'func(c *vm.Caller, words []uint64) error {';assert s.count(needle)>=1,rel;s=s.replace(needle,needle+'\nwasm.DiagnosticP3Kind("builtin/'+Path(rel).stem+'",uint32('+var+'.Definition.Op))',1);setcode(rel,imports(s))
s=get('internal/component/canonical/value.go');needle='wasm.DiagnosticP3Count("canonical/clone/node",1)';s=s.replace(needle,needle+'\nwasm.DiagnosticP3Kind("canonical/clone/kind",uint32(t.Kind))');setcode('internal/component/canonical/value.go',s)
s=get('pkg/component/canonical_frame.go');s=s.replace('frame = &canonicalFrame{}','wasm.DiagnosticP3Count("component/frame/new",1)\nframe = &canonicalFrame{}');setcode('pkg/component/canonical_frame.go',s)
helper='''package wasm
import("sync";"sync/atomic";"strconv")
var diagnosticP3Active atomic.Bool
var diagnosticP3Mu sync.Mutex
var diagnosticP3Counts=map[string]uint64{}
func DiagnosticP3Count(key string,n uint64){if !diagnosticP3Active.Load(){return};diagnosticP3Mu.Lock();diagnosticP3Counts[key]+=n;diagnosticP3Mu.Unlock()}
func DiagnosticP3Kind(key string,kind uint32){if diagnosticP3Active.Load(){DiagnosticP3Count(key+"/"+strconv.FormatUint(uint64(kind),10),1)}}
func DiagnosticP3Start(){diagnosticP3Mu.Lock();clear(diagnosticP3Counts);diagnosticP3Mu.Unlock();diagnosticP3Active.Store(true)}
func DiagnosticP3Stop()map[string]uint64{diagnosticP3Active.Store(false);diagnosticP3Mu.Lock();defer diagnosticP3Mu.Unlock();out:=make(map[string]uint64,len(diagnosticP3Counts));for k,v:=range diagnosticP3Counts{out[k]=v};return out}
'''
helperpath=D/'diagnostic_probe.go';helperpath.write_text(helper);overlay={'Replace':{str(W/'pkg/wasm/zz_diagnostic_p3.go'):str(helperpath)}};provenance={}
for rel,s in changed.items():
 target=D/(rel.replace('/','__'));target.write_text(s);subprocess.run(['gofmt','-w',str(target)],check=True);overlay['Replace'][str(W/rel)]=str(target);provenance[rel]=dict(originalSHA256=hashlib.sha256(original[rel].encode()).hexdigest(),probeSHA256=hashlib.sha256(target.read_bytes()).hexdigest())
bench=(W/'benchmarks/p3io/profile_test.go').read_text();bench=bench.replace('"context"','"context"\n"encoding/json"\n"os"\n"path/filepath"\n"strconv"\n"github.com/cpunion/wasmvm/pkg/wasm"');bench=bench.replace('args := largeOptions()', '''args := nativeOptions()
if os.Getenv("P3_PROBE_PAYLOAD")=="65536"{args=largeOptions()}
args.responseMode,args.requestMode="buffered","snapshot"''');bench=bench.replace('b.ResetTimer()','b.ResetTimer()\nwasm.DiagnosticP3Start()');bench=bench.replace('b.StopTimer()','''b.StopTimer()
counts:=wasm.DiagnosticP3Stop()
record:=map[string]any{"requests":b.N,"payloadBytes":len(args.payload),"counterOnly":true,"counts":counts}
data,failed:=json.MarshalIndent(record,"","  ");if failed!=nil{b.Fatal(failed)}
if failed=os.WriteFile(filepath.Join(os.Getenv("P3_PROBE_OUTPUT"),"n"+strconv.Itoa(b.N)+".json"),data,0600);failed!=nil{b.Fatal(failed)}''');target=D/'profile_test.go';target.write_text(bench);subprocess.run(['gofmt','-w',str(target)],check=True);overlay['Replace'][str(W/'benchmarks/p3io/profile_test.go')]=str(target)
(D/'overlay.json').write_text(json.dumps(overlay,indent=2)+'\n');(D/'source-manifest.json').write_text(json.dumps(dict(source='b4bcc4523fc4ca6799c0a790f6b806036ccd438a',changes=provenance,scope='Diagnostic counter-only overlays, no production source mutation, test timings and instrumented allocations excluded.'),indent=2)+'\n')
