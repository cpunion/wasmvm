from pathlib import Path
import sys,json,os,time,random,subprocess,traceback
r=Path('/Users/lijie/source/goplus/wasmvm');w=r.parent/'wasmvm-source-cleanup';p=r/'artifacts/canonical-invocation-frames-20261116';m=r/'artifacts/p3-mechanism-costs-20261116/micro';sys.path.insert(0,str(w/'benchmarks'));import interleaved
plan=json.loads((p/'micro-plan.json').read_text());d=p/'micro-timing';d.mkdir(exist_ok=False);rng=random.Random(plan['rngSeed']);os.environ['GOMAXPROCS']='4'
def load():
 return {'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'loadAverage':os.getloadavg(),'processes':subprocess.check_output(['ps','-axo','pid,ppid,etime,%cpu,command'],text=True)}
(d/'load-before.json').write_text(json.dumps(load(),indent=2)+'\n')
try:
 for block,seed in enumerate(plan['seeds']):
  commands={}
  for participant,binary in plan['participants'].items():
   kind='dynamic-host'if participant=='wasmtime-dynamic'else'component-host'
   for alias in ['A','B']:commands[participant+'-'+alias]=[binary,kind,str(m/'component-host.wasm'),str(plan['iterations']),str(seed)]
  started=time.monotonic();observations,orders=interleaved.invoke(commands,timeout=90,rng=rng)
  (d/(str(block)+'.json')).write_text(json.dumps({'block':block,'seed':seed,'iterations':plan['iterations'],'observations':observations,'orders':orders,'seconds':time.monotonic()-started,'loadAverage':os.getloadavg()},indent=2)+'\n');print('micro',block,'complete',flush=True)
 (d/'status.json').write_text(json.dumps({'complete':True,'blocks':10})+'\n')
except BaseException:
 (d/'failure.txt').write_text(traceback.format_exc());raise
finally:(d/'load-after.json').write_text(json.dumps(load(),indent=2)+'\n')
