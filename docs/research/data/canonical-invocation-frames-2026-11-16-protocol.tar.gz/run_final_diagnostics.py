from pathlib import Path
import subprocess,time,json
p=Path(__file__).resolve().parent
names=['final-llgo-65536-gc', 'final-go-16', 'final-go-65536', 'final-llgo-16']
status=[]
for name in names:
 d=p/name;started=time.monotonic()
 with(d/'driver.log').open('w') as f:r=subprocess.run(['python3','-u',str(d/'measure.py')],stdout=f,stderr=subprocess.STDOUT)
 status.append(dict(cohort=name,exitCode=r.returncode,seconds=time.monotonic()-started));(p/'final-diagnostic-status.json').write_text(json.dumps(status,indent=2)+'\n');print(status[-1],flush=True);r.check_returncode()
