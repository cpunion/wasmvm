from pathlib import Path
import gzip,hashlib,json,statistics,subprocess,tarfile
D=Path(__file__).resolve().parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');name='performance-native-parameter-initialization-2026-11-15'
folders=['counter-screen','counter-final','core-final','final-16','final-65536','no-gc-16','no-gc-65536','p3-16-audit']
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def project(v):
 if isinstance(v,list):return[project(x)for x in v]
 if not isinstance(v,dict):return v
 return{k:(dict(count=len(x),minimum=min(x)if x else None,maximum=max(x)if x else None,canonicalJSONSHA256=hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest())if k in('RequestNs','PublicAPINs')and isinstance(x,list)else project(x))for k,x in v.items()}
evidence=W/'docs/research/evidence'/f'{name}.jsonl.gz';counts={};gc={}
with gzip.open(evidence,'wt',compresslevel=9)as output:
 for folder in folders:
  p=D/folder
  with (gzip.open(p/'rows.jsonl.gz','rt')if(p/'rows.jsonl.gz').exists()else(p/'rows.jsonl').open())as stream:rows=[json.loads(l)for l in stream]
  counts[folder]=len(rows)
  for row in rows:output.write(json.dumps(dict(cohort=folder,**project(row)),separators=(',',':'))+'\n')
  if 'service'not in rows[0].get('record',{}):continue
  gc[folder]={};end=8 if folder.startswith('no-gc')else 23
  for role in sorted({r['id']for r in rows if not r['id'].endswith('-aa')}):
   rr=[r for r in rows if r['id']in(role,role+'-aa')];cc=[sum(b['GCAfter']-b['GCBefore']for b in r['record']['service']['Batches'][3:end])for r in rr];heaps=[r['record']['service']['Batches'][3]['HeapBefore']for r in rr]
   gc[folder][role]=dict(collectionsMedian=statistics.median(cc),collectionsRange=[min(cc),max(cc)],initialHeapMedian=statistics.median(heaps))
assert sum(counts.values())==544 and len(counts)==8,counts
protocol=W/'docs/research/data'/f'{name}-protocol.tar.gz'
with tarfile.open(protocol,'w:gz')as archive:
 for p in sorted(D.rglob('*')):
  if p.is_file()and not p.is_symlink()and p.suffix in('.go','.py','.json','.log','.txt','.patch','.stderr','.stdout'):archive.add(p,arcname=str(p.relative_to(D)))
 fixture=D.parent/'native-frame-deltas-20261114/generic-calls.wasm';archive.add(fixture,arcname='fixtures/'+fixture.name)
identity=read(D/'committed-identity.json')
report=dict(base=identity['base'],reusedBaseSource=identity['reusedBaseSource'],source=identity['source'],sourceTree=subprocess.check_output(['git','rev-parse',identity['source']+'^{tree}'],cwd=W,text=True).strip(),identity=identity,host='Apple M4 Max, darwin/arm64; other user compiler/link/test/desktop activity observed. Fixed cohorts are distinct; no owned build/test/analysis/source edit/pruning overlaps timed work.',references=dict(wazero='1.12.0',wasmtime='48.0.1',wasmer='7.3.0',nativeC='Unchecked LLVM22 affine oracle, 2N steps normalized per guest iteration, without VM safety contracts.'),finalComparisons=read(D/'analysis.json'),screen=read(D/'counter-screen/analysis.json'),regressionAudit=read(D/'p3-16-audit/analysis.json'),GCObservations=gc,validation=dict(Go='All32 root test packages pass; all31 measured executable packages >=90% statement coverage.',LLGo='Affected codegen/nativeexec execute under pinned6a482f7f -O3 -lto=full. Complete final-head Go/LLGo x Linux amd64/macOS arm64 CI required before merge.',cases='Parameter and outer-guard complete words, zeroed local suffix, zero/all-parameter frames, >4095-byte prefixes and bounded cancellation; existing mixed results/roots/quotas/reentry/proposals/fullWASI stay green.'),interpretation='See companion study. Generic-call CPU improves with resolving own controls, but full requests do not show resolved gains. All adverse throughput/cold/no-GC points and unresolved controls remain. Independent regression audit does not reproduce a resolved16B regression; do not pool it or relabel the initial event. Repeated store/dependency contribution versus layout remains unisolated. No milestone, competitive-parity or release acceptance.',protocolErrata='The first new cancellation test set Control before the wrapper, which correctly returned Poll before the generated body. Final fixture sets it after wrapper validation to exercise chunk cancellation. The initial failing expectation/source and corrected semantic logs are retained; this was not a production execution failure.',evidence=dict(path='../evidence/'+evidence.name,records=sum(counts.values()),cohorts=counts,sha256=digest(evidence),projection='Only unused RequestNs/PublicAPINs vectors become count/extrema/canonical-JSON SHA256. Full originals retained locally; phases, checks, GC/allocations, rusage and orders remain.'),protocol=dict(path=protocol.name,sha256=digest(protocol)))
p=W/'docs/research/data'/f'{name}.json';p.write_text(json.dumps(report,indent=2)+'\n');print(dict(records=sum(counts.values()),reportBytes=p.stat().st_size,evidenceBytes=evidence.stat().st_size,protocolBytes=protocol.stat().st_size))
