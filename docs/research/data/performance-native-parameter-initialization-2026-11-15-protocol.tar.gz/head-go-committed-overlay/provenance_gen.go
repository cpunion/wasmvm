package phase
func init(){sourceRevision="55f3e93a0a362c56b2fc285fe2aee9919582a38e";compilerRevision="go1.27.3"}
