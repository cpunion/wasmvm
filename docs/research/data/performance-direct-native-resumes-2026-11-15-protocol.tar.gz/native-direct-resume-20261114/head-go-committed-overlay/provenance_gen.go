package phase
func init(){sourceRevision="e938398763259e560840fee5e86070f22c0f3b93";compilerRevision="go1.27.3"}
