from pathlib import Path
import gzip
import hashlib
import json
import statistics
import tarfile

D = Path(__file__).resolve().parent
R = D.parent / 'native-register-results-20261114'
W = Path('/Users/lijie/source/goplus/wasmvm-source-cleanup')
name = 'performance-direct-native-resumes-2026-11-15'
cohorts = [(R, p) for p in ('core-screen', 'p3-screen-16', 'p3-screen-65536',
                            'vector-counter-audit', 'scalar-counter-audit')]
cohorts += [(D, p) for p in ('counter-screen', 'p3-screen-16', 'p3-screen-65536',
                            'core-final', 'final-16', 'final-65536',
                            'final-counter-audit', 'no-gc-65536')]

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def project(value):
    if isinstance(value, list):
        return [project(v) for v in value]
    if not isinstance(value, dict):
        return value
    out = {}
    for key, v in value.items():
        if key in ('RequestNs', 'PublicAPINs') and isinstance(v, list):
            out[key] = dict(count=len(v), minimum=min(v) if v else None,
                            maximum=max(v) if v else None,
                            canonicalJSONSHA256=hashlib.sha256(
                                json.dumps(v, separators=(',', ':')).encode()).hexdigest())
        else:
            out[key] = project(v)
    return out

evidence = W / 'docs/research/evidence' / (name + '.jsonl.gz')
counts, gc = {}, {}
with gzip.open(evidence, 'wt', compresslevel=9) as output:
    for root, folder in cohorts:
        path = root / folder
        compressed = path / 'rows.jsonl.gz'
        stream = gzip.open(compressed, 'rt') if compressed.exists() else (path / 'rows.jsonl').open()
        with stream:
            rows = [json.loads(line) for line in stream]
        key = root.name + '/' + folder
        counts[key] = len(rows)
        for row in rows:
            output.write(json.dumps(dict(cohort=key, **project(row)), separators=(',', ':')) + '\n')
        if 'service' not in rows[0].get('record', {}):
            continue
        end = 8 if folder.startswith('no-gc') else 23
        gc[key] = {}
        for role in sorted({r['id'] for r in rows if not r['id'].endswith('-aa')}):
            selected = [r for r in rows if r['id'] in (role, role + '-aa')]
            collections = [sum(b['GCAfter'] - b['GCBefore']
                               for b in r['record']['service']['Batches'][3:end]) for r in selected]
            gc[key][role] = dict(collectionsMedian=statistics.median(collections),
                                 collectionsRange=[min(collections), max(collections)],
                                 initialHeapMedian=statistics.median(
                                     r['record']['service']['Batches'][3]['HeapBefore'] for r in selected))
assert sum(counts.values()) == 1084

protocol = W / 'docs/research/data' / (name + '-protocol.tar.gz')
with tarfile.open(protocol, 'w:gz') as archive:
    for root in (D, R):
        for path in sorted(root.rglob('*')):
            if path.is_file() and path.suffix in ('.go', '.py', '.json', '.log', '.txt'):
                archive.add(path, arcname=root.name + '/' + str(path.relative_to(root)))
    fixture = D.parent / 'native-frame-deltas-20261114/generic-calls.wasm'
    archive.add(fixture, arcname='fixtures/' + fixture.name)

report = dict(
    base='5e25ac7dff2ef5f56795125ab064cd4ccf9f0996',
    source='e938398763259e560840fee5e86070f22c0f3b93',
    rebasedSource='af30e41014f9a5fa78b1ed673059e72e2e810a3a',
    sourceTree='4950ab41d09df7d586882d146c24f2caddcba2e0',
    integratedBase='a2aa727a13e79449738481ff538f67768af604dc',
    identityQualification='Measured base tree equals integrated a2aa727a; measured head tree equals rebased af30e410. Five-file source overlays are symmetric and archived; report-only commits must retain this runtime.',
    host='Apple M4 Max, darwin/arm64',
    profile=dict(go='go1.27.3', llgo='6a482f7f6ad94e9f2d0a0fea97dd4cabd46b1130',
                 llvm='22.1.8', llgoFlags=['-O3', '-lto=full'],
                 GC='Default production GC; one explicitly bounded no-GC diagnostic only.'),
    references=dict(wazero='1.12.0', wasmtime='48.0.1', wasmer='7.3.0',
                    nativeC='Frozen LLVM22 unchecked affine oracle, 2N steps normalized per guest iteration; no VM/fuel/cancellation/frame contract.'),
    builds=read(D / 'committed-build.json'),
    selectedComparisons=read(D / 'final-analysis.json'),
    finalCounterAudit=read(D / 'final-counter-audit/analysis.json'),
    noGCDiagnostic=read(D / 'no-gc-analysis.json'),
    GCObservations=gc,
    retainedExperiments=dict(resultRegisters=read(R / 'screen-analysis.json'),
                             vectorAudit=read(R / 'vector-counter-audit/analysis.json'),
                             scalarPairAudit=read(R / 'scalar-counter-audit/analysis.json'),
                             initialDirectResumeAudit=read(D / 'counter-screen/analysis.json'),
                             initialDirectResumeP3=read(D / 'p3-screen-analysis.json')),
    validation=dict(Go='32 root test packages pass; all 31 measured executable packages >=90% statement coverage.',
                    LLGo='New production-profile codegen/nativeexec suites execute successfully, including focused constants/shared-memory return cases.',
                    regression='Before correction, isolated test crashes at address 7654321: the callee constant used as a cached memory binding. Corrected test and official wasi-threads pass; failed logs retained.',
                    CI='Final-head complete Go/LLGo x Linux amd64/macOS arm64 checks required before merge.'),
    protocolErrata='Initial result-register screens retain stale template scope/source prose. Actual commands, hashes, sourceRevision records and overlays identify c3cd0c4b versus its register-result diagnostic. Final committed events have explicit correct identities. No event is rewritten, extended or pooled.',
    interpretation='See the accompanying study for adverse points, unresolved controls, distinct counter/prototype events and collection-work qualifications. No competitive, portfolio or release acceptance is claimed.',
    evidence=dict(path='../evidence/' + evidence.name, records=sum(counts.values()),
                  cohorts=counts, sha256=digest(evidence),
                  projection='Only unused RequestNs/PublicAPINs vectors become count/extrema/canonical-JSON SHA256; full originals remain local. All process records, phases, rusage, GC/allocation counters, outputs and interleave orders remain.'),
    protocol=dict(path=protocol.name, sha256=digest(protocol)),
)
path = W / 'docs/research/data' / (name + '.json')
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(records=sum(counts.values()), cohorts=counts,
                      dataBytes=path.stat().st_size, evidenceBytes=evidence.stat().st_size,
                      protocolBytes=protocol.stat().st_size), indent=2))
