from pathlib import Path
import json,os,random,statistics,sys,hashlib,subprocess
D=Path(__file__).resolve().parent;A=D.parent.parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');P=A/'native-frame-deltas-20261114'
sys.path.insert(0,str(W/'benchmarks'));sys.path.insert(0,str(W/'benchmarks/native'))
import interleaved,runtime_fixtures
os.environ['GOMAXPROCS']='1';os.environ['GOGC']='100'
count=5000000;seed=17;expected=runtime_fixtures.checksum('nested-calls',seed,count*2)
refs=json.loads((A/'transitive-leaves/plan.json').read_text())['commands']
binaries={'base':str(D.parent/'base-go-phase-committed'),'head':str(D.parent/'head-go-phase-committed'),**{k:refs[k][0]for k in ('wazero','wasmtime','wasmer')},'native-llvm':str(A/'transitive-leaves/native-llvm-control'),'llgo-base':str(D.parent/'base-llgo-phase-committed'),'llgo-head':str(D.parent/'head-llgo-phase-committed')}
commands={}
for name,binary in binaries.items():
 if name=='native-llvm':
  cmd=[binary,str(count*2),str(seed),str(expected)];commands[name]=cmd;commands[name+'-aa']=cmd;continue
 cmd=[binary,'--backend','native'if name in ('base','head','llgo-base','llgo-head')else'compiler','--wasm',str(P/'generic-calls.wasm'),'--iterations',str(count),'--seed',str(seed),'--expected',str(expected),'--samples','7','--warmups','2']
 if name in ('base','head','llgo-base','llgo-head'):cmd+=['--mode','api']
 commands[name]=cmd;commands[name+'-aa']=cmd
plan=dict(blocks=20,samples=7,warmups=2,iterations=count,seed=seed,expected=expected,randomSeed=202611150801,commands=commands,binaryHashes={k:hashlib.sha256(Path(v).read_bytes()).hexdigest()for k,v in binaries.items()},scope='Fixed 20 blocks/320 fresh processes, Go and LLGo exact base5e25ac7d versus heade9383987, symmetric five-file Git overlays; Go1.27.3 and LLGo6a482f7f -O3/fullLTO/LLVM22.1.8/default GC. General native calls, three independent pinned runtimes and unchecked C2N oracle normalized per guest source iteration; no source/build/test/profile/pruning overlap, no extension or portfolio acceptance.')
assert not(D/'rows.jsonl').exists();(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rng=random.Random(plan['randomSeed']);rows=[]
for block in range(plan['blocks']):
 load=subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True);(D/f'load-{block}.txt').write_text('\n'.join(l for l in load.splitlines()[1:]if float(l.split(None,2)[1])>5)+'\n')
 observations,orders=interleaved.invoke(commands,180,rng,samples=7)
 for name,ob in observations.items():
  r=ob['record'];assert r['result']==expected and r['warmResults']==[expected]*7 and r['warmupResults']==[expected]*2
  if name.removesuffix('-aa') in ('base','head','llgo-base','llgo-head'):
   role=name.removesuffix('-aa');assert r['sourceRevision']==('e938398763259e560840fee5e86070f22c0f3b93'if role.endswith('head')else'5e25ac7dff2ef5f56795125ab064cd4ccf9f0996') and r['compilerRevision']==('6a482f7f6ad94e9f2d0a0fea97dd4cabd46b1130'if role.startswith('llgo-')else'go1.27.3')
  row=dict(block=block,id=name,nsPerIteration=statistics.median(r['warmCallNs'])/count,observation=ob,orders=orders)
  with(D/'rows.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  rows.append(row)
 print('block',block,{n:round(rows[-len(commands)+i]['nsPerIteration'],4)for i,n in enumerate(observations)},flush=True)
summary={n:statistics.median(r['nsPerIteration']for r in rows if r['id']==n)for n in commands};(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
