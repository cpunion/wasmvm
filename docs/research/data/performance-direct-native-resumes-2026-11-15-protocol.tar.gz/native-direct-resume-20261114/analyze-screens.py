from pathlib import Path
import gzip,json,math,random,statistics
D=Path(__file__).resolve().parent
rng=random.Random(202611150411)
def ratio(xs):
 logs=[math.log(v)for v in xs];n=len(logs);boots=sorted(math.exp(sum(rng.choices(logs,k=n))/n)for _ in range(20000));return dict(ratio=math.exp(sum(logs)/n),ci95=[boots[500],boots[19499]])
all_results={}
for folder in ('p3-screen-16','p3-screen-65536'):
 p=D/folder;compressed=p/'rows.jsonl.gz';rows=[json.loads(l)for l in (gzip.open(compressed,'rt')if compressed.exists()else(p/'rows.jsonl').open())];groups={}
 for r in rows:groups.setdefault(r['block'],{})[r['id']]=r
 plan=json.loads((p/'plan.json').read_text());ids=set(r['id']for r in rows);roles=sorted(n for n in ids if not n.endswith('-aa'));assert len(rows)==plan['blocks']*len(roles)*2
 result={'processes':len(rows),'medians':{},'comparisons':{}}
 for r in rows:
  record=r.get('record',r.get('observation',{}).get('record'))
  for k,v in record['phasesNs'].items():r['phase_'+k]=v
  if not compressed.exists():
   r['readinessNs']=r['observation']['processReadyNs']
 keys=['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest']if compressed.exists()else['nsPerIteration','readinessNs']
 keys+=sorted({k for r in rows for k in r if k.startswith('phase_')})
 for role in roles:
  result['medians'][role]={k:statistics.median(r[k]for r in rows if r['id']in (role,role+'-aa'))for k in keys if all(k in r for r in rows if r['id']in (role,role+'-aa'))}
 for key in keys:
  available=[n for n in roles if all(key in b[n]and key in b[n+'-aa']and b[n][key]>0 and b[n+'-aa'][key]>0 for b in groups.values())]
  v={'AA':{}}
  for role in available:
   aa=ratio([b[role+'-aa'][key]/b[role][key]for b in groups.values()]);aa['resolves2_5Percent']=aa['ci95'][0]>=.975 and aa['ci95'][1]<=1.025;v['AA'][role]=aa
  def compare(a,b):return ratio([math.sqrt(g[a][key]*g[a+'-aa'][key])/math.sqrt(g[b][key]*g[b+'-aa'][key])for g in groups.values()])
  for a,b in [('head','base'),('head','wasmtime'),('head','wazero'),('head','wasmer'),('head','native-llvm'),('llgo-head','llgo-base'),('llgo-head','head'),('llgo-head','wasmtime')]:
   if a in available and b in available:v[a+'/'+b]=compare(a,b)
  result['comparisons'][key]=v
 (p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');all_results[folder]=result
 if folder.startswith('p3-screen-'):
  print(folder,json.dumps({k:result['comparisons'][k]for k in ('cpuUs','instructions','throughput','phase_compileValidate')}),flush=True)
 elif folder.endswith('-final'): print(folder,json.dumps(result['comparisons']['nsPerIteration']),flush=True)
(D/'p3-screen-analysis.json').write_text(json.dumps(all_results,indent=2)+'\n')
