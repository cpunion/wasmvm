package phase
func init(){sourceRevision="c3cd0c4b2c1feb7c0a8fcac8c8392b1230992711+register-results-diagnostic";compilerRevision="go1.27.3"}
