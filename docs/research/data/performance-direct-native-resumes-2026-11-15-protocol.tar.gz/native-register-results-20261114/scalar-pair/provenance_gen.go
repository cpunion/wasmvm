package phase
func init(){sourceRevision="5e25ac7dff2ef5f56795125ab064cd4ccf9f0996+scalar-pair-diagnostic";compilerRevision="go1.27.3"}
