"""Fixed native Linux source audit for the adverse PR memory-loop points."""
from pathlib import Path
import hashlib, json, os, random, statistics, subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "memory-source-results"
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(ROOT / "benchmarks"))
import interleaved
import phase_ci

BASE = "14466bade1679ead9be33776416d767bcbf207e4"
HEAD = "020e863f7af03bf9e8f40003ba6a70ad8e7d24c5"
os.environ.update(GOMAXPROCS="4", GOGC="100", GOTOOLCHAIN="local",
                  CGO_ENABLED="1", CC="/usr/lib/llvm-22/bin/clang", GOWORK="off", GOFLAGS="-mod=readonly")
def capture(cmd):
    return subprocess.check_output(cmd, cwd=ROOT, text=True)
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
builds = {}
for role, revision in [("base", BASE), ("head", HEAD), ("head-full", HEAD)]:
    subprocess.run(["git", "checkout", "--detach", revision], cwd=ROOT, check=True)
    binary = OUT / role
    command = ["go", "build", "-ldflags", "-X github.com/cpunion/wasmvm/internal/bench/phase.sourceRevision=" + revision +
               " -X github.com/cpunion/wasmvm/internal/bench/phase.compilerRevision=go1.27.3"]
    if role == "head-full":
        source = ROOT / "internal/platform/native/native.go"
        text = source.read_text()
        old = "return publishCode(code, entries, maxBytes, true)"
        assert text.count(old) == 1
        overlay_source = OUT / "full-native.go"
        overlay_source.write_text(text.replace(old, "return publishCode(code, entries, maxBytes, false)"))
        overlay = OUT / "full-overlay.json"
        overlay.write_text(json.dumps({"Replace": {str(source): str(overlay_source)}}))
        command += ["-overlay", str(overlay)]
    command += ["-o", str(binary), "./benchmarks/embedded/wasmvm"]
    subprocess.run(command, cwd=ROOT, check=True, timeout=180)
    builds[role] = {"source": revision, "command": command, "sha256": digest(binary), "path": str(binary)}

fixtures = [w for w in phase_ci.load_workloads(ROOT)["workloads"] if w["id"] in ["memory-load-store", "memory-sustained"]]
assert len(fixtures) == 2
cpu = min(os.sched_getaffinity(0))
plan = {"blocks": 20, "samples": 7, "warmups": 2, "seed": 202611136620,
        "builds": builds, "fixtures": fixtures, "go": capture(["go", "version"]),
        "clang": capture([os.environ["CC"], "--version"]), "cpu": capture(["lscpu"]),
        "profiles": {"original": {"GOMAXPROCS": 4}, "pinned": {"GOMAXPROCS": 4, "cpu": cpu}},
        "scope": "Fixed20blocks/480freshprocesses,3sources2AA2memorycases2affinityprofiles. Exact parent/current Go, plus same current source with only integer-only publication forced to the full FP path. Unaltered timed executables. Build actual revisions serially in one checkout, no full source snapshots. Capture anonymous RX mappings from direct child /proc/pid/mem before timed calls. First+2warmups separate,7individuallyinterleavedcheckedcalls. No extension or interim timing look; allobservations retained. AA diagnostic margin2.5%. Not full-portfolio acceptance."}
(OUT / "plan.json").write_text(json.dumps(plan, indent=2) + "\n")

# Observe compiled images without inserting a hook into the timed Go binaries.
original_expect, original_finish = interleaved.Child.expect, interleaved.Child.finish
image_dir = OUT / "images"
image_dir.mkdir(exist_ok=True)
def expect(self, expected):
    original_expect(self, expected)
    if expected != {"sampleReady": 0}:
        return
    self.image_records = []
    pid = self.process.pid
    with open(f"/proc/{pid}/mem", "rb", buffering=0) as memory:
        for line in Path(f"/proc/{pid}/maps").read_text().splitlines():
            fields = line.split()
            if len(fields) != 5 or "x" not in fields[1] or fields[4] != "0":
                continue
            start, end = [int(x, 16) for x in fields[0].split("-")]
            assert 0 < end - start <= 64 << 20
            data = os.pread(memory.fileno(), end - start, start)
            assert len(data) == end - start
            sha = hashlib.sha256(data).hexdigest()
            path = image_dir / (sha + ".bin")
            if not path.exists(): path.write_bytes(data)
            self.image_records.append({"start": start, "bytes": len(data), "sha256": sha})
    assert self.image_records, "no anonymous executable image captured"
def finish(self, ready_ns, record):
    return {**original_finish(self, ready_ns, record), "jitImages": self.image_records}
interleaved.Child.expect, interleaved.Child.finish = expect, finish

rng = random.Random(plan["seed"])
rows = []
for block in range(plan["blocks"]):
    cases = [(profile, fixture) for profile in plan["profiles"] for fixture in fixtures]
    rng.shuffle(cases)
    for profile, f in cases:
        commands = {}
        for role, build in builds.items():
            command = [build["path"], "--mode", "api", "--backend", "native", "--wasm", str(ROOT / "benchmarks/embedded" / f["wasm"]),
                       "--iterations", str(f["iterations"]), "--seed", str(f["seed"]), "--expected", str(f["expectedChecksum"]),
                       "--samples", "7", "--warmups", "2"]
            if profile == "pinned": command = ["taskset", "-c", str(cpu)] + command
            commands[role] = command
            commands[role + "-aa"] = command
        observations, orders = interleaved.invoke(commands, 120, rng, samples=7)
        for role, obs in observations.items():
            record = obs["record"]
            expected_source = BASE if role.startswith("base") else HEAD
            assert record["sourceRevision"] == expected_source and record["compilerRevision"] == "go1.27.3"
            assert record["backend"] == "native" and record["result"] == f["expectedChecksum"]
            assert record["warmResults"] == [f["expectedChecksum"]] * 7 and record["warmupResults"] == [f["expectedChecksum"]] * 2
            row = {"block": block, "profile": profile, "fixture": f["id"], "id": role, "observation": obs,
                   "orders": orders, "nsPerIteration": statistics.median(record["warmCallNs"]) / f["iterations"]}
            rows.append(row)
            with (OUT / "rows.jsonl").open("a") as out: out.write(json.dumps(row) + "\n")
    print("block", block, "checked", flush=True)
summary = {profile: {f["id"]: {role: statistics.median(r["nsPerIteration"] for r in rows if r["profile"] == profile and r["fixture"] == f["id"] and r["id"] == role)
                           for role in ["base", "base-aa", "head", "head-aa", "head-full", "head-full-aa"]}
                    for f in fixtures} for profile in plan["profiles"]}
(OUT / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
