from pathlib import Path
import gzip,json,math,random,statistics
D=Path(__file__).resolve().parent;rng=random.Random(202611150629)
def ratio(xs):
 logs=[math.log(v)for v in xs];n=len(logs);b=sorted(math.exp(sum(rng.choices(logs,k=n))/n)for _ in range(20000));return dict(ratio=math.exp(sum(logs)/n),ci95=[b[500],b[19499]])
results={}
for n in ('p3-16','p3-65536','integer-interpreter','integer-native','memory-interpreter','narrow-native','generic-native'):
 p=D/n;f=p/'rows.jsonl.gz';rows=[json.loads(l)for l in(gzip.open(f,'rt')if f.exists()else(p/'rows.jsonl').open())];groups={}
 for r in rows:
  groups.setdefault(r['block'],{})[r['id']]=r;record=r.get('record',r.get('observation',{}).get('record'))
  for k,v in record['phasesNs'].items():r['phase_'+k]=v
 roles=sorted({r['id']for r in rows if not r['id'].endswith('-aa')});assert len(rows)==20*len(roles)*2
 keys=['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest']if f.exists()else['nsPerIteration'];keys+=sorted({k for r in rows for k in r if k.startswith('phase_')});result={'processes':len(rows),'medians':{},'comparisons':{}}
 for role in roles:result['medians'][role]={k:statistics.median(r[k]for r in rows if r['id']in(role,role+'-aa'))for k in keys if all(k in r for r in rows if r['id']in(role,role+'-aa'))}
 for k in keys:
  available=[role for role in roles if all(k in b[role]and k in b[role+'-aa']and b[role][k]>0 and b[role+'-aa'][k]>0 for b in groups.values())];q={'AA':{}}
  for role in available:
   v=ratio([b[role+'-aa'][k]/b[role][k]for b in groups.values()]);v['resolves2_5Percent']=v['ci95'][0]>=.975 and v['ci95'][1]<=1.025;q['AA'][role]=v
  for c in ('base','go','wasmtime'):
   if 'head'in available and c in available:q['head/'+c]=ratio([math.sqrt(b['head'][k]*b['head-aa'][k])/math.sqrt(b[c][k]*b[c+'-aa'][k])for b in groups.values()])
  result['comparisons'][k]=q
 (p/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');results[n]=result;print(n,json.dumps({k:q for k,q in result['comparisons'].items()if k in ('cpuUs','instructions','throughput','nsPerIteration','phase_compileValidate')}),flush=True)
(D/'analysis.json').write_text(json.dumps(results,indent=2)+'\n')
