from pathlib import Path
import json,os,random,statistics,sys,hashlib,subprocess
D=Path(__file__).resolve().parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup')
sys.path.insert(0,str(W/'benchmarks'));import interleaved
os.environ['GOMAXPROCS']='1';os.environ['GOGC']='100'
config={'backend': 'native', 'wasm': '/Users/lijie/source/goplus/wasmvm-source-cleanup/benchmarks/native/memory-fixtures/narrow-unaligned.wasm', 'seed': 305419896, 'iterations': 1000000, 'expected': 2010447593}
binaries={'base': '/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/llgo-upgrade-6a482f7f-20261114/old-llgo-phase', 'head': '/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/llgo-upgrade-6a482f7f-20261114/new-llgo-phase', 'go': '/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-call-entries-20261114/head-go-phase-v2'}
commands={}
for n,p in binaries.items():
 cmd=[p,'--mode','api','--backend',config['backend'],'--wasm',config['wasm'],'--seed',str(config['seed']),'--iterations',str(config['iterations']),'--expected',str(config['expected']),'--samples','7','--warmups','2'];commands[n]=cmd;commands[n+'-aa']=cmd
plan=dict(blocks=20,samples=7,warmups=2,**config,randomSeed=202611150605,commands=commands,binarySHA256={k:hashlib.sha256(Path(v).read_bytes()).hexdigest()for k,v in binaries.items()},fixtureSHA256=hashlib.sha256(Path(config['wasm']).read_bytes()).hexdigest(),scope='Independent fixed20block120process compiler baseline event, ac129220 to6a482f7f, same wasmvm production code, identical flags, normalGC.7interleavedwarm calls, all results checked, first/preparation/readiness/cleanup separate. Everyrole has identical-binaryalias; no local build/test/profile/sourceedit/prune overlap, no extension or portfolio acceptance.')
assert not(D/'rows.jsonl').exists();(D/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rows=[];rng=random.Random(plan['randomSeed'])
for block in range(plan['blocks']):
 load=subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True);(D/f'load-{block}.txt').write_text('\n'.join(l for l in load.splitlines()[1:]if float(l.split(None,2)[1])>5)+'\n')
 observations,orders=interleaved.invoke(commands,180,rng,samples=7)
 for n,ob in observations.items():
  r=ob['record'];assert r['result']==config['expected']and r['warmResults']==[config['expected']]*7 and r['warmupResults']==[config['expected']]*2
  row=dict(block=block,id=n,nsPerIteration=statistics.median(r['warmCallNs'])/config['iterations'],observation=ob,orders=orders)
  with(D/'rows.jsonl').open('a')as f:f.write(json.dumps(row)+'\n')
  rows.append(row)
 print('block',block,flush=True)
summary={n:statistics.median(r['nsPerIteration']for r in rows if r['id']==n)for n in commands};(D/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
