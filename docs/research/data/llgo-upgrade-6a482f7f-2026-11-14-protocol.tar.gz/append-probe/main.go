package main
import("encoding/binary";"encoding/json";"os";"runtime")
var stats runtime.MemStats
var keep []byte
//go:noinline
func word(b []byte,w uint32)[]byte{return binary.LittleEndian.AppendUint32(b,w)}
//go:noinline
func direct(b []byte,w uint32)[]byte{n:=len(b);if cap(b)-n>=4{b=b[:n+4]}else{b=append(b,0,0,0,0)};binary.LittleEndian.PutUint32(b[n:],w);return b}
func events()uint64{runtime.ReadMemStats(&stats);return stats.Mallocs}
func main(){
 const n=100000
 b:=make([]byte,0,16);before:=events();empty:=events()-before
 before=events();for i:=0;i<n;i++{b=word(b[:0],uint32(i));if binary.LittleEndian.Uint32(b)!=uint32(i){panic("word checksum")}};old:=events()-before
 before=events();for i:=0;i<n;i++{b=direct(b[:0],uint32(i));if binary.LittleEndian.Uint32(b)!=uint32(i){panic("direct checksum")}};fixed:=events()-before;keep=b
 json.NewEncoder(os.Stdout).Encode(struct{Compiler string;Calls int;Empty,Word,Direct uint64}{runtime.Compiler,n,empty,old,fixed})
}
