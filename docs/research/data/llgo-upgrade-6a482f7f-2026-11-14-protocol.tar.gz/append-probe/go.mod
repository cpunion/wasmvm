module appendprobe

go 1.27.3
