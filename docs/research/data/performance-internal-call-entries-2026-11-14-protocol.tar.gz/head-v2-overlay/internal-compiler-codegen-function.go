package codegen

import (
	"math"
	"slices"

	"github.com/cpunion/wasmvm/internal/compiler/ir"
	"github.com/cpunion/wasmvm/internal/compiler/nativeabi"
	"github.com/cpunion/wasmvm/internal/compiler/slots"
	"github.com/cpunion/wasmvm/internal/core/module"
	"github.com/cpunion/wasmvm/pkg/wasm"
)

type Limits struct {
	MaxCodeBytes              uint64
	MaxInstructions, MaxSlots uint32
}

func DefaultLimits() Limits { return Limits{64 << 20, 1 << 20, 1 << 20} }

// CompiledFunction is immutable. A continuation is an original slot-code PC,
// never an interior machine address. ReferenceSlots conservatively describes
// every reference-bearing slot in the current frame (root-map ID zero).
type CompiledFunction struct {
	NativeAtomics uint32
	Entry         nativeabi.Entry
	// LinkedEntry is a compiler-only target after ordinary entry checks.
	// Its caller must establish the checked frame, root map and dispatch PC.
	LinkedEntry                   uint32
	Function                      *slots.Function
	Offsets                       []uint32
	ReferenceSlots                []uint32
	Helpers, Calls, EdgeCopies    uint32
	FusedIntegers                 uint32
	MixedIntegers                 uint32
	ForwardedPredicates           uint32
	UsesMemory                    bool
	BoundsElided                  uint32
	DirectMemoryOperands          uint32
	ForwardedMemory               uint32
	MemoryGuards, GuardedAccesses uint32
	LoopGuards                    uint32
	RegisterRegions               uint32
	AllocationBlocks              uint32
	ValueVersions, ValuePhis      uint32
	ValueLoops                    uint32
	DeferredFrameCopies           uint32
	DeferredPredicates            uint32
	DeferredPredicateLiterals     uint32
	// Generated private backedge polls, excluding header/guard/cold polls.
	PrivatePollOffsets            []uint32
	CoalescedSlotGroups           uint32
	HoistedLiterals               uint32
	NativeLoops                   uint32
	UnrolledLoops, UnrolledCopies uint32
	DeadScalarOps                 uint32
	MemoryGrows                   uint32
	ForwardedScalars              uint32
	InlinedCalls, InlineSlots     uint32
	InlineFrames                  uint32
	UsesRuntimeData               bool
	GlobalIndices                 []uint32
	NativeGlobals                 uint32
	NativeTables, NativeFunctions uint32
	NativeVectors                 uint32
	FusedVectors                  uint32
	AliasedVectorReads            uint32
	NativeHeap                    uint32
	HeapCaches                    uint32
	ForwardedHeap                 uint32
	NativeBulk                    uint32
	NativeAllocations             uint32
	NativeAllocationBatch         uint32
	CallRelocations               []CallRelocation
	DispatchRelocations           []uint32
}

// CompileFunction consumes trusted, immutable output of slot lowering. It emits
// complete control flow, integer operations, local/constant/select operations
// and explicit runtime exits for the remaining Core 2.0 semantics. A driver
// must service RuntimeHelper/Call; the compiler never inserts an interpreter.
// Payload[3] enables semantic fuel; Budget bounds native instructions per slice.
// RuntimeHelper/Call publish the instruction PC in Payload[0] and the next PC
// in Continuation. Return publishes its PC for multi-result marshalling.
// Move publishes a large edge-copy plan in Payload[0] and its destination PC
// in Continuation; the driver copies it in bounded, cancelable chunks.
func CompileFunction(arch string, f *slots.Function, limits Limits) (*CompiledFunction, error) {
	return compileFunction(arch, f, limits, Config{})
}

// CompileUnmeteredFunction emits bounded interrupt polls without periodic host
// round trips or dynamic fuel checks. The driver must supply canonical scalar
// values (Hi == 0), as required by value.Value, and Payload[3] == 0. Budget is
// unused. All scalar slots are canonical on exit; vectors retain all 128 bits.
// The shared runtime selects this tier for calls without semantic fuel.
func CompileUnmeteredFunction(arch string, f *slots.Function, limits Limits) (*CompiledFunction, error) {
	return compileFunction(arch, f, limits, Config{Unmetered: true})
}

// Config records validated module assumptions. Entry checks the minimum memory
// length before any optimized access; every resume repeats this binding check.
type Config struct {
	Unmetered          bool
	MemoryMinimumPages uint32
	// MemoryPageSizes follows memory index order; nil means default 64-KiB pages.
	MemoryPageSizes []uint64
	X86Features     X86Features
	ARM64Features   ARM64Features
	// DirectCallees contains only immutable definitions in the same module.
	// An expanded entry requires InlineFrames additional logical frames and
	// InlineSlots remaining slots for the original nested call tree. The runtime
	// must select an ordinary entry when either invocation quota does not fit.
	DirectCallees map[uint32]*slots.Function
	// IndirectCallees indexes bounded leaf candidates by the call's type index.
	// Every candidate must have that validated structural signature. Identity
	// is checked against the current instance's function reference at runtime.
	IndirectCallees map[uint32][]uint32
	FunctionCount   uint32
	// ScalarImports enables guarded integer-storage accessors among imports.
	ScalarImports  uint32
	TableCount     uint32
	SharedMemories []bool
	MemoryCount    uint32
	// Globals follows validated imported-then-defined global index order.
	Globals []module.GlobalType
	// HeapTypes contains the validated module-local aggregate definitions.
	HeapTypes []module.TypeDef
	// NativeAllocations requires the driver's prepare/finish batch protocol.
	NativeAllocations bool
	// NativeThreads requires stable shared views and machine atomic helpers.
	NativeThreads bool
	// LinkedCallees enables bounded native direct calls within this module.
	// All linked bodies use the same sorted global binding layout. The caller
	// must resolve CallRelocations before publishing any linked body.
	LinkedCallees map[uint32]*slots.Function
	LinkedGlobals []uint32
	// LinkedSignatures follows defined-function order. LinkedTypeLabels maps
	// module type indices to the same validated structural identities.
	LinkedSignatures []uint32
	LinkedTypeLabels []uint32
	// SharedDispatch leaves forward address relocations for one module table
	// per policy. The owner must append and link that table before publication.
	SharedDispatch bool
}

func CompileFunctionWithConfig(arch string, f *slots.Function, limits Limits, config Config) (*CompiledFunction, error) {
	return compileFunction(arch, f, limits, config)
}

func compileFunction(arch string, f *slots.Function, limits Limits, config Config) (out *CompiledFunction, err error) {
	unmetered := config.Unmetered
	pageSize := uint64(65536)
	if len(config.MemoryPageSizes) != 0 {
		if len(config.MemoryPageSizes) != max(1, int(config.MemoryCount)) {
			return nil, wasm.ErrInvalid
		}
		for _, size := range config.MemoryPageSizes {
			if size != 1 && size != 65536 {
				return nil, wasm.ErrInvalid
			}
		}
		pageSize = config.MemoryPageSizes[0]
	}
	if pageSize == 65536 && config.MemoryMinimumPages > 65536 {
		return nil, wasm.ErrInvalid
	}
	if config.X86Features&^x86KnownFeatures != 0 || arch != "amd64" && config.X86Features != 0 {
		return nil, wasm.ErrUnsupported
	}
	defer func() {
		if p := recover(); p != nil {
			if e, ok := p.(*wasm.Error); ok {
				out = nil
				err = e
			} else {
				panic(p)
			}
		}
	}()
	if f == nil || len(f.Code) == 0 || len(f.Slots) < int(f.LocalCount) {
		return nil, wasm.ErrInvalid
	}
	if uint64(len(f.Code)) > uint64(limits.MaxInstructions) || uint64(len(f.Slots)) > uint64(limits.MaxSlots) || uint64(len(f.Slots)) > math.MaxInt32/16 {
		return nil, wasm.ErrLimit
	}
	// Each continuation/table edge needs at least one word of code or metadata.
	// Bound label arrays before allocating them, even for enormous br_tables.
	if uint64(len(f.Code)) > limits.MaxCodeBytes/4 || uint64(len(f.Edges)) > limits.MaxCodeBytes/4 {
		return nil, wasm.ErrLimit
	}
	if err := checkFunction(f); err != nil {
		return nil, err
	}
	originalFunction := f
	if !config.NativeThreads {
		f = sharedMemoryHelpers(f, config.SharedMemories)
	}
	empty, err := nativeabi.Wrap(arch, nil, limits.MaxCodeBytes)
	if err != nil {
		return nil, err
	}
	a := assembler{arch: arch, labels: make([]int, 1, len(f.Code)+8), bounded: true, limit: limits.MaxCodeBytes - uint64(len(empty.Code)), longBranches: true, compactBranches: arch == "arm64"}
	e := functionEmitter{a: &a, f: f, exit: a.label(), bad: a.label(), zero: a.label(), overflow: a.label(), unmetered: unmetered, memoryMinimum: uint64(config.MemoryMinimumPages) * pageSize, memoryPageSizes: config.MemoryPageSizes}
	e.x86Features = config.X86Features
	e.arm64Features = config.ARM64Features
	e.nativeThreads = config.NativeThreads
	e.sharedMemories = config.SharedMemories
	e.sharedDefaultMemory = config.NativeThreads && len(config.SharedMemories) != 0 && config.SharedMemories[0]
	e.nativeBulk = unmetered && config.MemoryCount == 1 && (len(config.SharedMemories) == 0 || !config.SharedMemories[0])
	pcs := make([]int, len(f.Code))
	for i := range pcs {
		pcs[i] = a.label()
	}
	for _, in := range f.Code {
		if e.bulkMemoryOpcode(in) {
			e.usesMemory = true
		}
		if isMemoryAccess(in.Op) || in.Op == 0x3f || in.Op == 0x40 || config.NativeThreads && in.Op>>16 == 0xfe && (in.Op&0xffff <= 2 || in.Op&0xffff >= 0x10) {
			e.usesMemory = true
			index := f.Sources[in.Source].Wasm.Memory
			if in.Op == 0x3f || in.Op == 0x40 {
				index = f.Sources[in.Source].Wasm.A
			}
			if index != 0 && index >= config.MemoryCount {
				return nil, wasm.ErrInvalid
			}
			if index != 0 {
				e.sharedDefaultMemory = false
			}
			if in.Op != 0x40 && (index != 0 || config.NativeThreads && uint64(index) < uint64(len(config.SharedMemories)) && config.SharedMemories[index]) {
				e.memoryViews = true
			}
		}
	}
	e.sharedDefaultMemory = e.sharedDefaultMemory && e.memoryViews
	e.start = a.label()
	a.mark(e.start)
	e.header(uint64(len(f.Slots))*16, len(pcs))
	e.prepareHeapAccesses(config)
	if config.NativeAllocations && unmetered {
		e.allocationTypes = config.HeapTypes
		for _, in := range f.Code {
			if _, ok := e.heapAllocationType(in); ok {
				e.hasAllocations = true
				break
			}
		}
	}
	globalIndices, usesRuntimeData := e.prepareRuntimeData(config)
	e.linkedStart = a.label()
	a.mark(e.linkedStart)
	e.memoryFunctions, e.memoryTables, e.memoryGlobals, e.memoryBindings = config.FunctionCount, config.TableCount, uint32(len(config.Globals)), uint32(len(globalIndices))
	if e.usesMemory && (!e.memoryViews || e.sharedDefaultMemory) {
		e.prepareMemory()
	}
	regions := e.addNativeLoops(e.memoryRegions())
	if unmetered {
		e.selectRegisters(config, regions)
		e.prepareVectorConstants()
		e.prepareConstants()
		e.prepareRuntimeRegisters(config)
		e.prepareHeapCaches()
		e.prepareLinearScan(regions, 1<<18)
		plan := e.currentRegisterPlan()
		e.useRegisterPlan(nil)
		if e.allocationPlans == nil {
			e.transitionRegisters(plan)
		}
		e.contextLoad(0, nativeabi.PayloadOffset+24)
		e.test(true)
		e.branch(e.bad, "ne")
		e.contextLoad(0, nativeabi.ContinuationOffset)
	}
	entryPCs := pcs
	if e.allocationPlans != nil {
		entryPCs = make([]int, len(pcs))
		entries := map[*registerPlan]int{}
		for pc, plan := range e.allocationPlans {
			label, ok := entries[plan]
			if !ok {
				label = a.label()
				entries[plan] = label
				e.allocationEntries = append(e.allocationEntries, allocationEdge{label: label, from: e.currentRegisterPlan(), to: plan})
			}
			entryPCs[pc] = label
		}
	}
	a.dispatch(entryPCs)
	out = &CompiledFunction{Function: originalFunction, Offsets: make([]uint32, len(pcs)), UsesMemory: e.usesMemory, GlobalIndices: globalIndices, UsesRuntimeData: usesRuntimeData}
	out.HeapCaches = uint32(len(e.heapCaches))
	out.NativeAllocationBatch = e.allocationBatch
	out.AllocationBlocks = uint32(len(e.allocationStarts))
	if e.valueFlow != nil {
		out.ValueVersions = uint32(len(e.valueFlow.nodes))
		for _, node := range e.valueFlow.nodes {
			if node.phi {
				out.ValuePhis++
			}
		}
	}
	for _, in := range f.Code {
		if nativeVectorOpcode(in.Op) || nativeVectorMemoryOpcode(in.Op) {
			out.NativeVectors++
		}
	}
	for i, t := range f.Slots {
		if t.IsReference() {
			out.ReferenceSlots = append(out.ReferenceSlots, uint32(i))
		}
	}
	var independentEntries []int
	var regionStarts []int
	for pc := range regions {
		regionStarts = append(regionStarts, pc)
	}
	slices.Sort(regionStarts)
	regionPosition := 0
	combinedThrough := -1
	allocationBlock := 0
	for pc, in := range f.Code {
		if pc <= combinedThrough {
			continue
		}
		for regionPosition < len(regionStarts) && regionStarts[regionPosition] <= pc {
			regionPosition++
		}
		e.nativeRegionLimit = 0
		if regionPosition < len(regionStarts) {
			e.nativeRegionLimit = regionStarts[regionPosition]
		}
		if edge, ok := e.loopBackedges[pc]; ok {
			e.frameAliases = edge.aliases
			e.pollSnapshot = edge.snapshot
			if edge.branch != nil {
				e.transitionRegisters(edge.branch)
			}
			poll := a.label()
			a.mark(poll)
			e.privatePollLabels = append(e.privatePollLabels, poll)
			e.interrupt(uint32(pc))
			e.pollSnapshot = nil
			if edge.always {
				a.branch(edge.header, false, 0)
				if edge.registers != nil {
					e.useRegisterPlan(edge.registers)
				}
				independentEntries = append(independentEntries, pc)
				e.frameAliases = nil
				continue
			}
			if edge.snapshot != nil && edge.snapshot.predicate != nil {
				in := edge.snapshot.predicate.in
				e.predicateFlags(edge.snapshot.predicate)
				cc := x86IntegerCondition(in.Op)
				if arch == "arm64" {
					cc = armIntegerCondition(in.Op)
				}
				if !edge.yes {
					cc ^= 1
				}
				a.branch(edge.header, true, cc)
			} else if arch == "arm64" && edge.flags {
				cc := armIntegerCondition(f.Code[pc-1].Op)
				if !edge.yes {
					cc ^= 1
				}
				a.branch(edge.header, true, cc)
				out.ForwardedPredicates++
			} else {
				e.branchCondition(in.A, edge.header, edge.yes)
			}
			e.frameAliases = nil
			e.materializeFrameSnapshot(edge.snapshot, true, !edge.yes)
			restoreMemory := edge.restoreMemory || e.loopBorrowedMemoryLength()
			if edge.registers != nil {
				e.transitionRegisters(edge.registers)
			}
			if restoreMemory {
				e.prepareMemory()
			}
			if edge.exit != pc+1 {
				a.branch(e.targetPC(pcs, edge.exit), false, 0)
			}
			independentEntries = append(independentEntries, pc)
			continue
		}
		if e.allocationPlans != nil {
			for allocationBlock+1 < len(e.allocationStarts) && pc >= e.allocationStarts[allocationBlock+1] {
				allocationBlock++
			}
			e.allocationLimit = len(f.Code)
			if allocationBlock+1 < len(e.allocationStarts) {
				e.allocationLimit = e.allocationStarts[allocationBlock+1]
			}
			if pc == 0 {
				e.useRegisterPlan(e.allocationPlans[pc])
			} else {
				e.transitionRegisters(e.allocationPlans[pc])
			}
		}
		// Only fallthrough from the preceding constant proves an immediate.
		// Keep the original PC as a generic cold entry for branches/resumption.
		if unmetered && pc > 0 && pc%256 != 0 {
			previous := f.Code[pc-1]
			if (previous.Op == 0x41 || previous.Op == 0x42) && previous.Dst == in.B && in.B != slots.NoSlot &&
				e.registerImmediate(in.Op, in.Dst, in.A, f.Sources[previous.Source].Wasm.Bits) {
				independentEntries = append(independentEntries, pc)
				continue
			}
		}
		if e.compareBranchFallthrough(pc, pcs) {
			out.ForwardedPredicates++
			independentEntries = append(independentEntries, pc)
			continue
		}
		a.mark(pcs[pc])
		src := f.Sources[in.Source]
		isControl := in.Op >= slots.ControlBase
		if unmetered {
			if pc%256 == 0 || in.Op >= 0x10 && in.Op <= 0x15 || isControl && !e.fallthroughEdge(pc) {
				e.interrupt(uint32(pc))
			}
		} else {
			e.boundary(uint32(pc), src, in.Op >= 0x10 && in.Op <= 0x15 || isControl)
		}
		if region, ok := regions[pc]; ok {
			e.emitMemoryRegion(pc, region, pcs, out)
			for entry := pc + 1; entry <= region.end; entry++ {
				independentEntries = append(independentEntries, entry)
			}
			combinedThrough = region.end
			continue
		}
		if end, ok := e.combinePlain(pc, 0, out); ok {
			for entry := pc + 1; entry <= end; entry++ {
				independentEntries = append(independentEntries, entry)
			}
			combinedThrough = end
			continue
		}
		if e.atomicInstruction(in, uint32(pc)) {
			out.NativeAtomics++
			if in.Op&0xffff <= 2 && e.atomicShared(in) {
				out.Helpers++ // Queue/pending-registration fallback remains complete.
			}
			continue
		}
		switch op := in.Op; {
		case isControl:
			kind := ir.TermKind(op - slots.ControlBase)
			switch kind {
			case ir.Return:
				if config.LinkedCallees != nil {
					e.linkedReturn(pc)
					continue
				}
				e.leave(nativeabi.Return, uint64(pc), uint64(pc))
			case ir.Trap:
				e.trap(wasm.TrapUnreachable, uint64(src.Wasm.Offset))
			case ir.Jump:
				e.edge(in.Extra, pcs, pc+1)
			case ir.IfCast:
				out.Helpers++
				e.contextConst(nativeabi.SourceOffset, uint64(src.Wasm.Offset))
				e.leave(nativeabi.RuntimeHelper, uint64(pc), uint64(pc))
			case ir.IfNull:
				e.nullConditionalEdges(in, pcs, pc+1)
			case ir.If:
				e.conditionalEdges(in, pcs, pc+1)
			case ir.Table:
				targets := make([]int, in.Count)
				for i := range targets {
					targets[i] = a.label()
				}
				e.slotLoad(in.A, 0, false, false)
				e.constant(1, uint64(in.Count-1))
				e.compare(false)
				valid := a.label()
				e.branch(valid, "lo")
				e.constant(0, uint64(in.Count-1))
				a.mark(valid)
				a.dispatch(targets)
				for i, l := range targets {
					a.mark(l)
					e.edge(in.Extra+uint32(i), pcs, -1)
				}
			}
		case nativeVectorOpcode(op):
			e.vectorInstruction(in)
		case module.IsWideArithmetic(op):
			e.wideArithmetic(in)
		case plainOpcode(op):
			e.plain(in, false)
		case (op == 0x23 || op == 0x24) && e.globalInstruction(in, config):
			out.NativeGlobals++
		case (op == 0x25 || op == 0x26 || op == 0xd2) && e.referenceInstruction(in, config):
			if op == 0xd2 {
				out.NativeFunctions++
			} else {
				out.NativeTables++
			}
		case e.heapInstruction(in):
			out.NativeHeap++
		case e.heapAllocation(in, uint32(pc)):
			out.NativeAllocations++
			out.Helpers++ // The checked slow allocation remains an explicit exit.
		case e.bulkMemoryOpcode(in):
			e.bulkMemory(in, uint32(pc))
			out.NativeBulk++
		case op == 0x40:
			out.MemoryGrows++
			e.contextConst(nativeabi.SourceOffset, uint64(src.Wasm.Offset))
			e.leave(nativeabi.GrowMemory, uint64(pc), uint64(pc+1))
		case op == 0x12 || op == 0x13 || op == 0x15:
			out.Calls++
			e.contextConst(nativeabi.SourceOffset, uint64(src.Wasm.Offset))
			// Tail calls discard this continuation in the common frame driver.
			e.leave(nativeabi.Call, uint64(pc), uint64(pc))
		case op == 0x10 || op == 0x11 || op == 0x14:
			out.Calls++
			if op == 0x10 && e.scalarStorageCall(pc, config, uint32(len(globalIndices))) {
				continue
			}
			var end int
			var expanded bool
			if op == 0x10 {
				end, expanded = e.inlineLeaf(pc, config.DirectCallees[src.Wasm.A], config.DirectCallees)
				if expanded {
					out.InlineSlots = max(out.InlineSlots, uint32(len(config.DirectCallees[src.Wasm.A].Slots)))
				}
			} else if op == 0x11 {
				var needed uint32
				end, needed, expanded = e.inlineIndirect(pc, config)
				if expanded {
					out.InlineSlots = max(out.InlineSlots, needed)
					out.UsesRuntimeData = true
				}
			}
			if expanded {
				out.InlinedCalls++
				if end != pc {
					independentEntries = append(independentEntries, end)
					combinedThrough = end
				}
				continue
			}
			if (op == 0x11 || op == 0x14) && e.linkedIndirect(pc, config) {
				continue
			}
			if op == 0x10 && e.linkedCall(pc, config.LinkedCallees[src.Wasm.A]) {
				continue
			}
			e.contextConst(nativeabi.SourceOffset, uint64(src.Wasm.Offset))
			e.leave(nativeabi.Call, uint64(pc), uint64(pc+1))
		case helperOpcode(op):
			out.Helpers++
			e.contextConst(nativeabi.SourceOffset, uint64(src.Wasm.Offset))
			e.leave(nativeabi.RuntimeHelper, uint64(pc), uint64(pc+1))
		default:
			return nil, wasm.ErrUnsupported
		}
	}
	// A validated function never falls through its final terminator.
	for _, pc := range independentEntries {
		if e.allocationPlans != nil {
			e.useRegisterPlan(e.allocationPlans[pc])
		}
		a.mark(pcs[pc])
		if f.Code[pc].Op == slots.ControlBase+uint32(ir.If) {
			e.interrupt(uint32(pc))
			e.conditionalEdges(f.Code[pc], pcs, -1)
		} else if f.Code[pc].Op == slots.ControlBase+uint32(ir.Jump) {
			e.interrupt(uint32(pc))
			e.edge(f.Code[pc].Extra, pcs, -1)
		} else {
			if !e.heapInstruction(f.Code[pc]) {
				e.plain(f.Code[pc], false)
			}
			a.branch(e.targetPC(pcs, pc+1), false, 0)
		}
	}
	for _, fallback := range e.memoryFallbacks {
		e.useRegisterPlan(fallback.registers)
		a.mark(fallback.label)
		e.plain(f.Code[fallback.pc], false)
		a.branch(e.targetPC(pcs, fallback.pc+1), false, 0)
	}
	e.emitAllocationEdges()
	e.emitAllocationEntries(pcs)
	e.emitPollExits()
	e.emitCallExits(config)
	e.emitTrapExits()
	e.emitLinkedDispatch(config)
	a.mark(e.bad)
	e.rawStatus(nativeabi.BadState)
	a.mark(e.zero)
	e.trapCode(wasm.TrapIntegerDivideByZero)
	a.mark(e.overflow)
	e.trapCode(wasm.TrapIntegerOverflow)
	a.mark(e.exit)
	out.InlineSlots = max(out.InlineSlots, e.inlineSlots)
	out.InlineFrames = e.inlineFrames
	out.EdgeCopies = e.edgeCopies
	out.MixedIntegers = e.mixedIntegers
	out.BoundsElided = e.boundsElided
	out.DirectMemoryOperands = e.directMemoryOperands
	out.ForwardedMemory = e.forwardedMemory
	out.AliasedVectorReads = e.aliasedVectorReads
	body, err := a.finish()
	if err != nil {
		return nil, err
	}
	out.Entry, err = nativeabi.Wrap(arch, body, limits.MaxCodeBytes)
	if err != nil {
		return nil, err
	}
	linkedPosition, _ := a.labelAt(e.linkedStart)
	out.LinkedEntry = out.Entry.BodyOffset + uint32(linkedPosition)
	for i, l := range pcs {
		position, _ := a.labelAt(l)
		out.Offsets[i] = out.Entry.BodyOffset + uint32(position)
	}
	for _, label := range e.privatePollLabels {
		position, _ := a.labelAt(label)
		out.PrivatePollOffsets = append(out.PrivatePollOffsets, out.Entry.BodyOffset+uint32(position))
	}
	for _, call := range e.linkedRelocations {
		position, _ := a.labelAt(call.label)
		out.CallRelocations = append(out.CallRelocations, CallRelocation{Offset: out.Entry.BodyOffset + uint32(position), Function: call.target})
	}
	for _, label := range e.dispatchRelocations {
		position, _ := a.labelAt(label)
		out.DispatchRelocations = append(out.DispatchRelocations, out.Entry.BodyOffset+uint32(position))
	}
	return out, nil
}

func isInteger(op uint32) bool {
	return op >= 0x45 && op <= 0x5a || op >= 0x67 && op <= 0x8a || op == 0xa7 || op == 0xac || op == 0xad || op >= 0xc0 && op <= 0xc4
}
func integerWide(op uint32) bool {
	return op >= 0x50 && op <= 0x5a || op >= 0x79 && op <= 0x8a || op == 0xac || op == 0xad || op >= 0xc2
}
func helperOpcode(op uint32) bool {
	return op >= 0xe0 && op <= 0xe6 || op == slots.SharedMemoryOp || op>>16 == 0xfe || op == 8 || op == 10 || op >= 0x23 && op <= 0x26 || op >= 0x28 && op <= 0x40 || op >= 0x5b && op <= 0x66 || op >= 0x8b && op <= 0xbf || op == 0xd2 || op == 0xd3 || op>>16 == 0xfb || op >= 0xfc0000 && op <= 0xfc0011 || op>>16 == 0xfd
}

func checkFunction(f *slots.Function) error {
	valid := func(s slots.Slot) bool { return s != slots.NoSlot && uint64(s) < uint64(len(f.Slots)) }
	for _, s := range f.Args {
		if !valid(s) {
			return wasm.ErrInvalid
		}
	}
	for _, m := range f.Moves {
		if !valid(m.Dst) || !valid(m.Src) {
			return wasm.ErrInvalid
		}
	}
	for _, e := range f.Edges {
		if uint64(e.PC) >= uint64(len(f.Code)) || uint64(e.Start)+uint64(e.Count) > uint64(len(f.Moves)) {
			return wasm.ErrInvalid
		}
	}
	for _, in := range f.Code {
		if uint64(in.Source) >= uint64(len(f.Sources)) {
			return wasm.ErrInvalid
		}
		for _, s := range []slots.Slot{in.A, in.B, in.C, in.Dst} {
			if s != slots.NoSlot && !valid(s) {
				return wasm.ErrInvalid
			}
		}
		if in.Op >= 0x20 && in.Op <= 0x22 && f.Sources[in.Source].Wasm.A >= f.LocalCount {
			return wasm.ErrInvalid
		}
		if in.Op >= slots.ControlBase {
			if in.Op > slots.ControlBase+uint32(ir.IfNull) {
				return wasm.ErrInvalid
			}
			kind := ir.TermKind(in.Op - slots.ControlBase)
			switch kind {
			case ir.Return:
				if uint64(in.Extra)+uint64(in.Count) > uint64(len(f.Args)) {
					return wasm.ErrInvalid
				}
			case ir.Trap:
			case ir.Jump, ir.If, ir.Table, ir.IfNull, ir.IfCast:
				if in.Count == 0 || kind == ir.Jump && in.Count != 1 || (kind == ir.If || kind == ir.IfNull || kind == ir.IfCast) && in.Count != 2 || uint64(in.Extra)+uint64(in.Count) > uint64(len(f.Edges)) {
					return wasm.ErrInvalid
				}
			default:
				return wasm.ErrInvalid
			}
		}
		if in.Op == 8 || in.Op == 10 || in.Op >= 0x10 && in.Op <= 0x15 || in.Op>>16 == 0xfb || module.IsWideArithmetic(in.Op) || in.Op >= 0xe0 && in.Op <= 0xe6 {
			outputs := 0
			if in.Op == 0x10 || in.Op == 0x11 || in.Op == 0x14 || in.Op>>16 == 0xfb || module.IsWideArithmetic(in.Op) || in.Op >= 0xe0 && in.Op <= 0xe6 {
				outputs = len(f.Sources[in.Source].Outputs)
			}
			if uint64(in.Extra)+uint64(in.Count)+uint64(outputs) > uint64(len(f.Args)) {
				return wasm.ErrInvalid
			}
			if module.IsWideArithmetic(in.Op) {
				count := uint32(2)
				if in.Op <= 0xfc0014 {
					count = 4
				}
				if in.Count != count || outputs != 2 || f.Args[in.Extra+count] == f.Args[in.Extra+count+1] {
					return wasm.ErrInvalid
				}
				for _, slot := range f.Args[in.Extra : in.Extra+count+2] {
					if f.Slots[slot] != wasm.I64 {
						return wasm.ErrInvalid
					}
				}
			}
		}
	}
	return nil
}
