;; Diagnostic guest counterfactual: same arithmetic, explicit local reset, no Wasm call.
(module
 (func (export "run") (param $x i32) (param $n i32) (result i32) (local $i i32) (local $j i32)
  (loop $outer
   i32.const 0 local.set $j
   (loop $inner
    local.get $x i32.const 1664525 i32.mul i32.const 1013904223 i32.add local.set $x
    local.get $j i32.const 1 i32.add local.tee $j i32.const 2 i32.lt_u br_if $inner)
   local.get $i i32.const 1 i32.add local.tee $i local.get $n i32.lt_u br_if $outer)
  local.get $x))
