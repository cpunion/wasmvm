package phase
func init(){sourceRevision="433d995d2de4f4ed158fe156cbd4f1f04ac7ec5a";compilerRevision="go1.27.3"}
