package phase
func init(){sourceRevision="fe1dc69b1113e9c7bb60f1ef9b358ae28ce3d6bd";compilerRevision="go1.27.3"}
