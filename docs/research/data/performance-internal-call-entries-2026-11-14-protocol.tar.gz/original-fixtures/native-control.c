#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static uint64_t now(void) { struct timespec t; if (clock_gettime(CLOCK_MONOTONIC_RAW, &t)) exit(2); return (uint64_t)t.tv_sec*1000000000+t.tv_nsec; }
__attribute__((noinline)) static uint32_t run(uint32_t x, uint32_t n) {
    __asm__ volatile("" : "+r"(x), "+r"(n) : : "memory");
    for (uint32_t i=0;i<n;++i) x=x*UINT32_C(1664525)+UINT32_C(1013904223);
    return x;
}
int main(int argc, char **argv) {
    if (argc != 4) return 2;
    uint32_t count=(uint32_t)strtoul(argv[1],0,10), seed=(uint32_t)strtoul(argv[2],0,10), expected=(uint32_t)strtoul(argv[3],0,10);
    if (!count || count>INT32_MAX) return 2;
    char line[32]; uint64_t warm[7], first=0;
    puts("{\"ready\":true}"); fflush(stdout);
    if (!fgets(line,sizeof line,stdin) || strcmp(line,"run\n")) return 2;
    for (int i=-3;i<7;++i) {
        if (i>=0) { printf("{\"sampleReady\":%d}\n",i); fflush(stdout); if (!fgets(line,sizeof line,stdin) || strcmp(line,"sample\n")) return 2; }
        uint64_t start=now(); uint32_t result=run(seed,count); uint64_t elapsed=now()-start;
        if (result != expected) return 3;
        if (i==-3) first=elapsed;
        if (i>=0) warm[i]=elapsed;
    }
    printf("{\"engine\":\"native-llvm-control\",\"iterations\":%u,\"seed\":%u,\"result\":%u,\"warmCallNs\":[",count,seed,expected);
    for(int i=0;i<7;++i) printf("%s%llu",i?",":"",(unsigned long long)warm[i]);
    printf("],\"warmResults\":["); for(int i=0;i<7;++i)printf("%s%u",i?",":"",expected);
    printf("],\"warmupResults\":[%u,%u],\"phasesNs\":{\"firstCall\":%llu}}\n",expected,expected,(unsigned long long)first);
    return 0;
}
