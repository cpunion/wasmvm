# Internal native call entries

The ordinary C entry and every native host resume keep the full header checks.
Only compiler-owned linked branches target the interior entry after the header.
Before a push, the caller checks call metadata capacity, global logical depth,
the invocation slot quota and physical arena capacity for both complete frames.
It initializes the entire callee frame and copies complete parameters. The used
offset is the validated parent offset plus its checked, 16-byte slot extent.

The private entry receives the computed callee frame in the standard frame
register, root-map zero and the current continuation PC in the ordinary dispatch
register. A native return derives its parent frame from compiler-owned immutable
call metadata and restores that same entry state. Its continuation was emitted
by the compiler and cannot be written by guest linear-memory operations. Host
reentry still goes through the authenticated common chain and the ordinary
entry. Reducing invocation budgets is checked before any resumed native run.

Nonlinked bodies retain their existing machine bytes: adding an interior label
emits no instructions. Native direct/indirect targets and saved native returns
share this protocol; no separate executor, function fallback or hardware-stack
switch is introduced. Register/slot state, memory preparation, metered boundaries,
root publication and cancellation checks after the header remain unchanged.

The initial prototype incorrectly clobbered the dispatch PC while setting the
root map, which the existing metered/resumption suite rejected. The corrected
entry explicitly reloads that PC. Preserve both failed and passing logs; do not
claim production completion from the local prototype.

Next validation: exact committed source identity, all Go/LLGo supported targets,
full per-package coverage, ordinary header rejection under linked configurations,
large/mixed result tuples, recursion/quotas, host reentry, cancellation and roots.
Go-first source/reference comparisons must keep cold phases and all controls.
