from pathlib import Path
import json,sys
sys.path.insert(0,"/Users/lijie/source/goplus/wasmvm-source-cleanup/benchmarks")
import comparison_format as fmt
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');stem='bounded-pure-call-2026-11-20';data=json.loads((w/'docs/research/data'/f'{stem}.json').read_text());core=data['core']['results'];p3=data['p3']['results'];out=[]
def add(s=''):out.append(s)
def table(headers,rows):
 add('| '+' | '.join(headers)+' |');add('| '+' | '.join(['---']+['---:']*(len(headers)-1))+' |')
 for row in rows:add('| '+' | '.join(map(str,row))+' |')
 add()
def num(v):return f'{v:,.3f}'if abs(v)<100 else f'{v:,.2f}'
def ratio(v, **kwargs):return fmt.comparison(v, **kwargs)
headers=['Workload / metric','wasmvm Go','wasmvm LLGo','wazero','Wasmtime','Wasmer','WasmEdge']
roles={'native':['head-go-native','head-llgo-native','wazero-compiler','wasmtime-compiler','wasmer-compiler','wasmedge-compiler'],'interpreter':['head-go-interpreter','head-llgo-interpreter','wazero-interpreter',None,None,'wasmedge-interpreter']}
failed={(x['cohort']+'/'+x['case'],x['runtime'])for x in data['failures']['failures']}
def unavailable(key,role):
 if role is None:return 'NM'
 if (key,role)in failed:return '**FAIL: SIGSEGV**'
 return 'US'
def cell(key,role,phase=None):
 v=core[key]
 if role not in v['mediansNsPerIteration']:return unavailable(key,role)
 if phase is not None:
  n=v['phasesMedianNs'][role].get(phase);return 'N/A'if n is None else num(n/1000)
 backend='native' if role in roles['native'] else 'interpreter'
 reference='wasmtime-compiler' if backend=='native' else 'wazero-interpreter'
 if reference not in v['mediansNsPerIteration']:reference='wasmedge-interpreter'
 value=v['mediansNsPerIteration'][role];baseline=v['mediansNsPerIteration'][reference]
 unresolved=not(v['AA'][role]['resolves2_5Percent'] and v['AA'][reference]['resolves2_5Percent'])
 return num(value)+' ('+('ref' if role==reference else fmt.observed(value,baseline)+' speed')+')'+(' †' if unresolved else '')
add('# Bounded pure calls: complete runtime comparison, 2026-11-20');add()
add('Constant-decidable pure integer calls now expand within the shared 256-visit budget. Wrapping affine expressions compose without mutating shared nodes, and final expression literals enter the existing register cache. Unknown/effectful/recursive or over-budget paths retain ordinary calls; precise fuel, original logical stack quotas, caller cold continuations and cancellation remain supported.');add()
add('The general-call workload falls from about **3.84/3.86 to 1.044/1.044 ns per iteration** for Go/LLGo. Paired source ratios are **0.26995 [0.26260,0.27766]** and **0.26423 [0.25564,0.26948]**, both controls pass: **−73.01%/−73.58% time**, **+270.44%/+278.46% speed**. Both host compilers beat Wasmtime and Wasmer on this workload with resolving controls; WasmEdge O3 AOT observes **1.037 ns**, but its control leaves precise parity unresolved. This workload now includes different engines’ successful loop expansion/inlining; it does not isolate a surviving call ABI.');add()
add('This fresh event covers all **33 core workloads** and **two complete P3 payloads**, with four independent runtime columns. SHA, field access, shared memory and complete P3 still require work; there is no overall parity or milestone-completion claim. Latest LLGo also has resolved interpreter regressions, including **+15.72% time on SIMD lanes**, investigated separately below. All adverse results remain recorded.');add()
add('## Percentage differences');add()
add('Cells show `absolute observation (signed speed Δ%)`. Positive speed change means faster. Native execution and P3 use **Wasmtime** as a fixed reference; interpreter execution uses **wazero**, with **WasmEdge** explicitly named for GC rows where wazero rejects the feature. These choices make each table comparable across revisions; they do not assert that the reference is the fastest competitor.');add()
add('For time, speed Δ = `(reference / candidate - 1) * 100%`; for throughput, speed Δ = `(candidate / reference - 1) * 100%`. Thus 100 ns to 50 ns is **−50% time**, **+100% speed**. P3 CPU percentages mean work per CPU time, separate from wall-clock throughput. Instruction/allocation/byte counters show quantity Δ rather than speed. Source/SDK comparisons retain paired ratio intervals and report quantity Δ plus speed Δ where applicable; reciprocal interval endpoints are reversed.');add()
add('Competitive cell percentages are descriptive quotients of the displayed medians; paired block estimates below can differ. `†` on these cells means either the candidate or the named reference has unresolved A/A controls; it never establishes a qualified win. Incomparable preparation/phase boundaries keep separate absolute observations. This is a presentation update of the recorded event, not a measurement of later compiler changes.');add()
add('## Revisions, profiles and protocol')
add()
add('- Engine source: base `18dbc5cb` (merged PR #201), measured head `329d2c0f` for PR #202. Reused binaries retain their actual producer revisions; `build.json` records verified production-source equivalence to the qualified source. No full source copies or new worktrees were created.')
add('- Go **1.27.3**; LLGo **3c6b33ec**, **`-O3 -lto=full`**, LLVM **22.1.8**, default production GC. Source base/head share the compiler profile. LLGo **114c98b4** on the same source baseline measures the SDK upgrade independently.')
add('- wazero **1.12.0**, native compiler/interpreter; Wasmtime **48.0.1**, Cranelift speed; Wasmer **7.3.0**, Cranelift; WasmEdge **0.17.1**, interpreter and **O3 AOT**. These are explicit pinned profiles, not a claim that every available backend or configuration was measured.')
add('- Local Apple M4 Max, macOS arm64, 128 GiB RAM. External desktop load is uncontrolled and recorded; no owned builds, tests, profiles, analysis or edits overlap timing. This is not a Linux amd64 performance result.')
add('- Core: six fixed fresh-process blocks, each with symmetric same-binary A/A, two warmups and seven interleaved measured calls. **6,156 successful process records** after excluding exactly three failing sustained WasmEdge AOT cells. All 33 workloads remain represented. Allocation workloads use means including pauses; others use medians.')
add('- P3: **84 processes per payload**, seven roles with A/A, six fixed blocks, four workers, sixteen clients and twenty interleaved 512-request windows plus a separate flush. Verify status, headers, full body, trailers, CRC and joined guest completion. CPU/instruction counters include the driver and checks. Mach ticks use the recorded timebase.')
add('- Ratios use paired block geometric means and 20,000 fixed-seed bootstrap resamples with marginal 95% intervals. Both relevant A/A intervals must fit `[0.975, 1.025]`. No simultaneous portfolio-acceptance claim, adaptive extension, phase subtraction or cross-event pooling.')
add()
add('**Legend:** `†` means the role or its percentage reference has an unresolved same-binary timing control. Values are observations; a qualified comparison additionally needs both controls and its ratio interval. `US` means this pinned profile rejected the feature in semantic preflight. `NM` means this benchmark adapter/profile was not measured; it does not claim the engine lacks the capability. `N/A` means the metric does not apply. `FAIL` is an execution failure, never an unsupported-feature classification or performance win.')
add()
for backend in roles:
 add('## '+('Native compiled execution'if backend=='native'else'Interpreter execution'));add()
 add('Warm **ns/source iteration**, except SHA uses **ns/message block**. Cohorts distinguish the original 22 cases from four sustained GC, six sustained Threads, and the general-call workload.');add()
 add('Reference: **Wasmtime**.' if backend=='native' else 'Reference: **wazero**; GC rows explicitly use **WasmEdge**.');add()
 table(headers,[[key+(' (vs WasmEdge)' if backend=='interpreter' and 'wazero-interpreter'not in core[key]['mediansNsPerIteration'] else '')]+[cell(key,r)for r in roles[backend]]for key in core])
add('## Complete P3 HTTP requests');add()
add('P3 competitor cells marked `NM` have no measured adapter for the pinned component/WASI workload. Wasmtime uses the same validated workload. Managed allocation counts exclude foreign Rust/C/JIT allocations and cannot compare total allocation across engines.');add()
rows=[]
for size,v in p3.items():
 for metric,label in [('cpuUs','CPU, us/request'),('instructions','instructions/request'),('throughput','requests/s')]:
  cells=[]
  for role in ['head-go','head-llgo',None,'wasmtime',None,None]:
   if role is None:cells.append('NM');continue
   value=v['medians'][role][metric];reference=v['medians']['wasmtime'][metric]
   delta=fmt.signed(100*(value/reference-1))+' Δ' if metric=='instructions' else fmt.observed(value,reference,higher_is_better=metric=='throughput')+' speed'
   unresolved=not(v['AA'][role][metric]['resolves2_5Percent'] and v['AA']['wasmtime'][metric]['resolves2_5Percent'])
   cells.append(num(value)+' ('+('ref'if role=='wasmtime'else delta)+')'+(' †'if unresolved else ''))
  rows.append([size+' B '+label]+cells)
table(headers,rows)
add('### P3 source and SDK contrasts');add()
rows=[]
for size,v in p3.items():
 for metric in ['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest']:
  rows.append([size+' B '+metric,ratio(v['comparisons']['head-go/base-go'][metric],higher_is_better=metric=='throughput',speed=metric in ['cpuUs','throughput']),ratio(v['comparisons']['head-llgo/base-llgo'][metric],higher_is_better=metric=='throughput',speed=metric in ['cpuUs','throughput']),ratio(v['comparisons']['base-llgo/old-sdk-base-llgo'][metric],higher_is_better=metric=='throughput',speed=metric in ['cpuUs','throughput'])])
table(['Metric','Go source head/base','LLGo source head/base','LLGo SDK3c/SDK114 on fixed base'],rows)
add('Throughput ratios above one improve; CPU/instructions/allocation ratios below one improve. The JSON also retains the combined PR source+SDK contrast, all own-baseline observations and every per-role A/A interval.');add()
add('### Competitive P3 ratios');add()
table(['Payload / compiler','CPU ratio to Wasmtime [95% CI]; controls','Throughput ratio to Wasmtime [95% CI]; controls'],[[size+' B '+compiler,ratio(v['comparisons']['head-'+compiler+'/wasmtime']['cpuUs']),ratio(v['comparisons']['head-'+compiler+'/wasmtime']['throughput'],higher_is_better=True)]for size,v in p3.items()for compiler in ['go','llgo']])
add('## Core source baseline and SDK contrasts');add()
add('Head/base ratios below one improve. These marginal intervals describe this event; an apparent change in an unchanged mechanism requires diagnosis before being attributed to source changes. The machine-readable report includes every competitor ratio and A/A interval.');add()
for backend in roles:
 add('### '+backend);add()
 table(['Workload','Go source head/base','LLGo source head/base','LLGo SDK3c/SDK114 on fixed base'],[[key]+[ratio(v['comparisons'][pair])for pair in [f'head-go-{backend}/base-go-{backend}',f'head-llgo-{backend}/base-llgo-{backend}',f'base-llgo-{backend}/old-sdk-base-llgo-{backend}']]for key,v in core.items()])
add('## Preparation, first call and cleanup');add()
add('All entries below are **microseconds per process or invocation**, including unresolved observations. Phase intervals are not inferred from warm-call controls. Startup is independently observed process readiness. Native compile/validate boundaries differ by API; WasmEdge AOT includes validation and artifact I/O, plus separately recorded native-image loading. Every process creates a fresh native image. First-call and warm execution have their own boundaries; values are never subtracted to invent pure costs.');add()
for backend in roles:
 add('<details>');add('<summary>'+backend.title()+': all 33 workloads and phase observations</summary>');add()
 for phase in ['processStartup','load','engineSetup','compileValidate','instantiate','exportLookup','firstCall','cleanup']:
  add('### '+phase);add();table(headers,[[key]+[cell(key,r,phase)for r in roles[backend]]for key in core])
 add('</details>');add()
add('### WasmEdge AOT preparation detail');add()
table(['Workload','Compile + validation + artifact I/O, us','Native image load, us','Post-load validation, us'],[[key]+[cell(key,'wasmedge-compiler',phase)for phase in ['aotPreparationNs/compileValidateArtifactIO','aotPreparationNs/compiledArtifactLoad','preparationPartsNs/validate']]for key in core])
add('### P3 phase observations');add()
rows=[]
for size,v in p3.items():
 for phase in sorted({k for role in ['head-go','head-llgo','wasmtime']for k in v['phasesMedianNs'][role]}):
  cells=[]
  for role in ['head-go','head-llgo',None,'wasmtime',None,None]:
   value=None if role is None else v['phasesMedianNs'][role].get(phase);cells.append('NM'if role is None else'N/A'if value is None else num(value/1000))
  rows.append([size+' B / '+phase]+cells)
table(headers,rows)
add('## Native controls (different contracts)');add()
add('Unchecked C kernels omit runtime safety/lifetime contracts; native Go implements HTTP replies without Component/WASI. These are overhead oracles, not equivalent competitors, and are never subtracted from runtime timings.');add()
table(['Workload','Unchecked native C, ns/iteration'],[[key,num(v['mediansNsPerIteration']['native-c'])]for key,v in core.items()if'native-c'in v['mediansNsPerIteration']])
table(['Payload','Native Go CPU, us/request','Native Go requests/s'],[[size+' B',num(v['medians']['native-go']['cpuUs']),num(v['medians']['native-go']['throughput'])]for size,v in p3.items()])
add('## WasmEdge sustained AOT failures');add()
add('Full-size WasmEdge0.17.1 O3 AOT preflight freshly reproduces SIGSEGV in sustained struct access, allocation and indirect access. Small original cases pass. Only those exact three cells remain failures in the timing matrix. The original investigation and the observed cumulative stack growth are retained in the [PR #200 report](performance-pr200-complete-comparison-2026-11-17.md). No incomplete or historical timing rows are pooled into this fresh event.');add()
add('## Generated-code mechanism');add()
add('An untimed codegen audit of the actual general-call Wasm confirms one expanded call. Affine composition produces `x * 389569705 + 1196435762` modulo 2^32. Before the cache fix, four MOV/MOVK instructions rematerialize the two literals every iteration. The final loop uses entry-prepared registers with `madd w20,w20,w1,w2`; call and backedge polling remain. Full cold entries and ordinary/metered tiers are retained, so this is not unchecked bare code. The audit entry is 1,232 bytes including cold/control code; this is not total module code size. Assembly and original schema are in the protocol archive.');add()
add('## Regression investigation');add()
add('The fixed primary event finds source changes of Go sustained indirect GC interpreter **+0.99% time [0.46%,1.53%]** and LLGo general-call interpreter **+0.53% [0.14%,1.12%]**, with resolving controls. A separate predeclared four-block, seven-case, 120-process diagnostic checks CPU, instructions, cycles and CPI with same-binary A/A. It uses the same binaries and production GC; it is not a statistical extension or acceptance rerun.');add()
add('Those two small source regressions do not reproduce in the independent diagnostic medians: Go indirect GC CPU 74.003→72.811 ns; LLGo general-call interpreter 96.699→96.158 ns. Their instruction counts are essentially unchanged. LLGo base/head runSlotsLoop both have 2,053 static instructions; the retained diff shows jump-table/data relocation offsets rather than added interpreter operations. This supports a layout/CPI sensitivity investigation, not a claim that the primary regression is fixed.');add()
add('Fixed-base SDK114→SDK3c regressions with resolving primary controls include normal interpreter calls **+3.80%**, SIMD widening **+1.68%**, SIMD lanes **+15.72%**, sustained GC field access **+3.31%**, generic interpreter calls **+3.79%**, and native Rust SHA **+0.72%**. New-SDK source+SDK combined ratios are separately retained; they are not attributed entirely to source changes.');add()
add('Independent diagnostic observations (CPU ns/iteration, dynamic instructions and CPI) follow. They describe mechanism, without replacing the primary block intervals:');add()
rows=[]
for key,values in data['diagnostics'].items():
 for role,metrics in values.items():rows.append([key,role,num(metrics['cpuNs']),num(metrics['instructions']),f"{metrics['cyclesPerInstruction']:.6f}"])
table(['Case','Role','CPU ns','Instructions/iteration','CPI'],rows)
add('Normal interpreter calls show about **+6.7% dynamic instructions** at the new SDK. SIMD lanes show about **+0.6% instructions**, but CPI rises **0.16094→0.18533 (+15.2%)**, consistent with their reproduced CPU increase. The full SIMD runner assembly changes its private-memory call from `Memory.load` (wrapper branches inlined into runSIMD) to an out-of-line `Memory.Load`. New nil guards, spills, register allocation and layout also change. These are concrete codegen differences, not proof that one accounts for the entire loss. Required nil checks must remain; upstream optimization should preserve semantics.');add()
add('Native Rust SHA’s small SDK timing regression does not reproduce in the diagnostic CPU medians (237.552→236.948 ns); dynamic guest instructions remain about 4,945/iteration. Its primary adverse interval remains recorded. P3 source CPU intervals span one; SDK instruction counts increase about 0.94–1.17% with resolving controls, without a confirmed SDK CPU regression.');add()
add('## Next implementation work');add()
add('1. Investigate native calls whose control flow is dynamic and cannot use bounded expansion; add a separately named workload that survives each competitor’s optimizers before attributing ratios to call ABI overhead.')
add('2. Improve SHA range/region coverage and invariant-reference field access while preserving traps, GC roots and cold resumes.')
add('3. Improve shared-memory loop efficiency; prior poll grouping did not prove a gain and remains rejected.')
add('4. Continue complete P3 canonical/host-transition optimization and the upstream LLGo interpreter regression investigation. Performance acceptance remains open.')
add()
add('## Reproducible evidence');add()
add(f'- [Machine-readable results, all controls and source/SDK contrasts](data/{stem}.json).')
add(f'- [All 6,324 primary and 120 independent diagnostic process records](data/{stem}-raw.jsonl.gz), SHA-256 `{data["raw"]["sha256"]}`.')
add(f'- [Frozen plans, commands, hashes, analysis/export scripts, semantic checks and failure evidence](data/{stem}-protocol.tar.gz), SHA-256 `{data["protocol"]["sha256"]}`.')

add('- Per-request vectors unused by these metrics are projected to count/extrema/hash; no latency-tail claim. Public load records omit unrelated desktop command arguments. The separate diagnostic contains 120 process records and is never pooled into the 6,324 primary records.')
(w/'docs/research'/f'performance-{stem}.md').write_text('\n'.join(out)+'\n')
print('Rendered',len(out),'lines')
