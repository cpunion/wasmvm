from pathlib import Path
import json,gzip,hashlib,tarfile,io,statistics,math,collections
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');dest=w/'docs/research/data';stem='bounded-pure-call-2026-11-20'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
core=json.loads((p/'core-analysis.json').read_text());p3=json.loads((p/'p3-analysis.json').read_text());plan=json.loads((p/'core-plan.json').read_text());cases={(c['fixture']['cohort'],c['fixture']['id']):c for c in plan['cases']};counts={};sources={};core_rows=[]
raw=dest/(stem+'-raw.jsonl.gz')
with raw.open('wb')as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as stream:
 for cohort in ['core','p3-16','p3-65536','diagnostics']:
  f=p/cohort/'rows.jsonl.gz';sources[cohort]=sha(f);count=0
  for line in gzip.open(f,'rt'):
   r=json.loads(line);count+=1
   if cohort=='core':
    c=cases[(r['cohort'],r['case'])];fxt=c['fixture'];record=r['observation']['record'];assert record.get('result',record.get('checksum'))==fxt['expectedChecksum'];warm=record['warmCallNs'];assert len(warm)==7
    if 'warmResults'in record:assert record['warmResults']==[fxt['expectedChecksum']]*7
    reduce=statistics.mean if c['statistic']=='mean-including-pauses'else statistics.median;assert math.isclose(r['nsPerIteration'],reduce(warm)/fxt['iterations'],rel_tol=1e-12)
    core_rows.append(r)
   elif cohort.startswith('p3-'):
    record=r['record'];size=16 if cohort=='p3-16'else 65536;expected=1757737011 if size==16 else 2629362236;assert record['warmResults']==[expected]*21
    total={k:sum(x['after'][k]-x['before'][k]for x in r['rounds'])for k in r['totals']};assert total==r['totals'];clock=json.loads((p/cohort/'plan.json').read_text())['machTimebase'];tick=clock['numer']/clock['denom']
    assert math.isclose(r['cpuUs'],(total['ri_user_time']+total['ri_system_time'])*tick/r['windowRequests']/1000,rel_tol=1e-12)
    assert math.isclose(r['instructions'],total['ri_instructions']/r['windowRequests'],rel_tol=1e-12)
    assert math.isclose(r['throughput'],512e9/statistics.median(record['warmCallNs'][:20]),rel_tol=1e-12)
    for batch in record['service']['Batches']:
     for key in ['RequestNs','PublicAPINs']:
      if key in batch:
       values=batch.pop(key);batch[key+'Projection']=dict(count=len(values),minimum=min(values)if values else None,maximum=max(values)if values else None,sha256=hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest())
   else:
    record=r['record'];case=next(c for c in json.loads((p/'diagnostics/frozen-plan.json').read_text())['cases']if c['fixture']['id']==r['case']);assert record['warmResults']==[case['fixture']['expectedChecksum']]*6
    total={key:sum(delta[key]for delta in r['deltas'])for key in r['deltas'][0]};n=case['fixture']['iterations']*5
    assert math.isclose(r['instructions'],total['ri_instructions']/n,rel_tol=1e-12)
    assert math.isclose(r['cycles'],total['ri_cycles']/n,rel_tol=1e-12)
    assert math.isclose(r['cyclesPerInstruction'],total['ri_cycles']/total['ri_instructions'],rel_tol=1e-12)
   stream.write((json.dumps(dict(cohort=cohort,row=r),separators=(',',':'))+'\n').encode())
  counts[cohort]=count
assert counts=={'core':6156,'p3-16':84,'p3-65536':84,'diagnostics':120}
# Recompute every phase median from raw records, including independently observed startup.
for key,result in core['results'].items():
 selected=[r for r in core_rows if r['cohort']+'/'+r['case']==key]
 for role,phases in result['phasesMedianNs'].items():
  rr=[r for r in selected if r['id']in[role,role+'-aa']];phases['processStartup']=statistics.median(r['observation']['processReadyNs']for r in rr)
  for family in ['preparationPartsNs','aotPreparationNs']:
   for k in {k for r in rr for k in r['observation']['record'].get(family,{})}:
    phases[family+'/'+k]=statistics.median(r['observation']['record'][family][k]for r in rr)
files=['publish_evidence.py', 'render_report.py', 'build.py', 'build.json', 'build-complete.json', 'sdk-build.json', 'prepare_core.py', 'prepare_p3.py', 'measure_core.py', 'run_campaign.py', 'campaign.json', 'core-plan.json', 'qualification.json', 'machine.json', 'analyze_core.py', 'analyze_p3.py', 'capability_smoke.py', 'capability-smoke.json', 'smoke.py', 'smoke.json', 'p3-reference-smoke.json', 'reference-build.json', 'wasmedge-builds.json', 'wasmedge-full-size-smoke.json', 'runtime-failures.json', 'benchmark-tests.log', 'go-semantics.log', 'llgo-final-semantics.log', 'race-final.log', 'vet-final.log', 'nocgo-final.log', 'coverage-gates.json', 'kernel-audit.go', 'kernel-audit-overlay.json', 'final-generic-code.json', 'final-generic-0.asm', 'final-generic-1.asm', 'diagnostics/measure.py', 'diagnostics/frozen-plan.json', 'diagnostics/medians.json', 'diagnostics/simd.diff', 'diagnostics/base-llgo-phase-loop.asm', 'diagnostics/base-llgo-phase-loop-normalized.asm', 'diagnostics/old-sdk-base-llgo-phase-loop.asm', 'diagnostics/old-sdk-base-llgo-phase-loop-normalized.asm', 'diagnostics/head-llgo-phase-loop.asm', 'diagnostics/head-llgo-phase-loop-normalized.asm', 'diagnostics/base-llgo-phase-simd.asm', 'diagnostics/old-sdk-base-llgo-phase-simd.asm', 'p3-16/measure.py', 'p3-16/plan.json', 'p3-16/frozen-plan.json', 'p3-65536/measure.py', 'p3-65536/plan.json', 'p3-65536/frozen-plan.json', 'core/case-orders.json', 'core/unsupported.json', 'core/runtime-failures.json', 'core/complete.json']
extras={}
for cohort in ['core','p3-16','p3-65536']:
 for f in sorted((p/cohort).glob('*load*.json')):
  data=json.loads(f.read_text());original=sha(f)
  if isinstance(data,dict)and isinstance(data.get('processes'),str):
   rows=[]
   for line in data.pop('processes').splitlines()[1:]:
    fields=line.split(None,4)
    if len(fields)==5:rows.append(dict(pid=fields[0],ppid=fields[1],elapsed=fields[2],cpuPercent=fields[3],commandName=Path(fields[4].split()[0]).name))
   data['processes']=rows
  elif isinstance(data,list):
   for r in data:
    if 'command'in r:r['commandName']=Path(r.pop('command')).name
  extras[str(f.relative_to(p))]=json.dumps(dict(fullLocalSHA256=original,sanitizedLoad=data),separators=(',',':')).encode()
extras['REPRODUCE.md']=b'Rebase checkout/output paths. Source base18dbc5cb and measured head329d2c0f. Go1.27.3 and LLGo3c6b33ec O3/fullLTO/defaultGC on both sources. Fixed-base old SDK114c98b4 is separate. Build/hash/semantic-check all participants before running six fixed blocks on macOS ARM64 without concurrent owned work on the measured host. Remote PR CI is independent. Every reused binary retains its producer identity and verified source qualification. Known full-size WasmEdge O3 AOT failures were freshly reproduced before timing and are exact failure cells, never speed wins. Diagnostics use separate four fixed blocks and CPU/instruction/cycle counters for seven affected comparisons; never pool them into primary acceptance. Frozen scripts, fixture/library/binary hashes, source overlays, execution evidence and emitted assembly are included. Load arguments are sanitized, request-time vectors projected only where unused. Native C/Go remain different-contract oracles. Renderer percentage comparisons retain controls and CIs. No portfolio/milestone completion claim.\n'
protocol=dest/(stem+'-protocol.tar.gz')
with protocol.open('wb')as out,gzip.GzipFile(fileobj=out,mode='wb',mtime=0)as compressed,tarfile.open(fileobj=compressed,mode='w')as tar:
 for name in files:
  data=(p/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 for name,data in extras.items():
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
summary=dict(machine=json.loads((p/'machine.json').read_text()),qualification=json.loads((p/'qualification.json').read_text()),campaign=json.loads((p/'campaign.json').read_text()),builds=json.loads((p/'build.json').read_text()),core=core,p3=p3,failures=json.loads((p/'runtime-failures.json').read_text()),processCounts=counts,fullLocalRowsSHA256=sources,diagnostics=json.loads((p/'diagnostics/medians.json').read_text()),raw=dict(file=raw.name,sha256=sha(raw)),protocol=dict(file=protocol.name,sha256=sha(protocol)))
(dest/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
print('Verified and exported',counts,[(f.name,f.stat().st_size)for f in [raw,protocol,dest/(stem+'.json')]])
