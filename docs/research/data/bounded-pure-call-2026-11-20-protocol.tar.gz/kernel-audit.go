package main
import (
 "encoding/json"
 "fmt"
 "os"
 "github.com/cpunion/wasmvm/pkg/wasm"
 "github.com/cpunion/wasmvm/internal/core/decode"
 "github.com/cpunion/wasmvm/internal/core/validate"
 "github.com/cpunion/wasmvm/internal/compiler/lower"
 "github.com/cpunion/wasmvm/internal/compiler/slots"
 "github.com/cpunion/wasmvm/internal/compiler/codegen"
 "github.com/cpunion/wasmvm/internal/platform/native"
)
func check(err error){if err!=nil{panic(err)}}
func main(){
 b,err:=os.ReadFile(os.Args[1]);check(err);m,err:=decode.DecodeWithFeatures(b,decode.DefaultLimits(),wasm.SupportedFeatures);check(err);v,err:=validate.CheckWithFeatures(m,validate.DefaultLimits(),wasm.SupportedFeatures);check(err);i,err:=lower.Compile(v,lower.DefaultLimits());check(err);s,err:=slots.Compile(i,slots.DefaultLimits());check(err);d:=v.Definition()
 config:=codegen.Config{Unmetered:true,NativeAllocations:true,NativeThreads:true,NativeFrameRegisters:true,NativeCallLimits:true,SharedDispatch:true,HeapTypes:d.TypeDefs,TableCount:uint32(len(d.Tables)),MemoryCount:uint32(len(d.Memories)),ARM64Features:codegen.ARM64Features(native.ARM64CPUFeatures())}
 for _,im:=range d.Imports{if im.Kind==0{panic("audit requires no imported functions")}}
 for _,memory:=range d.Memories{config.SharedMemories=append(config.SharedMemories,memory.Shared);config.MemoryPageSizes=append(config.MemoryPageSizes,memory.PageBytes())};if len(d.Memories)!=0{config.MemoryMinimumPages=uint32(d.Memories[0].Min)}
 for _,global:=range d.Globals{config.Globals=append(config.Globals,global.Type)}
 callees:=map[uint32]*slots.Function{};for j,f:=range s.Functions{callees[uint32(j)]=f};usedGlobals:=map[uint32]bool{};linked:=false;for _,f:=range s.Functions{for _,in:=range f.Code{if in.Op==0x10 || in.Op==0x11 || in.Op==0x14{linked=true};if in.Op==0x23 || in.Op==0x24{usedGlobals[f.Sources[in.Source].Wasm.A]=true}}};config.DirectCallees=callees;if linked{config.LinkedCallees=callees};config.NativeFrameRegisters=linked;config.NativeCallLimits=linked;for j:=range config.Globals{if usedGlobals[uint32(j)]{config.LinkedGlobals=append(config.LinkedGlobals,uint32(j))}};config.FunctionCount=uint32(len(s.Functions));config.LinkedTypeLabels=v.TypeLabels();for _,f:=range d.Functions{config.LinkedSignatures=append(config.LinkedSignatures,config.LinkedTypeLabels[f.Type])}
 rows:=[]map[string]any{};for j,f:=range s.Functions{config.NativeFunction=0;if config.NativeFrameRegisters{config.NativeFunction=uint64(j)+1};c,err:=codegen.CompileFunctionWithConfig("arm64",f,codegen.DefaultLimits(),config);check(err);path:=fmt.Sprintf("%s-%d.bin",os.Args[2],j);check(os.WriteFile(path,c.Entry.Code,0644));rows=append(rows,map[string]any{"function":j,"code":f.Code,"sources":f.Sources,"codeBytes":len(c.Entry.Code),"binary":path,"inlinedCalls":c.InlinedCalls,"nativeLoops":c.NativeLoops,"registerRegions":c.RegisterRegions,"nativeHeap":c.NativeHeap,"forwardedHeap":c.ForwardedHeap,"heapCaches":c.HeapCaches,"fusedIntegers":c.FusedIntegers,"loopGuards":c.LoopGuards,"privatePollOffsets":c.PrivatePollOffsets})};check(json.NewEncoder(os.Stdout).Encode(rows))
}
