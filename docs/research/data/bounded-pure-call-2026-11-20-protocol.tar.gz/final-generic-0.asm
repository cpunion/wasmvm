	stp	x29, x30, [sp, #-16]!
	mov	x29, sp
	stp	x19, x20, [sp, #-16]!
	stp	x21, x22, [sp, #-16]!
	stp	x23, x24, [sp, #-16]!
	stp	x25, x26, [sp, #-16]!
	stp	x27, x28, [sp, #-16]!
	stp	q8, q9, [sp, #-32]!
	stp	q10, q11, [sp, #-32]!
	stp	q12, q13, [sp, #-32]!
	stp	q14, q15, [sp, #-32]!
	mov	x26, #-1                        // =0xffffffffffffffff
	ldr	x28, [x0, #32]
	ldr	x27, [x0, #40]
	ldr	x12, [x0, #8]
	ldr	x13, [x0, #32]
	ldr	x9, [x0, #16]
	sub	x9, x9, x13
	mov	w10, #80                        // =0x50
	cmp	x9, x10
	b.lo	#992
	and	x9, x13, #0xf
	cmp	x9, #0
	b.ne	#980
	add	x12, x12, x13
	mov	w9, #0                          // =0x0
	str	x9, [x0, #72]
	ldr	x9, [x0, #56]
	mov	w10, #18                        // =0x12
	cmp	x9, x10
	b.hs	#952
	ldr	x9, [x0, #128]
	cmp	x9, #0
	b.eq	#940
	ldr	x9, [x0, #56]
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#8
	ldr	x26, [x11]
	mov	w1, #26125                      // =0x660d
	movk	w1, #25, lsl #16
	mov	w2, #62303                      // =0xf35f
	movk	w2, #15470, lsl #16
	ldr	x19, [x12, #48]
	ldr	x20, [x12]
	ldr	x21, [x12, #16]
	ldr	x22, [x12, #64]
	ldr	x23, [x12, #32]
	ldr	x9, [x0, #136]
	cmp	x9, #0
	b.ne	#872
	ldr	x9, [x0, #56]
	adr	x13, #16
	ldrsw	x14, [x13, x9, lsl #2]
	add	x13, x13, x14
	br	x13
	udf	#72
	udf	#84
	udf	#328
	udf	#404
	udf	#412
	udf	#420
	udf	#428
	udf	#436
	udf	#444
	udf	#448
	udf	#456
	udf	#464
	udf	#472
	udf	#480
	udf	#492
	udf	#376
	udf	#376
	udf	#392
	ldr	x9, [x0, #144]
	cbnz	x9, #432
	b	#248
	ldr	x9, [x0, #144]
	cbnz	x9, #468
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#184
	cmp	x26, #0
	b.eq	#176
	mov	x16, x23
	ldr	x11, [x0, #120]
	mov	x9, x26
	sub	x9, x9, #1
	ldr	x10, [x11, #32]
	cmp	x9, x10
	b.hs	#8
	str	x9, [x11, #32]
	add	x9, x9, x9, lsl #1
	add	x14, x11, x9, lsl #3
	add	x14, x14, #40
	ldr	x15, [x14, #8]
	ldr	x9, [x0, #8]
	add	x15, x15, x9
	mov	x10, x16
	ldr	x11, [x12, #40]
	ldr	x13, [x14, #16]
	sub	x13, x13, #4
	ldr	w9, [x13]
	lsl	x9, x9, #4
	add	x9, x9, x15
	stp	x10, x11, [x9]
	ldr	x9, [x0, #144]
	cmp	x9, #0
	b.ne	#28
	ldr	x28, [x14, #8]
	sub	x27, x27, #1
	sub	x26, x26, #1
	ldr	x9, [x14, #16]
	br	x9
	udf	#2
	dmb	ishld
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #56]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #112]
	mov	x10, #1                         // =0x1
	b	#684
	mov	w9, #1                          // =0x1
	str	x9, [x0, #56]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #1                         // =0x1
	b	#640
	mov	x22, x2
	mov	x19, x1
	mul	w19, w20, w19
	add	w20, w19, w22
	add	w21, w21, #1
	ldr	x9, [x0, #144]
	cbnz	x9, #252
	cmp	w21, #2
	b.lo	#-28
	mov	w9, #0                          // =0x0
	mov	x19, x9
	b	#20
	ldr	x9, [x0, #144]
	cbnz	x9, #284
	mov	x23, x20
	b	#-304
	ldr	x9, [x0, #144]
	cbnz	x9, #316
	b	#-24
	mov	x19, x1
	b	#4
	mul	w19, w20, w19
	b	#4
	mov	x22, x2
	b	#4
	add	w19, w19, w22
	b	#4
	mov	x20, x19
	b	#4
	b	#4
	mov	w19, #1                         // =0x1
	b	#4
	add	w19, w21, w19
	b	#4
	mov	x21, x19
	b	#4
	mov	w19, #2                         // =0x2
	b	#4
	cmp	w21, w19
	cset	w19, lo
	b	#4
	ldr	x9, [x0, #144]
	cbnz	x9, #264
	cbnz	w19, #-172
	b	#-112
	dmb	ishld
	mov	w9, #0                          // =0x0
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #6                         // =0x6
	b	#412
	dmb	ishld
	mov	w9, #1                          // =0x1
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #6                         // =0x6
	b	#364
	dmb	ishld
	mov	w19, #2                         // =0x2
	cmp	w21, w19
	cset	w19, lo
	mov	w9, #14                         // =0xe
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #6                         // =0x6
	b	#304
	dmb	ishld
	mov	w9, #16                         // =0x10
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #6                         // =0x6
	b	#256
	dmb	ishld
	mov	w9, #17                         // =0x11
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #6                         // =0x6
	b	#208
	dmb	ishld
	mov	w9, #14                         // =0xe
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #6                         // =0x6
	b	#160
	mov	x20, x16
	mov	w1, #26125                      // =0x660d
	movk	w1, #25, lsl #16
	mov	w2, #62303                      // =0xf35f
	movk	w2, #15470, lsl #16
	ldr	x19, [x12, #48]
	ldr	x21, [x12, #16]
	ldr	x22, [x12, #64]
	ldr	x23, [x12, #32]
	b	#-772
	mov	x9, #-1                         // =0xffffffffffffffff
	cmp	x26, x9
	b.eq	#20
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#8
	str	x26, [x11]
	str	x28, [x0, #32]
	str	x27, [x0, #40]
	mov	w0, #11                         // =0xb
	b	#124
	mov	w9, #7                          // =0x7
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #2                         // =0x2
	b	#40
	mov	w9, #6                          // =0x6
	str	x9, [x0, #112]
	str	x19, [x12, #48]
	str	x20, [x12]
	str	x21, [x12, #16]
	str	x22, [x12, #64]
	str	x23, [x12, #32]
	mov	x10, #2                         // =0x2
	b	#4
	mov	x9, #-1                         // =0xffffffffffffffff
	cmp	x26, x9
	b.eq	#20
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#8
	str	x26, [x11]
	str	x28, [x0, #32]
	str	x27, [x0, #40]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #48]
	mov	w0, w10
	ldp	q14, q15, [sp], #32
	ldp	q12, q13, [sp], #32
	ldp	q10, q11, [sp], #32
	ldp	q8, q9, [sp], #32
	ldp	x27, x28, [sp], #16
	ldp	x25, x26, [sp], #16
	ldp	x23, x24, [sp], #16
	ldp	x21, x22, [sp], #16
	ldp	x19, x20, [sp], #16
	ldp	x29, x30, [sp], #16
	ret
