stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x1d0
ldr	x8, [x0, #0x48]
cmp	x8, #0x1
b.lt	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
ldrb	w26, [x0, #0x20]
mov	x21, x0
mov	x20, x1
str	w26, [sp, #0x14]
ldr	x9, [x21, #0x40]
add	x8, x9, x8, lsl #6
ldur	x10, [x8, #-0x40]
sturb	wzr, [x8, #-0x30]
str	x8, [sp, #0x18]
ldur	x8, [x8, #-0x28]
ldr	x2, [x21, #0x88]
ldr	x16, [x10, #0x48]
ldr	x19, [x16, #0x98]
add	x9, x19, x8
cmp	x9, x2
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f70>
cmp	x8, x9
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f80>
ldr	x9, [sp, #0x18]
ldr	x22, [x16, #0xb8]
ldur	w0, [x9, #-0x38]
sub	x9, x2, x8
lsl	x8, x8, #4
cmp	x9, #0x0
csel	x8, x8, xzr, gt
cmp	x22, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
ldr	x9, [x21, #0x78]
ldr	x28, [x16, #0xb0]
mov	w24, w0
str	x10, [sp, #0x8]
ldr	x10, [x10, #0x40]
add	x23, x9, x8
stp	x10, x16, [sp, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xcc>
add	w27, w24, #0x1
mov	w0, w27
mov	w24, w27
cmp	x22, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
add	x27, x28, x0, lsl #5
tbz	w26, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x110>
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
mov	w9, #0xe0               ; =224
ldr	x8, [x16, #0x78]
umaddl	x25, w0, w9, x8
ldr	w8, [x25]
cmp	w8, #0x5
ccmp	w8, #0xb, #0x4, ne
ldr	x8, [x21, #0x150]
cset	w9, ne
subs	x8, x8, x9
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dbc>
str	x8, [x21, #0x150]
add	x20, x20, #0x1
tst	x20, #0x3f
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
ldr	x8, [x21, #0x160]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x130>
cbz	x21, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
ldar	w8, [x8]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x18c>
ldr	x8, [x21, #0x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
ldr	x9, [x8, #0x8]
ldr	x0, [x21, #0x10]
ldrb	w9, [x9, #0x17]
and	w10, w9, #0x1f
and	w9, w9, #0x20
cmp	w10, #0x16
ccmp	w9, #0x0, #0x4, ne
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x160>
stur	x0, [x29, #-0x78]
sub	x0, x29, #0x78
ldr	x8, [x8, #0x28]
blr	x8
ldr	x16, [sp, #0x28]
mov	x2, x1
cbnz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
ldr	x16, [sp, #0x28]
cbnz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
mov	x0, xzr
mov	x2, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
ldr	x8, [x0, #0x8]
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
ldr	w8, [x27, #0x1c]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
tbz	w26, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
ldr	w9, [x27]
cmp	w9, #0x20
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
cmp	w9, #0x41
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
ldr	w9, [x27]
cmp	w9, #0x20
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8>
cmp	w9, #0x41
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
mvn	w8, w20
tst	x8, #0x3f
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
cmp	w9, #0x41
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x204>
ldr	w0, [x27, #0x8]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	w8, [x27, #0x18]
add	x9, x23, x0, lsl #4
stp	x8, xzr, [x9]
add	w24, w24, #0x1
cmp	x22, x24
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
add	x27, x28, x24, lsl #5
add	x20, x20, #0x1
ldr	w8, [x27, #0x1c]
cbnz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
ldr	w9, [x27]
mov	w10, #0xff20            ; =65312
sub	w8, w9, #0xe0
movk	w10, #0xff, lsl #16
cmp	w8, w10
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c4>
lsr	w8, w9, #16
cmp	w8, #0xfb
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x414>
cmp	w8, #0xfc
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x31c>
cmp	w8, #0xfd
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4bc>
ldr	w0, [x27, #0xc]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x67c>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
add	x8, x23, x0, lsl #4
ldp	x2, x8, [x8]
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x690>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x60]
ldp	x5, x6, [sp, #0x60]
ldr	w0, [x27, #0x14]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6a4>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x70]
ldp	x10, x11, [sp, #0x70]
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6bc>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
sub	w8, w9, #0x45
cmp	w8, #0x80
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
cmp	w8, #0x7f
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a44>
adrp	x12, ADDR <dyld_stub_binder+ADDR>
add	x12, x12, #0x3d0
adr	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
ldrh	w11, [x12, x8, lsl #1]
add	x10, x10, x11, lsl #2
br	x10
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa98>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	x2, [x23, x8]
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
mov	w8, #0xffed             ; =65517
movk	w8, #0xff03, lsl #16
add	w13, w9, w8
cmp	w13, #0x4
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
ldp	w8, w0, [x27, #0x18]
ldr	x2, [x16, #0xd8]
add	w10, w8, w0
add	w10, w10, #0x2
cmp	x2, x10
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fd4>
cmp	w8, w10
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fc0>
sub	x11, x2, x8
lsl	x12, x8, #2
cmp	x11, #0x0
csel	x11, x12, xzr, gt
cmp	w10, w8
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
ldr	x12, [x16, #0xc8]
add	x12, x12, x11
ldr	w11, [x12]
cmp	x19, x11
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f94>
sub	x1, x10, x8
cmp	x1, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fac>
ldr	w8, [x12, #0x4]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x10, x11, #4
lsl	x8, x8, #4
cmp	w13, #0x2
ldr	x15, [x23, x10]
ldr	x14, [x23, x8]
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7b4>
cmp	x1, #0x3
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2010>
ldr	w8, [x12, #0x8]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
cmp	x1, #0x3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2008>
ldr	w10, [x12, #0xc]
cmp	x19, x10
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
lsl	x8, x8, #4
lsl	x10, x10, #4
ldr	x11, [x23, x8]
ldr	x8, [x23, x10]
mov	w10, #0x13              ; =19
movk	w10, #0xfc, lsl #16
cmp	w9, w10
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x970>
add	x10, x11, x15
orr	x9, x11, x15
and	x11, x11, x15
bic	x9, x9, x10
add	x8, x8, x14
orr	x9, x9, x11
add	x11, x8, x9, lsr #63
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
sub	w8, w9, #0x2
and	w9, w8, #0xffff
cmp	w9, #0x21
mov	x9, #0x3e0f             ; =15887
movk	x9, #0x1c00, lsl #16
cset	w10, lo
movk	x9, #0x1, lsl #32
lsr	x9, x9, x8
and	w9, w10, w9
tbz	w9, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x65c>
ldr	w0, [x27, #0xc]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x860>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x30]
ldp	x3, x4, [sp, #0x30]
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x40]
ldp	x5, x6, [sp, #0x40]
and	w8, w8, #0xffff
cmp	w8, #0xc
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
ldr	w8, [x27, #0x18]
ldr	x1, [x16, #0xd0]
add	w0, w8, #0x2
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x16, #0xc8]
ldr	w0, [x8, x0, lsl #2]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x50]
ldp	x7, x9, [sp, #0x50]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x890>
cmp	w9, #0xe7
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
sub	w8, w9, #0x1
cmp	w8, #0xd3
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x584>
adrp	x12, ADDR <dyld_stub_binder+ADDR>
add	x12, x12, #0x4d0
mov	x0, xzr
adr	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f0>
ldrh	w11, [x12, x8, lsl #1]
add	x10, x10, x11, lsl #2
mov	x1, xzr
br	x10
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
mov	w10, #0xe0              ; =224
ldr	x8, [x16, #0x78]
umaddl	x10, w0, w10, x8
cbz	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [sp, #0x20]
ldr	w0, [x10, #0x18]
ldr	x1, [x8, #0x78]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x11, [x8]
cbz	x11, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	w8, [x27, #0xc]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
ldr	x0, [x11, #0x10]
lsl	x8, x8, #4
ldr	w11, [x10, #0x14]
ldr	w10, [x10, #0x1c]
ldr	x12, [x0, #0x40]
ldr	x2, [x23, x8]
orr	x3, x11, x10, lsl #32
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x56c>
ldr	x8, [x0, #0x60]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x90c>
sub	x8, x29, #0x78
mov	w1, w9
mov	w4, wzr
mov	x5, xzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x744>
sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
cmp	w8, #0x8
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x750>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	w0, w9
mov	x2, xzr
ldr	x1, [x23, x8]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
mov	x25, x1
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
mov	w10, #0xe0              ; =224
ldr	x8, [x16, #0x78]
umaddl	x11, w0, w10, x8
cbz	x11, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [sp, #0x20]
ldr	w0, [x11, #0x18]
ldr	x1, [x8, #0x78]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x12, [x8]
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	w8, [x27, #0xc]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
ldr	w10, [x27, #0x10]
cmp	x19, x10
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
ldr	x0, [x12, #0x10]
ldr	w12, [x11, #0x14]
lsl	x8, x8, #4
ldr	w11, [x11, #0x1c]
lsl	x10, x10, #4
ldr	x13, [x0, #0x40]
ldr	x2, [x23, x8]
orr	x3, x12, x11, lsl #32
ldr	x5, [x23, x10]
cbz	x13, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x64c>
ldr	x8, [x0, #0x60]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa3c>
mov	w1, w9
mov	w4, wzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x848>
ldr	x8, [sp, #0x18]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
ldr	x16, [sp, #0x28]
tst	w0, #0xff
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
mov	x8, xzr
mov	x2, xzr
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x27c>
mov	x5, xzr
mov	x6, xzr
ldr	w0, [x27, #0x14]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x29c>
mov	x10, xzr
mov	x11, xzr
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
mov	w13, #0xe0              ; =224
ldr	x12, [x16, #0x78]
umaddl	x0, w0, w13, x12
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
and	w12, w9, #0xfffc
and	w13, w9, #0xffff
cmp	w12, #0x54
ccmp	w13, #0xb, #0x0, ne
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6ec>
sub	w14, w13, #0x5c
cmp	w14, #0x2
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7e4>
ldr	x10, [sp, #0x20]
ldr	w8, [x0, #0x18]
ldr	x1, [x10, #0x78]
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
ldr	x10, [x10, #0x70]
adds	x8, x10, x8, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x10, [x8, #0x10]
ldr	w8, [x0, #0x14]
ldr	w11, [x0, #0x1c]
ldrb	w4, [x0, #0x40]
ldr	x12, [x10, #0x40]
orr	x3, x8, x11, lsl #32
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x738>
ldr	x8, [x10, #0x60]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x924>
sub	x8, x29, #0x78
mov	x0, x10
mov	w1, w9
sub	x26, x29, #0x78
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x938>
mov	w8, #-0x1000001         ; =-16777217
add	w8, w9, w8
cmp	w8, #0x8
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
mov	w10, #0x117             ; =279
lsr	w10, w10, w8
tbz	w10, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf04>
and	w9, w9, #0xff
mov	w8, wzr
cmp	w9, #0x4
b.gt	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
cmp	w9, #0x2
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xad0>
cmp	w9, #0x3
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	w9, [x27, #0x1c]
ldr	w8, [x23, x8]
sub	w9, w9, #0x1
cmp	w9, w8
csel	w8, w9, w8, lo
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
umulh	x11, x14, x15
mov	w8, #0x13               ; =19
movk	w8, #0xfc, lsl #16
mul	x10, x14, x15
add	w8, w8, #0x2
cmp	w9, w8
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
and	x8, x14, x15, asr #63
and	x9, x15, x14, asr #63
add	x8, x9, x8
sub	x11, x11, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
cmp	w13, #0xb
ldr	x13, [sp, #0x20]
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f8>
cmp	w12, #0x58
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb88>
ldr	x1, [x13, #0x78]
ldr	w8, [x0, #0x18]
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
ldr	x10, [x13, #0x70]
adds	x8, x10, x8, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [x8, #0x10]
ldr	w10, [x0, #0x14]
ldr	w11, [x0, #0x1c]
ldrb	w4, [x0, #0x40]
ldr	x12, [x8, #0x40]
orr	x3, x10, x11, lsl #32
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x840>
ldr	x10, [x8, #0x60]
cbz	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
mov	x0, x8
mov	w1, w9
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
mov	w8, w0
mov	x0, xzr
mov	x1, xzr
and	w25, w8, #0xff
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
mov	x3, xzr
mov	x4, xzr
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x468>
mov	x5, xzr
mov	x6, xzr
and	w8, w8, #0xffff
cmp	w8, #0xc
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x488>
mov	x7, xzr
mov	x9, xzr
cbz	x21, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
mov	w10, #0xe0              ; =224
ldr	x8, [x16, #0x78]
umaddl	x2, w0, w10, x8
cbz	x2, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x0, [x21]
ldr	x1, [sp, #0x20]
add	x8, sp, #0x80
str	x9, [sp]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
ldr	x25, [sp, #0x90]
ldr	q0, [sp, #0x80]
cbz	x25, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8dc>
ldr	x8, [x25, #0x8]
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
ldr	w0, [x27, #0x8]
ldr	x16, [sp, #0x28]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
str	q0, [x23, x0, lsl #4]
add	w27, w24, #0x1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9cc>
ldr	x0, [x27, #0x18]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
sub	x8, x29, #0x78
mov	w1, w9
mov	w4, wzr
mov	x5, xzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x930>
sub	x8, x29, #0x78
mov	x0, x10
mov	w1, w9
sub	x26, x29, #0x78
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
ldp	x0, x1, [x26]
ldrb	w25, [x26, #0x10]
ldr	w26, [sp, #0x14]
ldr	x16, [sp, #0x28]
tst	w25, #0xff
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
ldr	w8, [x27, #0x8]
cmn	w8, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
add	x8, x23, x8, lsl #4
stp	x0, x1, [x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
sub	x10, x15, x11
eon	x9, x15, x11
bic	x11, x11, x15
and	x9, x10, x9
orr	x9, x9, x11
add	x8, x8, x9, lsr #63
sub	x11, x14, x8
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
add	w8, w0, #0x1
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
ldr	w9, [x12, x0, lsl #2]
cmp	x19, x9
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
ldr	w0, [x12, x8, lsl #2]
add	x8, x23, x9, lsl #4
cmp	x19, x0
stp	x10, xzr, [x8]
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
add	x8, x23, x0, lsl #4
add	w27, w24, #0x1
stp	x11, xzr, [x8]
ldr	x8, [sp, #0x18]
stur	w27, [x8, #-0x38]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldr	w8, [x27, #0x18]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
add	x9, x23, x0, lsl #4
ldr	q0, [x9]
ldr	x1, [x9, #0x8]
str	q0, [x23, x8, lsl #4]
fmov	x0, d0
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0x14]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	w9, #0x10               ; =16
ldr	w8, [x23, x8]
cmp	w8, #0x0
mov	w8, #0xc                ; =12
csel	x8, x9, x8, eq
ldr	w0, [x27, x8]
cmp	x19, x0
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xddc>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
mov	w1, w9
mov	w4, wzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe48>
cmp	w9, #0x9
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	x8, [x23, x8]
cmp	x8, #0x0
cset	w8, ne
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldr	x8, [x23, x8]
cmp	x8, #0x0
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
mov	x2, xzr
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	w0, w9
ldr	x1, [x23, x8]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
mov	x25, x1
ldr	x16, [sp, #0x28]
tst	w25, #0xff
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	w8, [x23, x8]
cmp	w8, #0x0
cset	w8, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
cmp	w9, #0x69
mov	x1, xzr
ldr	x8, [x23, x8]
mov	w9, w8
csel	x8, x9, x8, eq
lsr	x9, x8, #1
and	x8, x8, #ADDR
and	x9, x9, #ADDR
add	x8, x9, x8
lsr	x9, x8, #2
and	x8, x8, #ADDR
and	x9, x9, #ADDR
add	x8, x9, x8
add	x8, x8, x8, lsr #4
and	x8, x8, #ADDR
add	x8, x8, x8, lsr #8
add	x8, x8, x8, lsr #16
add	x8, x8, x8, lsr #32
and	x0, x8, #0x7f
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldrsw	x0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldr	w0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
mov	x1, x2
mov	x2, x8
mov	x3, x5
mov	x4, x6
mov	x5, x10
mov	x6, x11
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
ldr	x16, [sp, #0x28]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x17fc>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
ldr	x8, [sp, #0x20]
ldr	w0, [x27, #0x18]
ldr	x1, [x8, #0x78]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
cbz	x21, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x25, [x8]
cbz	x25, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x9, [x25, #0x10]
ldr	w8, [x27, #0xc]
ldr	x0, [x21]
ldrb	w9, [x9, #0x31]
cmp	x19, x8
strb	w9, [sp, #0xae]
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x8, x8, #4
ldrb	w9, [sp, #0xae]
mov	x1, x25
ldr	x8, [x23, x8]
cmp	w9, #0x0
mov	w10, w8
csel	x2, x8, x10, ne
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
tbz	w1, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ba4>
ldr	x16, [sp, #0x28]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x20]
ldr	w0, [x27, #0x18]
ldr	x1, [x8, #0x60]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x58]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x9, x0, #4
ldrb	w10, [x8, #0x29]
ldr	x9, [x23, x9]
cmp	w10, #0x0
ldr	x10, [x8, #0x40]
mov	w11, w9
csel	x9, x9, x11, ne
cmp	x9, x10
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
ldr	x8, [x8, #0x38]
mov	x1, xzr
ldr	x0, [x8, x9, lsl #3]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x20]
ldr	w0, [x27, #0x18]
ldr	x1, [x8, #0x48]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x40]
mov	x1, xzr
ldr	x0, [x8, x0, lsl #3]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
add	x8, x23, x0, lsl #4
ldr	x0, [x8]
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e7c>
ldr	x1, [x8, #0x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x20]
ldr	x1, [x8, #0x90]
ldr	w8, [x27, #0x18]
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
ldr	w9, [x27, #0xc]
cmp	x19, x9
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x201c>
ldr	x10, [sp, #0x20]
ldr	q0, [x23, x9, lsl #4]
mov	x0, xzr
mov	x1, xzr
ldr	x10, [x10, #0x88]
ldr	x8, [x10, x8, lsl #3]
str	q0, [x8, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x20]
ldr	w0, [x27, #0x18]
ldr	x1, [x8, #0x90]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x88]
ldr	x8, [x8, x0, lsl #3]
ldp	x0, x1, [x8, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x20]
ldr	w0, [x27, #0x18]
ldr	x1, [x8, #0x60]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x58]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x9, [x8]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldrb	w10, [x9, #0x29]
ldr	x12, [x9, #0x40]
ldr	x8, [x23, x8]
cmp	w10, #0x0
mov	w11, w8
csel	x10, x8, x11, ne
cmp	x10, x12
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x8, x8, #4
ldr	x9, [x9, #0x38]
mov	x0, xzr
mov	x1, xzr
ldr	x8, [x23, x8]
str	x8, [x9, x10, lsl #3]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0x18]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
add	x8, x23, x0, lsl #4
ldp	x0, x1, [x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x20]
ldr	w0, [x27, #0x18]
ldr	x1, [x8, #0x78]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x0, [x8, #0x10]
ldr	x9, [x0, #0x40]
ldr	x8, [x0, #0x60]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bcc>
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).pagesLocked>
ldr	x16, [sp, #0x28]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0x18]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
mov	x0, x8
mov	w1, w9
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
mov	w25, w0
mov	x0, xzr
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
cmp	w9, #0x5
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e74>
ldr	w9, [x27, #0x18]
ldr	x1, [x16, #0xe8]
add	w0, w9, w8
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x16, #0xe0]
mov	w9, #0xc                ; =12
umaddl	x8, w0, w9, x8
ldp	w27, w25, [x8]
ldr	w26, [x8, #0x8]
cmp	w27, w24
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
ldr	x8, [x21, #0x160]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea8>
cbz	x21, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xef0>
ldar	w8, [x8]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bf0>
ldr	x8, [x21, #0x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
ldr	x9, [x8, #0x8]
ldr	x0, [x21, #0x10]
ldrb	w9, [x9, #0x17]
and	w10, w9, #0x1f
and	w9, w9, #0x20
cmp	w10, #0x16
ccmp	w9, #0x0, #0x4, ne
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xed8>
stur	x0, [x29, #-0x78]
sub	x0, x29, #0x78
ldr	x8, [x8, #0x28]
blr	x8
ldr	x16, [sp, #0x28]
mov	x2, x1
cbnz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
ldr	x16, [sp, #0x28]
cbnz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
cmp	w8, #0x3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8c>
cmp	w8, #0x6
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
sub	w8, w9, #0x12
cmp	w8, #0x4
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d64>
ldr	w0, [x27, #0xc]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a8c>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	x5, [x23, x8]
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a9c>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	x7, [x23, x8]
ldr	w0, [x27, #0x14]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aac>
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
lsl	x8, x0, #4
ldr	x10, [x23, x8]
and	w8, w9, #ADDR
cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1abc>
and	w4, w9, #0xffff
cmp	w4, #0x3
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c7c>
cbz	x21, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x8, [x21]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x0, [x8, #0x8]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
ldr	x16, [sp, #0x28]
mov	x0, xzr
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
eor	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
lsr	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
asr	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
orr	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
lsl	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
orr	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldr	x8, [x23, x8]
rbit	x8, x8
clz	x0, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, lo
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, ls
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, hi
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
sub	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	w11, #0x20              ; =32
mov	w12, #0x18              ; =24
mov	x1, xzr
ldr	w8, [x23, x8]
lsr	w9, w8, #16
cmp	w9, #0x0
csel	w8, w9, w8, ne
mov	x9, #-0x10              ; =-16
lsr	w10, w8, #8
csel	x9, x9, xzr, ne
cmp	w8, #0xff
csel	w8, w10, w8, hi
adrp	x10, ADDR <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x1088>
add	x10, x10, #0x70d
and	x8, x8, #0xff
ldrb	w8, [x10, x8]
csel	x10, x12, x11, hi
add	x9, x10, x9
sub	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
lsr	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, gt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, lt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, ne
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
ldr	w8, [x23, x8]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d0c>
rbit	w8, w8
mov	x1, xzr
clz	w0, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, ne
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, le
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x8, x8, #4
lsl	x9, x0, #4
mov	x1, xzr
ldr	w8, [x23, x8]
ldr	w9, [x23, x9]
neg	w8, w8
ror	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, ls
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, ge
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldr	w8, [x23, x8]
cmp	w8, #0x0
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, lo
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
add	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
eor	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
and	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
sub	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x8, x8, #4
lsl	x9, x0, #4
ldr	w8, [x23, x8]
ldr	x9, [x23, x9]
neg	w8, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1768>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, hs
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
mul	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, le
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, gt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
ror	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, lt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
ror	x0, x9, x8
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, hi
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldrsb	x0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldrsh	x0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, hs
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, ge
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
asr	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
and	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
add	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
mul	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldrsb	x8, [x23, x8]
mov	w0, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	w10, #0x20              ; =32
mov	x1, xzr
ldr	x8, [x23, x8]
lsr	x9, x8, #32
cmp	x9, #0x0
csel	x8, x9, x8, ne
csel	x10, x10, xzr, ne
lsr	x9, x8, #16
cmp	x9, #0x0
csel	x8, x9, x8, ne
orr	x9, x10, #0x10
lsr	x11, x8, #8
csel	x9, x9, x10, ne
cmp	x8, #0xff
orr	x10, x9, #0x8
csel	x8, x11, x8, hi
adrp	x11, ADDR <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x1088>
add	x11, x11, #0x70d
and	x8, x8, #0xff
csel	x9, x10, x9, hi
mov	w10, #0x40              ; =64
ldrb	w8, [x11, x8]
sub	x9, x10, x9
sub	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
ldr	w8, [x27, #0x10]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
lsl	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	w0, [x27, #0xc]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
lsl	x8, x0, #4
mov	x1, xzr
ldrsh	x8, [x23, x8]
mov	w0, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
sub	w8, w9, #0x8b
cmp	w8, #0x34
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a64>
mov	x10, #-ADDR       ; =-268435457
movk	x10, #0xfff9, lsl #32
movk	x10, #0x1f, lsl #48
lsr	x8, x10, x8
tbnz	w8, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
sub	w8, w9, #0x61
mov	x0, xzr
cmp	w8, #0x21
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d34>
mov	x10, #ADDR       ; =16106127360
mov	x1, x0
movk	x10, #0xf03f
lsr	x8, x10, x8
tbnz	w8, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
mov	x5, xzr
ldr	w0, [x27, #0x10]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf48>
mov	x7, xzr
ldr	w0, [x27, #0x14]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf64>
mov	x10, xzr
and	w8, w9, #ADDR
cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf80>
mov	w8, #0xffed             ; =65517
movk	w8, #0xff03, lsl #16
add	w8, w8, w9
add	w8, w8, #0xb
cmp	w8, #0xa
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2058>
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x16, #0x78]
mov	w9, #0xe0               ; =224
umaddl	x8, w0, w9, x8
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	w9, [x8]
ldr	x11, [x8, #0x8]
add	x12, sp, #0xd8
ldr	q0, [x8, #0x10]
ldur	q1, [x8, #0x48]
add	x2, sp, #0xd8
str	w9, [sp, #0xd8]
ldur	q2, [x8, #0x68]
mov	x0, x21
str	x11, [sp, #0xe0]
ldp	x9, x11, [x8, #0x20]
str	q0, [x12, #0x10]
mov	x3, x5
mov	x4, xzr
ldr	q0, [x8, #0x30]
stur	q1, [x12, #0x48]
mov	x5, x7
stp	x9, x11, [sp, #0xf8]
ldrb	w9, [x8, #0x40]
mov	x6, xzr
str	q0, [x12, #0x30]
ldur	q0, [x8, #0x58]
mov	x7, x10
strb	w9, [sp, #0x118]
ldur	q1, [x8, #0x78]
ldr	x1, [sp, #0x20]
stur	q0, [x12, #0x58]
ldur	q0, [x8, #0x88]
ldp	x9, x8, [x8, #0x98]
stur	q2, [x12, #0x68]
stur	q1, [x12, #0x78]
stur	q0, [x12, #0x88]
stp	x9, x8, [sp, #0x170]
add	x8, sp, #0xb0
str	xzr, [sp]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
ldp	x0, x1, [sp, #0xb0]
ldr	x8, [sp, #0xc8]
ldrb	w25, [sp, #0xc0]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
ldr	x9, [x8, #0x8]
ldr	x16, [sp, #0x28]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f10>
ldr	x8, [x25, #0x10]
ldr	x16, [sp, #0x28]
mov	x1, xzr
ldrb	w8, [x8, #0x31]
tst	w8, #0x1
strb	w8, [sp, #0xaf]
mov	w8, #-0x1               ; =-1
csinv	x0, x8, xzr, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d18>
ldar	x8, [x8]
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d20>
ldr	x9, [x0, #0x38]
mov	w10, #0x10000           ; =65536
mov	x1, xzr
cmp	x9, #0x0
csel	x9, x10, x9, eq
udiv	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
mov	x0, xzr
mov	x2, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
ldr	x8, [x0, #0x8]
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
ldr	x2, [x16, #0x108]
add	w8, w26, w25
cmp	x2, x8
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ff8>
cmp	w25, w8
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
sub	x9, x2, x25
lsl	x10, x25, #3
cmp	x9, #0x0
csel	x9, x10, xzr, gt
cbz	w26, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c74>
ldr	x10, [x16, #0xf8]
ldr	w26, [sp, #0x14]
add	x10, x10, x9
sub	x9, x8, x25
add	x10, x10, #0x4
ldr	w0, [x10]
cmp	x19, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
ldur	w8, [x10, #-0x4]
cmp	x19, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
ldr	q0, [x23, x0, lsl #4]
subs	x9, x9, #0x1
add	x10, x10, #0x8
str	q0, [x23, x8, lsl #4]
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c44>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
ldr	w26, [sp, #0x14]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
ldr	x1, [x16, #0x80]
ldr	w0, [x27, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x8, [x16, #0x78]
mov	w9, #0xe0               ; =224
umaddl	x8, w0, w9, x8
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x9, [sp, #0x20]
ldr	w0, [x8, #0x18]
ldr	x1, [x9, #0x78]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x9, [x9, #0x70]
adds	x9, x9, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldr	x9, [x9]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
ldp	x11, x1, [x21]
ldr	w12, [x8, #0x14]
ldr	w8, [x8, #0x1c]
ldr	x2, [x21, #0x10]
ldr	x0, [x9, #0x10]
ldr	x3, [x11, #0x8]
orr	x6, x12, x8, lsl #32
sub	x8, x29, #0xa0
str	x10, [sp]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
ldp	x0, x1, [x29, #-0xa0]
ldur	x8, [x29, #-0x88]
ldurb	w25, [x29, #-0x90]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
ldr	x9, [x8, #0x8]
ldr	x16, [sp, #0x28]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f18>
mov	x1, xzr
mov	w0, #0x20               ; =32
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [x0, #0x8]
cbnz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bd4>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
ldr	x16, [sp, #0x28]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
mov	x1, x0
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
ldr	x8, [sp, #0x18]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
tst	w0, #0xff
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
ldr	x8, [x21, #0x48]
cmp	x8, #0x0
b.gt	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x3c>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
ldr	x8, [sp, #0x18]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
ldr	x8, [sp, #0x18]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
ldr	x8, [sp, #0x18]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
and	w8, w0, #0xff
tbz	w8, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d54>
mov	w0, #0x1                ; =1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
mov	x0, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
mov	w0, #0x28               ; =40
bl	ADDR <dyld_stub_binder+ADDR>
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
mov	x19, x0
mov	w0, #0x28               ; =40
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
ldr	x8, [x25, #0x8]
adrp	x9, ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x3e3>
adrp	x10, ADDR <dyld_stub_binder+ADDR>
add	x10, x10, #0x81f
ldr	q0, [x9, #0xa20]
adrp	x1, ADDR <_[][]_llgo_github.com/cpunion/wasmvm/internal/compiler/ir.Catch+0x20>
add	x1, x1, #0x470
stp	x8, x10, [x19, #0x10]
mov	w8, #0xe                ; =14
str	q0, [x19]
str	x8, [x19, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1edc>
mov	x1, x0
mov	x0, x21
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
and	x0, x0, #0xff
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
ldr	x19, [sp, #0x98]
mov	w0, #0x8                ; =8
bl	ADDR <dyld_stub_binder+ADDR>
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
mov	x22, x0
mov	w0, #0x8                ; =8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
adrp	x2, ADDR <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
add	x2, x2, #0x468
mov	x0, x25
mov	x1, x19
mov	x3, x22
bl	ADDR <_errors.As>
ldr	x9, [sp, #0x8]
tbz	w0, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e60>
ldr	x8, [x22]
ldr	w9, [x9, #0x50]
str	w9, [x8, #0x4]
mov	x0, x21
mov	x1, x25
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
mov	w25, #0x3               ; =3
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
mov	w25, #0x1               ; =1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
mov	w25, #0x9               ; =9
mov	w0, #0x10               ; =16
bl	ADDR <dyld_stub_binder+ADDR>
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
mov	x19, x0
mov	w0, #0x10               ; =16
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
ldr	x9, [sp, #0x28]
stp	xzr, xzr, [x19]
ldr	w0, [x27, #0x4]
ldr	x1, [x9, #0x80]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
mov	w8, #0xe0               ; =224
ldr	x9, [x9, #0x78]
adrp	x1, ADDR <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
add	x1, x1, #0x7d0
umaddl	x8, w0, w8, x9
ldr	x9, [sp, #0x8]
ldr	w9, [x9, #0x50]
ldr	x8, [x8, #0x8]
strb	w25, [x19]
str	w9, [x19, #0x4]
str	x8, [x19, #0x8]
mov	x0, x21
mov	x2, x19
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
mov	w0, #0x3                ; =3
mov	x1, x20
add	sp, sp, #0x1d0
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret
ldr	x2, [sp, #0xd0]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f1c>
ldur	x2, [x29, #-0x80]
mov	x0, x21
mov	x1, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
mov	x0, x24
mov	x1, x22
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, x8
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x1, x22
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x8
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x10
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x9
mov	w1, #0x1                ; =1
mov	w3, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x8
mov	w1, #0x1                ; =1
mov	x2, x9
mov	w3, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x11
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x9
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, xzr
mov	x1, xzr
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, x8
mov	w1, wzr
mov	x2, x10
mov	w3, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x10
mov	w1, wzr
mov	w3, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x25
mov	w1, wzr
mov	x2, x8
mov	w3, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x8
mov	w1, wzr
mov	w3, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	w0, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	w0, #0x2                ; =2
mov	w1, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, x9
mov	x1, x19
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
adrp	x0, ADDR <__llgo_func$Oob_PMZ7jwg4Zq77Ey2ib6LC02NBqIRsIh_lNyFzLAc+0x60>
add	x0, x0, #0x9e8
adrp	x1, ADDR <__llgo_func$Oob_PMZ7jwg4Zq77Ey2ib6LC02NBqIRsIh_lNyFzLAc+0x60>
add	x1, x1, #0xc68
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
adrp	x0, ADDR <__llgo_complex64+0x40>
add	x0, x0, #0x320
adrp	x1, ADDR <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
add	x1, x1, #0x4b8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
adrp	x0, ADDR <__llgo_complex64+0x40>
add	x0, x0, #0x320
adrp	x1, ADDR <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
add	x1, x1, #0x4c8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
adrp	x0, ADDR <__llgo_complex64+0x40>
add	x0, x0, #0x320
adrp	x1, ADDR <__llgo_func$Oob_PMZ7jwg4Zq77Ey2ib6LC02NBqIRsIh_lNyFzLAc+0x60>
add	x1, x1, #0x9d8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
