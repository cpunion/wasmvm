
/Users/lijie/source/goplus/wasmvm/artifacts/bounded-pure-call-20261120/head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010002f764 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>:
10002f764:     	stp	x28, x27, [sp, #-0x60]!
10002f768:     	stp	x26, x25, [sp, #0x10]
10002f76c:     	stp	x24, x23, [sp, #0x20]
10002f770:     	stp	x22, x21, [sp, #0x30]
10002f774:     	stp	x20, x19, [sp, #0x40]
10002f778:     	stp	x29, x30, [sp, #0x50]
10002f77c:     	add	x29, sp, #0x50
10002f780:     	sub	sp, sp, #0x1d0
10002f784:     	cbz	x0, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f788:     	ldr	x8, [x0, #0x48]
10002f78c:     	mov	x21, x0
10002f790:     	cmp	x8, #0x1
10002f794:     	b.lt	0x100031730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
10002f798:     	ldrb	w27, [x21, #0x20]
10002f79c:     	mov	x19, x1
10002f7a0:     	str	w27, [sp, #0x24]
10002f7a4:     	ldr	x9, [x21, #0x40]
10002f7a8:     	add	x9, x9, x8, lsl #6
10002f7ac:     	mov	x8, x9
10002f7b0:     	str	x9, [sp, #0x30]
10002f7b4:     	ldr	x10, [x8, #-0x40]!
10002f7b8:     	sturb	wzr, [x9, #-0x30]
10002f7bc:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f7c0:     	cbz	x10, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f7c4:     	ldr	x15, [x10, #0x48]
10002f7c8:     	cbz	x15, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002f7cc:     	ldr	x8, [sp, #0x30]
10002f7d0:     	ldr	x20, [x15, #0x98]
10002f7d4:     	ldr	x2, [x21, #0x88]
10002f7d8:     	ldur	x8, [x8, #-0x28]
10002f7dc:     	add	x9, x20, x8
10002f7e0:     	cmp	x9, x2
10002f7e4:     	b.hi	0x10003168c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
10002f7e8:     	cmp	x8, x9
10002f7ec:     	b.hi	0x100031678 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f14>
10002f7f0:     	ldr	x9, [sp, #0x30]
10002f7f4:     	ldr	x22, [x15, #0xb8]
10002f7f8:     	ldur	w0, [x9, #-0x38]
10002f7fc:     	sub	x9, x2, x8
10002f800:     	lsl	x8, x8, #4
10002f804:     	cmp	x9, #0x0
10002f808:     	csel	x8, x8, xzr, gt
10002f80c:     	cmp	x22, x0
10002f810:     	b.ls	0x100031650 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002f814:     	ldr	x9, [x21, #0x78]
10002f818:     	ldr	x26, [x15, #0xb0]
10002f81c:     	mov	w24, w0
10002f820:     	str	x10, [sp, #0x18]
10002f824:     	ldr	x10, [x10, #0x40]
10002f828:     	add	x23, x9, x8
10002f82c:     	str	x15, [sp, #0x38]
10002f830:     	str	x10, [sp, #0x28]
10002f834:     	b	0x10002f84c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe8>
10002f838:     	add	w28, w24, #0x1
10002f83c:     	mov	w0, w28
10002f840:     	mov	w24, w28
10002f844:     	cmp	x22, x0
10002f848:     	b.ls	0x100031650 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002f84c:     	add	x28, x26, x0, lsl #5
10002f850:     	tbz	w27, #0x0, 0x10002f890 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x12c>
10002f854:     	ldr	x1, [x15, #0x80]
10002f858:     	ldr	w0, [x28, #0x4]
10002f85c:     	cmp	x1, x0
10002f860:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002f864:     	mov	w9, #0xe0               ; =224
10002f868:     	ldr	x8, [x15, #0x78]
10002f86c:     	umaddl	x25, w0, w9, x8
10002f870:     	ldr	w8, [x25]
10002f874:     	cmp	w8, #0x5
10002f878:     	ccmp	w8, #0xb, #0x4, ne
10002f87c:     	ldr	x8, [x21, #0x150]
10002f880:     	cset	w9, ne
10002f884:     	subs	x8, x8, x9
10002f888:     	b.lo	0x1000314cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d68>
10002f88c:     	str	x8, [x21, #0x150]
10002f890:     	add	x19, x19, #0x1
10002f894:     	tst	x19, #0x3f
10002f898:     	b.ne	0x10002f908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
10002f89c:     	ldr	x8, [x21, #0x160]
10002f8a0:     	cbz	x8, 0x10002f8ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x148>
10002f8a4:     	ldar	w8, [x8]
10002f8a8:     	cbz	w8, 0x10002f8f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x190>
10002f8ac:     	ldr	x8, [x21, #0x8]
10002f8b0:     	cbz	x8, 0x100031718 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
10002f8b4:     	ldr	x9, [x8, #0x8]
10002f8b8:     	ldr	x0, [x21, #0x10]
10002f8bc:     	ldrb	w9, [x9, #0x17]
10002f8c0:     	and	w10, w9, #0x1f
10002f8c4:     	and	w9, w9, #0x20
10002f8c8:     	cmp	w10, #0x16
10002f8cc:     	ccmp	w9, #0x0, #0x4, ne
10002f8d0:     	b.eq	0x10002f8dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
10002f8d4:     	stur	x0, [x29, #-0x78]
10002f8d8:     	sub	x0, x29, #0x78
10002f8dc:     	ldr	x8, [x8, #0x28]
10002f8e0:     	blr	x8
10002f8e4:     	ldr	x15, [sp, #0x38]
10002f8e8:     	mov	x2, x1
10002f8ec:     	cbnz	x0, 0x10002f900 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x19c>
10002f8f0:     	b	0x10002f908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
10002f8f4:     	mov	x0, xzr
10002f8f8:     	mov	x2, xzr
10002f8fc:     	b	0x10002f908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
10002f900:     	ldr	x8, [x0, #0x8]
10002f904:     	cbnz	x8, 0x100031570 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e0c>
10002f908:     	ldr	w8, [x28, #0x1c]
10002f90c:     	cbz	w8, 0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f910:     	tbz	w27, #0x0, 0x10002f92c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
10002f914:     	ldr	w9, [x28]
10002f918:     	cmp	w9, #0x20
10002f91c:     	b.eq	0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f920:     	cmp	w9, #0x41
10002f924:     	b.eq	0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f928:     	b	0x10002f98c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
10002f92c:     	ldr	w9, [x28]
10002f930:     	cmp	w9, #0x20
10002f934:     	b.eq	0x10002f940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dc>
10002f938:     	cmp	w9, #0x41
10002f93c:     	b.ne	0x10002f98c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
10002f940:     	mvn	w8, w19
10002f944:     	tst	x8, #0x3f
10002f948:     	b.eq	0x10002f988 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002f94c:     	cmp	w9, #0x41
10002f950:     	b.ne	0x10002f96c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x208>
10002f954:     	ldr	w0, [x28, #0x8]
10002f958:     	cmp	x20, x0
10002f95c:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002f960:     	ldr	w8, [x28, #0x18]
10002f964:     	add	x9, x23, x0, lsl #4
10002f968:     	stp	x8, xzr, [x9]
10002f96c:     	add	w24, w24, #0x1
10002f970:     	cmp	x22, x24
10002f974:     	b.ls	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ecc>
10002f978:     	add	x28, x26, x24, lsl #5
10002f97c:     	add	x19, x19, #0x1
10002f980:     	ldr	w8, [x28, #0x1c]
10002f984:     	cbnz	w8, 0x10002f92c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
10002f988:     	ldr	w9, [x28]
10002f98c:     	mov	w10, #0xff20            ; =65312
10002f990:     	sub	w8, w9, #0xe0
10002f994:     	movk	w10, #0xff, lsl #16
10002f998:     	cmp	w8, w10
10002f99c:     	b.hs	0x10002fa2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c8>
10002f9a0:     	lsr	w8, w9, #16
10002f9a4:     	cmp	w8, #0xfb
10002f9a8:     	b.eq	0x10002fb7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x418>
10002f9ac:     	cmp	w8, #0xfc
10002f9b0:     	b.eq	0x10002fa84 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x320>
10002f9b4:     	cmp	w8, #0xfd
10002f9b8:     	b.ne	0x10002fc24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c0>
10002f9bc:     	ldr	w0, [x28, #0xc]
10002f9c0:     	cmn	w0, #0x1
10002f9c4:     	b.eq	0x10002fdec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x688>
10002f9c8:     	cmp	x20, x0
10002f9cc:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002f9d0:     	add	x8, x23, x0, lsl #4
10002f9d4:     	ldp	x2, x8, [x8]
10002f9d8:     	ldr	w0, [x28, #0x10]
10002f9dc:     	cmn	w0, #0x1
10002f9e0:     	b.eq	0x10002fe00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x69c>
10002f9e4:     	cmp	x20, x0
10002f9e8:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002f9ec:     	ldr	q0, [x23, x0, lsl #4]
10002f9f0:     	str	q0, [sp, #0x70]
10002f9f4:     	ldp	x5, x6, [sp, #0x70]
10002f9f8:     	ldr	w0, [x28, #0x14]
10002f9fc:     	cmn	w0, #0x1
10002fa00:     	b.eq	0x10002fe14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6b0>
10002fa04:     	cmp	x20, x0
10002fa08:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fa0c:     	ldr	q0, [x23, x0, lsl #4]
10002fa10:     	str	q0, [sp, #0x80]
10002fa14:     	ldp	x10, x11, [sp, #0x80]
10002fa18:     	ldr	x1, [x15, #0x80]
10002fa1c:     	ldr	w0, [x28, #0x4]
10002fa20:     	cmp	x1, x0
10002fa24:     	b.hi	0x10002fe2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6c8>
10002fa28:     	b	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fa2c:     	sub	w8, w9, #0x45
10002fa30:     	cmp	w8, #0x80
10002fa34:     	b.hs	0x10002fc2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
10002fa38:     	cmp	w8, #0x7f
10002fa3c:     	b.hi	0x1000311bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a58>
10002fa40:     	adrp	x12, 0x100221000 <dyld_stub_binder+0x100221000>
10002fa44:     	add	x12, x12, #0x140
10002fa48:     	adr	x10, 0x10002fa58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
10002fa4c:     	ldrh	w11, [x12, x8, lsl #1]
10002fa50:     	add	x10, x10, x11, lsl #2
10002fa54:     	br	x10
10002fa58:     	ldr	w0, [x28, #0x10]
10002fa5c:     	cmn	w0, #0x1
10002fa60:     	b.eq	0x10003020c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
10002fa64:     	cmp	x20, x0
10002fa68:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002fa6c:     	lsl	x8, x0, #4
10002fa70:     	ldr	x2, [x23, x8]
10002fa74:     	ldr	w0, [x28, #0xc]
10002fa78:     	cmp	x20, x0
10002fa7c:     	b.hi	0x10003021c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xab8>
10002fa80:     	b	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002fa84:     	mov	w8, #0xffed             ; =65517
10002fa88:     	movk	w8, #0xff03, lsl #16
10002fa8c:     	add	w12, w9, w8
10002fa90:     	cmp	w12, #0x4
10002fa94:     	b.hs	0x10002fc2c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
10002fa98:     	ldp	w8, w0, [x28, #0x18]
10002fa9c:     	ldr	x10, [x15, #0xd8]
10002faa0:     	add	w11, w8, w0
10002faa4:     	add	w2, w11, #0x2
10002faa8:     	cmp	x10, x2
10002faac:     	b.lo	0x1000316cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f68>
10002fab0:     	cmp	w8, w2
10002fab4:     	b.hi	0x1000316bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f58>
10002fab8:     	sub	x10, x10, x8
10002fabc:     	lsl	x11, x8, #2
10002fac0:     	cmp	x10, #0x0
10002fac4:     	csel	x10, x11, xzr, gt
10002fac8:     	cmp	w2, w8
10002facc:     	b.eq	0x1000316b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fad0:     	ldr	x11, [x15, #0xc8]
10002fad4:     	add	x11, x11, x10
10002fad8:     	ldr	w10, [x11]
10002fadc:     	cmp	x20, x10
10002fae0:     	b.ls	0x10003166c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
10002fae4:     	sub	x1, x2, x8
10002fae8:     	cmp	x1, #0x1
10002faec:     	b.eq	0x1000316a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f44>
10002faf0:     	ldr	w8, [x11, #0x4]
10002faf4:     	cmp	x20, x8
10002faf8:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fafc:     	lsl	x10, x10, #4
10002fb00:     	lsl	x8, x8, #4
10002fb04:     	cmp	w12, #0x2
10002fb08:     	ldr	x14, [x23, x10]
10002fb0c:     	ldr	x13, [x23, x8]
10002fb10:     	b.hs	0x10002ff28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7c4>
10002fb14:     	cmp	x1, #0x3
10002fb18:     	b.lo	0x10003170c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa8>
10002fb1c:     	ldr	w8, [x11, #0x8]
10002fb20:     	cmp	x20, x8
10002fb24:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fb28:     	cmp	x1, #0x3
10002fb2c:     	b.eq	0x100031704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
10002fb30:     	ldr	w10, [x11, #0xc]
10002fb34:     	cmp	x20, x10
10002fb38:     	b.ls	0x10003166c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
10002fb3c:     	lsl	x8, x8, #4
10002fb40:     	lsl	x10, x10, #4
10002fb44:     	ldr	x12, [x23, x8]
10002fb48:     	ldr	x8, [x23, x10]
10002fb4c:     	mov	w10, #0x13              ; =19
10002fb50:     	movk	w10, #0xfc, lsl #16
10002fb54:     	cmp	w9, w10
10002fb58:     	b.ne	0x1000300e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x980>
10002fb5c:     	add	x10, x12, x14
10002fb60:     	orr	x9, x12, x14
10002fb64:     	and	x12, x12, x14
10002fb68:     	bic	x9, x9, x10
10002fb6c:     	add	x8, x8, x13
10002fb70:     	orr	x9, x9, x12
10002fb74:     	add	x12, x8, x9, lsr #63
10002fb78:     	b	0x100030100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
10002fb7c:     	sub	w8, w9, #0x2
10002fb80:     	and	w9, w8, #0xffff
10002fb84:     	cmp	w9, #0x21
10002fb88:     	mov	x9, #0x3e0f             ; =15887
10002fb8c:     	movk	x9, #0x1c00, lsl #16
10002fb90:     	cset	w10, lo
10002fb94:     	movk	x9, #0x1, lsl #32
10002fb98:     	lsr	x9, x9, x8
10002fb9c:     	and	w9, w10, w9
10002fba0:     	tbz	w9, #0x0, 0x10002fdcc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x668>
10002fba4:     	ldr	w0, [x28, #0xc]
10002fba8:     	cmn	w0, #0x1
10002fbac:     	b.eq	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
10002fbb0:     	cmp	x20, x0
10002fbb4:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fbb8:     	ldr	q0, [x23, x0, lsl #4]
10002fbbc:     	str	q0, [sp, #0x40]
10002fbc0:     	ldp	x3, x4, [sp, #0x40]
10002fbc4:     	ldr	w0, [x28, #0x10]
10002fbc8:     	cmn	w0, #0x1
10002fbcc:     	b.eq	0x10002ffec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
10002fbd0:     	cmp	x20, x0
10002fbd4:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fbd8:     	ldr	q0, [x23, x0, lsl #4]
10002fbdc:     	str	q0, [sp, #0x50]
10002fbe0:     	ldp	x5, x6, [sp, #0x50]
10002fbe4:     	and	w8, w8, #0xffff
10002fbe8:     	cmp	w8, #0xc
10002fbec:     	b.ne	0x100030000 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x89c>
10002fbf0:     	ldr	w8, [x28, #0x18]
10002fbf4:     	ldr	x1, [x15, #0xd0]
10002fbf8:     	add	w0, w8, #0x2
10002fbfc:     	cmp	x1, x0
10002fc00:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fc04:     	ldr	x8, [x15, #0xc8]
10002fc08:     	ldr	w0, [x8, x0, lsl #2]
10002fc0c:     	cmp	x20, x0
10002fc10:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
10002fc14:     	ldr	q0, [x23, x0, lsl #4]
10002fc18:     	str	q0, [sp, #0x60]
10002fc1c:     	ldp	x7, x9, [sp, #0x60]
10002fc20:     	b	0x100030008 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8a4>
10002fc24:     	cmp	w9, #0xe7
10002fc28:     	b.lo	0x10003144c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
10002fc2c:     	sub	w8, w9, #0x1
10002fc30:     	cmp	w8, #0xd3
10002fc34:     	b.hi	0x10002fcf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x58c>
10002fc38:     	adrp	x12, 0x100221000 <dyld_stub_binder+0x100221000>
10002fc3c:     	add	x12, x12, #0x240
10002fc40:     	mov	x0, xzr
10002fc44:     	adr	x10, 0x10002fc58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f4>
10002fc48:     	ldrh	w11, [x12, x8, lsl #1]
10002fc4c:     	add	x10, x10, x11, lsl #2
10002fc50:     	mov	x1, xzr
10002fc54:     	br	x10
10002fc58:     	ldr	x1, [x15, #0x80]
10002fc5c:     	ldr	w0, [x28, #0x4]
10002fc60:     	cmp	x1, x0
10002fc64:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fc68:     	mov	w10, #0xe0              ; =224
10002fc6c:     	ldr	x8, [x15, #0x78]
10002fc70:     	umaddl	x10, w0, w10, x8
10002fc74:     	cbz	x10, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fc78:     	ldr	x8, [sp, #0x28]
10002fc7c:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fc80:     	ldr	x1, [x8, #0x78]
10002fc84:     	ldr	w0, [x10, #0x18]
10002fc88:     	cmp	x1, x0
10002fc8c:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fc90:     	ldr	x8, [x8, #0x70]
10002fc94:     	adds	x8, x8, x0, lsl #3
10002fc98:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fc9c:     	ldr	x11, [x8]
10002fca0:     	cbz	x11, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fca4:     	ldr	w8, [x28, #0xc]
10002fca8:     	cmp	x20, x8
10002fcac:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fcb0:     	ldr	x0, [x11, #0x10]
10002fcb4:     	lsl	x8, x8, #4
10002fcb8:     	ldr	w11, [x10, #0x14]
10002fcbc:     	ldr	w10, [x10, #0x1c]
10002fcc0:     	ldr	x12, [x0, #0x40]
10002fcc4:     	ldr	x2, [x23, x8]
10002fcc8:     	orr	x3, x11, x10, lsl #32
10002fccc:     	cbz	x12, 0x10002fcd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x574>
10002fcd0:     	ldr	x8, [x0, #0x60]
10002fcd4:     	cbz	x8, 0x100030080 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x91c>
10002fcd8:     	sub	x8, x29, #0x78
10002fcdc:     	mov	w1, w9
10002fce0:     	mov	w4, wzr
10002fce4:     	mov	x5, xzr
10002fce8:     	mov	x6, xzr
10002fcec:     	b	0x10002feb8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x754>
10002fcf0:     	sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
10002fcf4:     	cmp	w8, #0x8
10002fcf8:     	b.hs	0x10002fec4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x760>
10002fcfc:     	ldr	w0, [x28, #0xc]
10002fd00:     	cmp	x20, x0
10002fd04:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002fd08:     	lsl	x8, x0, #4
10002fd0c:     	mov	w0, w9
10002fd10:     	mov	x2, xzr
10002fd14:     	ldr	x1, [x23, x8]
10002fd18:     	bl	0x100056a74 <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10002fd1c:     	mov	x25, x1
10002fd20:     	mov	x1, xzr
10002fd24:     	b	0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10002fd28:     	ldr	x1, [x15, #0x80]
10002fd2c:     	ldr	w0, [x28, #0x4]
10002fd30:     	cmp	x1, x0
10002fd34:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fd38:     	mov	w10, #0xe0              ; =224
10002fd3c:     	ldr	x8, [x15, #0x78]
10002fd40:     	umaddl	x11, w0, w10, x8
10002fd44:     	cbz	x11, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd48:     	ldr	x8, [sp, #0x28]
10002fd4c:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd50:     	ldr	x1, [x8, #0x78]
10002fd54:     	ldr	w0, [x11, #0x18]
10002fd58:     	cmp	x1, x0
10002fd5c:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fd60:     	ldr	x8, [x8, #0x70]
10002fd64:     	adds	x8, x8, x0, lsl #3
10002fd68:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd6c:     	ldr	x12, [x8]
10002fd70:     	cbz	x12, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fd74:     	ldr	w8, [x28, #0xc]
10002fd78:     	cmp	x20, x8
10002fd7c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10002fd80:     	ldr	w10, [x28, #0x10]
10002fd84:     	cmp	x20, x10
10002fd88:     	b.ls	0x10003166c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
10002fd8c:     	ldr	x0, [x12, #0x10]
10002fd90:     	ldr	w12, [x11, #0x14]
10002fd94:     	lsl	x8, x8, #4
10002fd98:     	ldr	w11, [x11, #0x1c]
10002fd9c:     	lsl	x10, x10, #4
10002fda0:     	ldr	x13, [x0, #0x40]
10002fda4:     	ldr	x2, [x23, x8]
10002fda8:     	orr	x3, x12, x11, lsl #32
10002fdac:     	ldr	x5, [x23, x10]
10002fdb0:     	cbz	x13, 0x10002fdbc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x658>
10002fdb4:     	ldr	x8, [x0, #0x60]
10002fdb8:     	cbz	x8, 0x1000301b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
10002fdbc:     	mov	w1, w9
10002fdc0:     	mov	w4, wzr
10002fdc4:     	mov	x6, xzr
10002fdc8:     	b	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x85c>
10002fdcc:     	ldr	x8, [sp, #0x30]
10002fdd0:     	mov	x0, x21
10002fdd4:     	stur	w24, [x8, #-0x38]
10002fdd8:     	bl	0x10003195c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
10002fddc:     	ldr	x15, [sp, #0x38]
10002fde0:     	tst	w0, #0xff
10002fde4:     	b.eq	0x10003006c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
10002fde8:     	b	0x100031514 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
10002fdec:     	mov	x8, xzr
10002fdf0:     	mov	x2, xzr
10002fdf4:     	ldr	w0, [x28, #0x10]
10002fdf8:     	cmn	w0, #0x1
10002fdfc:     	b.ne	0x10002f9e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x280>
10002fe00:     	mov	x5, xzr
10002fe04:     	mov	x6, xzr
10002fe08:     	ldr	w0, [x28, #0x14]
10002fe0c:     	cmn	w0, #0x1
10002fe10:     	b.ne	0x10002fa04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2a0>
10002fe14:     	mov	x10, xzr
10002fe18:     	mov	x11, xzr
10002fe1c:     	ldr	x1, [x15, #0x80]
10002fe20:     	ldr	w0, [x28, #0x4]
10002fe24:     	cmp	x1, x0
10002fe28:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10002fe2c:     	mov	w13, #0xe0              ; =224
10002fe30:     	ldr	x12, [x15, #0x78]
10002fe34:     	umaddl	x0, w0, w13, x12
10002fe38:     	cbz	x0, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe3c:     	and	w12, w9, #0xfffc
10002fe40:     	and	w13, w9, #0xffff
10002fe44:     	cmp	w12, #0x54
10002fe48:     	ccmp	w13, #0xb, #0x0, ne
10002fe4c:     	b.lo	0x10002fe5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6f8>
10002fe50:     	sub	w14, w13, #0x5c
10002fe54:     	cmp	w14, #0x2
10002fe58:     	b.hs	0x10002ff58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f4>
10002fe5c:     	ldr	x10, [sp, #0x28]
10002fe60:     	cbz	x10, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe64:     	ldr	x1, [x10, #0x78]
10002fe68:     	ldr	w8, [x0, #0x18]
10002fe6c:     	cmp	x1, x8
10002fe70:     	b.ls	0x100031664 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
10002fe74:     	ldr	x10, [x10, #0x70]
10002fe78:     	adds	x8, x10, x8, lsl #3
10002fe7c:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe80:     	ldr	x8, [x8]
10002fe84:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002fe88:     	ldr	x10, [x8, #0x10]
10002fe8c:     	ldr	w8, [x0, #0x14]
10002fe90:     	ldr	w11, [x0, #0x1c]
10002fe94:     	ldrb	w4, [x0, #0x40]
10002fe98:     	ldr	x12, [x10, #0x40]
10002fe9c:     	orr	x3, x8, x11, lsl #32
10002fea0:     	cbz	x12, 0x10002feac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x748>
10002fea4:     	ldr	x8, [x10, #0x60]
10002fea8:     	cbz	x8, 0x100030098 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x934>
10002feac:     	sub	x8, x29, #0x78
10002feb0:     	mov	x0, x10
10002feb4:     	mov	w1, w9
10002feb8:     	sub	x27, x29, #0x78
10002febc:     	bl	0x10004ea1c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
10002fec0:     	b	0x1000300ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
10002fec4:     	mov	w8, #-0x1000001         ; =-16777217
10002fec8:     	add	w8, w9, w8
10002fecc:     	cmp	w8, #0x8
10002fed0:     	b.hi	0x100030690 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf2c>
10002fed4:     	mov	w10, #0x117             ; =279
10002fed8:     	lsr	w10, w10, w8
10002fedc:     	tbz	w10, #0x0, 0x100030680 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf1c>
10002fee0:     	and	w9, w9, #0xff
10002fee4:     	mov	w8, wzr
10002fee8:     	cmp	w9, #0x4
10002feec:     	b.gt	0x1000301c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa5c>
10002fef0:     	cmp	w9, #0x2
10002fef4:     	b.eq	0x100030244 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xae0>
10002fef8:     	cmp	w9, #0x3
10002fefc:     	b.ne	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
10002ff00:     	ldr	w0, [x28, #0xc]
10002ff04:     	cmp	x20, x0
10002ff08:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10002ff0c:     	lsl	x8, x0, #4
10002ff10:     	ldr	w9, [x28, #0x1c]
10002ff14:     	ldr	w8, [x23, x8]
10002ff18:     	sub	w9, w9, #0x1
10002ff1c:     	cmp	w9, w8
10002ff20:     	csel	w8, w9, w8, lo
10002ff24:     	b	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
10002ff28:     	umulh	x12, x13, x14
10002ff2c:     	mov	w8, #0x13               ; =19
10002ff30:     	movk	w8, #0xfc, lsl #16
10002ff34:     	mul	x10, x13, x14
10002ff38:     	add	w8, w8, #0x2
10002ff3c:     	cmp	w9, w8
10002ff40:     	b.ne	0x100030100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
10002ff44:     	and	x8, x13, x14, asr #63
10002ff48:     	and	x9, x14, x13, asr #63
10002ff4c:     	add	x8, x9, x8
10002ff50:     	sub	x12, x12, x8
10002ff54:     	b	0x100030100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
10002ff58:     	cmp	w13, #0xb
10002ff5c:     	ldr	x13, [sp, #0x28]
10002ff60:     	b.eq	0x10002ff6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x808>
10002ff64:     	cmp	w12, #0x58
10002ff68:     	b.ne	0x1000302fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb98>
10002ff6c:     	cbz	x13, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002ff70:     	ldr	x1, [x13, #0x78]
10002ff74:     	ldr	w8, [x0, #0x18]
10002ff78:     	cmp	x1, x8
10002ff7c:     	b.ls	0x100031664 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
10002ff80:     	ldr	x10, [x13, #0x70]
10002ff84:     	adds	x8, x10, x8, lsl #3
10002ff88:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002ff8c:     	ldr	x8, [x8]
10002ff90:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10002ff94:     	ldr	x8, [x8, #0x10]
10002ff98:     	ldr	w10, [x0, #0x14]
10002ff9c:     	ldr	w11, [x0, #0x1c]
10002ffa0:     	ldrb	w4, [x0, #0x40]
10002ffa4:     	ldr	x12, [x8, #0x40]
10002ffa8:     	orr	x3, x10, x11, lsl #32
10002ffac:     	cbz	x12, 0x10002ffb8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x854>
10002ffb0:     	ldr	x10, [x8, #0x60]
10002ffb4:     	cbz	x10, 0x10003059c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe38>
10002ffb8:     	mov	x0, x8
10002ffbc:     	mov	w1, w9
10002ffc0:     	bl	0x10004c250 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
10002ffc4:     	mov	w8, w0
10002ffc8:     	mov	x0, xzr
10002ffcc:     	mov	x1, xzr
10002ffd0:     	and	w25, w8, #0xff
10002ffd4:     	b	0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10002ffd8:     	mov	x3, xzr
10002ffdc:     	mov	x4, xzr
10002ffe0:     	ldr	w0, [x28, #0x10]
10002ffe4:     	cmn	w0, #0x1
10002ffe8:     	b.ne	0x10002fbd0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x46c>
10002ffec:     	mov	x5, xzr
10002fff0:     	mov	x6, xzr
10002fff4:     	and	w8, w8, #0xffff
10002fff8:     	cmp	w8, #0xc
10002fffc:     	b.eq	0x10002fbf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x48c>
100030000:     	mov	x7, xzr
100030004:     	mov	x9, xzr
100030008:     	ldr	x1, [x15, #0x80]
10003000c:     	ldr	w0, [x28, #0x4]
100030010:     	cmp	x1, x0
100030014:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030018:     	mov	w10, #0xe0              ; =224
10003001c:     	ldr	x8, [x15, #0x78]
100030020:     	umaddl	x2, w0, w10, x8
100030024:     	cbz	x2, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030028:     	ldr	x0, [x21]
10003002c:     	ldr	x1, [sp, #0x28]
100030030:     	add	x8, sp, #0x90
100030034:     	str	x9, [sp]
100030038:     	bl	0x10003bd4c <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
10003003c:     	ldr	x25, [sp, #0xa0]
100030040:     	ldr	q0, [sp, #0x90]
100030044:     	cbz	x25, 0x100030050 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8ec>
100030048:     	ldr	x8, [x25, #0x8]
10003004c:     	cbnz	x8, 0x10003151c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db8>
100030050:     	ldr	w0, [x28, #0x8]
100030054:     	ldr	x15, [sp, #0x38]
100030058:     	cmn	w0, #0x1
10003005c:     	b.eq	0x10003006c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
100030060:     	cmp	x20, x0
100030064:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030068:     	str	q0, [x23, x0, lsl #4]
10003006c:     	add	w28, w24, #0x1
100030070:     	b	0x100030140 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9dc>
100030074:     	ldr	x0, [x28, #0x18]
100030078:     	mov	x1, xzr
10003007c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030080:     	sub	x8, x29, #0x78
100030084:     	mov	w1, w9
100030088:     	mov	w4, wzr
10003008c:     	mov	x5, xzr
100030090:     	mov	x6, xzr
100030094:     	b	0x1000300a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x940>
100030098:     	sub	x8, x29, #0x78
10003009c:     	mov	x0, x10
1000300a0:     	mov	w1, w9
1000300a4:     	sub	x27, x29, #0x78
1000300a8:     	bl	0x10004eb44 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
1000300ac:     	ldp	x0, x1, [x27]
1000300b0:     	ldrb	w25, [x27, #0x10]
1000300b4:     	ldr	w27, [sp, #0x24]
1000300b8:     	ldr	x15, [sp, #0x38]
1000300bc:     	tst	w25, #0xff
1000300c0:     	b.ne	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
1000300c4:     	ldr	w8, [x28, #0x8]
1000300c8:     	cmn	w8, #0x1
1000300cc:     	b.eq	0x10002f838 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
1000300d0:     	cmp	x20, x8
1000300d4:     	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
1000300d8:     	add	x8, x23, x8, lsl #4
1000300dc:     	stp	x0, x1, [x8]
1000300e0:     	b	0x10002f838 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
1000300e4:     	sub	x10, x14, x12
1000300e8:     	eon	x9, x14, x12
1000300ec:     	bic	x12, x12, x14
1000300f0:     	and	x9, x10, x9
1000300f4:     	orr	x9, x9, x12
1000300f8:     	add	x8, x8, x9, lsr #63
1000300fc:     	sub	x12, x13, x8
100030100:     	cmp	x1, x0
100030104:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030108:     	add	w8, w0, #0x1
10003010c:     	cmp	x1, x8
100030110:     	b.ls	0x100031664 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
100030114:     	ldr	w9, [x11, x0, lsl #2]
100030118:     	cmp	x20, x9
10003011c:     	b.ls	0x10003169c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f38>
100030120:     	ldr	w0, [x11, x8, lsl #2]
100030124:     	add	x8, x23, x9, lsl #4
100030128:     	cmp	x20, x0
10003012c:     	stp	x10, xzr, [x8]
100030130:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030134:     	add	x8, x23, x0, lsl #4
100030138:     	add	w28, w24, #0x1
10003013c:     	stp	x12, xzr, [x8]
100030140:     	ldr	x8, [sp, #0x30]
100030144:     	stur	w28, [x8, #-0x38]
100030148:     	b	0x10002f83c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
10003014c:     	ldr	w0, [x28, #0xc]
100030150:     	cmp	x20, x0
100030154:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030158:     	ldr	w8, [x28, #0x18]
10003015c:     	cmp	x20, x8
100030160:     	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030164:     	add	x9, x23, x0, lsl #4
100030168:     	ldr	q0, [x9]
10003016c:     	ldr	x1, [x9, #0x8]
100030170:     	str	q0, [x23, x8, lsl #4]
100030174:     	fmov	x0, d0
100030178:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003017c:     	ldr	w0, [x28, #0x14]
100030180:     	cmp	x20, x0
100030184:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030188:     	lsl	x8, x0, #4
10003018c:     	mov	w9, #0x10               ; =16
100030190:     	ldr	w8, [x23, x8]
100030194:     	cmp	w8, #0x0
100030198:     	mov	w8, #0xc                ; =12
10003019c:     	csel	x8, x9, x8, eq
1000301a0:     	ldr	w0, [x28, x8]
1000301a4:     	cmp	x20, x0
1000301a8:     	b.hi	0x100030544 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xde0>
1000301ac:     	b	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000301b0:     	mov	w1, w9
1000301b4:     	mov	w4, wzr
1000301b8:     	mov	x6, xzr
1000301bc:     	b	0x1000305a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
1000301c0:     	cmp	w9, #0x9
1000301c4:     	b.ne	0x1000305b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe54>
1000301c8:     	ldr	w0, [x28, #0xc]
1000301cc:     	cmp	x20, x0
1000301d0:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000301d4:     	lsl	x8, x0, #4
1000301d8:     	ldr	x8, [x23, x8]
1000301dc:     	cmp	x8, #0x0
1000301e0:     	cset	w8, ne
1000301e4:     	b	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
1000301e8:     	ldr	w0, [x28, #0xc]
1000301ec:     	cmp	x20, x0
1000301f0:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000301f4:     	lsl	x8, x0, #4
1000301f8:     	mov	x1, xzr
1000301fc:     	ldr	x8, [x23, x8]
100030200:     	cmp	x8, #0x0
100030204:     	cset	w0, eq
100030208:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003020c:     	mov	x2, xzr
100030210:     	ldr	w0, [x28, #0xc]
100030214:     	cmp	x20, x0
100030218:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003021c:     	lsl	x8, x0, #4
100030220:     	mov	w0, w9
100030224:     	ldr	x1, [x23, x8]
100030228:     	bl	0x100056a74 <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10003022c:     	mov	x25, x1
100030230:     	ldr	x15, [sp, #0x38]
100030234:     	tst	w25, #0xff
100030238:     	b.ne	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
10003023c:     	mov	x1, xzr
100030240:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030244:     	ldr	w0, [x28, #0xc]
100030248:     	cmp	x20, x0
10003024c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030250:     	lsl	x8, x0, #4
100030254:     	ldr	w8, [x23, x8]
100030258:     	cmp	w8, #0x0
10003025c:     	cset	w8, eq
100030260:     	b	0x1000305c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
100030264:     	ldr	w0, [x28, #0xc]
100030268:     	cmp	x20, x0
10003026c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030270:     	lsl	x8, x0, #4
100030274:     	cmp	w9, #0x69
100030278:     	mov	x1, xzr
10003027c:     	ldr	x8, [x23, x8]
100030280:     	mov	w9, w8
100030284:     	csel	x8, x9, x8, eq
100030288:     	lsr	x9, x8, #1
10003028c:     	and	x8, x8, #0x5555555555555555
100030290:     	and	x9, x9, #0x5555555555555555
100030294:     	add	x8, x9, x8
100030298:     	lsr	x9, x8, #2
10003029c:     	and	x8, x8, #0x3333333333333333
1000302a0:     	and	x9, x9, #0x3333333333333333
1000302a4:     	add	x8, x9, x8
1000302a8:     	add	x8, x8, x8, lsr #4
1000302ac:     	and	x8, x8, #0xf0f0f0f0f0f0f0f
1000302b0:     	add	x8, x8, x8, lsr #8
1000302b4:     	add	x8, x8, x8, lsr #16
1000302b8:     	add	x8, x8, x8, lsr #32
1000302bc:     	and	x0, x8, #0x7f
1000302c0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000302c4:     	ldr	w0, [x28, #0xc]
1000302c8:     	cmp	x20, x0
1000302cc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000302d0:     	lsl	x8, x0, #4
1000302d4:     	mov	x1, xzr
1000302d8:     	ldrsw	x0, [x23, x8]
1000302dc:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000302e0:     	ldr	w0, [x28, #0xc]
1000302e4:     	cmp	x20, x0
1000302e8:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000302ec:     	lsl	x8, x0, #4
1000302f0:     	mov	x1, xzr
1000302f4:     	ldr	w0, [x23, x8]
1000302f8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000302fc:     	mov	x1, x2
100030300:     	mov	x2, x8
100030304:     	mov	x3, x5
100030308:     	mov	x4, x6
10003030c:     	mov	x5, x10
100030310:     	mov	x6, x11
100030314:     	bl	0x100054f3c <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100030318:     	ldr	x15, [sp, #0x38]
10003031c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030320:     	ldr	w0, [x28, #0xc]
100030324:     	cmp	x20, x0
100030328:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003032c:     	ldr	w8, [x28, #0x10]
100030330:     	cmp	x20, x8
100030334:     	b.hi	0x100030f74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1810>
100030338:     	b	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003033c:     	ldr	x8, [sp, #0x28]
100030340:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030344:     	ldr	x1, [x8, #0x78]
100030348:     	ldr	w0, [x28, #0x18]
10003034c:     	cmp	x1, x0
100030350:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030354:     	ldr	x8, [x8, #0x70]
100030358:     	adds	x8, x8, x0, lsl #3
10003035c:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030360:     	ldr	x25, [x8]
100030364:     	cbz	x25, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030368:     	ldr	x8, [x25, #0x10]
10003036c:     	ldr	x11, [x21]
100030370:     	cbz	x8, 0x10003131c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bb8>
100030374:     	ldrb	w8, [x8, #0x31]
100030378:     	b	0x10003132c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
10003037c:     	ldr	x8, [sp, #0x28]
100030380:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030384:     	ldr	x1, [x8, #0x60]
100030388:     	ldr	w0, [x28, #0x18]
10003038c:     	cmp	x1, x0
100030390:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030394:     	ldr	x8, [x8, #0x58]
100030398:     	adds	x8, x8, x0, lsl #3
10003039c:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000303a0:     	ldr	x8, [x8]
1000303a4:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000303a8:     	ldr	w0, [x28, #0xc]
1000303ac:     	cmp	x20, x0
1000303b0:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000303b4:     	lsl	x9, x0, #4
1000303b8:     	ldrb	w10, [x8, #0x29]
1000303bc:     	ldr	x9, [x23, x9]
1000303c0:     	cmp	w10, #0x0
1000303c4:     	ldr	x10, [x8, #0x40]
1000303c8:     	mov	w11, w9
1000303cc:     	csel	x9, x9, x11, ne
1000303d0:     	cmp	x9, x10
1000303d4:     	b.hs	0x100031564 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
1000303d8:     	ldr	x8, [x8, #0x38]
1000303dc:     	mov	x1, xzr
1000303e0:     	ldr	x0, [x8, x9, lsl #3]
1000303e4:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000303e8:     	ldr	x8, [sp, #0x28]
1000303ec:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000303f0:     	ldr	x1, [x8, #0x48]
1000303f4:     	ldr	w0, [x28, #0x18]
1000303f8:     	cmp	x1, x0
1000303fc:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030400:     	ldr	x8, [x8, #0x40]
100030404:     	mov	x1, xzr
100030408:     	ldr	x0, [x8, x0, lsl #3]
10003040c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030410:     	ldr	w0, [x28, #0xc]
100030414:     	cmp	x20, x0
100030418:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003041c:     	add	x8, x23, x0, lsl #4
100030420:     	ldr	x0, [x8]
100030424:     	cbz	x0, 0x100031584 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e20>
100030428:     	ldr	x1, [x8, #0x8]
10003042c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030430:     	ldr	x8, [sp, #0x28]
100030434:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030438:     	ldr	x1, [x8, #0x90]
10003043c:     	ldr	w0, [x28, #0x18]
100030440:     	cmp	x1, x0
100030444:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030448:     	ldr	w8, [x28, #0xc]
10003044c:     	cmp	x20, x8
100030450:     	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030454:     	ldr	x9, [sp, #0x28]
100030458:     	ldr	x9, [x9, #0x88]
10003045c:     	add	x9, x9, x0, lsl #3
100030460:     	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030464:     	ldr	x9, [x9]
100030468:     	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003046c:     	ldr	q0, [x23, x8, lsl #4]
100030470:     	mov	x0, xzr
100030474:     	mov	x1, xzr
100030478:     	str	q0, [x9, #0x20]
10003047c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030480:     	ldr	x8, [sp, #0x28]
100030484:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030488:     	ldr	x1, [x8, #0x90]
10003048c:     	ldr	w0, [x28, #0x18]
100030490:     	cmp	x1, x0
100030494:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030498:     	ldr	x8, [x8, #0x88]
10003049c:     	adds	x8, x8, x0, lsl #3
1000304a0:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304a4:     	ldr	x8, [x8]
1000304a8:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304ac:     	ldp	x0, x1, [x8, #0x20]
1000304b0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000304b4:     	ldr	x8, [sp, #0x28]
1000304b8:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304bc:     	ldr	x1, [x8, #0x60]
1000304c0:     	ldr	w0, [x28, #0x18]
1000304c4:     	cmp	x1, x0
1000304c8:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000304cc:     	ldr	x8, [x8, #0x58]
1000304d0:     	adds	x8, x8, x0, lsl #3
1000304d4:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304d8:     	ldr	x9, [x8]
1000304dc:     	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000304e0:     	ldr	w0, [x28, #0xc]
1000304e4:     	cmp	x20, x0
1000304e8:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000304ec:     	lsl	x8, x0, #4
1000304f0:     	ldrb	w10, [x9, #0x29]
1000304f4:     	ldr	x12, [x9, #0x40]
1000304f8:     	ldr	x8, [x23, x8]
1000304fc:     	cmp	w10, #0x0
100030500:     	mov	w11, w8
100030504:     	csel	x10, x8, x11, ne
100030508:     	cmp	x10, x12
10003050c:     	b.hs	0x100031564 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
100030510:     	ldr	w8, [x28, #0x10]
100030514:     	cmp	x20, x8
100030518:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003051c:     	lsl	x8, x8, #4
100030520:     	ldr	x9, [x9, #0x38]
100030524:     	mov	x0, xzr
100030528:     	mov	x1, xzr
10003052c:     	ldr	x8, [x23, x8]
100030530:     	str	x8, [x9, x10, lsl #3]
100030534:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030538:     	ldr	w0, [x28, #0x18]
10003053c:     	cmp	x20, x0
100030540:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030544:     	add	x8, x23, x0, lsl #4
100030548:     	ldp	x0, x1, [x8]
10003054c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030550:     	ldr	x8, [sp, #0x28]
100030554:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030558:     	ldr	x1, [x8, #0x78]
10003055c:     	ldr	w0, [x28, #0x18]
100030560:     	cmp	x1, x0
100030564:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
100030568:     	ldr	x8, [x8, #0x70]
10003056c:     	adds	x8, x8, x0, lsl #3
100030570:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030574:     	ldr	x8, [x8]
100030578:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003057c:     	ldr	x0, [x8, #0x10]
100030580:     	bl	0x10004ba44 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages>
100030584:     	ldr	x15, [sp, #0x38]
100030588:     	mov	x1, xzr
10003058c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030590:     	ldr	w0, [x28, #0x18]
100030594:     	mov	x1, xzr
100030598:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003059c:     	mov	x0, x8
1000305a0:     	mov	w1, w9
1000305a4:     	bl	0x10004c498 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
1000305a8:     	mov	w25, w0
1000305ac:     	mov	x0, xzr
1000305b0:     	mov	x1, xzr
1000305b4:     	b	0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
1000305b8:     	cmp	w9, #0x5
1000305bc:     	b.eq	0x10003157c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
1000305c0:     	ldr	w9, [x28, #0x18]
1000305c4:     	ldr	x1, [x15, #0xe8]
1000305c8:     	add	w0, w9, w8
1000305cc:     	cmp	x1, x0
1000305d0:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000305d4:     	ldr	x8, [x15, #0xe0]
1000305d8:     	mov	w9, #0xc                ; =12
1000305dc:     	umaddl	x8, w0, w9, x8
1000305e0:     	ldp	w28, w25, [x8]
1000305e4:     	ldr	w27, [x8, #0x8]
1000305e8:     	cmp	w28, w24
1000305ec:     	b.hi	0x100030608 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
1000305f0:     	mov	x0, x21
1000305f4:     	bl	0x1000341ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
1000305f8:     	ldr	x15, [sp, #0x38]
1000305fc:     	cbz	x0, 0x100030608 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
100030600:     	ldr	x8, [x0, #0x8]
100030604:     	cbnz	x8, 0x10003156c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e08>
100030608:     	ldr	x8, [x15, #0x108]
10003060c:     	add	w2, w27, w25
100030610:     	cmp	x8, x2
100030614:     	b.lo	0x1000316f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f8c>
100030618:     	cmp	w25, w2
10003061c:     	b.hi	0x1000316e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f7c>
100030620:     	sub	x8, x8, x25
100030624:     	lsl	x9, x25, #3
100030628:     	cmp	x8, #0x0
10003062c:     	csel	x8, x9, xzr, gt
100030630:     	cbz	w27, 0x100030678 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
100030634:     	ldr	x9, [x15, #0xf8]
100030638:     	ldr	w27, [sp, #0x24]
10003063c:     	add	x8, x9, x8
100030640:     	sub	x9, x2, x25
100030644:     	add	x10, x8, #0x4
100030648:     	ldr	w0, [x10]
10003064c:     	cmp	x20, x0
100030650:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
100030654:     	ldur	w8, [x10, #-0x4]
100030658:     	cmp	x20, x8
10003065c:     	b.ls	0x100031644 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
100030660:     	ldr	q0, [x23, x0, lsl #4]
100030664:     	subs	x9, x9, #0x1
100030668:     	add	x10, x10, #0x8
10003066c:     	str	q0, [x23, x8, lsl #4]
100030670:     	b.ne	0x100030648 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xee4>
100030674:     	b	0x10002f83c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
100030678:     	ldr	w27, [sp, #0x24]
10003067c:     	b	0x10002f83c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
100030680:     	cmp	w8, #0x3
100030684:     	b.eq	0x10003149c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d38>
100030688:     	cmp	w8, #0x6
10003068c:     	b.eq	0x10003144c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
100030690:     	sub	w8, w9, #0x12
100030694:     	cmp	w8, #0x4
100030698:     	b.lo	0x100031474 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d10>
10003069c:     	ldr	w0, [x28, #0xc]
1000306a0:     	cmn	w0, #0x1
1000306a4:     	b.eq	0x100031204 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aa0>
1000306a8:     	cmp	x20, x0
1000306ac:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000306b0:     	lsl	x8, x0, #4
1000306b4:     	ldr	x5, [x23, x8]
1000306b8:     	ldr	w0, [x28, #0x10]
1000306bc:     	cmn	w0, #0x1
1000306c0:     	b.eq	0x100031214 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ab0>
1000306c4:     	cmp	x20, x0
1000306c8:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000306cc:     	lsl	x8, x0, #4
1000306d0:     	ldr	x7, [x23, x8]
1000306d4:     	ldr	w0, [x28, #0x14]
1000306d8:     	cmn	w0, #0x1
1000306dc:     	b.eq	0x100031224 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ac0>
1000306e0:     	cmp	x20, x0
1000306e4:     	b.ls	0x10003163c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
1000306e8:     	lsl	x8, x0, #4
1000306ec:     	ldr	x10, [x23, x8]
1000306f0:     	and	w8, w9, #0xffff0000
1000306f4:     	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
1000306f8:     	b.ne	0x100031234 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ad0>
1000306fc:     	and	w4, w9, #0xffff
100030700:     	cmp	w4, #0x3
100030704:     	b.ne	0x10003138c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c28>
100030708:     	ldr	x8, [x21]
10003070c:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
100030710:     	ldr	x0, [x8, #0x8]
100030714:     	bl	0x10004af80 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
100030718:     	ldr	x15, [sp, #0x38]
10003071c:     	mov	x0, xzr
100030720:     	mov	x1, xzr
100030724:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030728:     	ldr	w0, [x28, #0xc]
10003072c:     	cmp	x20, x0
100030730:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030734:     	ldr	w8, [x28, #0x10]
100030738:     	cmp	x20, x8
10003073c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030740:     	lsl	x9, x0, #4
100030744:     	lsl	x8, x8, #4
100030748:     	mov	x1, xzr
10003074c:     	ldr	x9, [x23, x9]
100030750:     	ldr	x8, [x23, x8]
100030754:     	eor	x0, x8, x9
100030758:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003075c:     	ldr	w0, [x28, #0xc]
100030760:     	cmp	x20, x0
100030764:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030768:     	ldr	w8, [x28, #0x10]
10003076c:     	cmp	x20, x8
100030770:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030774:     	lsl	x9, x0, #4
100030778:     	lsl	x8, x8, #4
10003077c:     	mov	x1, xzr
100030780:     	ldr	x9, [x23, x9]
100030784:     	ldr	x8, [x23, x8]
100030788:     	lsr	x0, x9, x8
10003078c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030790:     	ldr	w0, [x28, #0xc]
100030794:     	cmp	x20, x0
100030798:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003079c:     	ldr	w8, [x28, #0x10]
1000307a0:     	cmp	x20, x8
1000307a4:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000307a8:     	lsl	x9, x0, #4
1000307ac:     	lsl	x8, x8, #4
1000307b0:     	mov	x1, xzr
1000307b4:     	ldr	w9, [x23, x9]
1000307b8:     	ldr	w8, [x23, x8]
1000307bc:     	asr	w0, w9, w8
1000307c0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000307c4:     	ldr	w0, [x28, #0xc]
1000307c8:     	cmp	x20, x0
1000307cc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000307d0:     	ldr	w8, [x28, #0x10]
1000307d4:     	cmp	x20, x8
1000307d8:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000307dc:     	lsl	x9, x0, #4
1000307e0:     	lsl	x8, x8, #4
1000307e4:     	mov	x1, xzr
1000307e8:     	ldr	x9, [x23, x9]
1000307ec:     	ldr	x8, [x23, x8]
1000307f0:     	orr	x0, x8, x9
1000307f4:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000307f8:     	ldr	w0, [x28, #0xc]
1000307fc:     	cmp	x20, x0
100030800:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030804:     	ldr	w8, [x28, #0x10]
100030808:     	cmp	x20, x8
10003080c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030810:     	lsl	x9, x0, #4
100030814:     	lsl	x8, x8, #4
100030818:     	mov	x1, xzr
10003081c:     	ldr	w9, [x23, x9]
100030820:     	ldr	w8, [x23, x8]
100030824:     	lsl	w0, w9, w8
100030828:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003082c:     	ldr	w0, [x28, #0xc]
100030830:     	cmp	x20, x0
100030834:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030838:     	ldr	w8, [x28, #0x10]
10003083c:     	cmp	x20, x8
100030840:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030844:     	lsl	x9, x0, #4
100030848:     	lsl	x8, x8, #4
10003084c:     	mov	x1, xzr
100030850:     	ldr	w9, [x23, x9]
100030854:     	ldr	w8, [x23, x8]
100030858:     	orr	w0, w8, w9
10003085c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030860:     	ldr	w0, [x28, #0xc]
100030864:     	cmp	x20, x0
100030868:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003086c:     	lsl	x8, x0, #4
100030870:     	mov	x1, xzr
100030874:     	ldr	x8, [x23, x8]
100030878:     	rbit	x8, x8
10003087c:     	clz	x0, x8
100030880:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030884:     	ldr	w0, [x28, #0xc]
100030888:     	cmp	x20, x0
10003088c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030890:     	ldr	w8, [x28, #0x10]
100030894:     	cmp	x20, x8
100030898:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003089c:     	lsl	x9, x0, #4
1000308a0:     	lsl	x8, x8, #4
1000308a4:     	mov	x1, xzr
1000308a8:     	ldr	x9, [x23, x9]
1000308ac:     	ldr	x8, [x23, x8]
1000308b0:     	cmp	x9, x8
1000308b4:     	cset	w0, lo
1000308b8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000308bc:     	ldr	w0, [x28, #0xc]
1000308c0:     	cmp	x20, x0
1000308c4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000308c8:     	ldr	w8, [x28, #0x10]
1000308cc:     	cmp	x20, x8
1000308d0:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000308d4:     	lsl	x9, x0, #4
1000308d8:     	lsl	x8, x8, #4
1000308dc:     	mov	x1, xzr
1000308e0:     	ldr	x9, [x23, x9]
1000308e4:     	ldr	x8, [x23, x8]
1000308e8:     	cmp	x9, x8
1000308ec:     	cset	w0, ls
1000308f0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000308f4:     	ldr	w0, [x28, #0xc]
1000308f8:     	cmp	x20, x0
1000308fc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030900:     	ldr	w8, [x28, #0x10]
100030904:     	cmp	x20, x8
100030908:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003090c:     	lsl	x9, x0, #4
100030910:     	lsl	x8, x8, #4
100030914:     	mov	x1, xzr
100030918:     	ldr	x9, [x23, x9]
10003091c:     	ldr	x8, [x23, x8]
100030920:     	cmp	x9, x8
100030924:     	cset	w0, hi
100030928:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003092c:     	ldr	w0, [x28, #0xc]
100030930:     	cmp	x20, x0
100030934:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030938:     	ldr	w8, [x28, #0x10]
10003093c:     	cmp	x20, x8
100030940:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030944:     	lsl	x9, x0, #4
100030948:     	lsl	x8, x8, #4
10003094c:     	mov	x1, xzr
100030950:     	ldr	w9, [x23, x9]
100030954:     	ldr	w8, [x23, x8]
100030958:     	sub	w0, w9, w8
10003095c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030960:     	ldr	w0, [x28, #0xc]
100030964:     	cmp	x20, x0
100030968:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
10003096c:     	lsl	x8, x0, #4
100030970:     	mov	w11, #0x20              ; =32
100030974:     	mov	w12, #0x18              ; =24
100030978:     	mov	x1, xzr
10003097c:     	ldr	w8, [x23, x8]
100030980:     	lsr	w9, w8, #16
100030984:     	cmp	w9, #0x0
100030988:     	csel	w8, w9, w8, ne
10003098c:     	mov	x9, #-0x10              ; =-16
100030990:     	lsr	w10, w8, #8
100030994:     	csel	x9, x9, xzr, ne
100030998:     	cmp	w8, #0xff
10003099c:     	csel	w8, w10, w8, hi
1000309a0:     	adrp	x10, 0x1002ae000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xd38>
1000309a4:     	add	x10, x10, #0xa5d
1000309a8:     	and	x8, x8, #0xff
1000309ac:     	ldrb	w8, [x10, x8]
1000309b0:     	csel	x10, x12, x11, hi
1000309b4:     	add	x9, x10, x9
1000309b8:     	sub	x0, x9, x8
1000309bc:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000309c0:     	ldr	w0, [x28, #0xc]
1000309c4:     	cmp	x20, x0
1000309c8:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000309cc:     	ldr	w8, [x28, #0x10]
1000309d0:     	cmp	x20, x8
1000309d4:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000309d8:     	lsl	x9, x0, #4
1000309dc:     	lsl	x8, x8, #4
1000309e0:     	mov	x1, xzr
1000309e4:     	ldr	w9, [x23, x9]
1000309e8:     	ldr	w8, [x23, x8]
1000309ec:     	lsr	w0, w9, w8
1000309f0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000309f4:     	ldr	w0, [x28, #0xc]
1000309f8:     	cmp	x20, x0
1000309fc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a00:     	ldr	w8, [x28, #0x10]
100030a04:     	cmp	x20, x8
100030a08:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030a0c:     	lsl	x9, x0, #4
100030a10:     	lsl	x8, x8, #4
100030a14:     	mov	x1, xzr
100030a18:     	ldr	x9, [x23, x9]
100030a1c:     	ldr	x8, [x23, x8]
100030a20:     	cmp	x9, x8
100030a24:     	cset	w0, gt
100030a28:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a2c:     	ldr	w0, [x28, #0xc]
100030a30:     	cmp	x20, x0
100030a34:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a38:     	ldr	w8, [x28, #0x10]
100030a3c:     	cmp	x20, x8
100030a40:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030a44:     	lsl	x9, x0, #4
100030a48:     	lsl	x8, x8, #4
100030a4c:     	mov	x1, xzr
100030a50:     	ldr	w9, [x23, x9]
100030a54:     	ldr	w8, [x23, x8]
100030a58:     	cmp	w9, w8
100030a5c:     	cset	w0, lt
100030a60:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a64:     	ldr	w0, [x28, #0xc]
100030a68:     	cmp	x20, x0
100030a6c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030a70:     	ldr	w8, [x28, #0x10]
100030a74:     	cmp	x20, x8
100030a78:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030a7c:     	lsl	x9, x0, #4
100030a80:     	lsl	x8, x8, #4
100030a84:     	mov	x1, xzr
100030a88:     	ldr	x9, [x23, x9]
100030a8c:     	ldr	x8, [x23, x8]
100030a90:     	cmp	x9, x8
100030a94:     	cset	w0, ne
100030a98:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030a9c:     	ldr	w0, [x28, #0xc]
100030aa0:     	cmp	x20, x0
100030aa4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030aa8:     	lsl	x8, x0, #4
100030aac:     	ldr	w8, [x23, x8]
100030ab0:     	cbz	w8, 0x100031420 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cbc>
100030ab4:     	rbit	w8, w8
100030ab8:     	mov	x1, xzr
100030abc:     	clz	w0, w8
100030ac0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ac4:     	ldr	w0, [x28, #0xc]
100030ac8:     	cmp	x20, x0
100030acc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ad0:     	ldr	w8, [x28, #0x10]
100030ad4:     	cmp	x20, x8
100030ad8:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030adc:     	lsl	x9, x0, #4
100030ae0:     	lsl	x8, x8, #4
100030ae4:     	mov	x1, xzr
100030ae8:     	ldr	w9, [x23, x9]
100030aec:     	ldr	w8, [x23, x8]
100030af0:     	cmp	w9, w8
100030af4:     	cset	w0, ne
100030af8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030afc:     	ldr	w0, [x28, #0xc]
100030b00:     	cmp	x20, x0
100030b04:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b08:     	ldr	w8, [x28, #0x10]
100030b0c:     	cmp	x20, x8
100030b10:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030b14:     	lsl	x9, x0, #4
100030b18:     	lsl	x8, x8, #4
100030b1c:     	mov	x1, xzr
100030b20:     	ldr	x9, [x23, x9]
100030b24:     	ldr	x8, [x23, x8]
100030b28:     	cmp	x9, x8
100030b2c:     	cset	w0, le
100030b30:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b34:     	ldr	w0, [x28, #0xc]
100030b38:     	cmp	x20, x0
100030b3c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b40:     	ldr	w8, [x28, #0x10]
100030b44:     	cmp	x20, x8
100030b48:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030b4c:     	lsl	x8, x8, #4
100030b50:     	lsl	x9, x0, #4
100030b54:     	mov	x1, xzr
100030b58:     	ldr	w8, [x23, x8]
100030b5c:     	ldr	w9, [x23, x9]
100030b60:     	neg	w8, w8
100030b64:     	ror	w0, w9, w8
100030b68:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030b6c:     	ldr	w0, [x28, #0xc]
100030b70:     	cmp	x20, x0
100030b74:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030b78:     	ldr	w8, [x28, #0x10]
100030b7c:     	cmp	x20, x8
100030b80:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030b84:     	lsl	x9, x0, #4
100030b88:     	lsl	x8, x8, #4
100030b8c:     	mov	x1, xzr
100030b90:     	ldr	w9, [x23, x9]
100030b94:     	ldr	w8, [x23, x8]
100030b98:     	cmp	w9, w8
100030b9c:     	cset	w0, ls
100030ba0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ba4:     	ldr	w0, [x28, #0xc]
100030ba8:     	cmp	x20, x0
100030bac:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030bb0:     	ldr	w8, [x28, #0x10]
100030bb4:     	cmp	x20, x8
100030bb8:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030bbc:     	lsl	x9, x0, #4
100030bc0:     	lsl	x8, x8, #4
100030bc4:     	mov	x1, xzr
100030bc8:     	ldr	w9, [x23, x9]
100030bcc:     	ldr	w8, [x23, x8]
100030bd0:     	cmp	w9, w8
100030bd4:     	cset	w0, ge
100030bd8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030bdc:     	ldr	w0, [x28, #0xc]
100030be0:     	cmp	x20, x0
100030be4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030be8:     	lsl	x8, x0, #4
100030bec:     	mov	x1, xzr
100030bf0:     	ldr	w8, [x23, x8]
100030bf4:     	cmp	w8, #0x0
100030bf8:     	cset	w0, eq
100030bfc:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c00:     	ldr	w0, [x28, #0xc]
100030c04:     	cmp	x20, x0
100030c08:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c0c:     	ldr	w8, [x28, #0x10]
100030c10:     	cmp	x20, x8
100030c14:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030c18:     	lsl	x9, x0, #4
100030c1c:     	lsl	x8, x8, #4
100030c20:     	mov	x1, xzr
100030c24:     	ldr	w9, [x23, x9]
100030c28:     	ldr	w8, [x23, x8]
100030c2c:     	cmp	w9, w8
100030c30:     	cset	w0, lo
100030c34:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c38:     	ldr	w0, [x28, #0xc]
100030c3c:     	cmp	x20, x0
100030c40:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c44:     	ldr	w8, [x28, #0x10]
100030c48:     	cmp	x20, x8
100030c4c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030c50:     	lsl	x9, x0, #4
100030c54:     	lsl	x8, x8, #4
100030c58:     	mov	x1, xzr
100030c5c:     	ldr	x9, [x23, x9]
100030c60:     	ldr	x8, [x23, x8]
100030c64:     	add	x0, x8, x9
100030c68:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030c6c:     	ldr	w0, [x28, #0xc]
100030c70:     	cmp	x20, x0
100030c74:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030c78:     	ldr	w8, [x28, #0x10]
100030c7c:     	cmp	x20, x8
100030c80:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030c84:     	lsl	x9, x0, #4
100030c88:     	lsl	x8, x8, #4
100030c8c:     	mov	x1, xzr
100030c90:     	ldr	w9, [x23, x9]
100030c94:     	ldr	w8, [x23, x8]
100030c98:     	eor	w0, w8, w9
100030c9c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ca0:     	ldr	w0, [x28, #0xc]
100030ca4:     	cmp	x20, x0
100030ca8:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030cac:     	ldr	w8, [x28, #0x10]
100030cb0:     	cmp	x20, x8
100030cb4:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030cb8:     	lsl	x9, x0, #4
100030cbc:     	lsl	x8, x8, #4
100030cc0:     	mov	x1, xzr
100030cc4:     	ldr	x9, [x23, x9]
100030cc8:     	ldr	x8, [x23, x8]
100030ccc:     	and	x0, x8, x9
100030cd0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030cd4:     	ldr	w0, [x28, #0xc]
100030cd8:     	cmp	x20, x0
100030cdc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ce0:     	ldr	w8, [x28, #0x10]
100030ce4:     	cmp	x20, x8
100030ce8:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030cec:     	lsl	x9, x0, #4
100030cf0:     	lsl	x8, x8, #4
100030cf4:     	mov	x1, xzr
100030cf8:     	ldr	x9, [x23, x9]
100030cfc:     	ldr	x8, [x23, x8]
100030d00:     	sub	x0, x9, x8
100030d04:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030d08:     	ldr	w0, [x28, #0xc]
100030d0c:     	cmp	x20, x0
100030d10:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d14:     	ldr	w8, [x28, #0x10]
100030d18:     	cmp	x20, x8
100030d1c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030d20:     	lsl	x8, x8, #4
100030d24:     	lsl	x9, x0, #4
100030d28:     	ldr	w8, [x23, x8]
100030d2c:     	ldr	x9, [x23, x9]
100030d30:     	neg	w8, w8
100030d34:     	b	0x100030ee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x177c>
100030d38:     	ldr	w0, [x28, #0xc]
100030d3c:     	cmp	x20, x0
100030d40:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d44:     	ldr	w8, [x28, #0x10]
100030d48:     	cmp	x20, x8
100030d4c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030d50:     	lsl	x9, x0, #4
100030d54:     	lsl	x8, x8, #4
100030d58:     	mov	x1, xzr
100030d5c:     	ldr	w9, [x23, x9]
100030d60:     	ldr	w8, [x23, x8]
100030d64:     	cmp	w9, w8
100030d68:     	cset	w0, eq
100030d6c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030d70:     	ldr	w0, [x28, #0xc]
100030d74:     	cmp	x20, x0
100030d78:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030d7c:     	ldr	w8, [x28, #0x10]
100030d80:     	cmp	x20, x8
100030d84:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030d88:     	lsl	x9, x0, #4
100030d8c:     	lsl	x8, x8, #4
100030d90:     	mov	x1, xzr
100030d94:     	ldr	w9, [x23, x9]
100030d98:     	ldr	w8, [x23, x8]
100030d9c:     	cmp	w9, w8
100030da0:     	cset	w0, hs
100030da4:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030da8:     	ldr	w0, [x28, #0xc]
100030dac:     	cmp	x20, x0
100030db0:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030db4:     	ldr	w8, [x28, #0x10]
100030db8:     	cmp	x20, x8
100030dbc:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030dc0:     	lsl	x9, x0, #4
100030dc4:     	lsl	x8, x8, #4
100030dc8:     	mov	x1, xzr
100030dcc:     	ldr	w9, [x23, x9]
100030dd0:     	ldr	w8, [x23, x8]
100030dd4:     	mul	w0, w8, w9
100030dd8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030ddc:     	ldr	w0, [x28, #0xc]
100030de0:     	cmp	x20, x0
100030de4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030de8:     	ldr	w8, [x28, #0x10]
100030dec:     	cmp	x20, x8
100030df0:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030df4:     	lsl	x9, x0, #4
100030df8:     	lsl	x8, x8, #4
100030dfc:     	mov	x1, xzr
100030e00:     	ldr	w9, [x23, x9]
100030e04:     	ldr	w8, [x23, x8]
100030e08:     	cmp	w9, w8
100030e0c:     	cset	w0, le
100030e10:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e14:     	ldr	w0, [x28, #0xc]
100030e18:     	cmp	x20, x0
100030e1c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030e20:     	ldr	w8, [x28, #0x10]
100030e24:     	cmp	x20, x8
100030e28:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030e2c:     	lsl	x9, x0, #4
100030e30:     	lsl	x8, x8, #4
100030e34:     	mov	x1, xzr
100030e38:     	ldr	w9, [x23, x9]
100030e3c:     	ldr	w8, [x23, x8]
100030e40:     	cmp	w9, w8
100030e44:     	cset	w0, gt
100030e48:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e4c:     	ldr	w0, [x28, #0xc]
100030e50:     	cmp	x20, x0
100030e54:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030e58:     	ldr	w8, [x28, #0x10]
100030e5c:     	cmp	x20, x8
100030e60:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030e64:     	lsl	x9, x0, #4
100030e68:     	lsl	x8, x8, #4
100030e6c:     	mov	x1, xzr
100030e70:     	ldr	w9, [x23, x9]
100030e74:     	ldr	w8, [x23, x8]
100030e78:     	ror	w0, w9, w8
100030e7c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030e80:     	ldr	w0, [x28, #0xc]
100030e84:     	cmp	x20, x0
100030e88:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030e8c:     	ldr	w8, [x28, #0x10]
100030e90:     	cmp	x20, x8
100030e94:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030e98:     	lsl	x9, x0, #4
100030e9c:     	lsl	x8, x8, #4
100030ea0:     	mov	x1, xzr
100030ea4:     	ldr	x9, [x23, x9]
100030ea8:     	ldr	x8, [x23, x8]
100030eac:     	cmp	x9, x8
100030eb0:     	cset	w0, lt
100030eb4:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030eb8:     	ldr	w0, [x28, #0xc]
100030ebc:     	cmp	x20, x0
100030ec0:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ec4:     	ldr	w8, [x28, #0x10]
100030ec8:     	cmp	x20, x8
100030ecc:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030ed0:     	lsl	x9, x0, #4
100030ed4:     	lsl	x8, x8, #4
100030ed8:     	ldr	x9, [x23, x9]
100030edc:     	ldr	x8, [x23, x8]
100030ee0:     	ror	x0, x9, x8
100030ee4:     	mov	x1, xzr
100030ee8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030eec:     	ldr	w0, [x28, #0xc]
100030ef0:     	cmp	x20, x0
100030ef4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030ef8:     	ldr	w8, [x28, #0x10]
100030efc:     	cmp	x20, x8
100030f00:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030f04:     	lsl	x9, x0, #4
100030f08:     	lsl	x8, x8, #4
100030f0c:     	mov	x1, xzr
100030f10:     	ldr	w9, [x23, x9]
100030f14:     	ldr	w8, [x23, x8]
100030f18:     	cmp	w9, w8
100030f1c:     	cset	w0, hi
100030f20:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f24:     	ldr	w0, [x28, #0xc]
100030f28:     	cmp	x20, x0
100030f2c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f30:     	lsl	x8, x0, #4
100030f34:     	mov	x1, xzr
100030f38:     	ldrsb	x0, [x23, x8]
100030f3c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f40:     	ldr	w0, [x28, #0xc]
100030f44:     	cmp	x20, x0
100030f48:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f4c:     	lsl	x8, x0, #4
100030f50:     	mov	x1, xzr
100030f54:     	ldrsh	x0, [x23, x8]
100030f58:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f5c:     	ldr	w0, [x28, #0xc]
100030f60:     	cmp	x20, x0
100030f64:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030f68:     	ldr	w8, [x28, #0x10]
100030f6c:     	cmp	x20, x8
100030f70:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030f74:     	lsl	x9, x0, #4
100030f78:     	lsl	x8, x8, #4
100030f7c:     	mov	x1, xzr
100030f80:     	ldr	x9, [x23, x9]
100030f84:     	ldr	x8, [x23, x8]
100030f88:     	cmp	x9, x8
100030f8c:     	cset	w0, eq
100030f90:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030f94:     	ldr	w0, [x28, #0xc]
100030f98:     	cmp	x20, x0
100030f9c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030fa0:     	ldr	w8, [x28, #0x10]
100030fa4:     	cmp	x20, x8
100030fa8:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030fac:     	lsl	x9, x0, #4
100030fb0:     	lsl	x8, x8, #4
100030fb4:     	mov	x1, xzr
100030fb8:     	ldr	x9, [x23, x9]
100030fbc:     	ldr	x8, [x23, x8]
100030fc0:     	cmp	x9, x8
100030fc4:     	cset	w0, hs
100030fc8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100030fcc:     	ldr	w0, [x28, #0xc]
100030fd0:     	cmp	x20, x0
100030fd4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100030fd8:     	ldr	w8, [x28, #0x10]
100030fdc:     	cmp	x20, x8
100030fe0:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100030fe4:     	lsl	x9, x0, #4
100030fe8:     	lsl	x8, x8, #4
100030fec:     	mov	x1, xzr
100030ff0:     	ldr	x9, [x23, x9]
100030ff4:     	ldr	x8, [x23, x8]
100030ff8:     	cmp	x9, x8
100030ffc:     	cset	w0, ge
100031000:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031004:     	ldr	w0, [x28, #0xc]
100031008:     	cmp	x20, x0
10003100c:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031010:     	ldr	w8, [x28, #0x10]
100031014:     	cmp	x20, x8
100031018:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
10003101c:     	lsl	x9, x0, #4
100031020:     	lsl	x8, x8, #4
100031024:     	mov	x1, xzr
100031028:     	ldr	x9, [x23, x9]
10003102c:     	ldr	x8, [x23, x8]
100031030:     	asr	x0, x9, x8
100031034:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031038:     	ldr	w0, [x28, #0xc]
10003103c:     	cmp	x20, x0
100031040:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031044:     	ldr	w8, [x28, #0x10]
100031048:     	cmp	x20, x8
10003104c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031050:     	lsl	x9, x0, #4
100031054:     	lsl	x8, x8, #4
100031058:     	mov	x1, xzr
10003105c:     	ldr	w9, [x23, x9]
100031060:     	ldr	w8, [x23, x8]
100031064:     	and	w0, w9, w8
100031068:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003106c:     	ldr	w0, [x28, #0xc]
100031070:     	cmp	x20, x0
100031074:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031078:     	ldr	w8, [x28, #0x10]
10003107c:     	cmp	x20, x8
100031080:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031084:     	lsl	x9, x0, #4
100031088:     	lsl	x8, x8, #4
10003108c:     	mov	x1, xzr
100031090:     	ldr	w9, [x23, x9]
100031094:     	ldr	w8, [x23, x8]
100031098:     	add	w0, w8, w9
10003109c:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310a0:     	ldr	w0, [x28, #0xc]
1000310a4:     	cmp	x20, x0
1000310a8:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000310ac:     	ldr	w8, [x28, #0x10]
1000310b0:     	cmp	x20, x8
1000310b4:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
1000310b8:     	lsl	x9, x0, #4
1000310bc:     	lsl	x8, x8, #4
1000310c0:     	mov	x1, xzr
1000310c4:     	ldr	x9, [x23, x9]
1000310c8:     	ldr	x8, [x23, x8]
1000310cc:     	mul	x0, x8, x9
1000310d0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310d4:     	ldr	w0, [x28, #0xc]
1000310d8:     	cmp	x20, x0
1000310dc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000310e0:     	lsl	x8, x0, #4
1000310e4:     	mov	x1, xzr
1000310e8:     	ldrsb	x8, [x23, x8]
1000310ec:     	mov	w0, w8
1000310f0:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000310f4:     	ldr	w0, [x28, #0xc]
1000310f8:     	cmp	x20, x0
1000310fc:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031100:     	lsl	x8, x0, #4
100031104:     	mov	w10, #0x20              ; =32
100031108:     	mov	x1, xzr
10003110c:     	ldr	x8, [x23, x8]
100031110:     	lsr	x9, x8, #32
100031114:     	cmp	x9, #0x0
100031118:     	csel	x8, x9, x8, ne
10003111c:     	csel	x10, x10, xzr, ne
100031120:     	lsr	x9, x8, #16
100031124:     	cmp	x9, #0x0
100031128:     	csel	x8, x9, x8, ne
10003112c:     	orr	x9, x10, #0x10
100031130:     	lsr	x11, x8, #8
100031134:     	csel	x9, x9, x10, ne
100031138:     	cmp	x8, #0xff
10003113c:     	orr	x10, x9, #0x8
100031140:     	csel	x8, x11, x8, hi
100031144:     	adrp	x11, 0x1002ae000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xd38>
100031148:     	add	x11, x11, #0xa5d
10003114c:     	and	x8, x8, #0xff
100031150:     	csel	x9, x10, x9, hi
100031154:     	mov	w10, #0x40              ; =64
100031158:     	ldrb	w8, [x11, x8]
10003115c:     	sub	x9, x10, x9
100031160:     	sub	x0, x9, x8
100031164:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031168:     	ldr	w0, [x28, #0xc]
10003116c:     	cmp	x20, x0
100031170:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031174:     	ldr	w8, [x28, #0x10]
100031178:     	cmp	x20, x8
10003117c:     	b.ls	0x100031658 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
100031180:     	lsl	x9, x0, #4
100031184:     	lsl	x8, x8, #4
100031188:     	mov	x1, xzr
10003118c:     	ldr	x9, [x23, x9]
100031190:     	ldr	x8, [x23, x8]
100031194:     	lsl	x0, x9, x8
100031198:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003119c:     	ldr	w0, [x28, #0xc]
1000311a0:     	cmp	x20, x0
1000311a4:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
1000311a8:     	lsl	x8, x0, #4
1000311ac:     	mov	x1, xzr
1000311b0:     	ldrsh	x8, [x23, x8]
1000311b4:     	mov	w0, w8
1000311b8:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
1000311bc:     	sub	w8, w9, #0x8b
1000311c0:     	cmp	w8, #0x34
1000311c4:     	b.hi	0x1000311dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a78>
1000311c8:     	mov	x10, #-0x10000001       ; =-268435457
1000311cc:     	movk	x10, #0xfff9, lsl #32
1000311d0:     	movk	x10, #0x1f, lsl #48
1000311d4:     	lsr	x8, x10, x8
1000311d8:     	tbnz	w8, #0x0, 0x10002fa58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
1000311dc:     	sub	w8, w9, #0x61
1000311e0:     	mov	x0, xzr
1000311e4:     	cmp	w8, #0x21
1000311e8:     	b.hi	0x100031444 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce0>
1000311ec:     	mov	x10, #0x3c0000000       ; =16106127360
1000311f0:     	mov	x1, x0
1000311f4:     	movk	x10, #0xf03f
1000311f8:     	lsr	x8, x10, x8
1000311fc:     	tbnz	w8, #0x0, 0x10002fa58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
100031200:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031204:     	mov	x5, xzr
100031208:     	ldr	w0, [x28, #0x10]
10003120c:     	cmn	w0, #0x1
100031210:     	b.ne	0x1000306c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf60>
100031214:     	mov	x7, xzr
100031218:     	ldr	w0, [x28, #0x14]
10003121c:     	cmn	w0, #0x1
100031220:     	b.ne	0x1000306e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf7c>
100031224:     	mov	x10, xzr
100031228:     	and	w8, w9, #0xffff0000
10003122c:     	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100031230:     	b.eq	0x1000306fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf98>
100031234:     	mov	w8, #0xffed             ; =65517
100031238:     	movk	w8, #0xff03, lsl #16
10003123c:     	add	w8, w8, w9
100031240:     	add	w8, w8, #0xb
100031244:     	cmp	w8, #0xa
100031248:     	b.hs	0x100031748 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
10003124c:     	ldr	x1, [x15, #0x80]
100031250:     	ldr	w0, [x28, #0x4]
100031254:     	cmp	x1, x0
100031258:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10003125c:     	ldr	x8, [x15, #0x78]
100031260:     	mov	w9, #0xe0               ; =224
100031264:     	umaddl	x8, w0, w9, x8
100031268:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
10003126c:     	ldr	w9, [x8]
100031270:     	ldr	x11, [x8, #0x8]
100031274:     	add	x12, sp, #0xd8
100031278:     	ldr	q0, [x8, #0x10]
10003127c:     	ldur	q1, [x8, #0x48]
100031280:     	add	x2, sp, #0xd8
100031284:     	str	w9, [sp, #0xd8]
100031288:     	ldur	q2, [x8, #0x68]
10003128c:     	mov	x0, x21
100031290:     	str	x11, [sp, #0xe0]
100031294:     	ldp	x9, x11, [x8, #0x20]
100031298:     	str	q0, [x12, #0x10]
10003129c:     	mov	x3, x5
1000312a0:     	mov	x4, xzr
1000312a4:     	ldr	q0, [x8, #0x30]
1000312a8:     	stur	q1, [x12, #0x48]
1000312ac:     	mov	x5, x7
1000312b0:     	stp	x9, x11, [sp, #0xf8]
1000312b4:     	ldrb	w9, [x8, #0x40]
1000312b8:     	mov	x6, xzr
1000312bc:     	str	q0, [x12, #0x30]
1000312c0:     	ldur	q0, [x8, #0x58]
1000312c4:     	mov	x7, x10
1000312c8:     	strb	w9, [sp, #0x118]
1000312cc:     	ldur	q1, [x8, #0x78]
1000312d0:     	ldr	x1, [sp, #0x28]
1000312d4:     	stur	q0, [x12, #0x58]
1000312d8:     	ldur	q0, [x8, #0x88]
1000312dc:     	ldp	x9, x8, [x8, #0x98]
1000312e0:     	stur	q2, [x12, #0x68]
1000312e4:     	stur	q1, [x12, #0x78]
1000312e8:     	stur	q0, [x12, #0x88]
1000312ec:     	stp	x9, x8, [sp, #0x170]
1000312f0:     	add	x8, sp, #0xb0
1000312f4:     	str	xzr, [sp]
1000312f8:     	bl	0x10003596c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
1000312fc:     	ldp	x0, x1, [sp, #0xb0]
100031300:     	ldr	x8, [sp, #0xc8]
100031304:     	ldrb	w25, [sp, #0xc0]
100031308:     	cbz	x8, 0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
10003130c:     	ldr	x9, [x8, #0x8]
100031310:     	ldr	x15, [sp, #0x38]
100031314:     	cbz	x9, 0x1000300bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
100031318:     	b	0x100031618 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eb4>
10003131c:     	mov	w0, #0x1                ; =1
100031320:     	str	x11, [sp, #0x10]
100031324:     	bl	0x10020a3d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031328:     	ldr	x11, [sp, #0x10]
10003132c:     	ldr	w0, [x28, #0xc]
100031330:     	cmp	x20, x0
100031334:     	b.ls	0x10003165c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
100031338:     	lsl	x9, x0, #4
10003133c:     	tst	w8, #0x1
100031340:     	mov	x0, x11
100031344:     	mov	x1, x25
100031348:     	ldr	x9, [x23, x9]
10003134c:     	mov	w10, w9
100031350:     	csel	x2, x9, x10, ne
100031354:     	bl	0x100048d98 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
100031358:     	tbz	w1, #0x0, 0x100031368 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
10003135c:     	ldr	x15, [sp, #0x38]
100031360:     	mov	x1, xzr
100031364:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031368:     	ldr	x8, [x25, #0x10]
10003136c:     	ldr	x15, [sp, #0x38]
100031370:     	cbz	x8, 0x10003142c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cc8>
100031374:     	ldrb	w8, [x8, #0x31]
100031378:     	mov	x1, xzr
10003137c:     	cmp	w8, #0x0
100031380:     	mov	w8, #-0x1               ; =-1
100031384:     	csinv	x0, x8, xzr, eq
100031388:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003138c:     	ldr	x1, [x15, #0x80]
100031390:     	ldr	w0, [x28, #0x4]
100031394:     	cmp	x1, x0
100031398:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
10003139c:     	ldr	x8, [x15, #0x78]
1000313a0:     	mov	w9, #0xe0               ; =224
1000313a4:     	umaddl	x8, w0, w9, x8
1000313a8:     	cbz	x8, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313ac:     	ldr	x9, [sp, #0x28]
1000313b0:     	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313b4:     	ldr	x1, [x9, #0x78]
1000313b8:     	ldr	w0, [x8, #0x18]
1000313bc:     	cmp	x1, x0
1000313c0:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000313c4:     	ldr	x9, [x9, #0x70]
1000313c8:     	adds	x9, x9, x0, lsl #3
1000313cc:     	b.eq	0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313d0:     	ldr	x9, [x9]
1000313d4:     	cbz	x9, 0x1000314bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
1000313d8:     	ldp	x11, x1, [x21]
1000313dc:     	ldr	w12, [x8, #0x14]
1000313e0:     	ldr	w8, [x8, #0x1c]
1000313e4:     	ldr	x0, [x9, #0x10]
1000313e8:     	ldr	x2, [x21, #0x10]
1000313ec:     	ldr	x3, [x11, #0x8]
1000313f0:     	orr	x6, x12, x8, lsl #32
1000313f4:     	sub	x8, x29, #0xa0
1000313f8:     	str	x10, [sp]
1000313fc:     	bl	0x10004d080 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
100031400:     	ldp	x0, x1, [x29, #-0xa0]
100031404:     	ldur	x8, [x29, #-0x88]
100031408:     	ldurb	w25, [x29, #-0x90]
10003140c:     	cbz	x8, 0x1000300b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
100031410:     	ldr	x9, [x8, #0x8]
100031414:     	ldr	x15, [sp, #0x38]
100031418:     	cbz	x9, 0x1000300bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
10003141c:     	b	0x100031620 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ebc>
100031420:     	mov	x1, xzr
100031424:     	mov	w0, #0x20               ; =32
100031428:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003142c:     	mov	w0, #0x1                ; =1
100031430:     	bl	0x10020a3d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031434:     	ldr	x15, [sp, #0x38]
100031438:     	mov	x1, xzr
10003143c:     	mov	w0, #-0x1               ; =-1
100031440:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
100031444:     	mov	x1, x0
100031448:     	b	0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
10003144c:     	ldr	x8, [sp, #0x30]
100031450:     	mov	x0, x21
100031454:     	stur	w24, [x8, #-0x38]
100031458:     	bl	0x10003348c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
10003145c:     	tst	w0, #0xff
100031460:     	b.ne	0x100031514 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
100031464:     	ldr	x8, [x21, #0x48]
100031468:     	cmp	x8, #0x0
10003146c:     	b.gt	0x10002f7a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x40>
100031470:     	b	0x100031730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
100031474:     	ldr	x8, [sp, #0x30]
100031478:     	mov	x0, x21
10003147c:     	stur	w24, [x8, #-0x38]
100031480:     	bl	0x1000325ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
100031484:     	b	0x10003145c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
100031488:     	ldr	x8, [sp, #0x30]
10003148c:     	mov	x0, x21
100031490:     	stur	w24, [x8, #-0x38]
100031494:     	bl	0x100033098 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
100031498:     	b	0x10003145c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
10003149c:     	ldr	x8, [sp, #0x30]
1000314a0:     	mov	x0, x21
1000314a4:     	stur	w24, [x8, #-0x38]
1000314a8:     	bl	0x1000321c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
1000314ac:     	tst	w0, #0xff
1000314b0:     	b.eq	0x100031464 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d00>
1000314b4:     	mov	w0, #0x1                ; =1
1000314b8:     	b	0x1000315f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
1000314bc:     	mov	w0, #0x1                ; =1
1000314c0:     	bl	0x10020a3d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000314c4:     	mov	x0, xzr
1000314c8:     	b	0x1000315f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
1000314cc:     	mov	w0, #0x28               ; =40
1000314d0:     	bl	0x10021ec88 <dyld_stub_binder+0x10021ec88>
1000314d4:     	cbz	x0, 0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
1000314d8:     	mov	x20, x0
1000314dc:     	mov	w0, #0x28               ; =40
1000314e0:     	bl	0x100205ea4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1000314e4:     	ldr	x8, [x25, #0x8]
1000314e8:     	adrp	x9, 0x1003bc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
1000314ec:     	adrp	x10, 0x100293000 <dyld_stub_binder+0x100293000>
1000314f0:     	add	x10, x10, #0xb28
1000314f4:     	ldr	q0, [x9, #0xe10]
1000314f8:     	adrp	x1, 0x1002ee000 <__llgo_struct$q3PA0LZP97wpNbxg_ocAy1psepid_kL-4QjthQQIIOw$fields+0x50>
1000314fc:     	add	x1, x1, #0x5f0
100031500:     	stp	x8, x10, [x20, #0x10]
100031504:     	mov	w8, #0xe                ; =14
100031508:     	str	q0, [x20]
10003150c:     	str	x8, [x20, #0x20]
100031510:     	b	0x1000315e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
100031514:     	and	x0, x0, #0xff
100031518:     	b	0x1000315f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
10003151c:     	ldr	x20, [sp, #0xa8]
100031520:     	mov	w0, #0x8                ; =8
100031524:     	bl	0x10020a1a8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
100031528:     	mov	x22, x0
10003152c:     	adrp	x2, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe0>
100031530:     	add	x2, x2, #0x5e8
100031534:     	mov	x0, x25
100031538:     	mov	x1, x20
10003153c:     	mov	x3, x22
100031540:     	bl	0x1001e5264 <_errors.As>
100031544:     	tbz	w0, #0x0, 0x100031558 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1df4>
100031548:     	ldr	x9, [sp, #0x18]
10003154c:     	ldr	x8, [x22]
100031550:     	ldr	w9, [x9, #0x50]
100031554:     	str	w9, [x8, #0x4]
100031558:     	mov	x0, x21
10003155c:     	mov	x1, x25
100031560:     	b	0x1000315e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e84>
100031564:     	mov	w25, #0x3               ; =3
100031568:     	b	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
10003156c:     	mov	x2, x1
100031570:     	mov	x1, x0
100031574:     	mov	x0, x21
100031578:     	b	0x1000315ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
10003157c:     	mov	w25, #0x1               ; =1
100031580:     	b	0x100031588 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
100031584:     	mov	w25, #0x9               ; =9
100031588:     	mov	w0, #0x10               ; =16
10003158c:     	bl	0x10021ec7c <dyld_stub_binder+0x10021ec7c>
100031590:     	cbz	x0, 0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
100031594:     	mov	x20, x0
100031598:     	mov	w0, #0x10               ; =16
10003159c:     	bl	0x100205ea4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1000315a0:     	ldr	x9, [sp, #0x38]
1000315a4:     	stp	xzr, xzr, [x20]
1000315a8:     	ldr	w0, [x28, #0x4]
1000315ac:     	ldr	x1, [x9, #0x80]
1000315b0:     	cmp	x1, x0
1000315b4:     	b.ls	0x100031654 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
1000315b8:     	mov	w8, #0xe0               ; =224
1000315bc:     	ldr	x9, [x9, #0x78]
1000315c0:     	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe0>
1000315c4:     	add	x1, x1, #0x950
1000315c8:     	umaddl	x8, w0, w8, x9
1000315cc:     	ldr	x9, [sp, #0x18]
1000315d0:     	ldr	w9, [x9, #0x50]
1000315d4:     	ldr	x8, [x8, #0x8]
1000315d8:     	strb	w25, [x20]
1000315dc:     	str	w9, [x20, #0x4]
1000315e0:     	str	x8, [x20, #0x8]
1000315e4:     	mov	x0, x21
1000315e8:     	mov	x2, x20
1000315ec:     	bl	0x10002e94c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
1000315f0:     	mov	w0, #0x3                ; =3
1000315f4:     	mov	x1, x19
1000315f8:     	add	sp, sp, #0x1d0
1000315fc:     	ldp	x29, x30, [sp, #0x50]
100031600:     	ldp	x20, x19, [sp, #0x40]
100031604:     	ldp	x22, x21, [sp, #0x30]
100031608:     	ldp	x24, x23, [sp, #0x20]
10003160c:     	ldp	x26, x25, [sp, #0x10]
100031610:     	ldp	x28, x27, [sp], #0x60
100031614:     	ret
100031618:     	ldr	x2, [sp, #0xd0]
10003161c:     	b	0x100031624 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ec0>
100031620:     	ldur	x2, [x29, #-0x80]
100031624:     	mov	x0, x21
100031628:     	mov	x1, x8
10003162c:     	b	0x1000315ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
100031630:     	mov	x0, x24
100031634:     	mov	x1, x22
100031638:     	bl	0x100207550 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003163c:     	mov	x1, x20
100031640:     	bl	0x100205f9c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031644:     	mov	x0, x8
100031648:     	mov	x1, x20
10003164c:     	bl	0x100205f9c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031650:     	mov	x1, x22
100031654:     	bl	0x100207550 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031658:     	mov	x0, x8
10003165c:     	mov	x1, x20
100031660:     	bl	0x100207550 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031664:     	mov	x0, x8
100031668:     	bl	0x100207550 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003166c:     	mov	x0, x10
100031670:     	mov	x1, x20
100031674:     	bl	0x100207550 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031678:     	mov	x0, x8
10003167c:     	mov	w1, #0x1                ; =1
100031680:     	mov	x2, x9
100031684:     	mov	w3, #0x3                ; =3
100031688:     	bl	0x100206cb4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003168c:     	mov	x0, x9
100031690:     	mov	w1, #0x1                ; =1
100031694:     	mov	w3, #0x2                ; =2
100031698:     	bl	0x100206cb4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003169c:     	mov	x0, x9
1000316a0:     	mov	x1, x20
1000316a4:     	bl	0x100207550 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000316a8:     	mov	w0, #0x1                ; =1
1000316ac:     	bl	0x100205f9c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000316b0:     	mov	x0, xzr
1000316b4:     	mov	x1, xzr
1000316b8:     	bl	0x100205f9c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000316bc:     	mov	x0, x8
1000316c0:     	mov	w1, wzr
1000316c4:     	mov	w3, #0x3                ; =3
1000316c8:     	bl	0x100206cb4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000316cc:     	mov	x0, x2
1000316d0:     	mov	w1, wzr
1000316d4:     	mov	x2, x10
1000316d8:     	mov	w3, #0x2                ; =2
1000316dc:     	bl	0x100206cb4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000316e0:     	mov	x0, x25
1000316e4:     	mov	w1, wzr
1000316e8:     	mov	w3, #0x3                ; =3
1000316ec:     	bl	0x100206cb4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000316f0:     	mov	x0, x2
1000316f4:     	mov	w1, wzr
1000316f8:     	mov	x2, x8
1000316fc:     	mov	w3, #0x2                ; =2
100031700:     	bl	0x100206cb4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031704:     	mov	w0, #0x3                ; =3
100031708:     	bl	0x100205f9c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003170c:     	mov	w0, #0x2                ; =2
100031710:     	mov	w1, #0x2                ; =2
100031714:     	bl	0x100205f9c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031718:     	adrp	x0, 0x100345000 <__llgo_func$5y6TRKwaWPE10AAwnlBqoVZEnFOulgb5ezY7raDDgrY+0x18>
10003171c:     	add	x0, x0, #0xcb8
100031720:     	adrp	x1, 0x100345000 <__llgo_func$5y6TRKwaWPE10AAwnlBqoVZEnFOulgb5ezY7raDDgrY+0x18>
100031724:     	add	x1, x1, #0xf38
100031728:     	bl	0x100205c90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10003172c:     	brk	#0x1
100031730:     	adrp	x0, 0x10034f000 <__llgo_ifacebox$LP1Iwt1nahmJKh7_-mOjxhUQqBht_jHtJklhWOO7_5c+0x8>
100031734:     	add	x0, x0, #0x5f0
100031738:     	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe0>
10003173c:     	add	x1, x1, #0x638
100031740:     	bl	0x100205c90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031744:     	brk	#0x1
100031748:     	adrp	x0, 0x10034f000 <__llgo_ifacebox$LP1Iwt1nahmJKh7_-mOjxhUQqBht_jHtJklhWOO7_5c+0x8>
10003174c:     	add	x0, x0, #0x5f0
100031750:     	adrp	x1, 0x1002d1000 <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe0>
100031754:     	add	x1, x1, #0x648
100031758:     	bl	0x100205c90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
10003175c:     	brk	#0x1
100031760:     	adrp	x0, 0x10034f000 <__llgo_ifacebox$LP1Iwt1nahmJKh7_-mOjxhUQqBht_jHtJklhWOO7_5c+0x8>
100031764:     	add	x0, x0, #0x5f0
100031768:     	adrp	x1, 0x100345000 <__llgo_func$5y6TRKwaWPE10AAwnlBqoVZEnFOulgb5ezY7raDDgrY+0x18>
10003176c:     	add	x1, x1, #0xca8
100031770:     	bl	0x100205c90 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031774:     	brk	#0x1
