
/Users/lijie/source/goplus/wasmvm/artifacts/native-loop-poll-groups-20261117/base-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010002fb5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>:
10002fb5c:     	stp	x28, x27, [sp, #-0x60]!
10002fb60:     	stp	x26, x25, [sp, #0x10]
10002fb64:     	stp	x24, x23, [sp, #0x20]
10002fb68:     	stp	x22, x21, [sp, #0x30]
10002fb6c:     	stp	x20, x19, [sp, #0x40]
10002fb70:     	stp	x29, x30, [sp, #0x50]
10002fb74:     	add	x29, sp, #0x50
10002fb78:     	sub	sp, sp, #0x1d0
10002fb7c:     	ldr	x8, [x0, #0x48]
10002fb80:     	cmp	x8, #0x1
10002fb84:     	b.lt	0x100031b9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
10002fb88:     	ldrb	w26, [x0, #0x20]
10002fb8c:     	mov	x21, x0
10002fb90:     	mov	x20, x1
10002fb94:     	str	w26, [sp, #0x14]
10002fb98:     	ldr	x9, [x21, #0x40]
10002fb9c:     	add	x8, x9, x8, lsl #6
10002fba0:     	ldur	x10, [x8, #-0x40]
10002fba4:     	sturb	wzr, [x8, #-0x30]
10002fba8:     	str	x8, [sp, #0x18]
10002fbac:     	ldur	x8, [x8, #-0x28]
10002fbb0:     	ldr	x2, [x21, #0x88]
10002fbb4:     	ldr	x16, [x10, #0x48]
10002fbb8:     	ldr	x19, [x16, #0x98]
10002fbbc:     	add	x9, x19, x8
10002fbc0:     	cmp	x9, x2
10002fbc4:     	b.hi	0x100031acc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f70>
10002fbc8:     	cmp	x8, x9
10002fbcc:     	b.hi	0x100031adc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f80>
10002fbd0:     	ldr	x9, [sp, #0x18]
10002fbd4:     	ldr	x22, [x16, #0xb8]
10002fbd8:     	ldur	w0, [x9, #-0x38]
10002fbdc:     	sub	x9, x2, x8
10002fbe0:     	lsl	x8, x8, #4
10002fbe4:     	cmp	x9, #0x0
10002fbe8:     	csel	x8, x8, xzr, gt
10002fbec:     	cmp	x22, x0
10002fbf0:     	b.ls	0x100031aa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
10002fbf4:     	ldr	x9, [x21, #0x78]
10002fbf8:     	ldr	x28, [x16, #0xb0]
10002fbfc:     	mov	w24, w0
10002fc00:     	str	x10, [sp, #0x8]
10002fc04:     	ldr	x10, [x10, #0x40]
10002fc08:     	add	x23, x9, x8
10002fc0c:     	stp	x10, x16, [sp, #0x20]
10002fc10:     	b	0x10002fc28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xcc>
10002fc14:     	add	w27, w24, #0x1
10002fc18:     	mov	w0, w27
10002fc1c:     	mov	w24, w27
10002fc20:     	cmp	x22, x0
10002fc24:     	b.ls	0x100031aa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
10002fc28:     	add	x27, x28, x0, lsl #5
10002fc2c:     	tbz	w26, #0x0, 0x10002fc6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x110>
10002fc30:     	ldr	x1, [x16, #0x80]
10002fc34:     	ldr	w0, [x27, #0x4]
10002fc38:     	cmp	x1, x0
10002fc3c:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fc40:     	mov	w9, #0xe0               ; =224
10002fc44:     	ldr	x8, [x16, #0x78]
10002fc48:     	umaddl	x25, w0, w9, x8
10002fc4c:     	ldr	w8, [x25]
10002fc50:     	cmp	w8, #0x5
10002fc54:     	ccmp	w8, #0xb, #0x4, ne
10002fc58:     	ldr	x8, [x21, #0x150]
10002fc5c:     	cset	w9, ne
10002fc60:     	subs	x8, x8, x9
10002fc64:     	b.lo	0x100031918 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dbc>
10002fc68:     	str	x8, [x21, #0x150]
10002fc6c:     	add	x20, x20, #0x1
10002fc70:     	tst	x20, #0x3f
10002fc74:     	b.ne	0x10002fcfc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002fc78:     	ldr	x8, [x21, #0x160]
10002fc7c:     	cbz	x8, 0x10002fc8c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x130>
10002fc80:     	cbz	x21, 0x10002fcd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
10002fc84:     	ldar	w8, [x8]
10002fc88:     	cbz	w8, 0x10002fce8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x18c>
10002fc8c:     	ldr	x8, [x21, #0x8]
10002fc90:     	cbz	x8, 0x100031b84 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
10002fc94:     	ldr	x9, [x8, #0x8]
10002fc98:     	ldr	x0, [x21, #0x10]
10002fc9c:     	ldrb	w9, [x9, #0x17]
10002fca0:     	and	w10, w9, #0x1f
10002fca4:     	and	w9, w9, #0x20
10002fca8:     	cmp	w10, #0x16
10002fcac:     	ccmp	w9, #0x0, #0x4, ne
10002fcb0:     	b.eq	0x10002fcbc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x160>
10002fcb4:     	stur	x0, [x29, #-0x78]
10002fcb8:     	sub	x0, x29, #0x78
10002fcbc:     	ldr	x8, [x8, #0x28]
10002fcc0:     	blr	x8
10002fcc4:     	ldr	x16, [sp, #0x28]
10002fcc8:     	mov	x2, x1
10002fccc:     	cbnz	x0, 0x10002fcf4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
10002fcd0:     	b	0x10002fcfc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002fcd4:     	mov	w0, #0x1                ; =1
10002fcd8:     	bl	0x100221638 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10002fcdc:     	ldr	x16, [sp, #0x28]
10002fce0:     	cbnz	x0, 0x10002fcf4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
10002fce4:     	b	0x10002fcfc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002fce8:     	mov	x0, xzr
10002fcec:     	mov	x2, xzr
10002fcf0:     	b	0x10002fcfc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002fcf4:     	ldr	x8, [x0, #0x8]
10002fcf8:     	cbnz	x8, 0x100031960 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
10002fcfc:     	ldr	w8, [x27, #0x1c]
10002fd00:     	cbz	w8, 0x10002fd7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fd04:     	tbz	w26, #0x0, 0x10002fd20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
10002fd08:     	ldr	w9, [x27]
10002fd0c:     	cmp	w9, #0x20
10002fd10:     	b.eq	0x10002fd7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fd14:     	cmp	w9, #0x41
10002fd18:     	b.eq	0x10002fd7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fd1c:     	b	0x10002fd80 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002fd20:     	ldr	w9, [x27]
10002fd24:     	cmp	w9, #0x20
10002fd28:     	b.eq	0x10002fd34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8>
10002fd2c:     	cmp	w9, #0x41
10002fd30:     	b.ne	0x10002fd80 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002fd34:     	mvn	w8, w20
10002fd38:     	tst	x8, #0x3f
10002fd3c:     	b.eq	0x10002fd7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fd40:     	cmp	w9, #0x41
10002fd44:     	b.ne	0x10002fd60 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x204>
10002fd48:     	ldr	w0, [x27, #0x8]
10002fd4c:     	cmp	x19, x0
10002fd50:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fd54:     	ldr	w8, [x27, #0x18]
10002fd58:     	add	x9, x23, x0, lsl #4
10002fd5c:     	stp	x8, xzr, [x9]
10002fd60:     	add	w24, w24, #0x1
10002fd64:     	cmp	x22, x24
10002fd68:     	b.ls	0x100031a84 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
10002fd6c:     	add	x27, x28, x24, lsl #5
10002fd70:     	add	x20, x20, #0x1
10002fd74:     	ldr	w8, [x27, #0x1c]
10002fd78:     	cbnz	w8, 0x10002fd20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
10002fd7c:     	ldr	w9, [x27]
10002fd80:     	mov	w10, #0xff20            ; =65312
10002fd84:     	sub	w8, w9, #0xe0
10002fd88:     	movk	w10, #0xff, lsl #16
10002fd8c:     	cmp	w8, w10
10002fd90:     	b.hs	0x10002fe20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c4>
10002fd94:     	lsr	w8, w9, #16
10002fd98:     	cmp	w8, #0xfb
10002fd9c:     	b.eq	0x10002ff70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x414>
10002fda0:     	cmp	w8, #0xfc
10002fda4:     	b.eq	0x10002fe78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x31c>
10002fda8:     	cmp	w8, #0xfd
10002fdac:     	b.ne	0x100030018 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4bc>
10002fdb0:     	ldr	w0, [x27, #0xc]
10002fdb4:     	cmn	w0, #0x1
10002fdb8:     	b.eq	0x1000301d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x67c>
10002fdbc:     	cmp	x19, x0
10002fdc0:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fdc4:     	add	x8, x23, x0, lsl #4
10002fdc8:     	ldp	x2, x8, [x8]
10002fdcc:     	ldr	w0, [x27, #0x10]
10002fdd0:     	cmn	w0, #0x1
10002fdd4:     	b.eq	0x1000301ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x690>
10002fdd8:     	cmp	x19, x0
10002fddc:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fde0:     	ldr	q0, [x23, x0, lsl #4]
10002fde4:     	str	q0, [sp, #0x60]
10002fde8:     	ldp	x5, x6, [sp, #0x60]
10002fdec:     	ldr	w0, [x27, #0x14]
10002fdf0:     	cmn	w0, #0x1
10002fdf4:     	b.eq	0x100030200 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6a4>
10002fdf8:     	cmp	x19, x0
10002fdfc:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fe00:     	ldr	q0, [x23, x0, lsl #4]
10002fe04:     	str	q0, [sp, #0x70]
10002fe08:     	ldp	x10, x11, [sp, #0x70]
10002fe0c:     	ldr	x1, [x16, #0x80]
10002fe10:     	ldr	w0, [x27, #0x4]
10002fe14:     	cmp	x1, x0
10002fe18:     	b.hi	0x100030218 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6bc>
10002fe1c:     	b	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fe20:     	sub	w8, w9, #0x45
10002fe24:     	cmp	w8, #0x80
10002fe28:     	b.hs	0x100030020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
10002fe2c:     	cmp	w8, #0x7f
10002fe30:     	b.hi	0x1000315a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a44>
10002fe34:     	adrp	x12, 0x100238000 <dyld_stub_binder+0x100238000>
10002fe38:     	add	x12, x12, #0x3d0
10002fe3c:     	adr	x10, 0x10002fe4c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
10002fe40:     	ldrh	w11, [x12, x8, lsl #1]
10002fe44:     	add	x10, x10, x11, lsl #2
10002fe48:     	br	x10
10002fe4c:     	ldr	w0, [x27, #0x10]
10002fe50:     	cmn	w0, #0x1
10002fe54:     	b.eq	0x1000305f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa98>
10002fe58:     	cmp	x19, x0
10002fe5c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fe60:     	lsl	x8, x0, #4
10002fe64:     	ldr	x2, [x23, x8]
10002fe68:     	ldr	w0, [x27, #0xc]
10002fe6c:     	cmp	x19, x0
10002fe70:     	b.hi	0x100030604 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
10002fe74:     	b	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fe78:     	mov	w8, #0xffed             ; =65517
10002fe7c:     	movk	w8, #0xff03, lsl #16
10002fe80:     	add	w13, w9, w8
10002fe84:     	cmp	w13, #0x4
10002fe88:     	b.hs	0x100030020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
10002fe8c:     	ldp	w8, w0, [x27, #0x18]
10002fe90:     	ldr	x2, [x16, #0xd8]
10002fe94:     	add	w10, w8, w0
10002fe98:     	add	w10, w10, #0x2
10002fe9c:     	cmp	x2, x10
10002fea0:     	b.lo	0x100031b30 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fd4>
10002fea4:     	cmp	w8, w10
10002fea8:     	b.hi	0x100031b1c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fc0>
10002feac:     	sub	x11, x2, x8
10002feb0:     	lsl	x12, x8, #2
10002feb4:     	cmp	x11, #0x0
10002feb8:     	csel	x11, x12, xzr, gt
10002febc:     	cmp	w10, w8
10002fec0:     	b.eq	0x100031b10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
10002fec4:     	ldr	x12, [x16, #0xc8]
10002fec8:     	add	x12, x12, x11
10002fecc:     	ldr	w11, [x12]
10002fed0:     	cmp	x19, x11
10002fed4:     	b.ls	0x100031af0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f94>
10002fed8:     	sub	x1, x10, x8
10002fedc:     	cmp	x1, #0x1
10002fee0:     	b.eq	0x100031b08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fac>
10002fee4:     	ldr	w8, [x12, #0x4]
10002fee8:     	cmp	x19, x8
10002feec:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002fef0:     	lsl	x10, x11, #4
10002fef4:     	lsl	x8, x8, #4
10002fef8:     	cmp	w13, #0x2
10002fefc:     	ldr	x15, [x23, x10]
10002ff00:     	ldr	x14, [x23, x8]
10002ff04:     	b.hs	0x100030310 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7b4>
10002ff08:     	cmp	x1, #0x3
10002ff0c:     	b.lo	0x100031b6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2010>
10002ff10:     	ldr	w8, [x12, #0x8]
10002ff14:     	cmp	x19, x8
10002ff18:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002ff1c:     	cmp	x1, #0x3
10002ff20:     	b.eq	0x100031b64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2008>
10002ff24:     	ldr	w10, [x12, #0xc]
10002ff28:     	cmp	x19, x10
10002ff2c:     	b.ls	0x100031ac0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
10002ff30:     	lsl	x8, x8, #4
10002ff34:     	lsl	x10, x10, #4
10002ff38:     	ldr	x11, [x23, x8]
10002ff3c:     	ldr	x8, [x23, x10]
10002ff40:     	mov	w10, #0x13              ; =19
10002ff44:     	movk	w10, #0xfc, lsl #16
10002ff48:     	cmp	w9, w10
10002ff4c:     	b.ne	0x1000304cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x970>
10002ff50:     	add	x10, x11, x15
10002ff54:     	orr	x9, x11, x15
10002ff58:     	and	x11, x11, x15
10002ff5c:     	bic	x9, x9, x10
10002ff60:     	add	x8, x8, x14
10002ff64:     	orr	x9, x9, x11
10002ff68:     	add	x11, x8, x9, lsr #63
10002ff6c:     	b	0x1000304e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
10002ff70:     	sub	w8, w9, #0x2
10002ff74:     	and	w9, w8, #0xffff
10002ff78:     	cmp	w9, #0x21
10002ff7c:     	mov	x9, #0x3e0f             ; =15887
10002ff80:     	movk	x9, #0x1c00, lsl #16
10002ff84:     	cset	w10, lo
10002ff88:     	movk	x9, #0x1, lsl #32
10002ff8c:     	lsr	x9, x9, x8
10002ff90:     	and	w9, w10, w9
10002ff94:     	tbz	w9, #0x0, 0x1000301b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x65c>
10002ff98:     	ldr	w0, [x27, #0xc]
10002ff9c:     	cmn	w0, #0x1
10002ffa0:     	b.eq	0x1000303bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x860>
10002ffa4:     	cmp	x19, x0
10002ffa8:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002ffac:     	ldr	q0, [x23, x0, lsl #4]
10002ffb0:     	str	q0, [sp, #0x30]
10002ffb4:     	ldp	x3, x4, [sp, #0x30]
10002ffb8:     	ldr	w0, [x27, #0x10]
10002ffbc:     	cmn	w0, #0x1
10002ffc0:     	b.eq	0x1000303d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
10002ffc4:     	cmp	x19, x0
10002ffc8:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002ffcc:     	ldr	q0, [x23, x0, lsl #4]
10002ffd0:     	str	q0, [sp, #0x40]
10002ffd4:     	ldp	x5, x6, [sp, #0x40]
10002ffd8:     	and	w8, w8, #0xffff
10002ffdc:     	cmp	w8, #0xc
10002ffe0:     	b.ne	0x1000303e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
10002ffe4:     	ldr	w8, [x27, #0x18]
10002ffe8:     	ldr	x1, [x16, #0xd0]
10002ffec:     	add	w0, w8, #0x2
10002fff0:     	cmp	x1, x0
10002fff4:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fff8:     	ldr	x8, [x16, #0xc8]
10002fffc:     	ldr	w0, [x8, x0, lsl #2]
100030000:     	cmp	x19, x0
100030004:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030008:     	ldr	q0, [x23, x0, lsl #4]
10003000c:     	str	q0, [sp, #0x50]
100030010:     	ldp	x7, x9, [sp, #0x50]
100030014:     	b	0x1000303ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x890>
100030018:     	cmp	w9, #0xe7
10003001c:     	b.lo	0x100031898 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
100030020:     	sub	w8, w9, #0x1
100030024:     	cmp	w8, #0xd3
100030028:     	b.hi	0x1000300e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x584>
10003002c:     	adrp	x12, 0x100238000 <dyld_stub_binder+0x100238000>
100030030:     	add	x12, x12, #0x4d0
100030034:     	mov	x0, xzr
100030038:     	adr	x10, 0x10003004c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f0>
10003003c:     	ldrh	w11, [x12, x8, lsl #1]
100030040:     	add	x10, x10, x11, lsl #2
100030044:     	mov	x1, xzr
100030048:     	br	x10
10003004c:     	ldr	x1, [x16, #0x80]
100030050:     	ldr	w0, [x27, #0x4]
100030054:     	cmp	x1, x0
100030058:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10003005c:     	mov	w10, #0xe0              ; =224
100030060:     	ldr	x8, [x16, #0x78]
100030064:     	umaddl	x10, w0, w10, x8
100030068:     	cbz	x10, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10003006c:     	ldr	x8, [sp, #0x20]
100030070:     	ldr	w0, [x10, #0x18]
100030074:     	ldr	x1, [x8, #0x78]
100030078:     	cmp	x1, x0
10003007c:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030080:     	ldr	x8, [x8, #0x70]
100030084:     	adds	x8, x8, x0, lsl #3
100030088:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10003008c:     	ldr	x11, [x8]
100030090:     	cbz	x11, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030094:     	ldr	w8, [x27, #0xc]
100030098:     	cmp	x19, x8
10003009c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000300a0:     	ldr	x0, [x11, #0x10]
1000300a4:     	lsl	x8, x8, #4
1000300a8:     	ldr	w11, [x10, #0x14]
1000300ac:     	ldr	w10, [x10, #0x1c]
1000300b0:     	ldr	x12, [x0, #0x40]
1000300b4:     	ldr	x2, [x23, x8]
1000300b8:     	orr	x3, x11, x10, lsl #32
1000300bc:     	cbz	x12, 0x1000300c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x56c>
1000300c0:     	ldr	x8, [x0, #0x60]
1000300c4:     	cbz	x8, 0x100030468 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x90c>
1000300c8:     	sub	x8, x29, #0x78
1000300cc:     	mov	w1, w9
1000300d0:     	mov	w4, wzr
1000300d4:     	mov	x5, xzr
1000300d8:     	mov	x6, xzr
1000300dc:     	b	0x1000302a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x744>
1000300e0:     	sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
1000300e4:     	cmp	w8, #0x8
1000300e8:     	b.hs	0x1000302ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x750>
1000300ec:     	ldr	w0, [x27, #0xc]
1000300f0:     	cmp	x19, x0
1000300f4:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000300f8:     	lsl	x8, x0, #4
1000300fc:     	mov	w0, w9
100030100:     	mov	x2, xzr
100030104:     	ldr	x1, [x23, x8]
100030108:     	bl	0x100055fdc <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10003010c:     	mov	x25, x1
100030110:     	mov	x1, xzr
100030114:     	b	0x1000304a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
100030118:     	ldr	x1, [x16, #0x80]
10003011c:     	ldr	w0, [x27, #0x4]
100030120:     	cmp	x1, x0
100030124:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030128:     	mov	w10, #0xe0              ; =224
10003012c:     	ldr	x8, [x16, #0x78]
100030130:     	umaddl	x11, w0, w10, x8
100030134:     	cbz	x11, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030138:     	ldr	x8, [sp, #0x20]
10003013c:     	ldr	w0, [x11, #0x18]
100030140:     	ldr	x1, [x8, #0x78]
100030144:     	cmp	x1, x0
100030148:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10003014c:     	ldr	x8, [x8, #0x70]
100030150:     	adds	x8, x8, x0, lsl #3
100030154:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030158:     	ldr	x12, [x8]
10003015c:     	cbz	x12, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030160:     	ldr	w8, [x27, #0xc]
100030164:     	cmp	x19, x8
100030168:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003016c:     	ldr	w10, [x27, #0x10]
100030170:     	cmp	x19, x10
100030174:     	b.ls	0x100031ac0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
100030178:     	ldr	x0, [x12, #0x10]
10003017c:     	ldr	w12, [x11, #0x14]
100030180:     	lsl	x8, x8, #4
100030184:     	ldr	w11, [x11, #0x1c]
100030188:     	lsl	x10, x10, #4
10003018c:     	ldr	x13, [x0, #0x40]
100030190:     	ldr	x2, [x23, x8]
100030194:     	orr	x3, x12, x11, lsl #32
100030198:     	ldr	x5, [x23, x10]
10003019c:     	cbz	x13, 0x1000301a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x64c>
1000301a0:     	ldr	x8, [x0, #0x60]
1000301a4:     	cbz	x8, 0x100030598 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa3c>
1000301a8:     	mov	w1, w9
1000301ac:     	mov	w4, wzr
1000301b0:     	mov	x6, xzr
1000301b4:     	b	0x1000303a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x848>
1000301b8:     	ldr	x8, [sp, #0x18]
1000301bc:     	mov	x0, x21
1000301c0:     	stur	w24, [x8, #-0x38]
1000301c4:     	bl	0x100031dc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
1000301c8:     	ldr	x16, [sp, #0x28]
1000301cc:     	tst	w0, #0xff
1000301d0:     	b.eq	0x100030454 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
1000301d4:     	b	0x10003196c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
1000301d8:     	mov	x8, xzr
1000301dc:     	mov	x2, xzr
1000301e0:     	ldr	w0, [x27, #0x10]
1000301e4:     	cmn	w0, #0x1
1000301e8:     	b.ne	0x10002fdd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x27c>
1000301ec:     	mov	x5, xzr
1000301f0:     	mov	x6, xzr
1000301f4:     	ldr	w0, [x27, #0x14]
1000301f8:     	cmn	w0, #0x1
1000301fc:     	b.ne	0x10002fdf8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x29c>
100030200:     	mov	x10, xzr
100030204:     	mov	x11, xzr
100030208:     	ldr	x1, [x16, #0x80]
10003020c:     	ldr	w0, [x27, #0x4]
100030210:     	cmp	x1, x0
100030214:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030218:     	mov	w13, #0xe0              ; =224
10003021c:     	ldr	x12, [x16, #0x78]
100030220:     	umaddl	x0, w0, w13, x12
100030224:     	cbz	x0, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030228:     	and	w12, w9, #0xfffc
10003022c:     	and	w13, w9, #0xffff
100030230:     	cmp	w12, #0x54
100030234:     	ccmp	w13, #0xb, #0x0, ne
100030238:     	b.lo	0x100030248 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6ec>
10003023c:     	sub	w14, w13, #0x5c
100030240:     	cmp	w14, #0x2
100030244:     	b.hs	0x100030340 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7e4>
100030248:     	ldr	x10, [sp, #0x20]
10003024c:     	ldr	w8, [x0, #0x18]
100030250:     	ldr	x1, [x10, #0x78]
100030254:     	cmp	x1, x8
100030258:     	b.ls	0x100031ab8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10003025c:     	ldr	x10, [x10, #0x70]
100030260:     	adds	x8, x10, x8, lsl #3
100030264:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030268:     	ldr	x8, [x8]
10003026c:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030270:     	ldr	x10, [x8, #0x10]
100030274:     	ldr	w8, [x0, #0x14]
100030278:     	ldr	w11, [x0, #0x1c]
10003027c:     	ldrb	w4, [x0, #0x40]
100030280:     	ldr	x12, [x10, #0x40]
100030284:     	orr	x3, x8, x11, lsl #32
100030288:     	cbz	x12, 0x100030294 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x738>
10003028c:     	ldr	x8, [x10, #0x60]
100030290:     	cbz	x8, 0x100030480 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x924>
100030294:     	sub	x8, x29, #0x78
100030298:     	mov	x0, x10
10003029c:     	mov	w1, w9
1000302a0:     	sub	x26, x29, #0x78
1000302a4:     	bl	0x10004e074 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
1000302a8:     	b	0x100030494 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x938>
1000302ac:     	mov	w8, #-0x1000001         ; =-16777217
1000302b0:     	add	w8, w9, w8
1000302b4:     	cmp	w8, #0x8
1000302b8:     	b.hi	0x100030a70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
1000302bc:     	mov	w10, #0x117             ; =279
1000302c0:     	lsr	w10, w10, w8
1000302c4:     	tbz	w10, #0x0, 0x100030a60 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf04>
1000302c8:     	and	w9, w9, #0xff
1000302cc:     	mov	w8, wzr
1000302d0:     	cmp	w9, #0x4
1000302d4:     	b.gt	0x1000305a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
1000302d8:     	cmp	w9, #0x2
1000302dc:     	b.eq	0x10003062c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xad0>
1000302e0:     	cmp	w9, #0x3
1000302e4:     	b.ne	0x1000309c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
1000302e8:     	ldr	w0, [x27, #0xc]
1000302ec:     	cmp	x19, x0
1000302f0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000302f4:     	lsl	x8, x0, #4
1000302f8:     	ldr	w9, [x27, #0x1c]
1000302fc:     	ldr	w8, [x23, x8]
100030300:     	sub	w9, w9, #0x1
100030304:     	cmp	w9, w8
100030308:     	csel	w8, w9, w8, lo
10003030c:     	b	0x1000309c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
100030310:     	umulh	x11, x14, x15
100030314:     	mov	w8, #0x13               ; =19
100030318:     	movk	w8, #0xfc, lsl #16
10003031c:     	mul	x10, x14, x15
100030320:     	add	w8, w8, #0x2
100030324:     	cmp	w9, w8
100030328:     	b.ne	0x1000304e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
10003032c:     	and	x8, x14, x15, asr #63
100030330:     	and	x9, x15, x14, asr #63
100030334:     	add	x8, x9, x8
100030338:     	sub	x11, x11, x8
10003033c:     	b	0x1000304e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
100030340:     	cmp	w13, #0xb
100030344:     	ldr	x13, [sp, #0x20]
100030348:     	b.eq	0x100030354 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f8>
10003034c:     	cmp	w12, #0x58
100030350:     	b.ne	0x1000306e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb88>
100030354:     	ldr	x1, [x13, #0x78]
100030358:     	ldr	w8, [x0, #0x18]
10003035c:     	cmp	x1, x8
100030360:     	b.ls	0x100031ab8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
100030364:     	ldr	x10, [x13, #0x70]
100030368:     	adds	x8, x10, x8, lsl #3
10003036c:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030370:     	ldr	x8, [x8]
100030374:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030378:     	ldr	x8, [x8, #0x10]
10003037c:     	ldr	w10, [x0, #0x14]
100030380:     	ldr	w11, [x0, #0x1c]
100030384:     	ldrb	w4, [x0, #0x40]
100030388:     	ldr	x12, [x8, #0x40]
10003038c:     	orr	x3, x10, x11, lsl #32
100030390:     	cbz	x12, 0x10003039c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x840>
100030394:     	ldr	x10, [x8, #0x60]
100030398:     	cbz	x10, 0x10003099c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
10003039c:     	mov	x0, x8
1000303a0:     	mov	w1, w9
1000303a4:     	bl	0x10004ba2c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
1000303a8:     	mov	w8, w0
1000303ac:     	mov	x0, xzr
1000303b0:     	mov	x1, xzr
1000303b4:     	and	w25, w8, #0xff
1000303b8:     	b	0x1000304a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
1000303bc:     	mov	x3, xzr
1000303c0:     	mov	x4, xzr
1000303c4:     	ldr	w0, [x27, #0x10]
1000303c8:     	cmn	w0, #0x1
1000303cc:     	b.ne	0x10002ffc4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x468>
1000303d0:     	mov	x5, xzr
1000303d4:     	mov	x6, xzr
1000303d8:     	and	w8, w8, #0xffff
1000303dc:     	cmp	w8, #0xc
1000303e0:     	b.eq	0x10002ffe4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x488>
1000303e4:     	mov	x7, xzr
1000303e8:     	mov	x9, xzr
1000303ec:     	cbz	x21, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000303f0:     	ldr	x1, [x16, #0x80]
1000303f4:     	ldr	w0, [x27, #0x4]
1000303f8:     	cmp	x1, x0
1000303fc:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030400:     	mov	w10, #0xe0              ; =224
100030404:     	ldr	x8, [x16, #0x78]
100030408:     	umaddl	x2, w0, w10, x8
10003040c:     	cbz	x2, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030410:     	ldr	x0, [x21]
100030414:     	ldr	x1, [sp, #0x20]
100030418:     	add	x8, sp, #0x80
10003041c:     	str	x9, [sp]
100030420:     	bl	0x10003bea8 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
100030424:     	ldr	x25, [sp, #0x90]
100030428:     	ldr	q0, [sp, #0x80]
10003042c:     	cbz	x25, 0x100030438 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8dc>
100030430:     	ldr	x8, [x25, #0x8]
100030434:     	cbnz	x8, 0x100031974 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
100030438:     	ldr	w0, [x27, #0x8]
10003043c:     	ldr	x16, [sp, #0x28]
100030440:     	cmn	w0, #0x1
100030444:     	b.eq	0x100030454 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
100030448:     	cmp	x19, x0
10003044c:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030450:     	str	q0, [x23, x0, lsl #4]
100030454:     	add	w27, w24, #0x1
100030458:     	b	0x100030528 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9cc>
10003045c:     	ldr	x0, [x27, #0x18]
100030460:     	mov	x1, xzr
100030464:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030468:     	sub	x8, x29, #0x78
10003046c:     	mov	w1, w9
100030470:     	mov	w4, wzr
100030474:     	mov	x5, xzr
100030478:     	mov	x6, xzr
10003047c:     	b	0x10003048c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x930>
100030480:     	sub	x8, x29, #0x78
100030484:     	mov	x0, x10
100030488:     	mov	w1, w9
10003048c:     	sub	x26, x29, #0x78
100030490:     	bl	0x10004e19c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
100030494:     	ldp	x0, x1, [x26]
100030498:     	ldrb	w25, [x26, #0x10]
10003049c:     	ldr	w26, [sp, #0x14]
1000304a0:     	ldr	x16, [sp, #0x28]
1000304a4:     	tst	w25, #0xff
1000304a8:     	b.ne	0x1000319dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
1000304ac:     	ldr	w8, [x27, #0x8]
1000304b0:     	cmn	w8, #0x1
1000304b4:     	b.eq	0x10002fc14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
1000304b8:     	cmp	x19, x8
1000304bc:     	b.ls	0x100031a98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
1000304c0:     	add	x8, x23, x8, lsl #4
1000304c4:     	stp	x0, x1, [x8]
1000304c8:     	b	0x10002fc14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
1000304cc:     	sub	x10, x15, x11
1000304d0:     	eon	x9, x15, x11
1000304d4:     	bic	x11, x11, x15
1000304d8:     	and	x9, x10, x9
1000304dc:     	orr	x9, x9, x11
1000304e0:     	add	x8, x8, x9, lsr #63
1000304e4:     	sub	x11, x14, x8
1000304e8:     	cmp	x1, x0
1000304ec:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000304f0:     	add	w8, w0, #0x1
1000304f4:     	cmp	x1, x8
1000304f8:     	b.ls	0x100031ab8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
1000304fc:     	ldr	w9, [x12, x0, lsl #2]
100030500:     	cmp	x19, x9
100030504:     	b.ls	0x100031afc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
100030508:     	ldr	w0, [x12, x8, lsl #2]
10003050c:     	add	x8, x23, x9, lsl #4
100030510:     	cmp	x19, x0
100030514:     	stp	x10, xzr, [x8]
100030518:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003051c:     	add	x8, x23, x0, lsl #4
100030520:     	add	w27, w24, #0x1
100030524:     	stp	x11, xzr, [x8]
100030528:     	ldr	x8, [sp, #0x18]
10003052c:     	stur	w27, [x8, #-0x38]
100030530:     	b	0x10002fc18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
100030534:     	ldr	w0, [x27, #0xc]
100030538:     	cmp	x19, x0
10003053c:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030540:     	ldr	w8, [x27, #0x18]
100030544:     	cmp	x19, x8
100030548:     	b.ls	0x100031a98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
10003054c:     	add	x9, x23, x0, lsl #4
100030550:     	ldr	q0, [x9]
100030554:     	ldr	x1, [x9, #0x8]
100030558:     	str	q0, [x23, x8, lsl #4]
10003055c:     	fmov	x0, d0
100030560:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030564:     	ldr	w0, [x27, #0x14]
100030568:     	cmp	x19, x0
10003056c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030570:     	lsl	x8, x0, #4
100030574:     	mov	w9, #0x10               ; =16
100030578:     	ldr	w8, [x23, x8]
10003057c:     	cmp	w8, #0x0
100030580:     	mov	w8, #0xc                ; =12
100030584:     	csel	x8, x9, x8, eq
100030588:     	ldr	w0, [x27, x8]
10003058c:     	cmp	x19, x0
100030590:     	b.hi	0x100030938 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xddc>
100030594:     	b	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030598:     	mov	w1, w9
10003059c:     	mov	w4, wzr
1000305a0:     	mov	x6, xzr
1000305a4:     	b	0x1000309a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe48>
1000305a8:     	cmp	w9, #0x9
1000305ac:     	b.ne	0x1000309b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
1000305b0:     	ldr	w0, [x27, #0xc]
1000305b4:     	cmp	x19, x0
1000305b8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000305bc:     	lsl	x8, x0, #4
1000305c0:     	ldr	x8, [x23, x8]
1000305c4:     	cmp	x8, #0x0
1000305c8:     	cset	w8, ne
1000305cc:     	b	0x1000309c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
1000305d0:     	ldr	w0, [x27, #0xc]
1000305d4:     	cmp	x19, x0
1000305d8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000305dc:     	lsl	x8, x0, #4
1000305e0:     	mov	x1, xzr
1000305e4:     	ldr	x8, [x23, x8]
1000305e8:     	cmp	x8, #0x0
1000305ec:     	cset	w0, eq
1000305f0:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000305f4:     	mov	x2, xzr
1000305f8:     	ldr	w0, [x27, #0xc]
1000305fc:     	cmp	x19, x0
100030600:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030604:     	lsl	x8, x0, #4
100030608:     	mov	w0, w9
10003060c:     	ldr	x1, [x23, x8]
100030610:     	bl	0x100055fdc <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
100030614:     	mov	x25, x1
100030618:     	ldr	x16, [sp, #0x28]
10003061c:     	tst	w25, #0xff
100030620:     	b.ne	0x1000319dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
100030624:     	mov	x1, xzr
100030628:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003062c:     	ldr	w0, [x27, #0xc]
100030630:     	cmp	x19, x0
100030634:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030638:     	lsl	x8, x0, #4
10003063c:     	ldr	w8, [x23, x8]
100030640:     	cmp	w8, #0x0
100030644:     	cset	w8, eq
100030648:     	b	0x1000309c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
10003064c:     	ldr	w0, [x27, #0xc]
100030650:     	cmp	x19, x0
100030654:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030658:     	lsl	x8, x0, #4
10003065c:     	cmp	w9, #0x69
100030660:     	mov	x1, xzr
100030664:     	ldr	x8, [x23, x8]
100030668:     	mov	w9, w8
10003066c:     	csel	x8, x9, x8, eq
100030670:     	lsr	x9, x8, #1
100030674:     	and	x8, x8, #0x5555555555555555
100030678:     	and	x9, x9, #0x5555555555555555
10003067c:     	add	x8, x9, x8
100030680:     	lsr	x9, x8, #2
100030684:     	and	x8, x8, #0x3333333333333333
100030688:     	and	x9, x9, #0x3333333333333333
10003068c:     	add	x8, x9, x8
100030690:     	add	x8, x8, x8, lsr #4
100030694:     	and	x8, x8, #0xf0f0f0f0f0f0f0f
100030698:     	add	x8, x8, x8, lsr #8
10003069c:     	add	x8, x8, x8, lsr #16
1000306a0:     	add	x8, x8, x8, lsr #32
1000306a4:     	and	x0, x8, #0x7f
1000306a8:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000306ac:     	ldr	w0, [x27, #0xc]
1000306b0:     	cmp	x19, x0
1000306b4:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000306b8:     	lsl	x8, x0, #4
1000306bc:     	mov	x1, xzr
1000306c0:     	ldrsw	x0, [x23, x8]
1000306c4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000306c8:     	ldr	w0, [x27, #0xc]
1000306cc:     	cmp	x19, x0
1000306d0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000306d4:     	lsl	x8, x0, #4
1000306d8:     	mov	x1, xzr
1000306dc:     	ldr	w0, [x23, x8]
1000306e0:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000306e4:     	mov	x1, x2
1000306e8:     	mov	x2, x8
1000306ec:     	mov	x3, x5
1000306f0:     	mov	x4, x6
1000306f4:     	mov	x5, x10
1000306f8:     	mov	x6, x11
1000306fc:     	bl	0x1000544b8 <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100030700:     	ldr	x16, [sp, #0x28]
100030704:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030708:     	ldr	w0, [x27, #0xc]
10003070c:     	cmp	x19, x0
100030710:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030714:     	ldr	w8, [x27, #0x10]
100030718:     	cmp	x19, x8
10003071c:     	b.hi	0x100031358 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x17fc>
100030720:     	b	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030724:     	ldr	x8, [sp, #0x20]
100030728:     	ldr	w0, [x27, #0x18]
10003072c:     	ldr	x1, [x8, #0x78]
100030730:     	cmp	x1, x0
100030734:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030738:     	ldr	x8, [x8, #0x70]
10003073c:     	adds	x8, x8, x0, lsl #3
100030740:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030744:     	cbz	x21, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030748:     	ldr	x25, [x8]
10003074c:     	cbz	x25, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030750:     	ldr	x9, [x25, #0x10]
100030754:     	ldr	w8, [x27, #0xc]
100030758:     	ldr	x0, [x21]
10003075c:     	ldrb	w9, [x9, #0x31]
100030760:     	cmp	x19, x8
100030764:     	strb	w9, [sp, #0xae]
100030768:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003076c:     	lsl	x8, x8, #4
100030770:     	ldrb	w9, [sp, #0xae]
100030774:     	mov	x1, x25
100030778:     	ldr	x8, [x23, x8]
10003077c:     	cmp	w9, #0x0
100030780:     	mov	w10, w8
100030784:     	csel	x2, x8, x10, ne
100030788:     	bl	0x1000486dc <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
10003078c:     	tbz	w1, #0x0, 0x100031700 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ba4>
100030790:     	ldr	x16, [sp, #0x28]
100030794:     	mov	x1, xzr
100030798:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003079c:     	ldr	x8, [sp, #0x20]
1000307a0:     	ldr	w0, [x27, #0x18]
1000307a4:     	ldr	x1, [x8, #0x60]
1000307a8:     	cmp	x1, x0
1000307ac:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000307b0:     	ldr	x8, [x8, #0x58]
1000307b4:     	adds	x8, x8, x0, lsl #3
1000307b8:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000307bc:     	ldr	x8, [x8]
1000307c0:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000307c4:     	ldr	w0, [x27, #0xc]
1000307c8:     	cmp	x19, x0
1000307cc:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000307d0:     	lsl	x9, x0, #4
1000307d4:     	ldrb	w10, [x8, #0x29]
1000307d8:     	ldr	x9, [x23, x9]
1000307dc:     	cmp	w10, #0x0
1000307e0:     	ldr	x10, [x8, #0x40]
1000307e4:     	mov	w11, w9
1000307e8:     	csel	x9, x9, x11, ne
1000307ec:     	cmp	x9, x10
1000307f0:     	b.hs	0x1000319c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
1000307f4:     	ldr	x8, [x8, #0x38]
1000307f8:     	mov	x1, xzr
1000307fc:     	ldr	x0, [x8, x9, lsl #3]
100030800:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030804:     	ldr	x8, [sp, #0x20]
100030808:     	ldr	w0, [x27, #0x18]
10003080c:     	ldr	x1, [x8, #0x48]
100030810:     	cmp	x1, x0
100030814:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030818:     	ldr	x8, [x8, #0x40]
10003081c:     	mov	x1, xzr
100030820:     	ldr	x0, [x8, x0, lsl #3]
100030824:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030828:     	ldr	w0, [x27, #0xc]
10003082c:     	cmp	x19, x0
100030830:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030834:     	add	x8, x23, x0, lsl #4
100030838:     	ldr	x0, [x8]
10003083c:     	cbz	x0, 0x1000319d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e7c>
100030840:     	ldr	x1, [x8, #0x8]
100030844:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030848:     	ldr	x8, [sp, #0x20]
10003084c:     	ldr	x1, [x8, #0x90]
100030850:     	ldr	w8, [x27, #0x18]
100030854:     	cmp	x1, x8
100030858:     	b.ls	0x100031ab8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10003085c:     	ldr	w9, [x27, #0xc]
100030860:     	cmp	x19, x9
100030864:     	b.ls	0x100031b78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x201c>
100030868:     	ldr	x10, [sp, #0x20]
10003086c:     	ldr	q0, [x23, x9, lsl #4]
100030870:     	mov	x0, xzr
100030874:     	mov	x1, xzr
100030878:     	ldr	x10, [x10, #0x88]
10003087c:     	ldr	x8, [x10, x8, lsl #3]
100030880:     	str	q0, [x8, #0x20]
100030884:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030888:     	ldr	x8, [sp, #0x20]
10003088c:     	ldr	w0, [x27, #0x18]
100030890:     	ldr	x1, [x8, #0x90]
100030894:     	cmp	x1, x0
100030898:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10003089c:     	ldr	x8, [x8, #0x88]
1000308a0:     	ldr	x8, [x8, x0, lsl #3]
1000308a4:     	ldp	x0, x1, [x8, #0x20]
1000308a8:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000308ac:     	ldr	x8, [sp, #0x20]
1000308b0:     	ldr	w0, [x27, #0x18]
1000308b4:     	ldr	x1, [x8, #0x60]
1000308b8:     	cmp	x1, x0
1000308bc:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000308c0:     	ldr	x8, [x8, #0x58]
1000308c4:     	adds	x8, x8, x0, lsl #3
1000308c8:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000308cc:     	ldr	x9, [x8]
1000308d0:     	cbz	x9, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000308d4:     	ldr	w0, [x27, #0xc]
1000308d8:     	cmp	x19, x0
1000308dc:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000308e0:     	lsl	x8, x0, #4
1000308e4:     	ldrb	w10, [x9, #0x29]
1000308e8:     	ldr	x12, [x9, #0x40]
1000308ec:     	ldr	x8, [x23, x8]
1000308f0:     	cmp	w10, #0x0
1000308f4:     	mov	w11, w8
1000308f8:     	csel	x10, x8, x11, ne
1000308fc:     	cmp	x10, x12
100030900:     	b.hs	0x1000319c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
100030904:     	ldr	w8, [x27, #0x10]
100030908:     	cmp	x19, x8
10003090c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030910:     	lsl	x8, x8, #4
100030914:     	ldr	x9, [x9, #0x38]
100030918:     	mov	x0, xzr
10003091c:     	mov	x1, xzr
100030920:     	ldr	x8, [x23, x8]
100030924:     	str	x8, [x9, x10, lsl #3]
100030928:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003092c:     	ldr	w0, [x27, #0x18]
100030930:     	cmp	x19, x0
100030934:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030938:     	add	x8, x23, x0, lsl #4
10003093c:     	ldp	x0, x1, [x8]
100030940:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030944:     	ldr	x8, [sp, #0x20]
100030948:     	ldr	w0, [x27, #0x18]
10003094c:     	ldr	x1, [x8, #0x78]
100030950:     	cmp	x1, x0
100030954:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030958:     	ldr	x8, [x8, #0x70]
10003095c:     	adds	x8, x8, x0, lsl #3
100030960:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030964:     	ldr	x8, [x8]
100030968:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10003096c:     	ldr	x0, [x8, #0x10]
100030970:     	ldr	x9, [x0, #0x40]
100030974:     	ldr	x8, [x0, #0x60]
100030978:     	cbz	x9, 0x100031724 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
10003097c:     	cbnz	x8, 0x100031728 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bcc>
100030980:     	bl	0x10004b2cc <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).pagesLocked>
100030984:     	ldr	x16, [sp, #0x28]
100030988:     	mov	x1, xzr
10003098c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030990:     	ldr	w0, [x27, #0x18]
100030994:     	mov	x1, xzr
100030998:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003099c:     	mov	x0, x8
1000309a0:     	mov	w1, w9
1000309a4:     	bl	0x10004bc74 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
1000309a8:     	mov	w25, w0
1000309ac:     	mov	x0, xzr
1000309b0:     	mov	x1, xzr
1000309b4:     	b	0x1000304a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
1000309b8:     	cmp	w9, #0x5
1000309bc:     	b.eq	0x1000319d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e74>
1000309c0:     	ldr	w9, [x27, #0x18]
1000309c4:     	ldr	x1, [x16, #0xe8]
1000309c8:     	add	w0, w9, w8
1000309cc:     	cmp	x1, x0
1000309d0:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000309d4:     	ldr	x8, [x16, #0xe0]
1000309d8:     	mov	w9, #0xc                ; =12
1000309dc:     	umaddl	x8, w0, w9, x8
1000309e0:     	ldp	w27, w25, [x8]
1000309e4:     	ldr	w26, [x8, #0x8]
1000309e8:     	cmp	w27, w24
1000309ec:     	b.hi	0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
1000309f0:     	ldr	x8, [x21, #0x160]
1000309f4:     	cbz	x8, 0x100030a04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea8>
1000309f8:     	cbz	x21, 0x100030a4c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xef0>
1000309fc:     	ldar	w8, [x8]
100030a00:     	cbz	w8, 0x10003174c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bf0>
100030a04:     	ldr	x8, [x21, #0x8]
100030a08:     	cbz	x8, 0x100031b84 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
100030a0c:     	ldr	x9, [x8, #0x8]
100030a10:     	ldr	x0, [x21, #0x10]
100030a14:     	ldrb	w9, [x9, #0x17]
100030a18:     	and	w10, w9, #0x1f
100030a1c:     	and	w9, w9, #0x20
100030a20:     	cmp	w10, #0x16
100030a24:     	ccmp	w9, #0x0, #0x4, ne
100030a28:     	b.eq	0x100030a34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xed8>
100030a2c:     	stur	x0, [x29, #-0x78]
100030a30:     	sub	x0, x29, #0x78
100030a34:     	ldr	x8, [x8, #0x28]
100030a38:     	blr	x8
100030a3c:     	ldr	x16, [sp, #0x28]
100030a40:     	mov	x2, x1
100030a44:     	cbnz	x0, 0x100031758 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
100030a48:     	b	0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100030a4c:     	mov	w0, #0x1                ; =1
100030a50:     	bl	0x100221638 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100030a54:     	ldr	x16, [sp, #0x28]
100030a58:     	cbnz	x0, 0x100031758 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
100030a5c:     	b	0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100030a60:     	cmp	w8, #0x3
100030a64:     	b.eq	0x1000318e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8c>
100030a68:     	cmp	w8, #0x6
100030a6c:     	b.eq	0x100031898 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
100030a70:     	sub	w8, w9, #0x12
100030a74:     	cmp	w8, #0x4
100030a78:     	b.lo	0x1000318c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d64>
100030a7c:     	ldr	w0, [x27, #0xc]
100030a80:     	cmn	w0, #0x1
100030a84:     	b.eq	0x1000315e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a8c>
100030a88:     	cmp	x19, x0
100030a8c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030a90:     	lsl	x8, x0, #4
100030a94:     	ldr	x5, [x23, x8]
100030a98:     	ldr	w0, [x27, #0x10]
100030a9c:     	cmn	w0, #0x1
100030aa0:     	b.eq	0x1000315f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a9c>
100030aa4:     	cmp	x19, x0
100030aa8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030aac:     	lsl	x8, x0, #4
100030ab0:     	ldr	x7, [x23, x8]
100030ab4:     	ldr	w0, [x27, #0x14]
100030ab8:     	cmn	w0, #0x1
100030abc:     	b.eq	0x100031608 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aac>
100030ac0:     	cmp	x19, x0
100030ac4:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030ac8:     	lsl	x8, x0, #4
100030acc:     	ldr	x10, [x23, x8]
100030ad0:     	and	w8, w9, #0xffff0000
100030ad4:     	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100030ad8:     	b.ne	0x100031618 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1abc>
100030adc:     	and	w4, w9, #0xffff
100030ae0:     	cmp	w4, #0x3
100030ae4:     	b.ne	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c7c>
100030ae8:     	cbz	x21, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030aec:     	ldr	x8, [x21]
100030af0:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030af4:     	ldr	x0, [x8, #0x8]
100030af8:     	bl	0x10004a8e0 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
100030afc:     	ldr	x16, [sp, #0x28]
100030b00:     	mov	x0, xzr
100030b04:     	mov	x1, xzr
100030b08:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030b0c:     	ldr	w0, [x27, #0xc]
100030b10:     	cmp	x19, x0
100030b14:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030b18:     	ldr	w8, [x27, #0x10]
100030b1c:     	cmp	x19, x8
100030b20:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030b24:     	lsl	x9, x0, #4
100030b28:     	lsl	x8, x8, #4
100030b2c:     	mov	x1, xzr
100030b30:     	ldr	x9, [x23, x9]
100030b34:     	ldr	x8, [x23, x8]
100030b38:     	eor	x0, x8, x9
100030b3c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030b40:     	ldr	w0, [x27, #0xc]
100030b44:     	cmp	x19, x0
100030b48:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030b4c:     	ldr	w8, [x27, #0x10]
100030b50:     	cmp	x19, x8
100030b54:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030b58:     	lsl	x9, x0, #4
100030b5c:     	lsl	x8, x8, #4
100030b60:     	mov	x1, xzr
100030b64:     	ldr	x9, [x23, x9]
100030b68:     	ldr	x8, [x23, x8]
100030b6c:     	lsr	x0, x9, x8
100030b70:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030b74:     	ldr	w0, [x27, #0xc]
100030b78:     	cmp	x19, x0
100030b7c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030b80:     	ldr	w8, [x27, #0x10]
100030b84:     	cmp	x19, x8
100030b88:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030b8c:     	lsl	x9, x0, #4
100030b90:     	lsl	x8, x8, #4
100030b94:     	mov	x1, xzr
100030b98:     	ldr	w9, [x23, x9]
100030b9c:     	ldr	w8, [x23, x8]
100030ba0:     	asr	w0, w9, w8
100030ba4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ba8:     	ldr	w0, [x27, #0xc]
100030bac:     	cmp	x19, x0
100030bb0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030bb4:     	ldr	w8, [x27, #0x10]
100030bb8:     	cmp	x19, x8
100030bbc:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030bc0:     	lsl	x9, x0, #4
100030bc4:     	lsl	x8, x8, #4
100030bc8:     	mov	x1, xzr
100030bcc:     	ldr	x9, [x23, x9]
100030bd0:     	ldr	x8, [x23, x8]
100030bd4:     	orr	x0, x8, x9
100030bd8:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030bdc:     	ldr	w0, [x27, #0xc]
100030be0:     	cmp	x19, x0
100030be4:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030be8:     	ldr	w8, [x27, #0x10]
100030bec:     	cmp	x19, x8
100030bf0:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030bf4:     	lsl	x9, x0, #4
100030bf8:     	lsl	x8, x8, #4
100030bfc:     	mov	x1, xzr
100030c00:     	ldr	w9, [x23, x9]
100030c04:     	ldr	w8, [x23, x8]
100030c08:     	lsl	w0, w9, w8
100030c0c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030c10:     	ldr	w0, [x27, #0xc]
100030c14:     	cmp	x19, x0
100030c18:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030c1c:     	ldr	w8, [x27, #0x10]
100030c20:     	cmp	x19, x8
100030c24:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030c28:     	lsl	x9, x0, #4
100030c2c:     	lsl	x8, x8, #4
100030c30:     	mov	x1, xzr
100030c34:     	ldr	w9, [x23, x9]
100030c38:     	ldr	w8, [x23, x8]
100030c3c:     	orr	w0, w8, w9
100030c40:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030c44:     	ldr	w0, [x27, #0xc]
100030c48:     	cmp	x19, x0
100030c4c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030c50:     	lsl	x8, x0, #4
100030c54:     	mov	x1, xzr
100030c58:     	ldr	x8, [x23, x8]
100030c5c:     	rbit	x8, x8
100030c60:     	clz	x0, x8
100030c64:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030c68:     	ldr	w0, [x27, #0xc]
100030c6c:     	cmp	x19, x0
100030c70:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030c74:     	ldr	w8, [x27, #0x10]
100030c78:     	cmp	x19, x8
100030c7c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030c80:     	lsl	x9, x0, #4
100030c84:     	lsl	x8, x8, #4
100030c88:     	mov	x1, xzr
100030c8c:     	ldr	x9, [x23, x9]
100030c90:     	ldr	x8, [x23, x8]
100030c94:     	cmp	x9, x8
100030c98:     	cset	w0, lo
100030c9c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ca0:     	ldr	w0, [x27, #0xc]
100030ca4:     	cmp	x19, x0
100030ca8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030cac:     	ldr	w8, [x27, #0x10]
100030cb0:     	cmp	x19, x8
100030cb4:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030cb8:     	lsl	x9, x0, #4
100030cbc:     	lsl	x8, x8, #4
100030cc0:     	mov	x1, xzr
100030cc4:     	ldr	x9, [x23, x9]
100030cc8:     	ldr	x8, [x23, x8]
100030ccc:     	cmp	x9, x8
100030cd0:     	cset	w0, ls
100030cd4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030cd8:     	ldr	w0, [x27, #0xc]
100030cdc:     	cmp	x19, x0
100030ce0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030ce4:     	ldr	w8, [x27, #0x10]
100030ce8:     	cmp	x19, x8
100030cec:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030cf0:     	lsl	x9, x0, #4
100030cf4:     	lsl	x8, x8, #4
100030cf8:     	mov	x1, xzr
100030cfc:     	ldr	x9, [x23, x9]
100030d00:     	ldr	x8, [x23, x8]
100030d04:     	cmp	x9, x8
100030d08:     	cset	w0, hi
100030d0c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030d10:     	ldr	w0, [x27, #0xc]
100030d14:     	cmp	x19, x0
100030d18:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030d1c:     	ldr	w8, [x27, #0x10]
100030d20:     	cmp	x19, x8
100030d24:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030d28:     	lsl	x9, x0, #4
100030d2c:     	lsl	x8, x8, #4
100030d30:     	mov	x1, xzr
100030d34:     	ldr	w9, [x23, x9]
100030d38:     	ldr	w8, [x23, x8]
100030d3c:     	sub	w0, w9, w8
100030d40:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030d44:     	ldr	w0, [x27, #0xc]
100030d48:     	cmp	x19, x0
100030d4c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030d50:     	lsl	x8, x0, #4
100030d54:     	mov	w11, #0x20              ; =32
100030d58:     	mov	w12, #0x18              ; =24
100030d5c:     	mov	x1, xzr
100030d60:     	ldr	w8, [x23, x8]
100030d64:     	lsr	w9, w8, #16
100030d68:     	cmp	w9, #0x0
100030d6c:     	csel	w8, w9, w8, ne
100030d70:     	mov	x9, #-0x10              ; =-16
100030d74:     	lsr	w10, w8, #8
100030d78:     	csel	x9, x9, xzr, ne
100030d7c:     	cmp	w8, #0xff
100030d80:     	csel	w8, w10, w8, hi
100030d84:     	adrp	x10, 0x1002c5000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x1088>
100030d88:     	add	x10, x10, #0x70d
100030d8c:     	and	x8, x8, #0xff
100030d90:     	ldrb	w8, [x10, x8]
100030d94:     	csel	x10, x12, x11, hi
100030d98:     	add	x9, x10, x9
100030d9c:     	sub	x0, x9, x8
100030da0:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030da4:     	ldr	w0, [x27, #0xc]
100030da8:     	cmp	x19, x0
100030dac:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030db0:     	ldr	w8, [x27, #0x10]
100030db4:     	cmp	x19, x8
100030db8:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030dbc:     	lsl	x9, x0, #4
100030dc0:     	lsl	x8, x8, #4
100030dc4:     	mov	x1, xzr
100030dc8:     	ldr	w9, [x23, x9]
100030dcc:     	ldr	w8, [x23, x8]
100030dd0:     	lsr	w0, w9, w8
100030dd4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030dd8:     	ldr	w0, [x27, #0xc]
100030ddc:     	cmp	x19, x0
100030de0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030de4:     	ldr	w8, [x27, #0x10]
100030de8:     	cmp	x19, x8
100030dec:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030df0:     	lsl	x9, x0, #4
100030df4:     	lsl	x8, x8, #4
100030df8:     	mov	x1, xzr
100030dfc:     	ldr	x9, [x23, x9]
100030e00:     	ldr	x8, [x23, x8]
100030e04:     	cmp	x9, x8
100030e08:     	cset	w0, gt
100030e0c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030e10:     	ldr	w0, [x27, #0xc]
100030e14:     	cmp	x19, x0
100030e18:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030e1c:     	ldr	w8, [x27, #0x10]
100030e20:     	cmp	x19, x8
100030e24:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030e28:     	lsl	x9, x0, #4
100030e2c:     	lsl	x8, x8, #4
100030e30:     	mov	x1, xzr
100030e34:     	ldr	w9, [x23, x9]
100030e38:     	ldr	w8, [x23, x8]
100030e3c:     	cmp	w9, w8
100030e40:     	cset	w0, lt
100030e44:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030e48:     	ldr	w0, [x27, #0xc]
100030e4c:     	cmp	x19, x0
100030e50:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030e54:     	ldr	w8, [x27, #0x10]
100030e58:     	cmp	x19, x8
100030e5c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030e60:     	lsl	x9, x0, #4
100030e64:     	lsl	x8, x8, #4
100030e68:     	mov	x1, xzr
100030e6c:     	ldr	x9, [x23, x9]
100030e70:     	ldr	x8, [x23, x8]
100030e74:     	cmp	x9, x8
100030e78:     	cset	w0, ne
100030e7c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030e80:     	ldr	w0, [x27, #0xc]
100030e84:     	cmp	x19, x0
100030e88:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030e8c:     	lsl	x8, x0, #4
100030e90:     	ldr	w8, [x23, x8]
100030e94:     	cbz	w8, 0x100031868 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d0c>
100030e98:     	rbit	w8, w8
100030e9c:     	mov	x1, xzr
100030ea0:     	clz	w0, w8
100030ea4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ea8:     	ldr	w0, [x27, #0xc]
100030eac:     	cmp	x19, x0
100030eb0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030eb4:     	ldr	w8, [x27, #0x10]
100030eb8:     	cmp	x19, x8
100030ebc:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030ec0:     	lsl	x9, x0, #4
100030ec4:     	lsl	x8, x8, #4
100030ec8:     	mov	x1, xzr
100030ecc:     	ldr	w9, [x23, x9]
100030ed0:     	ldr	w8, [x23, x8]
100030ed4:     	cmp	w9, w8
100030ed8:     	cset	w0, ne
100030edc:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ee0:     	ldr	w0, [x27, #0xc]
100030ee4:     	cmp	x19, x0
100030ee8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030eec:     	ldr	w8, [x27, #0x10]
100030ef0:     	cmp	x19, x8
100030ef4:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030ef8:     	lsl	x9, x0, #4
100030efc:     	lsl	x8, x8, #4
100030f00:     	mov	x1, xzr
100030f04:     	ldr	x9, [x23, x9]
100030f08:     	ldr	x8, [x23, x8]
100030f0c:     	cmp	x9, x8
100030f10:     	cset	w0, le
100030f14:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030f18:     	ldr	w0, [x27, #0xc]
100030f1c:     	cmp	x19, x0
100030f20:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030f24:     	ldr	w8, [x27, #0x10]
100030f28:     	cmp	x19, x8
100030f2c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030f30:     	lsl	x8, x8, #4
100030f34:     	lsl	x9, x0, #4
100030f38:     	mov	x1, xzr
100030f3c:     	ldr	w8, [x23, x8]
100030f40:     	ldr	w9, [x23, x9]
100030f44:     	neg	w8, w8
100030f48:     	ror	w0, w9, w8
100030f4c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030f50:     	ldr	w0, [x27, #0xc]
100030f54:     	cmp	x19, x0
100030f58:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030f5c:     	ldr	w8, [x27, #0x10]
100030f60:     	cmp	x19, x8
100030f64:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030f68:     	lsl	x9, x0, #4
100030f6c:     	lsl	x8, x8, #4
100030f70:     	mov	x1, xzr
100030f74:     	ldr	w9, [x23, x9]
100030f78:     	ldr	w8, [x23, x8]
100030f7c:     	cmp	w9, w8
100030f80:     	cset	w0, ls
100030f84:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030f88:     	ldr	w0, [x27, #0xc]
100030f8c:     	cmp	x19, x0
100030f90:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030f94:     	ldr	w8, [x27, #0x10]
100030f98:     	cmp	x19, x8
100030f9c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030fa0:     	lsl	x9, x0, #4
100030fa4:     	lsl	x8, x8, #4
100030fa8:     	mov	x1, xzr
100030fac:     	ldr	w9, [x23, x9]
100030fb0:     	ldr	w8, [x23, x8]
100030fb4:     	cmp	w9, w8
100030fb8:     	cset	w0, ge
100030fbc:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030fc0:     	ldr	w0, [x27, #0xc]
100030fc4:     	cmp	x19, x0
100030fc8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030fcc:     	lsl	x8, x0, #4
100030fd0:     	mov	x1, xzr
100030fd4:     	ldr	w8, [x23, x8]
100030fd8:     	cmp	w8, #0x0
100030fdc:     	cset	w0, eq
100030fe0:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030fe4:     	ldr	w0, [x27, #0xc]
100030fe8:     	cmp	x19, x0
100030fec:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030ff0:     	ldr	w8, [x27, #0x10]
100030ff4:     	cmp	x19, x8
100030ff8:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030ffc:     	lsl	x9, x0, #4
100031000:     	lsl	x8, x8, #4
100031004:     	mov	x1, xzr
100031008:     	ldr	w9, [x23, x9]
10003100c:     	ldr	w8, [x23, x8]
100031010:     	cmp	w9, w8
100031014:     	cset	w0, lo
100031018:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003101c:     	ldr	w0, [x27, #0xc]
100031020:     	cmp	x19, x0
100031024:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031028:     	ldr	w8, [x27, #0x10]
10003102c:     	cmp	x19, x8
100031030:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031034:     	lsl	x9, x0, #4
100031038:     	lsl	x8, x8, #4
10003103c:     	mov	x1, xzr
100031040:     	ldr	x9, [x23, x9]
100031044:     	ldr	x8, [x23, x8]
100031048:     	add	x0, x8, x9
10003104c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031050:     	ldr	w0, [x27, #0xc]
100031054:     	cmp	x19, x0
100031058:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003105c:     	ldr	w8, [x27, #0x10]
100031060:     	cmp	x19, x8
100031064:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031068:     	lsl	x9, x0, #4
10003106c:     	lsl	x8, x8, #4
100031070:     	mov	x1, xzr
100031074:     	ldr	w9, [x23, x9]
100031078:     	ldr	w8, [x23, x8]
10003107c:     	eor	w0, w8, w9
100031080:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031084:     	ldr	w0, [x27, #0xc]
100031088:     	cmp	x19, x0
10003108c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031090:     	ldr	w8, [x27, #0x10]
100031094:     	cmp	x19, x8
100031098:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003109c:     	lsl	x9, x0, #4
1000310a0:     	lsl	x8, x8, #4
1000310a4:     	mov	x1, xzr
1000310a8:     	ldr	x9, [x23, x9]
1000310ac:     	ldr	x8, [x23, x8]
1000310b0:     	and	x0, x8, x9
1000310b4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000310b8:     	ldr	w0, [x27, #0xc]
1000310bc:     	cmp	x19, x0
1000310c0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000310c4:     	ldr	w8, [x27, #0x10]
1000310c8:     	cmp	x19, x8
1000310cc:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000310d0:     	lsl	x9, x0, #4
1000310d4:     	lsl	x8, x8, #4
1000310d8:     	mov	x1, xzr
1000310dc:     	ldr	x9, [x23, x9]
1000310e0:     	ldr	x8, [x23, x8]
1000310e4:     	sub	x0, x9, x8
1000310e8:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000310ec:     	ldr	w0, [x27, #0xc]
1000310f0:     	cmp	x19, x0
1000310f4:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000310f8:     	ldr	w8, [x27, #0x10]
1000310fc:     	cmp	x19, x8
100031100:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031104:     	lsl	x8, x8, #4
100031108:     	lsl	x9, x0, #4
10003110c:     	ldr	w8, [x23, x8]
100031110:     	ldr	x9, [x23, x9]
100031114:     	neg	w8, w8
100031118:     	b	0x1000312c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1768>
10003111c:     	ldr	w0, [x27, #0xc]
100031120:     	cmp	x19, x0
100031124:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031128:     	ldr	w8, [x27, #0x10]
10003112c:     	cmp	x19, x8
100031130:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031134:     	lsl	x9, x0, #4
100031138:     	lsl	x8, x8, #4
10003113c:     	mov	x1, xzr
100031140:     	ldr	w9, [x23, x9]
100031144:     	ldr	w8, [x23, x8]
100031148:     	cmp	w9, w8
10003114c:     	cset	w0, eq
100031150:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031154:     	ldr	w0, [x27, #0xc]
100031158:     	cmp	x19, x0
10003115c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031160:     	ldr	w8, [x27, #0x10]
100031164:     	cmp	x19, x8
100031168:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003116c:     	lsl	x9, x0, #4
100031170:     	lsl	x8, x8, #4
100031174:     	mov	x1, xzr
100031178:     	ldr	w9, [x23, x9]
10003117c:     	ldr	w8, [x23, x8]
100031180:     	cmp	w9, w8
100031184:     	cset	w0, hs
100031188:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003118c:     	ldr	w0, [x27, #0xc]
100031190:     	cmp	x19, x0
100031194:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031198:     	ldr	w8, [x27, #0x10]
10003119c:     	cmp	x19, x8
1000311a0:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000311a4:     	lsl	x9, x0, #4
1000311a8:     	lsl	x8, x8, #4
1000311ac:     	mov	x1, xzr
1000311b0:     	ldr	w9, [x23, x9]
1000311b4:     	ldr	w8, [x23, x8]
1000311b8:     	mul	w0, w8, w9
1000311bc:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000311c0:     	ldr	w0, [x27, #0xc]
1000311c4:     	cmp	x19, x0
1000311c8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000311cc:     	ldr	w8, [x27, #0x10]
1000311d0:     	cmp	x19, x8
1000311d4:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000311d8:     	lsl	x9, x0, #4
1000311dc:     	lsl	x8, x8, #4
1000311e0:     	mov	x1, xzr
1000311e4:     	ldr	w9, [x23, x9]
1000311e8:     	ldr	w8, [x23, x8]
1000311ec:     	cmp	w9, w8
1000311f0:     	cset	w0, le
1000311f4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000311f8:     	ldr	w0, [x27, #0xc]
1000311fc:     	cmp	x19, x0
100031200:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031204:     	ldr	w8, [x27, #0x10]
100031208:     	cmp	x19, x8
10003120c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031210:     	lsl	x9, x0, #4
100031214:     	lsl	x8, x8, #4
100031218:     	mov	x1, xzr
10003121c:     	ldr	w9, [x23, x9]
100031220:     	ldr	w8, [x23, x8]
100031224:     	cmp	w9, w8
100031228:     	cset	w0, gt
10003122c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031230:     	ldr	w0, [x27, #0xc]
100031234:     	cmp	x19, x0
100031238:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003123c:     	ldr	w8, [x27, #0x10]
100031240:     	cmp	x19, x8
100031244:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031248:     	lsl	x9, x0, #4
10003124c:     	lsl	x8, x8, #4
100031250:     	mov	x1, xzr
100031254:     	ldr	w9, [x23, x9]
100031258:     	ldr	w8, [x23, x8]
10003125c:     	ror	w0, w9, w8
100031260:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031264:     	ldr	w0, [x27, #0xc]
100031268:     	cmp	x19, x0
10003126c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031270:     	ldr	w8, [x27, #0x10]
100031274:     	cmp	x19, x8
100031278:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003127c:     	lsl	x9, x0, #4
100031280:     	lsl	x8, x8, #4
100031284:     	mov	x1, xzr
100031288:     	ldr	x9, [x23, x9]
10003128c:     	ldr	x8, [x23, x8]
100031290:     	cmp	x9, x8
100031294:     	cset	w0, lt
100031298:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003129c:     	ldr	w0, [x27, #0xc]
1000312a0:     	cmp	x19, x0
1000312a4:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000312a8:     	ldr	w8, [x27, #0x10]
1000312ac:     	cmp	x19, x8
1000312b0:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000312b4:     	lsl	x9, x0, #4
1000312b8:     	lsl	x8, x8, #4
1000312bc:     	ldr	x9, [x23, x9]
1000312c0:     	ldr	x8, [x23, x8]
1000312c4:     	ror	x0, x9, x8
1000312c8:     	mov	x1, xzr
1000312cc:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000312d0:     	ldr	w0, [x27, #0xc]
1000312d4:     	cmp	x19, x0
1000312d8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000312dc:     	ldr	w8, [x27, #0x10]
1000312e0:     	cmp	x19, x8
1000312e4:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000312e8:     	lsl	x9, x0, #4
1000312ec:     	lsl	x8, x8, #4
1000312f0:     	mov	x1, xzr
1000312f4:     	ldr	w9, [x23, x9]
1000312f8:     	ldr	w8, [x23, x8]
1000312fc:     	cmp	w9, w8
100031300:     	cset	w0, hi
100031304:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031308:     	ldr	w0, [x27, #0xc]
10003130c:     	cmp	x19, x0
100031310:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031314:     	lsl	x8, x0, #4
100031318:     	mov	x1, xzr
10003131c:     	ldrsb	x0, [x23, x8]
100031320:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031324:     	ldr	w0, [x27, #0xc]
100031328:     	cmp	x19, x0
10003132c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031330:     	lsl	x8, x0, #4
100031334:     	mov	x1, xzr
100031338:     	ldrsh	x0, [x23, x8]
10003133c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031340:     	ldr	w0, [x27, #0xc]
100031344:     	cmp	x19, x0
100031348:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003134c:     	ldr	w8, [x27, #0x10]
100031350:     	cmp	x19, x8
100031354:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031358:     	lsl	x9, x0, #4
10003135c:     	lsl	x8, x8, #4
100031360:     	mov	x1, xzr
100031364:     	ldr	x9, [x23, x9]
100031368:     	ldr	x8, [x23, x8]
10003136c:     	cmp	x9, x8
100031370:     	cset	w0, eq
100031374:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031378:     	ldr	w0, [x27, #0xc]
10003137c:     	cmp	x19, x0
100031380:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031384:     	ldr	w8, [x27, #0x10]
100031388:     	cmp	x19, x8
10003138c:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031390:     	lsl	x9, x0, #4
100031394:     	lsl	x8, x8, #4
100031398:     	mov	x1, xzr
10003139c:     	ldr	x9, [x23, x9]
1000313a0:     	ldr	x8, [x23, x8]
1000313a4:     	cmp	x9, x8
1000313a8:     	cset	w0, hs
1000313ac:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000313b0:     	ldr	w0, [x27, #0xc]
1000313b4:     	cmp	x19, x0
1000313b8:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000313bc:     	ldr	w8, [x27, #0x10]
1000313c0:     	cmp	x19, x8
1000313c4:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000313c8:     	lsl	x9, x0, #4
1000313cc:     	lsl	x8, x8, #4
1000313d0:     	mov	x1, xzr
1000313d4:     	ldr	x9, [x23, x9]
1000313d8:     	ldr	x8, [x23, x8]
1000313dc:     	cmp	x9, x8
1000313e0:     	cset	w0, ge
1000313e4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000313e8:     	ldr	w0, [x27, #0xc]
1000313ec:     	cmp	x19, x0
1000313f0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000313f4:     	ldr	w8, [x27, #0x10]
1000313f8:     	cmp	x19, x8
1000313fc:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031400:     	lsl	x9, x0, #4
100031404:     	lsl	x8, x8, #4
100031408:     	mov	x1, xzr
10003140c:     	ldr	x9, [x23, x9]
100031410:     	ldr	x8, [x23, x8]
100031414:     	asr	x0, x9, x8
100031418:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003141c:     	ldr	w0, [x27, #0xc]
100031420:     	cmp	x19, x0
100031424:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031428:     	ldr	w8, [x27, #0x10]
10003142c:     	cmp	x19, x8
100031430:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031434:     	lsl	x9, x0, #4
100031438:     	lsl	x8, x8, #4
10003143c:     	mov	x1, xzr
100031440:     	ldr	w9, [x23, x9]
100031444:     	ldr	w8, [x23, x8]
100031448:     	and	w0, w9, w8
10003144c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031450:     	ldr	w0, [x27, #0xc]
100031454:     	cmp	x19, x0
100031458:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003145c:     	ldr	w8, [x27, #0x10]
100031460:     	cmp	x19, x8
100031464:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031468:     	lsl	x9, x0, #4
10003146c:     	lsl	x8, x8, #4
100031470:     	mov	x1, xzr
100031474:     	ldr	w9, [x23, x9]
100031478:     	ldr	w8, [x23, x8]
10003147c:     	add	w0, w8, w9
100031480:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031484:     	ldr	w0, [x27, #0xc]
100031488:     	cmp	x19, x0
10003148c:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031490:     	ldr	w8, [x27, #0x10]
100031494:     	cmp	x19, x8
100031498:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003149c:     	lsl	x9, x0, #4
1000314a0:     	lsl	x8, x8, #4
1000314a4:     	mov	x1, xzr
1000314a8:     	ldr	x9, [x23, x9]
1000314ac:     	ldr	x8, [x23, x8]
1000314b0:     	mul	x0, x8, x9
1000314b4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000314b8:     	ldr	w0, [x27, #0xc]
1000314bc:     	cmp	x19, x0
1000314c0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000314c4:     	lsl	x8, x0, #4
1000314c8:     	mov	x1, xzr
1000314cc:     	ldrsb	x8, [x23, x8]
1000314d0:     	mov	w0, w8
1000314d4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000314d8:     	ldr	w0, [x27, #0xc]
1000314dc:     	cmp	x19, x0
1000314e0:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000314e4:     	lsl	x8, x0, #4
1000314e8:     	mov	w10, #0x20              ; =32
1000314ec:     	mov	x1, xzr
1000314f0:     	ldr	x8, [x23, x8]
1000314f4:     	lsr	x9, x8, #32
1000314f8:     	cmp	x9, #0x0
1000314fc:     	csel	x8, x9, x8, ne
100031500:     	csel	x10, x10, xzr, ne
100031504:     	lsr	x9, x8, #16
100031508:     	cmp	x9, #0x0
10003150c:     	csel	x8, x9, x8, ne
100031510:     	orr	x9, x10, #0x10
100031514:     	lsr	x11, x8, #8
100031518:     	csel	x9, x9, x10, ne
10003151c:     	cmp	x8, #0xff
100031520:     	orr	x10, x9, #0x8
100031524:     	csel	x8, x11, x8, hi
100031528:     	adrp	x11, 0x1002c5000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x1088>
10003152c:     	add	x11, x11, #0x70d
100031530:     	and	x8, x8, #0xff
100031534:     	csel	x9, x10, x9, hi
100031538:     	mov	w10, #0x40              ; =64
10003153c:     	ldrb	w8, [x11, x8]
100031540:     	sub	x9, x10, x9
100031544:     	sub	x0, x9, x8
100031548:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003154c:     	ldr	w0, [x27, #0xc]
100031550:     	cmp	x19, x0
100031554:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031558:     	ldr	w8, [x27, #0x10]
10003155c:     	cmp	x19, x8
100031560:     	b.ls	0x100031aac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031564:     	lsl	x9, x0, #4
100031568:     	lsl	x8, x8, #4
10003156c:     	mov	x1, xzr
100031570:     	ldr	x9, [x23, x9]
100031574:     	ldr	x8, [x23, x8]
100031578:     	lsl	x0, x9, x8
10003157c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031580:     	ldr	w0, [x27, #0xc]
100031584:     	cmp	x19, x0
100031588:     	b.ls	0x100031ab0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003158c:     	lsl	x8, x0, #4
100031590:     	mov	x1, xzr
100031594:     	ldrsh	x8, [x23, x8]
100031598:     	mov	w0, w8
10003159c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000315a0:     	sub	w8, w9, #0x8b
1000315a4:     	cmp	w8, #0x34
1000315a8:     	b.hi	0x1000315c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a64>
1000315ac:     	mov	x10, #-0x10000001       ; =-268435457
1000315b0:     	movk	x10, #0xfff9, lsl #32
1000315b4:     	movk	x10, #0x1f, lsl #48
1000315b8:     	lsr	x8, x10, x8
1000315bc:     	tbnz	w8, #0x0, 0x10002fe4c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
1000315c0:     	sub	w8, w9, #0x61
1000315c4:     	mov	x0, xzr
1000315c8:     	cmp	w8, #0x21
1000315cc:     	b.hi	0x100031890 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d34>
1000315d0:     	mov	x10, #0x3c0000000       ; =16106127360
1000315d4:     	mov	x1, x0
1000315d8:     	movk	x10, #0xf03f
1000315dc:     	lsr	x8, x10, x8
1000315e0:     	tbnz	w8, #0x0, 0x10002fe4c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
1000315e4:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000315e8:     	mov	x5, xzr
1000315ec:     	ldr	w0, [x27, #0x10]
1000315f0:     	cmn	w0, #0x1
1000315f4:     	b.ne	0x100030aa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf48>
1000315f8:     	mov	x7, xzr
1000315fc:     	ldr	w0, [x27, #0x14]
100031600:     	cmn	w0, #0x1
100031604:     	b.ne	0x100030ac0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf64>
100031608:     	mov	x10, xzr
10003160c:     	and	w8, w9, #0xffff0000
100031610:     	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100031614:     	b.eq	0x100030adc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf80>
100031618:     	mov	w8, #0xffed             ; =65517
10003161c:     	movk	w8, #0xff03, lsl #16
100031620:     	add	w8, w8, w9
100031624:     	add	w8, w8, #0xb
100031628:     	cmp	w8, #0xa
10003162c:     	b.hs	0x100031bb4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2058>
100031630:     	ldr	x1, [x16, #0x80]
100031634:     	ldr	w0, [x27, #0x4]
100031638:     	cmp	x1, x0
10003163c:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100031640:     	ldr	x8, [x16, #0x78]
100031644:     	mov	w9, #0xe0               ; =224
100031648:     	umaddl	x8, w0, w9, x8
10003164c:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031650:     	ldr	w9, [x8]
100031654:     	ldr	x11, [x8, #0x8]
100031658:     	add	x12, sp, #0xd8
10003165c:     	ldr	q0, [x8, #0x10]
100031660:     	ldur	q1, [x8, #0x48]
100031664:     	add	x2, sp, #0xd8
100031668:     	str	w9, [sp, #0xd8]
10003166c:     	ldur	q2, [x8, #0x68]
100031670:     	mov	x0, x21
100031674:     	str	x11, [sp, #0xe0]
100031678:     	ldp	x9, x11, [x8, #0x20]
10003167c:     	str	q0, [x12, #0x10]
100031680:     	mov	x3, x5
100031684:     	mov	x4, xzr
100031688:     	ldr	q0, [x8, #0x30]
10003168c:     	stur	q1, [x12, #0x48]
100031690:     	mov	x5, x7
100031694:     	stp	x9, x11, [sp, #0xf8]
100031698:     	ldrb	w9, [x8, #0x40]
10003169c:     	mov	x6, xzr
1000316a0:     	str	q0, [x12, #0x30]
1000316a4:     	ldur	q0, [x8, #0x58]
1000316a8:     	mov	x7, x10
1000316ac:     	strb	w9, [sp, #0x118]
1000316b0:     	ldur	q1, [x8, #0x78]
1000316b4:     	ldr	x1, [sp, #0x20]
1000316b8:     	stur	q0, [x12, #0x58]
1000316bc:     	ldur	q0, [x8, #0x88]
1000316c0:     	ldp	x9, x8, [x8, #0x98]
1000316c4:     	stur	q2, [x12, #0x68]
1000316c8:     	stur	q1, [x12, #0x78]
1000316cc:     	stur	q0, [x12, #0x88]
1000316d0:     	stp	x9, x8, [sp, #0x170]
1000316d4:     	add	x8, sp, #0xb0
1000316d8:     	str	xzr, [sp]
1000316dc:     	bl	0x100035c14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
1000316e0:     	ldp	x0, x1, [sp, #0xb0]
1000316e4:     	ldr	x8, [sp, #0xc8]
1000316e8:     	ldrb	w25, [sp, #0xc0]
1000316ec:     	cbz	x8, 0x1000304a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
1000316f0:     	ldr	x9, [x8, #0x8]
1000316f4:     	ldr	x16, [sp, #0x28]
1000316f8:     	cbz	x9, 0x1000304a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
1000316fc:     	b	0x100031a6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f10>
100031700:     	ldr	x8, [x25, #0x10]
100031704:     	ldr	x16, [sp, #0x28]
100031708:     	mov	x1, xzr
10003170c:     	ldrb	w8, [x8, #0x31]
100031710:     	tst	w8, #0x1
100031714:     	strb	w8, [sp, #0xaf]
100031718:     	mov	w8, #-0x1               ; =-1
10003171c:     	csinv	x0, x8, xzr, eq
100031720:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031724:     	cbz	x8, 0x100031874 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d18>
100031728:     	ldar	x8, [x8]
10003172c:     	cbz	x0, 0x10003187c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d20>
100031730:     	ldr	x9, [x0, #0x38]
100031734:     	mov	w10, #0x10000           ; =65536
100031738:     	mov	x1, xzr
10003173c:     	cmp	x9, #0x0
100031740:     	csel	x9, x10, x9, eq
100031744:     	udiv	x0, x8, x9
100031748:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003174c:     	mov	x0, xzr
100031750:     	mov	x2, xzr
100031754:     	b	0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100031758:     	ldr	x8, [x0, #0x8]
10003175c:     	cbnz	x8, 0x100031960 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
100031760:     	ldr	x2, [x16, #0x108]
100031764:     	add	w8, w26, w25
100031768:     	cmp	x2, x8
10003176c:     	b.lo	0x100031b54 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ff8>
100031770:     	cmp	w25, w8
100031774:     	b.hi	0x100031b40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
100031778:     	sub	x9, x2, x25
10003177c:     	lsl	x10, x25, #3
100031780:     	cmp	x9, #0x0
100031784:     	csel	x9, x10, xzr, gt
100031788:     	cbz	w26, 0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c74>
10003178c:     	ldr	x10, [x16, #0xf8]
100031790:     	ldr	w26, [sp, #0x14]
100031794:     	add	x10, x10, x9
100031798:     	sub	x9, x8, x25
10003179c:     	add	x10, x10, #0x4
1000317a0:     	ldr	w0, [x10]
1000317a4:     	cmp	x19, x0
1000317a8:     	b.ls	0x100031a90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
1000317ac:     	ldur	w8, [x10, #-0x4]
1000317b0:     	cmp	x19, x8
1000317b4:     	b.ls	0x100031a98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
1000317b8:     	ldr	q0, [x23, x0, lsl #4]
1000317bc:     	subs	x9, x9, #0x1
1000317c0:     	add	x10, x10, #0x8
1000317c4:     	str	q0, [x23, x8, lsl #4]
1000317c8:     	b.ne	0x1000317a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c44>
1000317cc:     	b	0x10002fc18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
1000317d0:     	ldr	w26, [sp, #0x14]
1000317d4:     	b	0x10002fc18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
1000317d8:     	ldr	x1, [x16, #0x80]
1000317dc:     	ldr	w0, [x27, #0x4]
1000317e0:     	cmp	x1, x0
1000317e4:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000317e8:     	ldr	x8, [x16, #0x78]
1000317ec:     	mov	w9, #0xe0               ; =224
1000317f0:     	umaddl	x8, w0, w9, x8
1000317f4:     	cbz	x8, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000317f8:     	ldr	x9, [sp, #0x20]
1000317fc:     	ldr	w0, [x8, #0x18]
100031800:     	ldr	x1, [x9, #0x78]
100031804:     	cmp	x1, x0
100031808:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10003180c:     	ldr	x9, [x9, #0x70]
100031810:     	adds	x9, x9, x0, lsl #3
100031814:     	b.eq	0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031818:     	ldr	x9, [x9]
10003181c:     	cbz	x9, 0x100031908 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031820:     	ldp	x11, x1, [x21]
100031824:     	ldr	w12, [x8, #0x14]
100031828:     	ldr	w8, [x8, #0x1c]
10003182c:     	ldr	x2, [x21, #0x10]
100031830:     	ldr	x0, [x9, #0x10]
100031834:     	ldr	x3, [x11, #0x8]
100031838:     	orr	x6, x12, x8, lsl #32
10003183c:     	sub	x8, x29, #0xa0
100031840:     	str	x10, [sp]
100031844:     	bl	0x10004c788 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
100031848:     	ldp	x0, x1, [x29, #-0xa0]
10003184c:     	ldur	x8, [x29, #-0x88]
100031850:     	ldurb	w25, [x29, #-0x90]
100031854:     	cbz	x8, 0x1000304a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
100031858:     	ldr	x9, [x8, #0x8]
10003185c:     	ldr	x16, [sp, #0x28]
100031860:     	cbz	x9, 0x1000304a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
100031864:     	b	0x100031a74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f18>
100031868:     	mov	x1, xzr
10003186c:     	mov	w0, #0x20               ; =32
100031870:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031874:     	ldr	x8, [x0, #0x8]
100031878:     	cbnz	x0, 0x100031730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bd4>
10003187c:     	mov	w0, #0x1                ; =1
100031880:     	bl	0x100221638 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031884:     	ldr	x16, [sp, #0x28]
100031888:     	mov	x1, xzr
10003188c:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031890:     	mov	x1, x0
100031894:     	b	0x1000304ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031898:     	ldr	x8, [sp, #0x18]
10003189c:     	mov	x0, x21
1000318a0:     	stur	w24, [x8, #-0x38]
1000318a4:     	bl	0x1000338f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
1000318a8:     	tst	w0, #0xff
1000318ac:     	b.ne	0x10003196c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
1000318b0:     	ldr	x8, [x21, #0x48]
1000318b4:     	cmp	x8, #0x0
1000318b8:     	b.gt	0x10002fb98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x3c>
1000318bc:     	b	0x100031b9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
1000318c0:     	ldr	x8, [sp, #0x18]
1000318c4:     	mov	x0, x21
1000318c8:     	stur	w24, [x8, #-0x38]
1000318cc:     	bl	0x100032a04 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
1000318d0:     	b	0x1000318a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
1000318d4:     	ldr	x8, [sp, #0x18]
1000318d8:     	mov	x0, x21
1000318dc:     	stur	w24, [x8, #-0x38]
1000318e0:     	bl	0x100033500 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
1000318e4:     	b	0x1000318a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
1000318e8:     	ldr	x8, [sp, #0x18]
1000318ec:     	mov	x0, x21
1000318f0:     	stur	w24, [x8, #-0x38]
1000318f4:     	bl	0x10003263c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
1000318f8:     	and	w8, w0, #0xff
1000318fc:     	tbz	w8, #0x0, 0x1000318b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d54>
100031900:     	mov	w0, #0x1                ; =1
100031904:     	b	0x100031a48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
100031908:     	mov	w0, #0x1                ; =1
10003190c:     	bl	0x100221638 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031910:     	mov	x0, xzr
100031914:     	b	0x100031a48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
100031918:     	mov	w0, #0x28               ; =40
10003191c:     	bl	0x100235f20 <dyld_stub_binder+0x100235f20>
100031920:     	cbz	x0, 0x100031bcc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
100031924:     	mov	x19, x0
100031928:     	mov	w0, #0x28               ; =40
10003192c:     	bl	0x10021d104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100031930:     	ldr	x8, [x25, #0x8]
100031934:     	adrp	x9, 0x1003d0000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x3e3>
100031938:     	adrp	x10, 0x1002aa000 <dyld_stub_binder+0x1002aa000>
10003193c:     	add	x10, x10, #0x81f
100031940:     	ldr	q0, [x9, #0xa20]
100031944:     	adrp	x1, 0x100302000 <_[][]_llgo_github.com/cpunion/wasmvm/internal/compiler/ir.Catch+0x20>
100031948:     	add	x1, x1, #0x470
10003194c:     	stp	x8, x10, [x19, #0x10]
100031950:     	mov	w8, #0xe                ; =14
100031954:     	str	q0, [x19]
100031958:     	str	x8, [x19, #0x20]
10003195c:     	b	0x100031a38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1edc>
100031960:     	mov	x1, x0
100031964:     	mov	x0, x21
100031968:     	b	0x100031a40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
10003196c:     	and	x0, x0, #0xff
100031970:     	b	0x100031a48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
100031974:     	ldr	x19, [sp, #0x98]
100031978:     	mov	w0, #0x8                ; =8
10003197c:     	bl	0x100235f20 <dyld_stub_binder+0x100235f20>
100031980:     	cbz	x0, 0x100031bcc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
100031984:     	mov	x22, x0
100031988:     	mov	w0, #0x8                ; =8
10003198c:     	bl	0x10021d104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100031990:     	adrp	x2, 0x1002e5000 <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
100031994:     	add	x2, x2, #0x468
100031998:     	mov	x0, x25
10003199c:     	mov	x1, x19
1000319a0:     	mov	x3, x22
1000319a4:     	bl	0x1001fc9fc <_errors.As>
1000319a8:     	ldr	x9, [sp, #0x8]
1000319ac:     	tbz	w0, #0x0, 0x1000319bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e60>
1000319b0:     	ldr	x8, [x22]
1000319b4:     	ldr	w9, [x9, #0x50]
1000319b8:     	str	w9, [x8, #0x4]
1000319bc:     	mov	x0, x21
1000319c0:     	mov	x1, x25
1000319c4:     	b	0x100031a3c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
1000319c8:     	mov	w25, #0x3               ; =3
1000319cc:     	b	0x1000319dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
1000319d0:     	mov	w25, #0x1               ; =1
1000319d4:     	b	0x1000319dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
1000319d8:     	mov	w25, #0x9               ; =9
1000319dc:     	mov	w0, #0x10               ; =16
1000319e0:     	bl	0x100235f14 <dyld_stub_binder+0x100235f14>
1000319e4:     	cbz	x0, 0x100031bcc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
1000319e8:     	mov	x19, x0
1000319ec:     	mov	w0, #0x10               ; =16
1000319f0:     	bl	0x10021d104 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1000319f4:     	ldr	x9, [sp, #0x28]
1000319f8:     	stp	xzr, xzr, [x19]
1000319fc:     	ldr	w0, [x27, #0x4]
100031a00:     	ldr	x1, [x9, #0x80]
100031a04:     	cmp	x1, x0
100031a08:     	b.ls	0x100031aa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100031a0c:     	mov	w8, #0xe0               ; =224
100031a10:     	ldr	x9, [x9, #0x78]
100031a14:     	adrp	x1, 0x1002e5000 <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
100031a18:     	add	x1, x1, #0x7d0
100031a1c:     	umaddl	x8, w0, w8, x9
100031a20:     	ldr	x9, [sp, #0x8]
100031a24:     	ldr	w9, [x9, #0x50]
100031a28:     	ldr	x8, [x8, #0x8]
100031a2c:     	strb	w25, [x19]
100031a30:     	str	w9, [x19, #0x4]
100031a34:     	str	x8, [x19, #0x8]
100031a38:     	mov	x0, x21
100031a3c:     	mov	x2, x19
100031a40:     	bl	0x10002ede4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
100031a44:     	mov	w0, #0x3                ; =3
100031a48:     	mov	x1, x20
100031a4c:     	add	sp, sp, #0x1d0
100031a50:     	ldp	x29, x30, [sp, #0x50]
100031a54:     	ldp	x20, x19, [sp, #0x40]
100031a58:     	ldp	x22, x21, [sp, #0x30]
100031a5c:     	ldp	x24, x23, [sp, #0x20]
100031a60:     	ldp	x26, x25, [sp, #0x10]
100031a64:     	ldp	x28, x27, [sp], #0x60
100031a68:     	ret
100031a6c:     	ldr	x2, [sp, #0xd0]
100031a70:     	b	0x100031a78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f1c>
100031a74:     	ldur	x2, [x29, #-0x80]
100031a78:     	mov	x0, x21
100031a7c:     	mov	x1, x8
100031a80:     	b	0x100031a40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
100031a84:     	mov	x0, x24
100031a88:     	mov	x1, x22
100031a8c:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031a90:     	mov	x1, x19
100031a94:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031a98:     	mov	x0, x8
100031a9c:     	mov	x1, x19
100031aa0:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031aa4:     	mov	x1, x22
100031aa8:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031aac:     	mov	x0, x8
100031ab0:     	mov	x1, x19
100031ab4:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031ab8:     	mov	x0, x8
100031abc:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031ac0:     	mov	x0, x10
100031ac4:     	mov	x1, x19
100031ac8:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031acc:     	mov	x0, x9
100031ad0:     	mov	w1, #0x1                ; =1
100031ad4:     	mov	w3, #0x2                ; =2
100031ad8:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031adc:     	mov	x0, x8
100031ae0:     	mov	w1, #0x1                ; =1
100031ae4:     	mov	x2, x9
100031ae8:     	mov	w3, #0x3                ; =3
100031aec:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031af0:     	mov	x0, x11
100031af4:     	mov	x1, x19
100031af8:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031afc:     	mov	x0, x9
100031b00:     	mov	x1, x19
100031b04:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031b08:     	mov	w0, #0x1                ; =1
100031b0c:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031b10:     	mov	x0, xzr
100031b14:     	mov	x1, xzr
100031b18:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031b1c:     	mov	x0, x8
100031b20:     	mov	w1, wzr
100031b24:     	mov	x2, x10
100031b28:     	mov	w3, #0x3                ; =3
100031b2c:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031b30:     	mov	x0, x10
100031b34:     	mov	w1, wzr
100031b38:     	mov	w3, #0x2                ; =2
100031b3c:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031b40:     	mov	x0, x25
100031b44:     	mov	w1, wzr
100031b48:     	mov	x2, x8
100031b4c:     	mov	w3, #0x3                ; =3
100031b50:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031b54:     	mov	x0, x8
100031b58:     	mov	w1, wzr
100031b5c:     	mov	w3, #0x2                ; =2
100031b60:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031b64:     	mov	w0, #0x3                ; =3
100031b68:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031b6c:     	mov	w0, #0x2                ; =2
100031b70:     	mov	w1, #0x2                ; =2
100031b74:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031b78:     	mov	x0, x9
100031b7c:     	mov	x1, x19
100031b80:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031b84:     	adrp	x0, 0x100359000 <__llgo_func$Oob_PMZ7jwg4Zq77Ey2ib6LC02NBqIRsIh_lNyFzLAc+0x60>
100031b88:     	add	x0, x0, #0x9e8
100031b8c:     	adrp	x1, 0x100359000 <__llgo_func$Oob_PMZ7jwg4Zq77Ey2ib6LC02NBqIRsIh_lNyFzLAc+0x60>
100031b90:     	add	x1, x1, #0xc68
100031b94:     	bl	0x10021cef0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031b98:     	brk	#0x1
100031b9c:     	adrp	x0, 0x100363000 <__llgo_complex64+0x40>
100031ba0:     	add	x0, x0, #0x320
100031ba4:     	adrp	x1, 0x1002e5000 <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
100031ba8:     	add	x1, x1, #0x4b8
100031bac:     	bl	0x10021cef0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031bb0:     	brk	#0x1
100031bb4:     	adrp	x0, 0x100363000 <__llgo_complex64+0x40>
100031bb8:     	add	x0, x0, #0x320
100031bbc:     	adrp	x1, 0x1002e5000 <__llgo_itab$pWkszluPzcgTZMYCec_UM9cSl4n9O8T6XKgA52abA9Y+0x10>
100031bc0:     	add	x1, x1, #0x4c8
100031bc4:     	bl	0x10021cef0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031bc8:     	brk	#0x1
100031bcc:     	adrp	x0, 0x100363000 <__llgo_complex64+0x40>
100031bd0:     	add	x0, x0, #0x320
100031bd4:     	adrp	x1, 0x100359000 <__llgo_func$Oob_PMZ7jwg4Zq77Ey2ib6LC02NBqIRsIh_lNyFzLAc+0x60>
100031bd8:     	add	x1, x1, #0x9d8
100031bdc:     	bl	0x10021cef0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031be0:     	brk	#0x1
