
/Users/lijie/source/goplus/wasmvm/artifacts/bounded-pure-call-20261120/base-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100031e74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD>:
100031e74:     	sub	sp, sp, #0xd0
100031e78:     	stp	x28, x27, [sp, #0x70]
100031e7c:     	stp	x26, x25, [sp, #0x80]
100031e80:     	stp	x24, x23, [sp, #0x90]
100031e84:     	stp	x22, x21, [sp, #0xa0]
100031e88:     	stp	x20, x19, [sp, #0xb0]
100031e8c:     	stp	x29, x30, [sp, #0xc0]
100031e90:     	add	x29, sp, #0xc0
100031e94:     	cbz	x0, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031e98:     	ldr	x9, [x0, #0x48]
100031e9c:     	sub	x8, x9, #0x1
100031ea0:     	cbz	x9, 0x100032170 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2fc>
100031ea4:     	ldr	x9, [x0, #0x40]
100031ea8:     	adds	x23, x9, x8, lsl #6
100031eac:     	b.eq	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031eb0:     	ldr	x21, [x23]
100031eb4:     	cbz	x21, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031eb8:     	ldr	x8, [x21, #0x48]
100031ebc:     	cbz	x8, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031ec0:     	ldr	w13, [x23, #0x8]
100031ec4:     	ldr	x1, [x8, #0xb8]
100031ec8:     	cmp	x1, x13
100031ecc:     	b.ls	0x100032188 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x314>
100031ed0:     	ldr	x9, [x23, #0x18]
100031ed4:     	ldr	x20, [x8, #0x98]
100031ed8:     	ldr	x2, [x0, #0x88]
100031edc:     	add	x10, x20, x9
100031ee0:     	cmp	x10, x2
100031ee4:     	b.hi	0x100032190 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x31c>
100031ee8:     	cmp	x9, x10
100031eec:     	b.hi	0x1000321a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x32c>
100031ef0:     	ldr	x10, [x8, #0xb0]
100031ef4:     	lsl	x11, x9, #4
100031ef8:     	ldr	x26, [x21, #0x40]
100031efc:     	str	x13, [sp, #0x8]
100031f00:     	add	x24, x10, x13, lsl #5
100031f04:     	sub	x10, x2, x9
100031f08:     	cmp	x10, #0x0
100031f0c:     	ldr	x10, [x0, #0x78]
100031f10:     	ldr	w9, [x24, #0xc]
100031f14:     	csel	x11, x11, xzr, gt
100031f18:     	ldr	w22, [x24]
100031f1c:     	add	x25, x10, x11
100031f20:     	cmn	w9, #0x1
100031f24:     	b.eq	0x100031f9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x128>
100031f28:     	cmp	x20, x9
100031f2c:     	b.ls	0x10003217c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x308>
100031f30:     	add	x9, x25, x9, lsl #4
100031f34:     	ldp	x10, x19, [x9]
100031f38:     	ldr	w9, [x24, #0x10]
100031f3c:     	cmn	w9, #0x1
100031f40:     	b.eq	0x100031fb0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x13c>
100031f44:     	cmp	x20, x9
100031f48:     	b.ls	0x10003217c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x308>
100031f4c:     	ldr	q0, [x25, x9, lsl #4]
100031f50:     	str	q0, [sp, #0x30]
100031f54:     	ldp	x12, x11, [sp, #0x30]
100031f58:     	ldr	w9, [x24, #0x14]
100031f5c:     	stp	x11, x10, [sp, #0x20]
100031f60:     	str	x12, [sp, #0x18]
100031f64:     	cmn	w9, #0x1
100031f68:     	b.eq	0x100031fc4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x150>
100031f6c:     	cmp	x20, x9
100031f70:     	b.ls	0x10003217c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x308>
100031f74:     	ldr	q0, [x25, x9, lsl #4]
100031f78:     	str	q0, [sp, #0x40]
100031f7c:     	ldp	x27, x28, [sp, #0x40]
100031f80:     	ldr	w1, [x24, #0x4]
100031f84:     	str	x0, [sp, #0x10]
100031f88:     	add	x2, x0, #0x1d8
100031f8c:     	mov	x0, x8
100031f90:     	bl	0x1000cbc0c <_github.com/cpunion/wasmvm/internal/compiler/slots.(*Function).ReadSource>
100031f94:     	cbnz	x0, 0x100031fe4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x170>
100031f98:     	b	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031f9c:     	mov	x19, xzr
100031fa0:     	mov	x10, xzr
100031fa4:     	ldr	w9, [x24, #0x10]
100031fa8:     	cmn	w9, #0x1
100031fac:     	b.ne	0x100031f44 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0xd0>
100031fb0:     	ldr	w9, [x24, #0x14]
100031fb4:     	stp	xzr, x10, [sp, #0x20]
100031fb8:     	str	xzr, [sp, #0x18]
100031fbc:     	cmn	w9, #0x1
100031fc0:     	b.ne	0x100031f6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0xf8>
100031fc4:     	mov	x27, xzr
100031fc8:     	mov	x28, xzr
100031fcc:     	ldr	w1, [x24, #0x4]
100031fd0:     	str	x0, [sp, #0x10]
100031fd4:     	add	x2, x0, #0x1d8
100031fd8:     	mov	x0, x8
100031fdc:     	bl	0x1000cbc0c <_github.com/cpunion/wasmvm/internal/compiler/slots.(*Function).ReadSource>
100031fe0:     	cbz	x0, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100031fe4:     	and	w8, w22, #0xfffc
100031fe8:     	and	w9, w22, #0xffff
100031fec:     	cmp	w8, #0x54
100031ff0:     	ccmp	w9, #0xb, #0x0, ne
100031ff4:     	b.lo	0x100032004 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x190>
100031ff8:     	sub	w10, w9, #0x5c
100031ffc:     	cmp	w10, #0x2
100032000:     	b.hs	0x100032084 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x210>
100032004:     	cbz	x26, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100032008:     	ldr	x1, [x26, #0x78]
10003200c:     	ldr	w8, [x0, #0x18]
100032010:     	cmp	x1, x8
100032014:     	b.ls	0x1000321b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x340>
100032018:     	ldr	x9, [x26, #0x70]
10003201c:     	adds	x8, x9, x8, lsl #3
100032020:     	b.eq	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100032024:     	ldr	x8, [x8]
100032028:     	cbz	x8, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
10003202c:     	ldr	w10, [x0, #0x14]
100032030:     	ldr	w11, [x0, #0x1c]
100032034:     	mov	w1, w22
100032038:     	ldr	x9, [x8, #0x10]
10003203c:     	ldp	x6, x2, [sp, #0x20]
100032040:     	orr	x3, x10, x11, lsl #32
100032044:     	ldrb	w4, [x0, #0x40]
100032048:     	add	x8, sp, #0x58
10003204c:     	ldr	x5, [sp, #0x18]
100032050:     	mov	x0, x9
100032054:     	bl	0x10004e9bc <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load>
100032058:     	ldp	x0, x1, [sp, #0x58]
10003205c:     	ldrb	w3, [sp, #0x68]
100032060:     	ldr	x8, [sp, #0x10]
100032064:     	tst	w3, #0xff
100032068:     	b.eq	0x100032140 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2cc>
10003206c:     	ldr	w2, [x24, #0x4]
100032070:     	mov	x0, x8
100032074:     	mov	x1, x21
100032078:     	bl	0x100034254 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
10003207c:     	mov	w0, #0x3                ; =3
100032080:     	b	0x100032108 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x294>
100032084:     	cmp	w9, #0xb
100032088:     	b.eq	0x100032094 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x220>
10003208c:     	cmp	w8, #0x58
100032090:     	b.ne	0x100032128 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2b4>
100032094:     	cbz	x26, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
100032098:     	ldr	x1, [x26, #0x78]
10003209c:     	ldr	w8, [x0, #0x18]
1000320a0:     	cmp	x1, x8
1000320a4:     	b.ls	0x1000321b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x340>
1000320a8:     	ldr	x9, [x26, #0x70]
1000320ac:     	adds	x8, x9, x8, lsl #3
1000320b0:     	b.eq	0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
1000320b4:     	ldr	x8, [x8]
1000320b8:     	cbz	x8, 0x100032100 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
1000320bc:     	ldr	w9, [x0, #0x14]
1000320c0:     	ldr	w10, [x0, #0x1c]
1000320c4:     	mov	w1, w22
1000320c8:     	ldr	x8, [x8, #0x10]
1000320cc:     	ldp	x6, x2, [sp, #0x20]
1000320d0:     	orr	x3, x9, x10, lsl #32
1000320d4:     	ldrb	w4, [x0, #0x40]
1000320d8:     	ldr	x5, [sp, #0x18]
1000320dc:     	mov	x0, x8
1000320e0:     	bl	0x10004c238 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store>
1000320e4:     	mov	w3, w0
1000320e8:     	mov	x0, xzr
1000320ec:     	mov	x1, xzr
1000320f0:     	ldr	x8, [sp, #0x10]
1000320f4:     	tst	w3, #0xff
1000320f8:     	b.ne	0x10003206c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x1f8>
1000320fc:     	b	0x100032140 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2cc>
100032100:     	mov	w0, #0x1                ; =1
100032104:     	bl	0x100209bf0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100032108:     	ldp	x29, x30, [sp, #0xc0]
10003210c:     	ldp	x20, x19, [sp, #0xb0]
100032110:     	ldp	x22, x21, [sp, #0xa0]
100032114:     	ldp	x24, x23, [sp, #0x90]
100032118:     	ldp	x26, x25, [sp, #0x80]
10003211c:     	ldp	x28, x27, [sp, #0x70]
100032120:     	add	sp, sp, #0xd0
100032124:     	ret
100032128:     	ldp	x4, x1, [sp, #0x20]
10003212c:     	mov	x2, x19
100032130:     	ldr	x3, [sp, #0x18]
100032134:     	mov	x5, x27
100032138:     	mov	x6, x28
10003213c:     	bl	0x100054f3c <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100032140:     	ldr	w8, [x24, #0x8]
100032144:     	ldr	x9, [sp, #0x8]
100032148:     	cmn	w8, #0x1
10003214c:     	b.eq	0x100032160 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2ec>
100032150:     	cmp	x20, x8
100032154:     	b.ls	0x1000321bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x348>
100032158:     	add	x8, x25, x8, lsl #4
10003215c:     	stp	x0, x1, [x8]
100032160:     	add	w8, w9, #0x1
100032164:     	mov	w0, wzr
100032168:     	str	w8, [x23, #0x8]
10003216c:     	b	0x100032108 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x294>
100032170:     	mov	x0, x8
100032174:     	mov	x1, xzr
100032178:     	bl	0x1002057b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003217c:     	mov	x0, x9
100032180:     	mov	x1, x20
100032184:     	bl	0x1002057b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100032188:     	mov	x0, x13
10003218c:     	bl	0x100206d68 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100032190:     	mov	x0, x10
100032194:     	mov	w1, #0x1                ; =1
100032198:     	mov	w3, #0x2                ; =2
10003219c:     	bl	0x1002064cc <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000321a0:     	mov	x0, x9
1000321a4:     	mov	w1, #0x1                ; =1
1000321a8:     	mov	x2, x10
1000321ac:     	mov	w3, #0x3                ; =3
1000321b0:     	bl	0x1002064cc <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
1000321b4:     	mov	x0, x8
1000321b8:     	bl	0x100206d68 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000321bc:     	mov	x0, x8
1000321c0:     	mov	x1, x20
1000321c4:     	bl	0x1002057b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
