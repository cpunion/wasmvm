
/Users/lijie/source/goplus/wasmvm/artifacts/native-loop-poll-groups-20261117/base-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000322e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD>:
1000322e4:     	sub	sp, sp, #0xd0
1000322e8:     	stp	x28, x27, [sp, #0x70]
1000322ec:     	stp	x26, x25, [sp, #0x80]
1000322f0:     	stp	x24, x23, [sp, #0x90]
1000322f4:     	stp	x22, x21, [sp, #0xa0]
1000322f8:     	stp	x20, x19, [sp, #0xb0]
1000322fc:     	stp	x29, x30, [sp, #0xc0]
100032300:     	add	x29, sp, #0xc0
100032304:     	ldr	x9, [x0, #0x48]
100032308:     	sub	x8, x9, #0x1
10003230c:     	cbz	x9, 0x1000325e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x300>
100032310:     	ldr	x9, [x0, #0x40]
100032314:     	adds	x23, x9, x8, lsl #6
100032318:     	b.eq	0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
10003231c:     	ldr	x21, [x23]
100032320:     	cbz	x21, 0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
100032324:     	ldr	x8, [x21, #0x48]
100032328:     	ldr	w13, [x23, #0x8]
10003232c:     	ldr	x1, [x8, #0xb8]
100032330:     	cmp	x1, x13
100032334:     	b.ls	0x1000325fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x318>
100032338:     	ldr	x9, [x23, #0x18]
10003233c:     	ldr	x20, [x8, #0x98]
100032340:     	ldr	x2, [x0, #0x88]
100032344:     	add	x10, x20, x9
100032348:     	cmp	x10, x2
10003234c:     	b.hi	0x100032604 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x320>
100032350:     	cmp	x9, x10
100032354:     	b.hi	0x100032614 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x330>
100032358:     	ldr	x10, [x8, #0xb0]
10003235c:     	lsl	x11, x9, #4
100032360:     	ldr	x26, [x21, #0x40]
100032364:     	add	x24, x10, x13, lsl #5
100032368:     	sub	x10, x2, x9
10003236c:     	cmp	x10, #0x0
100032370:     	ldr	x10, [x0, #0x78]
100032374:     	ldr	w9, [x24, #0xc]
100032378:     	csel	x11, x11, xzr, gt
10003237c:     	ldr	w22, [x24]
100032380:     	add	x25, x10, x11
100032384:     	cmn	w9, #0x1
100032388:     	b.eq	0x1000323e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x100>
10003238c:     	cmp	x20, x9
100032390:     	b.ls	0x1000325f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x30c>
100032394:     	add	x9, x25, x9, lsl #4
100032398:     	ldp	x10, x19, [x9]
10003239c:     	ldr	w9, [x24, #0x10]
1000323a0:     	cmn	w9, #0x1
1000323a4:     	b.eq	0x1000323f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x114>
1000323a8:     	cmp	x20, x9
1000323ac:     	b.ls	0x1000325f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x30c>
1000323b0:     	ldr	q0, [x25, x9, lsl #4]
1000323b4:     	str	q0, [sp, #0x30]
1000323b8:     	ldp	x12, x11, [sp, #0x30]
1000323bc:     	ldr	w9, [x24, #0x14]
1000323c0:     	cmn	w9, #0x1
1000323c4:     	b.eq	0x10003240c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x128>
1000323c8:     	cmp	x20, x9
1000323cc:     	b.ls	0x1000325f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x30c>
1000323d0:     	ldr	q0, [x25, x9, lsl #4]
1000323d4:     	str	q0, [sp, #0x40]
1000323d8:     	ldp	x27, x28, [sp, #0x40]
1000323dc:     	cbnz	x0, 0x100032418 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x134>
1000323e0:     	b	0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
1000323e4:     	mov	x19, xzr
1000323e8:     	mov	x10, xzr
1000323ec:     	ldr	w9, [x24, #0x10]
1000323f0:     	cmn	w9, #0x1
1000323f4:     	b.ne	0x1000323a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0xc4>
1000323f8:     	mov	x12, xzr
1000323fc:     	mov	x11, xzr
100032400:     	ldr	w9, [x24, #0x14]
100032404:     	cmn	w9, #0x1
100032408:     	b.ne	0x1000323c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0xe4>
10003240c:     	mov	x27, xzr
100032410:     	mov	x28, xzr
100032414:     	cbz	x0, 0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
100032418:     	ldr	w1, [x24, #0x4]
10003241c:     	stp	x13, x0, [sp, #0x8]
100032420:     	add	x2, x0, #0x1d8
100032424:     	mov	x0, x8
100032428:     	stp	x12, x11, [sp, #0x18]
10003242c:     	str	x10, [sp, #0x28]
100032430:     	bl	0x1000e6fe0 <_github.com/cpunion/wasmvm/internal/compiler/slots.(*Function).ReadSource>
100032434:     	cbz	x0, 0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
100032438:     	and	w8, w22, #0xfffc
10003243c:     	and	w9, w22, #0xffff
100032440:     	cmp	w8, #0x54
100032444:     	ccmp	w9, #0xb, #0x0, ne
100032448:     	b.lo	0x100032458 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x174>
10003244c:     	sub	w10, w9, #0x5c
100032450:     	cmp	w10, #0x2
100032454:     	b.hs	0x1000324c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x1dc>
100032458:     	ldr	x1, [x26, #0x78]
10003245c:     	ldr	w8, [x0, #0x18]
100032460:     	cmp	x1, x8
100032464:     	b.ls	0x100032628 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x344>
100032468:     	ldr	x9, [x26, #0x70]
10003246c:     	adds	x8, x9, x8, lsl #3
100032470:     	b.eq	0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
100032474:     	ldr	x8, [x8]
100032478:     	cbz	x8, 0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
10003247c:     	ldr	x9, [x8, #0x10]
100032480:     	ldr	w8, [x0, #0x14]
100032484:     	ldr	w10, [x0, #0x1c]
100032488:     	ldrb	w4, [x0, #0x40]
10003248c:     	ldr	x11, [x9, #0x40]
100032490:     	orr	x3, x8, x10, lsl #32
100032494:     	cbz	x11, 0x1000324a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x1bc>
100032498:     	ldr	x8, [x9, #0x60]
10003249c:     	cbz	x8, 0x100032554 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x270>
1000324a0:     	ldp	x6, x2, [sp, #0x20]
1000324a4:     	add	x8, sp, #0x58
1000324a8:     	ldr	x5, [sp, #0x18]
1000324ac:     	mov	x0, x9
1000324b0:     	mov	w1, w22
1000324b4:     	add	x22, sp, #0x58
1000324b8:     	bl	0x10004e074 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
1000324bc:     	b	0x100032570 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x28c>
1000324c0:     	cmp	w9, #0xb
1000324c4:     	b.eq	0x1000324d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x1ec>
1000324c8:     	cmp	w8, #0x58
1000324cc:     	b.ne	0x10003259c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2b8>
1000324d0:     	ldr	x1, [x26, #0x78]
1000324d4:     	ldr	w8, [x0, #0x18]
1000324d8:     	cmp	x1, x8
1000324dc:     	b.ls	0x100032628 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x344>
1000324e0:     	ldr	x9, [x26, #0x70]
1000324e4:     	adds	x8, x9, x8, lsl #3
1000324e8:     	b.eq	0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
1000324ec:     	ldr	x8, [x8]
1000324f0:     	cbz	x8, 0x10003252c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x248>
1000324f4:     	ldr	w9, [x0, #0x14]
1000324f8:     	ldr	w10, [x0, #0x1c]
1000324fc:     	mov	w1, w22
100032500:     	ldr	x8, [x8, #0x10]
100032504:     	ldp	x6, x2, [sp, #0x20]
100032508:     	orr	x3, x9, x10, lsl #32
10003250c:     	ldrb	w4, [x0, #0x40]
100032510:     	ldr	x5, [sp, #0x18]
100032514:     	mov	x0, x8
100032518:     	bl	0x10004ba14 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store>
10003251c:     	mov	w3, w0
100032520:     	mov	x0, xzr
100032524:     	mov	x1, xzr
100032528:     	b	0x100032578 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x294>
10003252c:     	mov	w0, #0x1                ; =1
100032530:     	bl	0x100221638 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100032534:     	ldp	x29, x30, [sp, #0xc0]
100032538:     	ldp	x20, x19, [sp, #0xb0]
10003253c:     	ldp	x22, x21, [sp, #0xa0]
100032540:     	ldp	x24, x23, [sp, #0x90]
100032544:     	ldp	x26, x25, [sp, #0x80]
100032548:     	ldp	x28, x27, [sp, #0x70]
10003254c:     	add	sp, sp, #0xd0
100032550:     	ret
100032554:     	ldp	x6, x2, [sp, #0x20]
100032558:     	add	x8, sp, #0x58
10003255c:     	ldr	x5, [sp, #0x18]
100032560:     	mov	x0, x9
100032564:     	mov	w1, w22
100032568:     	add	x22, sp, #0x58
10003256c:     	bl	0x10004e19c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
100032570:     	ldp	x0, x1, [x22]
100032574:     	ldrb	w3, [x22, #0x10]
100032578:     	ldr	x8, [sp, #0x10]
10003257c:     	tst	w3, #0xff
100032580:     	b.eq	0x1000325b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2d0>
100032584:     	ldr	w2, [x24, #0x4]
100032588:     	mov	x0, x8
10003258c:     	mov	x1, x21
100032590:     	bl	0x100034668 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).failTrap>
100032594:     	mov	w0, #0x3                ; =3
100032598:     	b	0x100032534 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x250>
10003259c:     	ldp	x4, x1, [sp, #0x20]
1000325a0:     	mov	x2, x19
1000325a4:     	ldr	x3, [sp, #0x18]
1000325a8:     	mov	x5, x27
1000325ac:     	mov	x6, x28
1000325b0:     	bl	0x1000544b8 <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
1000325b4:     	ldr	w8, [x24, #0x8]
1000325b8:     	ldr	x9, [sp, #0x8]
1000325bc:     	cmn	w8, #0x1
1000325c0:     	b.eq	0x1000325d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x2f0>
1000325c4:     	cmp	x20, x8
1000325c8:     	b.ls	0x100032630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x34c>
1000325cc:     	add	x8, x25, x8, lsl #4
1000325d0:     	stp	x0, x1, [x8]
1000325d4:     	add	w8, w9, #0x1
1000325d8:     	mov	w0, wzr
1000325dc:     	str	w8, [x23, #0x8]
1000325e0:     	b	0x100032534 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSIMD+0x250>
1000325e4:     	mov	x0, x8
1000325e8:     	mov	x1, xzr
1000325ec:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000325f0:     	mov	x0, x9
1000325f4:     	mov	x1, x20
1000325f8:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000325fc:     	mov	x0, x13
100032600:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100032604:     	mov	x0, x10
100032608:     	mov	w1, #0x1                ; =1
10003260c:     	mov	w3, #0x2                ; =2
100032610:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100032614:     	mov	x0, x9
100032618:     	mov	w1, #0x1                ; =1
10003261c:     	mov	x2, x10
100032620:     	mov	w3, #0x3                ; =3
100032624:     	bl	0x10021df14 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100032628:     	mov	x0, x8
10003262c:     	bl	0x10021e7b0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100032630:     	mov	x0, x8
100032634:     	mov	x1, x20
100032638:     	bl	0x10021d1fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
