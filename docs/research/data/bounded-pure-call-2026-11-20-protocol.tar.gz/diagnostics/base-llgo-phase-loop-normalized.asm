stp	x28, x27, [sp, #-0x60]!
stp	x26, x25, [sp, #0x10]
stp	x24, x23, [sp, #0x20]
stp	x22, x21, [sp, #0x30]
stp	x20, x19, [sp, #0x40]
stp	x29, x30, [sp, #0x50]
add	x29, sp, #0x50
sub	sp, sp, #0x1d0
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x0, #0x48]
mov	x21, x0
cmp	x8, #0x1
b.lt	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
ldrb	w27, [x21, #0x20]
mov	x19, x1
str	w27, [sp, #0x24]
ldr	x9, [x21, #0x40]
add	x9, x9, x8, lsl #6
mov	x8, x9
str	x9, [sp, #0x30]
ldr	x10, [x8, #-0x40]!
sturb	wzr, [x9, #-0x30]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
cbz	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x15, [x10, #0x48]
cbz	x15, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [sp, #0x30]
ldr	x20, [x15, #0x98]
ldr	x2, [x21, #0x88]
ldur	x8, [x8, #-0x28]
add	x9, x20, x8
cmp	x9, x2
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
cmp	x8, x9
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f14>
ldr	x9, [sp, #0x30]
ldr	x22, [x15, #0xb8]
ldur	w0, [x9, #-0x38]
sub	x9, x2, x8
lsl	x8, x8, #4
cmp	x9, #0x0
csel	x8, x8, xzr, gt
cmp	x22, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
ldr	x9, [x21, #0x78]
ldr	x26, [x15, #0xb0]
mov	w24, w0
str	x10, [sp, #0x18]
ldr	x10, [x10, #0x40]
add	x23, x9, x8
str	x15, [sp, #0x38]
str	x10, [sp, #0x28]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe8>
add	w28, w24, #0x1
mov	w0, w28
mov	w24, w28
cmp	x22, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
add	x28, x26, x0, lsl #5
tbz	w27, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x12c>
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
mov	w9, #0xe0               ; =224
ldr	x8, [x15, #0x78]
umaddl	x25, w0, w9, x8
ldr	w8, [x25]
cmp	w8, #0x5
ccmp	w8, #0xb, #0x4, ne
ldr	x8, [x21, #0x150]
cset	w9, ne
subs	x8, x8, x9
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d68>
str	x8, [x21, #0x150]
add	x19, x19, #0x1
tst	x19, #0x3f
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
ldr	x8, [x21, #0x160]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x148>
ldar	w8, [x8]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x190>
ldr	x8, [x21, #0x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
ldr	x9, [x8, #0x8]
ldr	x0, [x21, #0x10]
ldrb	w9, [x9, #0x17]
and	w10, w9, #0x1f
and	w9, w9, #0x20
cmp	w10, #0x16
ccmp	w9, #0x0, #0x4, ne
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
stur	x0, [x29, #-0x78]
sub	x0, x29, #0x78
ldr	x8, [x8, #0x28]
blr	x8
ldr	x15, [sp, #0x38]
mov	x2, x1
cbnz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x19c>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
mov	x0, xzr
mov	x2, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a4>
ldr	x8, [x0, #0x8]
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e0c>
ldr	w8, [x28, #0x1c]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
tbz	w27, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
ldr	w9, [x28]
cmp	w9, #0x20
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
cmp	w9, #0x41
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
ldr	w9, [x28]
cmp	w9, #0x20
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dc>
cmp	w9, #0x41
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x228>
mvn	w8, w19
tst	x8, #0x3f
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
cmp	w9, #0x41
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x208>
ldr	w0, [x28, #0x8]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	w8, [x28, #0x18]
add	x9, x23, x0, lsl #4
stp	x8, xzr, [x9]
add	w24, w24, #0x1
cmp	x22, x24
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ecc>
add	x28, x26, x24, lsl #5
add	x19, x19, #0x1
ldr	w8, [x28, #0x1c]
cbnz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c8>
ldr	w9, [x28]
mov	w10, #0xff20            ; =65312
sub	w8, w9, #0xe0
movk	w10, #0xff, lsl #16
cmp	w8, w10
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c8>
lsr	w8, w9, #16
cmp	w8, #0xfb
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x418>
cmp	w8, #0xfc
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x320>
cmp	w8, #0xfd
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c0>
ldr	w0, [x28, #0xc]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x688>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
add	x8, x23, x0, lsl #4
ldp	x2, x8, [x8]
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x69c>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x70]
ldp	x5, x6, [sp, #0x70]
ldr	w0, [x28, #0x14]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6b0>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x80]
ldp	x10, x11, [sp, #0x80]
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6c8>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
sub	w8, w9, #0x45
cmp	w8, #0x80
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
cmp	w8, #0x7f
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a58>
adrp	x12, ADDR <dyld_stub_binder+ADDR>
add	x12, x12, #0x950
adr	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
ldrh	w11, [x12, x8, lsl #1]
add	x10, x10, x11, lsl #2
br	x10
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	x2, [x23, x8]
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xab8>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
mov	w8, #0xffed             ; =65517
movk	w8, #0xff03, lsl #16
add	w12, w9, w8
cmp	w12, #0x4
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c8>
ldp	w8, w0, [x28, #0x18]
ldr	x10, [x15, #0xd8]
add	w11, w8, w0
add	w2, w11, #0x2
cmp	x10, x2
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f68>
cmp	w8, w2
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f58>
sub	x10, x10, x8
lsl	x11, x8, #2
cmp	x10, #0x0
csel	x10, x11, xzr, gt
cmp	w2, w8
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
ldr	x11, [x15, #0xc8]
add	x11, x11, x10
ldr	w10, [x11]
cmp	x20, x10
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
sub	x1, x2, x8
cmp	x1, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f44>
ldr	w8, [x11, #0x4]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x10, x10, #4
lsl	x8, x8, #4
cmp	w12, #0x2
ldr	x14, [x23, x10]
ldr	x13, [x23, x8]
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7c4>
cmp	x1, #0x3
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa8>
ldr	w8, [x11, #0x8]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
cmp	x1, #0x3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
ldr	w10, [x11, #0xc]
cmp	x20, x10
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
lsl	x8, x8, #4
lsl	x10, x10, #4
ldr	x12, [x23, x8]
ldr	x8, [x23, x10]
mov	w10, #0x13              ; =19
movk	w10, #0xfc, lsl #16
cmp	w9, w10
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x980>
add	x10, x12, x14
orr	x9, x12, x14
and	x12, x12, x14
bic	x9, x9, x10
add	x8, x8, x13
orr	x9, x9, x12
add	x12, x8, x9, lsr #63
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
sub	w8, w9, #0x2
and	w9, w8, #0xffff
cmp	w9, #0x21
mov	x9, #0x3e0f             ; =15887
movk	x9, #0x1c00, lsl #16
cset	w10, lo
movk	x9, #0x1, lsl #32
lsr	x9, x9, x8
and	w9, w10, w9
tbz	w9, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x668>
ldr	w0, [x28, #0xc]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x40]
ldp	x3, x4, [sp, #0x40]
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x50]
ldp	x5, x6, [sp, #0x50]
and	w8, w8, #0xffff
cmp	w8, #0xc
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x89c>
ldr	w8, [x28, #0x18]
ldr	x1, [x15, #0xd0]
add	w0, w8, #0x2
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x15, #0xc8]
ldr	w0, [x8, x0, lsl #2]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	q0, [x23, x0, lsl #4]
str	q0, [sp, #0x60]
ldp	x7, x9, [sp, #0x60]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8a4>
cmp	w9, #0xe7
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
sub	w8, w9, #0x1
cmp	w8, #0xd3
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x58c>
adrp	x12, ADDR <dyld_stub_binder+ADDR>
add	x12, x12, #0xa50
mov	x0, xzr
adr	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f4>
ldrh	w11, [x12, x8, lsl #1]
add	x10, x10, x11, lsl #2
mov	x1, xzr
br	x10
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
mov	w10, #0xe0              ; =224
ldr	x8, [x15, #0x78]
umaddl	x10, w0, w10, x8
cbz	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x78]
ldr	w0, [x10, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x11, [x8]
cbz	x11, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	w8, [x28, #0xc]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
ldr	x0, [x11, #0x10]
lsl	x8, x8, #4
ldr	w11, [x10, #0x14]
ldr	w10, [x10, #0x1c]
ldr	x12, [x0, #0x40]
ldr	x2, [x23, x8]
orr	x3, x11, x10, lsl #32
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x574>
ldr	x8, [x0, #0x60]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x91c>
sub	x8, x29, #0x78
mov	w1, w9
mov	w4, wzr
mov	x5, xzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x754>
sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
cmp	w8, #0x8
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x760>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	w0, w9
mov	x2, xzr
ldr	x1, [x23, x8]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
mov	x25, x1
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
mov	w10, #0xe0              ; =224
ldr	x8, [x15, #0x78]
umaddl	x11, w0, w10, x8
cbz	x11, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x78]
ldr	w0, [x11, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x12, [x8]
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	w8, [x28, #0xc]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
ldr	w10, [x28, #0x10]
cmp	x20, x10
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f08>
ldr	x0, [x12, #0x10]
ldr	w12, [x11, #0x14]
lsl	x8, x8, #4
ldr	w11, [x11, #0x1c]
lsl	x10, x10, #4
ldr	x13, [x0, #0x40]
ldr	x2, [x23, x8]
orr	x3, x12, x11, lsl #32
ldr	x5, [x23, x10]
cbz	x13, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x658>
ldr	x8, [x0, #0x60]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
mov	w1, w9
mov	w4, wzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x85c>
ldr	x8, [sp, #0x30]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
ldr	x15, [sp, #0x38]
tst	w0, #0xff
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
mov	x8, xzr
mov	x2, xzr
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x280>
mov	x5, xzr
mov	x6, xzr
ldr	w0, [x28, #0x14]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2a0>
mov	x10, xzr
mov	x11, xzr
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
mov	w13, #0xe0              ; =224
ldr	x12, [x15, #0x78]
umaddl	x0, w0, w13, x12
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
and	w12, w9, #0xfffc
and	w13, w9, #0xffff
cmp	w12, #0x54
ccmp	w13, #0xb, #0x0, ne
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6f8>
sub	w14, w13, #0x5c
cmp	w14, #0x2
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f4>
ldr	x10, [sp, #0x28]
cbz	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x10, #0x78]
ldr	w8, [x0, #0x18]
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
ldr	x10, [x10, #0x70]
adds	x8, x10, x8, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x10, [x8, #0x10]
ldr	w8, [x0, #0x14]
ldr	w11, [x0, #0x1c]
ldrb	w4, [x0, #0x40]
ldr	x12, [x10, #0x40]
orr	x3, x8, x11, lsl #32
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x748>
ldr	x8, [x10, #0x60]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x934>
sub	x8, x29, #0x78
mov	x0, x10
mov	w1, w9
sub	x27, x29, #0x78
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
mov	w8, #-0x1000001         ; =-16777217
add	w8, w9, w8
cmp	w8, #0x8
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf2c>
mov	w10, #0x117             ; =279
lsr	w10, w10, w8
tbz	w10, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf1c>
and	w9, w9, #0xff
mov	w8, wzr
cmp	w9, #0x4
b.gt	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa5c>
cmp	w9, #0x2
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xae0>
cmp	w9, #0x3
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	w9, [x28, #0x1c]
ldr	w8, [x23, x8]
sub	w9, w9, #0x1
cmp	w9, w8
csel	w8, w9, w8, lo
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
umulh	x12, x13, x14
mov	w8, #0x13               ; =19
movk	w8, #0xfc, lsl #16
mul	x10, x13, x14
add	w8, w8, #0x2
cmp	w9, w8
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
and	x8, x13, x14, asr #63
and	x9, x14, x13, asr #63
add	x8, x9, x8
sub	x12, x12, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x99c>
cmp	w13, #0xb
ldr	x13, [sp, #0x28]
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x808>
cmp	w12, #0x58
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb98>
cbz	x13, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x13, #0x78]
ldr	w8, [x0, #0x18]
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
ldr	x10, [x13, #0x70]
adds	x8, x10, x8, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x8, #0x10]
ldr	w10, [x0, #0x14]
ldr	w11, [x0, #0x1c]
ldrb	w4, [x0, #0x40]
ldr	x12, [x8, #0x40]
orr	x3, x10, x11, lsl #32
cbz	x12, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x854>
ldr	x10, [x8, #0x60]
cbz	x10, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe38>
mov	x0, x8
mov	w1, w9
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
mov	w8, w0
mov	x0, xzr
mov	x1, xzr
and	w25, w8, #0xff
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
mov	x3, xzr
mov	x4, xzr
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x46c>
mov	x5, xzr
mov	x6, xzr
and	w8, w8, #0xffff
cmp	w8, #0xc
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x48c>
mov	x7, xzr
mov	x9, xzr
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
mov	w10, #0xe0              ; =224
ldr	x8, [x15, #0x78]
umaddl	x2, w0, w10, x8
cbz	x2, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x0, [x21]
ldr	x1, [sp, #0x28]
add	x8, sp, #0x90
str	x9, [sp]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
ldr	x25, [sp, #0xa0]
ldr	q0, [sp, #0x90]
cbz	x25, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8ec>
ldr	x8, [x25, #0x8]
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db8>
ldr	w0, [x28, #0x8]
ldr	x15, [sp, #0x38]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x908>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
str	q0, [x23, x0, lsl #4]
add	w28, w24, #0x1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9dc>
ldr	x0, [x28, #0x18]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
sub	x8, x29, #0x78
mov	w1, w9
mov	w4, wzr
mov	x5, xzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x940>
sub	x8, x29, #0x78
mov	x0, x10
mov	w1, w9
sub	x27, x29, #0x78
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
ldp	x0, x1, [x27]
ldrb	w25, [x27, #0x10]
ldr	w27, [sp, #0x24]
ldr	x15, [sp, #0x38]
tst	w25, #0xff
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
ldr	w8, [x28, #0x8]
cmn	w8, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
add	x8, x23, x8, lsl #4
stp	x0, x1, [x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd4>
sub	x10, x14, x12
eon	x9, x14, x12
bic	x12, x12, x14
and	x9, x10, x9
orr	x9, x9, x12
add	x8, x8, x9, lsr #63
sub	x12, x13, x8
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
add	w8, w0, #0x1
cmp	x1, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f00>
ldr	w9, [x11, x0, lsl #2]
cmp	x20, x9
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f38>
ldr	w0, [x11, x8, lsl #2]
add	x8, x23, x9, lsl #4
cmp	x20, x0
stp	x10, xzr, [x8]
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
add	x8, x23, x0, lsl #4
add	w28, w24, #0x1
stp	x12, xzr, [x8]
ldr	x8, [sp, #0x30]
stur	w28, [x8, #-0x38]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldr	w8, [x28, #0x18]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
add	x9, x23, x0, lsl #4
ldr	q0, [x9]
ldr	x1, [x9, #0x8]
str	q0, [x23, x8, lsl #4]
fmov	x0, d0
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0x14]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	w9, #0x10               ; =16
ldr	w8, [x23, x8]
cmp	w8, #0x0
mov	w8, #0xc                ; =12
csel	x8, x9, x8, eq
ldr	w0, [x28, x8]
cmp	x20, x0
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xde0>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
mov	w1, w9
mov	w4, wzr
mov	x6, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
cmp	w9, #0x9
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe54>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	x8, [x23, x8]
cmp	x8, #0x0
cset	w8, ne
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldr	x8, [x23, x8]
cmp	x8, #0x0
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
mov	x2, xzr
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	w0, w9
ldr	x1, [x23, x8]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
mov	x25, x1
ldr	x15, [sp, #0x38]
tst	w25, #0xff
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	w8, [x23, x8]
cmp	w8, #0x0
cset	w8, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
cmp	w9, #0x69
mov	x1, xzr
ldr	x8, [x23, x8]
mov	w9, w8
csel	x8, x9, x8, eq
lsr	x9, x8, #1
and	x8, x8, #ADDR
and	x9, x9, #ADDR
add	x8, x9, x8
lsr	x9, x8, #2
and	x8, x8, #ADDR
and	x9, x9, #ADDR
add	x8, x9, x8
add	x8, x8, x8, lsr #4
and	x8, x8, #ADDR
add	x8, x8, x8, lsr #8
add	x8, x8, x8, lsr #16
add	x8, x8, x8, lsr #32
and	x0, x8, #0x7f
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldrsw	x0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldr	w0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
mov	x1, x2
mov	x2, x8
mov	x3, x5
mov	x4, x6
mov	x5, x10
mov	x6, x11
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
ldr	x15, [sp, #0x38]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1810>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x78]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x25, [x8]
cbz	x25, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x25, #0x10]
ldr	x11, [x21]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bb8>
ldrb	w8, [x8, #0x31]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x60]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x58]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x9, x0, #4
ldrb	w10, [x8, #0x29]
ldr	x9, [x23, x9]
cmp	w10, #0x0
ldr	x10, [x8, #0x40]
mov	w11, w9
csel	x9, x9, x11, ne
cmp	x9, x10
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
ldr	x8, [x8, #0x38]
mov	x1, xzr
ldr	x0, [x8, x9, lsl #3]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x48]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x40]
mov	x1, xzr
ldr	x0, [x8, x0, lsl #3]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
add	x8, x23, x0, lsl #4
ldr	x0, [x8]
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e20>
ldr	x1, [x8, #0x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x90]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	w8, [x28, #0xc]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
ldr	x9, [sp, #0x28]
ldr	x9, [x9, #0x88]
add	x9, x9, x0, lsl #3
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x9, [x9]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	q0, [x23, x8, lsl #4]
mov	x0, xzr
mov	x1, xzr
str	q0, [x9, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x90]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x88]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldp	x0, x1, [x8, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x60]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x58]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x9, [x8]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldrb	w10, [x9, #0x29]
ldr	x12, [x9, #0x40]
ldr	x8, [x23, x8]
cmp	w10, #0x0
mov	w11, w8
csel	x10, x8, x11, ne
cmp	x10, x12
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e00>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x8, x8, #4
ldr	x9, [x9, #0x38]
mov	x0, xzr
mov	x1, xzr
ldr	x8, [x23, x8]
str	x8, [x9, x10, lsl #3]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0x18]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
add	x8, x23, x0, lsl #4
ldp	x0, x1, [x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [sp, #0x28]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x8, #0x78]
ldr	w0, [x28, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x8, #0x70]
adds	x8, x8, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x8, [x8]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x0, [x8, #0x10]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages>
ldr	x15, [sp, #0x38]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0x18]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
mov	x0, x8
mov	w1, w9
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
mov	w25, w0
mov	x0, xzr
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
cmp	w9, #0x5
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
ldr	w9, [x28, #0x18]
ldr	x1, [x15, #0xe8]
add	w0, w9, w8
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x15, #0xe0]
mov	w9, #0xc                ; =12
umaddl	x8, w0, w9, x8
ldp	w28, w25, [x8]
ldr	w27, [x8, #0x8]
cmp	w28, w24
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
mov	x0, x21
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).poll>
ldr	x15, [sp, #0x38]
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea4>
ldr	x8, [x0, #0x8]
cbnz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e08>
ldr	x8, [x15, #0x108]
add	w2, w27, w25
cmp	x8, x2
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f8c>
cmp	w25, w2
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f7c>
sub	x8, x8, x25
lsl	x9, x25, #3
cmp	x8, #0x0
csel	x8, x9, xzr, gt
cbz	w27, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
ldr	x9, [x15, #0xf8]
ldr	w27, [sp, #0x24]
add	x8, x9, x8
sub	x9, x2, x25
add	x10, x8, #0x4
ldr	w0, [x10]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
ldur	w8, [x10, #-0x4]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
ldr	q0, [x23, x0, lsl #4]
subs	x9, x9, #0x1
add	x10, x10, #0x8
str	q0, [x23, x8, lsl #4]
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xee4>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
ldr	w27, [sp, #0x24]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xd8>
cmp	w8, #0x3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d38>
cmp	w8, #0x6
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce8>
sub	w8, w9, #0x12
cmp	w8, #0x4
b.lo	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d10>
ldr	w0, [x28, #0xc]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aa0>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	x5, [x23, x8]
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ab0>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	x7, [x23, x8]
ldr	w0, [x28, #0x14]
cmn	w0, #0x1
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ac0>
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ed8>
lsl	x8, x0, #4
ldr	x10, [x23, x8]
and	w8, w9, #ADDR
cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ad0>
and	w4, w9, #0xffff
cmp	w4, #0x3
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c28>
ldr	x8, [x21]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x0, [x8, #0x8]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
ldr	x15, [sp, #0x38]
mov	x0, xzr
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
eor	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
lsr	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
asr	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
orr	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
lsl	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
orr	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldr	x8, [x23, x8]
rbit	x8, x8
clz	x0, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, lo
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, ls
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, hi
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
sub	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	w11, #0x20              ; =32
mov	w12, #0x18              ; =24
mov	x1, xzr
ldr	w8, [x23, x8]
lsr	w9, w8, #16
cmp	w9, #0x0
csel	w8, w9, w8, ne
mov	x9, #-0x10              ; =-16
lsr	w10, w8, #8
csel	x9, x9, xzr, ne
cmp	w8, #0xff
csel	w8, w10, w8, hi
adrp	x10, ADDR <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x1618>
add	x10, x10, #0x17d
and	x8, x8, #0xff
ldrb	w8, [x10, x8]
csel	x10, x12, x11, hi
add	x9, x10, x9
sub	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
lsr	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, gt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, lt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, ne
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
ldr	w8, [x23, x8]
cbz	w8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cbc>
rbit	w8, w8
mov	x1, xzr
clz	w0, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, ne
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, le
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x8, x8, #4
lsl	x9, x0, #4
mov	x1, xzr
ldr	w8, [x23, x8]
ldr	w9, [x23, x9]
neg	w8, w8
ror	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, ls
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, ge
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldr	w8, [x23, x8]
cmp	w8, #0x0
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, lo
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
add	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
eor	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
and	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
sub	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x8, x8, #4
lsl	x9, x0, #4
ldr	w8, [x23, x8]
ldr	x9, [x23, x9]
neg	w8, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x177c>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, hs
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
mul	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, le
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, gt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
ror	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, lt
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
ror	x0, x9, x8
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
cmp	w9, w8
cset	w0, hi
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldrsb	x0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldrsh	x0, [x23, x8]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, hs
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
cmp	x9, x8
cset	w0, ge
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
asr	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
and	w0, w9, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	w9, [x23, x9]
ldr	w8, [x23, x8]
add	w0, w8, w9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
mul	x0, x8, x9
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldrsb	x8, [x23, x8]
mov	w0, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	w10, #0x20              ; =32
mov	x1, xzr
ldr	x8, [x23, x8]
lsr	x9, x8, #32
cmp	x9, #0x0
csel	x8, x9, x8, ne
csel	x10, x10, xzr, ne
lsr	x9, x8, #16
cmp	x9, #0x0
csel	x8, x9, x8, ne
orr	x9, x10, #0x10
lsr	x11, x8, #8
csel	x9, x9, x10, ne
cmp	x8, #0xff
orr	x10, x9, #0x8
csel	x8, x11, x8, hi
adrp	x11, ADDR <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0x1618>
add	x11, x11, #0x17d
and	x8, x8, #0xff
csel	x9, x10, x9, hi
mov	w10, #0x40              ; =64
ldrb	w8, [x11, x8]
sub	x9, x10, x9
sub	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
ldr	w8, [x28, #0x10]
cmp	x20, x8
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef4>
lsl	x9, x0, #4
lsl	x8, x8, #4
mov	x1, xzr
ldr	x9, [x23, x9]
ldr	x8, [x23, x8]
lsl	x0, x9, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x8, x0, #4
mov	x1, xzr
ldrsh	x8, [x23, x8]
mov	w0, w8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
sub	w8, w9, #0x8b
cmp	w8, #0x34
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a78>
mov	x10, #-ADDR       ; =-268435457
movk	x10, #0xfff9, lsl #32
movk	x10, #0x1f, lsl #48
lsr	x8, x10, x8
tbnz	w8, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
sub	w8, w9, #0x61
mov	x0, xzr
cmp	w8, #0x21
b.hi	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ce0>
mov	x10, #ADDR       ; =16106127360
mov	x1, x0
movk	x10, #0xf03f
lsr	x8, x10, x8
tbnz	w8, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f4>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
mov	x5, xzr
ldr	w0, [x28, #0x10]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf60>
mov	x7, xzr
ldr	w0, [x28, #0x14]
cmn	w0, #0x1
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf7c>
mov	x10, xzr
and	w8, w9, #ADDR
cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf98>
mov	w8, #0xffed             ; =65517
movk	w8, #0xff03, lsl #16
add	w8, w8, w9
add	w8, w8, #0xb
cmp	w8, #0xa
b.hs	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x15, #0x78]
mov	w9, #0xe0               ; =224
umaddl	x8, w0, w9, x8
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	w9, [x8]
ldr	x11, [x8, #0x8]
add	x12, sp, #0xd8
ldr	q0, [x8, #0x10]
ldur	q1, [x8, #0x48]
add	x2, sp, #0xd8
str	w9, [sp, #0xd8]
ldur	q2, [x8, #0x68]
mov	x0, x21
str	x11, [sp, #0xe0]
ldp	x9, x11, [x8, #0x20]
str	q0, [x12, #0x10]
mov	x3, x5
mov	x4, xzr
ldr	q0, [x8, #0x30]
stur	q1, [x12, #0x48]
mov	x5, x7
stp	x9, x11, [sp, #0xf8]
ldrb	w9, [x8, #0x40]
mov	x6, xzr
str	q0, [x12, #0x30]
ldur	q0, [x8, #0x58]
mov	x7, x10
strb	w9, [sp, #0x118]
ldur	q1, [x8, #0x78]
ldr	x1, [sp, #0x28]
stur	q0, [x12, #0x58]
ldur	q0, [x8, #0x88]
ldp	x9, x8, [x8, #0x98]
stur	q2, [x12, #0x68]
stur	q1, [x12, #0x78]
stur	q0, [x12, #0x88]
stp	x9, x8, [sp, #0x170]
add	x8, sp, #0xb0
str	xzr, [sp]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
ldp	x0, x1, [sp, #0xb0]
ldr	x8, [sp, #0xc8]
ldrb	w25, [sp, #0xc0]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
ldr	x9, [x8, #0x8]
ldr	x15, [sp, #0x38]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eb4>
mov	w0, #0x1                ; =1
str	x11, [sp, #0x10]
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
ldr	x11, [sp, #0x10]
ldr	w0, [x28, #0xc]
cmp	x20, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef8>
lsl	x9, x0, #4
tst	w8, #0x1
mov	x0, x11
mov	x1, x25
ldr	x9, [x23, x9]
mov	w10, w9
csel	x2, x9, x10, ne
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
tbz	w1, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
ldr	x15, [sp, #0x38]
mov	x1, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [x25, #0x10]
ldr	x15, [sp, #0x38]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cc8>
ldrb	w8, [x8, #0x31]
mov	x1, xzr
cmp	w8, #0x0
mov	w8, #-0x1               ; =-1
csinv	x0, x8, xzr, eq
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x1, [x15, #0x80]
ldr	w0, [x28, #0x4]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x8, [x15, #0x78]
mov	w9, #0xe0               ; =224
umaddl	x8, w0, w9, x8
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x9, [sp, #0x28]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x1, [x9, #0x78]
ldr	w0, [x8, #0x18]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
ldr	x9, [x9, #0x70]
adds	x9, x9, x0, lsl #3
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldr	x9, [x9]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d58>
ldp	x11, x1, [x21]
ldr	w12, [x8, #0x14]
ldr	w8, [x8, #0x1c]
ldr	x0, [x9, #0x10]
ldr	x2, [x21, #0x10]
ldr	x3, [x11, #0x8]
orr	x6, x12, x8, lsl #32
sub	x8, x29, #0xa0
str	x10, [sp]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
ldp	x0, x1, [x29, #-0xa0]
ldur	x8, [x29, #-0x88]
ldurb	w25, [x29, #-0x90]
cbz	x8, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x954>
ldr	x9, [x8, #0x8]
ldr	x15, [sp, #0x38]
cbz	x9, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x958>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ebc>
mov	x1, xzr
mov	w0, #0x20               ; =32
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
ldr	x15, [sp, #0x38]
mov	x1, xzr
mov	w0, #-0x1               ; =-1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
mov	x1, x0
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x960>
ldr	x8, [sp, #0x30]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
tst	w0, #0xff
b.ne	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1db0>
ldr	x8, [x21, #0x48]
cmp	x8, #0x0
b.gt	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x40>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fcc>
ldr	x8, [sp, #0x30]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
ldr	x8, [sp, #0x30]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1cf8>
ldr	x8, [sp, #0x30]
mov	x0, x21
stur	w24, [x8, #-0x38]
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
tst	w0, #0xff
b.eq	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d00>
mov	w0, #0x1                ; =1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
mov	x0, xzr
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
mov	w0, #0x28               ; =40
bl	ADDR <dyld_stub_binder+ADDR>
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
mov	x20, x0
mov	w0, #0x28               ; =40
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
ldr	x8, [x25, #0x8]
adrp	x9, ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x2>
adrp	x10, ADDR <dyld_stub_binder+ADDR>
add	x10, x10, #0x248
ldr	q0, [x9, #0xe10]
adrp	x1, ADDR <__llgo_struct$q3PA0LZP97wpNbxg_ocAy1psepid_kL-4QjthQQIIOw$fields+0x58>
add	x1, x1, #0x5e8
stp	x8, x10, [x20, #0x10]
mov	w8, #0xe                ; =14
str	q0, [x20]
str	x8, [x20, #0x20]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
and	x0, x0, #0xff
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e90>
ldr	x20, [sp, #0xa8]
mov	w0, #0x8                ; =8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.AllocZ>
mov	x22, x0
adrp	x2, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe8>
add	x2, x2, #0x5e0
mov	x0, x25
mov	x1, x20
mov	x3, x22
bl	ADDR <_errors.As>
tbz	w0, #0x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1df4>
ldr	x9, [sp, #0x18]
ldr	x8, [x22]
ldr	w9, [x9, #0x50]
str	w9, [x8, #0x4]
mov	x0, x21
mov	x1, x25
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e84>
mov	w25, #0x3               ; =3
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
mov	x2, x1
mov	x1, x0
mov	x0, x21
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
mov	w25, #0x1               ; =1
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e24>
mov	w25, #0x9               ; =9
mov	w0, #0x10               ; =16
bl	ADDR <dyld_stub_binder+ADDR>
cbz	x0, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ffc>
mov	x20, x0
mov	w0, #0x10               ; =16
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
ldr	x9, [sp, #0x38]
stp	xzr, xzr, [x20]
ldr	w0, [x28, #0x4]
ldr	x1, [x9, #0x80]
cmp	x1, x0
b.ls	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ef0>
mov	w8, #0xe0               ; =224
ldr	x9, [x9, #0x78]
adrp	x1, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe8>
add	x1, x1, #0x948
umaddl	x8, w0, w8, x9
ldr	x9, [sp, #0x18]
ldr	w9, [x9, #0x50]
ldr	x8, [x8, #0x8]
strb	w25, [x20]
str	w9, [x20, #0x4]
str	x8, [x20, #0x8]
mov	x0, x21
mov	x2, x20
bl	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
mov	w0, #0x3                ; =3
mov	x1, x19
add	sp, sp, #0x1d0
ldp	x29, x30, [sp, #0x50]
ldp	x20, x19, [sp, #0x40]
ldp	x22, x21, [sp, #0x30]
ldp	x24, x23, [sp, #0x20]
ldp	x26, x25, [sp, #0x10]
ldp	x28, x27, [sp], #0x60
ret
ldr	x2, [sp, #0xd0]
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ec0>
ldur	x2, [x29, #-0x80]
mov	x0, x21
mov	x1, x8
b	ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e88>
mov	x0, x24
mov	x1, x22
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x1, x20
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, x8
mov	x1, x20
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x1, x22
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x8
mov	x1, x20
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x8
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x10
mov	x1, x20
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	x0, x8
mov	w1, #0x1                ; =1
mov	x2, x9
mov	w3, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x9
mov	w1, #0x1                ; =1
mov	w3, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x9
mov	x1, x20
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
mov	w0, #0x1                ; =1
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, xzr
mov	x1, xzr
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	x0, x8
mov	w1, wzr
mov	w3, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x2
mov	w1, wzr
mov	x2, x10
mov	w3, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x25
mov	w1, wzr
mov	w3, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	x0, x2
mov	w1, wzr
mov	x2, x8
mov	w3, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
mov	w0, #0x3                ; =3
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
mov	w0, #0x2                ; =2
mov	w1, #0x2                ; =2
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
adrp	x0, ADDR <__llgo_func$5y6TRKwaWPE10AAwnlBqoVZEnFOulgb5ezY7raDDgrY+0x20>
add	x0, x0, #0xcb0
adrp	x1, ADDR <__llgo_func$5y6TRKwaWPE10AAwnlBqoVZEnFOulgb5ezY7raDDgrY+0x20>
add	x1, x1, #0xf30
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
adrp	x0, ADDR <__llgo_ifacebox$zXm49YsusR3kQeeT96v8-x7XU5uG33uVOfGq27_toEE>
add	x0, x0, #0x5e8
adrp	x1, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe8>
add	x1, x1, #0x630
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
adrp	x0, ADDR <__llgo_ifacebox$zXm49YsusR3kQeeT96v8-x7XU5uG33uVOfGq27_toEE>
add	x0, x0, #0x5e8
adrp	x1, ADDR <_github.com/cpunion/wasmvm/internal/engine/execute.struct$-smIeuD2cU3qbkgav4Gdn_RKmNrg2ddsW15iZrQE2Bg$fields+0xe8>
add	x1, x1, #0x640
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
adrp	x0, ADDR <__llgo_ifacebox$zXm49YsusR3kQeeT96v8-x7XU5uG33uVOfGq27_toEE>
add	x0, x0, #0x5e8
adrp	x1, ADDR <__llgo_func$5y6TRKwaWPE10AAwnlBqoVZEnFOulgb5ezY7raDDgrY+0x20>
add	x1, x1, #0xca0
bl	ADDR <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
brk	#0x1
