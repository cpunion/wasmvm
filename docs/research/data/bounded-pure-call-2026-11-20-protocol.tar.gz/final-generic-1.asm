	stp	x29, x30, [sp, #-16]!
	mov	x29, sp
	stp	x19, x20, [sp, #-16]!
	stp	x21, x22, [sp, #-16]!
	stp	x23, x24, [sp, #-16]!
	stp	x25, x26, [sp, #-16]!
	stp	x27, x28, [sp, #-16]!
	stp	q8, q9, [sp, #-32]!
	stp	q10, q11, [sp, #-32]!
	stp	q12, q13, [sp, #-32]!
	stp	q14, q15, [sp, #-32]!
	mov	x26, #-1                        // =0xffffffffffffffff
	ldr	x28, [x0, #32]
	ldr	x27, [x0, #40]
	ldr	x12, [x0, #8]
	ldr	x13, [x0, #32]
	ldr	x9, [x0, #16]
	sub	x9, x9, x13
	mov	w10, #80                        // =0x50
	cmp	x9, x10
	b.lo	#944
	and	x9, x13, #0xf
	cmp	x9, #0
	b.ne	#932
	add	x12, x12, x13
	mov	w9, #0                          // =0x0
	str	x9, [x0, #72]
	ldr	x9, [x0, #56]
	mov	w10, #15                        // =0xf
	cmp	x9, x10
	b.hs	#904
	ldr	x9, [x0, #128]
	cmp	x9, #0
	b.eq	#892
	ldr	x9, [x0, #56]
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#8
	ldr	x26, [x11]
	mov	w1, #23721                      // =0x5ca9
	movk	w1, #5944, lsl #16
	mov	w2, #10546                      // =0x2932
	movk	w2, #18256, lsl #16
	ldr	x19, [x12, #64]
	ldr	x20, [x12]
	ldr	x21, [x12, #32]
	ldr	x22, [x12, #48]
	ldr	x23, [x12, #16]
	ldr	x9, [x0, #136]
	cmp	x9, #0
	b.ne	#824
	ldr	x9, [x0, #56]
	adr	x13, #16
	ldrsw	x14, [x13, x9, lsl #2]
	add	x13, x13, x14
	br	x13
	udf	#60
	udf	#72
	udf	#316
	udf	#316
	udf	#384
	udf	#328
	udf	#328
	udf	#392
	udf	#400
	udf	#332
	udf	#332
	udf	#408
	udf	#356
	udf	#356
	udf	#372
	ldr	x9, [x0, #144]
	cbnz	x9, #360
	b	#248
	ldr	x9, [x0, #144]
	cbnz	x9, #396
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#184
	cmp	x26, #0
	b.eq	#176
	mov	x16, x22
	ldr	x11, [x0, #120]
	mov	x9, x26
	sub	x9, x9, #1
	ldr	x10, [x11, #32]
	cmp	x9, x10
	b.hs	#8
	str	x9, [x11, #32]
	add	x9, x9, x9, lsl #1
	add	x14, x11, x9, lsl #3
	add	x14, x14, #40
	ldr	x15, [x14, #8]
	ldr	x9, [x0, #8]
	add	x15, x15, x9
	mov	x10, x16
	ldr	x11, [x12, #56]
	ldr	x13, [x14, #16]
	sub	x13, x13, #4
	ldr	w9, [x13]
	lsl	x9, x9, #4
	add	x9, x9, x15
	stp	x10, x11, [x9]
	ldr	x9, [x0, #144]
	cmp	x9, #0
	b.ne	#28
	ldr	x28, [x14, #8]
	sub	x27, x27, #1
	sub	x26, x26, #1
	ldr	x9, [x14, #16]
	br	x9
	udf	#3
	dmb	ishld
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #56]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #112]
	mov	x10, #1                         // =0x1
	b	#648
	mov	w9, #1                          // =0x1
	str	x9, [x0, #56]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #1                         // =0x1
	b	#604
	ldr	x9, [x0, #144]
	cbnz	x9, #200
	madd	w20, w20, w1, w2
	add	w21, w21, #1
	cmp	w21, w23
	cset	w19, lo
	ldr	x9, [x0, #144]
	cbnz	x9, #224
	b.lo	#-32
	b	#20
	ldr	x9, [x0, #144]
	cbnz	x9, #256
	mov	x22, x20
	b	#-296
	ldr	x9, [x0, #144]
	cbnz	x9, #288
	b	#-24
	mov	x20, x19
	b	#-60
	add	w19, w21, w19
	b	#4
	mov	x21, x19
	b	#-72
	ldr	x9, [x0, #144]
	cbnz	x9, #300
	cbnz	w19, #-100
	b	#-48
	dmb	ishld
	mov	w9, #0                          // =0x0
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#448
	dmb	ishld
	mov	w9, #1                          // =0x1
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#400
	dmb	ishld
	mov	w9, #3                          // =0x3
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#352
	dmb	ishld
	mov	w9, #11                         // =0xb
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#304
	dmb	ishld
	mov	w9, #13                         // =0xd
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#256
	dmb	ishld
	mov	w9, #14                         // =0xe
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#208
	dmb	ishld
	mov	w9, #11                         // =0xb
	str	x9, [x0, #56]
	mov	w9, #0                          // =0x0
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #6                         // =0x6
	b	#160
	mov	x20, x16
	mov	x23, x17
	mov	w1, #23721                      // =0x5ca9
	movk	w1, #5944, lsl #16
	mov	w2, #10546                      // =0x2932
	movk	w2, #18256, lsl #16
	ldr	x19, [x12, #64]
	ldr	x21, [x12, #32]
	ldr	x22, [x12, #48]
	b	#-736
	mov	x9, #-1                         // =0xffffffffffffffff
	cmp	x26, x9
	b.eq	#20
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#8
	str	x26, [x11]
	str	x28, [x0, #32]
	str	x27, [x0, #40]
	mov	w0, #11                         // =0xb
	b	#124
	mov	w9, #7                          // =0x7
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #2                         // =0x2
	b	#40
	mov	w9, #6                          // =0x6
	str	x9, [x0, #112]
	str	x19, [x12, #64]
	str	x20, [x12]
	str	x21, [x12, #32]
	str	x22, [x12, #48]
	str	x23, [x12, #16]
	mov	x10, #2                         // =0x2
	b	#4
	mov	x9, #-1                         // =0xffffffffffffffff
	cmp	x26, x9
	b.eq	#20
	ldr	x11, [x0, #120]
	cmp	x11, #0
	b.eq	#8
	str	x26, [x11]
	str	x28, [x0, #32]
	str	x27, [x0, #40]
	mov	w9, #1                          // =0x1
	str	x9, [x0, #48]
	mov	w0, w10
	ldp	q14, q15, [sp], #32
	ldp	q12, q13, [sp], #32
	ldp	q10, q11, [sp], #32
	ldp	q8, q9, [sp], #32
	ldp	x27, x28, [sp], #16
	ldp	x25, x26, [sp], #16
	ldp	x23, x24, [sp], #16
	ldp	x21, x22, [sp], #16
	ldp	x19, x20, [sp], #16
	ldp	x29, x30, [sp], #16
	ret
