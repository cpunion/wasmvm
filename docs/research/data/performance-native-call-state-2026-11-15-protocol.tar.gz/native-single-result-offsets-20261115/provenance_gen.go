package phase
func init(){sourceRevision="0baaf03e7c760b968638cc764a1f649e03dce407+single-result-offset-prototype";compilerRevision="go1.27.3"}
