from pathlib import Path
import gzip,hashlib,json,statistics,subprocess,tarfile
D=Path(__file__).resolve().parent;A=D.parent;W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');P=A/'native-function-state-20261115';R=A/'native-single-result-offsets-20261115';T=A/'native-call-stack-20261115';name='performance-native-call-state-2026-11-15'
cohorts=[(R,n)for n in ['counter-screen','counter-early-destination']]+[(P,n)for n in ['counter-screen','result-counter-screen','counter-final','core-final','final-16','final-65536','no-gc-16','no-gc-65536','fresh-counter-screen','top-counter-screen']]+[(T,n)for n in ['counter-final','core-final','final-16','final-65536','no-gc-16','no-gc-65536']]+[(D,n)for n in ['counter-final','core-final','final-16','final-65536','no-gc-16','no-gc-65536','sharing-audit']]
def read(p):return json.loads(p.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def project(v):
 if isinstance(v,list):return[project(x)for x in v]
 if not isinstance(v,dict):return v
 return{k:(dict(count=len(x),minimum=min(x)if x else None,maximum=max(x)if x else None,canonicalJSONSHA256=hashlib.sha256(json.dumps(x,separators=(',',':')).encode()).hexdigest())if k in('RequestNs','PublicAPINs')and isinstance(x,list)else project(x))for k,x in v.items()}
evidence=W/'docs/research/evidence'/f'{name}.jsonl.gz';counts={};gc={}
with gzip.open(evidence,'wt',compresslevel=9)as output:
 for root,folder in cohorts:
  p=root/folder;compressed=p/'rows.jsonl.gz'
  with(gzip.open(compressed,'rt')if compressed.exists()else(p/'rows.jsonl').open())as stream:rows=[json.loads(l)for l in stream]
  key=root.name+'/'+folder;counts[key]=len(rows)
  for row in rows:output.write(json.dumps(dict(cohort=key,**project(row)),separators=(',',':'))+'\n')
  if 'service'not in rows[0].get('record',{}):continue
  gc[key]={};end=8 if folder.startswith('no-gc')else 23
  for role in sorted({r['id']for r in rows if not r['id'].endswith('-aa')}):
   rr=[r for r in rows if r['id']in(role,role+'-aa')];cc=[sum(b['GCAfter']-b['GCBefore']for b in r['record']['service']['Batches'][3:end])for r in rr];heaps=[r['record']['service']['Batches'][3]['HeapBefore']for r in rr];buckets={}
   for row,n in zip(rr,cc):buckets.setdefault(n,[]).append(row['cpuUs'])
   gc[key][role]=dict(collectionsMedian=statistics.median(cc),collectionsRange=[min(cc),max(cc)],initialHeapMedian=statistics.median(heaps),cpuUsByCollectionCount={k:dict(processes=len(v),median=statistics.median(v))for k,v in sorted(buckets.items())})
assert sum(counts.values())==1748,counts
protocol=W/'docs/research/data'/f'{name}-protocol.tar.gz'
with tarfile.open(protocol,'w:gz')as archive:
 for root in [R,P,T,D]:
  for p in sorted(root.rglob('*')):
   if p.is_file()and not p.is_symlink()and p.suffix in('.go','.py','.json','.log','.txt','.patch','.stderr','.stdout'):
    archive.add(p,arcname=root.name+'/'+str(p.relative_to(root)))
 fixture=A/'native-frame-deltas-20261114/generic-calls.wasm';archive.add(fixture,arcname='fixtures/'+fixture.name)
identity=read(D/'committed-identity.json')
report=dict(base=identity['base'],reusedBaseSource=identity['reusedBaseSource'],source=identity['source'],sourceTree=subprocess.check_output(['git','rev-parse',identity['source']+'^{tree}'],cwd=W,text=True).strip(),identityQualification=identity['baseQualification'],host='Apple M4 Max, darwin/arm64; other user tests/compiler/link and desktop activity observed. Absolute times across cohorts are not comparable; snapshots and A/A controls qualify every claim.',profile=identity['profile'],references=dict(wazero='1.12.0',wasmtime='48.0.1',wasmer='7.3.0',nativeC='Frozen unchecked LLVM22 affine oracle, 2N steps normalized per guest iteration, without VM limits/cancellation/frame contract.'),identity=identity,finalComparisons=read(D/'analysis.json'),sharingAudit=read(D/'sharing-audit/analysis.json'),intermediateComparisons=read(P/'analysis.json'),unsharedTopComparisons=read(T/'analysis.json'),entryTopExperiments=read(P/'entry-top-analysis.json'),rejectedOffsets=read(R/'analysis.json'),GCObservations=gc,imageAudit=read(D/'image-audit/identity.json'),validation=dict(Go='32 root test packages pass; all 31 measured executable packages >=90% statement coverage.',LLGo='Affected codegen/nativeexec and complete-word/scratch probes execute with -O3 -lto=full. Complete final-head Go/LLGo x Linux amd64/macOS arm64 CI required before merge.',cases='Three state registers excluded from allocation, large result sources/high words, borrowed scratch fallback, malformed header/view sentinel, function identity/import prefixes and parallel ordering; existing full proposals/roots/quotas/reentry/cancellation/cleanup/WASI stay green.'),interpretation='See the accompanying study for exact final-source comparisons. Full values, quotas, roots, precise fuel and cancellation stay intact. All cold/LLGo adverse points, unresolved controls and discarded variants remain distinct. Shared status publication resolves observed image growth without changing record layout. No competitive, milestone or release acceptance.',protocolErrata='Earlier result-offset identity calls.go hash denotes retained calls-late-destination.go. The initial uncommitted offset implementation restored the destination as the parent frame; corrected before timing. Carrier-audit initial stderr is a missing interactive acknowledgement, not an engine failure. Every cohort retains its original plan/sourceRevision/hash; experiments are not pooled or substituted.',evidence=dict(path='../evidence/'+evidence.name,records=sum(counts.values()),cohorts=counts,sha256=digest(evidence),projection='Only unused RequestNs/PublicAPINs vectors become count/extrema/canonical-JSON SHA256. Full originals retained locally. All process phases, outputs, rusage, GC/allocation counters and orders remain.'),protocol=dict(path=protocol.name,sha256=digest(protocol)))
p=W/'docs/research/data'/f'{name}.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(records=sum(counts.values()),reportBytes=p.stat().st_size,evidenceBytes=evidence.stat().st_size,protocolBytes=protocol.stat().st_size),indent=2))
