package phase
func init(){sourceRevision="9de037fbef8f0e99a56175141233258ef426aa70";compilerRevision="go1.27.3"}
