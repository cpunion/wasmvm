package phase
func init(){sourceRevision="7b79ae65fe5b9fc6b14a0bbdf204fa516876edae";compilerRevision="go1.27.3"}
