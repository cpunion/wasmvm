from pathlib import Path
import ctypes,json,os,random,re,statistics,subprocess,threading

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/lijie/source/goplus/wasmvm')
header=Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sys/resource.h').read_text()
body=header.split('struct rusage_info_v4 {',1)[1].split('};',1)[0]
fields=re.findall(r'uint64_t\s+(ri_\w+);',body)
class Info(ctypes.Structure):_fields_=[('ri_uuid',ctypes.c_ubyte*16)]+[(n,ctypes.c_uint64)for n in fields]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
names=['ri_user_time','ri_system_time','ri_instructions','ri_cycles','ri_pkg_idle_wkups','ri_interrupt_wkups','ri_phys_footprint','ri_lifetime_max_phys_footprint','ri_runnable_time']
def snapshot(pid):
 info=Info();result=lib.proc_pid_rusage(pid,4,ctypes.byref(info))
 if result:raise OSError(ctypes.get_errno(),'proc_pid_rusage')
 return {n:int(getattr(info,n)) for n in names}
assert snapshot(os.getpid())['ri_user_time']>0
class Timebase(ctypes.Structure):
 _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
system=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
system.mach_timebase_info.argtypes=[ctypes.POINTER(Timebase)]
system.mach_timebase_info.restype=ctypes.c_int
clockbase=Timebase()
assert system.mach_timebase_info(ctypes.byref(clockbase))==0
tickNanoseconds=clockbase.numer/clockbase.denom



import hashlib,time,signal,gzip,sys
sys.path.insert(0,'/Users/lijie/source/goplus/wasmvm-source-cleanup/benchmarks/native')
import runtime_fixtures
P=OUT.parent.parent/'native-frame-deltas-20261114';count=5000000;expected=runtime_fixtures.checksum('nested-calls',17,count*2)
variants={'base': '/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-call-stack-20261115/base-go-phase-committed', 'head': '/Users/lijie/source/goplus/wasmvm/artifacts/protocol-cost-20261112/native-call-stack-20261115/head-go-phase-committed'}
plan=dict(blocks=10,samples=20,iterations=count,expected=expected,seed=202611151801,variants=variants,scope='Independent fixed10block40process audit of committed integratedbase51778a62/reused0baaf03e versus head7b79ae65, Go1.27.3/default GC. Twenty individually interleaved5M warmcalls plus separate flush; raw rusage/instruction/cycle snapshots, independent output checks, binary aliases. No owned builds/tests/profiles/source edits/pruning overlap. Distinct from prototype and reference cohorts; no extension or portfolio acceptance.')
plan['knownHostActivity']='Other user-owned test, compiler/link and desktop processes were observed during preparation; they are not controlled or terminated. Per-block load snapshots and same-binary controls qualify every result.'
plan['baseQualification']='Reused baseline binaries record0baaf03e; Git verifies all Go/module sources identical to integrated51778a62. Symlinks avoid duplicate binaries; retain original hashes and identities. Final head exact7b79ae65fe5b9fc6b14a0bbdf204fa516876edae.'
plan['binaryHashes']={k:hashlib.sha256(Path(v).read_bytes()).hexdigest()for k,v in variants.items()};assert not(OUT/'rows.jsonl.gz').exists();(OUT/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');rng=random.Random(plan['seed']);rows=[]
def freeze(p):
 os.kill(p.pid,signal.SIGSTOP);pid,status=os.waitpid(p.pid,os.WUNTRACED);assert pid==p.pid and os.WIFSTOPPED(status)
def resume(p):os.kill(p.pid,signal.SIGCONT)
for block in range(plan['blocks']):
 children=[];order=[(name,alias)for name in variants for alias in ('','-aa')];rng.shuffle(order)
 load=subprocess.check_output(['ps','-axo','pid,pcpu,comm'],text=True);(OUT/f'load-{block}.txt').write_text('\n'.join(l for l in load.splitlines()[1:]if float(l.split(None,2)[1])>5)+'\n')
 try:
  for name,alias in order:
   cmd=[variants[name],'--backend','native','--mode','api','--wasm',str(P/'generic-calls.wasm'),'--iterations',str(count),'--seed','17','--expected',str(expected),'--samples','21','--warmups','2']
   env=dict(os.environ,GOMAXPROCS='1',GOGC='100',WASMVM_INTERLEAVE='1')
   err=(OUT/f'{block}-{name}{alias}.stderr').open('w');p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True,env=env);c=dict(id=name+alias,process=p,errorFile=err,command=cmd,rounds=[]);children.append(c);c['watchdog']=threading.Timer(120,p.kill);c['watchdog'].start()
   assert json.loads(p.stdout.readline())=={'ready':True};p.stdin.write('run\n');p.stdin.flush();assert json.loads(p.stdout.readline())=={'sampleReady':0};freeze(p)
  for sample in range(plan['samples']):
   order=list(children);rng.shuffle(order)
   for c in order:
    p=c['process'];before=snapshot(p.pid);resume(p);p.stdin.write('sample\n');p.stdin.flush();assert json.loads(p.stdout.readline())=={'sampleReady':sample+1};freeze(p);after=snapshot(p.pid);c['rounds'].append(dict(sample=sample,before=before,after=after))
  for c in children:
   p=c['process'];resume(p);p.stdin.write('sample\n');p.stdin.close();record=json.loads(p.stdout.readline());rest=p.stdout.read();assert p.wait(timeout=30)==0 and not rest and record['warmResults']==[expected]*21
   n=count*plan['samples'];totals={k:sum(r['after'][k]-r['before'][k]for r in c['rounds'])for k in names};row=dict(block=block,id=c['id'],command=c['command'],rounds=c['rounds'],totals=totals,iterations=n,cpuNs=(totals['ri_user_time']+totals['ri_system_time'])*tickNanoseconds/n,instructions=totals['ri_instructions']/n,cycles=totals['ri_cycles']/n,nsPerIteration=statistics.median(record['warmCallNs'][:20])/count,record=record)
   with gzip.open(OUT/'rows.jsonl.gz','at',compresslevel=1)as f:f.write(json.dumps(row)+'\n')
   rows.append(row)
  print('block',block,flush=True)
 finally:
  for c in children:
   p=c['process'];c['watchdog'].cancel()
   if p.poll()is None:p.kill();p.wait()
   c['errorFile'].close()
summary={n:{k:statistics.median(r[k]for r in rows if r['id']==n)for k in ('cpuNs','instructions','cycles','nsPerIteration')}for n in ('base','base-aa','head','head-aa')};(OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
