package phase
func init(){sourceRevision="51778a629b032033bf62bbb352bd9ebc94dfccd5+function-state-prototype";compilerRevision="go1.27.3"}
