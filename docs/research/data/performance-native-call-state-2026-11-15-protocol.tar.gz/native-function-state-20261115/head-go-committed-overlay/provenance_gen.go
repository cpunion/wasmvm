package phase
func init(){sourceRevision="33da30b94380efa87cf44dfde4f9e927b062da19";compilerRevision="go1.27.3"}
