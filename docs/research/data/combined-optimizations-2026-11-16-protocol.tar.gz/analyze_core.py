from pathlib import Path
import json,gzip,random,math,statistics
P=Path(__file__).resolve().parent;plan=json.loads((P/'core-plan.json').read_text());data=[json.loads(x)for x in gzip.open(P/'core/rows.jsonl.gz','rt')];n=plan['blocks'];rng=random.Random(202611169902);indices=[rng.choices(range(n),k=n)for _ in range(20000)]
def ratio(values):
 logs=[math.log(x)for x in values];samples=sorted(math.exp(sum(logs[i]for i in sample)/n)for sample in indices);return dict(ratio=math.exp(statistics.mean(logs)),ci95=[samples[500],samples[19499]])
results={}
for case in plan['cases']:
 f=case['fixture'];key=f['cohort']+'/'+f['id'];rows=[r for r in data if r['case']==f['id']and r['cohort']==f['cohort']];blocks={}
 for r in rows:assert r['id']not in blocks.setdefault(r['block'],{});blocks[r['block']][r['id']]=r
 assert len(blocks)==n
 roles=sorted(name for name in blocks[0]if not name.endswith('-aa'));assert all(set(block)==set(blocks[0])for block in blocks.values())
 aa={role:ratio([blocks[b][role+'-aa']['nsPerIteration']/blocks[b][role]['nsPerIteration']for b in range(n)])for role in roles}
 for value in aa.values():value['resolves2_5Percent']=value['ci95'][0]>=.975 and value['ci95'][1]<=1.025
 pairs=[]
 for backend in ['native','interpreter']:
  for compiler in ['go','llgo']:pairs.append((f'head-{compiler}-{backend}',f'base-{compiler}-{backend}'))
  pairs.extend([(f'head-llgo-{backend}',f'head-go-{backend}'),(f'head-llgo-{backend}',f'old-sdk-head-llgo-{backend}')])
  peers=['wazero-compiler','wasmtime-compiler','wasmer-compiler','native-c']if backend=='native'else['wazero-interpreter','wasmedge-interpreter']
  pairs.extend((f'head-{compiler}-{backend}',peer)for compiler in ['go','llgo']for peer in peers)
 comparisons={}
 for a,b in pairs:
  if a not in roles or b not in roles:continue
  value=ratio([math.sqrt(blocks[i][a]['nsPerIteration']*blocks[i][a+'-aa']['nsPerIteration'])/math.sqrt(blocks[i][b]['nsPerIteration']*blocks[i][b+'-aa']['nsPerIteration'])for i in range(n)])
  value['controlsResolve']=aa[a]['resolves2_5Percent']and aa[b]['resolves2_5Percent'];value['upper95AtMostOne']=value['ci95'][1]<=1;value['resolvedRegression']=value['controlsResolve']and value['ci95'][0]>1;comparisons[a+'/'+b]=value
 medians={role:statistics.median(r['nsPerIteration']for r in rows if r['id']in [role,role+'-aa'])for role in roles}
 phases={}
 for role in roles:
  selected=[r for r in rows if r['id']in[role,role+'-aa']];keys={k for r in selected for k in r['observation']['record'].get('phasesNs',{})};phases[role]={k:statistics.median(r['observation']['record']['phasesNs'][k]for r in selected if k in r['observation']['record'].get('phasesNs',{}))for k in keys}
 results[key]=dict(processes=len(rows),statistic=case['statistic'],mediansNsPerIteration=medians,AA=aa,comparisons=comparisons,phasesMedianNs=phases)
 print(key,'checked',len(rows),flush=True)
(P/'core-analysis.json').write_text(json.dumps(dict(scope='Independent fixed-block marginal bootstrap95 intervals; no pooling, subtraction or simultaneous-confidence claim. Failed AA leaves comparisons unresolved.',results=results),indent=2)+'\n')
