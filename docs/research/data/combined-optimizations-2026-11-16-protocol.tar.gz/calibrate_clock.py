from pathlib import Path
import ctypes,json,os,random,re,statistics,subprocess,threading

OUT=Path(__file__).resolve().parent
ROOT=Path('/Users/lijie/source/goplus/wasmvm')
header=Path('/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk/usr/include/sys/resource.h').read_text()
body=header.split('struct rusage_info_v4 {',1)[1].split('};',1)[0]
fields=re.findall(r'uint64_t\s+(ri_\w+);',body)
class Info(ctypes.Structure):_fields_=[('ri_uuid',ctypes.c_ubyte*16)]+[(n,ctypes.c_uint64)for n in fields]
lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
lib.proc_pid_rusage.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_void_p];lib.proc_pid_rusage.restype=ctypes.c_int
names=['ri_user_time','ri_system_time','ri_instructions','ri_cycles','ri_pkg_idle_wkups','ri_interrupt_wkups','ri_phys_footprint','ri_lifetime_max_phys_footprint','ri_runnable_time']
def snapshot(pid):
 info=Info();result=lib.proc_pid_rusage(pid,4,ctypes.byref(info))
 if result:raise OSError(ctypes.get_errno(),'proc_pid_rusage')
 return {n:int(getattr(info,n)) for n in names}
assert snapshot(os.getpid())['ri_user_time']>0
class Timebase(ctypes.Structure):
 _fields_=[('numer',ctypes.c_uint32),('denom',ctypes.c_uint32)]
system=ctypes.CDLL('/usr/lib/libSystem.B.dylib')
system.mach_timebase_info.argtypes=[ctypes.POINTER(Timebase)]
system.mach_timebase_info.restype=ctypes.c_int
clockbase=Timebase()
assert system.mach_timebase_info(ctypes.byref(clockbase))==0
tickNanoseconds=clockbase.numer/clockbase.denom




import time,resource
before=snapshot(os.getpid());start=time.process_time_ns();ru=resource.getrusage(resource.RUSAGE_SELF);user=ru.ru_utime+ru.ru_stime
value=0
for i in range(2000000):value=(value+i)&0xffffffff
elapsed=time.process_time_ns()-start;ru=resource.getrusage(resource.RUSAGE_SELF);usage=(ru.ru_utime+ru.ru_stime-user)*1e9;after=snapshot(os.getpid());raw=(after['ri_user_time']-before['ri_user_time'])+(after['ri_system_time']-before['ri_system_time']);ratio=elapsed/raw
out=dict(processTimeNs=elapsed,getrusageNs=usage,rawProcCpu=raw,observedNanosecondsPerTick=ratio,machTimebaseNumer=clockbase.numer,machTimebaseDenom=clockbase.denom,expectedNanosecondsPerTick=tickNanoseconds)
assert abs(ratio/tickNanoseconds-1)<.03,out
(OUT/'clock-calibration.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))
