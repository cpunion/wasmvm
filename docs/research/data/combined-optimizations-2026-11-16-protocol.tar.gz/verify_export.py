from pathlib import Path
import gzip,json,hashlib,statistics,math,collections,tarfile
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');d=w/'docs/research/data';stem='combined-optimizations-2026-11-16';s=json.loads((d/(stem+'.json')).read_text());plans=json.loads((p/'core-plan.json').read_text());cases={(x['fixture']['cohort'],x['fixture']['id']):x for x in plans['cases']};counts=collections.Counter()
def equal(a,b):assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),(a,b)
for kind in ['raw','protocol']:
 f=d/s[kind]['file'];assert hashlib.sha256(f.read_bytes()).hexdigest()==s[kind]['sha256']
for line in gzip.open(d/s['raw']['file'],'rt'):
 x=json.loads(line);name=x['cohort'];r=x['row'];counts[name]+=1
 if name=='core':
  c=cases[(r['cohort'],r['case'])];f=c['fixture'];record=r['observation']['record'];assert record.get('result',record.get('checksum'))==f['expectedChecksum'];warm=record['warmCallNs'];assert len(warm)==7
  if 'warmResults'in record:assert record['warmResults']==[f['expectedChecksum']]*7
  reduce=statistics.mean if c['statistic']=='mean-including-pauses'else statistics.median;equal(r['nsPerIteration'],reduce(warm)/f['iterations'])
 elif name.startswith('p3-')or name=='diagnostics/sdk-no-gc-65536':
  size=16 if name=='p3-16'else 65536;expected=1757737011 if size==16 else 2629362236;samples=5 if name.startswith('diagnostics/')else 20;record=r['record'];assert record['warmResults']==[expected]*(samples+1)
  total={key:sum(i['after'][key]-i['before'][key]for i in r['rounds'])for key in r['totals']};assert total==r['totals'];equal(r['cpuUs'],(total['ri_user_time']+total['ri_system_time'])*(125/3)/r['windowRequests']/1000);equal(r['instructions'],total['ri_instructions']/r['windowRequests']);equal(r['throughput'],512e9/statistics.median(record['warmCallNs'][:samples]))
  if name.startswith('diagnostics/'):assert all(b['GCBefore']==b['GCAfter']for b in record['service']['Batches'][3:3+samples])
 else:
  assert name=='diagnostics/interpreter-counters';total={k:sum(v[k]for v in r['deltas'])for k in r['deltas'][0]};f=next(x['fixture']for x in plans['cases']if x['fixture']['cohort']=='original22-v1'and x['fixture']['id']==r['case']);assert r['record']['warmResults']==[f['expectedChecksum']]*6;count=f['iterations']*5;equal(r['instructions'],total['ri_instructions']/count);equal(r['cyclesPerInstruction'],total['ri_cycles']/total['ri_instructions'])
assert dict(counts)==s['processCounts'];assert sum(counts.values())==10124
with tarfile.open(d/s['protocol']['file'])as t:
 members=t.getnames();assert len(members)==len(set(members))and all(not Path(x).is_absolute()and'..'not in Path(x).parts for x in members)
print('Verified10124 process records, all warm checksums, primary metrics, zero-GC diagnostic, safe protocol paths and artifact digests.')
