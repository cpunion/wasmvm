from pathlib import Path
import json,hashlib,subprocess,os,time,sys
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');R=W.parent/'wasmvm';P=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'benchmarks'));import routing_compare
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert head.startswith('4d6fc1a4')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
env=dict(os.environ,PATH='/opt/homebrew/Cellar/go/1.27.3/libexec/bin:/opt/homebrew/opt/llvm@22/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly',GOMAXPROCS='4',CGO_ENABLED='1',CC='/opt/homebrew/opt/llvm@22/bin/clang',LLGO_ROOT=str(W.parent/'llgo-external-link-options'))
cli=R/'artifacts/components/llgo-5860fb6f';revision='5860fb6f9c13371f6cdb456a987a8e95844066d4';assert revision[:12] in subprocess.check_output([str(cli),'version'],env=env,text=True)
source=routing_compare.instrument_own((W/'internal/bench/phase/phase.go').read_text()).replace('var sourceRevision = "development"','var sourceRevision = '+json.dumps(head)).replace('var compilerRevision = "development"','var compilerRevision = '+json.dumps(revision))
f=P/'old-sdk-phase.go';f.write_text(source);g=P/'old-sdk-provenance.go';g.write_text('package phase\nconst SourceRevision = '+json.dumps(head)+'\n')
o=P/'old-sdk-overlay.json';o.write_text(json.dumps({'Replace':{str(W/'internal/bench/phase/phase.go'):str(f),str(W/'internal/bench/phase/provenance_gen.go'):str(g)}}))
results={}
for kind,directory in [('phase',W/'benchmarks/embedded/wasmvm'),('p3',W/'benchmarks/p3io')]:
 name='old-sdk-llgo-'+kind;binary=P/name;assert not binary.exists();cmd=[str(cli),'build','-O3','-lto=full','-overlay',str(o),'-o',str(binary),'.'];started=time.monotonic()
 with (P/(name+'-build.log')).open('w')as log:subprocess.run(cmd,cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600,check=True)
 results[kind]=dict(command=cmd,source=head,compiler=revision,binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),seconds=time.monotonic()-started)
 (P/'old-sdk-builds.json').write_text(json.dumps(results,indent=2)+'\n');print('built',name,flush=True)
