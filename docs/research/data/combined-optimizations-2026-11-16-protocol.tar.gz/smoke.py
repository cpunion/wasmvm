from pathlib import Path
import json,subprocess,os,sys,zlib
W=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');R=W.parent/'wasmvm';P=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'benchmarks'));import routing_compare
build=json.loads((P/'build.json').read_text());old=json.loads((P/'old-sdk-builds.json').read_text());env=dict(os.environ,GOMAXPROCS='4',GOGC='100',WASMVM_INTERLEAVE='0');records=[]
for name,row in build['builds'].items():
 binary=row['binary']
 if name.endswith('-phase'):
  f=next(x for x in routing_compare.fixtures(W)if x['id']=='core/integer-loop');count=1000;expected=routing_compare.oracle(W,f,f['seed'],count)
  for backend in ['interpreter','native']:
   cmd=[binary,'--mode','api','--backend',backend,'--wasm',f['path'],'--iterations',str(count),'--seed',str(f['seed']),'--expected',str(expected),'--samples','3','--warmups','0']
   out=json.loads(subprocess.check_output(cmd,env=env,timeout=120,input='run\n',text=True).splitlines()[-1]);assert out['sourceRevision']==row['source'] and out['warmResults']==[expected]*3;records.append(dict(name=name,backend=backend,record=out))
 else:
  for size in [16,65536]:
   expected=zlib.crc32(b'0123456789abcdef'*(size//16));cmd=[binary,'--engine','wasmvm','--backend','native','--wasm',str(W/'pkg/wasi/preview3/testdata/world-rust-http.wasm'),'--response-mode','buffered','--request-mode','snapshot','--payload-bytes',str(size),'--expected',str(expected),'--workers','2','--clients','4','--requests','2','--samples','3','--warmups','0']
   out=json.loads(subprocess.check_output(cmd,env=env,timeout=120,input='run\n',text=True).splitlines()[-1]);assert out['warmResults']==[expected]*3;records.append(dict(name=name,payload=size,record=out))
 print('smoke',name,flush=True)
(P/'smoke.json').write_text(json.dumps({'scope':'Semantic harness smoke only; timer fields are not performance evidence.','records':records},indent=2)+'\n')
