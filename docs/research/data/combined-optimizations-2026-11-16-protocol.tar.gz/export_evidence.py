from pathlib import Path
import gzip,json,hashlib,tarfile,io,subprocess,re
p=Path(__file__).resolve().parent;w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');dest=w/'docs/research/data';stem='combined-optimizations-2026-11-16'
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
cohorts=['core','p3-16','p3-65536','diagnostics/sdk-no-gc-65536','diagnostics/interpreter-counters'];raw=dest/(stem+'-raw.jsonl.gz');counts={};sources={}
with raw.open('wb')as target:
 with gzip.GzipFile(fileobj=target,mode='wb',mtime=0)as compressed:
  for name in cohorts:
   f=p/name/'rows.jsonl.gz';sources[name]=sha(f);count=0
   for line in gzip.open(f,'rt'):
    row=json.loads(line);count+=1
    if 'record'in row and 'service'in row['record']:
     for batch in row['record']['service']['Batches']:
      for key in ['RequestNs','PublicAPINs']:
       if key not in batch:continue
       values=batch.pop(key);batch[key+'Projection']=dict(count=len(values),minimum=min(values)if values else None,maximum=max(values)if values else None,sha256=hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest())
    compressed.write((json.dumps(dict(cohort=name,row=row),separators=(',',':'))+'\n').encode())
   counts[name]=count
assert counts=={'core':9660,'p3-16':140,'p3-65536':140,'diagnostics/sdk-no-gc-65536':40,'diagnostics/interpreter-counters':144}
files=['export_evidence.py','verify_export.py','build.py','build.json','build-complete.json','build_old_sdk.py','old-sdk-builds.json','prepare_core.py','core-plan.json','prepare_p3.py','run_campaign.py','campaign.json','qualification.json','machine.json','measure_core.py','analyze_core.py','analyze_p3.py','clock-calibration.json','calibrate_clock.py','smoke.py','smoke.json','capability_smoke.py','capability-smoke.json','p3-capability-smoke.json','wasmedge-build.json','wasmedge.c','common.h','capability-smoke-edge-threads-config-failure.log','core-plan-preflight-config.json','diagnostics/profile_go.py','diagnostics/profile-provenance.json','diagnostics/gc-observations.json','diagnostics/analyze.py','diagnostics/analysis.json','diagnostics/go-loop-comparison.json','diagnostics/llgo-loop-comparison.json','diagnostics/section-identities.json','diagnostics/go16-cpu.pb.gz','diagnostics/go16-allocs.pb.gz']
for name in ['p3-16','p3-65536','diagnostics/sdk-no-gc-65536','diagnostics/interpreter-counters']:
 files += [name+'/'+f for f in ['measure.py','frozen-plan.json']]
files += [str(x.relative_to(p))for x in (p/'diagnostics').glob('*-runSlotsLoop.asm')]
extras={}
# Publish process names/CPU/load only. Full command lines remain local with
# original source hashes, because unrelated desktop arguments may be private.
for folder in ['core','p3-16','p3-65536']:
 for f in sorted((p/folder).glob('*load*.json')):
  data=json.loads(f.read_text());original=sha(f)
  if isinstance(data,dict)and isinstance(data.get('processes'),str):
   rows=[]
   for line in data.pop('processes').splitlines()[1:]:
    v=line.split(None,4)
    if len(v)==5:rows.append(dict(pid=v[0],ppid=v[1],elapsed=v[2],cpuPercent=v[3],commandName=Path(v[4].split()[0]).name))
   data['processes']=rows
  elif isinstance(data,list):
   for row in data:
    if 'command'in row:row['commandName']=Path(row.pop('command')).name
  extras[str(f.relative_to(p))]=json.dumps(dict(fullLocalSHA256=original,sanitizedLoad=data),separators=(',',':')).encode()
extras['REPRODUCE.md']=b'Use qualified source aa935e3 (production source equals477af3b), baseline e9d9e1b, the frozen plans, compiler pins and existing repository harnesses. Build oldSDK5860 controls before advancing SDK to1b44; oldSDK engine sources4d6fc1a are Go/C-equivalent to477af3b, so public measured source can reproduce that engine with the recorded provenance label. Rebase local output/checkout paths. Build/check/hash everything before timing and run each frozen cohort once. Do not overlap owned builds/tests/profiles/analysis, extend failed controls, pool distinct events, subtract phases or infer exclusive CPU from cumulative profiles. DefaultGC and noGC are separate experiments. Protocol scripts recreate changed-file overlays from Git; no full source tree copies are needed. Compact raw rows omit only unused per-request vectors with count/extrema/hashes; no latency-tail inference. Load snapshots omit unrelated command arguments; full originals remain local with hashes.\n'
qualified=p.parent/'owned-native-context-20261116'
for rel in ['new-sdk-build.json','ci-audit/closeout.json','ci-http-timeout-timing.json']:
 f=qualified/rel;extras['qualification/'+rel]=f.read_bytes()
ref=p.parent/'ordered-optimizations-20261115/reference-build.json';extras['references/reference-build.json']=ref.read_bytes()
protocol=dest/(stem+'-protocol.tar.gz')
with protocol.open('wb')as file:
 with gzip.GzipFile(fileobj=file,mode='wb',mtime=0)as zipped:
  with tarfile.open(fileobj=zipped,mode='w')as tar:
   for name in files:
    f=p/name;assert f.is_file(),f;data=f.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
   for name,data in extras.items():
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
summary=dict(machine=json.loads((p/'machine.json').read_text()),qualification=json.loads((p/'qualification.json').read_text()),campaign=json.loads((p/'campaign.json').read_text()),builds=json.loads((p/'build.json').read_text()),oldSDK=json.loads((p/'old-sdk-builds.json').read_text()),core=json.loads((p/'core-analysis.json').read_text()),p3=json.loads((p/'p3-analysis.json').read_text()),diagnostics=json.loads((p/'diagnostics/analysis.json').read_text()),processCounts=counts,fullLocalRowsSHA256=sources,raw=dict(file=raw.name,sha256=sha(raw),scope='All process and counter windows retained. Unused request-time vectors projected to count/extrema/hash; no tail inference.'),protocol=dict(file=protocol.name,sha256=sha(protocol)))
(dest/(stem+'.json')).write_text(json.dumps(summary,indent=2)+'\n');print('Exported',[(f.name,f.stat().st_size)for f in [raw,protocol,dest/(stem+'.json')]])
