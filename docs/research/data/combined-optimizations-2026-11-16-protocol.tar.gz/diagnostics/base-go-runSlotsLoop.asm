TEXT github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB) /Users/lijie/source/goplus/wasmvm-source-cleanup/internal/engine/execute/execution.go
  execution.go:325	0x10020f5a0		f9400b90		MOVD 16(R28), R16									
  execution.go:325	0x10020f5a4		d10703f1		SUB $448, RSP, R17									
  execution.go:325	0x10020f5a8		eb10023f		CMP R16, R17										
  execution.go:325	0x10020f5ac		54013b09		BLS 2520(PC)										
  execution.go:325	0x10020f5b0		d10903f4		SUB $576, RSP, R20									
  execution.go:325	0x10020f5b4		a93ffa9d		STP (R29, R30), -8(R20)									
  execution.go:325	0x10020f5b8		9100029f		MOVD R20, RSP										
  execution.go:325	0x10020f5bc		d10023fd		SUB $8, RSP, R29									
  execution.go:327	0x10020f5c0		f90127e0		MOVD R0, 584(RSP)									
  execution.go:326	0x10020f5c4		39408009		MOVBU 32(R0), R9									
  execution.go:326	0x10020f5c8		3903dfe9		MOVB R9, 247(RSP)									
  execution.go:327	0x10020f5cc		14000004		JMP 4(PC)										
  execution.go:327	0x10020f5d0		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x10020f5d4		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:328	0x10020f5d8		f94093e1		MOVD 288(RSP), R1									
  execution.go:327	0x10020f5dc		a9442c0a		LDP 64(R0), (R10, R11)									
  execution.go:327	0x10020f5e0		b40138ab		CBZ R11, 2501(PC)									
  execution.go:328	0x10020f5e4		d100056b		SUB $1, R11, R11									
  execution.go:329	0x10020f5e8		8b0b194a		ADD R11<<6, R10, R10									
  execution.go:330	0x10020f5ec		3900415f		MOVB ZR, 16(R10)									
  execution.go:331	0x10020f5f0		f940014b		MOVD (R10), R11										
  execution.go:334	0x10020f5f4		f9400d4c		MOVD 24(R10), R12									
  execution.go:332	0x10020f5f8		a944396d		LDP 64(R11), (R13, R14)									
  execution.go:333	0x10020f5fc		a94b41cf		LDP 176(R14), (R15, R16)								
  execution.go:337	0x10020f600		f9404411		MOVD 136(R0), R17									
  execution.go:337	0x10020f604		f9404dd3		MOVD 152(R14), R19									
  execution.go:337	0x10020f608		8b130194		ADD R19, R12, R20									
  execution.go:337	0x10020f60c		eb14023f		CMP R20, R17										
  execution.go:337	0x10020f610		540136c3		BCC 2486(PC)										
  execution.go:337	0x10020f614		eb14019f		CMP R20, R12										
  execution.go:337	0x10020f618		54013648		BHI 2482(PC)										
  execution.go:329	0x10020f61c		f900b7ea		MOVD R10, 360(RSP)									
  execution.go:331	0x10020f620		f900b3eb		MOVD R11, 352(RSP)									
  execution.go:332	0x10020f624		f900bfee		MOVD R14, 376(RSP)									
  execution.go:335	0x10020f628		f900abed		MOVD R13, 336(RSP)									
  execution.go:337	0x10020f62c		f90087f3		MOVD R19, 264(RSP)									
  execution.go:333	0x10020f630		f9008bf0		MOVD R16, 272(RSP)									
  execution.go:333	0x10020f634		f900a7ef		MOVD R15, 328(RSP)									
  execution.go:337	0x10020f638		f9403c14		MOVD 120(R0), R20									
  execution.go:337	0x10020f63c		cb110191		SUB R17, R12, R17									
  execution.go:337	0x10020f640		8a91fd8c		AND R17->63, R12, R12									
  execution.go:336	0x10020f644		b9400951		MOVWU 8(R10), R17									
  execution.go:337	0x10020f648		8b0c128c		ADD R12<<4, R20, R12									
  execution.go:337	0x10020f64c		f9009bec		MOVD R12, 304(RSP)									
  execution.go:338	0x10020f650		14000002		JMP 2(PC)										
  execution.go:341	0x10020f654		aa1503e1		MOVD R21, R1										
  execution.go:341	0x10020f658		2a1103f4		MOVW R17, R20										
  execution.go:341	0x10020f65c		eb10029f		CMP R16, R20										
  execution.go:341	0x10020f660		540133a2		BCS 2461(PC)										
  execution.go:341	0x10020f664		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:342	0x10020f668		360002c9		TBZ $0, R9, 22(PC)									
  execution.go:343	0x10020f66c		a947d9d5		LDP 120(R14), (R21, R22)								
  execution.go:343	0x10020f670		b9400697		MOVWU 4(R20), R23									
  execution.go:343	0x10020f674		aa1703f8		MOVD R23, R24										
  execution.go:343	0x10020f678		eb16031f		CMP R22, R24										
  execution.go:343	0x10020f67c		54013262		BCS 2451(PC)										
  execution.go:343	0x10020f680		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:343	0x10020f684		cb1816d6		SUB R24<<5, R22, R22									
  ir.go:27		0x10020f688		b8766ab7		MOVWU (R21)(R22), R23									
  execution.go:343	0x10020f68c		8b1602b5		ADD R22, R21, R21									
  ir.go:27		0x10020f690		710016ff		CMPW $5, R23										
  ir.go:27		0x10020f694		54000060		BEQ 3(PC)										
  ir.go:27		0x10020f698		71002eff		CMPW $11, R23										
  ir.go:27		0x10020f69c		54000061		BNE 3(PC)										
  execution.go:344	0x10020f6a0		aa1f03e2		MOVD ZR, R2										
  execution.go:344	0x10020f6a4		14000002		JMP 2(PC)										
  execution.go:344	0x10020f6a8		b24003e2		ORR $1, ZR, R2										
  execution.go:345	0x10020f6ac		f940a816		MOVD 336(R0), R22									
  execution.go:345	0x10020f6b0		eb16005f		CMP R22, R2										
  execution.go:345	0x10020f6b4		5400de88		BHI 1780(PC)										
  execution.go:348	0x10020f6b8		cb0202d5		SUB R2, R22, R21									
  execution.go:348	0x10020f6bc		f900a815		MOVD R21, 336(R0)									
  execution.go:350	0x10020f6c0		91000435		ADD $1, R1, R21										
  execution.go:351	0x10020f6c4		f24016bf		TST $63, R21										
  execution.go:351	0x10020f6c8		54000421		BNE 33(PC)										
  execution.go:341	0x10020f6cc		f900aff4		MOVD R20, 344(RSP)									
  execution.go:350	0x10020f6d0		f90097f5		MOVD R21, 296(RSP)									
  execution.go:341	0x10020f6d4		b900fbf1		MOVW R17, 248(RSP)									
  execution.go:209	0x10020f6d8		f940b016		MOVD 352(R0), R22									
  execution.go:209	0x10020f6dc		b40000d6		CBZ R22, 6(PC)										
  type.go:19		0x10020f6e0		88dffed6		LDARW (R22), R22									
  execution.go:209	0x10020f6e4		35000096		CBNZW R22, 4(PC)									
  execution.go:212	0x10020f6e8		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x10020f6ec		aa1f03e2		MOVD ZR, R2										
  execution.go:352	0x10020f6f0		14000013		JMP 19(PC)										
  execution.go:212	0x10020f6f4		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x10020f6f8		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10020f6fc		d63f0020		CALL (R1)										
  execution.go:356	0x10020f700		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x10020f704		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10020f708		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x10020f70c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10020f710		f940abed		MOVD 336(RSP), R13									
  execution.go:434	0x10020f714		f940bfee		MOVD 376(RSP), R14									
  execution.go:364	0x10020f718		f940a7ef		MOVD 328(RSP), R15									
  execution.go:364	0x10020f71c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:360	0x10020f720		b940fbf1		MOVWU 248(RSP), R17									
  execution.go:361	0x10020f724		f94087f3		MOVD 264(RSP), R19									
  execution.go:360	0x10020f728		f940aff4		MOVD 344(RSP), R20									
  execution.go:360	0x10020f72c		f94097f5		MOVD 296(RSP), R21									
  execution.go:212	0x10020f730		aa0103e2		MOVD R1, R2										
  execution.go:212	0x10020f734		aa0003e1		MOVD R0, R1										
  execution.go:353	0x10020f738		f94127e0		MOVD 584(RSP), R0									
  execution.go:352	0x10020f73c		b4000081		CBZ R1, 4(PC)										
  execution.go:352	0x10020f740		140006f2		JMP 1778(PC)										
  execution.go:364	0x10020f744		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:365	0x10020f748		910006b5		ADD $1, R21, R21									
  execution.go:356	0x10020f74c		b9401e96		MOVWU 28(R20), R22									
  execution.go:356	0x10020f750		340002f6		CBZW R22, 23(PC)									
  execution.go:356	0x10020f754		b9400297		MOVWU (R20), R23									
  execution.go:356	0x10020f758		710082ff		CMPW $32, R23										
  execution.go:356	0x10020f75c		54000060		BEQ 3(PC)										
  execution.go:356	0x10020f760		710106ff		CMPW $65, R23										
  execution.go:356	0x10020f764		54000241		BNE 18(PC)										
  execution.go:356	0x10020f768		37000229		TBNZ $0, R9, 17(PC)									
  execution.go:356	0x10020f76c		924016b8		AND $63, R21, R24									
  execution.go:356	0x10020f770		f100ff1f		CMP $63, R24										
  execution.go:356	0x10020f774		540001c0		BEQ 14(PC)										
  execution.go:360	0x10020f778		710106ff		CMPW $65, R23										
  execution.go:360	0x10020f77c		540000e1		BNE 7(PC)										
  execution.go:361	0x10020f780		b9400a96		MOVWU 8(R20), R22									
  execution.go:361	0x10020f784		eb1302df		CMP R19, R22										
  execution.go:361	0x10020f788		540129a2		BCS 2381(PC)										
  execution.go:361	0x10020f78c		8b161196		ADD R22<<4, R12, R22									
  execution.go:361	0x10020f790		b9401a94		MOVWU 24(R20), R20									
  execution.go:361	0x10020f794		a9007ed4		STP (R20, ZR), (R22)									
  execution.go:363	0x10020f798		91000631		ADD $1, R17, R17									
  execution.go:364	0x10020f79c		2a1103f4		MOVW R17, R20										
  execution.go:364	0x10020f7a0		eb10029f		CMP R16, R20										
  execution.go:364	0x10020f7a4		54fffd03		BCC -24(PC)										
  execution.go:364	0x10020f7a8		14000942		JMP 2370(PC)										
  execution.go:360	0x10020f7ac		b90107f1		MOVW R17, 260(RSP)									
  execution.go:360	0x10020f7b0		f90093f5		MOVD R21, 288(RSP)									
  execution.go:360	0x10020f7b4		f900c3f4		MOVD R20, 384(RSP)									
  execution.go:371	0x10020f7b8		b9400281		MOVWU (R20), R1										
  execution.go:371	0x10020f7bc		d1038037		SUB $224, R1, R23									
  execution.go:371	0x10020f7c0		d29fe418		MOVD $65312, R24									
  execution.go:371	0x10020f7c4		f2a01ff8		MOVK $(255<<16), R24									
  execution.go:371	0x10020f7c8		6b1802ff		CMPW R24, R23										
  execution.go:371	0x10020f7cc		54002822		BCS 321(PC)										
  execution.go:372	0x10020f7d0		d3507c37		UBFX $16, R1, $16, R23									
  execution.go:396	0x10020f7d4		7103eeff		CMPW $251, R23										
  execution.go:396	0x10020f7d8		540019e0		BEQ 207(PC)										
  execution.go:432	0x10020f7dc		7103f2ff		CMPW $252, R23										
  execution.go:432	0x10020f7e0		54000ba1		BNE 93(PC)										
  wide.go:3		0x10020f7e4		d2800277		MOVD $19, R23										
  wide.go:3		0x10020f7e8		f2a01f97		MOVK $(252<<16), R23									
  wide.go:3		0x10020f7ec		cb170038		SUB R23, R1, R24									
  wide.go:3		0x10020f7f0		71000f1f		CMPW $3, R24										
  execution.go:433	0x10020f7f4		540026e8		BHI 311(PC)										
  execution.go:434	0x10020f7f8		f9406dd8		MOVD 216(R14), R24									
  execution.go:434	0x10020f7fc		b9401a94		MOVWU 24(R20), R20									
  execution.go:434	0x10020f800		8b160299		ADD R22, R20, R25									
  execution.go:434	0x10020f804		91000b39		ADD $2, R25, R25									
  execution.go:434	0x10020f808		2a1903f9		MOVW R25, R25										
  execution.go:434	0x10020f80c		eb18033f		CMP R24, R25										
  execution.go:434	0x10020f810		540124a8		BHI 2341(PC)										
  execution.go:434	0x10020f814		eb19029f		CMP R25, R20										
  execution.go:434	0x10020f818		54012408		BHI 2336(PC)										
  execution.go:434	0x10020f81c		f94065da		MOVD 200(R14), R26									
  execution.go:434	0x10020f820		cb180298		SUB R24, R20, R24									
  execution.go:434	0x10020f824		8a98fe98		AND R24->63, R20, R24									
  execution.go:434	0x10020f828		8b180b5e		ADD R24<<2, R26, R30									
  execution.go:434	0x10020f82c		cb140334		SUB R20, R25, R20									
  execution.go:435	0x10020f830		b4012334		CBZ R20, 2329(PC)									
  execution.go:435	0x10020f834		b8787b58		MOVWU (R26)(R24<<2), R24								
  execution.go:435	0x10020f838		eb13031f		CMP R19, R24										
  execution.go:435	0x10020f83c		54012262		BCS 2323(PC)										
  execution.go:435	0x10020f840		8b181198		ADD R24<<4, R12, R24									
  execution.go:435	0x10020f844		f100069f		CMP $1, R20										
  execution.go:435	0x10020f848		540121e9		BLS 2319(PC)										
  execution.go:435	0x10020f84c		b94007d9		MOVWU 4(R30), R25									
  execution.go:435	0x10020f850		eb13033f		CMP R19, R25										
  execution.go:435	0x10020f854		54012122		BCS 2313(PC)										
  execution.go:435	0x10020f858		8b191199		ADD R25<<4, R12, R25									
  execution.go:435	0x10020f85c		f9400318		MOVD (R24), R24										
  execution.go:435	0x10020f860		f9400339		MOVD (R25), R25										
  execution.go:438	0x10020f864		d280029a		MOVD $20, R26										
  execution.go:438	0x10020f868		f2a01f9a		MOVK $(252<<16), R26									
  execution.go:438	0x10020f86c		6b1a003f		CMPW R26, R1										
  execution.go:438	0x10020f870		540002e8		BHI 23(PC)										
  execution.go:439	0x10020f874		f1000a9f		CMP $2, R20										
  execution.go:439	0x10020f878		54011fe9		BLS 2303(PC)										
  execution.go:439	0x10020f87c		b9400bda		MOVWU 8(R30), R26									
  execution.go:439	0x10020f880		eb13035f		CMP R19, R26										
  execution.go:439	0x10020f884		54011f22		BCS 2297(PC)										
  execution.go:439	0x10020f888		8b1a119a		ADD R26<<4, R12, R26									
  execution.go:439	0x10020f88c		f1000e9f		CMP $3, R20										
  execution.go:439	0x10020f890		54011ea9		BLS 2293(PC)										
  execution.go:439	0x10020f894		b9400fc2		MOVWU 12(R30), R2									
  execution.go:439	0x10020f898		eb13005f		CMP R19, R2										
  execution.go:439	0x10020f89c		54011e02		BCS 2288(PC)										
  execution.go:439	0x10020f8a0		8b021182		ADD R2<<4, R12, R2									
  execution.go:439	0x10020f8a4		f940035a		MOVD (R26), R26										
  execution.go:439	0x10020f8a8		f9400042		MOVD (R2), R2										
  execution.go:441	0x10020f8ac		6b17003f		CMPW R23, R1										
  execution.go:441	0x10020f8b0		54000081		BNE 4(PC)										
  execution.go:442	0x10020f8b4		ab180357		ADDS R24, R26, R23									
  execution.go:443	0x10020f8b8		ba020338		ADCS R2, R25, R24									
  <autogenerated>:1	0x10020f8bc		14000013		JMP 19(PC)										
  execution.go:445	0x10020f8c0		eb1a0317		SUBS R26, R24, R23									
  execution.go:446	0x10020f8c4		fa020338		SBCS R2, R25, R24									
  <autogenerated>:1	0x10020f8c8		14000010		JMP 16(PC)										
  execution.go:449	0x10020f8cc		9b187f37		MUL R24, R25, R23									
  execution.go:449	0x10020f8d0		9bd97f1a		UMULH R25, R24, R26									
  execution.go:331	0x10020f8d4		aa0b03e2		MOVD R11, R2										
  execution.go:450	0x10020f8d8		d28002ab		MOVD $21, R11										
  execution.go:450	0x10020f8dc		f2a01f8b		MOVK $(252<<16), R11									
  execution.go:450	0x10020f8e0		6b0b003f		CMPW R11, R1										
  execution.go:450	0x10020f8e4		540000e1		BNE 7(PC)										
  execution.go:452	0x10020f8e8		cb19034b		SUB R25, R26, R11									
  execution.go:451	0x10020f8ec		f100031f		CMP $0, R24										
  execution.go:452	0x10020f8f0		9a9ab16b		CSEL LT, R11, R26, R11									
  execution.go:455	0x10020f8f4		cb180178		SUB R24, R11, R24									
  execution.go:454	0x10020f8f8		f100033f		CMP $0, R25										
  execution.go:455	0x10020f8fc		9a8bb31a		CSEL LT, R24, R11, R26									
  execution.go:786	0x10020f900		aa0203eb		MOVD R2, R11										
  execution.go:441	0x10020f904		aa1a03f8		MOVD R26, R24										
  execution.go:459	0x10020f908		910006d9		ADD $1, R22, R25									
  execution.go:459	0x10020f90c		2a1903f9		MOVW R25, R25										
  execution.go:459	0x10020f910		eb14033f		CMP R20, R25										
  execution.go:459	0x10020f914		540119e2		BCS 2255(PC)										
  execution.go:459	0x10020f918		b8797bd9		MOVWU (R30)(R25<<2), R25								
  execution.go:459	0x10020f91c		eb1402df		CMP R20, R22										
  execution.go:459	0x10020f920		54011922		BCS 2249(PC)										
  execution.go:459	0x10020f924		b8767bd4		MOVWU (R30)(R22<<2), R20								
  execution.go:459	0x10020f928		eb13029f		CMP R19, R20										
  execution.go:459	0x10020f92c		54011862		BCS 2243(PC)										
  execution.go:459	0x10020f930		8b141194		ADD R20<<4, R12, R20									
  execution.go:459	0x10020f934		a9007e97		STP (R23, ZR), (R20)									
  execution.go:459	0x10020f938		eb13033f		CMP R19, R25										
  execution.go:459	0x10020f93c		54011782		BCS 2236(PC)										
  execution.go:459	0x10020f940		8b191194		ADD R25<<4, R12, R20									
  execution.go:459	0x10020f944		a9007e98		STP (R24, ZR), (R20)									
  execution.go:460	0x10020f948		91000631		ADD $1, R17, R17									
  execution.go:461	0x10020f94c		b9000951		MOVW R17, 8(R10)									
  execution.go:462	0x10020f950		17ffff41		JMP -191(PC)										
  execution.go:373	0x10020f954		7103f6ff		CMPW $253, R23										
  execution.go:373	0x10020f958		54000080		BEQ 4(PC)										
  execution.go:465	0x10020f95c		7103983f		CMPW $230, R1										
  execution.go:465	0x10020f960		54001b88		BHI 220(PC)										
  execution.go:465	0x10020f964		1400062f		JMP 1583(PC)										
  execution.go:375	0x10020f968		b9400e87		MOVWU 12(R20), R7									
  execution.go:375	0x10020f96c		310004ff		CMNW $1, R7										
  execution.go:375	0x10020f970		540000c0		BEQ 6(PC)										
  execution.go:376	0x10020f974		eb1300ff		CMP R19, R7										
  execution.go:376	0x10020f978		54011562		BCS 2219(PC)										
  execution.go:376	0x10020f97c		8b071187		ADD R7<<4, R12, R7									
  execution.go:376	0x10020f980		a9401ce2		LDP (R7), (R2, R7)									
  execution.go:376	0x10020f984		14000003		JMP 3(PC)										
  execution.go:376	0x10020f988		aa1f03e2		MOVD ZR, R2										
  execution.go:376	0x10020f98c		aa1f03e7		MOVD ZR, R7										
  execution.go:378	0x10020f990		b9401288		MOVWU 16(R20), R8									
  execution.go:378	0x10020f994		3100051f		CMNW $1, R8										
  execution.go:378	0x10020f998		540000c0		BEQ 6(PC)										
  execution.go:379	0x10020f99c		eb13011f		CMP R19, R8										
  execution.go:379	0x10020f9a0		540113e2		BCS 2207(PC)										
  execution.go:379	0x10020f9a4		8b081188		ADD R8<<4, R12, R8									
  execution.go:379	0x10020f9a8		a9401103		LDP (R8), (R3, R4)									
  execution.go:379	0x10020f9ac		14000003		JMP 3(PC)										
  execution.go:379	0x10020f9b0		aa1f03e4		MOVD ZR, R4										
  execution.go:379	0x10020f9b4		aa1f03e3		MOVD ZR, R3										
  execution.go:382	0x10020f9b8		b9401688		MOVWU 20(R20), R8									
  execution.go:382	0x10020f9bc		3100051f		CMNW $1, R8										
  execution.go:382	0x10020f9c0		540000c0		BEQ 6(PC)										
  execution.go:383	0x10020f9c4		eb13011f		CMP R19, R8										
  execution.go:383	0x10020f9c8		54011262		BCS 2195(PC)										
  execution.go:383	0x10020f9cc		8b081188		ADD R8<<4, R12, R8									
  execution.go:383	0x10020f9d0		a9401905		LDP (R8), (R5, R6)									
  execution.go:383	0x10020f9d4		14000003		JMP 3(PC)										
  execution.go:383	0x10020f9d8		aa1f03e6		MOVD ZR, R6										
  execution.go:383	0x10020f9dc		aa1f03e5		MOVD ZR, R5										
  execution.go:385	0x10020f9e0		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:385	0x10020f9e4		b9400697		MOVWU 4(R20), R23									
  execution.go:385	0x10020f9e8		aa1703f8		MOVD R23, R24										
  execution.go:385	0x10020f9ec		eb16031f		CMP R22, R24										
  execution.go:385	0x10020f9f0		540110c2		BCS 2182(PC)										
  execution.go:385	0x10020f9f4		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:385	0x10020f9f8		cb1816d6		SUB R24<<5, R22, R22									
  execution.go:386	0x10020f9fc		d3403c37		UBFX $0, R1, $16, R23									
  execution.go:385	0x10020fa00		8b160108		ADD R22, R8, R8										
  execution.go:388	0x10020fa04		71002aff		CMPW $10, R23										
  execution.go:388	0x10020fa08		540000e9		BLS 7(PC)										
  execution.go:388	0x10020fa0c		d10152f6		SUB $84, R23, R22									
  execution.go:388	0x10020fa10		71000edf		CMPW $3, R22										
  execution.go:388	0x10020fa14		54000089		BLS 4(PC)										
  execution.go:388	0x10020fa18		b24002f6		ORR $1, R23, R22									
  execution.go:388	0x10020fa1c		710176df		CMPW $93, R22										
  execution.go:388	0x10020fa20		54000201		BNE 16(PC)										
  execution.go:389	0x10020fa24		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x10020fa28		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x10020fa2c		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x10020fa30		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:389	0x10020fa34		eb16031f		CMP R22, R24										
  execution.go:389	0x10020fa38		54010e22		BCS 2161(PC)										
  execution.go:389	0x10020fa3c		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:389	0x10020fa40		f94008e0		MOVD 16(R7), R0										
  execution.go:389	0x10020fa44		39410107		MOVBU 64(R8), R7									
  execution.go:389	0x10020fa48		aa0303e5		MOVD R3, R5										
  execution.go:389	0x10020fa4c		aa0403e6		MOVD R4, R6										
  execution.go:389	0x10020fa50		aa1703e3		MOVD R23, R3										
  execution.go:389	0x10020fa54		aa0703e4		MOVD R7, R4										
  execution.go:389	0x10020fa58		97ffa312		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:389	0x10020fa5c		1400001d		JMP 29(PC)										
  execution.go:390	0x10020fa60		71002eff		CMPW $11, R23										
  execution.go:390	0x10020fa64		54000080		BEQ 4(PC)										
  execution.go:390	0x10020fa68		d10162f6		SUB $88, R23, R22									
  execution.go:390	0x10020fa6c		71000edf		CMPW $3, R22										
  execution.go:390	0x10020fa70		54000268		BHI 19(PC)										
  execution.go:391	0x10020fa74		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x10020fa78		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x10020fa7c		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x10020fa80		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:391	0x10020fa84		eb16031f		CMP R22, R24										
  execution.go:391	0x10020fa88		54010b42		BCS 2138(PC)										
  execution.go:391	0x10020fa8c		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:391	0x10020fa90		f94008e0		MOVD 16(R7), R0										
  execution.go:391	0x10020fa94		39410107		MOVBU 64(R8), R7									
  execution.go:391	0x10020fa98		aa0303e5		MOVD R3, R5										
  execution.go:391	0x10020fa9c		aa0403e6		MOVD R4, R6										
  execution.go:391	0x10020faa0		aa1703e3		MOVD R23, R3										
  execution.go:391	0x10020faa4		aa0703e4		MOVD R7, R4										
  execution.go:391	0x10020faa8		97ffa376		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:391	0x10020faac		aa0003e2		MOVD R0, R2										
  execution.go:393	0x10020fab0		aa1f03e1		MOVD ZR, R1										
  execution.go:393	0x10020fab4		aa1f03e0		MOVD ZR, R0										
  execution.go:391	0x10020fab8		14000006		JMP 6(PC)										
  execution.go:393	0x10020fabc		aa0803e0		MOVD R8, R0										
  execution.go:393	0x10020fac0		aa0203e1		MOVD R2, R1										
  execution.go:393	0x10020fac4		aa0703e2		MOVD R7, R2										
  execution.go:393	0x10020fac8		97ffb362		CALL github.com/cpunion/wasmvm/internal/engine/simd.Eval(SB)				
  execution.go:391	0x10020facc		aa1f03e2		MOVD ZR, R2										
  execution.go:342	0x10020fad0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x10020fad4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10020fad8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10020fadc		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10020fae0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x10020fae4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10020fae8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10020faec		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x10020faf0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x10020faf4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x10020faf8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10020fafc		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x10020fb00		aa0103f7		MOVD R1, R23										
  execution.go:395	0x10020fb04		aa0003f6		MOVD R0, R22										
  execution.go:209	0x10020fb08		f94127e0		MOVD 584(RSP), R0									
  execution.go:395	0x10020fb0c		aa0203e1		MOVD R2, R1										
  execution.go:395	0x10020fb10		140005b9		JMP 1465(PC)										
  gc_access.go:11	0x10020fb14		d3403c36		UBFX $0, R1, $16, R22									
  gc_access.go:11	0x10020fb18		710036df		CMPW $13, R22										
  gc_access.go:14	0x10020fb1c		54000148		BHI 10(PC)										
  gc_access.go:12	0x10020fb20		d1000ad7		SUB $2, R22, R23									
  gc_access.go:12	0x10020fb24		71000aff		CMPW $2, R23										
  gc_access.go:12	0x10020fb28		54000249		BLS 18(PC)										
  gc_access.go:14	0x10020fb2c		710016df		CMPW $5, R22										
  gc_access.go:14	0x10020fb30		54000060		BEQ 3(PC)										
  gc_access.go:14	0x10020fb34		71002edf		CMPW $11, R22										
  gc_access.go:14	0x10020fb38		54000203		BCC 16(PC)										
  gc_access.go:14	0x10020fb3c		b27f03e1		ORR $2, ZR, R1										
  execution.go:400	0x10020fb40		1400000f		JMP 15(PC)										
  gc_access.go:11	0x10020fb44		71003edf		CMPW $15, R22										
  gc_access.go:12	0x10020fb48		540000a8		BHI 5(PC)										
  gc_access.go:16	0x10020fb4c		71003adf		CMPW $14, R22										
  gc_access.go:16	0x10020fb50		54000101		BNE 8(PC)										
  gc_access.go:16	0x10020fb54		b24007e1		ORR $3, ZR, R1										
  execution.go:400	0x10020fb58		14000009		JMP 9(PC)										
  gc_access.go:12	0x10020fb5c		d10072d7		SUB $28, R22, R23									
  gc_access.go:12	0x10020fb60		71000aff		CMPW $2, R23										
  gc_access.go:12	0x10020fb64		54000069		BLS 3(PC)										
  gc_access.go:12	0x10020fb68		71008adf		CMPW $34, R22										
  gc_access.go:12	0x10020fb6c		54000061		BNE 3(PC)										
  gc_access.go:12	0x10020fb70		b24003e1		ORR $1, ZR, R1										
  execution.go:400	0x10020fb74		14000002		JMP 2(PC)										
  execution.go:400	0x10020fb78		aa1f03e1		MOVD ZR, R1										
  execution.go:400	0x10020fb7c		b40007e1		CBZ R1, 63(PC)										
  execution.go:402	0x10020fb80		b9400e96		MOVWU 12(R20), R22									
  execution.go:402	0x10020fb84		310006df		CMNW $1, R22										
  execution.go:402	0x10020fb88		540000c0		BEQ 6(PC)										
  execution.go:403	0x10020fb8c		eb1302df		CMP R19, R22										
  execution.go:403	0x10020fb90		540102a2		BCS 2069(PC)										
  execution.go:403	0x10020fb94		8b161196		ADD R22<<4, R12, R22									
  execution.go:403	0x10020fb98		a94012c3		LDP (R22), (R3, R4)									
  execution.go:403	0x10020fb9c		14000003		JMP 3(PC)										
  execution.go:403	0x10020fba0		aa1f03e4		MOVD ZR, R4										
  execution.go:403	0x10020fba4		aa1f03e3		MOVD ZR, R3										
  execution.go:405	0x10020fba8		b9401296		MOVWU 16(R20), R22									
  execution.go:405	0x10020fbac		310006df		CMNW $1, R22										
  execution.go:405	0x10020fbb0		540000c0		BEQ 6(PC)										
  execution.go:406	0x10020fbb4		eb1302df		CMP R19, R22										
  execution.go:406	0x10020fbb8		54010102		BCS 2056(PC)										
  execution.go:406	0x10020fbbc		8b161196		ADD R22<<4, R12, R22									
  execution.go:406	0x10020fbc0		a9401ac5		LDP (R22), (R5, R6)									
  execution.go:406	0x10020fbc4		14000003		JMP 3(PC)										
  execution.go:406	0x10020fbc8		aa1f03e6		MOVD ZR, R6										
  execution.go:406	0x10020fbcc		aa1f03e5		MOVD ZR, R5										
  execution.go:408	0x10020fbd0		f100083f		CMP $2, R1										
  execution.go:408	0x10020fbd4		540001ad		BLE 13(PC)										
  execution.go:409	0x10020fbd8		a94cddd6		LDP 200(R14), (R22, R23)								
  execution.go:409	0x10020fbdc		b9401a98		MOVWU 24(R20), R24									
  execution.go:409	0x10020fbe0		91000b18		ADD $2, R24, R24									
  execution.go:409	0x10020fbe4		2a1803f8		MOVW R24, R24										
  execution.go:409	0x10020fbe8		eb17031f		CMP R23, R24										
  execution.go:409	0x10020fbec		5400ff02		BCS 2040(PC)										
  execution.go:409	0x10020fbf0		b8787ad6		MOVWU (R22)(R24<<2), R22								
  execution.go:409	0x10020fbf4		eb1302df		CMP R19, R22										
  execution.go:409	0x10020fbf8		5400fe42		BCS 2034(PC)										
  execution.go:409	0x10020fbfc		8b161196		ADD R22<<4, R12, R22									
  execution.go:409	0x10020fc00		a94022c7		LDP (R22), (R7, R8)									
  execution.go:409	0x10020fc04		14000003		JMP 3(PC)										
  execution.go:409	0x10020fc08		aa1f03e7		MOVD ZR, R7										
  execution.go:409	0x10020fc0c		aa1f03e8		MOVD ZR, R8										
  execution.go:412	0x10020fc10		a947ddd6		LDP 120(R14), (R22, R23)								
  execution.go:412	0x10020fc14		b9400698		MOVWU 4(R20), R24									
  execution.go:412	0x10020fc18		aa1803f9		MOVD R24, R25										
  execution.go:412	0x10020fc1c		eb17033f		CMP R23, R25										
  execution.go:412	0x10020fc20		5400fca2		BCS 2021(PC)										
  execution.go:412	0x10020fc24		f9400000		MOVD (R0), R0										
  execution.go:412	0x10020fc28		d3787f09		UBFIZ $8, R24, $32, R9									
  execution.go:412	0x10020fc2c		cb191529		SUB R25<<5, R9, R9									
  execution.go:412	0x10020fc30		8b0902c2		ADD R9, R22, R2										
  execution.go:412	0x10020fc34		aa0d03e1		MOVD R13, R1										
  execution.go:412	0x10020fc38		97ffc37a		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess(SB)		
  execution.go:413	0x10020fc3c		b500b782		CBNZ R2, 1468(PC)									
  execution.go:420	0x10020fc40		f940c3e9		MOVD 384(RSP), R9									
  execution.go:420	0x10020fc44		b9400929		MOVWU 8(R9), R9										
  execution.go:420	0x10020fc48		3100053f		CMNW $1, R9										
  execution.go:420	0x10020fc4c		54000100		BEQ 8(PC)										
  execution.go:421	0x10020fc50		f94087ea		MOVD 264(RSP), R10									
  execution.go:421	0x10020fc54		eb0a013f		CMP R10, R9										
  execution.go:421	0x10020fc58		5400fac2		BCS 2006(PC)										
  execution.go:421	0x10020fc5c		f9409beb		MOVD 304(RSP), R11									
  execution.go:421	0x10020fc60		8b091169		ADD R9<<4, R11, R9									
  execution.go:421	0x10020fc64		a9000520		STP (R0, R1), (R9)									
  execution.go:421	0x10020fc68		1400000a		JMP 10(PC)										
  execution.go:361	0x10020fc6c		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x10020fc70		f9409beb		MOVD 304(RSP), R11									
  execution.go:420	0x10020fc74		14000007		JMP 7(PC)										
  execution.go:424	0x10020fc78		b9000951		MOVW R17, 8(R10)									
  execution.go:425	0x10020fc7c		9400091d		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC(SB)		
  execution.go:425	0x10020fc80		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:425	0x10020fc84		3500b8c1		CBNZW R1, 1478(PC)									
  execution.go:361	0x10020fc88		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x10020fc8c		f9409beb		MOVD 304(RSP), R11									
  execution.go:429	0x10020fc90		b94107e9		MOVWU 260(RSP), R9									
  execution.go:429	0x10020fc94		91000531		ADD $1, R9, R17										
  execution.go:430	0x10020fc98		f940b7e9		MOVD 360(RSP), R9									
  execution.go:430	0x10020fc9c		b9000931		MOVW R17, 8(R9)										
  execution.go:209	0x10020fca0		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x10020fca4		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x10020fca8		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10020fcac		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x10020fcb0		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10020fcb4		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x10020fcb8		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10020fcbc		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10020fcc0		f9408bf0		MOVD 272(RSP), R16									
  execution.go:361	0x10020fcc4		f94087f3		MOVD 264(RSP), R19									
  execution.go:341	0x10020fcc8		f94093f5		MOVD 288(RSP), R21									
  execution.go:431	0x10020fccc		17fffe62		JMP -414(PC)										
  execution.go:479	0x10020fcd0		d1011437		SUB $69, R1, R23									
  execution.go:479	0x10020fcd4		7101feff		CMPW $127, R23										
  execution.go:479	0x10020fcd8		54005468		BHI 675(PC)										
  execution.go:480	0x10020fcdc		aa0103f6		MOVD R1, R22										
  execution.go:480	0x10020fce0		d10116d6		SUB $69, R22, R22									
  execution.go:480	0x10020fce4		d0000fc2		ADRP 2072576(PC), R2									
  execution.go:480	0x10020fce8		91360042		ADD $3456, R2, R2									
  execution.go:480	0x10020fcec		f876785b		MOVD (R2)(R22<<3), R27									
  execution.go:480	0x10020fcf0		d61f0360		JMP (R27)										
  execution.go:482	0x10020fcf4		b9400e96		MOVWU 12(R20), R22									
  execution.go:482	0x10020fcf8		eb1302df		CMP R19, R22										
  execution.go:482	0x10020fcfc		5400f542		BCS 1962(PC)										
  execution.go:482	0x10020fd00		8b161196		ADD R22<<4, R12, R22									
  execution.go:482	0x10020fd04		f94002d6		MOVD (R22), R22										
  integer.go:9		0x10020fd08		710002df		CMPW $0, R22										
  integer.go:9		0x10020fd0c		9a9f17f6		CSET EQ, R22										
  execution.go:482	0x10020fd10		14000293		JMP 659(PC)										
  execution.go:484	0x10020fd14		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:484	0x10020fd18		eb1302df		CMP R19, R22										
  execution.go:484	0x10020fd1c		5400f3e2		BCS 1951(PC)										
  execution.go:484	0x10020fd20		8b161196		ADD R22<<4, R12, R22									
  execution.go:484	0x10020fd24		eb1302ff		CMP R19, R23										
  execution.go:484	0x10020fd28		5400f322		BCS 1945(PC)										
  execution.go:484	0x10020fd2c		f94002d8		MOVD (R22), R24										
  execution.go:484	0x10020fd30		8b171197		ADD R23<<4, R12, R23									
  execution.go:484	0x10020fd34		f94002f7		MOVD (R23), R23										
  integer.go:10		0x10020fd38		6b1802ff		CMPW R24, R23										
  integer.go:10		0x10020fd3c		9a9f17f6		CSET EQ, R22										
  execution.go:484	0x10020fd40		14000287		JMP 647(PC)										
  execution.go:486	0x10020fd44		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:486	0x10020fd48		eb1302df		CMP R19, R22										
  execution.go:486	0x10020fd4c		5400f1a2		BCS 1933(PC)										
  execution.go:486	0x10020fd50		8b161196		ADD R22<<4, R12, R22									
  execution.go:486	0x10020fd54		eb1302ff		CMP R19, R23										
  execution.go:486	0x10020fd58		5400f0e2		BCS 1927(PC)										
  execution.go:486	0x10020fd5c		f94002d8		MOVD (R22), R24										
  execution.go:486	0x10020fd60		8b171197		ADD R23<<4, R12, R23									
  execution.go:486	0x10020fd64		f94002f7		MOVD (R23), R23										
  integer.go:11		0x10020fd68		6b1802ff		CMPW R24, R23										
  integer.go:11		0x10020fd6c		9a9f07f6		CSET NE, R22										
  execution.go:486	0x10020fd70		1400027b		JMP 635(PC)										
  execution.go:488	0x10020fd74		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:488	0x10020fd78		eb1302df		CMP R19, R22										
  execution.go:488	0x10020fd7c		5400ef62		BCS 1915(PC)										
  execution.go:488	0x10020fd80		8b161196		ADD R22<<4, R12, R22									
  execution.go:488	0x10020fd84		eb1302ff		CMP R19, R23										
  execution.go:488	0x10020fd88		5400eea2		BCS 1909(PC)										
  execution.go:488	0x10020fd8c		f94002d8		MOVD (R22), R24										
  execution.go:488	0x10020fd90		8b171197		ADD R23<<4, R12, R23									
  execution.go:488	0x10020fd94		f94002f7		MOVD (R23), R23										
  integer.go:12		0x10020fd98		6b1802ff		CMPW R24, R23										
  integer.go:12		0x10020fd9c		9a9fd7f6		CSET GT, R22										
  execution.go:488	0x10020fda0		1400026f		JMP 623(PC)										
  execution.go:490	0x10020fda4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:490	0x10020fda8		eb1302df		CMP R19, R22										
  execution.go:490	0x10020fdac		5400ed22		BCS 1897(PC)										
  execution.go:490	0x10020fdb0		8b161196		ADD R22<<4, R12, R22									
  execution.go:490	0x10020fdb4		eb1302ff		CMP R19, R23										
  execution.go:490	0x10020fdb8		5400ec62		BCS 1891(PC)										
  execution.go:490	0x10020fdbc		f94002d8		MOVD (R22), R24										
  execution.go:490	0x10020fdc0		8b171197		ADD R23<<4, R12, R23									
  execution.go:490	0x10020fdc4		f94002f7		MOVD (R23), R23										
  integer.go:13		0x10020fdc8		6b1802ff		CMPW R24, R23										
  integer.go:13		0x10020fdcc		9a9f97f6		CSET HI, R22										
  execution.go:490	0x10020fdd0		14000263		JMP 611(PC)										
  execution.go:492	0x10020fdd4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:492	0x10020fdd8		eb1302df		CMP R19, R22										
  execution.go:492	0x10020fddc		5400eae2		BCS 1879(PC)										
  execution.go:492	0x10020fde0		8b161196		ADD R22<<4, R12, R22									
  execution.go:492	0x10020fde4		eb1302ff		CMP R19, R23										
  execution.go:492	0x10020fde8		5400ea22		BCS 1873(PC)										
  execution.go:492	0x10020fdec		f94002d8		MOVD (R22), R24										
  execution.go:492	0x10020fdf0		8b171197		ADD R23<<4, R12, R23									
  execution.go:492	0x10020fdf4		f94002f7		MOVD (R23), R23										
  integer.go:14		0x10020fdf8		6b1802ff		CMPW R24, R23										
  integer.go:14		0x10020fdfc		9a9fa7f6		CSET LT, R22										
  execution.go:492	0x10020fe00		14000257		JMP 599(PC)										
  execution.go:494	0x10020fe04		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:494	0x10020fe08		eb1302df		CMP R19, R22										
  execution.go:494	0x10020fe0c		5400e8a2		BCS 1861(PC)										
  execution.go:494	0x10020fe10		8b161196		ADD R22<<4, R12, R22									
  execution.go:494	0x10020fe14		eb1302ff		CMP R19, R23										
  execution.go:494	0x10020fe18		5400e7e2		BCS 1855(PC)										
  execution.go:494	0x10020fe1c		f94002d8		MOVD (R22), R24										
  execution.go:494	0x10020fe20		8b171197		ADD R23<<4, R12, R23									
  execution.go:494	0x10020fe24		f94002f7		MOVD (R23), R23										
  integer.go:15		0x10020fe28		6b1802ff		CMPW R24, R23										
  integer.go:15		0x10020fe2c		9a9f27f6		CSET LO, R22										
  execution.go:494	0x10020fe30		1400024b		JMP 587(PC)										
  execution.go:496	0x10020fe34		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:496	0x10020fe38		eb1302df		CMP R19, R22										
  execution.go:496	0x10020fe3c		5400e662		BCS 1843(PC)										
  execution.go:496	0x10020fe40		8b161196		ADD R22<<4, R12, R22									
  execution.go:496	0x10020fe44		eb1302ff		CMP R19, R23										
  execution.go:496	0x10020fe48		5400e5a2		BCS 1837(PC)										
  execution.go:496	0x10020fe4c		f94002d8		MOVD (R22), R24										
  execution.go:496	0x10020fe50		8b171197		ADD R23<<4, R12, R23									
  execution.go:496	0x10020fe54		f94002f7		MOVD (R23), R23										
  integer.go:16		0x10020fe58		6b1802ff		CMPW R24, R23										
  integer.go:16		0x10020fe5c		9a9fb7f6		CSET GE, R22										
  execution.go:496	0x10020fe60		1400023f		JMP 575(PC)										
  execution.go:498	0x10020fe64		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:498	0x10020fe68		eb1302df		CMP R19, R22										
  execution.go:498	0x10020fe6c		5400e422		BCS 1825(PC)										
  execution.go:498	0x10020fe70		8b161196		ADD R22<<4, R12, R22									
  execution.go:498	0x10020fe74		eb1302ff		CMP R19, R23										
  execution.go:498	0x10020fe78		5400e362		BCS 1819(PC)										
  execution.go:498	0x10020fe7c		f94002d8		MOVD (R22), R24										
  execution.go:498	0x10020fe80		8b171197		ADD R23<<4, R12, R23									
  execution.go:498	0x10020fe84		f94002f7		MOVD (R23), R23										
  integer.go:17		0x10020fe88		6b1802ff		CMPW R24, R23										
  integer.go:17		0x10020fe8c		9a9f37f6		CSET HS, R22										
  execution.go:498	0x10020fe90		14000233		JMP 563(PC)										
  execution.go:500	0x10020fe94		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:500	0x10020fe98		eb1302df		CMP R19, R22										
  execution.go:500	0x10020fe9c		5400e1e2		BCS 1807(PC)										
  execution.go:500	0x10020fea0		8b161196		ADD R22<<4, R12, R22									
  execution.go:500	0x10020fea4		eb1302ff		CMP R19, R23										
  execution.go:500	0x10020fea8		5400e122		BCS 1801(PC)										
  execution.go:500	0x10020feac		f94002d8		MOVD (R22), R24										
  execution.go:500	0x10020feb0		8b171197		ADD R23<<4, R12, R23									
  execution.go:500	0x10020feb4		f94002f7		MOVD (R23), R23										
  integer.go:18		0x10020feb8		6b1802ff		CMPW R24, R23										
  integer.go:18		0x10020febc		9a9fc7f6		CSET LE, R22										
  execution.go:500	0x10020fec0		14000227		JMP 551(PC)										
  execution.go:502	0x10020fec4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:502	0x10020fec8		eb1302df		CMP R19, R22										
  execution.go:502	0x10020fecc		5400dfa2		BCS 1789(PC)										
  execution.go:502	0x10020fed0		8b161196		ADD R22<<4, R12, R22									
  execution.go:502	0x10020fed4		eb1302ff		CMP R19, R23										
  execution.go:502	0x10020fed8		5400dee2		BCS 1783(PC)										
  execution.go:502	0x10020fedc		f94002d8		MOVD (R22), R24										
  execution.go:502	0x10020fee0		8b171197		ADD R23<<4, R12, R23									
  execution.go:502	0x10020fee4		f94002f7		MOVD (R23), R23										
  integer.go:19		0x10020fee8		6b1802ff		CMPW R24, R23										
  integer.go:19		0x10020feec		9a9f87f6		CSET LS, R22										
  execution.go:502	0x10020fef0		1400021b		JMP 539(PC)										
  execution.go:504	0x10020fef4		b9400e96		MOVWU 12(R20), R22									
  execution.go:504	0x10020fef8		eb1302df		CMP R19, R22										
  execution.go:504	0x10020fefc		5400dd62		BCS 1771(PC)										
  execution.go:504	0x10020ff00		8b161197		ADD R22<<4, R12, R23									
  execution.go:504	0x10020ff04		f94002f7		MOVD (R23), R23										
  integer.go:20		0x10020ff08		f10002ff		CMP $0, R23										
  integer.go:20		0x10020ff0c		9a9f17f6		CSET EQ, R22										
  execution.go:504	0x10020ff10		14000213		JMP 531(PC)										
  execution.go:506	0x10020ff14		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:506	0x10020ff18		eb1302df		CMP R19, R22										
  execution.go:506	0x10020ff1c		5400dc02		BCS 1760(PC)										
  execution.go:506	0x10020ff20		8b161196		ADD R22<<4, R12, R22									
  execution.go:506	0x10020ff24		eb1302ff		CMP R19, R23										
  execution.go:506	0x10020ff28		5400db42		BCS 1754(PC)										
  execution.go:506	0x10020ff2c		f94002d8		MOVD (R22), R24										
  execution.go:506	0x10020ff30		8b171197		ADD R23<<4, R12, R23									
  execution.go:506	0x10020ff34		f94002f7		MOVD (R23), R23										
  integer.go:21		0x10020ff38		eb1802ff		CMP R24, R23										
  integer.go:21		0x10020ff3c		9a9f17f6		CSET EQ, R22										
  execution.go:506	0x10020ff40		14000207		JMP 519(PC)										
  execution.go:508	0x10020ff44		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:508	0x10020ff48		eb1302df		CMP R19, R22										
  execution.go:508	0x10020ff4c		5400d9c2		BCS 1742(PC)										
  execution.go:508	0x10020ff50		8b161196		ADD R22<<4, R12, R22									
  execution.go:508	0x10020ff54		eb1302ff		CMP R19, R23										
  execution.go:508	0x10020ff58		5400d902		BCS 1736(PC)										
  execution.go:508	0x10020ff5c		f94002d8		MOVD (R22), R24										
  execution.go:508	0x10020ff60		8b171197		ADD R23<<4, R12, R23									
  execution.go:508	0x10020ff64		f94002f7		MOVD (R23), R23										
  integer.go:22		0x10020ff68		eb1802ff		CMP R24, R23										
  integer.go:22		0x10020ff6c		9a9f07f6		CSET NE, R22										
  execution.go:508	0x10020ff70		140001fb		JMP 507(PC)										
  execution.go:510	0x10020ff74		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:510	0x10020ff78		eb1302df		CMP R19, R22										
  execution.go:510	0x10020ff7c		5400d782		BCS 1724(PC)										
  execution.go:510	0x10020ff80		8b161196		ADD R22<<4, R12, R22									
  execution.go:510	0x10020ff84		eb1302ff		CMP R19, R23										
  execution.go:510	0x10020ff88		5400d6c2		BCS 1718(PC)										
  execution.go:510	0x10020ff8c		f94002d8		MOVD (R22), R24										
  execution.go:510	0x10020ff90		8b171197		ADD R23<<4, R12, R23									
  execution.go:510	0x10020ff94		f94002f7		MOVD (R23), R23										
  integer.go:23		0x10020ff98		eb1802ff		CMP R24, R23										
  integer.go:23		0x10020ff9c		9a9fd7f6		CSET GT, R22										
  execution.go:510	0x10020ffa0		140001ef		JMP 495(PC)										
  execution.go:512	0x10020ffa4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:512	0x10020ffa8		eb1302df		CMP R19, R22										
  execution.go:512	0x10020ffac		5400d542		BCS 1706(PC)										
  execution.go:512	0x10020ffb0		8b161196		ADD R22<<4, R12, R22									
  execution.go:512	0x10020ffb4		eb1302ff		CMP R19, R23										
  execution.go:512	0x10020ffb8		5400d482		BCS 1700(PC)										
  execution.go:512	0x10020ffbc		f94002d8		MOVD (R22), R24										
  execution.go:512	0x10020ffc0		8b171197		ADD R23<<4, R12, R23									
  execution.go:512	0x10020ffc4		f94002f7		MOVD (R23), R23										
  integer.go:24		0x10020ffc8		eb1802ff		CMP R24, R23										
  integer.go:24		0x10020ffcc		9a9f97f6		CSET HI, R22										
  execution.go:512	0x10020ffd0		140001e3		JMP 483(PC)										
  execution.go:514	0x10020ffd4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:514	0x10020ffd8		eb1302df		CMP R19, R22										
  execution.go:514	0x10020ffdc		5400d302		BCS 1688(PC)										
  execution.go:514	0x10020ffe0		8b161196		ADD R22<<4, R12, R22									
  execution.go:514	0x10020ffe4		eb1302ff		CMP R19, R23										
  execution.go:514	0x10020ffe8		5400d242		BCS 1682(PC)										
  execution.go:514	0x10020ffec		f94002d8		MOVD (R22), R24										
  execution.go:514	0x10020fff0		8b171197		ADD R23<<4, R12, R23									
  execution.go:514	0x10020fff4		f94002f7		MOVD (R23), R23										
  integer.go:25		0x10020fff8		eb1802ff		CMP R24, R23										
  integer.go:25		0x10020fffc		9a9fa7f6		CSET LT, R22										
  execution.go:514	0x100210000		140001d7		JMP 471(PC)										
  execution.go:516	0x100210004		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:516	0x100210008		eb1302df		CMP R19, R22										
  execution.go:516	0x10021000c		5400d0c2		BCS 1670(PC)										
  execution.go:516	0x100210010		8b161196		ADD R22<<4, R12, R22									
  execution.go:516	0x100210014		eb1302ff		CMP R19, R23										
  execution.go:516	0x100210018		5400d002		BCS 1664(PC)										
  execution.go:516	0x10021001c		f94002d8		MOVD (R22), R24										
  execution.go:516	0x100210020		8b171197		ADD R23<<4, R12, R23									
  execution.go:516	0x100210024		f94002f7		MOVD (R23), R23										
  integer.go:26		0x100210028		eb1802ff		CMP R24, R23										
  integer.go:26		0x10021002c		9a9f27f6		CSET LO, R22										
  execution.go:516	0x100210030		140001cb		JMP 459(PC)										
  execution.go:518	0x100210034		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:518	0x100210038		eb1302df		CMP R19, R22										
  execution.go:518	0x10021003c		5400ce82		BCS 1652(PC)										
  execution.go:518	0x100210040		8b161196		ADD R22<<4, R12, R22									
  execution.go:518	0x100210044		eb1302ff		CMP R19, R23										
  execution.go:518	0x100210048		5400cdc2		BCS 1646(PC)										
  execution.go:518	0x10021004c		f94002d8		MOVD (R22), R24										
  execution.go:518	0x100210050		8b171197		ADD R23<<4, R12, R23									
  execution.go:518	0x100210054		f94002f7		MOVD (R23), R23										
  integer.go:27		0x100210058		eb1802ff		CMP R24, R23										
  integer.go:27		0x10021005c		9a9fb7f6		CSET GE, R22										
  execution.go:518	0x100210060		140001bf		JMP 447(PC)										
  execution.go:520	0x100210064		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:520	0x100210068		eb1302df		CMP R19, R22										
  execution.go:520	0x10021006c		5400cc42		BCS 1634(PC)										
  execution.go:520	0x100210070		8b161196		ADD R22<<4, R12, R22									
  execution.go:520	0x100210074		eb1302ff		CMP R19, R23										
  execution.go:520	0x100210078		5400cb82		BCS 1628(PC)										
  execution.go:520	0x10021007c		f94002d8		MOVD (R22), R24										
  execution.go:520	0x100210080		8b171197		ADD R23<<4, R12, R23									
  execution.go:520	0x100210084		f94002f7		MOVD (R23), R23										
  integer.go:28		0x100210088		eb1802ff		CMP R24, R23										
  integer.go:28		0x10021008c		9a9f37f6		CSET HS, R22										
  execution.go:520	0x100210090		140001b3		JMP 435(PC)										
  execution.go:522	0x100210094		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:522	0x100210098		eb1302df		CMP R19, R22										
  execution.go:522	0x10021009c		5400ca02		BCS 1616(PC)										
  execution.go:522	0x1002100a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:522	0x1002100a4		eb1302ff		CMP R19, R23										
  execution.go:522	0x1002100a8		5400c942		BCS 1610(PC)										
  execution.go:522	0x1002100ac		f94002d8		MOVD (R22), R24										
  execution.go:522	0x1002100b0		8b171197		ADD R23<<4, R12, R23									
  execution.go:522	0x1002100b4		f94002f7		MOVD (R23), R23										
  integer.go:29		0x1002100b8		eb1802ff		CMP R24, R23										
  integer.go:29		0x1002100bc		9a9fc7f6		CSET LE, R22										
  execution.go:522	0x1002100c0		140001a7		JMP 423(PC)										
  execution.go:524	0x1002100c4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:524	0x1002100c8		eb1302df		CMP R19, R22										
  execution.go:524	0x1002100cc		5400c7c2		BCS 1598(PC)										
  execution.go:524	0x1002100d0		8b161196		ADD R22<<4, R12, R22									
  execution.go:524	0x1002100d4		eb1302ff		CMP R19, R23										
  execution.go:524	0x1002100d8		5400c702		BCS 1592(PC)										
  execution.go:524	0x1002100dc		f94002d8		MOVD (R22), R24										
  execution.go:524	0x1002100e0		8b171197		ADD R23<<4, R12, R23									
  execution.go:524	0x1002100e4		f94002f7		MOVD (R23), R23										
  integer.go:30		0x1002100e8		eb1802ff		CMP R24, R23										
  integer.go:30		0x1002100ec		9a9f87f6		CSET LS, R22										
  execution.go:524	0x1002100f0		1400019b		JMP 411(PC)										
  execution.go:526	0x1002100f4		b9400e96		MOVWU 12(R20), R22									
  execution.go:526	0x1002100f8		eb1302df		CMP R19, R22										
  execution.go:526	0x1002100fc		5400c582		BCS 1580(PC)										
  execution.go:526	0x100210100		8b161197		ADD R22<<4, R12, R23									
  execution.go:526	0x100210104		f94002f7		MOVD (R23), R23										
  integer.go:31		0x100210108		d503201f		NOOP											
  bits.go:34		0x10021010c		5ac012f6		CLZW R23, R22										
  execution.go:526	0x100210110		14000193		JMP 403(PC)										
  execution.go:528	0x100210114		b9400e96		MOVWU 12(R20), R22									
  execution.go:528	0x100210118		eb1302df		CMP R19, R22										
  execution.go:528	0x10021011c		5400c422		BCS 1569(PC)										
  execution.go:528	0x100210120		8b161197		ADD R22<<4, R12, R23									
  execution.go:528	0x100210124		f94002f7		MOVD (R23), R23										
  integer.go:32		0x100210128		5ac002f7		RBITW R23, R23										
  integer.go:32		0x10021012c		5ac012f6		CLZW R23, R22										
  execution.go:528	0x100210130		1400018b		JMP 395(PC)										
  execution.go:538	0x100210134		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:538	0x100210138		eb1302df		CMP R19, R22										
  execution.go:538	0x10021013c		5400c2c2		BCS 1558(PC)										
  execution.go:538	0x100210140		8b161196		ADD R22<<4, R12, R22									
  execution.go:538	0x100210144		eb1302ff		CMP R19, R23										
  execution.go:538	0x100210148		5400c202		BCS 1552(PC)										
  execution.go:538	0x10021014c		f94002d8		MOVD (R22), R24										
  execution.go:538	0x100210150		8b171197		ADD R23<<4, R12, R23									
  execution.go:538	0x100210154		f94002f7		MOVD (R23), R23										
  integer.go:34		0x100210158		8b170317		ADD R23, R24, R23									
  integer.go:34		0x10021015c		2a1703f6		MOVW R23, R22										
  execution.go:538	0x100210160		1400017f		JMP 383(PC)										
  execution.go:540	0x100210164		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:540	0x100210168		eb1302df		CMP R19, R22										
  execution.go:540	0x10021016c		5400c082		BCS 1540(PC)										
  execution.go:540	0x100210170		8b161196		ADD R22<<4, R12, R22									
  execution.go:540	0x100210174		eb1302ff		CMP R19, R23										
  execution.go:540	0x100210178		5400bfc2		BCS 1534(PC)										
  execution.go:540	0x10021017c		f94002d8		MOVD (R22), R24										
  execution.go:540	0x100210180		8b171197		ADD R23<<4, R12, R23									
  execution.go:540	0x100210184		f94002f7		MOVD (R23), R23										
  integer.go:35		0x100210188		cb170317		SUB R23, R24, R23									
  integer.go:35		0x10021018c		2a1703f6		MOVW R23, R22										
  execution.go:540	0x100210190		14000173		JMP 371(PC)										
  execution.go:542	0x100210194		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:542	0x100210198		eb1302df		CMP R19, R22										
  execution.go:542	0x10021019c		5400be42		BCS 1522(PC)										
  execution.go:542	0x1002101a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:542	0x1002101a4		eb1302ff		CMP R19, R23										
  execution.go:542	0x1002101a8		5400bd82		BCS 1516(PC)										
  execution.go:542	0x1002101ac		f94002d8		MOVD (R22), R24										
  execution.go:542	0x1002101b0		8b171197		ADD R23<<4, R12, R23									
  execution.go:542	0x1002101b4		f94002f7		MOVD (R23), R23										
  integer.go:36		0x1002101b8		1b177f16		MULW R23, R24, R22									
  execution.go:542	0x1002101bc		14000168		JMP 360(PC)										
  execution.go:544	0x1002101c0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:544	0x1002101c4		eb1302df		CMP R19, R22										
  execution.go:544	0x1002101c8		5400bc22		BCS 1505(PC)										
  execution.go:544	0x1002101cc		8b161196		ADD R22<<4, R12, R22									
  execution.go:544	0x1002101d0		eb1302ff		CMP R19, R23										
  execution.go:544	0x1002101d4		5400bb62		BCS 1499(PC)										
  execution.go:544	0x1002101d8		f94002d8		MOVD (R22), R24										
  execution.go:544	0x1002101dc		8b171197		ADD R23<<4, R12, R23									
  execution.go:544	0x1002101e0		f94002f7		MOVD (R23), R23										
  integer.go:37		0x1002101e4		8a170317		AND R23, R24, R23									
  integer.go:37		0x1002101e8		2a1703f6		MOVW R23, R22										
  execution.go:544	0x1002101ec		1400015c		JMP 348(PC)										
  execution.go:546	0x1002101f0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:546	0x1002101f4		eb1302df		CMP R19, R22										
  execution.go:546	0x1002101f8		5400b9e2		BCS 1487(PC)										
  execution.go:546	0x1002101fc		8b161196		ADD R22<<4, R12, R22									
  execution.go:546	0x100210200		eb1302ff		CMP R19, R23										
  execution.go:546	0x100210204		5400b922		BCS 1481(PC)										
  execution.go:546	0x100210208		f94002d8		MOVD (R22), R24										
  execution.go:546	0x10021020c		8b171197		ADD R23<<4, R12, R23									
  execution.go:546	0x100210210		f94002f7		MOVD (R23), R23										
  integer.go:38		0x100210214		aa170317		ORR R23, R24, R23									
  integer.go:38		0x100210218		2a1703f6		MOVW R23, R22										
  execution.go:546	0x10021021c		14000150		JMP 336(PC)										
  execution.go:548	0x100210220		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:548	0x100210224		eb1302df		CMP R19, R22										
  execution.go:548	0x100210228		5400b7a2		BCS 1469(PC)										
  execution.go:548	0x10021022c		8b161196		ADD R22<<4, R12, R22									
  execution.go:548	0x100210230		eb1302ff		CMP R19, R23										
  execution.go:548	0x100210234		5400b6e2		BCS 1463(PC)										
  execution.go:548	0x100210238		f94002d8		MOVD (R22), R24										
  execution.go:548	0x10021023c		8b171197		ADD R23<<4, R12, R23									
  execution.go:548	0x100210240		f94002f7		MOVD (R23), R23										
  integer.go:39		0x100210244		ca170317		EOR R23, R24, R23									
  integer.go:39		0x100210248		2a1703f6		MOVW R23, R22										
  execution.go:548	0x10021024c		14000144		JMP 324(PC)										
  execution.go:550	0x100210250		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:550	0x100210254		eb1302df		CMP R19, R22										
  execution.go:550	0x100210258		5400b562		BCS 1451(PC)										
  execution.go:550	0x10021025c		8b161196		ADD R22<<4, R12, R22									
  execution.go:550	0x100210260		eb1302ff		CMP R19, R23										
  execution.go:550	0x100210264		5400b4a2		BCS 1445(PC)										
  execution.go:550	0x100210268		f94002d8		MOVD (R22), R24										
  execution.go:550	0x10021026c		8b171197		ADD R23<<4, R12, R23									
  execution.go:550	0x100210270		f94002f7		MOVD (R23), R23										
  integer.go:40		0x100210274		924012f7		AND $31, R23, R23									
  integer.go:40		0x100210278		9ad72317		LSL R23, R24, R23									
  integer.go:40		0x10021027c		2a1703f6		MOVW R23, R22										
  execution.go:550	0x100210280		14000137		JMP 311(PC)										
  execution.go:552	0x100210284		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:552	0x100210288		eb1302df		CMP R19, R22										
  execution.go:552	0x10021028c		5400b302		BCS 1432(PC)										
  execution.go:552	0x100210290		8b161196		ADD R22<<4, R12, R22									
  execution.go:552	0x100210294		eb1302ff		CMP R19, R23										
  execution.go:552	0x100210298		5400b242		BCS 1426(PC)										
  execution.go:552	0x10021029c		f94002d8		MOVD (R22), R24										
  execution.go:552	0x1002102a0		8b171197		ADD R23<<4, R12, R23									
  execution.go:552	0x1002102a4		f94002f7		MOVD (R23), R23										
  integer.go:41		0x1002102a8		93407f18		SXTW R24, R24										
  integer.go:41		0x1002102ac		924012f7		AND $31, R23, R23									
  integer.go:41		0x1002102b0		9ad72b17		ASR R23, R24, R23									
  integer.go:41		0x1002102b4		2a1703f6		MOVW R23, R22										
  execution.go:552	0x1002102b8		14000129		JMP 297(PC)										
  execution.go:554	0x1002102bc		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:554	0x1002102c0		eb1302df		CMP R19, R22										
  execution.go:554	0x1002102c4		5400b082		BCS 1412(PC)										
  execution.go:554	0x1002102c8		8b161196		ADD R22<<4, R12, R22									
  execution.go:554	0x1002102cc		eb1302ff		CMP R19, R23										
  execution.go:554	0x1002102d0		5400afc2		BCS 1406(PC)										
  execution.go:554	0x1002102d4		f94002d8		MOVD (R22), R24										
  execution.go:554	0x1002102d8		8b171197		ADD R23<<4, R12, R23									
  execution.go:554	0x1002102dc		f94002f7		MOVD (R23), R23										
  integer.go:42		0x1002102e0		2a1803f8		MOVW R24, R24										
  integer.go:42		0x1002102e4		924012f7		AND $31, R23, R23									
  integer.go:42		0x1002102e8		9ad72717		LSR R23, R24, R23									
  integer.go:42		0x1002102ec		2a1703f6		MOVW R23, R22										
  execution.go:554	0x1002102f0		1400011b		JMP 283(PC)										
  execution.go:556	0x1002102f4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:556	0x1002102f8		eb1302df		CMP R19, R22										
  execution.go:556	0x1002102fc		5400ae02		BCS 1392(PC)										
  execution.go:556	0x100210300		8b161196		ADD R22<<4, R12, R22									
  execution.go:556	0x100210304		eb1302ff		CMP R19, R23										
  execution.go:556	0x100210308		5400ad42		BCS 1386(PC)										
  execution.go:556	0x10021030c		f94002d8		MOVD (R22), R24										
  execution.go:556	0x100210310		8b171197		ADD R23<<4, R12, R23									
  execution.go:556	0x100210314		f94002f7		MOVD (R23), R23										
  integer.go:43		0x100210318		cb1703f7		NEG R23, R23										
  integer.go:43		0x10021031c		1ad72f16		RORW R23, R24, R22									
  execution.go:556	0x100210320		1400010f		JMP 271(PC)										
  execution.go:558	0x100210324		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:558	0x100210328		eb1302df		CMP R19, R22										
  execution.go:558	0x10021032c		5400abc2		BCS 1374(PC)										
  execution.go:558	0x100210330		8b161196		ADD R22<<4, R12, R22									
  execution.go:558	0x100210334		eb1302ff		CMP R19, R23										
  execution.go:558	0x100210338		5400ab02		BCS 1368(PC)										
  execution.go:558	0x10021033c		f94002d8		MOVD (R22), R24										
  execution.go:558	0x100210340		8b171197		ADD R23<<4, R12, R23									
  execution.go:558	0x100210344		f94002f7		MOVD (R23), R23										
  integer.go:44		0x100210348		1ad72f16		RORW R23, R24, R22									
  execution.go:558	0x10021034c		14000104		JMP 260(PC)										
  execution.go:560	0x100210350		b9400e96		MOVWU 12(R20), R22									
  execution.go:560	0x100210354		eb1302df		CMP R19, R22										
  execution.go:560	0x100210358		5400a9a2		BCS 1357(PC)										
  execution.go:560	0x10021035c		8b161197		ADD R22<<4, R12, R23									
  execution.go:560	0x100210360		f94002f7		MOVD (R23), R23										
  integer.go:45		0x100210364		d503201f		NOOP											
  bits.go:37		0x100210368		dac012f6		CLZ R23, R22										
  execution.go:560	0x10021036c		140000fc		JMP 252(PC)										
  execution.go:562	0x100210370		b9400e96		MOVWU 12(R20), R22									
  execution.go:562	0x100210374		eb1302df		CMP R19, R22										
  execution.go:562	0x100210378		5400a842		BCS 1346(PC)										
  execution.go:562	0x10021037c		8b161197		ADD R22<<4, R12, R23									
  execution.go:562	0x100210380		f94002f7		MOVD (R23), R23										
  integer.go:46		0x100210384		dac002f7		RBIT R23, R23										
  integer.go:46		0x100210388		dac012f6		CLZ R23, R22										
  execution.go:562	0x10021038c		140000f4		JMP 244(PC)										
  execution.go:532	0x100210390		b9400e96		MOVWU 12(R20), R22									
  execution.go:532	0x100210394		eb1302df		CMP R19, R22										
  execution.go:532	0x100210398		5400a6e2		BCS 1335(PC)										
  execution.go:532	0x10021039c		8b161197		ADD R22<<4, R12, R23									
  execution.go:532	0x1002103a0		f94002f7		MOVD (R23), R23										
  execution.go:534	0x1002103a4		2a1703f8		MOVW R23, R24										
  execution.go:536	0x1002103a8		d503201f		NOOP											
  execution.go:533	0x1002103ac		7101a43f		CMPW $105, R1										
  execution.go:534	0x1002103b0		9a970317		CSEL EQ, R24, R23, R23									
  integer.go:47		0x1002103b4		9e6702e0		FMOVD R23, F0										
  integer.go:47		0x1002103b8		0e205800		VCNT V0.B8, V0.B8									
  integer.go:47		0x1002103bc		2e303800		VUADDLV V0.B8, V0									
  integer.go:47		0x1002103c0		9e660016		FMOVD F0, R22										
  execution.go:533	0x1002103c4		140000e6		JMP 230(PC)										
  execution.go:564	0x1002103c8		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:564	0x1002103cc		eb1302df		CMP R19, R22										
  execution.go:564	0x1002103d0		5400a4c2		BCS 1318(PC)										
  execution.go:564	0x1002103d4		8b161196		ADD R22<<4, R12, R22									
  execution.go:564	0x1002103d8		eb1302ff		CMP R19, R23										
  execution.go:564	0x1002103dc		5400a402		BCS 1312(PC)										
  execution.go:564	0x1002103e0		f94002d8		MOVD (R22), R24										
  execution.go:564	0x1002103e4		8b171197		ADD R23<<4, R12, R23									
  execution.go:564	0x1002103e8		f94002f7		MOVD (R23), R23										
  integer.go:48		0x1002103ec		8b170316		ADD R23, R24, R22									
  execution.go:564	0x1002103f0		140000db		JMP 219(PC)										
  execution.go:566	0x1002103f4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:566	0x1002103f8		eb1302df		CMP R19, R22										
  execution.go:566	0x1002103fc		5400a2a2		BCS 1301(PC)										
  execution.go:566	0x100210400		8b161196		ADD R22<<4, R12, R22									
  execution.go:566	0x100210404		eb1302ff		CMP R19, R23										
  execution.go:566	0x100210408		5400a1e2		BCS 1295(PC)										
  execution.go:566	0x10021040c		f94002d8		MOVD (R22), R24										
  execution.go:566	0x100210410		8b171197		ADD R23<<4, R12, R23									
  execution.go:566	0x100210414		f94002f7		MOVD (R23), R23										
  integer.go:49		0x100210418		cb170316		SUB R23, R24, R22									
  execution.go:566	0x10021041c		140000d0		JMP 208(PC)										
  execution.go:568	0x100210420		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:568	0x100210424		eb1302df		CMP R19, R22										
  execution.go:568	0x100210428		5400a082		BCS 1284(PC)										
  execution.go:568	0x10021042c		8b161196		ADD R22<<4, R12, R22									
  execution.go:568	0x100210430		eb1302ff		CMP R19, R23										
  execution.go:568	0x100210434		54009fc2		BCS 1278(PC)										
  execution.go:568	0x100210438		f94002d8		MOVD (R22), R24										
  execution.go:568	0x10021043c		8b171197		ADD R23<<4, R12, R23									
  execution.go:568	0x100210440		f94002f7		MOVD (R23), R23										
  integer.go:50		0x100210444		9b187ef6		MUL R24, R23, R22									
  execution.go:568	0x100210448		140000c5		JMP 197(PC)										
  execution.go:570	0x10021044c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:570	0x100210450		eb1302df		CMP R19, R22										
  execution.go:570	0x100210454		54009e62		BCS 1267(PC)										
  execution.go:570	0x100210458		8b161196		ADD R22<<4, R12, R22									
  execution.go:570	0x10021045c		eb1302ff		CMP R19, R23										
  execution.go:570	0x100210460		54009da2		BCS 1261(PC)										
  execution.go:570	0x100210464		f94002d8		MOVD (R22), R24										
  execution.go:570	0x100210468		8b171197		ADD R23<<4, R12, R23									
  execution.go:570	0x10021046c		f94002f7		MOVD (R23), R23										
  integer.go:51		0x100210470		8a170316		AND R23, R24, R22									
  execution.go:570	0x100210474		140000ba		JMP 186(PC)										
  execution.go:572	0x100210478		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:572	0x10021047c		eb1302df		CMP R19, R22										
  execution.go:572	0x100210480		54009c42		BCS 1250(PC)										
  execution.go:572	0x100210484		8b161196		ADD R22<<4, R12, R22									
  execution.go:572	0x100210488		eb1302ff		CMP R19, R23										
  execution.go:572	0x10021048c		54009b82		BCS 1244(PC)										
  execution.go:572	0x100210490		f94002d8		MOVD (R22), R24										
  execution.go:572	0x100210494		8b171197		ADD R23<<4, R12, R23									
  execution.go:572	0x100210498		f94002f7		MOVD (R23), R23										
  integer.go:52		0x10021049c		aa170316		ORR R23, R24, R22									
  execution.go:572	0x1002104a0		140000af		JMP 175(PC)										
  execution.go:574	0x1002104a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:574	0x1002104a8		eb1302df		CMP R19, R22										
  execution.go:574	0x1002104ac		54009a22		BCS 1233(PC)										
  execution.go:574	0x1002104b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:574	0x1002104b4		eb1302ff		CMP R19, R23										
  execution.go:574	0x1002104b8		54009962		BCS 1227(PC)										
  execution.go:574	0x1002104bc		f94002d8		MOVD (R22), R24										
  execution.go:574	0x1002104c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:574	0x1002104c4		f94002f7		MOVD (R23), R23										
  integer.go:53		0x1002104c8		ca170316		EOR R23, R24, R22									
  execution.go:574	0x1002104cc		140000a4		JMP 164(PC)										
  execution.go:576	0x1002104d0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:576	0x1002104d4		eb1302df		CMP R19, R22										
  execution.go:576	0x1002104d8		54009802		BCS 1216(PC)										
  execution.go:576	0x1002104dc		8b161196		ADD R22<<4, R12, R22									
  execution.go:576	0x1002104e0		eb1302ff		CMP R19, R23										
  execution.go:576	0x1002104e4		54009742		BCS 1210(PC)										
  execution.go:576	0x1002104e8		f94002d8		MOVD (R22), R24										
  execution.go:576	0x1002104ec		8b171197		ADD R23<<4, R12, R23									
  execution.go:576	0x1002104f0		f94002f7		MOVD (R23), R23										
  integer.go:54		0x1002104f4		9ad72316		LSL R23, R24, R22									
  execution.go:576	0x1002104f8		14000099		JMP 153(PC)										
  execution.go:578	0x1002104fc		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:578	0x100210500		eb1302df		CMP R19, R22										
  execution.go:578	0x100210504		540095e2		BCS 1199(PC)										
  execution.go:578	0x100210508		8b161196		ADD R22<<4, R12, R22									
  execution.go:578	0x10021050c		eb1302ff		CMP R19, R23										
  execution.go:578	0x100210510		54009522		BCS 1193(PC)										
  execution.go:578	0x100210514		f94002d8		MOVD (R22), R24										
  execution.go:578	0x100210518		8b171197		ADD R23<<4, R12, R23									
  execution.go:578	0x10021051c		f94002f7		MOVD (R23), R23										
  integer.go:55		0x100210520		9ad72b16		ASR R23, R24, R22									
  execution.go:578	0x100210524		1400008e		JMP 142(PC)										
  execution.go:580	0x100210528		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:580	0x10021052c		eb1302df		CMP R19, R22										
  execution.go:580	0x100210530		540093c2		BCS 1182(PC)										
  execution.go:580	0x100210534		8b161196		ADD R22<<4, R12, R22									
  execution.go:580	0x100210538		eb1302ff		CMP R19, R23										
  execution.go:580	0x10021053c		54009302		BCS 1176(PC)										
  execution.go:580	0x100210540		f94002d8		MOVD (R22), R24										
  execution.go:580	0x100210544		8b171197		ADD R23<<4, R12, R23									
  execution.go:580	0x100210548		f94002f7		MOVD (R23), R23										
  integer.go:56		0x10021054c		9ad72716		LSR R23, R24, R22									
  execution.go:580	0x100210550		14000083		JMP 131(PC)										
  execution.go:582	0x100210554		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:582	0x100210558		eb1302df		CMP R19, R22										
  execution.go:582	0x10021055c		540091a2		BCS 1165(PC)										
  execution.go:582	0x100210560		8b161196		ADD R22<<4, R12, R22									
  execution.go:582	0x100210564		eb1302ff		CMP R19, R23										
  execution.go:582	0x100210568		540090e2		BCS 1159(PC)										
  execution.go:582	0x10021056c		f94002d8		MOVD (R22), R24										
  execution.go:582	0x100210570		8b171197		ADD R23<<4, R12, R23									
  execution.go:582	0x100210574		f94002f7		MOVD (R23), R23										
  integer.go:57		0x100210578		cb1703f7		NEG R23, R23										
  integer.go:57		0x10021057c		9ad72f16		ROR R23, R24, R22									
  execution.go:582	0x100210580		14000077		JMP 119(PC)										
  execution.go:584	0x100210584		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:584	0x100210588		eb1302df		CMP R19, R22										
  execution.go:584	0x10021058c		54008f62		BCS 1147(PC)										
  execution.go:584	0x100210590		8b161196		ADD R22<<4, R12, R22									
  execution.go:584	0x100210594		eb1302ff		CMP R19, R23										
  execution.go:584	0x100210598		54008ea2		BCS 1141(PC)										
  execution.go:584	0x10021059c		f94002d8		MOVD (R22), R24										
  execution.go:584	0x1002105a0		8b171197		ADD R23<<4, R12, R23									
  execution.go:584	0x1002105a4		f94002f7		MOVD (R23), R23										
  integer.go:58		0x1002105a8		9ad72f16		ROR R23, R24, R22									
  execution.go:584	0x1002105ac		1400006c		JMP 108(PC)										
  execution.go:586	0x1002105b0		b9400e96		MOVWU 12(R20), R22									
  execution.go:586	0x1002105b4		eb1302df		CMP R19, R22										
  execution.go:586	0x1002105b8		54008d42		BCS 1130(PC)										
  execution.go:586	0x1002105bc		8b161197		ADD R22<<4, R12, R23									
  execution.go:586	0x1002105c0		f94002f7		MOVD (R23), R23										
  integer.go:59		0x1002105c4		2a1703f6		MOVW R23, R22										
  execution.go:586	0x1002105c8		14000065		JMP 101(PC)										
  execution.go:588	0x1002105cc		b9400e96		MOVWU 12(R20), R22									
  execution.go:588	0x1002105d0		eb1302df		CMP R19, R22										
  execution.go:588	0x1002105d4		54008c02		BCS 1120(PC)										
  execution.go:588	0x1002105d8		8b161197		ADD R22<<4, R12, R23									
  execution.go:588	0x1002105dc		f94002f7		MOVD (R23), R23										
  integer.go:60		0x1002105e0		93407ef6		SXTW R23, R22										
  execution.go:588	0x1002105e4		1400005e		JMP 94(PC)										
  execution.go:590	0x1002105e8		b9400e96		MOVWU 12(R20), R22									
  execution.go:590	0x1002105ec		eb1302df		CMP R19, R22										
  execution.go:590	0x1002105f0		54008ac2		BCS 1110(PC)										
  execution.go:590	0x1002105f4		8b161197		ADD R22<<4, R12, R23									
  execution.go:590	0x1002105f8		f94002f7		MOVD (R23), R23										
  integer.go:61		0x1002105fc		2a1703f6		MOVW R23, R22										
  execution.go:590	0x100210600		14000057		JMP 87(PC)										
  execution.go:611	0x100210604		b9401283		MOVWU 16(R20), R3									
  execution.go:611	0x100210608		3100047f		CMNW $1, R3										
  execution.go:611	0x10021060c		540000c0		BEQ 6(PC)										
  execution.go:612	0x100210610		eb13007f		CMP R19, R3										
  execution.go:612	0x100210614		54008962		BCS 1099(PC)										
  execution.go:612	0x100210618		8b031183		ADD R3<<4, R12, R3									
  execution.go:612	0x10021061c		f9400062		MOVD (R3), R2										
  execution.go:612	0x100210620		14000002		JMP 2(PC)										
  execution.go:612	0x100210624		aa1f03e2		MOVD ZR, R2										
  execution.go:614	0x100210628		b9400e83		MOVWU 12(R20), R3									
  execution.go:614	0x10021062c		eb13007f		CMP R19, R3										
  execution.go:614	0x100210630		54008842		BCS 1090(PC)										
  execution.go:614	0x100210634		8b031183		ADD R3<<4, R12, R3									
  execution.go:614	0x100210638		f9400063		MOVD (R3), R3										
  execution.go:614	0x10021063c		aa0103e0		MOVD R1, R0										
  execution.go:614	0x100210640		aa0303e1		MOVD R3, R1										
  execution.go:614	0x100210644		97ffa8c3		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:615	0x100210648		d3401c23		UBFX $0, R1, $8, R3									
  execution.go:615	0x10021064c		34000223		CBZW R3, 17(PC)										
  execution.go:342	0x100210650		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210654		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210658		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021065c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210660		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210664		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210668		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021066c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210670		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210674		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210678		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021067c		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x100210680		aa1f03f7		MOVD ZR, R23										
  execution.go:395	0x100210684		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100210688		f94127e0		MOVD 584(RSP), R0									
  execution.go:616	0x10021068c		140002da		JMP 730(PC)										
  execution.go:342	0x100210690		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210694		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210698		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021069c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002106a0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002106a4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002106a8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002106ac		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002106b0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002106b4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002106b8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002106bc		f94093f5		MOVD 288(RSP), R21									
  execution.go:488	0x1002106c0		aa0003f6		MOVD R0, R22										
  execution.go:209	0x1002106c4		f94127e0		MOVD 584(RSP), R0									
  execution.go:615	0x1002106c8		14000025		JMP 37(PC)										
  execution.go:592	0x1002106cc		b9400e96		MOVWU 12(R20), R22									
  execution.go:592	0x1002106d0		eb1302df		CMP R19, R22										
  execution.go:592	0x1002106d4		540082c2		BCS 1046(PC)										
  execution.go:592	0x1002106d8		8b161196		ADD R22<<4, R12, R22									
  execution.go:592	0x1002106dc		f94002d6		MOVD (R22), R22										
  integer.go:62		0x1002106e0		93401ed6		SXTB R22, R22										
  integer.go:62		0x1002106e4		2a1603f6		MOVW R22, R22										
  execution.go:592	0x1002106e8		1400001d		JMP 29(PC)										
  execution.go:594	0x1002106ec		b9400e96		MOVWU 12(R20), R22									
  execution.go:594	0x1002106f0		eb1302df		CMP R19, R22										
  execution.go:594	0x1002106f4		54008162		BCS 1035(PC)										
  execution.go:594	0x1002106f8		8b161196		ADD R22<<4, R12, R22									
  execution.go:594	0x1002106fc		f94002d6		MOVD (R22), R22										
  integer.go:63		0x100210700		93403ed6		SXTH R22, R22										
  integer.go:63		0x100210704		2a1603f6		MOVW R22, R22										
  execution.go:594	0x100210708		14000015		JMP 21(PC)										
  execution.go:596	0x10021070c		b9400e96		MOVWU 12(R20), R22									
  execution.go:596	0x100210710		eb1302df		CMP R19, R22										
  execution.go:596	0x100210714		54008002		BCS 1024(PC)										
  execution.go:596	0x100210718		8b161196		ADD R22<<4, R12, R22									
  execution.go:596	0x10021071c		f94002d6		MOVD (R22), R22										
  integer.go:64		0x100210720		93401ed6		SXTB R22, R22										
  execution.go:596	0x100210724		1400000e		JMP 14(PC)										
  execution.go:598	0x100210728		b9400e96		MOVWU 12(R20), R22									
  execution.go:598	0x10021072c		eb1302df		CMP R19, R22										
  execution.go:598	0x100210730		54007ec2		BCS 1014(PC)										
  execution.go:598	0x100210734		8b161196		ADD R22<<4, R12, R22									
  execution.go:598	0x100210738		f94002d6		MOVD (R22), R22										
  integer.go:65		0x10021073c		93403ed6		SXTH R22, R22										
  execution.go:598	0x100210740		14000007		JMP 7(PC)										
  execution.go:600	0x100210744		b9400e96		MOVWU 12(R20), R22									
  execution.go:600	0x100210748		eb1302df		CMP R19, R22										
  execution.go:600	0x10021074c		54007d82		BCS 1004(PC)										
  execution.go:600	0x100210750		8b161196		ADD R22<<4, R12, R22									
  execution.go:600	0x100210754		f94002d6		MOVD (R22), R22										
  integer.go:66		0x100210758		93407ed6		SXTW R22, R22										
  execution.go:619	0x10021075c		aa1f03f7		MOVD ZR, R23										
  execution.go:619	0x100210760		140002a7		JMP 679(PC)										
  execution.go:621	0x100210764		7100f83f		CMPW $62, R1										
  execution.go:706	0x100210768		54001e68		BHI 243(PC)										
  execution.go:621	0x10021076c		7100803f		CMPW $32, R1										
  execution.go:676	0x100210770		540005c8		BHI 46(PC)										
  execution.go:621	0x100210774		7100283f		CMPW $10, R1										
  execution.go:663	0x100210778		54000108		BHI 8(PC)										
  execution.go:669	0x10021077c		7100043f		CMPW $1, R1										
  execution.go:669	0x100210780		540001a0		BEQ 13(PC)										
  execution.go:663	0x100210784		7100203f		CMPW $8, R1										
  execution.go:663	0x100210788		54005560		BEQ 683(PC)										
  execution.go:621	0x10021078c		7100283f		CMPW $10, R1										
  execution.go:663	0x100210790		540042e1		BNE 535(PC)										
  execution.go:663	0x100210794		140002a8		JMP 680(PC)										
  execution.go:621	0x100210798		7100683f		CMPW $26, R1										
  execution.go:669	0x10021079c		54000148		BHI 10(PC)										
  execution.go:743	0x1002107a0		d1004036		SUB $16, R1, R22									
  execution.go:743	0x1002107a4		710016df		CMPW $5, R22										
  execution.go:743	0x1002107a8		54005509		BLS 680(PC)										
  execution.go:621	0x1002107ac		7100683f		CMPW $26, R1										
  execution.go:669	0x1002107b0		540041e1		BNE 527(PC)										
  execution.go:704	0x1002107b4		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002107b8		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x1002107bc		aa1f03e1		MOVD ZR, R1										
  execution.go:669	0x1002107c0		1400028d		JMP 653(PC)										
  execution.go:670	0x1002107c4		7100703f		CMPW $28, R1										
  execution.go:670	0x1002107c8		540001e8		BHI 15(PC)										
  execution.go:671	0x1002107cc		29425e96		LDPW 16(R20), (R22, R23)								
  execution.go:672	0x1002107d0		eb1302ff		CMP R19, R23										
  execution.go:672	0x1002107d4		540078e2		BCS 967(PC)										
  execution.go:672	0x1002107d8		8b171197		ADD R23<<4, R12, R23									
  execution.go:672	0x1002107dc		f94002f7		MOVD (R23), R23										
  execution.go:672	0x1002107e0		34000057		CBZW R23, 2(PC)										
  execution.go:673	0x1002107e4		b9400e96		MOVWU 12(R20), R22									
  execution.go:675	0x1002107e8		2a1603f6		MOVW R22, R22										
  execution.go:675	0x1002107ec		eb1302df		CMP R19, R22										
  execution.go:675	0x1002107f0		540077a2		BCS 957(PC)										
  execution.go:675	0x1002107f4		8b161196		ADD R22<<4, R12, R22									
  execution.go:675	0x1002107f8		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x1002107fc		aa1f03e1		MOVD ZR, R1										
  execution.go:675	0x100210800		1400027d		JMP 637(PC)										
  execution.go:621	0x100210804		7100803f		CMPW $32, R1										
  execution.go:676	0x100210808		54003f21		BNE 505(PC)										
  execution.go:677	0x10021080c		b9401a96		MOVWU 24(R20), R22									
  execution.go:677	0x100210810		eb1302df		CMP R19, R22										
  execution.go:677	0x100210814		54007622		BCS 945(PC)										
  execution.go:677	0x100210818		8b161196		ADD R22<<4, R12, R22									
  execution.go:677	0x10021081c		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x100210820		aa1f03e1		MOVD ZR, R1										
  execution.go:677	0x100210824		14000274		JMP 628(PC)										
  execution.go:621	0x100210828		7100903f		CMPW $36, R1										
  execution.go:683	0x10021082c		54000548		BHI 42(PC)										
  execution.go:678	0x100210830		7100883f		CMPW $34, R1										
  execution.go:678	0x100210834		540001a8		BHI 13(PC)										
  execution.go:679	0x100210838		b9400e96		MOVWU 12(R20), R22									
  execution.go:679	0x10021083c		eb1302df		CMP R19, R22										
  execution.go:679	0x100210840		54007462		BCS 931(PC)										
  execution.go:679	0x100210844		8b161196		ADD R22<<4, R12, R22									
  execution.go:679	0x100210848		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:680	0x10021084c		b9401a98		MOVWU 24(R20), R24									
  execution.go:680	0x100210850		eb13031f		CMP R19, R24										
  execution.go:680	0x100210854		54007362		BCS 923(PC)										
  execution.go:680	0x100210858		8b181198		ADD R24<<4, R12, R24									
  execution.go:680	0x10021085c		a9005f16		STP (R22, R23), (R24)									
  execution.go:708	0x100210860		aa1f03e1		MOVD ZR, R1										
  execution.go:680	0x100210864		14000264		JMP 612(PC)										
  execution.go:681	0x100210868		71008c3f		CMPW $35, R1										
  execution.go:681	0x10021086c		54000121		BNE 9(PC)										
  execution.go:682	0x100210870		a948ddb6		LDP 136(R13), (R22, R23)								
  execution.go:682	0x100210874		b9401a98		MOVWU 24(R20), R24									
  execution.go:682	0x100210878		eb17031f		CMP R23, R24										
  execution.go:682	0x10021087c		540071c2		BCS 910(PC)										
  execution.go:682	0x100210880		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:682	0x100210884		a9425ed6		LDP 32(R22), (R22, R23)									
  execution.go:708	0x100210888		aa1f03e1		MOVD ZR, R1										
  execution.go:682	0x10021088c		1400025a		JMP 602(PC)										
  execution.go:621	0x100210890		7100903f		CMPW $36, R1										
  execution.go:683	0x100210894		54003ac1		BNE 470(PC)										
  execution.go:684	0x100210898		b9400e96		MOVWU 12(R20), R22									
  execution.go:684	0x10021089c		eb1302df		CMP R19, R22										
  execution.go:684	0x1002108a0		54007042		BCS 898(PC)										
  execution.go:684	0x1002108a4		a948e1b7		LDP 136(R13), (R23, R24)								
  execution.go:684	0x1002108a8		b9401a99		MOVWU 24(R20), R25									
  execution.go:684	0x1002108ac		8b161196		ADD R22<<4, R12, R22									
  execution.go:684	0x1002108b0		a9406ad6		LDP (R22), (R22, R26)									
  execution.go:684	0x1002108b4		eb18033f		CMP R24, R25										
  execution.go:684	0x1002108b8		54006f22		BCS 889(PC)										
  execution.go:684	0x1002108bc		f8797af7		MOVD (R23)(R25<<3), R23									
  execution.go:684	0x1002108c0		a9026af6		STP (R22, R26), 32(R23)									
  execution.go:704	0x1002108c4		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002108c8		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x1002108cc		aa1f03e1		MOVD ZR, R1										
  execution.go:684	0x1002108d0		14000249		JMP 585(PC)										
  execution.go:621	0x1002108d4		7100983f		CMPW $38, R1										
  execution.go:693	0x1002108d8		54000708		BHI 56(PC)										
  execution.go:685	0x1002108dc		7100943f		CMPW $37, R1										
  execution.go:685	0x1002108e0		54000321		BNE 25(PC)										
  execution.go:686	0x1002108e4		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:686	0x1002108e8		b9401a98		MOVWU 24(R20), R24									
  execution.go:686	0x1002108ec		eb17031f		CMP R23, R24										
  execution.go:686	0x1002108f0		54006d02		BCS 872(PC)										
  execution.go:686	0x1002108f4		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:687	0x1002108f8		398002db		MOVB (R22), R27										
  execution.go:687	0x1002108fc		b9400e97		MOVWU 12(R20), R23									
  execution.go:687	0x100210900		eb1302ff		CMP R19, R23										
  execution.go:687	0x100210904		54006c02		BCS 864(PC)										
  execution.go:687	0x100210908		8b171197		ADD R23<<4, R12, R23									
  execution.go:687	0x10021090c		f94002f7		MOVD (R23), R23										
  module.go:70		0x100210910		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x100210914		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x100210918		2a1703f7		MOVW R23, R23										
  execution.go:688	0x10021091c		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:688	0x100210920		eb1802ff		CMP R24, R23										
  execution.go:688	0x100210924		54000083		BCC 4(PC)										
  execution.go:688	0x100210928		b24007e1		ORR $3, ZR, R1										
  execution.go:691	0x10021092c		aa1f03f6		MOVD ZR, R22										
  execution.go:688	0x100210930		14000003		JMP 3(PC)										
  execution.go:691	0x100210934		f8777ad6		MOVD (R22)(R23<<3), R22									
  execution.go:689	0x100210938		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x10021093c		aa1f03f7		MOVD ZR, R23										
  execution.go:688	0x100210940		1400022d		JMP 557(PC)										
  execution.go:694	0x100210944		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:694	0x100210948		b9401a98		MOVWU 24(R20), R24									
  execution.go:694	0x10021094c		eb17031f		CMP R23, R24										
  execution.go:694	0x100210950		54006942		BCS 842(PC)										
  execution.go:694	0x100210954		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:695	0x100210958		398002db		MOVB (R22), R27										
  execution.go:695	0x10021095c		b9400e97		MOVWU 12(R20), R23									
  execution.go:695	0x100210960		eb1302ff		CMP R19, R23										
  execution.go:695	0x100210964		54006842		BCS 834(PC)										
  execution.go:695	0x100210968		8b171197		ADD R23<<4, R12, R23									
  execution.go:695	0x10021096c		f94002f7		MOVD (R23), R23										
  module.go:70		0x100210970		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x100210974		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x100210978		2a1703f7		MOVW R23, R23										
  execution.go:696	0x10021097c		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:696	0x100210980		eb1802ff		CMP R24, R23										
  execution.go:696	0x100210984		54000063		BCC 3(PC)										
  execution.go:696	0x100210988		b24007e1		ORR $3, ZR, R1										
  execution.go:696	0x10021098c		14000008		JMP 8(PC)										
  execution.go:699	0x100210990		b9401298		MOVWU 16(R20), R24									
  execution.go:699	0x100210994		eb13031f		CMP R19, R24										
  execution.go:699	0x100210998		54006642		BCS 818(PC)										
  execution.go:699	0x10021099c		8b181198		ADD R24<<4, R12, R24									
  execution.go:699	0x1002109a0		f9400318		MOVD (R24), R24										
  execution.go:699	0x1002109a4		f8377ad8		MOVD R24, (R22)(R23<<3)									
  execution.go:697	0x1002109a8		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x1002109ac		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002109b0		aa1f03f6		MOVD ZR, R22										
  execution.go:696	0x1002109b4		14000210		JMP 528(PC)										
  execution.go:701	0x1002109b8		d100a036		SUB $40, R1, R22									
  execution.go:701	0x1002109bc		710036df		CMPW $13, R22										
  execution.go:702	0x1002109c0		54000588		BHI 44(PC)										
  execution.go:703	0x1002109c4		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:703	0x1002109c8		b9400696		MOVWU 4(R20), R22									
  execution.go:703	0x1002109cc		aa1603f7		MOVD R22, R23										
  execution.go:703	0x1002109d0		eb0802ff		CMP R8, R23										
  execution.go:703	0x1002109d4		54006422		BCS 801(PC)										
  execution.go:703	0x1002109d8		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:703	0x1002109dc		cb171508		SUB R23<<5, R8, R8									
  execution.go:703	0x1002109e0		8b0800e7		ADD R8, R7, R7										
  execution.go:704	0x1002109e4		a94759a8		LDP 112(R13), (R8, R22)									
  module.go:178		0x1002109e8		2942e0f7		LDPW 20(R7), (R23, R24)									
  module.go:178		0x1002109ec		b9401ce7		MOVWU 28(R7), R7									
  module.go:178		0x1002109f0		aa0782e3		ORR R7<<32, R23, R3									
  execution.go:704	0x1002109f4		eb16031f		CMP R22, R24										
  execution.go:704	0x1002109f8		540062a2		BCS 789(PC)										
  execution.go:704	0x1002109fc		f8787907		MOVD (R8)(R24<<3), R7									
  execution.go:704	0x100210a00		398000fb		MOVB (R7), R27										
  execution.go:704	0x100210a04		b9400e88		MOVWU 12(R20), R8									
  execution.go:704	0x100210a08		eb13011f		CMP R19, R8										
  execution.go:704	0x100210a0c		540061c2		BCS 782(PC)										
  execution.go:704	0x100210a10		f94008e0		MOVD 16(R7), R0										
  execution.go:704	0x100210a14		8b081187		ADD R8<<4, R12, R7									
  execution.go:704	0x100210a18		f94000e2		MOVD (R7), R2										
  execution.go:704	0x100210a1c		aa1f03e4		MOVD ZR, R4										
  execution.go:704	0x100210a20		aa1f03e5		MOVD ZR, R5										
  execution.go:704	0x100210a24		aa1f03e6		MOVD ZR, R6										
  execution.go:704	0x100210a28		97ff9f1e		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:342	0x100210a2c		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210a30		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210a34		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210a38		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210a3c		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210a40		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210a44		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210a48		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210a4c		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210a50		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210a54		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210a58		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210a5c		aa0103f7		MOVD R1, R23										
  execution.go:704	0x100210a60		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100210a64		aa0203e1		MOVD R2, R1										
  execution.go:209	0x100210a68		f94127e0		MOVD 584(RSP), R0									
  execution.go:704	0x100210a6c		140001e2		JMP 482(PC)										
  execution.go:705	0x100210a70		7100d83f		CMPW $54, R1										
  execution.go:705	0x100210a74		54002bc3		BCC 350(PC)										
  execution.go:707	0x100210a78		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:707	0x100210a7c		b9400696		MOVWU 4(R20), R22									
  execution.go:707	0x100210a80		aa1603f7		MOVD R22, R23										
  execution.go:707	0x100210a84		eb0802ff		CMP R8, R23										
  execution.go:707	0x100210a88		54005da2		BCS 749(PC)										
  execution.go:707	0x100210a8c		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:707	0x100210a90		cb171508		SUB R23<<5, R8, R8									
  execution.go:707	0x100210a94		8b0800e7		ADD R8, R7, R7										
  execution.go:708	0x100210a98		b9401288		MOVWU 16(R20), R8									
  module.go:178		0x100210a9c		b94014f6		MOVWU 20(R7), R22									
  module.go:178		0x100210aa0		29435ce7		LDPW 24(R7), (R7, R23)									
  module.go:178		0x100210aa4		aa1782c3		ORR R23<<32, R22, R3									
  execution.go:708	0x100210aa8		eb13011f		CMP R19, R8										
  execution.go:708	0x100210aac		54005c42		BCS 738(PC)										
  execution.go:708	0x100210ab0		a9475db6		LDP 112(R13), (R22, R23)								
  execution.go:708	0x100210ab4		8b081188		ADD R8<<4, R12, R8									
  execution.go:708	0x100210ab8		eb1700ff		CMP R23, R7										
  execution.go:708	0x100210abc		54005b82		BCS 732(PC)										
  execution.go:708	0x100210ac0		f8677ac7		MOVD (R22)(R7<<3), R7									
  execution.go:708	0x100210ac4		398000fb		MOVB (R7), R27										
  execution.go:708	0x100210ac8		b9400e96		MOVWU 12(R20), R22									
  execution.go:708	0x100210acc		eb1302df		CMP R19, R22										
  execution.go:708	0x100210ad0		54005a82		BCS 724(PC)										
  execution.go:708	0x100210ad4		f94008e0		MOVD 16(R7), R0										
  execution.go:708	0x100210ad8		8b161187		ADD R22<<4, R12, R7									
  execution.go:708	0x100210adc		f94000e2		MOVD (R7), R2										
  execution.go:708	0x100210ae0		f9400105		MOVD (R8), R5										
  execution.go:708	0x100210ae4		aa1f03e4		MOVD ZR, R4										
  execution.go:708	0x100210ae8		aa1f03e6		MOVD ZR, R6										
  execution.go:708	0x100210aec		97ff9f65		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:342	0x100210af0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210af4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210af8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210afc		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210b00		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210b04		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210b08		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210b0c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210b10		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210b14		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210b18		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210b1c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210b20		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210b24		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100210b28		aa0003e1		MOVD R0, R1										
  execution.go:209	0x100210b2c		f94127e0		MOVD 584(RSP), R0									
  execution.go:708	0x100210b30		140001b1		JMP 433(PC)										
  execution.go:621	0x100210b34		7103483f		CMPW $210, R1										
  execution.go:741	0x100210b38		54000ec8		BHI 118(PC)										
  execution.go:621	0x100210b3c		7101043f		CMPW $65, R1										
  execution.go:718	0x100210b40		54000a28		BHI 81(PC)										
  execution.go:709	0x100210b44		7100fc3f		CMPW $63, R1										
  execution.go:709	0x100210b48		540006e0		BEQ 55(PC)										
  execution.go:711	0x100210b4c		7101003f		CMPW $64, R1										
  execution.go:711	0x100210b50		540000a0		BEQ 5(PC)										
  execution.go:719	0x100210b54		b9401a96		MOVWU 24(R20), R22									
  execution.go:704	0x100210b58		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210b5c		aa1f03e1		MOVD ZR, R1										
  execution.go:719	0x100210b60		140001a5		JMP 421(PC)										
  execution.go:712	0x100210b64		a94711a3		LDP 112(R13), (R3, R4)									
  execution.go:712	0x100210b68		b9401a85		MOVWU 24(R20), R5									
  execution.go:712	0x100210b6c		eb0400bf		CMP R4, R5										
  execution.go:712	0x100210b70		54005562		BCS 683(PC)										
  execution.go:712	0x100210b74		f8657861		MOVD (R3)(R5<<3), R1									
  execution.go:713	0x100210b78		f9400823		MOVD 16(R1), R3										
  memory.go:127		0x100210b7c		ad410460		FLDPQ 32(R3), (F0, F1)									
  execution.go:713	0x100210b80		910623fb		ADD $392, RSP, R27									
  execution.go:713	0x100210b84		ad000760		FSTPQ (F0, F1), (R27)									
  execution.go:713	0x100210b88		b9400e83		MOVWU 12(R20), R3									
  execution.go:713	0x100210b8c		eb13007f		CMP R19, R3										
  execution.go:713	0x100210b90		54005422		BCS 673(PC)										
  execution.go:713	0x100210b94		8b031183		ADD R3<<4, R12, R3									
  execution.go:713	0x100210b98		f9400062		MOVD (R3), R2										
  module.go:70		0x100210b9c		394667e3		MOVBU 409(RSP), R3									
  module.go:70		0x100210ba0		37000043		TBNZ $0, R3, 2(PC)									
  module.go:73		0x100210ba4		2a0203e2		MOVW R2, R2										
  execution.go:712	0x100210ba8		f900a3e1		MOVD R1, 320(RSP)									
  execution.go:713	0x100210bac		f9400000		MOVD (R0), R0										
  execution.go:713	0x100210bb0		97ffe548		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory(SB)		
  execution.go:715	0x100210bb4		37000161		TBNZ $0, R1, 11(PC)									
  execution.go:716	0x100210bb8		f940a3e9		MOVD 320(RSP), R9									
  execution.go:716	0x100210bbc		f9400929		MOVD 16(R9), R9										
  memory.go:127		0x100210bc0		ad410520		FLDPQ 32(R9), (F0, F1)									
  execution.go:716	0x100210bc4		910623fb		ADD $392, RSP, R27									
  execution.go:716	0x100210bc8		ad000760		FSTPQ (F0, F1), (R27)									
  module.go:77		0x100210bcc		394667e9		MOVBU 409(RSP), R9									
  execution.go:716	0x100210bd0		7200013f		TSTW $1, R9										
  execution.go:716	0x100210bd4		92800009		MOVD $-1, R9										
  execution.go:716	0x100210bd8		b2407fea		MOVD $4294967295, R10									
  execution.go:716	0x100210bdc		9a8a1120		CSEL NE, R9, R10, R0									
  execution.go:342	0x100210be0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210be4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210be8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210bec		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210bf0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210bf4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210bf8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210bfc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210c00		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210c04		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210c08		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210c0c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210c10		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210c14		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100210c18		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x100210c1c		f94127e0		MOVD 584(RSP), R0									
  execution.go:715	0x100210c20		14000175		JMP 373(PC)										
  execution.go:710	0x100210c24		a94709a1		LDP 112(R13), (R1, R2)									
  execution.go:710	0x100210c28		b9401a83		MOVWU 24(R20), R3									
  execution.go:710	0x100210c2c		eb02007f		CMP R2, R3										
  execution.go:710	0x100210c30		54004f02		BCS 632(PC)										
  execution.go:710	0x100210c34		f8637821		MOVD (R1)(R3<<3), R1									
  execution.go:710	0x100210c38		f9400820		MOVD 16(R1), R0										
  execution.go:710	0x100210c3c		97ff9c19		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages(SB)		
  execution.go:342	0x100210c40		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210c44		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210c48		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210c4c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210c50		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210c54		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210c58		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210c5c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210c60		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210c64		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210c68		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210c6c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210c70		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210c74		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100210c78		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x100210c7c		f94127e0		MOVD 584(RSP), R0									
  execution.go:710	0x100210c80		1400015d		JMP 349(PC)										
  execution.go:621	0x100210c84		7103403f		CMPW $208, R1										
  execution.go:730	0x100210c88		540001c8		BHI 14(PC)										
  execution.go:721	0x100210c8c		7101103f		CMPW $68, R1										
  execution.go:721	0x100210c90		540000c8		BHI 6(PC)										
  execution.go:722	0x100210c94		b9401a97		MOVWU 24(R20), R23									
  execution.go:722	0x100210c98		aa1682f6		ORR R22<<32, R23, R22									
  execution.go:704	0x100210c9c		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210ca0		aa1f03e1		MOVD ZR, R1										
  execution.go:722	0x100210ca4		14000154		JMP 340(PC)										
  execution.go:621	0x100210ca8		7103403f		CMPW $208, R1										
  execution.go:730	0x100210cac		54001a01		BNE 208(PC)										
  execution.go:704	0x100210cb0		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210cb4		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100210cb8		aa1f03e1		MOVD ZR, R1										
  execution.go:730	0x100210cbc		1400014e		JMP 334(PC)										
  execution.go:737	0x100210cc0		7103443f		CMPW $209, R1										
  execution.go:737	0x100210cc4		54000161		BNE 11(PC)										
  execution.go:738	0x100210cc8		b9400e96		MOVWU 12(R20), R22									
  execution.go:738	0x100210ccc		eb1302df		CMP R19, R22										
  execution.go:738	0x100210cd0		540049a2		BCS 589(PC)										
  execution.go:738	0x100210cd4		8b161196		ADD R22<<4, R12, R22									
  execution.go:738	0x100210cd8		f94002d6		MOVD (R22), R22										
  execution.go:738	0x100210cdc		f10002df		CMP $0, R22										
  execution.go:738	0x100210ce0		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x100210ce4		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210ce8		aa1f03e1		MOVD ZR, R1										
  execution.go:738	0x100210cec		14000142		JMP 322(PC)										
  execution.go:742	0x100210cf0		a9445db6		LDP 64(R13), (R22, R23)									
  execution.go:742	0x100210cf4		b9401a98		MOVWU 24(R20), R24									
  execution.go:742	0x100210cf8		eb17031f		CMP R23, R24										
  execution.go:742	0x100210cfc		540047e2		BCS 575(PC)										
  execution.go:742	0x100210d00		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:704	0x100210d04		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210d08		aa1f03e1		MOVD ZR, R1										
  execution.go:742	0x100210d0c		1400013a		JMP 314(PC)										
  execution.go:621	0x100210d10		d2800077		MOVD $3, R23										
  execution.go:621	0x100210d14		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x100210d18		6b17003f		CMPW R23, R1										
  execution.go:634	0x100210d1c		54000808		BHI 64(PC)										
  execution.go:621	0x100210d20		7103503f		CMPW $212, R1										
  execution.go:731	0x100210d24		540003a8		BHI 29(PC)										
  execution.go:726	0x100210d28		71034c3f		CMPW $211, R1										
  execution.go:726	0x100210d2c		540001e1		BNE 15(PC)										
  execution.go:727	0x100210d30		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:727	0x100210d34		eb1302df		CMP R19, R22										
  execution.go:727	0x100210d38		540045a2		BCS 557(PC)										
  execution.go:727	0x100210d3c		8b161196		ADD R22<<4, R12, R22									
  execution.go:727	0x100210d40		eb1302ff		CMP R19, R23										
  execution.go:727	0x100210d44		540044e2		BCS 551(PC)										
  execution.go:727	0x100210d48		f94002d6		MOVD (R22), R22										
  execution.go:727	0x100210d4c		8b171197		ADD R23<<4, R12, R23									
  execution.go:727	0x100210d50		f94002f7		MOVD (R23), R23										
  execution.go:727	0x100210d54		eb1602ff		CMP R22, R23										
  execution.go:727	0x100210d58		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x100210d5c		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210d60		aa1f03e1		MOVD ZR, R1										
  execution.go:727	0x100210d64		14000124		JMP 292(PC)										
  execution.go:732	0x100210d68		b9400e96		MOVWU 12(R20), R22									
  execution.go:732	0x100210d6c		eb1302df		CMP R19, R22										
  execution.go:732	0x100210d70		54004322		BCS 537(PC)										
  execution.go:732	0x100210d74		8b161196		ADD R22<<4, R12, R22									
  execution.go:732	0x100210d78		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:732	0x100210d7c		b50000b6		CBNZ R22, 5(PC)										
  execution.go:732	0x100210d80		d2800121		MOVD $9, R1										
  execution.go:735	0x100210d84		aa1f03f7		MOVD ZR, R23										
  execution.go:735	0x100210d88		aa1f03f6		MOVD ZR, R22										
  execution.go:732	0x100210d8c		1400011a		JMP 282(PC)										
  execution.go:733	0x100210d90		aa1f03e1		MOVD ZR, R1										
  execution.go:735	0x100210d94		14000118		JMP 280(PC)										
  execution.go:723	0x100210d98		d17f0037		SUB $(4032<<12), R1, R23								
  execution.go:723	0x100210d9c		71001eff		CMPW $7, R23										
  execution.go:724	0x100210da0		540000c9		BLS 6(PC)										
  execution.go:634	0x100210da4		d2800037		MOVD $1, R23										
  execution.go:634	0x100210da8		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x100210dac		6b17003f		CMPW R23, R1										
  execution.go:634	0x100210db0		54000582		BCS 44(PC)										
  execution.go:634	0x100210db4		1400008e		JMP 142(PC)										
  execution.go:725	0x100210db8		b9400e83		MOVWU 12(R20), R3									
  execution.go:725	0x100210dbc		eb13007f		CMP R19, R3										
  execution.go:725	0x100210dc0		54004062		BCS 515(PC)										
  execution.go:725	0x100210dc4		8b031183		ADD R3<<4, R12, R3									
  execution.go:725	0x100210dc8		f9400063		MOVD (R3), R3										
  execution.go:725	0x100210dcc		aa0103e0		MOVD R1, R0										
  execution.go:725	0x100210dd0		aa0303e1		MOVD R3, R1										
  execution.go:725	0x100210dd4		aa1f03e2		MOVD ZR, R2										
  execution.go:725	0x100210dd8		97ffa6de		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:342	0x100210ddc		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210de0		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210de4		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210de8		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210dec		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210df0		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210df4		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210df8		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210dfc		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210e00		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210e04		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210e08		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210e0c		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210e10		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100210e14		f94127e0		MOVD 584(RSP), R0									
  execution.go:725	0x100210e18		140000f7		JMP 247(PC)										
  execution.go:621	0x100210e1c		d28000b7		MOVD $5, R23										
  execution.go:621	0x100210e20		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x100210e24		6b17003f		CMPW R23, R1										
  execution.go:634	0x100210e28		540000c8		BHI 6(PC)										
  execution.go:622	0x100210e2c		d2800097		MOVD $4, R23										
  execution.go:622	0x100210e30		f2a02017		MOVK $(256<<16), R23									
  execution.go:622	0x100210e34		6b17003f		CMPW R23, R1										
  execution.go:622	0x100210e38		54000141		BNE 10(PC)										
  execution.go:622	0x100210e3c		14000108		JMP 264(PC)										
  execution.go:628	0x100210e40		d28000f7		MOVD $7, R23										
  execution.go:628	0x100210e44		f2a02017		MOVK $(256<<16), R23									
  execution.go:628	0x100210e48		6b17003f		CMPW R23, R1										
  execution.go:628	0x100210e4c		54002120		BEQ 265(PC)										
  execution.go:634	0x100210e50		d2800137		MOVD $9, R23										
  execution.go:634	0x100210e54		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x100210e58		6b17003f		CMPW R23, R1										
  execution.go:634	0x100210e5c		54000c81		BNE 100(PC)										
  execution.go:635	0x100210e60		d2a02017		MOVD $16777216, R23									
  execution.go:635	0x100210e64		cb170037		SUB R23, R1, R23									
  execution.go:636	0x100210e68		d3401ef7		UBFX $0, R23, $8, R23									
  execution.go:636	0x100210e6c		710016ff		CMPW $5, R23										
  execution.go:636	0x100210e70		540000a1		BNE 5(PC)										
  execution.go:704	0x100210e74		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210e78		aa1f03f6		MOVD ZR, R22										
  execution.go:704	0x100210e7c		b24003e1		ORR $1, ZR, R1										
  execution.go:638	0x100210e80		140000dd		JMP 221(PC)										
  execution.go:641	0x100210e84		710026ff		CMPW $9, R23										
  execution.go:641	0x100210e88		54000121		BNE 9(PC)										
  execution.go:641	0x100210e8c		b9400e98		MOVWU 12(R20), R24									
  execution.go:641	0x100210e90		eb13031f		CMP R19, R24										
  execution.go:641	0x100210e94		54003962		BCS 459(PC)										
  execution.go:641	0x100210e98		8b181198		ADD R24<<4, R12, R24									
  execution.go:641	0x100210e9c		f9400318		MOVD (R24), R24										
  execution.go:641	0x100210ea0		b4000078		CBZ R24, 3(PC)										
  execution.go:641	0x100210ea4		b24003f6		ORR $1, ZR, R22										
  execution.go:641	0x100210ea8		14000018		JMP 24(PC)										
  execution.go:643	0x100210eac		71000aff		CMPW $2, R23										
  execution.go:643	0x100210eb0		54000121		BNE 9(PC)										
  execution.go:643	0x100210eb4		b9400e98		MOVWU 12(R20), R24									
  execution.go:643	0x100210eb8		eb13031f		CMP R19, R24										
  execution.go:643	0x100210ebc		540037c2		BCS 446(PC)										
  execution.go:643	0x100210ec0		8b181198		ADD R24<<4, R12, R24									
  execution.go:643	0x100210ec4		f9400318		MOVD (R24), R24										
  execution.go:643	0x100210ec8		35000078		CBNZW R24, 3(PC)									
  execution.go:643	0x100210ecc		b24003f6		ORR $1, ZR, R22										
  execution.go:643	0x100210ed0		1400000e		JMP 14(PC)										
  execution.go:645	0x100210ed4		71000eff		CMPW $3, R23										
  execution.go:645	0x100210ed8		54000161		BNE 11(PC)										
  execution.go:646	0x100210edc		b9400e97		MOVWU 12(R20), R23									
  execution.go:646	0x100210ee0		eb1302ff		CMP R19, R23										
  execution.go:646	0x100210ee4		54003622		BCS 433(PC)										
  execution.go:646	0x100210ee8		8b171197		ADD R23<<4, R12, R23									
  execution.go:646	0x100210eec		f94002f7		MOVD (R23), R23										
  execution.go:647	0x100210ef0		d10006d6		SUB $1, R22, R22									
  execution.go:647	0x100210ef4		6b1602ff		CMPW R22, R23										
  execution.go:647	0x100210ef8		54000082		BCS 4(PC)										
  execution.go:648	0x100210efc		aa1703f6		MOVD R23, R22										
  execution.go:647	0x100210f00		14000002		JMP 2(PC)										
  execution.go:647	0x100210f04		aa1f03f6		MOVD ZR, R22										
  execution.go:651	0x100210f08		a94e61d7		LDP 224(R14), (R23, R24)								
  execution.go:651	0x100210f0c		b9401a94		MOVWU 24(R20), R20									
  execution.go:651	0x100210f10		8b1402d4		ADD R20, R22, R20									
  execution.go:651	0x100210f14		2a1403f6		MOVW R20, R22										
  execution.go:651	0x100210f18		eb1802df		CMP R24, R22										
  execution.go:651	0x100210f1c		54003402		BCS 416(PC)										
  execution.go:651	0x100210f20		d37e7e94		UBFIZ $2, R20, $32, R20									
  execution.go:651	0x100210f24		8b140694		ADD R20<<1, R20, R20									
  execution.go:651	0x100210f28		b8746af6		MOVWU (R23)(R20), R22									
  execution.go:651	0x100210f2c		8b1402f4		ADD R20, R23, R20									
  execution.go:651	0x100210f30		2940de94		LDPW 4(R20), (R20, R23)									
  execution.go:652	0x100210f34		6b16023f		CMPW R22, R17										
  execution.go:652	0x100210f38		540003e3		BCC 31(PC)										
  execution.go:651	0x100210f3c		b90107f7		MOVW R23, 260(RSP)									
  execution.go:651	0x100210f40		b90103f4		MOVW R20, 256(RSP)									
  execution.go:651	0x100210f44		b900fff6		MOVW R22, 252(RSP)									
  execution.go:209	0x100210f48		f940b011		MOVD 352(R0), R17									
  execution.go:209	0x100210f4c		b40000d1		CBZ R17, 6(PC)										
  type.go:19		0x100210f50		88dffe31		LDARW (R17), R17									
  execution.go:209	0x100210f54		35000091		CBNZW R17, 4(PC)									
  execution.go:212	0x100210f58		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x100210f5c		aa1f03e2		MOVD ZR, R2										
  execution.go:653	0x100210f60		14000014		JMP 20(PC)										
  execution.go:212	0x100210f64		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x100210f68		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x100210f6c		d63f0020		CALL (R1)										
  execution.go:342	0x100210f70		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210f74		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210f78		f940b3eb		MOVD 352(RSP), R11									
  execution.go:658	0x100210f7c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210f80		f940abed		MOVD 336(RSP), R13									
  execution.go:657	0x100210f84		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210f88		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210f8c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:658	0x100210f90		f94087f3		MOVD 264(RSP), R19									
  execution.go:657	0x100210f94		b94103f4		MOVWU 256(RSP), R20									
  execution.go:341	0x100210f98		f94093f5		MOVD 288(RSP), R21									
  execution.go:460	0x100210f9c		b940fff6		MOVWU 252(RSP), R22									
  execution.go:657	0x100210fa0		b94107f7		MOVWU 260(RSP), R23									
  execution.go:212	0x100210fa4		aa0103e2		MOVD R1, R2										
  execution.go:212	0x100210fa8		aa0003e1		MOVD R0, R1										
  execution.go:654	0x100210fac		f94127e0		MOVD 584(RSP), R0									
  execution.go:653	0x100210fb0		b5002161		CBNZ R1, 267(PC)									
  execution.go:657	0x100210fb4		f94085d1		MOVD 264(R14), R17									
  execution.go:657	0x100210fb8		8b170297		ADD R23, R20, R23									
  execution.go:657	0x100210fbc		2a1703f7		MOVW R23, R23										
  execution.go:657	0x100210fc0		eb1102ff		CMP R17, R23										
  execution.go:657	0x100210fc4		54002e68		BHI 371(PC)										
  execution.go:657	0x100210fc8		eb17029f		CMP R23, R20										
  execution.go:657	0x100210fcc		54002dc8		BHI 366(PC)										
  execution.go:657	0x100210fd0		f9407dd8		MOVD 248(R14), R24									
  execution.go:657	0x100210fd4		cb110291		SUB R17, R20, R17									
  execution.go:657	0x100210fd8		8a91fe91		AND R17->63, R20, R17									
  execution.go:657	0x100210fdc		cb1402f4		SUB R20, R23, R20									
  execution.go:657	0x100210fe0		8b110f11		ADD R17<<3, R24, R17									
  execution.go:657	0x100210fe4		aa1f03f7		MOVD ZR, R23										
  execution.go:657	0x100210fe8		14000154		JMP 340(PC)										
  execution.go:751	0x100210fec		b9400e96		MOVWU 12(R20), R22									
  execution.go:751	0x100210ff0		310006df		CMNW $1, R22										
  execution.go:751	0x100210ff4		540000c0		BEQ 6(PC)										
  execution.go:752	0x100210ff8		eb1302df		CMP R19, R22										
  execution.go:752	0x100210ffc		54002922		BCS 329(PC)										
  execution.go:752	0x100211000		8b161196		ADD R22<<4, R12, R22									
  execution.go:752	0x100211004		f94002c2		MOVD (R22), R2										
  execution.go:752	0x100211008		14000002		JMP 2(PC)										
  execution.go:752	0x10021100c		aa1f03e2		MOVD ZR, R2										
  execution.go:754	0x100211010		b9401296		MOVWU 16(R20), R22									
  execution.go:754	0x100211014		310006df		CMNW $1, R22										
  execution.go:754	0x100211018		540000c0		BEQ 6(PC)										
  execution.go:755	0x10021101c		eb1302df		CMP R19, R22										
  execution.go:755	0x100211020		540027a2		BCS 317(PC)										
  execution.go:755	0x100211024		8b161196		ADD R22<<4, R12, R22									
  execution.go:755	0x100211028		f94002c4		MOVD (R22), R4										
  execution.go:755	0x10021102c		14000002		JMP 2(PC)										
  execution.go:755	0x100211030		aa1f03e4		MOVD ZR, R4										
  execution.go:757	0x100211034		b9401696		MOVWU 20(R20), R22									
  execution.go:757	0x100211038		310006df		CMNW $1, R22										
  execution.go:757	0x10021103c		540000c0		BEQ 6(PC)										
  execution.go:758	0x100211040		eb1302df		CMP R19, R22										
  execution.go:758	0x100211044		54002622		BCS 305(PC)										
  execution.go:758	0x100211048		8b161196		ADD R22<<4, R12, R22									
  execution.go:758	0x10021104c		f94002c6		MOVD (R22), R6										
  execution.go:758	0x100211050		14000002		JMP 2(PC)										
  execution.go:758	0x100211054		aa1f03e6		MOVD ZR, R6										
  execution.go:762	0x100211058		d3507c36		UBFX $16, R1, $16, R22									
  execution.go:762	0x10021105c		7103fadf		CMPW $254, R22										
  execution.go:762	0x100211060		54000501		BNE 40(PC)										
  execution.go:763	0x100211064		d3403c36		UBFX $0, R1, $16, R22									
  execution.go:763	0x100211068		71000edf		CMPW $3, R22										
  execution.go:763	0x10021106c		54000101		BNE 8(PC)										
  execution.go:764	0x100211070		f9400001		MOVD (R0), R1										
  execution.go:764	0x100211074		f9400420		MOVD 8(R1), R0										
  execution.go:764	0x100211078		97ff9a36		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence(SB)		
  execution.go:770	0x10021107c		aa1f03e2		MOVD ZR, R2										
  execution.go:770	0x100211080		aa1f03e1		MOVD ZR, R1										
  execution.go:770	0x100211084		aa1f03e0		MOVD ZR, R0										
  execution.go:765	0x100211088		1400004b		JMP 75(PC)										
  execution.go:767	0x10021108c		a947e1d7		LDP 120(R14), (R23, R24)								
  execution.go:767	0x100211090		b9400699		MOVWU 4(R20), R25									
  execution.go:767	0x100211094		aa1903fa		MOVD R25, R26										
  execution.go:767	0x100211098		eb18035f		CMP R24, R26										
  execution.go:767	0x10021109c		54002302		BCS 280(PC)										
  execution.go:767	0x1002110a0		d3787f38		UBFIZ $8, R25, $32, R24									
  execution.go:767	0x1002110a4		cb1a1718		SUB R26<<5, R24, R24									
  execution.go:767	0x1002110a8		8b1802f7		ADD R24, R23, R23									
  execution.go:769	0x1002110ac		a94765b8		LDP 112(R13), (R24, R25)								
  module.go:178		0x1002110b0		2942fafa		LDPW 20(R23), (R26, R30)								
  module.go:178		0x1002110b4		b9401ef7		MOVWU 28(R23), R23									
  module.go:178		0x1002110b8		aa178357		ORR R23<<32, R26, R23									
  execution.go:769	0x1002110bc		eb1903df		CMP R25, R30										
  execution.go:769	0x1002110c0		54002182		BCS 268(PC)										
  execution.go:769	0x1002110c4		f87e7b09		MOVD (R24)(R30<<3), R9									
  execution.go:769	0x1002110c8		f9400929		MOVD 16(R9), R9										
  execution.go:769	0x1002110cc		f940080a		MOVD 16(R0), R10									
  execution.go:769	0x1002110d0		a940040b		LDP (R0), (R11, R1)									
  execution.go:769	0x1002110d4		f9400563		MOVD 8(R11), R3										
  execution.go:769	0x1002110d8		aa0903e0		MOVD R9, R0										
  execution.go:769	0x1002110dc		aa0203e5		MOVD R2, R5										
  execution.go:769	0x1002110e0		aa0403e7		MOVD R4, R7										
  execution.go:769	0x1002110e4		aa0603e8		MOVD R6, R8										
  execution.go:769	0x1002110e8		aa0a03e2		MOVD R10, R2										
  execution.go:769	0x1002110ec		aa1603e4		MOVD R22, R4										
  execution.go:769	0x1002110f0		aa1703e6		MOVD R23, R6										
  execution.go:769	0x1002110f4		97ff9e57		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic(SB)		
  execution.go:770	0x1002110f8		b40005e3		CBZ R3, 47(PC)										
  execution.go:770	0x1002110fc		140000bd		JMP 189(PC)										
  execution.go:773	0x100211100		d2800108		MOVD $8, R8										
  execution.go:773	0x100211104		f2a01f88		MOVK $(252<<16), R8									
  execution.go:773	0x100211108		cb080028		SUB R8, R1, R8										
  execution.go:773	0x10021110c		7100251f		CMPW $9, R8										
  execution.go:773	0x100211110		54001e68		BHI 243(PC)										
  execution.go:774	0x100211114		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:774	0x100211118		b9400697		MOVWU 4(R20), R23									
  execution.go:774	0x10021111c		aa1703f8		MOVD R23, R24										
  execution.go:774	0x100211120		eb16031f		CMP R22, R24										
  execution.go:774	0x100211124		54001d62		BCS 235(PC)										
  execution.go:774	0x100211128		d3787ee9		UBFIZ $8, R23, $32, R9									
  execution.go:774	0x10021112c		cb181529		SUB R24<<5, R9, R9									
  execution.go:774	0x100211130		8b090108		ADD R9, R8, R8										
  execution.go:776	0x100211134		910623e9		ADD $392, RSP, R9									
  execution.go:776	0x100211138		ad404510		FLDPQ (R8), (F16, F17)									
  execution.go:776	0x10021113c		ad004530		FSTPQ (F16, F17), (R9)									
  execution.go:776	0x100211140		ad414510		FLDPQ 32(R8), (F16, F17)								
  execution.go:776	0x100211144		ad014530		FSTPQ (F16, F17), 32(R9)								
  execution.go:776	0x100211148		ad424510		FLDPQ 64(R8), (F16, F17)								
  execution.go:776	0x10021114c		ad024530		FSTPQ (F16, F17), 64(R9)								
  execution.go:776	0x100211150		ad434510		FLDPQ 96(R8), (F16, F17)								
  execution.go:776	0x100211154		ad034530		FSTPQ (F16, F17), 96(R9)								
  execution.go:776	0x100211158		ad444510		FLDPQ 128(R8), (F16, F17)								
  execution.go:776	0x10021115c		ad044530		FSTPQ (F16, F17), 128(R9)								
  execution.go:776	0x100211160		f9405119		MOVD 160(R8), R25									
  execution.go:776	0x100211164		f9005139		MOVD R25, 160(R9)									
  execution.go:776	0x100211168		910023e8		ADD $8, RSP, R8										
  execution.go:776	0x10021116c		ad404530		FLDPQ (R9), (F16, F17)									
  execution.go:776	0x100211170		ad004510		FSTPQ (F16, F17), (R8)									
  execution.go:776	0x100211174		ad414530		FLDPQ 32(R9), (F16, F17)								
  execution.go:776	0x100211178		ad014510		FSTPQ (F16, F17), 32(R8)								
  execution.go:776	0x10021117c		ad424530		FLDPQ 64(R9), (F16, F17)								
  execution.go:776	0x100211180		ad024510		FSTPQ (F16, F17), 64(R8)								
  execution.go:776	0x100211184		ad434530		FLDPQ 96(R9), (F16, F17)								
  execution.go:776	0x100211188		ad034510		FSTPQ (F16, F17), 96(R8)								
  execution.go:776	0x10021118c		ad444530		FLDPQ 128(R9), (F16, F17)								
  execution.go:776	0x100211190		ad044510		FSTPQ (F16, F17), 128(R8)								
  execution.go:776	0x100211194		f9405139		MOVD 160(R9), R25									
  execution.go:776	0x100211198		f9005119		MOVD R25, 160(R8)									
  execution.go:776	0x10021119c		aa0d03e1		MOVD R13, R1										
  execution.go:776	0x1002111a0		aa1f03e3		MOVD ZR, R3										
  execution.go:776	0x1002111a4		aa1f03e5		MOVD ZR, R5										
  execution.go:776	0x1002111a8		aa1f03e7		MOVD ZR, R7										
  execution.go:776	0x1002111ac		97fff0c1		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk(SB)		
  execution.go:777	0x1002111b0		b5001703		CBNZ R3, 184(PC)									
  execution.go:342	0x1002111b4		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002111b8		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002111bc		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x1002111c0		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002111c4		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002111c8		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002111cc		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002111d0		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002111d4		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002111d8		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002111dc		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002111e0		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x1002111e4		aa0103f7		MOVD R1, R23										
  execution.go:704	0x1002111e8		aa0003f6		MOVD R0, R22										
  execution.go:708	0x1002111ec		aa0203e1		MOVD R2, R1										
  execution.go:209	0x1002111f0		f94127e0		MOVD 584(RSP), R0									
  execution.go:785	0x1002111f4		d3401c38		UBFX $0, R1, $8, R24									
  execution.go:785	0x1002111f8		350010d8		CBNZW R24, 134(PC)									
  execution.go:789	0x1002111fc		b9400a94		MOVWU 8(R20), R20									
  execution.go:789	0x100211200		3100069f		CMNW $1, R20										
  execution.go:789	0x100211204		540000a0		BEQ 5(PC)										
  execution.go:790	0x100211208		eb13029f		CMP R19, R20										
  execution.go:790	0x10021120c		540015c2		BCS 174(PC)										
  execution.go:790	0x100211210		8b141194		ADD R20<<4, R12, R20									
  execution.go:790	0x100211214		a9005e96		STP (R22, R23), (R20)									
  execution.go:792	0x100211218		91000631		ADD $1, R17, R17									
  execution.go:793	0x10021121c		17fff90e		JMP -1778(PC)										
  execution.go:466	0x100211220		b9000951		MOVW R17, 8(R10)									
  execution.go:467	0x100211224		94000827		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:467	0x100211228		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:467	0x10021122c		34ff1d21		CBZW R1, -1815(PC)									
  execution.go:467	0x100211230		1400003b		JMP 59(PC)										
  execution.go:664	0x100211234		b9000951		MOVW R17, 8(R10)									
  execution.go:665	0x100211238		94000dde		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow(SB)	
  execution.go:665	0x10021123c		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:665	0x100211240		34ff1c81		CBZW R1, -1820(PC)									
  execution.go:665	0x100211244		1400005a		JMP 90(PC)										
  execution.go:744	0x100211248		b9000951		MOVW R17, 8(R10)									
  execution.go:745	0x10021124c		94000abd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB)		
  execution.go:745	0x100211250		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:745	0x100211254		34ff1be1		CBZW R1, -1825(PC)									
  execution.go:745	0x100211258		14000059		JMP 89(PC)										
  execution.go:623	0x10021125c		b9000951		MOVW R17, 8(R10)									
  execution.go:624	0x100211260		94000eb0		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame(SB)	
  execution.go:624	0x100211264		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:624	0x100211268		34ff1b41		CBZW R1, -1830(PC)									
  execution.go:624	0x10021126c		14000058		JMP 88(PC)										
  execution.go:629	0x100211270		b9000951		MOVW R17, 8(R10)									
  execution.go:630	0x100211274		94000813		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:630	0x100211278		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:630	0x10021127c		34ff1aa1		CBZW R1, -1835(PC)									
  execution.go:630	0x100211280		1400008c		JMP 140(PC)										
  execution.go:343	0x100211284		f9009ff5		MOVD R21, 312(RSP)									
  execution.go:341	0x100211288		f90097e1		MOVD R1, 296(RSP)									
  execution.go:346	0x10021128c		d2800500		MOVD $40, R0										
  execution.go:346	0x100211290		b0001221		ADRP 2379776(PC), R1									
  execution.go:346	0x100211294		913f8021		ADD $4064, R1, R1									
  execution.go:346	0x100211298		b24003e2		ORR $1, ZR, R2										
  execution.go:346	0x10021129c		97f82e59		CALL runtime.mallocgcSmallScanNoHeaderSC5(SB)						
  execution.go:346	0x1002112a0		d000137b		ADRP 2547712(PC), R27									
  execution.go:346	0x1002112a4		9104437b		ADD $272, R27, R27									
  execution.go:346	0x1002112a8		a9401363		LDP (R27), (R3, R4)									
  execution.go:346	0x1002112ac		f9000003		MOVD R3, (R0)										
  execution.go:346	0x1002112b0		f00014db		ADRP 2732032(PC), R27									
  execution.go:346	0x1002112b4		b94ef363		MOVWU 3824(R27), R3									
  execution.go:346	0x1002112b8		34000063		CBZW R3, 3(PC)										
  execution.go:346	0x1002112bc		97f9c7e9		CALL runtime.gcWriteBarrier1(SB)							
  execution.go:346	0x1002112c0		f9000324		MOVD R4, (R25)										
  execution.go:346	0x1002112c4		f9000404		MOVD R4, 8(R0)										
  execution.go:346	0x1002112c8		f9409fe3		MOVD 312(RSP), R3									
  execution.go:346	0x1002112cc		f9400463		MOVD 8(R3), R3										
  execution.go:346	0x1002112d0		f00000e4		ADRP 126976(PC), R4									
  execution.go:346	0x1002112d4		910bbc84		ADD $751, R4, R4									
  execution.go:346	0x1002112d8		a9011003		STP (R3, R4), 16(R0)									
  execution.go:346	0x1002112dc		b27f0be3		ORR $14, ZR, R3										
  execution.go:346	0x1002112e0		f9001003		MOVD R3, 32(R0)										
  execution.go:346	0x1002112e4		f00012e1		ADRP 2486272(PC), R1									
  execution.go:346	0x1002112e8		910b0021		ADD $704, R1, R1									
  execution.go:346	0x1002112ec		aa0003e2		MOVD R0, R2										
  execution.go:346	0x1002112f0		f94127e0		MOVD 584(RSP), R0									
  execution.go:346	0x1002112f4		97fff63f		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:346	0x1002112f8		f94097e1		MOVD 296(RSP), R1									
  execution.go:346	0x1002112fc		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:346	0x100211300		910903ff		ADD $576, RSP, RSP									
  execution.go:346	0x100211304		d65f03c0		RET											
  execution.go:353	0x100211308		97fff63a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:353	0x10021130c		f94097e1		MOVD 296(RSP), R1									
  execution.go:353	0x100211310		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:353	0x100211314		910903ff		ADD $576, RSP, RSP									
  execution.go:353	0x100211318		d65f03c0		RET											
  execution.go:468	0x10021131c		f94093e1		MOVD 288(RSP), R1									
  execution.go:468	0x100211320		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:468	0x100211324		910903ff		ADD $576, RSP, RSP									
  execution.go:468	0x100211328		d65f03c0		RET											
  execution.go:412	0x10021132c		f900bbe3		MOVD R3, 368(RSP)									
  execution.go:412	0x100211330		f9008fe2		MOVD R2, 280(RSP)									
  execution.go:414	0x100211334		b27d03e0		ORR $8, ZR, R0										
  execution.go:414	0x100211338		f0001061		ADRP 2158592(PC), R1									
  execution.go:414	0x10021133c		913e2021		ADD $3976, R1, R1									
  execution.go:414	0x100211340		b24003e2		ORR $1, ZR, R2										
  execution.go:414	0x100211344		97f82afb		CALL runtime.mallocgcSmallScanNoHeaderSC1(SB)						
  execution.go:414	0x100211348		f9011be0		MOVD R0, 560(RSP)									
  execution.go:415	0x10021134c		f940bbe1		MOVD 368(RSP), R1									
  execution.go:415	0x100211350		b0000fc2		ADRP 2068480(PC), R2									
  execution.go:415	0x100211354		91246042		ADD $2328, R2, R2									
  execution.go:415	0x100211358		aa0003e3		MOVD R0, R3										
  execution.go:415	0x10021135c		f9408fe0		MOVD 280(RSP), R0									
  execution.go:415	0x100211360		97f9dba4		CALL errors.As(SB)									
  execution.go:415	0x100211364		360000c0		TBZ $0, R0, 6(PC)									
  execution.go:416	0x100211368		f9411be3		MOVD 560(RSP), R3									
  execution.go:416	0x10021136c		f9400063		MOVD (R3), R3										
  execution.go:416	0x100211370		f940b3e4		MOVD 352(RSP), R4									
  execution.go:416	0x100211374		b9405084		MOVWU 80(R4), R4									
  execution.go:416	0x100211378		b9000464		MOVW R4, 4(R3)										
  execution.go:418	0x10021137c		f94127e0		MOVD 584(RSP), R0									
  execution.go:418	0x100211380		f9408fe1		MOVD 280(RSP), R1									
  execution.go:418	0x100211384		f940bbe2		MOVD 368(RSP), R2									
  execution.go:418	0x100211388		97fff61a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:418	0x10021138c		f94093e1		MOVD 288(RSP), R1									
  execution.go:418	0x100211390		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:418	0x100211394		910903ff		ADD $576, RSP, RSP									
  execution.go:418	0x100211398		d65f03c0		RET											
  execution.go:426	0x10021139c		f94093e1		MOVD 288(RSP), R1									
  execution.go:426	0x1002113a0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:426	0x1002113a4		910903ff		ADD $576, RSP, RSP									
  execution.go:426	0x1002113a8		d65f03c0		RET											
  execution.go:666	0x1002113ac		f94093e1		MOVD 288(RSP), R1									
  execution.go:666	0x1002113b0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:666	0x1002113b4		910903ff		ADD $576, RSP, RSP									
  execution.go:666	0x1002113b8		d65f03c0		RET											
  execution.go:746	0x1002113bc		f94093e1		MOVD 288(RSP), R1									
  execution.go:746	0x1002113c0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:746	0x1002113c4		910903ff		ADD $576, RSP, RSP									
  execution.go:746	0x1002113c8		d65f03c0		RET											
  execution.go:625	0x1002113cc		f94093e1		MOVD 288(RSP), R1									
  execution.go:625	0x1002113d0		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:625	0x1002113d4		910903ff		ADD $576, RSP, RSP									
  execution.go:625	0x1002113d8		d65f03c0		RET											
  execution.go:654	0x1002113dc		97fff605		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:654	0x1002113e0		f94093e1		MOVD 288(RSP), R1									
  execution.go:654	0x1002113e4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:654	0x1002113e8		910903ff		ADD $576, RSP, RSP									
  execution.go:654	0x1002113ec		d65f03c0		RET											
  execution.go:771	0x1002113f0		f94127e0		MOVD 584(RSP), R0									
  execution.go:771	0x1002113f4		aa0303e1		MOVD R3, R1										
  execution.go:771	0x1002113f8		aa0403e2		MOVD R4, R2										
  execution.go:771	0x1002113fc		97fff5fd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:771	0x100211400		f94093e1		MOVD 288(RSP), R1									
  execution.go:771	0x100211404		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:771	0x100211408		910903ff		ADD $576, RSP, RSP									
  execution.go:771	0x10021140c		d65f03c0		RET											
  execution.go:395	0x100211410		3903dbe1		MOVB R1, 246(RSP)									
  execution.go:786	0x100211414		b27c03e0		ORR $16, ZR, R0										
  execution.go:786	0x100211418		d0001221		ADRP 2383872(PC), R1									
  execution.go:786	0x10021141c		91022021		ADD $136, R1, R1									
  execution.go:786	0x100211420		b24003e2		ORR $1, ZR, R2										
  execution.go:786	0x100211424		97f8317b		CALL runtime.mallocgcSmallNoScanSC2(SB)							
  execution.go:786	0x100211428		3943dbe3		MOVBU 246(RSP), R3									
  execution.go:786	0x10021142c		39000003		MOVB R3, (R0)										
  execution.go:786	0x100211430		f940b3e3		MOVD 352(RSP), R3									
  execution.go:786	0x100211434		b9405063		MOVWU 80(R3), R3									
  execution.go:786	0x100211438		b9000403		MOVW R3, 4(R0)										
  execution.go:786	0x10021143c		f940bfe3		MOVD 376(RSP), R3									
  execution.go:786	0x100211440		a9479063		LDP 120(R3), (R3, R4)									
  execution.go:786	0x100211444		f940c3e5		MOVD 384(RSP), R5									
  execution.go:786	0x100211448		b94004a5		MOVWU 4(R5), R5										
  execution.go:786	0x10021144c		aa0503e6		MOVD R5, R6										
  execution.go:786	0x100211450		eb0400df		CMP R4, R6										
  execution.go:786	0x100211454		54000362		BCS 27(PC)										
  execution.go:786	0x100211458		d3787ca4		UBFIZ $8, R5, $32, R4									
  execution.go:786	0x10021145c		cb061484		SUB R6<<5, R4, R4									
  execution.go:786	0x100211460		8b040063		ADD R4, R3, R3										
  execution.go:786	0x100211464		f9400463		MOVD 8(R3), R3										
  execution.go:786	0x100211468		f9000403		MOVD R3, 8(R0)										
  execution.go:786	0x10021146c		f00012e1		ADRP 2486272(PC), R1									
  execution.go:786	0x100211470		910c0021		ADD $768, R1, R1									
  execution.go:786	0x100211474		aa0003e2		MOVD R0, R2										
  execution.go:786	0x100211478		f94127e0		MOVD 584(RSP), R0									
  execution.go:786	0x10021147c		97fff5dd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:786	0x100211480		f94093e1		MOVD 288(RSP), R1									
  execution.go:786	0x100211484		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:786	0x100211488		910903ff		ADD $576, RSP, RSP									
  execution.go:786	0x10021148c		d65f03c0		RET											
  execution.go:778	0x100211490		f94127e0		MOVD 584(RSP), R0									
  execution.go:778	0x100211494		aa0303e1		MOVD R3, R1										
  execution.go:778	0x100211498		aa0403e2		MOVD R4, R2										
  execution.go:778	0x10021149c		97fff5d5		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:778	0x1002114a0		f94093e1		MOVD 288(RSP), R1									
  execution.go:778	0x1002114a4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:778	0x1002114a8		910903ff		ADD $576, RSP, RSP									
  execution.go:778	0x1002114ac		d65f03c0		RET											
  execution.go:631	0x1002114b0		f94093e1		MOVD 288(RSP), R1									
  execution.go:631	0x1002114b4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:631	0x1002114b8		910903ff		ADD $576, RSP, RSP									
  execution.go:631	0x1002114bc		d65f03c0		RET											
  execution.go:786	0x1002114c0		97f9c820		CALL runtime.panicBounds(SB)								
  execution.go:790	0x1002114c4		aa1403e0		MOVD R20, R0										
  execution.go:790	0x1002114c8		aa1303e1		MOVD R19, R1										
  execution.go:790	0x1002114cc		97f9c81d		CALL runtime.panicBounds(SB)								
  execution.go:774	0x1002114d0		aa1803e0		MOVD R24, R0										
  execution.go:774	0x1002114d4		aa1603e1		MOVD R22, R1										
  execution.go:774	0x1002114d8		97f9c81a		CALL runtime.panicBounds(SB)								
  execution.go:781	0x1002114dc		f0001160		ADRP 2289664(PC), R0									
  execution.go:781	0x1002114e0		911e6000		ADD $1944, R0, R0									
  execution.go:781	0x1002114e4		f0000f81		ADRP 2043904(PC), R1									
  execution.go:781	0x1002114e8		91294021		ADD $2640, R1, R1									
  execution.go:781	0x1002114ec		97f9aca9		CALL runtime.gopanic(SB)								
  execution.go:769	0x1002114f0		aa1e03e0		MOVD R30, R0										
  execution.go:769	0x1002114f4		aa1903e1		MOVD R25, R1										
  execution.go:769	0x1002114f8		97f9c812		CALL runtime.panicBounds(SB)								
  execution.go:767	0x1002114fc		aa1a03e0		MOVD R26, R0										
  execution.go:767	0x100211500		aa1803e1		MOVD R24, R1										
  execution.go:767	0x100211504		97f9c80f		CALL runtime.panicBounds(SB)								
  execution.go:758	0x100211508		aa1603e0		MOVD R22, R0										
  execution.go:758	0x10021150c		aa1303e1		MOVD R19, R1										
  execution.go:758	0x100211510		97f9c80c		CALL runtime.panicBounds(SB)								
  execution.go:755	0x100211514		aa1603e0		MOVD R22, R0										
  execution.go:755	0x100211518		aa1303e1		MOVD R19, R1										
  execution.go:755	0x10021151c		97f9c809		CALL runtime.panicBounds(SB)								
  execution.go:752	0x100211520		aa1603e0		MOVD R22, R0										
  execution.go:752	0x100211524		aa1303e1		MOVD R19, R1										
  execution.go:752	0x100211528		97f9c806		CALL runtime.panicBounds(SB)								
  execution.go:658	0x10021152c		8b181198		ADD R24<<4, R12, R24									
  execution.go:658	0x100211530		a9006b19		STP (R25, R26), (R24)									
  execution.go:657	0x100211534		910006f7		ADD $1, R23, R23									
  execution.go:657	0x100211538		eb1402ff		CMP R20, R23										
  execution.go:657	0x10021153c		5400014a		BGE 10(PC)										
  execution.go:657	0x100211540		8b170e38		ADD R23<<3, R17, R24									
  execution.go:657	0x100211544		29406718		LDPW (R24), (R24, R25)									
  execution.go:658	0x100211548		eb13033f		CMP R19, R25										
  execution.go:658	0x10021154c		54000162		BCS 11(PC)										
  execution.go:658	0x100211550		8b191199		ADD R25<<4, R12, R25									
  execution.go:658	0x100211554		a9406b39		LDP (R25), (R25, R26)									
  execution.go:658	0x100211558		eb13031f		CMP R19, R24										
  execution.go:658	0x10021155c		54fffe83		BCC -12(PC)										
  execution.go:658	0x100211560		14000003		JMP 3(PC)										
  execution.go:460	0x100211564		aa1603f1		MOVD R22, R17										
  execution.go:661	0x100211568		17fff83b		JMP -1989(PC)										
  execution.go:658	0x10021156c		aa1803e0		MOVD R24, R0										
  execution.go:658	0x100211570		aa1303e1		MOVD R19, R1										
  execution.go:658	0x100211574		97f9c7f3		CALL runtime.panicBounds(SB)								
  execution.go:658	0x100211578		aa1903e0		MOVD R25, R0										
  execution.go:658	0x10021157c		aa1303e1		MOVD R19, R1										
  execution.go:658	0x100211580		97f9c7f0		CALL runtime.panicBounds(SB)								
  execution.go:657	0x100211584		aa1403e0		MOVD R20, R0										
  execution.go:657	0x100211588		aa1703e1		MOVD R23, R1										
  execution.go:657	0x10021158c		97f9c7ed		CALL runtime.panicBounds(SB)								
  execution.go:657	0x100211590		aa1703e0		MOVD R23, R0										
  execution.go:657	0x100211594		aa1103e1		MOVD R17, R1										
  execution.go:657	0x100211598		97f9c7ea		CALL runtime.panicBounds(SB)								
  execution.go:651	0x10021159c		aa1603e0		MOVD R22, R0										
  execution.go:651	0x1002115a0		aa1803e1		MOVD R24, R1										
  execution.go:651	0x1002115a4		97f9c7e7		CALL runtime.panicBounds(SB)								
  execution.go:646	0x1002115a8		aa1703e0		MOVD R23, R0										
  execution.go:646	0x1002115ac		aa1303e1		MOVD R19, R1										
  execution.go:646	0x1002115b0		97f9c7e4		CALL runtime.panicBounds(SB)								
  execution.go:643	0x1002115b4		aa1803e0		MOVD R24, R0										
  execution.go:643	0x1002115b8		aa1303e1		MOVD R19, R1										
  execution.go:643	0x1002115bc		97f9c7e1		CALL runtime.panicBounds(SB)								
  execution.go:641	0x1002115c0		aa1803e0		MOVD R24, R0										
  execution.go:641	0x1002115c4		aa1303e1		MOVD R19, R1										
  execution.go:641	0x1002115c8		97f9c7de		CALL runtime.panicBounds(SB)								
  execution.go:725	0x1002115cc		aa1303e0		MOVD R19, R0										
  execution.go:725	0x1002115d0		97f9c7dc		CALL runtime.panicBounds(SB)								
  execution.go:732	0x1002115d4		aa1603e0		MOVD R22, R0										
  execution.go:732	0x1002115d8		aa1303e1		MOVD R19, R1										
  execution.go:732	0x1002115dc		97f9c7d9		CALL runtime.panicBounds(SB)								
  execution.go:727	0x1002115e0		aa1703e0		MOVD R23, R0										
  execution.go:727	0x1002115e4		aa1303e1		MOVD R19, R1										
  execution.go:727	0x1002115e8		97f9c7d6		CALL runtime.panicBounds(SB)								
  execution.go:727	0x1002115ec		aa1603e0		MOVD R22, R0										
  execution.go:727	0x1002115f0		aa1303e1		MOVD R19, R1										
  execution.go:727	0x1002115f4		97f9c7d3		CALL runtime.panicBounds(SB)								
  execution.go:742	0x1002115f8		aa1803e0		MOVD R24, R0										
  execution.go:742	0x1002115fc		aa1703e1		MOVD R23, R1										
  execution.go:742	0x100211600		97f9c7d0		CALL runtime.panicBounds(SB)								
  execution.go:738	0x100211604		aa1603e0		MOVD R22, R0										
  execution.go:738	0x100211608		aa1303e1		MOVD R19, R1										
  execution.go:738	0x10021160c		97f9c7cd		CALL runtime.panicBounds(SB)								
  execution.go:710	0x100211610		97f9c7cc		CALL runtime.panicBounds(SB)								
  execution.go:713	0x100211614		aa1303e0		MOVD R19, R0										
  execution.go:713	0x100211618		97f9c7ca		CALL runtime.panicBounds(SB)								
  execution.go:712	0x10021161c		97f9c7c9		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100211620		aa1603e0		MOVD R22, R0										
  execution.go:708	0x100211624		aa1303e1		MOVD R19, R1										
  execution.go:708	0x100211628		97f9c7c6		CALL runtime.panicBounds(SB)								
  execution.go:708	0x10021162c		aa1703e0		MOVD R23, R0										
  execution.go:708	0x100211630		97f9c7c4		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100211634		aa1303e0		MOVD R19, R0										
  execution.go:708	0x100211638		97f9c7c2		CALL runtime.panicBounds(SB)								
  execution.go:707	0x10021163c		aa1703e0		MOVD R23, R0										
  execution.go:707	0x100211640		97f9c7c0		CALL runtime.panicBounds(SB)								
  execution.go:704	0x100211644		aa1303e0		MOVD R19, R0										
  execution.go:704	0x100211648		97f9c7be		CALL runtime.panicBounds(SB)								
  execution.go:704	0x10021164c		aa1803e0		MOVD R24, R0										
  execution.go:704	0x100211650		aa1603e1		MOVD R22, R1										
  execution.go:704	0x100211654		97f9c7bb		CALL runtime.panicBounds(SB)								
  execution.go:703	0x100211658		aa1703e0		MOVD R23, R0										
  execution.go:703	0x10021165c		97f9c7b9		CALL runtime.panicBounds(SB)								
  execution.go:699	0x100211660		aa1803e0		MOVD R24, R0										
  execution.go:699	0x100211664		aa1303e1		MOVD R19, R1										
  execution.go:699	0x100211668		97f9c7b6		CALL runtime.panicBounds(SB)								
  execution.go:695	0x10021166c		aa1703e0		MOVD R23, R0										
  execution.go:695	0x100211670		aa1303e1		MOVD R19, R1										
  execution.go:695	0x100211674		97f9c7b3		CALL runtime.panicBounds(SB)								
  execution.go:694	0x100211678		aa1803e0		MOVD R24, R0										
  execution.go:694	0x10021167c		aa1703e1		MOVD R23, R1										
  execution.go:694	0x100211680		97f9c7b0		CALL runtime.panicBounds(SB)								
  execution.go:687	0x100211684		aa1703e0		MOVD R23, R0										
  execution.go:687	0x100211688		aa1303e1		MOVD R19, R1										
  execution.go:687	0x10021168c		97f9c7ad		CALL runtime.panicBounds(SB)								
  execution.go:686	0x100211690		aa1803e0		MOVD R24, R0										
  execution.go:686	0x100211694		aa1703e1		MOVD R23, R1										
  execution.go:686	0x100211698		97f9c7aa		CALL runtime.panicBounds(SB)								
  execution.go:684	0x10021169c		aa1903e0		MOVD R25, R0										
  execution.go:684	0x1002116a0		aa1803e1		MOVD R24, R1										
  execution.go:684	0x1002116a4		97f9c7a7		CALL runtime.panicBounds(SB)								
  execution.go:684	0x1002116a8		aa1603e0		MOVD R22, R0										
  execution.go:684	0x1002116ac		aa1303e1		MOVD R19, R1										
  execution.go:684	0x1002116b0		97f9c7a4		CALL runtime.panicBounds(SB)								
  execution.go:682	0x1002116b4		aa1803e0		MOVD R24, R0										
  execution.go:682	0x1002116b8		aa1703e1		MOVD R23, R1										
  execution.go:682	0x1002116bc		97f9c7a1		CALL runtime.panicBounds(SB)								
  execution.go:680	0x1002116c0		aa1803e0		MOVD R24, R0										
  execution.go:680	0x1002116c4		aa1303e1		MOVD R19, R1										
  execution.go:680	0x1002116c8		97f9c79e		CALL runtime.panicBounds(SB)								
  execution.go:679	0x1002116cc		aa1603e0		MOVD R22, R0										
  execution.go:679	0x1002116d0		aa1303e1		MOVD R19, R1										
  execution.go:679	0x1002116d4		97f9c79b		CALL runtime.panicBounds(SB)								
  execution.go:677	0x1002116d8		aa1603e0		MOVD R22, R0										
  execution.go:677	0x1002116dc		aa1303e1		MOVD R19, R1										
  execution.go:677	0x1002116e0		97f9c798		CALL runtime.panicBounds(SB)								
  execution.go:675	0x1002116e4		aa1603e0		MOVD R22, R0										
  execution.go:675	0x1002116e8		aa1303e1		MOVD R19, R1										
  execution.go:675	0x1002116ec		97f9c795		CALL runtime.panicBounds(SB)								
  execution.go:672	0x1002116f0		aa1703e0		MOVD R23, R0										
  execution.go:672	0x1002116f4		aa1303e1		MOVD R19, R1										
  execution.go:672	0x1002116f8		97f9c792		CALL runtime.panicBounds(SB)								
  execution.go:600	0x1002116fc		aa1603e0		MOVD R22, R0										
  execution.go:600	0x100211700		aa1303e1		MOVD R19, R1										
  execution.go:600	0x100211704		97f9c78f		CALL runtime.panicBounds(SB)								
  execution.go:598	0x100211708		aa1603e0		MOVD R22, R0										
  execution.go:598	0x10021170c		aa1303e1		MOVD R19, R1										
  execution.go:598	0x100211710		97f9c78c		CALL runtime.panicBounds(SB)								
  execution.go:596	0x100211714		aa1603e0		MOVD R22, R0										
  execution.go:596	0x100211718		aa1303e1		MOVD R19, R1										
  execution.go:596	0x10021171c		97f9c789		CALL runtime.panicBounds(SB)								
  execution.go:594	0x100211720		aa1603e0		MOVD R22, R0										
  execution.go:594	0x100211724		aa1303e1		MOVD R19, R1										
  execution.go:594	0x100211728		97f9c786		CALL runtime.panicBounds(SB)								
  execution.go:592	0x10021172c		aa1603e0		MOVD R22, R0										
  execution.go:592	0x100211730		aa1303e1		MOVD R19, R1										
  execution.go:592	0x100211734		97f9c783		CALL runtime.panicBounds(SB)								
  execution.go:614	0x100211738		aa1303e0		MOVD R19, R0										
  execution.go:614	0x10021173c		97f9c781		CALL runtime.panicBounds(SB)								
  execution.go:612	0x100211740		aa1303e0		MOVD R19, R0										
  execution.go:612	0x100211744		97f9c77f		CALL runtime.panicBounds(SB)								
  execution.go:590	0x100211748		aa1603e0		MOVD R22, R0										
  execution.go:590	0x10021174c		aa1303e1		MOVD R19, R1										
  execution.go:590	0x100211750		97f9c77c		CALL runtime.panicBounds(SB)								
  execution.go:588	0x100211754		aa1603e0		MOVD R22, R0										
  execution.go:588	0x100211758		aa1303e1		MOVD R19, R1										
  execution.go:588	0x10021175c		97f9c779		CALL runtime.panicBounds(SB)								
  execution.go:586	0x100211760		aa1603e0		MOVD R22, R0										
  execution.go:586	0x100211764		aa1303e1		MOVD R19, R1										
  execution.go:586	0x100211768		97f9c776		CALL runtime.panicBounds(SB)								
  execution.go:584	0x10021176c		aa1703e0		MOVD R23, R0										
  execution.go:584	0x100211770		aa1303e1		MOVD R19, R1										
  execution.go:584	0x100211774		97f9c773		CALL runtime.panicBounds(SB)								
  execution.go:584	0x100211778		aa1603e0		MOVD R22, R0										
  execution.go:584	0x10021177c		aa1303e1		MOVD R19, R1										
  execution.go:584	0x100211780		97f9c770		CALL runtime.panicBounds(SB)								
  execution.go:582	0x100211784		aa1703e0		MOVD R23, R0										
  execution.go:582	0x100211788		aa1303e1		MOVD R19, R1										
  execution.go:582	0x10021178c		97f9c76d		CALL runtime.panicBounds(SB)								
  execution.go:582	0x100211790		aa1603e0		MOVD R22, R0										
  execution.go:582	0x100211794		aa1303e1		MOVD R19, R1										
  execution.go:582	0x100211798		97f9c76a		CALL runtime.panicBounds(SB)								
  execution.go:580	0x10021179c		aa1703e0		MOVD R23, R0										
  execution.go:580	0x1002117a0		aa1303e1		MOVD R19, R1										
  execution.go:580	0x1002117a4		97f9c767		CALL runtime.panicBounds(SB)								
  execution.go:580	0x1002117a8		aa1603e0		MOVD R22, R0										
  execution.go:580	0x1002117ac		aa1303e1		MOVD R19, R1										
  execution.go:580	0x1002117b0		97f9c764		CALL runtime.panicBounds(SB)								
  execution.go:578	0x1002117b4		aa1703e0		MOVD R23, R0										
  execution.go:578	0x1002117b8		aa1303e1		MOVD R19, R1										
  execution.go:578	0x1002117bc		97f9c761		CALL runtime.panicBounds(SB)								
  execution.go:578	0x1002117c0		aa1603e0		MOVD R22, R0										
  execution.go:578	0x1002117c4		aa1303e1		MOVD R19, R1										
  execution.go:578	0x1002117c8		97f9c75e		CALL runtime.panicBounds(SB)								
  execution.go:576	0x1002117cc		aa1703e0		MOVD R23, R0										
  execution.go:576	0x1002117d0		aa1303e1		MOVD R19, R1										
  execution.go:576	0x1002117d4		97f9c75b		CALL runtime.panicBounds(SB)								
  execution.go:576	0x1002117d8		aa1603e0		MOVD R22, R0										
  execution.go:576	0x1002117dc		aa1303e1		MOVD R19, R1										
  execution.go:576	0x1002117e0		97f9c758		CALL runtime.panicBounds(SB)								
  execution.go:574	0x1002117e4		aa1703e0		MOVD R23, R0										
  execution.go:574	0x1002117e8		aa1303e1		MOVD R19, R1										
  execution.go:574	0x1002117ec		97f9c755		CALL runtime.panicBounds(SB)								
  execution.go:574	0x1002117f0		aa1603e0		MOVD R22, R0										
  execution.go:574	0x1002117f4		aa1303e1		MOVD R19, R1										
  execution.go:574	0x1002117f8		97f9c752		CALL runtime.panicBounds(SB)								
  execution.go:572	0x1002117fc		aa1703e0		MOVD R23, R0										
  execution.go:572	0x100211800		aa1303e1		MOVD R19, R1										
  execution.go:572	0x100211804		97f9c74f		CALL runtime.panicBounds(SB)								
  execution.go:572	0x100211808		aa1603e0		MOVD R22, R0										
  execution.go:572	0x10021180c		aa1303e1		MOVD R19, R1										
  execution.go:572	0x100211810		97f9c74c		CALL runtime.panicBounds(SB)								
  execution.go:570	0x100211814		aa1703e0		MOVD R23, R0										
  execution.go:570	0x100211818		aa1303e1		MOVD R19, R1										
  execution.go:570	0x10021181c		97f9c749		CALL runtime.panicBounds(SB)								
  execution.go:570	0x100211820		aa1603e0		MOVD R22, R0										
  execution.go:570	0x100211824		aa1303e1		MOVD R19, R1										
  execution.go:570	0x100211828		97f9c746		CALL runtime.panicBounds(SB)								
  execution.go:568	0x10021182c		aa1703e0		MOVD R23, R0										
  execution.go:568	0x100211830		aa1303e1		MOVD R19, R1										
  execution.go:568	0x100211834		97f9c743		CALL runtime.panicBounds(SB)								
  execution.go:568	0x100211838		aa1603e0		MOVD R22, R0										
  execution.go:568	0x10021183c		aa1303e1		MOVD R19, R1										
  execution.go:568	0x100211840		97f9c740		CALL runtime.panicBounds(SB)								
  execution.go:566	0x100211844		aa1703e0		MOVD R23, R0										
  execution.go:566	0x100211848		aa1303e1		MOVD R19, R1										
  execution.go:566	0x10021184c		97f9c73d		CALL runtime.panicBounds(SB)								
  execution.go:566	0x100211850		aa1603e0		MOVD R22, R0										
  execution.go:566	0x100211854		aa1303e1		MOVD R19, R1										
  execution.go:566	0x100211858		97f9c73a		CALL runtime.panicBounds(SB)								
  execution.go:564	0x10021185c		aa1703e0		MOVD R23, R0										
  execution.go:564	0x100211860		aa1303e1		MOVD R19, R1										
  execution.go:564	0x100211864		97f9c737		CALL runtime.panicBounds(SB)								
  execution.go:564	0x100211868		aa1603e0		MOVD R22, R0										
  execution.go:564	0x10021186c		aa1303e1		MOVD R19, R1										
  execution.go:564	0x100211870		97f9c734		CALL runtime.panicBounds(SB)								
  execution.go:532	0x100211874		aa1603e0		MOVD R22, R0										
  execution.go:532	0x100211878		aa1303e1		MOVD R19, R1										
  execution.go:532	0x10021187c		97f9c731		CALL runtime.panicBounds(SB)								
  execution.go:562	0x100211880		aa1603e0		MOVD R22, R0										
  execution.go:562	0x100211884		aa1303e1		MOVD R19, R1										
  execution.go:562	0x100211888		97f9c72e		CALL runtime.panicBounds(SB)								
  execution.go:560	0x10021188c		aa1603e0		MOVD R22, R0										
  execution.go:560	0x100211890		aa1303e1		MOVD R19, R1										
  execution.go:560	0x100211894		97f9c72b		CALL runtime.panicBounds(SB)								
  execution.go:558	0x100211898		aa1703e0		MOVD R23, R0										
  execution.go:558	0x10021189c		aa1303e1		MOVD R19, R1										
  execution.go:558	0x1002118a0		97f9c728		CALL runtime.panicBounds(SB)								
  execution.go:558	0x1002118a4		aa1603e0		MOVD R22, R0										
  execution.go:558	0x1002118a8		aa1303e1		MOVD R19, R1										
  execution.go:558	0x1002118ac		97f9c725		CALL runtime.panicBounds(SB)								
  execution.go:556	0x1002118b0		aa1703e0		MOVD R23, R0										
  execution.go:556	0x1002118b4		aa1303e1		MOVD R19, R1										
  execution.go:556	0x1002118b8		97f9c722		CALL runtime.panicBounds(SB)								
  execution.go:556	0x1002118bc		aa1603e0		MOVD R22, R0										
  execution.go:556	0x1002118c0		aa1303e1		MOVD R19, R1										
  execution.go:556	0x1002118c4		97f9c71f		CALL runtime.panicBounds(SB)								
  execution.go:554	0x1002118c8		aa1703e0		MOVD R23, R0										
  execution.go:554	0x1002118cc		aa1303e1		MOVD R19, R1										
  execution.go:554	0x1002118d0		97f9c71c		CALL runtime.panicBounds(SB)								
  execution.go:554	0x1002118d4		aa1603e0		MOVD R22, R0										
  execution.go:554	0x1002118d8		aa1303e1		MOVD R19, R1										
  execution.go:554	0x1002118dc		97f9c719		CALL runtime.panicBounds(SB)								
  execution.go:552	0x1002118e0		aa1703e0		MOVD R23, R0										
  execution.go:552	0x1002118e4		aa1303e1		MOVD R19, R1										
  execution.go:552	0x1002118e8		97f9c716		CALL runtime.panicBounds(SB)								
  execution.go:552	0x1002118ec		aa1603e0		MOVD R22, R0										
  execution.go:552	0x1002118f0		aa1303e1		MOVD R19, R1										
  execution.go:552	0x1002118f4		97f9c713		CALL runtime.panicBounds(SB)								
  execution.go:550	0x1002118f8		aa1703e0		MOVD R23, R0										
  execution.go:550	0x1002118fc		aa1303e1		MOVD R19, R1										
  execution.go:550	0x100211900		97f9c710		CALL runtime.panicBounds(SB)								
  execution.go:550	0x100211904		aa1603e0		MOVD R22, R0										
  execution.go:550	0x100211908		aa1303e1		MOVD R19, R1										
  execution.go:550	0x10021190c		97f9c70d		CALL runtime.panicBounds(SB)								
  execution.go:548	0x100211910		aa1703e0		MOVD R23, R0										
  execution.go:548	0x100211914		aa1303e1		MOVD R19, R1										
  execution.go:548	0x100211918		97f9c70a		CALL runtime.panicBounds(SB)								
  execution.go:548	0x10021191c		aa1603e0		MOVD R22, R0										
  execution.go:548	0x100211920		aa1303e1		MOVD R19, R1										
  execution.go:548	0x100211924		97f9c707		CALL runtime.panicBounds(SB)								
  execution.go:546	0x100211928		aa1703e0		MOVD R23, R0										
  execution.go:546	0x10021192c		aa1303e1		MOVD R19, R1										
  execution.go:546	0x100211930		97f9c704		CALL runtime.panicBounds(SB)								
  execution.go:546	0x100211934		aa1603e0		MOVD R22, R0										
  execution.go:546	0x100211938		aa1303e1		MOVD R19, R1										
  execution.go:546	0x10021193c		97f9c701		CALL runtime.panicBounds(SB)								
  execution.go:544	0x100211940		aa1703e0		MOVD R23, R0										
  execution.go:544	0x100211944		aa1303e1		MOVD R19, R1										
  execution.go:544	0x100211948		97f9c6fe		CALL runtime.panicBounds(SB)								
  execution.go:544	0x10021194c		aa1603e0		MOVD R22, R0										
  execution.go:544	0x100211950		aa1303e1		MOVD R19, R1										
  execution.go:544	0x100211954		97f9c6fb		CALL runtime.panicBounds(SB)								
  execution.go:542	0x100211958		aa1703e0		MOVD R23, R0										
  execution.go:542	0x10021195c		aa1303e1		MOVD R19, R1										
  execution.go:542	0x100211960		97f9c6f8		CALL runtime.panicBounds(SB)								
  execution.go:542	0x100211964		aa1603e0		MOVD R22, R0										
  execution.go:542	0x100211968		aa1303e1		MOVD R19, R1										
  execution.go:542	0x10021196c		97f9c6f5		CALL runtime.panicBounds(SB)								
  execution.go:540	0x100211970		aa1703e0		MOVD R23, R0										
  execution.go:540	0x100211974		aa1303e1		MOVD R19, R1										
  execution.go:540	0x100211978		97f9c6f2		CALL runtime.panicBounds(SB)								
  execution.go:540	0x10021197c		aa1603e0		MOVD R22, R0										
  execution.go:540	0x100211980		aa1303e1		MOVD R19, R1										
  execution.go:540	0x100211984		97f9c6ef		CALL runtime.panicBounds(SB)								
  execution.go:538	0x100211988		aa1703e0		MOVD R23, R0										
  execution.go:538	0x10021198c		aa1303e1		MOVD R19, R1										
  execution.go:538	0x100211990		97f9c6ec		CALL runtime.panicBounds(SB)								
  execution.go:538	0x100211994		aa1603e0		MOVD R22, R0										
  execution.go:538	0x100211998		aa1303e1		MOVD R19, R1										
  execution.go:538	0x10021199c		97f9c6e9		CALL runtime.panicBounds(SB)								
  execution.go:528	0x1002119a0		aa1603e0		MOVD R22, R0										
  execution.go:528	0x1002119a4		aa1303e1		MOVD R19, R1										
  execution.go:528	0x1002119a8		97f9c6e6		CALL runtime.panicBounds(SB)								
  execution.go:526	0x1002119ac		aa1603e0		MOVD R22, R0										
  execution.go:526	0x1002119b0		aa1303e1		MOVD R19, R1										
  execution.go:526	0x1002119b4		97f9c6e3		CALL runtime.panicBounds(SB)								
  execution.go:524	0x1002119b8		aa1703e0		MOVD R23, R0										
  execution.go:524	0x1002119bc		aa1303e1		MOVD R19, R1										
  execution.go:524	0x1002119c0		97f9c6e0		CALL runtime.panicBounds(SB)								
  execution.go:524	0x1002119c4		aa1603e0		MOVD R22, R0										
  execution.go:524	0x1002119c8		aa1303e1		MOVD R19, R1										
  execution.go:524	0x1002119cc		97f9c6dd		CALL runtime.panicBounds(SB)								
  execution.go:522	0x1002119d0		aa1703e0		MOVD R23, R0										
  execution.go:522	0x1002119d4		aa1303e1		MOVD R19, R1										
  execution.go:522	0x1002119d8		97f9c6da		CALL runtime.panicBounds(SB)								
  execution.go:522	0x1002119dc		aa1603e0		MOVD R22, R0										
  execution.go:522	0x1002119e0		aa1303e1		MOVD R19, R1										
  execution.go:522	0x1002119e4		97f9c6d7		CALL runtime.panicBounds(SB)								
  execution.go:520	0x1002119e8		aa1703e0		MOVD R23, R0										
  execution.go:520	0x1002119ec		aa1303e1		MOVD R19, R1										
  execution.go:520	0x1002119f0		97f9c6d4		CALL runtime.panicBounds(SB)								
  execution.go:520	0x1002119f4		aa1603e0		MOVD R22, R0										
  execution.go:520	0x1002119f8		aa1303e1		MOVD R19, R1										
  execution.go:520	0x1002119fc		97f9c6d1		CALL runtime.panicBounds(SB)								
  execution.go:518	0x100211a00		aa1703e0		MOVD R23, R0										
  execution.go:518	0x100211a04		aa1303e1		MOVD R19, R1										
  execution.go:518	0x100211a08		97f9c6ce		CALL runtime.panicBounds(SB)								
  execution.go:518	0x100211a0c		aa1603e0		MOVD R22, R0										
  execution.go:518	0x100211a10		aa1303e1		MOVD R19, R1										
  execution.go:518	0x100211a14		97f9c6cb		CALL runtime.panicBounds(SB)								
  execution.go:516	0x100211a18		aa1703e0		MOVD R23, R0										
  execution.go:516	0x100211a1c		aa1303e1		MOVD R19, R1										
  execution.go:516	0x100211a20		97f9c6c8		CALL runtime.panicBounds(SB)								
  execution.go:516	0x100211a24		aa1603e0		MOVD R22, R0										
  execution.go:516	0x100211a28		aa1303e1		MOVD R19, R1										
  execution.go:516	0x100211a2c		97f9c6c5		CALL runtime.panicBounds(SB)								
  execution.go:514	0x100211a30		aa1703e0		MOVD R23, R0										
  execution.go:514	0x100211a34		aa1303e1		MOVD R19, R1										
  execution.go:514	0x100211a38		97f9c6c2		CALL runtime.panicBounds(SB)								
  execution.go:514	0x100211a3c		aa1603e0		MOVD R22, R0										
  execution.go:514	0x100211a40		aa1303e1		MOVD R19, R1										
  execution.go:514	0x100211a44		97f9c6bf		CALL runtime.panicBounds(SB)								
  execution.go:512	0x100211a48		aa1703e0		MOVD R23, R0										
  execution.go:512	0x100211a4c		aa1303e1		MOVD R19, R1										
  execution.go:512	0x100211a50		97f9c6bc		CALL runtime.panicBounds(SB)								
  execution.go:512	0x100211a54		aa1603e0		MOVD R22, R0										
  execution.go:512	0x100211a58		aa1303e1		MOVD R19, R1										
  execution.go:512	0x100211a5c		97f9c6b9		CALL runtime.panicBounds(SB)								
  execution.go:510	0x100211a60		aa1703e0		MOVD R23, R0										
  execution.go:510	0x100211a64		aa1303e1		MOVD R19, R1										
  execution.go:510	0x100211a68		97f9c6b6		CALL runtime.panicBounds(SB)								
  execution.go:510	0x100211a6c		aa1603e0		MOVD R22, R0										
  execution.go:510	0x100211a70		aa1303e1		MOVD R19, R1										
  execution.go:510	0x100211a74		97f9c6b3		CALL runtime.panicBounds(SB)								
  execution.go:508	0x100211a78		aa1703e0		MOVD R23, R0										
  execution.go:508	0x100211a7c		aa1303e1		MOVD R19, R1										
  execution.go:508	0x100211a80		97f9c6b0		CALL runtime.panicBounds(SB)								
  execution.go:508	0x100211a84		aa1603e0		MOVD R22, R0										
  execution.go:508	0x100211a88		aa1303e1		MOVD R19, R1										
  execution.go:508	0x100211a8c		97f9c6ad		CALL runtime.panicBounds(SB)								
  execution.go:506	0x100211a90		aa1703e0		MOVD R23, R0										
  execution.go:506	0x100211a94		aa1303e1		MOVD R19, R1										
  execution.go:506	0x100211a98		97f9c6aa		CALL runtime.panicBounds(SB)								
  execution.go:506	0x100211a9c		aa1603e0		MOVD R22, R0										
  execution.go:506	0x100211aa0		aa1303e1		MOVD R19, R1										
  execution.go:506	0x100211aa4		97f9c6a7		CALL runtime.panicBounds(SB)								
  execution.go:504	0x100211aa8		aa1603e0		MOVD R22, R0										
  execution.go:504	0x100211aac		aa1303e1		MOVD R19, R1										
  execution.go:504	0x100211ab0		97f9c6a4		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100211ab4		aa1703e0		MOVD R23, R0										
  execution.go:502	0x100211ab8		aa1303e1		MOVD R19, R1										
  execution.go:502	0x100211abc		97f9c6a1		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100211ac0		aa1603e0		MOVD R22, R0										
  execution.go:502	0x100211ac4		aa1303e1		MOVD R19, R1										
  execution.go:502	0x100211ac8		97f9c69e		CALL runtime.panicBounds(SB)								
  execution.go:500	0x100211acc		aa1703e0		MOVD R23, R0										
  execution.go:500	0x100211ad0		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100211ad4		97f9c69b		CALL runtime.panicBounds(SB)								
  execution.go:500	0x100211ad8		aa1603e0		MOVD R22, R0										
  execution.go:500	0x100211adc		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100211ae0		97f9c698		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100211ae4		aa1703e0		MOVD R23, R0										
  execution.go:498	0x100211ae8		aa1303e1		MOVD R19, R1										
  execution.go:498	0x100211aec		97f9c695		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100211af0		aa1603e0		MOVD R22, R0										
  execution.go:498	0x100211af4		aa1303e1		MOVD R19, R1										
  execution.go:498	0x100211af8		97f9c692		CALL runtime.panicBounds(SB)								
  execution.go:496	0x100211afc		aa1703e0		MOVD R23, R0										
  execution.go:496	0x100211b00		aa1303e1		MOVD R19, R1										
  execution.go:496	0x100211b04		97f9c68f		CALL runtime.panicBounds(SB)								
  execution.go:496	0x100211b08		aa1603e0		MOVD R22, R0										
  execution.go:496	0x100211b0c		aa1303e1		MOVD R19, R1										
  execution.go:496	0x100211b10		97f9c68c		CALL runtime.panicBounds(SB)								
  execution.go:494	0x100211b14		aa1703e0		MOVD R23, R0										
  execution.go:494	0x100211b18		aa1303e1		MOVD R19, R1										
  execution.go:494	0x100211b1c		97f9c689		CALL runtime.panicBounds(SB)								
  execution.go:494	0x100211b20		aa1603e0		MOVD R22, R0										
  execution.go:494	0x100211b24		aa1303e1		MOVD R19, R1										
  execution.go:494	0x100211b28		97f9c686		CALL runtime.panicBounds(SB)								
  execution.go:492	0x100211b2c		aa1703e0		MOVD R23, R0										
  execution.go:492	0x100211b30		aa1303e1		MOVD R19, R1										
  execution.go:492	0x100211b34		97f9c683		CALL runtime.panicBounds(SB)								
  execution.go:492	0x100211b38		aa1603e0		MOVD R22, R0										
  execution.go:492	0x100211b3c		aa1303e1		MOVD R19, R1										
  execution.go:492	0x100211b40		97f9c680		CALL runtime.panicBounds(SB)								
  execution.go:490	0x100211b44		aa1703e0		MOVD R23, R0										
  execution.go:490	0x100211b48		aa1303e1		MOVD R19, R1										
  execution.go:490	0x100211b4c		97f9c67d		CALL runtime.panicBounds(SB)								
  execution.go:490	0x100211b50		aa1603e0		MOVD R22, R0										
  execution.go:490	0x100211b54		aa1303e1		MOVD R19, R1										
  execution.go:490	0x100211b58		97f9c67a		CALL runtime.panicBounds(SB)								
  execution.go:488	0x100211b5c		aa1703e0		MOVD R23, R0										
  execution.go:488	0x100211b60		aa1303e1		MOVD R19, R1										
  execution.go:488	0x100211b64		97f9c677		CALL runtime.panicBounds(SB)								
  execution.go:488	0x100211b68		aa1603e0		MOVD R22, R0										
  execution.go:488	0x100211b6c		aa1303e1		MOVD R19, R1										
  execution.go:488	0x100211b70		97f9c674		CALL runtime.panicBounds(SB)								
  execution.go:486	0x100211b74		aa1703e0		MOVD R23, R0										
  execution.go:486	0x100211b78		aa1303e1		MOVD R19, R1										
  execution.go:486	0x100211b7c		97f9c671		CALL runtime.panicBounds(SB)								
  execution.go:486	0x100211b80		aa1603e0		MOVD R22, R0										
  execution.go:486	0x100211b84		aa1303e1		MOVD R19, R1										
  execution.go:486	0x100211b88		97f9c66e		CALL runtime.panicBounds(SB)								
  execution.go:484	0x100211b8c		aa1703e0		MOVD R23, R0										
  execution.go:484	0x100211b90		aa1303e1		MOVD R19, R1										
  execution.go:484	0x100211b94		97f9c66b		CALL runtime.panicBounds(SB)								
  execution.go:484	0x100211b98		aa1603e0		MOVD R22, R0										
  execution.go:484	0x100211b9c		aa1303e1		MOVD R19, R1										
  execution.go:484	0x100211ba0		97f9c668		CALL runtime.panicBounds(SB)								
  execution.go:482	0x100211ba4		aa1603e0		MOVD R22, R0										
  execution.go:482	0x100211ba8		aa1303e1		MOVD R19, R1										
  execution.go:482	0x100211bac		97f9c665		CALL runtime.panicBounds(SB)								
  execution.go:421	0x100211bb0		97f9c664		CALL runtime.panicBounds(SB)								
  execution.go:412	0x100211bb4		aa1903e0		MOVD R25, R0										
  execution.go:412	0x100211bb8		aa1703e1		MOVD R23, R1										
  execution.go:412	0x100211bbc		97f9c661		CALL runtime.panicBounds(SB)								
  execution.go:409	0x100211bc0		aa1603e0		MOVD R22, R0										
  execution.go:409	0x100211bc4		aa1303e1		MOVD R19, R1										
  execution.go:409	0x100211bc8		97f9c65e		CALL runtime.panicBounds(SB)								
  execution.go:409	0x100211bcc		aa1803e0		MOVD R24, R0										
  execution.go:409	0x100211bd0		aa1703e1		MOVD R23, R1										
  execution.go:409	0x100211bd4		97f9c65b		CALL runtime.panicBounds(SB)								
  execution.go:406	0x100211bd8		aa1603e0		MOVD R22, R0										
  execution.go:406	0x100211bdc		aa1303e1		MOVD R19, R1										
  execution.go:406	0x100211be0		97f9c658		CALL runtime.panicBounds(SB)								
  execution.go:403	0x100211be4		aa1603e0		MOVD R22, R0										
  execution.go:403	0x100211be8		aa1303e1		MOVD R19, R1										
  execution.go:403	0x100211bec		97f9c655		CALL runtime.panicBounds(SB)								
  execution.go:391	0x100211bf0		aa1803e0		MOVD R24, R0										
  execution.go:391	0x100211bf4		aa1603e1		MOVD R22, R1										
  execution.go:391	0x100211bf8		97f9c652		CALL runtime.panicBounds(SB)								
  execution.go:389	0x100211bfc		aa1803e0		MOVD R24, R0										
  execution.go:389	0x100211c00		aa1603e1		MOVD R22, R1										
  execution.go:389	0x100211c04		97f9c64f		CALL runtime.panicBounds(SB)								
  execution.go:385	0x100211c08		aa1803e0		MOVD R24, R0										
  execution.go:385	0x100211c0c		aa1603e1		MOVD R22, R1										
  execution.go:385	0x100211c10		97f9c64c		CALL runtime.panicBounds(SB)								
  execution.go:383	0x100211c14		aa1303e0		MOVD R19, R0										
  execution.go:383	0x100211c18		97f9c64a		CALL runtime.panicBounds(SB)								
  execution.go:379	0x100211c1c		aa1303e0		MOVD R19, R0										
  execution.go:379	0x100211c20		97f9c648		CALL runtime.panicBounds(SB)								
  execution.go:376	0x100211c24		aa1303e0		MOVD R19, R0										
  execution.go:376	0x100211c28		97f9c646		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211c2c		aa1903e0		MOVD R25, R0										
  execution.go:459	0x100211c30		aa1303e1		MOVD R19, R1										
  execution.go:459	0x100211c34		97f9c643		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211c38		aa1403e0		MOVD R20, R0										
  execution.go:459	0x100211c3c		aa1303e1		MOVD R19, R1										
  execution.go:459	0x100211c40		97f9c640		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211c44		aa1603e0		MOVD R22, R0										
  execution.go:459	0x100211c48		aa1403e1		MOVD R20, R1										
  execution.go:459	0x100211c4c		97f9c63d		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211c50		aa1903e0		MOVD R25, R0										
  execution.go:459	0x100211c54		aa1403e1		MOVD R20, R1										
  execution.go:459	0x100211c58		97f9c63a		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211c5c		aa1303e0		MOVD R19, R0										
  execution.go:439	0x100211c60		97f9c638		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211c64		97f9c637		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211c68		aa1a03e0		MOVD R26, R0										
  execution.go:439	0x100211c6c		aa1303e1		MOVD R19, R1										
  execution.go:439	0x100211c70		97f9c634		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211c74		97f9c633		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211c78		aa1903e0		MOVD R25, R0										
  execution.go:435	0x100211c7c		aa1303e1		MOVD R19, R1										
  execution.go:435	0x100211c80		97f9c630		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211c84		97f9c62f		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211c88		aa1803e0		MOVD R24, R0										
  execution.go:435	0x100211c8c		aa1303e1		MOVD R19, R1										
  execution.go:435	0x100211c90		97f9c62c		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211c94		97f9c62b		CALL runtime.panicBounds(SB)								
  execution.go:434	0x100211c98		aa1403e0		MOVD R20, R0										
  execution.go:434	0x100211c9c		aa1903e1		MOVD R25, R1										
  execution.go:434	0x100211ca0		97f9c628		CALL runtime.panicBounds(SB)								
  execution.go:434	0x100211ca4		aa1903e0		MOVD R25, R0										
  execution.go:434	0x100211ca8		aa1803e1		MOVD R24, R1										
  execution.go:434	0x100211cac		97f9c625		CALL runtime.panicBounds(SB)								
  execution.go:364	0x100211cb0		aa1403e0		MOVD R20, R0										
  execution.go:364	0x100211cb4		aa1003e1		MOVD R16, R1										
  execution.go:364	0x100211cb8		97f9c622		CALL runtime.panicBounds(SB)								
  execution.go:361	0x100211cbc		aa1603e0		MOVD R22, R0										
  execution.go:361	0x100211cc0		aa1303e1		MOVD R19, R1										
  execution.go:361	0x100211cc4		97f9c61f		CALL runtime.panicBounds(SB)								
  execution.go:343	0x100211cc8		aa1803e0		MOVD R24, R0										
  execution.go:343	0x100211ccc		aa1603e1		MOVD R22, R1										
  execution.go:343	0x100211cd0		97f9c61c		CALL runtime.panicBounds(SB)								
  execution.go:341	0x100211cd4		aa1403e0		MOVD R20, R0										
  execution.go:341	0x100211cd8		aa1003e1		MOVD R16, R1										
  execution.go:341	0x100211cdc		97f9c619		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100211ce0		aa1403e0		MOVD R20, R0										
  execution.go:337	0x100211ce4		97f9c617		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100211ce8		aa1403e0		MOVD R20, R0										
  execution.go:337	0x100211cec		aa1103e1		MOVD R17, R1										
  execution.go:337	0x100211cf0		97f9c614		CALL runtime.panicBounds(SB)								
  execution.go:797	0x100211cf4		f0001160		ADRP 2289664(PC), R0									
  execution.go:797	0x100211cf8		911e6000		ADD $1944, R0, R0									
  execution.go:797	0x100211cfc		f0000f81		ADRP 2043904(PC), R1									
  execution.go:797	0x100211d00		91298021		ADD $2656, R1, R1									
  execution.go:797	0x100211d04		97f9aaa3		CALL runtime.gopanic(SB)								
  execution.go:797	0x100211d08		d503201f		NOOP											
  execution.go:325	0x100211d0c		a90087e0		STP (R0, R1), 8(RSP)									
  execution.go:325	0x100211d10		aa1e03e3		MOVD R30, R3										
  execution.go:325	0x100211d14		97f9bd73		CALL runtime.morestack_noctxt.abi0(SB)							
  execution.go:325	0x100211d18		a94087e0		LDP 8(RSP), (R0, R1)									
  execution.go:325	0x100211d1c		17fff621		JMP github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB)	
