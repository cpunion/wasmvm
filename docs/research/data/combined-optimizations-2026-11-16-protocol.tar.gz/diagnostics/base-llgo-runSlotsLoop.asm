
artifacts/combined-optimizations-20261116/base-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010002e08c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>:
10002e08c: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10002e090: a90167fa    	stp	x26, x25, [sp, #0x10]
10002e094: a9025ff8    	stp	x24, x23, [sp, #0x20]
10002e098: a90357f6    	stp	x22, x21, [sp, #0x30]
10002e09c: a9044ff4    	stp	x20, x19, [sp, #0x40]
10002e0a0: a9057bfd    	stp	x29, x30, [sp, #0x50]
10002e0a4: 910143fd    	add	x29, sp, #0x50
10002e0a8: d10743ff    	sub	sp, sp, #0x1d0
10002e0ac: f9402408    	ldr	x8, [x0, #0x48]
10002e0b0: f100051f    	cmp	x8, #0x1
10002e0b4: 540100cb    	b.lt	0x1000300cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
10002e0b8: 3940801a    	ldrb	w26, [x0, #0x20]
10002e0bc: aa0003f5    	mov	x21, x0
10002e0c0: aa0103f4    	mov	x20, x1
10002e0c4: b90017fa    	str	w26, [sp, #0x14]
10002e0c8: f94022a9    	ldr	x9, [x21, #0x40]
10002e0cc: 8b081928    	add	x8, x9, x8, lsl #6
10002e0d0: f85c010a    	ldur	x10, [x8, #-0x40]
10002e0d4: 381d011f    	sturb	wzr, [x8, #-0x30]
10002e0d8: f9000fe8    	str	x8, [sp, #0x18]
10002e0dc: f85d8108    	ldur	x8, [x8, #-0x28]
10002e0e0: f94046a2    	ldr	x2, [x21, #0x88]
10002e0e4: f9402550    	ldr	x16, [x10, #0x48]
10002e0e8: f9404e13    	ldr	x19, [x16, #0x98]
10002e0ec: 8b080269    	add	x9, x19, x8
10002e0f0: eb02013f    	cmp	x9, x2
10002e0f4: 5400f848    	b.hi	0x10002fffc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f70>
10002e0f8: eb09011f    	cmp	x8, x9
10002e0fc: 5400f888    	b.hi	0x10003000c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f80>
10002e100: f9400fe9    	ldr	x9, [sp, #0x18]
10002e104: f9405e16    	ldr	x22, [x16, #0xb8]
10002e108: b85c8120    	ldur	w0, [x9, #-0x38]
10002e10c: cb080049    	sub	x9, x2, x8
10002e110: d37ced08    	lsl	x8, x8, #4
10002e114: f100013f    	cmp	x9, #0x0
10002e118: 9a9fc108    	csel	x8, x8, xzr, gt
10002e11c: eb0002df    	cmp	x22, x0
10002e120: 5400f5a9    	b.ls	0x10002ffd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
10002e124: f9403ea9    	ldr	x9, [x21, #0x78]
10002e128: f9405a1c    	ldr	x28, [x16, #0xb0]
10002e12c: 2a0003f8    	mov	w24, w0
10002e130: f90007ea    	str	x10, [sp, #0x8]
10002e134: f940214a    	ldr	x10, [x10, #0x40]
10002e138: 8b080137    	add	x23, x9, x8
10002e13c: a90243ea    	stp	x10, x16, [sp, #0x20]
10002e140: 14000006    	b	0x10002e158 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xcc>
10002e144: 1100071b    	add	w27, w24, #0x1
10002e148: 2a1b03e0    	mov	w0, w27
10002e14c: 2a1b03f8    	mov	w24, w27
10002e150: eb0002df    	cmp	x22, x0
10002e154: 5400f409    	b.ls	0x10002ffd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
10002e158: 8b00179b    	add	x27, x28, x0, lsl #5
10002e15c: 3600021a    	tbz	w26, #0x0, 0x10002e19c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x110>
10002e160: f9404201    	ldr	x1, [x16, #0x80]
10002e164: b9400760    	ldr	w0, [x27, #0x4]
10002e168: eb00003f    	cmp	x1, x0
10002e16c: 5400f369    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e170: 52801c09    	mov	w9, #0xe0               ; =224
10002e174: f9403e08    	ldr	x8, [x16, #0x78]
10002e178: 9ba92019    	umaddl	x25, w0, w9, x8
10002e17c: b9400328    	ldr	w8, [x25]
10002e180: 7100151f    	cmp	w8, #0x5
10002e184: 7a4b1904    	ccmp	w8, #0xb, #0x4, ne
10002e188: f940aaa8    	ldr	x8, [x21, #0x150]
10002e18c: 1a9f07e9    	cset	w9, ne
10002e190: eb090108    	subs	x8, x8, x9
10002e194: 5400e5a3    	b.lo	0x10002fe48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dbc>
10002e198: f900aaa8    	str	x8, [x21, #0x150]
10002e19c: 91000694    	add	x20, x20, #0x1
10002e1a0: f240169f    	tst	x20, #0x3f
10002e1a4: 54000441    	b.ne	0x10002e22c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002e1a8: f940b2a8    	ldr	x8, [x21, #0x160]
10002e1ac: b4000088    	cbz	x8, 0x10002e1bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x130>
10002e1b0: b40002b5    	cbz	x21, 0x10002e204 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
10002e1b4: 88dffd08    	ldar	w8, [x8]
10002e1b8: 34000308    	cbz	w8, 0x10002e218 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x18c>
10002e1bc: f94006a8    	ldr	x8, [x21, #0x8]
10002e1c0: b400f7a8    	cbz	x8, 0x1000300b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
10002e1c4: f9400509    	ldr	x9, [x8, #0x8]
10002e1c8: f9400aa0    	ldr	x0, [x21, #0x10]
10002e1cc: 39405d29    	ldrb	w9, [x9, #0x17]
10002e1d0: 1200112a    	and	w10, w9, #0x1f
10002e1d4: 121b0129    	and	w9, w9, #0x20
10002e1d8: 7100595f    	cmp	w10, #0x16
10002e1dc: 7a401924    	ccmp	w9, #0x0, #0x4, ne
10002e1e0: 54000060    	b.eq	0x10002e1ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x160>
10002e1e4: f81883a0    	stur	x0, [x29, #-0x78]
10002e1e8: d101e3a0    	sub	x0, x29, #0x78
10002e1ec: f9401508    	ldr	x8, [x8, #0x28]
10002e1f0: d63f0100    	blr	x8
10002e1f4: f94017f0    	ldr	x16, [sp, #0x28]
10002e1f8: aa0103e2    	mov	x2, x1
10002e1fc: b5000140    	cbnz	x0, 0x10002e224 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
10002e200: 1400000b    	b	0x10002e22c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002e204: 52800020    	mov	w0, #0x1                ; =1
10002e208: 9407bfbd    	bl	0x10021e0fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10002e20c: f94017f0    	ldr	x16, [sp, #0x28]
10002e210: b50000a0    	cbnz	x0, 0x10002e224 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
10002e214: 14000006    	b	0x10002e22c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002e218: aa1f03e0    	mov	x0, xzr
10002e21c: aa1f03e2    	mov	x2, xzr
10002e220: 14000003    	b	0x10002e22c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002e224: f9400408    	ldr	x8, [x0, #0x8]
10002e228: b500e348    	cbnz	x8, 0x10002fe90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
10002e22c: b9401f68    	ldr	w8, [x27, #0x1c]
10002e230: 340003e8    	cbz	w8, 0x10002e2ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002e234: 360000fa    	tbz	w26, #0x0, 0x10002e250 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
10002e238: b9400369    	ldr	w9, [x27]
10002e23c: 7100813f    	cmp	w9, #0x20
10002e240: 54000360    	b.eq	0x10002e2ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002e244: 7101053f    	cmp	w9, #0x41
10002e248: 54000320    	b.eq	0x10002e2ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002e24c: 14000019    	b	0x10002e2b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002e250: b9400369    	ldr	w9, [x27]
10002e254: 7100813f    	cmp	w9, #0x20
10002e258: 54000060    	b.eq	0x10002e264 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8>
10002e25c: 7101053f    	cmp	w9, #0x41
10002e260: 54000281    	b.ne	0x10002e2b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002e264: 2a3403e8    	mvn	w8, w20
10002e268: f240151f    	tst	x8, #0x3f
10002e26c: 54000200    	b.eq	0x10002e2ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002e270: 7101053f    	cmp	w9, #0x41
10002e274: 540000e1    	b.ne	0x10002e290 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x204>
10002e278: b9400b60    	ldr	w0, [x27, #0x8]
10002e27c: eb00027f    	cmp	x19, x0
10002e280: 5400ea09    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e284: b9401b68    	ldr	w8, [x27, #0x18]
10002e288: 8b0012e9    	add	x9, x23, x0, lsl #4
10002e28c: a9007d28    	stp	x8, xzr, [x9]
10002e290: 11000718    	add	w24, w24, #0x1
10002e294: eb1802df    	cmp	x22, x24
10002e298: 5400e8e9    	b.ls	0x10002ffb4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
10002e29c: 8b18179b    	add	x27, x28, x24, lsl #5
10002e2a0: 91000694    	add	x20, x20, #0x1
10002e2a4: b9401f68    	ldr	w8, [x27, #0x1c]
10002e2a8: 35fffd48    	cbnz	w8, 0x10002e250 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
10002e2ac: b9400369    	ldr	w9, [x27]
10002e2b0: 529fe40a    	mov	w10, #0xff20            ; =65312
10002e2b4: 51038128    	sub	w8, w9, #0xe0
10002e2b8: 72a01fea    	movk	w10, #0xff, lsl #16
10002e2bc: 6b0a011f    	cmp	w8, w10
10002e2c0: 54000482    	b.hs	0x10002e350 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c4>
10002e2c4: 53107d28    	lsr	w8, w9, #16
10002e2c8: 7103ed1f    	cmp	w8, #0xfb
10002e2cc: 54000ea0    	b.eq	0x10002e4a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x414>
10002e2d0: 7103f11f    	cmp	w8, #0xfc
10002e2d4: 540006a0    	b.eq	0x10002e3a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x31c>
10002e2d8: 7103f51f    	cmp	w8, #0xfd
10002e2dc: 54001361    	b.ne	0x10002e548 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4bc>
10002e2e0: b9400f60    	ldr	w0, [x27, #0xc]
10002e2e4: 3100041f    	cmn	w0, #0x1
10002e2e8: 54002100    	b.eq	0x10002e708 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x67c>
10002e2ec: eb00027f    	cmp	x19, x0
10002e2f0: 5400e689    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e2f4: 8b0012e8    	add	x8, x23, x0, lsl #4
10002e2f8: a9402102    	ldp	x2, x8, [x8]
10002e2fc: b9401360    	ldr	w0, [x27, #0x10]
10002e300: 3100041f    	cmn	w0, #0x1
10002e304: 540020c0    	b.eq	0x10002e71c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x690>
10002e308: eb00027f    	cmp	x19, x0
10002e30c: 5400e5a9    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e310: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002e314: 3d801be0    	str	q0, [sp, #0x60]
10002e318: a9461be5    	ldp	x5, x6, [sp, #0x60]
10002e31c: b9401760    	ldr	w0, [x27, #0x14]
10002e320: 3100041f    	cmn	w0, #0x1
10002e324: 54002060    	b.eq	0x10002e730 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6a4>
10002e328: eb00027f    	cmp	x19, x0
10002e32c: 5400e4a9    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e330: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002e334: 3d801fe0    	str	q0, [sp, #0x70]
10002e338: a9472fea    	ldp	x10, x11, [sp, #0x70]
10002e33c: f9404201    	ldr	x1, [x16, #0x80]
10002e340: b9400760    	ldr	w0, [x27, #0x4]
10002e344: eb00003f    	cmp	x1, x0
10002e348: 54002008    	b.hi	0x10002e748 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6bc>
10002e34c: 14000723    	b	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e350: 51011528    	sub	w8, w9, #0x45
10002e354: 7102011f    	cmp	w8, #0x80
10002e358: 54000fc2    	b.hs	0x10002e550 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
10002e35c: 7101fd1f    	cmp	w8, #0x7f
10002e360: 5400bb88    	b.hi	0x10002fad0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a44>
10002e364: d000102c    	adrp	x12, 0x100234000 <dyld_stub_binder+0x100234000>
10002e368: 9137c18c    	add	x12, x12, #0xdf0
10002e36c: 1000008a    	adr	x10, 0x10002e37c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
10002e370: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
10002e374: 8b0b094a    	add	x10, x10, x11, lsl #2
10002e378: d61f0140    	br	x10
10002e37c: b9401360    	ldr	w0, [x27, #0x10]
10002e380: 3100041f    	cmn	w0, #0x1
10002e384: 54003d00    	b.eq	0x10002eb24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa98>
10002e388: eb00027f    	cmp	x19, x0
10002e38c: 5400e2a9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002e390: d37cec08    	lsl	x8, x0, #4
10002e394: f8686ae2    	ldr	x2, [x23, x8]
10002e398: b9400f60    	ldr	w0, [x27, #0xc]
10002e39c: eb00027f    	cmp	x19, x0
10002e3a0: 54003ca8    	b.hi	0x10002eb34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
10002e3a4: 1400070f    	b	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002e3a8: 529ffda8    	mov	w8, #0xffed             ; =65517
10002e3ac: 72bfe068    	movk	w8, #0xff03, lsl #16
10002e3b0: 0b08012d    	add	w13, w9, w8
10002e3b4: 710011bf    	cmp	w13, #0x4
10002e3b8: 54000cc2    	b.hs	0x10002e550 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
10002e3bc: 29430368    	ldp	w8, w0, [x27, #0x18]
10002e3c0: f9406e02    	ldr	x2, [x16, #0xd8]
10002e3c4: 0b00010a    	add	w10, w8, w0
10002e3c8: 1100094a    	add	w10, w10, #0x2
10002e3cc: eb0a005f    	cmp	x2, x10
10002e3d0: 5400e483    	b.lo	0x100030060 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fd4>
10002e3d4: 6b0a011f    	cmp	w8, w10
10002e3d8: 5400e3a8    	b.hi	0x10003004c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fc0>
10002e3dc: cb08004b    	sub	x11, x2, x8
10002e3e0: d37ef50c    	lsl	x12, x8, #2
10002e3e4: f100017f    	cmp	x11, #0x0
10002e3e8: 9a9fc18b    	csel	x11, x12, xzr, gt
10002e3ec: 6b08015f    	cmp	w10, w8
10002e3f0: 5400e280    	b.eq	0x100030040 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
10002e3f4: f940660c    	ldr	x12, [x16, #0xc8]
10002e3f8: 8b0b018c    	add	x12, x12, x11
10002e3fc: b940018b    	ldr	w11, [x12]
10002e400: eb0b027f    	cmp	x19, x11
10002e404: 5400e0e9    	b.ls	0x100030020 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f94>
10002e408: cb080141    	sub	x1, x10, x8
10002e40c: f100043f    	cmp	x1, #0x1
10002e410: 5400e140    	b.eq	0x100030038 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fac>
10002e414: b9400588    	ldr	w8, [x12, #0x4]
10002e418: eb08027f    	cmp	x19, x8
10002e41c: 5400de09    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002e420: d37ced6a    	lsl	x10, x11, #4
10002e424: d37ced08    	lsl	x8, x8, #4
10002e428: 710009bf    	cmp	w13, #0x2
10002e42c: f86a6aef    	ldr	x15, [x23, x10]
10002e430: f8686aee    	ldr	x14, [x23, x8]
10002e434: 54002062    	b.hs	0x10002e840 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7b4>
10002e438: f1000c3f    	cmp	x1, #0x3
10002e43c: 5400e303    	b.lo	0x10003009c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2010>
10002e440: b9400988    	ldr	w8, [x12, #0x8]
10002e444: eb08027f    	cmp	x19, x8
10002e448: 5400dca9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002e44c: f1000c3f    	cmp	x1, #0x3
10002e450: 5400e220    	b.eq	0x100030094 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2008>
10002e454: b9400d8a    	ldr	w10, [x12, #0xc]
10002e458: eb0a027f    	cmp	x19, x10
10002e45c: 5400dca9    	b.ls	0x10002fff0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
10002e460: d37ced08    	lsl	x8, x8, #4
10002e464: d37ced4a    	lsl	x10, x10, #4
10002e468: f8686aeb    	ldr	x11, [x23, x8]
10002e46c: f86a6ae8    	ldr	x8, [x23, x10]
10002e470: 5280026a    	mov	w10, #0x13              ; =19
10002e474: 72a01f8a    	movk	w10, #0xfc, lsl #16
10002e478: 6b0a013f    	cmp	w9, w10
10002e47c: 54002c01    	b.ne	0x10002e9fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x970>
10002e480: 8b0f016a    	add	x10, x11, x15
10002e484: aa0f0169    	orr	x9, x11, x15
10002e488: 8a0f016b    	and	x11, x11, x15
10002e48c: 8a2a0129    	bic	x9, x9, x10
10002e490: 8b0e0108    	add	x8, x8, x14
10002e494: aa0b0129    	orr	x9, x9, x11
10002e498: 8b49fd0b    	add	x11, x8, x9, lsr #63
10002e49c: 1400015f    	b	0x10002ea18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
10002e4a0: 51000928    	sub	w8, w9, #0x2
10002e4a4: 12003d09    	and	w9, w8, #0xffff
10002e4a8: 7100853f    	cmp	w9, #0x21
10002e4ac: d287c1e9    	mov	x9, #0x3e0f             ; =15887
10002e4b0: f2a38009    	movk	x9, #0x1c00, lsl #16
10002e4b4: 1a9f27ea    	cset	w10, lo
10002e4b8: f2c00029    	movk	x9, #0x1, lsl #32
10002e4bc: 9ac82529    	lsr	x9, x9, x8
10002e4c0: 0a090149    	and	w9, w10, w9
10002e4c4: 36001129    	tbz	w9, #0x0, 0x10002e6e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x65c>
10002e4c8: b9400f60    	ldr	w0, [x27, #0xc]
10002e4cc: 3100041f    	cmn	w0, #0x1
10002e4d0: 540020e0    	b.eq	0x10002e8ec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x860>
10002e4d4: eb00027f    	cmp	x19, x0
10002e4d8: 5400d749    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e4dc: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002e4e0: 3d800fe0    	str	q0, [sp, #0x30]
10002e4e4: a94313e3    	ldp	x3, x4, [sp, #0x30]
10002e4e8: b9401360    	ldr	w0, [x27, #0x10]
10002e4ec: 3100041f    	cmn	w0, #0x1
10002e4f0: 54002080    	b.eq	0x10002e900 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
10002e4f4: eb00027f    	cmp	x19, x0
10002e4f8: 5400d649    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e4fc: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002e500: 3d8013e0    	str	q0, [sp, #0x40]
10002e504: a9441be5    	ldp	x5, x6, [sp, #0x40]
10002e508: 12003d08    	and	w8, w8, #0xffff
10002e50c: 7100311f    	cmp	w8, #0xc
10002e510: 54002021    	b.ne	0x10002e914 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
10002e514: b9401b68    	ldr	w8, [x27, #0x18]
10002e518: f9406a01    	ldr	x1, [x16, #0xd0]
10002e51c: 11000900    	add	w0, w8, #0x2
10002e520: eb00003f    	cmp	x1, x0
10002e524: 5400d5a9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e528: f9406608    	ldr	x8, [x16, #0xc8]
10002e52c: b8607900    	ldr	w0, [x8, x0, lsl #2]
10002e530: eb00027f    	cmp	x19, x0
10002e534: 5400d469    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e538: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002e53c: 3d8017e0    	str	q0, [sp, #0x50]
10002e540: a94527e7    	ldp	x7, x9, [sp, #0x50]
10002e544: 140000f6    	b	0x10002e91c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x890>
10002e548: 71039d3f    	cmp	w9, #0xe7
10002e54c: 5400c3e3    	b.lo	0x10002fdc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
10002e550: 51000528    	sub	w8, w9, #0x1
10002e554: 71034d1f    	cmp	w8, #0xd3
10002e558: 540005c8    	b.hi	0x10002e610 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x584>
10002e55c: d000102c    	adrp	x12, 0x100234000 <dyld_stub_binder+0x100234000>
10002e560: 913bc18c    	add	x12, x12, #0xef0
10002e564: aa1f03e0    	mov	x0, xzr
10002e568: 100000aa    	adr	x10, 0x10002e57c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f0>
10002e56c: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
10002e570: 8b0b094a    	add	x10, x10, x11, lsl #2
10002e574: aa1f03e1    	mov	x1, xzr
10002e578: d61f0140    	br	x10
10002e57c: f9404201    	ldr	x1, [x16, #0x80]
10002e580: b9400760    	ldr	w0, [x27, #0x4]
10002e584: eb00003f    	cmp	x1, x0
10002e588: 5400d289    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e58c: 52801c0a    	mov	w10, #0xe0              ; =224
10002e590: f9403e08    	ldr	x8, [x16, #0x78]
10002e594: 9baa200a    	umaddl	x10, w0, w10, x8
10002e598: b400c50a    	cbz	x10, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e59c: f94013e8    	ldr	x8, [sp, #0x20]
10002e5a0: b9401940    	ldr	w0, [x10, #0x18]
10002e5a4: f9403d01    	ldr	x1, [x8, #0x78]
10002e5a8: eb00003f    	cmp	x1, x0
10002e5ac: 5400d169    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e5b0: f9403908    	ldr	x8, [x8, #0x70]
10002e5b4: ab000d08    	adds	x8, x8, x0, lsl #3
10002e5b8: 5400c400    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e5bc: f940010b    	ldr	x11, [x8]
10002e5c0: b400c3cb    	cbz	x11, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e5c4: b9400f68    	ldr	w8, [x27, #0xc]
10002e5c8: eb08027f    	cmp	x19, x8
10002e5cc: 5400d089    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002e5d0: f9400960    	ldr	x0, [x11, #0x10]
10002e5d4: d37ced08    	lsl	x8, x8, #4
10002e5d8: b940154b    	ldr	w11, [x10, #0x14]
10002e5dc: b9401d4a    	ldr	w10, [x10, #0x1c]
10002e5e0: f940200c    	ldr	x12, [x0, #0x40]
10002e5e4: f8686ae2    	ldr	x2, [x23, x8]
10002e5e8: aa0a8163    	orr	x3, x11, x10, lsl #32
10002e5ec: b400006c    	cbz	x12, 0x10002e5f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x56c>
10002e5f0: f9403008    	ldr	x8, [x0, #0x60]
10002e5f4: b4001d28    	cbz	x8, 0x10002e998 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x90c>
10002e5f8: d101e3a8    	sub	x8, x29, #0x78
10002e5fc: 2a0903e1    	mov	w1, w9
10002e600: 2a1f03e4    	mov	w4, wzr
10002e604: aa1f03e5    	mov	x5, xzr
10002e608: aa1f03e6    	mov	x6, xzr
10002e60c: 14000071    	b	0x10002e7d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x744>
10002e610: 517f0128    	sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
10002e614: 7100211f    	cmp	w8, #0x8
10002e618: 54000e22    	b.hs	0x10002e7dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x750>
10002e61c: b9400f60    	ldr	w0, [x27, #0xc]
10002e620: eb00027f    	cmp	x19, x0
10002e624: 5400cde9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002e628: d37cec08    	lsl	x8, x0, #4
10002e62c: 2a0903e0    	mov	w0, w9
10002e630: aa1f03e2    	mov	x2, xzr
10002e634: f8686ae1    	ldr	x1, [x23, x8]
10002e638: 94009825    	bl	0x1000546cc <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10002e63c: aa0103f9    	mov	x25, x1
10002e640: aa1f03e1    	mov	x1, xzr
10002e644: 140000e3    	b	0x10002e9d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
10002e648: f9404201    	ldr	x1, [x16, #0x80]
10002e64c: b9400760    	ldr	w0, [x27, #0x4]
10002e650: eb00003f    	cmp	x1, x0
10002e654: 5400cc29    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e658: 52801c0a    	mov	w10, #0xe0              ; =224
10002e65c: f9403e08    	ldr	x8, [x16, #0x78]
10002e660: 9baa200b    	umaddl	x11, w0, w10, x8
10002e664: b400beab    	cbz	x11, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e668: f94013e8    	ldr	x8, [sp, #0x20]
10002e66c: b9401960    	ldr	w0, [x11, #0x18]
10002e670: f9403d01    	ldr	x1, [x8, #0x78]
10002e674: eb00003f    	cmp	x1, x0
10002e678: 5400cb09    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e67c: f9403908    	ldr	x8, [x8, #0x70]
10002e680: ab000d08    	adds	x8, x8, x0, lsl #3
10002e684: 5400bda0    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e688: f940010c    	ldr	x12, [x8]
10002e68c: b400bd6c    	cbz	x12, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e690: b9400f68    	ldr	w8, [x27, #0xc]
10002e694: eb08027f    	cmp	x19, x8
10002e698: 5400ca29    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002e69c: b940136a    	ldr	w10, [x27, #0x10]
10002e6a0: eb0a027f    	cmp	x19, x10
10002e6a4: 5400ca69    	b.ls	0x10002fff0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
10002e6a8: f9400980    	ldr	x0, [x12, #0x10]
10002e6ac: b940156c    	ldr	w12, [x11, #0x14]
10002e6b0: d37ced08    	lsl	x8, x8, #4
10002e6b4: b9401d6b    	ldr	w11, [x11, #0x1c]
10002e6b8: d37ced4a    	lsl	x10, x10, #4
10002e6bc: f940200d    	ldr	x13, [x0, #0x40]
10002e6c0: f8686ae2    	ldr	x2, [x23, x8]
10002e6c4: aa0b8183    	orr	x3, x12, x11, lsl #32
10002e6c8: f86a6ae5    	ldr	x5, [x23, x10]
10002e6cc: b400006d    	cbz	x13, 0x10002e6d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x64c>
10002e6d0: f9403008    	ldr	x8, [x0, #0x60]
10002e6d4: b4001fa8    	cbz	x8, 0x10002eac8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa3c>
10002e6d8: 2a0903e1    	mov	w1, w9
10002e6dc: 2a1f03e4    	mov	w4, wzr
10002e6e0: aa1f03e6    	mov	x6, xzr
10002e6e4: 1400007c    	b	0x10002e8d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x848>
10002e6e8: f9400fe8    	ldr	x8, [sp, #0x18]
10002e6ec: aa1503e0    	mov	x0, x21
10002e6f0: b81c8118    	stur	w24, [x8, #-0x38]
10002e6f4: 94000701    	bl	0x1000302f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
10002e6f8: f94017f0    	ldr	x16, [sp, #0x28]
10002e6fc: 72001c1f    	tst	w0, #0xff
10002e700: 54001420    	b.eq	0x10002e984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
10002e704: 140005e6    	b	0x10002fe9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
10002e708: aa1f03e8    	mov	x8, xzr
10002e70c: aa1f03e2    	mov	x2, xzr
10002e710: b9401360    	ldr	w0, [x27, #0x10]
10002e714: 3100041f    	cmn	w0, #0x1
10002e718: 54ffdf81    	b.ne	0x10002e308 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x27c>
10002e71c: aa1f03e5    	mov	x5, xzr
10002e720: aa1f03e6    	mov	x6, xzr
10002e724: b9401760    	ldr	w0, [x27, #0x14]
10002e728: 3100041f    	cmn	w0, #0x1
10002e72c: 54ffdfe1    	b.ne	0x10002e328 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x29c>
10002e730: aa1f03ea    	mov	x10, xzr
10002e734: aa1f03eb    	mov	x11, xzr
10002e738: f9404201    	ldr	x1, [x16, #0x80]
10002e73c: b9400760    	ldr	w0, [x27, #0x4]
10002e740: eb00003f    	cmp	x1, x0
10002e744: 5400c4a9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e748: 52801c0d    	mov	w13, #0xe0              ; =224
10002e74c: f9403e0c    	ldr	x12, [x16, #0x78]
10002e750: 9bad3000    	umaddl	x0, w0, w13, x12
10002e754: b400b720    	cbz	x0, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e758: 121e352c    	and	w12, w9, #0xfffc
10002e75c: 12003d2d    	and	w13, w9, #0xffff
10002e760: 7101519f    	cmp	w12, #0x54
10002e764: 7a4b19a0    	ccmp	w13, #0xb, #0x0, ne
10002e768: 54000083    	b.lo	0x10002e778 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6ec>
10002e76c: 510171ae    	sub	w14, w13, #0x5c
10002e770: 710009df    	cmp	w14, #0x2
10002e774: 540007e2    	b.hs	0x10002e870 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7e4>
10002e778: f94013ea    	ldr	x10, [sp, #0x20]
10002e77c: b9401808    	ldr	w8, [x0, #0x18]
10002e780: f9403d41    	ldr	x1, [x10, #0x78]
10002e784: eb08003f    	cmp	x1, x8
10002e788: 5400c309    	b.ls	0x10002ffe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10002e78c: f940394a    	ldr	x10, [x10, #0x70]
10002e790: ab080d48    	adds	x8, x10, x8, lsl #3
10002e794: 5400b520    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e798: f9400108    	ldr	x8, [x8]
10002e79c: b400b4e8    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e7a0: f940090a    	ldr	x10, [x8, #0x10]
10002e7a4: b9401408    	ldr	w8, [x0, #0x14]
10002e7a8: b9401c0b    	ldr	w11, [x0, #0x1c]
10002e7ac: 39410004    	ldrb	w4, [x0, #0x40]
10002e7b0: f940214c    	ldr	x12, [x10, #0x40]
10002e7b4: aa0b8103    	orr	x3, x8, x11, lsl #32
10002e7b8: b400006c    	cbz	x12, 0x10002e7c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x738>
10002e7bc: f9403148    	ldr	x8, [x10, #0x60]
10002e7c0: b4000f88    	cbz	x8, 0x10002e9b0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x924>
10002e7c4: d101e3a8    	sub	x8, x29, #0x78
10002e7c8: aa0a03e0    	mov	x0, x10
10002e7cc: 2a0903e1    	mov	w1, w9
10002e7d0: d101e3ba    	sub	x26, x29, #0x78
10002e7d4: 94007846    	bl	0x10004c8ec <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
10002e7d8: 1400007b    	b	0x10002e9c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x938>
10002e7dc: 12a02008    	mov	w8, #-0x1000001         ; =-16777217
10002e7e0: 0b080128    	add	w8, w9, w8
10002e7e4: 7100211f    	cmp	w8, #0x8
10002e7e8: 54003dc8    	b.hi	0x10002efa0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
10002e7ec: 528022ea    	mov	w10, #0x117             ; =279
10002e7f0: 1ac8254a    	lsr	w10, w10, w8
10002e7f4: 36003cea    	tbz	w10, #0x0, 0x10002ef90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf04>
10002e7f8: 12001d29    	and	w9, w9, #0xff
10002e7fc: 2a1f03e8    	mov	w8, wzr
10002e800: 7100113f    	cmp	w9, #0x4
10002e804: 540016ac    	b.gt	0x10002ead8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
10002e808: 7100093f    	cmp	w9, #0x2
10002e80c: 54001a80    	b.eq	0x10002eb5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xad0>
10002e810: 71000d3f    	cmp	w9, #0x3
10002e814: 540036e1    	b.ne	0x10002eef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
10002e818: b9400f60    	ldr	w0, [x27, #0xc]
10002e81c: eb00027f    	cmp	x19, x0
10002e820: 5400be09    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002e824: d37cec08    	lsl	x8, x0, #4
10002e828: b9401f69    	ldr	w9, [x27, #0x1c]
10002e82c: b8686ae8    	ldr	w8, [x23, x8]
10002e830: 51000529    	sub	w9, w9, #0x1
10002e834: 6b08013f    	cmp	w9, w8
10002e838: 1a883128    	csel	w8, w9, w8, lo
10002e83c: 140001ad    	b	0x10002eef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
10002e840: 9bcf7dcb    	umulh	x11, x14, x15
10002e844: 52800268    	mov	w8, #0x13               ; =19
10002e848: 72a01f88    	movk	w8, #0xfc, lsl #16
10002e84c: 9b0f7dca    	mul	x10, x14, x15
10002e850: 11000908    	add	w8, w8, #0x2
10002e854: 6b08013f    	cmp	w9, w8
10002e858: 54000e01    	b.ne	0x10002ea18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
10002e85c: 8a8ffdc8    	and	x8, x14, x15, asr #63
10002e860: 8a8efde9    	and	x9, x15, x14, asr #63
10002e864: 8b080128    	add	x8, x9, x8
10002e868: cb08016b    	sub	x11, x11, x8
10002e86c: 1400006b    	b	0x10002ea18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
10002e870: 71002dbf    	cmp	w13, #0xb
10002e874: f94013ed    	ldr	x13, [sp, #0x20]
10002e878: 54000060    	b.eq	0x10002e884 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f8>
10002e87c: 7101619f    	cmp	w12, #0x58
10002e880: 54001ca1    	b.ne	0x10002ec14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb88>
10002e884: f9403da1    	ldr	x1, [x13, #0x78]
10002e888: b9401808    	ldr	w8, [x0, #0x18]
10002e88c: eb08003f    	cmp	x1, x8
10002e890: 5400bac9    	b.ls	0x10002ffe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10002e894: f94039aa    	ldr	x10, [x13, #0x70]
10002e898: ab080d48    	adds	x8, x10, x8, lsl #3
10002e89c: 5400ace0    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e8a0: f9400108    	ldr	x8, [x8]
10002e8a4: b400aca8    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e8a8: f9400908    	ldr	x8, [x8, #0x10]
10002e8ac: b940140a    	ldr	w10, [x0, #0x14]
10002e8b0: b9401c0b    	ldr	w11, [x0, #0x1c]
10002e8b4: 39410004    	ldrb	w4, [x0, #0x40]
10002e8b8: f940210c    	ldr	x12, [x8, #0x40]
10002e8bc: aa0b8143    	orr	x3, x10, x11, lsl #32
10002e8c0: b400006c    	cbz	x12, 0x10002e8cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x840>
10002e8c4: f940310a    	ldr	x10, [x8, #0x60]
10002e8c8: b400302a    	cbz	x10, 0x10002eecc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
10002e8cc: aa0803e0    	mov	x0, x8
10002e8d0: 2a0903e1    	mov	w1, w9
10002e8d4: 94006e74    	bl	0x10004a2a4 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
10002e8d8: 2a0003e8    	mov	w8, w0
10002e8dc: aa1f03e0    	mov	x0, xzr
10002e8e0: aa1f03e1    	mov	x1, xzr
10002e8e4: 12001d19    	and	w25, w8, #0xff
10002e8e8: 1400003a    	b	0x10002e9d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
10002e8ec: aa1f03e3    	mov	x3, xzr
10002e8f0: aa1f03e4    	mov	x4, xzr
10002e8f4: b9401360    	ldr	w0, [x27, #0x10]
10002e8f8: 3100041f    	cmn	w0, #0x1
10002e8fc: 54ffdfc1    	b.ne	0x10002e4f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x468>
10002e900: aa1f03e5    	mov	x5, xzr
10002e904: aa1f03e6    	mov	x6, xzr
10002e908: 12003d08    	and	w8, w8, #0xffff
10002e90c: 7100311f    	cmp	w8, #0xc
10002e910: 54ffe020    	b.eq	0x10002e514 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x488>
10002e914: aa1f03e7    	mov	x7, xzr
10002e918: aa1f03e9    	mov	x9, xzr
10002e91c: b400a8f5    	cbz	x21, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e920: f9404201    	ldr	x1, [x16, #0x80]
10002e924: b9400760    	ldr	w0, [x27, #0x4]
10002e928: eb00003f    	cmp	x1, x0
10002e92c: 5400b569    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002e930: 52801c0a    	mov	w10, #0xe0              ; =224
10002e934: f9403e08    	ldr	x8, [x16, #0x78]
10002e938: 9baa2002    	umaddl	x2, w0, w10, x8
10002e93c: b400a7e2    	cbz	x2, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002e940: f94002a0    	ldr	x0, [x21]
10002e944: f94013e1    	ldr	x1, [sp, #0x20]
10002e948: 910203e8    	add	x8, sp, #0x80
10002e94c: f90003e9    	str	x9, [sp]
10002e950: 94002ed0    	bl	0x10003a490 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
10002e954: f9404bf9    	ldr	x25, [sp, #0x90]
10002e958: 3dc023e0    	ldr	q0, [sp, #0x80]
10002e95c: b4000079    	cbz	x25, 0x10002e968 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8dc>
10002e960: f9400728    	ldr	x8, [x25, #0x8]
10002e964: b500aa08    	cbnz	x8, 0x10002fea4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
10002e968: b9400b60    	ldr	w0, [x27, #0x8]
10002e96c: f94017f0    	ldr	x16, [sp, #0x28]
10002e970: 3100041f    	cmn	w0, #0x1
10002e974: 54000080    	b.eq	0x10002e984 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
10002e978: eb00027f    	cmp	x19, x0
10002e97c: 5400b229    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002e980: 3ca07ae0    	str	q0, [x23, x0, lsl #4]
10002e984: 1100071b    	add	w27, w24, #0x1
10002e988: 14000034    	b	0x10002ea58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9cc>
10002e98c: f9400f60    	ldr	x0, [x27, #0x18]
10002e990: aa1f03e1    	mov	x1, xzr
10002e994: 14000012    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002e998: d101e3a8    	sub	x8, x29, #0x78
10002e99c: 2a0903e1    	mov	w1, w9
10002e9a0: 2a1f03e4    	mov	w4, wzr
10002e9a4: aa1f03e5    	mov	x5, xzr
10002e9a8: aa1f03e6    	mov	x6, xzr
10002e9ac: 14000004    	b	0x10002e9bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x930>
10002e9b0: d101e3a8    	sub	x8, x29, #0x78
10002e9b4: aa0a03e0    	mov	x0, x10
10002e9b8: 2a0903e1    	mov	w1, w9
10002e9bc: d101e3ba    	sub	x26, x29, #0x78
10002e9c0: 94007815    	bl	0x10004ca14 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
10002e9c4: a9400740    	ldp	x0, x1, [x26]
10002e9c8: 39404359    	ldrb	w25, [x26, #0x10]
10002e9cc: b94017fa    	ldr	w26, [sp, #0x14]
10002e9d0: f94017f0    	ldr	x16, [sp, #0x28]
10002e9d4: 72001f3f    	tst	w25, #0xff
10002e9d8: 5400a9a1    	b.ne	0x10002ff0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
10002e9dc: b9400b68    	ldr	w8, [x27, #0x8]
10002e9e0: 3100051f    	cmn	w8, #0x1
10002e9e4: 54ffbb00    	b.eq	0x10002e144 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
10002e9e8: eb08027f    	cmp	x19, x8
10002e9ec: 5400aee9    	b.ls	0x10002ffc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
10002e9f0: 8b0812e8    	add	x8, x23, x8, lsl #4
10002e9f4: a9000500    	stp	x0, x1, [x8]
10002e9f8: 17fffdd3    	b	0x10002e144 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
10002e9fc: cb0b01ea    	sub	x10, x15, x11
10002ea00: ca2b01e9    	eon	x9, x15, x11
10002ea04: 8a2f016b    	bic	x11, x11, x15
10002ea08: 8a090149    	and	x9, x10, x9
10002ea0c: aa0b0129    	orr	x9, x9, x11
10002ea10: 8b49fd08    	add	x8, x8, x9, lsr #63
10002ea14: cb0801cb    	sub	x11, x14, x8
10002ea18: eb00003f    	cmp	x1, x0
10002ea1c: 5400ade9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ea20: 11000408    	add	w8, w0, #0x1
10002ea24: eb08003f    	cmp	x1, x8
10002ea28: 5400ae09    	b.ls	0x10002ffe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10002ea2c: b8607989    	ldr	w9, [x12, x0, lsl #2]
10002ea30: eb09027f    	cmp	x19, x9
10002ea34: 5400afc9    	b.ls	0x10003002c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
10002ea38: b8687980    	ldr	w0, [x12, x8, lsl #2]
10002ea3c: 8b0912e8    	add	x8, x23, x9, lsl #4
10002ea40: eb00027f    	cmp	x19, x0
10002ea44: a9007d0a    	stp	x10, xzr, [x8]
10002ea48: 5400acc9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ea4c: 8b0012e8    	add	x8, x23, x0, lsl #4
10002ea50: 1100071b    	add	w27, w24, #0x1
10002ea54: a9007d0b    	stp	x11, xzr, [x8]
10002ea58: f9400fe8    	ldr	x8, [sp, #0x18]
10002ea5c: b81c811b    	stur	w27, [x8, #-0x38]
10002ea60: 17fffdba    	b	0x10002e148 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
10002ea64: b9400f60    	ldr	w0, [x27, #0xc]
10002ea68: eb00027f    	cmp	x19, x0
10002ea6c: 5400aaa9    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002ea70: b9401b68    	ldr	w8, [x27, #0x18]
10002ea74: eb08027f    	cmp	x19, x8
10002ea78: 5400aa89    	b.ls	0x10002ffc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
10002ea7c: 8b0012e9    	add	x9, x23, x0, lsl #4
10002ea80: 3dc00120    	ldr	q0, [x9]
10002ea84: f9400521    	ldr	x1, [x9, #0x8]
10002ea88: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
10002ea8c: 9e660000    	fmov	x0, d0
10002ea90: 17ffffd3    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ea94: b9401760    	ldr	w0, [x27, #0x14]
10002ea98: eb00027f    	cmp	x19, x0
10002ea9c: 5400aa29    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eaa0: d37cec08    	lsl	x8, x0, #4
10002eaa4: 52800209    	mov	w9, #0x10               ; =16
10002eaa8: b8686ae8    	ldr	w8, [x23, x8]
10002eaac: 7100011f    	cmp	w8, #0x0
10002eab0: 52800188    	mov	w8, #0xc                ; =12
10002eab4: 9a880128    	csel	x8, x9, x8, eq
10002eab8: b8686b60    	ldr	w0, [x27, x8]
10002eabc: eb00027f    	cmp	x19, x0
10002eac0: 54001d48    	b.hi	0x10002ee68 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xddc>
10002eac4: 14000547    	b	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eac8: 2a0903e1    	mov	w1, w9
10002eacc: 2a1f03e4    	mov	w4, wzr
10002ead0: aa1f03e6    	mov	x6, xzr
10002ead4: 14000100    	b	0x10002eed4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe48>
10002ead8: 7100253f    	cmp	w9, #0x9
10002eadc: 54002061    	b.ne	0x10002eee8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
10002eae0: b9400f60    	ldr	w0, [x27, #0xc]
10002eae4: eb00027f    	cmp	x19, x0
10002eae8: 5400a7c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eaec: d37cec08    	lsl	x8, x0, #4
10002eaf0: f8686ae8    	ldr	x8, [x23, x8]
10002eaf4: f100011f    	cmp	x8, #0x0
10002eaf8: 1a9f07e8    	cset	w8, ne
10002eafc: 140000fd    	b	0x10002eef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
10002eb00: b9400f60    	ldr	w0, [x27, #0xc]
10002eb04: eb00027f    	cmp	x19, x0
10002eb08: 5400a6c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eb0c: d37cec08    	lsl	x8, x0, #4
10002eb10: aa1f03e1    	mov	x1, xzr
10002eb14: f8686ae8    	ldr	x8, [x23, x8]
10002eb18: f100011f    	cmp	x8, #0x0
10002eb1c: 1a9f17e0    	cset	w0, eq
10002eb20: 17ffffaf    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002eb24: aa1f03e2    	mov	x2, xzr
10002eb28: b9400f60    	ldr	w0, [x27, #0xc]
10002eb2c: eb00027f    	cmp	x19, x0
10002eb30: 5400a589    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eb34: d37cec08    	lsl	x8, x0, #4
10002eb38: 2a0903e0    	mov	w0, w9
10002eb3c: f8686ae1    	ldr	x1, [x23, x8]
10002eb40: 940096e3    	bl	0x1000546cc <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10002eb44: aa0103f9    	mov	x25, x1
10002eb48: f94017f0    	ldr	x16, [sp, #0x28]
10002eb4c: 72001f3f    	tst	w25, #0xff
10002eb50: 54009de1    	b.ne	0x10002ff0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
10002eb54: aa1f03e1    	mov	x1, xzr
10002eb58: 17ffffa1    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002eb5c: b9400f60    	ldr	w0, [x27, #0xc]
10002eb60: eb00027f    	cmp	x19, x0
10002eb64: 5400a3e9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eb68: d37cec08    	lsl	x8, x0, #4
10002eb6c: b8686ae8    	ldr	w8, [x23, x8]
10002eb70: 7100011f    	cmp	w8, #0x0
10002eb74: 1a9f17e8    	cset	w8, eq
10002eb78: 140000de    	b	0x10002eef0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
10002eb7c: b9400f60    	ldr	w0, [x27, #0xc]
10002eb80: eb00027f    	cmp	x19, x0
10002eb84: 5400a2e9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002eb88: d37cec08    	lsl	x8, x0, #4
10002eb8c: 7101a53f    	cmp	w9, #0x69
10002eb90: aa1f03e1    	mov	x1, xzr
10002eb94: f8686ae8    	ldr	x8, [x23, x8]
10002eb98: 2a0803e9    	mov	w9, w8
10002eb9c: 9a880128    	csel	x8, x9, x8, eq
10002eba0: d341fd09    	lsr	x9, x8, #1
10002eba4: 9200f108    	and	x8, x8, #0x5555555555555555
10002eba8: 9200f129    	and	x9, x9, #0x5555555555555555
10002ebac: 8b080128    	add	x8, x9, x8
10002ebb0: d342fd09    	lsr	x9, x8, #2
10002ebb4: 9200e508    	and	x8, x8, #0x3333333333333333
10002ebb8: 9200e529    	and	x9, x9, #0x3333333333333333
10002ebbc: 8b080128    	add	x8, x9, x8
10002ebc0: 8b481108    	add	x8, x8, x8, lsr #4
10002ebc4: 9200cd08    	and	x8, x8, #0xf0f0f0f0f0f0f0f
10002ebc8: 8b482108    	add	x8, x8, x8, lsr #8
10002ebcc: 8b484108    	add	x8, x8, x8, lsr #16
10002ebd0: 8b488108    	add	x8, x8, x8, lsr #32
10002ebd4: 92401900    	and	x0, x8, #0x7f
10002ebd8: 17ffff81    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ebdc: b9400f60    	ldr	w0, [x27, #0xc]
10002ebe0: eb00027f    	cmp	x19, x0
10002ebe4: 54009fe9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ebe8: d37cec08    	lsl	x8, x0, #4
10002ebec: aa1f03e1    	mov	x1, xzr
10002ebf0: b8a86ae0    	ldrsw	x0, [x23, x8]
10002ebf4: 17ffff7a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ebf8: b9400f60    	ldr	w0, [x27, #0xc]
10002ebfc: eb00027f    	cmp	x19, x0
10002ec00: 54009f09    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ec04: d37cec08    	lsl	x8, x0, #4
10002ec08: aa1f03e1    	mov	x1, xzr
10002ec0c: b8686ae0    	ldr	w0, [x23, x8]
10002ec10: 17ffff73    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ec14: aa0203e1    	mov	x1, x2
10002ec18: aa0803e2    	mov	x2, x8
10002ec1c: aa0503e3    	mov	x3, x5
10002ec20: aa0603e4    	mov	x4, x6
10002ec24: aa0a03e5    	mov	x5, x10
10002ec28: aa0b03e6    	mov	x6, x11
10002ec2c: 94008fdf    	bl	0x100052ba8 <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
10002ec30: f94017f0    	ldr	x16, [sp, #0x28]
10002ec34: 17ffff6a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ec38: b9400f60    	ldr	w0, [x27, #0xc]
10002ec3c: eb00027f    	cmp	x19, x0
10002ec40: 54009d09    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ec44: b9401368    	ldr	w8, [x27, #0x10]
10002ec48: eb08027f    	cmp	x19, x8
10002ec4c: 540061e8    	b.hi	0x10002f888 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x17fc>
10002ec50: 140004e3    	b	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002ec54: f94013e8    	ldr	x8, [sp, #0x20]
10002ec58: b9401b60    	ldr	w0, [x27, #0x18]
10002ec5c: f9403d01    	ldr	x1, [x8, #0x78]
10002ec60: eb00003f    	cmp	x1, x0
10002ec64: 54009ba9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ec68: f9403908    	ldr	x8, [x8, #0x70]
10002ec6c: ab000d08    	adds	x8, x8, x0, lsl #3
10002ec70: 54008e40    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ec74: b4008e35    	cbz	x21, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ec78: f9400119    	ldr	x25, [x8]
10002ec7c: b4008df9    	cbz	x25, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ec80: f9400b29    	ldr	x9, [x25, #0x10]
10002ec84: b9400f68    	ldr	w8, [x27, #0xc]
10002ec88: f94002a0    	ldr	x0, [x21]
10002ec8c: 3940c529    	ldrb	w9, [x9, #0x31]
10002ec90: eb08027f    	cmp	x19, x8
10002ec94: 3902bbe9    	strb	w9, [sp, #0xae]
10002ec98: 54009a29    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002ec9c: d37ced08    	lsl	x8, x8, #4
10002eca0: 3942bbe9    	ldrb	w9, [sp, #0xae]
10002eca4: aa1903e1    	mov	x1, x25
10002eca8: f8686ae8    	ldr	x8, [x23, x8]
10002ecac: 7100013f    	cmp	w9, #0x0
10002ecb0: 2a0803ea    	mov	w10, w8
10002ecb4: 9a8a1102    	csel	x2, x8, x10, ne
10002ecb8: 94006079    	bl	0x100046e9c <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
10002ecbc: 36007ba1    	tbz	w1, #0x0, 0x10002fc30 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ba4>
10002ecc0: f94017f0    	ldr	x16, [sp, #0x28]
10002ecc4: aa1f03e1    	mov	x1, xzr
10002ecc8: 17ffff45    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002eccc: f94013e8    	ldr	x8, [sp, #0x20]
10002ecd0: b9401b60    	ldr	w0, [x27, #0x18]
10002ecd4: f9403101    	ldr	x1, [x8, #0x60]
10002ecd8: eb00003f    	cmp	x1, x0
10002ecdc: 540097e9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ece0: f9402d08    	ldr	x8, [x8, #0x58]
10002ece4: ab000d08    	adds	x8, x8, x0, lsl #3
10002ece8: 54008a80    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ecec: f9400108    	ldr	x8, [x8]
10002ecf0: b4008a48    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ecf4: b9400f60    	ldr	w0, [x27, #0xc]
10002ecf8: eb00027f    	cmp	x19, x0
10002ecfc: 54009729    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ed00: d37cec09    	lsl	x9, x0, #4
10002ed04: 3940a50a    	ldrb	w10, [x8, #0x29]
10002ed08: f8696ae9    	ldr	x9, [x23, x9]
10002ed0c: 7100015f    	cmp	w10, #0x0
10002ed10: f940210a    	ldr	x10, [x8, #0x40]
10002ed14: 2a0903eb    	mov	w11, w9
10002ed18: 9a8b1129    	csel	x9, x9, x11, ne
10002ed1c: eb0a013f    	cmp	x9, x10
10002ed20: 54008ec2    	b.hs	0x10002fef8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
10002ed24: f9401d08    	ldr	x8, [x8, #0x38]
10002ed28: aa1f03e1    	mov	x1, xzr
10002ed2c: f8697900    	ldr	x0, [x8, x9, lsl #3]
10002ed30: 17ffff2b    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ed34: f94013e8    	ldr	x8, [sp, #0x20]
10002ed38: b9401b60    	ldr	w0, [x27, #0x18]
10002ed3c: f9402501    	ldr	x1, [x8, #0x48]
10002ed40: eb00003f    	cmp	x1, x0
10002ed44: 540094a9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ed48: f9402108    	ldr	x8, [x8, #0x40]
10002ed4c: aa1f03e1    	mov	x1, xzr
10002ed50: f8607900    	ldr	x0, [x8, x0, lsl #3]
10002ed54: 17ffff22    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ed58: b9400f60    	ldr	w0, [x27, #0xc]
10002ed5c: eb00027f    	cmp	x19, x0
10002ed60: 54009409    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ed64: 8b0012e8    	add	x8, x23, x0, lsl #4
10002ed68: f9400100    	ldr	x0, [x8]
10002ed6c: b4008ce0    	cbz	x0, 0x10002ff08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e7c>
10002ed70: f9400501    	ldr	x1, [x8, #0x8]
10002ed74: 17ffff1a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ed78: f94013e8    	ldr	x8, [sp, #0x20]
10002ed7c: f9404901    	ldr	x1, [x8, #0x90]
10002ed80: b9401b68    	ldr	w8, [x27, #0x18]
10002ed84: eb08003f    	cmp	x1, x8
10002ed88: 54009309    	b.ls	0x10002ffe8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10002ed8c: b9400f69    	ldr	w9, [x27, #0xc]
10002ed90: eb09027f    	cmp	x19, x9
10002ed94: 540098a9    	b.ls	0x1000300a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x201c>
10002ed98: f94013ea    	ldr	x10, [sp, #0x20]
10002ed9c: 3ce97ae0    	ldr	q0, [x23, x9, lsl #4]
10002eda0: aa1f03e0    	mov	x0, xzr
10002eda4: aa1f03e1    	mov	x1, xzr
10002eda8: f940454a    	ldr	x10, [x10, #0x88]
10002edac: f8687948    	ldr	x8, [x10, x8, lsl #3]
10002edb0: 3d800900    	str	q0, [x8, #0x20]
10002edb4: 17ffff0a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002edb8: f94013e8    	ldr	x8, [sp, #0x20]
10002edbc: b9401b60    	ldr	w0, [x27, #0x18]
10002edc0: f9404901    	ldr	x1, [x8, #0x90]
10002edc4: eb00003f    	cmp	x1, x0
10002edc8: 54009089    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002edcc: f9404508    	ldr	x8, [x8, #0x88]
10002edd0: f8607908    	ldr	x8, [x8, x0, lsl #3]
10002edd4: a9420500    	ldp	x0, x1, [x8, #0x20]
10002edd8: 17ffff01    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002eddc: f94013e8    	ldr	x8, [sp, #0x20]
10002ede0: b9401b60    	ldr	w0, [x27, #0x18]
10002ede4: f9403101    	ldr	x1, [x8, #0x60]
10002ede8: eb00003f    	cmp	x1, x0
10002edec: 54008f69    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002edf0: f9402d08    	ldr	x8, [x8, #0x58]
10002edf4: ab000d08    	adds	x8, x8, x0, lsl #3
10002edf8: 54008200    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002edfc: f9400109    	ldr	x9, [x8]
10002ee00: b40081c9    	cbz	x9, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ee04: b9400f60    	ldr	w0, [x27, #0xc]
10002ee08: eb00027f    	cmp	x19, x0
10002ee0c: 54008ea9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002ee10: d37cec08    	lsl	x8, x0, #4
10002ee14: 3940a52a    	ldrb	w10, [x9, #0x29]
10002ee18: f940212c    	ldr	x12, [x9, #0x40]
10002ee1c: f8686ae8    	ldr	x8, [x23, x8]
10002ee20: 7100015f    	cmp	w10, #0x0
10002ee24: 2a0803eb    	mov	w11, w8
10002ee28: 9a8b110a    	csel	x10, x8, x11, ne
10002ee2c: eb0c015f    	cmp	x10, x12
10002ee30: 54008642    	b.hs	0x10002fef8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
10002ee34: b9401368    	ldr	w8, [x27, #0x10]
10002ee38: eb08027f    	cmp	x19, x8
10002ee3c: 54008d09    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002ee40: d37ced08    	lsl	x8, x8, #4
10002ee44: f9401d29    	ldr	x9, [x9, #0x38]
10002ee48: aa1f03e0    	mov	x0, xzr
10002ee4c: aa1f03e1    	mov	x1, xzr
10002ee50: f8686ae8    	ldr	x8, [x23, x8]
10002ee54: f82a7928    	str	x8, [x9, x10, lsl #3]
10002ee58: 17fffee1    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ee5c: b9401b60    	ldr	w0, [x27, #0x18]
10002ee60: eb00027f    	cmp	x19, x0
10002ee64: 54008ae9    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002ee68: 8b0012e8    	add	x8, x23, x0, lsl #4
10002ee6c: a9400500    	ldp	x0, x1, [x8]
10002ee70: 17fffedb    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002ee74: f94013e8    	ldr	x8, [sp, #0x20]
10002ee78: b9401b60    	ldr	w0, [x27, #0x18]
10002ee7c: f9403d01    	ldr	x1, [x8, #0x78]
10002ee80: eb00003f    	cmp	x1, x0
10002ee84: 54008aa9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ee88: f9403908    	ldr	x8, [x8, #0x70]
10002ee8c: ab000d08    	adds	x8, x8, x0, lsl #3
10002ee90: 54007d40    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ee94: f9400108    	ldr	x8, [x8]
10002ee98: b4007d08    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ee9c: f9400900    	ldr	x0, [x8, #0x10]
10002eea0: f9402009    	ldr	x9, [x0, #0x40]
10002eea4: f9403008    	ldr	x8, [x0, #0x60]
10002eea8: b4006d69    	cbz	x9, 0x10002fc54 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
10002eeac: b5006d68    	cbnz	x8, 0x10002fc58 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bcc>
10002eeb0: 94006b25    	bl	0x100049b44 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).pagesLocked>
10002eeb4: f94017f0    	ldr	x16, [sp, #0x28]
10002eeb8: aa1f03e1    	mov	x1, xzr
10002eebc: 17fffec8    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002eec0: b9401b60    	ldr	w0, [x27, #0x18]
10002eec4: aa1f03e1    	mov	x1, xzr
10002eec8: 17fffec5    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002eecc: aa0803e0    	mov	x0, x8
10002eed0: 2a0903e1    	mov	w1, w9
10002eed4: 94006d86    	bl	0x10004a4ec <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
10002eed8: 2a0003f9    	mov	w25, w0
10002eedc: aa1f03e0    	mov	x0, xzr
10002eee0: aa1f03e1    	mov	x1, xzr
10002eee4: 17fffebb    	b	0x10002e9d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
10002eee8: 7100153f    	cmp	w9, #0x5
10002eeec: 540080a0    	b.eq	0x10002ff00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e74>
10002eef0: b9401b69    	ldr	w9, [x27, #0x18]
10002eef4: f9407601    	ldr	x1, [x16, #0xe8]
10002eef8: 0b080120    	add	w0, w9, w8
10002eefc: eb00003f    	cmp	x1, x0
10002ef00: 540086c9    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ef04: f9407208    	ldr	x8, [x16, #0xe0]
10002ef08: 52800189    	mov	w9, #0xc                ; =12
10002ef0c: 9ba92008    	umaddl	x8, w0, w9, x8
10002ef10: 2940651b    	ldp	w27, w25, [x8]
10002ef14: b940091a    	ldr	w26, [x8, #0x8]
10002ef18: 6b18037f    	cmp	w27, w24
10002ef1c: 54006ba8    	b.hi	0x10002fc90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
10002ef20: f940b2a8    	ldr	x8, [x21, #0x160]
10002ef24: b4000088    	cbz	x8, 0x10002ef34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea8>
10002ef28: b40002b5    	cbz	x21, 0x10002ef7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xef0>
10002ef2c: 88dffd08    	ldar	w8, [x8]
10002ef30: 34006a68    	cbz	w8, 0x10002fc7c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bf0>
10002ef34: f94006a8    	ldr	x8, [x21, #0x8]
10002ef38: b4008be8    	cbz	x8, 0x1000300b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
10002ef3c: f9400509    	ldr	x9, [x8, #0x8]
10002ef40: f9400aa0    	ldr	x0, [x21, #0x10]
10002ef44: 39405d29    	ldrb	w9, [x9, #0x17]
10002ef48: 1200112a    	and	w10, w9, #0x1f
10002ef4c: 121b0129    	and	w9, w9, #0x20
10002ef50: 7100595f    	cmp	w10, #0x16
10002ef54: 7a401924    	ccmp	w9, #0x0, #0x4, ne
10002ef58: 54000060    	b.eq	0x10002ef64 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xed8>
10002ef5c: f81883a0    	stur	x0, [x29, #-0x78]
10002ef60: d101e3a0    	sub	x0, x29, #0x78
10002ef64: f9401508    	ldr	x8, [x8, #0x28]
10002ef68: d63f0100    	blr	x8
10002ef6c: f94017f0    	ldr	x16, [sp, #0x28]
10002ef70: aa0103e2    	mov	x2, x1
10002ef74: b50068a0    	cbnz	x0, 0x10002fc88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
10002ef78: 14000346    	b	0x10002fc90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
10002ef7c: 52800020    	mov	w0, #0x1                ; =1
10002ef80: 9407bc5f    	bl	0x10021e0fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10002ef84: f94017f0    	ldr	x16, [sp, #0x28]
10002ef88: b5006800    	cbnz	x0, 0x10002fc88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
10002ef8c: 14000341    	b	0x10002fc90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
10002ef90: 71000d1f    	cmp	w8, #0x3
10002ef94: 54007420    	b.eq	0x10002fe18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8c>
10002ef98: 7100191f    	cmp	w8, #0x6
10002ef9c: 54007160    	b.eq	0x10002fdc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
10002efa0: 51004928    	sub	w8, w9, #0x12
10002efa4: 7100111f    	cmp	w8, #0x4
10002efa8: 54007243    	b.lo	0x10002fdf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d64>
10002efac: b9400f60    	ldr	w0, [x27, #0xc]
10002efb0: 3100041f    	cmn	w0, #0x1
10002efb4: 54005b20    	b.eq	0x10002fb18 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a8c>
10002efb8: eb00027f    	cmp	x19, x0
10002efbc: 54008129    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002efc0: d37cec08    	lsl	x8, x0, #4
10002efc4: f8686ae5    	ldr	x5, [x23, x8]
10002efc8: b9401360    	ldr	w0, [x27, #0x10]
10002efcc: 3100041f    	cmn	w0, #0x1
10002efd0: 54005ac0    	b.eq	0x10002fb28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a9c>
10002efd4: eb00027f    	cmp	x19, x0
10002efd8: 54008049    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002efdc: d37cec08    	lsl	x8, x0, #4
10002efe0: f8686ae7    	ldr	x7, [x23, x8]
10002efe4: b9401760    	ldr	w0, [x27, #0x14]
10002efe8: 3100041f    	cmn	w0, #0x1
10002efec: 54005a60    	b.eq	0x10002fb38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aac>
10002eff0: eb00027f    	cmp	x19, x0
10002eff4: 54007e69    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002eff8: d37cec08    	lsl	x8, x0, #4
10002effc: f8686aea    	ldr	x10, [x23, x8]
10002f000: 12103d28    	and	w8, w9, #0xffff0000
10002f004: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
10002f008: 54005a01    	b.ne	0x10002fb48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1abc>
10002f00c: 12003d24    	and	w4, w9, #0xffff
10002f010: 71000c9f    	cmp	w4, #0x3
10002f014: 540067a1    	b.ne	0x10002fd08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c7c>
10002f018: b4007115    	cbz	x21, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002f01c: f94002a8    	ldr	x8, [x21]
10002f020: b40070c8    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002f024: f9400500    	ldr	x0, [x8, #0x8]
10002f028: 9400684c    	bl	0x100049158 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
10002f02c: f94017f0    	ldr	x16, [sp, #0x28]
10002f030: aa1f03e0    	mov	x0, xzr
10002f034: aa1f03e1    	mov	x1, xzr
10002f038: 17fffe69    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f03c: b9400f60    	ldr	w0, [x27, #0xc]
10002f040: eb00027f    	cmp	x19, x0
10002f044: 54007ce9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f048: b9401368    	ldr	w8, [x27, #0x10]
10002f04c: eb08027f    	cmp	x19, x8
10002f050: 54007c69    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f054: d37cec09    	lsl	x9, x0, #4
10002f058: d37ced08    	lsl	x8, x8, #4
10002f05c: aa1f03e1    	mov	x1, xzr
10002f060: f8696ae9    	ldr	x9, [x23, x9]
10002f064: f8686ae8    	ldr	x8, [x23, x8]
10002f068: ca090100    	eor	x0, x8, x9
10002f06c: 17fffe5c    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f070: b9400f60    	ldr	w0, [x27, #0xc]
10002f074: eb00027f    	cmp	x19, x0
10002f078: 54007b49    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f07c: b9401368    	ldr	w8, [x27, #0x10]
10002f080: eb08027f    	cmp	x19, x8
10002f084: 54007ac9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f088: d37cec09    	lsl	x9, x0, #4
10002f08c: d37ced08    	lsl	x8, x8, #4
10002f090: aa1f03e1    	mov	x1, xzr
10002f094: f8696ae9    	ldr	x9, [x23, x9]
10002f098: f8686ae8    	ldr	x8, [x23, x8]
10002f09c: 9ac82520    	lsr	x0, x9, x8
10002f0a0: 17fffe4f    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f0a4: b9400f60    	ldr	w0, [x27, #0xc]
10002f0a8: eb00027f    	cmp	x19, x0
10002f0ac: 540079a9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f0b0: b9401368    	ldr	w8, [x27, #0x10]
10002f0b4: eb08027f    	cmp	x19, x8
10002f0b8: 54007929    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f0bc: d37cec09    	lsl	x9, x0, #4
10002f0c0: d37ced08    	lsl	x8, x8, #4
10002f0c4: aa1f03e1    	mov	x1, xzr
10002f0c8: b8696ae9    	ldr	w9, [x23, x9]
10002f0cc: b8686ae8    	ldr	w8, [x23, x8]
10002f0d0: 1ac82920    	asr	w0, w9, w8
10002f0d4: 17fffe42    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f0d8: b9400f60    	ldr	w0, [x27, #0xc]
10002f0dc: eb00027f    	cmp	x19, x0
10002f0e0: 54007809    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f0e4: b9401368    	ldr	w8, [x27, #0x10]
10002f0e8: eb08027f    	cmp	x19, x8
10002f0ec: 54007789    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f0f0: d37cec09    	lsl	x9, x0, #4
10002f0f4: d37ced08    	lsl	x8, x8, #4
10002f0f8: aa1f03e1    	mov	x1, xzr
10002f0fc: f8696ae9    	ldr	x9, [x23, x9]
10002f100: f8686ae8    	ldr	x8, [x23, x8]
10002f104: aa090100    	orr	x0, x8, x9
10002f108: 17fffe35    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f10c: b9400f60    	ldr	w0, [x27, #0xc]
10002f110: eb00027f    	cmp	x19, x0
10002f114: 54007669    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f118: b9401368    	ldr	w8, [x27, #0x10]
10002f11c: eb08027f    	cmp	x19, x8
10002f120: 540075e9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f124: d37cec09    	lsl	x9, x0, #4
10002f128: d37ced08    	lsl	x8, x8, #4
10002f12c: aa1f03e1    	mov	x1, xzr
10002f130: b8696ae9    	ldr	w9, [x23, x9]
10002f134: b8686ae8    	ldr	w8, [x23, x8]
10002f138: 1ac82120    	lsl	w0, w9, w8
10002f13c: 17fffe28    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f140: b9400f60    	ldr	w0, [x27, #0xc]
10002f144: eb00027f    	cmp	x19, x0
10002f148: 540074c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f14c: b9401368    	ldr	w8, [x27, #0x10]
10002f150: eb08027f    	cmp	x19, x8
10002f154: 54007449    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f158: d37cec09    	lsl	x9, x0, #4
10002f15c: d37ced08    	lsl	x8, x8, #4
10002f160: aa1f03e1    	mov	x1, xzr
10002f164: b8696ae9    	ldr	w9, [x23, x9]
10002f168: b8686ae8    	ldr	w8, [x23, x8]
10002f16c: 2a090100    	orr	w0, w8, w9
10002f170: 17fffe1b    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f174: b9400f60    	ldr	w0, [x27, #0xc]
10002f178: eb00027f    	cmp	x19, x0
10002f17c: 54007329    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f180: d37cec08    	lsl	x8, x0, #4
10002f184: aa1f03e1    	mov	x1, xzr
10002f188: f8686ae8    	ldr	x8, [x23, x8]
10002f18c: dac00108    	rbit	x8, x8
10002f190: dac01100    	clz	x0, x8
10002f194: 17fffe12    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f198: b9400f60    	ldr	w0, [x27, #0xc]
10002f19c: eb00027f    	cmp	x19, x0
10002f1a0: 54007209    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f1a4: b9401368    	ldr	w8, [x27, #0x10]
10002f1a8: eb08027f    	cmp	x19, x8
10002f1ac: 54007189    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f1b0: d37cec09    	lsl	x9, x0, #4
10002f1b4: d37ced08    	lsl	x8, x8, #4
10002f1b8: aa1f03e1    	mov	x1, xzr
10002f1bc: f8696ae9    	ldr	x9, [x23, x9]
10002f1c0: f8686ae8    	ldr	x8, [x23, x8]
10002f1c4: eb08013f    	cmp	x9, x8
10002f1c8: 1a9f27e0    	cset	w0, lo
10002f1cc: 17fffe04    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f1d0: b9400f60    	ldr	w0, [x27, #0xc]
10002f1d4: eb00027f    	cmp	x19, x0
10002f1d8: 54007049    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f1dc: b9401368    	ldr	w8, [x27, #0x10]
10002f1e0: eb08027f    	cmp	x19, x8
10002f1e4: 54006fc9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f1e8: d37cec09    	lsl	x9, x0, #4
10002f1ec: d37ced08    	lsl	x8, x8, #4
10002f1f0: aa1f03e1    	mov	x1, xzr
10002f1f4: f8696ae9    	ldr	x9, [x23, x9]
10002f1f8: f8686ae8    	ldr	x8, [x23, x8]
10002f1fc: eb08013f    	cmp	x9, x8
10002f200: 1a9f87e0    	cset	w0, ls
10002f204: 17fffdf6    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f208: b9400f60    	ldr	w0, [x27, #0xc]
10002f20c: eb00027f    	cmp	x19, x0
10002f210: 54006e89    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f214: b9401368    	ldr	w8, [x27, #0x10]
10002f218: eb08027f    	cmp	x19, x8
10002f21c: 54006e09    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f220: d37cec09    	lsl	x9, x0, #4
10002f224: d37ced08    	lsl	x8, x8, #4
10002f228: aa1f03e1    	mov	x1, xzr
10002f22c: f8696ae9    	ldr	x9, [x23, x9]
10002f230: f8686ae8    	ldr	x8, [x23, x8]
10002f234: eb08013f    	cmp	x9, x8
10002f238: 1a9f97e0    	cset	w0, hi
10002f23c: 17fffde8    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f240: b9400f60    	ldr	w0, [x27, #0xc]
10002f244: eb00027f    	cmp	x19, x0
10002f248: 54006cc9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f24c: b9401368    	ldr	w8, [x27, #0x10]
10002f250: eb08027f    	cmp	x19, x8
10002f254: 54006c49    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f258: d37cec09    	lsl	x9, x0, #4
10002f25c: d37ced08    	lsl	x8, x8, #4
10002f260: aa1f03e1    	mov	x1, xzr
10002f264: b8696ae9    	ldr	w9, [x23, x9]
10002f268: b8686ae8    	ldr	w8, [x23, x8]
10002f26c: 4b080120    	sub	w0, w9, w8
10002f270: 17fffddb    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f274: b9400f60    	ldr	w0, [x27, #0xc]
10002f278: eb00027f    	cmp	x19, x0
10002f27c: 54006b29    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f280: d37cec08    	lsl	x8, x0, #4
10002f284: 5280040b    	mov	w11, #0x20              ; =32
10002f288: 5280030c    	mov	w12, #0x18              ; =24
10002f28c: aa1f03e1    	mov	x1, xzr
10002f290: b8686ae8    	ldr	w8, [x23, x8]
10002f294: 53107d09    	lsr	w9, w8, #16
10002f298: 7100013f    	cmp	w9, #0x0
10002f29c: 1a881128    	csel	w8, w9, w8, ne
10002f2a0: 928001e9    	mov	x9, #-0x10              ; =-16
10002f2a4: 53087d0a    	lsr	w10, w8, #8
10002f2a8: 9a9f1129    	csel	x9, x9, xzr, ne
10002f2ac: 7103fd1f    	cmp	w8, #0xff
10002f2b0: 1a888148    	csel	w8, w10, w8, hi
10002f2b4: d000148a    	adrp	x10, 0x1002c1000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xec8>
10002f2b8: 9123354a    	add	x10, x10, #0x8cd
10002f2bc: 92401d08    	and	x8, x8, #0xff
10002f2c0: 38686948    	ldrb	w8, [x10, x8]
10002f2c4: 9a8b818a    	csel	x10, x12, x11, hi
10002f2c8: 8b090149    	add	x9, x10, x9
10002f2cc: cb080120    	sub	x0, x9, x8
10002f2d0: 17fffdc3    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f2d4: b9400f60    	ldr	w0, [x27, #0xc]
10002f2d8: eb00027f    	cmp	x19, x0
10002f2dc: 54006829    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f2e0: b9401368    	ldr	w8, [x27, #0x10]
10002f2e4: eb08027f    	cmp	x19, x8
10002f2e8: 540067a9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f2ec: d37cec09    	lsl	x9, x0, #4
10002f2f0: d37ced08    	lsl	x8, x8, #4
10002f2f4: aa1f03e1    	mov	x1, xzr
10002f2f8: b8696ae9    	ldr	w9, [x23, x9]
10002f2fc: b8686ae8    	ldr	w8, [x23, x8]
10002f300: 1ac82520    	lsr	w0, w9, w8
10002f304: 17fffdb6    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f308: b9400f60    	ldr	w0, [x27, #0xc]
10002f30c: eb00027f    	cmp	x19, x0
10002f310: 54006689    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f314: b9401368    	ldr	w8, [x27, #0x10]
10002f318: eb08027f    	cmp	x19, x8
10002f31c: 54006609    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f320: d37cec09    	lsl	x9, x0, #4
10002f324: d37ced08    	lsl	x8, x8, #4
10002f328: aa1f03e1    	mov	x1, xzr
10002f32c: f8696ae9    	ldr	x9, [x23, x9]
10002f330: f8686ae8    	ldr	x8, [x23, x8]
10002f334: eb08013f    	cmp	x9, x8
10002f338: 1a9fd7e0    	cset	w0, gt
10002f33c: 17fffda8    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f340: b9400f60    	ldr	w0, [x27, #0xc]
10002f344: eb00027f    	cmp	x19, x0
10002f348: 540064c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f34c: b9401368    	ldr	w8, [x27, #0x10]
10002f350: eb08027f    	cmp	x19, x8
10002f354: 54006449    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f358: d37cec09    	lsl	x9, x0, #4
10002f35c: d37ced08    	lsl	x8, x8, #4
10002f360: aa1f03e1    	mov	x1, xzr
10002f364: b8696ae9    	ldr	w9, [x23, x9]
10002f368: b8686ae8    	ldr	w8, [x23, x8]
10002f36c: 6b08013f    	cmp	w9, w8
10002f370: 1a9fa7e0    	cset	w0, lt
10002f374: 17fffd9a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f378: b9400f60    	ldr	w0, [x27, #0xc]
10002f37c: eb00027f    	cmp	x19, x0
10002f380: 54006309    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f384: b9401368    	ldr	w8, [x27, #0x10]
10002f388: eb08027f    	cmp	x19, x8
10002f38c: 54006289    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f390: d37cec09    	lsl	x9, x0, #4
10002f394: d37ced08    	lsl	x8, x8, #4
10002f398: aa1f03e1    	mov	x1, xzr
10002f39c: f8696ae9    	ldr	x9, [x23, x9]
10002f3a0: f8686ae8    	ldr	x8, [x23, x8]
10002f3a4: eb08013f    	cmp	x9, x8
10002f3a8: 1a9f07e0    	cset	w0, ne
10002f3ac: 17fffd8c    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f3b0: b9400f60    	ldr	w0, [x27, #0xc]
10002f3b4: eb00027f    	cmp	x19, x0
10002f3b8: 54006149    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f3bc: d37cec08    	lsl	x8, x0, #4
10002f3c0: b8686ae8    	ldr	w8, [x23, x8]
10002f3c4: 34004ea8    	cbz	w8, 0x10002fd98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d0c>
10002f3c8: 5ac00108    	rbit	w8, w8
10002f3cc: aa1f03e1    	mov	x1, xzr
10002f3d0: 5ac01100    	clz	w0, w8
10002f3d4: 17fffd82    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f3d8: b9400f60    	ldr	w0, [x27, #0xc]
10002f3dc: eb00027f    	cmp	x19, x0
10002f3e0: 54006009    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f3e4: b9401368    	ldr	w8, [x27, #0x10]
10002f3e8: eb08027f    	cmp	x19, x8
10002f3ec: 54005f89    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f3f0: d37cec09    	lsl	x9, x0, #4
10002f3f4: d37ced08    	lsl	x8, x8, #4
10002f3f8: aa1f03e1    	mov	x1, xzr
10002f3fc: b8696ae9    	ldr	w9, [x23, x9]
10002f400: b8686ae8    	ldr	w8, [x23, x8]
10002f404: 6b08013f    	cmp	w9, w8
10002f408: 1a9f07e0    	cset	w0, ne
10002f40c: 17fffd74    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f410: b9400f60    	ldr	w0, [x27, #0xc]
10002f414: eb00027f    	cmp	x19, x0
10002f418: 54005e49    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f41c: b9401368    	ldr	w8, [x27, #0x10]
10002f420: eb08027f    	cmp	x19, x8
10002f424: 54005dc9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f428: d37cec09    	lsl	x9, x0, #4
10002f42c: d37ced08    	lsl	x8, x8, #4
10002f430: aa1f03e1    	mov	x1, xzr
10002f434: f8696ae9    	ldr	x9, [x23, x9]
10002f438: f8686ae8    	ldr	x8, [x23, x8]
10002f43c: eb08013f    	cmp	x9, x8
10002f440: 1a9fc7e0    	cset	w0, le
10002f444: 17fffd66    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f448: b9400f60    	ldr	w0, [x27, #0xc]
10002f44c: eb00027f    	cmp	x19, x0
10002f450: 54005c89    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f454: b9401368    	ldr	w8, [x27, #0x10]
10002f458: eb08027f    	cmp	x19, x8
10002f45c: 54005c09    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f460: d37ced08    	lsl	x8, x8, #4
10002f464: d37cec09    	lsl	x9, x0, #4
10002f468: aa1f03e1    	mov	x1, xzr
10002f46c: b8686ae8    	ldr	w8, [x23, x8]
10002f470: b8696ae9    	ldr	w9, [x23, x9]
10002f474: 4b0803e8    	neg	w8, w8
10002f478: 1ac82d20    	ror	w0, w9, w8
10002f47c: 17fffd58    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f480: b9400f60    	ldr	w0, [x27, #0xc]
10002f484: eb00027f    	cmp	x19, x0
10002f488: 54005ac9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f48c: b9401368    	ldr	w8, [x27, #0x10]
10002f490: eb08027f    	cmp	x19, x8
10002f494: 54005a49    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f498: d37cec09    	lsl	x9, x0, #4
10002f49c: d37ced08    	lsl	x8, x8, #4
10002f4a0: aa1f03e1    	mov	x1, xzr
10002f4a4: b8696ae9    	ldr	w9, [x23, x9]
10002f4a8: b8686ae8    	ldr	w8, [x23, x8]
10002f4ac: 6b08013f    	cmp	w9, w8
10002f4b0: 1a9f87e0    	cset	w0, ls
10002f4b4: 17fffd4a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f4b8: b9400f60    	ldr	w0, [x27, #0xc]
10002f4bc: eb00027f    	cmp	x19, x0
10002f4c0: 54005909    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f4c4: b9401368    	ldr	w8, [x27, #0x10]
10002f4c8: eb08027f    	cmp	x19, x8
10002f4cc: 54005889    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f4d0: d37cec09    	lsl	x9, x0, #4
10002f4d4: d37ced08    	lsl	x8, x8, #4
10002f4d8: aa1f03e1    	mov	x1, xzr
10002f4dc: b8696ae9    	ldr	w9, [x23, x9]
10002f4e0: b8686ae8    	ldr	w8, [x23, x8]
10002f4e4: 6b08013f    	cmp	w9, w8
10002f4e8: 1a9fb7e0    	cset	w0, ge
10002f4ec: 17fffd3c    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f4f0: b9400f60    	ldr	w0, [x27, #0xc]
10002f4f4: eb00027f    	cmp	x19, x0
10002f4f8: 54005749    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f4fc: d37cec08    	lsl	x8, x0, #4
10002f500: aa1f03e1    	mov	x1, xzr
10002f504: b8686ae8    	ldr	w8, [x23, x8]
10002f508: 7100011f    	cmp	w8, #0x0
10002f50c: 1a9f17e0    	cset	w0, eq
10002f510: 17fffd33    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f514: b9400f60    	ldr	w0, [x27, #0xc]
10002f518: eb00027f    	cmp	x19, x0
10002f51c: 54005629    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f520: b9401368    	ldr	w8, [x27, #0x10]
10002f524: eb08027f    	cmp	x19, x8
10002f528: 540055a9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f52c: d37cec09    	lsl	x9, x0, #4
10002f530: d37ced08    	lsl	x8, x8, #4
10002f534: aa1f03e1    	mov	x1, xzr
10002f538: b8696ae9    	ldr	w9, [x23, x9]
10002f53c: b8686ae8    	ldr	w8, [x23, x8]
10002f540: 6b08013f    	cmp	w9, w8
10002f544: 1a9f27e0    	cset	w0, lo
10002f548: 17fffd25    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f54c: b9400f60    	ldr	w0, [x27, #0xc]
10002f550: eb00027f    	cmp	x19, x0
10002f554: 54005469    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f558: b9401368    	ldr	w8, [x27, #0x10]
10002f55c: eb08027f    	cmp	x19, x8
10002f560: 540053e9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f564: d37cec09    	lsl	x9, x0, #4
10002f568: d37ced08    	lsl	x8, x8, #4
10002f56c: aa1f03e1    	mov	x1, xzr
10002f570: f8696ae9    	ldr	x9, [x23, x9]
10002f574: f8686ae8    	ldr	x8, [x23, x8]
10002f578: 8b090100    	add	x0, x8, x9
10002f57c: 17fffd18    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f580: b9400f60    	ldr	w0, [x27, #0xc]
10002f584: eb00027f    	cmp	x19, x0
10002f588: 540052c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f58c: b9401368    	ldr	w8, [x27, #0x10]
10002f590: eb08027f    	cmp	x19, x8
10002f594: 54005249    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f598: d37cec09    	lsl	x9, x0, #4
10002f59c: d37ced08    	lsl	x8, x8, #4
10002f5a0: aa1f03e1    	mov	x1, xzr
10002f5a4: b8696ae9    	ldr	w9, [x23, x9]
10002f5a8: b8686ae8    	ldr	w8, [x23, x8]
10002f5ac: 4a090100    	eor	w0, w8, w9
10002f5b0: 17fffd0b    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f5b4: b9400f60    	ldr	w0, [x27, #0xc]
10002f5b8: eb00027f    	cmp	x19, x0
10002f5bc: 54005129    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f5c0: b9401368    	ldr	w8, [x27, #0x10]
10002f5c4: eb08027f    	cmp	x19, x8
10002f5c8: 540050a9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f5cc: d37cec09    	lsl	x9, x0, #4
10002f5d0: d37ced08    	lsl	x8, x8, #4
10002f5d4: aa1f03e1    	mov	x1, xzr
10002f5d8: f8696ae9    	ldr	x9, [x23, x9]
10002f5dc: f8686ae8    	ldr	x8, [x23, x8]
10002f5e0: 8a090100    	and	x0, x8, x9
10002f5e4: 17fffcfe    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f5e8: b9400f60    	ldr	w0, [x27, #0xc]
10002f5ec: eb00027f    	cmp	x19, x0
10002f5f0: 54004f89    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f5f4: b9401368    	ldr	w8, [x27, #0x10]
10002f5f8: eb08027f    	cmp	x19, x8
10002f5fc: 54004f09    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f600: d37cec09    	lsl	x9, x0, #4
10002f604: d37ced08    	lsl	x8, x8, #4
10002f608: aa1f03e1    	mov	x1, xzr
10002f60c: f8696ae9    	ldr	x9, [x23, x9]
10002f610: f8686ae8    	ldr	x8, [x23, x8]
10002f614: cb080120    	sub	x0, x9, x8
10002f618: 17fffcf1    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f61c: b9400f60    	ldr	w0, [x27, #0xc]
10002f620: eb00027f    	cmp	x19, x0
10002f624: 54004de9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f628: b9401368    	ldr	w8, [x27, #0x10]
10002f62c: eb08027f    	cmp	x19, x8
10002f630: 54004d69    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f634: d37ced08    	lsl	x8, x8, #4
10002f638: d37cec09    	lsl	x9, x0, #4
10002f63c: b8686ae8    	ldr	w8, [x23, x8]
10002f640: f8696ae9    	ldr	x9, [x23, x9]
10002f644: 4b0803e8    	neg	w8, w8
10002f648: 1400006b    	b	0x10002f7f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1768>
10002f64c: b9400f60    	ldr	w0, [x27, #0xc]
10002f650: eb00027f    	cmp	x19, x0
10002f654: 54004c69    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f658: b9401368    	ldr	w8, [x27, #0x10]
10002f65c: eb08027f    	cmp	x19, x8
10002f660: 54004be9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f664: d37cec09    	lsl	x9, x0, #4
10002f668: d37ced08    	lsl	x8, x8, #4
10002f66c: aa1f03e1    	mov	x1, xzr
10002f670: b8696ae9    	ldr	w9, [x23, x9]
10002f674: b8686ae8    	ldr	w8, [x23, x8]
10002f678: 6b08013f    	cmp	w9, w8
10002f67c: 1a9f17e0    	cset	w0, eq
10002f680: 17fffcd7    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f684: b9400f60    	ldr	w0, [x27, #0xc]
10002f688: eb00027f    	cmp	x19, x0
10002f68c: 54004aa9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f690: b9401368    	ldr	w8, [x27, #0x10]
10002f694: eb08027f    	cmp	x19, x8
10002f698: 54004a29    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f69c: d37cec09    	lsl	x9, x0, #4
10002f6a0: d37ced08    	lsl	x8, x8, #4
10002f6a4: aa1f03e1    	mov	x1, xzr
10002f6a8: b8696ae9    	ldr	w9, [x23, x9]
10002f6ac: b8686ae8    	ldr	w8, [x23, x8]
10002f6b0: 6b08013f    	cmp	w9, w8
10002f6b4: 1a9f37e0    	cset	w0, hs
10002f6b8: 17fffcc9    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f6bc: b9400f60    	ldr	w0, [x27, #0xc]
10002f6c0: eb00027f    	cmp	x19, x0
10002f6c4: 540048e9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f6c8: b9401368    	ldr	w8, [x27, #0x10]
10002f6cc: eb08027f    	cmp	x19, x8
10002f6d0: 54004869    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f6d4: d37cec09    	lsl	x9, x0, #4
10002f6d8: d37ced08    	lsl	x8, x8, #4
10002f6dc: aa1f03e1    	mov	x1, xzr
10002f6e0: b8696ae9    	ldr	w9, [x23, x9]
10002f6e4: b8686ae8    	ldr	w8, [x23, x8]
10002f6e8: 1b097d00    	mul	w0, w8, w9
10002f6ec: 17fffcbc    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f6f0: b9400f60    	ldr	w0, [x27, #0xc]
10002f6f4: eb00027f    	cmp	x19, x0
10002f6f8: 54004749    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f6fc: b9401368    	ldr	w8, [x27, #0x10]
10002f700: eb08027f    	cmp	x19, x8
10002f704: 540046c9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f708: d37cec09    	lsl	x9, x0, #4
10002f70c: d37ced08    	lsl	x8, x8, #4
10002f710: aa1f03e1    	mov	x1, xzr
10002f714: b8696ae9    	ldr	w9, [x23, x9]
10002f718: b8686ae8    	ldr	w8, [x23, x8]
10002f71c: 6b08013f    	cmp	w9, w8
10002f720: 1a9fc7e0    	cset	w0, le
10002f724: 17fffcae    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f728: b9400f60    	ldr	w0, [x27, #0xc]
10002f72c: eb00027f    	cmp	x19, x0
10002f730: 54004589    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f734: b9401368    	ldr	w8, [x27, #0x10]
10002f738: eb08027f    	cmp	x19, x8
10002f73c: 54004509    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f740: d37cec09    	lsl	x9, x0, #4
10002f744: d37ced08    	lsl	x8, x8, #4
10002f748: aa1f03e1    	mov	x1, xzr
10002f74c: b8696ae9    	ldr	w9, [x23, x9]
10002f750: b8686ae8    	ldr	w8, [x23, x8]
10002f754: 6b08013f    	cmp	w9, w8
10002f758: 1a9fd7e0    	cset	w0, gt
10002f75c: 17fffca0    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f760: b9400f60    	ldr	w0, [x27, #0xc]
10002f764: eb00027f    	cmp	x19, x0
10002f768: 540043c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f76c: b9401368    	ldr	w8, [x27, #0x10]
10002f770: eb08027f    	cmp	x19, x8
10002f774: 54004349    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f778: d37cec09    	lsl	x9, x0, #4
10002f77c: d37ced08    	lsl	x8, x8, #4
10002f780: aa1f03e1    	mov	x1, xzr
10002f784: b8696ae9    	ldr	w9, [x23, x9]
10002f788: b8686ae8    	ldr	w8, [x23, x8]
10002f78c: 1ac82d20    	ror	w0, w9, w8
10002f790: 17fffc93    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f794: b9400f60    	ldr	w0, [x27, #0xc]
10002f798: eb00027f    	cmp	x19, x0
10002f79c: 54004229    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f7a0: b9401368    	ldr	w8, [x27, #0x10]
10002f7a4: eb08027f    	cmp	x19, x8
10002f7a8: 540041a9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f7ac: d37cec09    	lsl	x9, x0, #4
10002f7b0: d37ced08    	lsl	x8, x8, #4
10002f7b4: aa1f03e1    	mov	x1, xzr
10002f7b8: f8696ae9    	ldr	x9, [x23, x9]
10002f7bc: f8686ae8    	ldr	x8, [x23, x8]
10002f7c0: eb08013f    	cmp	x9, x8
10002f7c4: 1a9fa7e0    	cset	w0, lt
10002f7c8: 17fffc85    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f7cc: b9400f60    	ldr	w0, [x27, #0xc]
10002f7d0: eb00027f    	cmp	x19, x0
10002f7d4: 54004069    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f7d8: b9401368    	ldr	w8, [x27, #0x10]
10002f7dc: eb08027f    	cmp	x19, x8
10002f7e0: 54003fe9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f7e4: d37cec09    	lsl	x9, x0, #4
10002f7e8: d37ced08    	lsl	x8, x8, #4
10002f7ec: f8696ae9    	ldr	x9, [x23, x9]
10002f7f0: f8686ae8    	ldr	x8, [x23, x8]
10002f7f4: 9ac82d20    	ror	x0, x9, x8
10002f7f8: aa1f03e1    	mov	x1, xzr
10002f7fc: 17fffc78    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f800: b9400f60    	ldr	w0, [x27, #0xc]
10002f804: eb00027f    	cmp	x19, x0
10002f808: 54003ec9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f80c: b9401368    	ldr	w8, [x27, #0x10]
10002f810: eb08027f    	cmp	x19, x8
10002f814: 54003e49    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f818: d37cec09    	lsl	x9, x0, #4
10002f81c: d37ced08    	lsl	x8, x8, #4
10002f820: aa1f03e1    	mov	x1, xzr
10002f824: b8696ae9    	ldr	w9, [x23, x9]
10002f828: b8686ae8    	ldr	w8, [x23, x8]
10002f82c: 6b08013f    	cmp	w9, w8
10002f830: 1a9f97e0    	cset	w0, hi
10002f834: 17fffc6a    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f838: b9400f60    	ldr	w0, [x27, #0xc]
10002f83c: eb00027f    	cmp	x19, x0
10002f840: 54003d09    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f844: d37cec08    	lsl	x8, x0, #4
10002f848: aa1f03e1    	mov	x1, xzr
10002f84c: 38a86ae0    	ldrsb	x0, [x23, x8]
10002f850: 17fffc63    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f854: b9400f60    	ldr	w0, [x27, #0xc]
10002f858: eb00027f    	cmp	x19, x0
10002f85c: 54003c29    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f860: d37cec08    	lsl	x8, x0, #4
10002f864: aa1f03e1    	mov	x1, xzr
10002f868: 78a86ae0    	ldrsh	x0, [x23, x8]
10002f86c: 17fffc5c    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f870: b9400f60    	ldr	w0, [x27, #0xc]
10002f874: eb00027f    	cmp	x19, x0
10002f878: 54003b49    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f87c: b9401368    	ldr	w8, [x27, #0x10]
10002f880: eb08027f    	cmp	x19, x8
10002f884: 54003ac9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f888: d37cec09    	lsl	x9, x0, #4
10002f88c: d37ced08    	lsl	x8, x8, #4
10002f890: aa1f03e1    	mov	x1, xzr
10002f894: f8696ae9    	ldr	x9, [x23, x9]
10002f898: f8686ae8    	ldr	x8, [x23, x8]
10002f89c: eb08013f    	cmp	x9, x8
10002f8a0: 1a9f17e0    	cset	w0, eq
10002f8a4: 17fffc4e    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f8a8: b9400f60    	ldr	w0, [x27, #0xc]
10002f8ac: eb00027f    	cmp	x19, x0
10002f8b0: 54003989    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f8b4: b9401368    	ldr	w8, [x27, #0x10]
10002f8b8: eb08027f    	cmp	x19, x8
10002f8bc: 54003909    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f8c0: d37cec09    	lsl	x9, x0, #4
10002f8c4: d37ced08    	lsl	x8, x8, #4
10002f8c8: aa1f03e1    	mov	x1, xzr
10002f8cc: f8696ae9    	ldr	x9, [x23, x9]
10002f8d0: f8686ae8    	ldr	x8, [x23, x8]
10002f8d4: eb08013f    	cmp	x9, x8
10002f8d8: 1a9f37e0    	cset	w0, hs
10002f8dc: 17fffc40    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f8e0: b9400f60    	ldr	w0, [x27, #0xc]
10002f8e4: eb00027f    	cmp	x19, x0
10002f8e8: 540037c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f8ec: b9401368    	ldr	w8, [x27, #0x10]
10002f8f0: eb08027f    	cmp	x19, x8
10002f8f4: 54003749    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f8f8: d37cec09    	lsl	x9, x0, #4
10002f8fc: d37ced08    	lsl	x8, x8, #4
10002f900: aa1f03e1    	mov	x1, xzr
10002f904: f8696ae9    	ldr	x9, [x23, x9]
10002f908: f8686ae8    	ldr	x8, [x23, x8]
10002f90c: eb08013f    	cmp	x9, x8
10002f910: 1a9fb7e0    	cset	w0, ge
10002f914: 17fffc32    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f918: b9400f60    	ldr	w0, [x27, #0xc]
10002f91c: eb00027f    	cmp	x19, x0
10002f920: 54003609    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f924: b9401368    	ldr	w8, [x27, #0x10]
10002f928: eb08027f    	cmp	x19, x8
10002f92c: 54003589    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f930: d37cec09    	lsl	x9, x0, #4
10002f934: d37ced08    	lsl	x8, x8, #4
10002f938: aa1f03e1    	mov	x1, xzr
10002f93c: f8696ae9    	ldr	x9, [x23, x9]
10002f940: f8686ae8    	ldr	x8, [x23, x8]
10002f944: 9ac82920    	asr	x0, x9, x8
10002f948: 17fffc25    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f94c: b9400f60    	ldr	w0, [x27, #0xc]
10002f950: eb00027f    	cmp	x19, x0
10002f954: 54003469    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f958: b9401368    	ldr	w8, [x27, #0x10]
10002f95c: eb08027f    	cmp	x19, x8
10002f960: 540033e9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f964: d37cec09    	lsl	x9, x0, #4
10002f968: d37ced08    	lsl	x8, x8, #4
10002f96c: aa1f03e1    	mov	x1, xzr
10002f970: b8696ae9    	ldr	w9, [x23, x9]
10002f974: b8686ae8    	ldr	w8, [x23, x8]
10002f978: 0a080120    	and	w0, w9, w8
10002f97c: 17fffc18    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f980: b9400f60    	ldr	w0, [x27, #0xc]
10002f984: eb00027f    	cmp	x19, x0
10002f988: 540032c9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f98c: b9401368    	ldr	w8, [x27, #0x10]
10002f990: eb08027f    	cmp	x19, x8
10002f994: 54003249    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f998: d37cec09    	lsl	x9, x0, #4
10002f99c: d37ced08    	lsl	x8, x8, #4
10002f9a0: aa1f03e1    	mov	x1, xzr
10002f9a4: b8696ae9    	ldr	w9, [x23, x9]
10002f9a8: b8686ae8    	ldr	w8, [x23, x8]
10002f9ac: 0b090100    	add	w0, w8, w9
10002f9b0: 17fffc0b    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f9b4: b9400f60    	ldr	w0, [x27, #0xc]
10002f9b8: eb00027f    	cmp	x19, x0
10002f9bc: 54003129    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f9c0: b9401368    	ldr	w8, [x27, #0x10]
10002f9c4: eb08027f    	cmp	x19, x8
10002f9c8: 540030a9    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002f9cc: d37cec09    	lsl	x9, x0, #4
10002f9d0: d37ced08    	lsl	x8, x8, #4
10002f9d4: aa1f03e1    	mov	x1, xzr
10002f9d8: f8696ae9    	ldr	x9, [x23, x9]
10002f9dc: f8686ae8    	ldr	x8, [x23, x8]
10002f9e0: 9b097d00    	mul	x0, x8, x9
10002f9e4: 17fffbfe    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002f9e8: b9400f60    	ldr	w0, [x27, #0xc]
10002f9ec: eb00027f    	cmp	x19, x0
10002f9f0: 54002f89    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002f9f4: d37cec08    	lsl	x8, x0, #4
10002f9f8: aa1f03e1    	mov	x1, xzr
10002f9fc: 38a86ae8    	ldrsb	x8, [x23, x8]
10002fa00: 2a0803e0    	mov	w0, w8
10002fa04: 17fffbf6    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fa08: b9400f60    	ldr	w0, [x27, #0xc]
10002fa0c: eb00027f    	cmp	x19, x0
10002fa10: 54002e89    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fa14: d37cec08    	lsl	x8, x0, #4
10002fa18: 5280040a    	mov	w10, #0x20              ; =32
10002fa1c: aa1f03e1    	mov	x1, xzr
10002fa20: f8686ae8    	ldr	x8, [x23, x8]
10002fa24: d360fd09    	lsr	x9, x8, #32
10002fa28: f100013f    	cmp	x9, #0x0
10002fa2c: 9a881128    	csel	x8, x9, x8, ne
10002fa30: 9a9f114a    	csel	x10, x10, xzr, ne
10002fa34: d350fd09    	lsr	x9, x8, #16
10002fa38: f100013f    	cmp	x9, #0x0
10002fa3c: 9a881128    	csel	x8, x9, x8, ne
10002fa40: b27c0149    	orr	x9, x10, #0x10
10002fa44: d348fd0b    	lsr	x11, x8, #8
10002fa48: 9a8a1129    	csel	x9, x9, x10, ne
10002fa4c: f103fd1f    	cmp	x8, #0xff
10002fa50: b27d012a    	orr	x10, x9, #0x8
10002fa54: 9a888168    	csel	x8, x11, x8, hi
10002fa58: d000148b    	adrp	x11, 0x1002c1000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xec8>
10002fa5c: 9123356b    	add	x11, x11, #0x8cd
10002fa60: 92401d08    	and	x8, x8, #0xff
10002fa64: 9a898149    	csel	x9, x10, x9, hi
10002fa68: 5280080a    	mov	w10, #0x40              ; =64
10002fa6c: 38686968    	ldrb	w8, [x11, x8]
10002fa70: cb090149    	sub	x9, x10, x9
10002fa74: cb080120    	sub	x0, x9, x8
10002fa78: 17fffbd9    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fa7c: b9400f60    	ldr	w0, [x27, #0xc]
10002fa80: eb00027f    	cmp	x19, x0
10002fa84: 54002ae9    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fa88: b9401368    	ldr	w8, [x27, #0x10]
10002fa8c: eb08027f    	cmp	x19, x8
10002fa90: 54002a69    	b.ls	0x10002ffdc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002fa94: d37cec09    	lsl	x9, x0, #4
10002fa98: d37ced08    	lsl	x8, x8, #4
10002fa9c: aa1f03e1    	mov	x1, xzr
10002faa0: f8696ae9    	ldr	x9, [x23, x9]
10002faa4: f8686ae8    	ldr	x8, [x23, x8]
10002faa8: 9ac82120    	lsl	x0, x9, x8
10002faac: 17fffbcc    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fab0: b9400f60    	ldr	w0, [x27, #0xc]
10002fab4: eb00027f    	cmp	x19, x0
10002fab8: 54002949    	b.ls	0x10002ffe0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fabc: d37cec08    	lsl	x8, x0, #4
10002fac0: aa1f03e1    	mov	x1, xzr
10002fac4: 78a86ae8    	ldrsh	x8, [x23, x8]
10002fac8: 2a0803e0    	mov	w0, w8
10002facc: 17fffbc4    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fad0: 51022d28    	sub	w8, w9, #0x8b
10002fad4: 7100d11f    	cmp	w8, #0x34
10002fad8: 540000c8    	b.hi	0x10002faf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a64>
10002fadc: 92a2000a    	mov	x10, #-0x10000001       ; =-268435457
10002fae0: f2dfff2a    	movk	x10, #0xfff9, lsl #32
10002fae4: f2e003ea    	movk	x10, #0x1f, lsl #48
10002fae8: 9ac82548    	lsr	x8, x10, x8
10002faec: 37074488    	tbnz	w8, #0x0, 0x10002e37c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
10002faf0: 51018528    	sub	w8, w9, #0x61
10002faf4: aa1f03e0    	mov	x0, xzr
10002faf8: 7100851f    	cmp	w8, #0x21
10002fafc: 54001628    	b.hi	0x10002fdc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d34>
10002fb00: b2620fea    	mov	x10, #0x3c0000000       ; =16106127360
10002fb04: aa0003e1    	mov	x1, x0
10002fb08: f29e07ea    	movk	x10, #0xf03f
10002fb0c: 9ac82548    	lsr	x8, x10, x8
10002fb10: 37074368    	tbnz	w8, #0x0, 0x10002e37c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
10002fb14: 17fffbb2    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fb18: aa1f03e5    	mov	x5, xzr
10002fb1c: b9401360    	ldr	w0, [x27, #0x10]
10002fb20: 3100041f    	cmn	w0, #0x1
10002fb24: 54ffa581    	b.ne	0x10002efd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf48>
10002fb28: aa1f03e7    	mov	x7, xzr
10002fb2c: b9401760    	ldr	w0, [x27, #0x14]
10002fb30: 3100041f    	cmn	w0, #0x1
10002fb34: 54ffa5e1    	b.ne	0x10002eff0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf64>
10002fb38: aa1f03ea    	mov	x10, xzr
10002fb3c: 12103d28    	and	w8, w9, #0xffff0000
10002fb40: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
10002fb44: 54ffa640    	b.eq	0x10002f00c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf80>
10002fb48: 529ffda8    	mov	w8, #0xffed             ; =65517
10002fb4c: 72bfe068    	movk	w8, #0xff03, lsl #16
10002fb50: 0b090108    	add	w8, w8, w9
10002fb54: 11002d08    	add	w8, w8, #0xb
10002fb58: 7100291f    	cmp	w8, #0xa
10002fb5c: 54002c42    	b.hs	0x1000300e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2058>
10002fb60: f9404201    	ldr	x1, [x16, #0x80]
10002fb64: b9400760    	ldr	w0, [x27, #0x4]
10002fb68: eb00003f    	cmp	x1, x0
10002fb6c: 54002369    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fb70: f9403e08    	ldr	x8, [x16, #0x78]
10002fb74: 52801c09    	mov	w9, #0xe0               ; =224
10002fb78: 9ba92008    	umaddl	x8, w0, w9, x8
10002fb7c: b40015e8    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fb80: b9400109    	ldr	w9, [x8]
10002fb84: f940050b    	ldr	x11, [x8, #0x8]
10002fb88: 910363ec    	add	x12, sp, #0xd8
10002fb8c: 3dc00500    	ldr	q0, [x8, #0x10]
10002fb90: 3cc48101    	ldur	q1, [x8, #0x48]
10002fb94: 910363e2    	add	x2, sp, #0xd8
10002fb98: b900dbe9    	str	w9, [sp, #0xd8]
10002fb9c: 3cc68102    	ldur	q2, [x8, #0x68]
10002fba0: aa1503e0    	mov	x0, x21
10002fba4: f90073eb    	str	x11, [sp, #0xe0]
10002fba8: a9422d09    	ldp	x9, x11, [x8, #0x20]
10002fbac: 3d800580    	str	q0, [x12, #0x10]
10002fbb0: aa0503e3    	mov	x3, x5
10002fbb4: aa1f03e4    	mov	x4, xzr
10002fbb8: 3dc00d00    	ldr	q0, [x8, #0x30]
10002fbbc: 3c848181    	stur	q1, [x12, #0x48]
10002fbc0: aa0703e5    	mov	x5, x7
10002fbc4: a90fafe9    	stp	x9, x11, [sp, #0xf8]
10002fbc8: 39410109    	ldrb	w9, [x8, #0x40]
10002fbcc: aa1f03e6    	mov	x6, xzr
10002fbd0: 3d800d80    	str	q0, [x12, #0x30]
10002fbd4: 3cc58100    	ldur	q0, [x8, #0x58]
10002fbd8: aa0a03e7    	mov	x7, x10
10002fbdc: 390463e9    	strb	w9, [sp, #0x118]
10002fbe0: 3cc78101    	ldur	q1, [x8, #0x78]
10002fbe4: f94013e1    	ldr	x1, [sp, #0x20]
10002fbe8: 3c858180    	stur	q0, [x12, #0x58]
10002fbec: 3cc88100    	ldur	q0, [x8, #0x88]
10002fbf0: a949a109    	ldp	x9, x8, [x8, #0x98]
10002fbf4: 3c868182    	stur	q2, [x12, #0x68]
10002fbf8: 3c878181    	stur	q1, [x12, #0x78]
10002fbfc: 3c888180    	stur	q0, [x12, #0x88]
10002fc00: a91723e9    	stp	x9, x8, [sp, #0x170]
10002fc04: 9102c3e8    	add	x8, sp, #0xb0
10002fc08: f90003ff    	str	xzr, [sp]
10002fc0c: 9400114e    	bl	0x100034144 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
10002fc10: a94b07e0    	ldp	x0, x1, [sp, #0xb0]
10002fc14: f94067e8    	ldr	x8, [sp, #0xc8]
10002fc18: 394303f9    	ldrb	w25, [sp, #0xc0]
10002fc1c: b4ff6da8    	cbz	x8, 0x10002e9d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
10002fc20: f9400509    	ldr	x9, [x8, #0x8]
10002fc24: f94017f0    	ldr	x16, [sp, #0x28]
10002fc28: b4ff6d69    	cbz	x9, 0x10002e9d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
10002fc2c: 140000dc    	b	0x10002ff9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f10>
10002fc30: f9400b28    	ldr	x8, [x25, #0x10]
10002fc34: f94017f0    	ldr	x16, [sp, #0x28]
10002fc38: aa1f03e1    	mov	x1, xzr
10002fc3c: 3940c508    	ldrb	w8, [x8, #0x31]
10002fc40: 7200011f    	tst	w8, #0x1
10002fc44: 3902bfe8    	strb	w8, [sp, #0xaf]
10002fc48: 12800008    	mov	w8, #-0x1               ; =-1
10002fc4c: da9f0100    	csinv	x0, x8, xzr, eq
10002fc50: 17fffb63    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fc54: b4000a88    	cbz	x8, 0x10002fda4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d18>
10002fc58: c8dffd08    	ldar	x8, [x8]
10002fc5c: b4000a80    	cbz	x0, 0x10002fdac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d20>
10002fc60: f9401c09    	ldr	x9, [x0, #0x38]
10002fc64: 52a0002a    	mov	w10, #0x10000           ; =65536
10002fc68: aa1f03e1    	mov	x1, xzr
10002fc6c: f100013f    	cmp	x9, #0x0
10002fc70: 9a890149    	csel	x9, x10, x9, eq
10002fc74: 9ac90900    	udiv	x0, x8, x9
10002fc78: 17fffb59    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fc7c: aa1f03e0    	mov	x0, xzr
10002fc80: aa1f03e2    	mov	x2, xzr
10002fc84: 14000003    	b	0x10002fc90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
10002fc88: f9400408    	ldr	x8, [x0, #0x8]
10002fc8c: b5001028    	cbnz	x8, 0x10002fe90 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
10002fc90: f9408602    	ldr	x2, [x16, #0x108]
10002fc94: 0b190348    	add	w8, w26, w25
10002fc98: eb08005f    	cmp	x2, x8
10002fc9c: 54001f43    	b.lo	0x100030084 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ff8>
10002fca0: 6b08033f    	cmp	w25, w8
10002fca4: 54001e68    	b.hi	0x100030070 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
10002fca8: cb190049    	sub	x9, x2, x25
10002fcac: d37df32a    	lsl	x10, x25, #3
10002fcb0: f100013f    	cmp	x9, #0x0
10002fcb4: 9a9fc149    	csel	x9, x10, xzr, gt
10002fcb8: 3400025a    	cbz	w26, 0x10002fd00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c74>
10002fcbc: f9407e0a    	ldr	x10, [x16, #0xf8]
10002fcc0: b94017fa    	ldr	w26, [sp, #0x14]
10002fcc4: 8b09014a    	add	x10, x10, x9
10002fcc8: cb190109    	sub	x9, x8, x25
10002fccc: 9100114a    	add	x10, x10, #0x4
10002fcd0: b9400140    	ldr	w0, [x10]
10002fcd4: eb00027f    	cmp	x19, x0
10002fcd8: 54001749    	b.ls	0x10002ffc0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fcdc: b85fc148    	ldur	w8, [x10, #-0x4]
10002fce0: eb08027f    	cmp	x19, x8
10002fce4: 54001729    	b.ls	0x10002ffc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
10002fce8: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fcec: f1000529    	subs	x9, x9, #0x1
10002fcf0: 9100214a    	add	x10, x10, #0x8
10002fcf4: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
10002fcf8: 54fffec1    	b.ne	0x10002fcd0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c44>
10002fcfc: 17fff913    	b	0x10002e148 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
10002fd00: b94017fa    	ldr	w26, [sp, #0x14]
10002fd04: 17fff911    	b	0x10002e148 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
10002fd08: f9404201    	ldr	x1, [x16, #0x80]
10002fd0c: b9400760    	ldr	w0, [x27, #0x4]
10002fd10: eb00003f    	cmp	x1, x0
10002fd14: 54001629    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fd18: f9403e08    	ldr	x8, [x16, #0x78]
10002fd1c: 52801c09    	mov	w9, #0xe0               ; =224
10002fd20: 9ba92008    	umaddl	x8, w0, w9, x8
10002fd24: b40008a8    	cbz	x8, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fd28: f94013e9    	ldr	x9, [sp, #0x20]
10002fd2c: b9401900    	ldr	w0, [x8, #0x18]
10002fd30: f9403d21    	ldr	x1, [x9, #0x78]
10002fd34: eb00003f    	cmp	x1, x0
10002fd38: 54001509    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fd3c: f9403929    	ldr	x9, [x9, #0x70]
10002fd40: ab000d29    	adds	x9, x9, x0, lsl #3
10002fd44: 540007a0    	b.eq	0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fd48: f9400129    	ldr	x9, [x9]
10002fd4c: b4000769    	cbz	x9, 0x10002fe38 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fd50: a94006ab    	ldp	x11, x1, [x21]
10002fd54: b940150c    	ldr	w12, [x8, #0x14]
10002fd58: b9401d08    	ldr	w8, [x8, #0x1c]
10002fd5c: f9400aa2    	ldr	x2, [x21, #0x10]
10002fd60: f9400920    	ldr	x0, [x9, #0x10]
10002fd64: f9400563    	ldr	x3, [x11, #0x8]
10002fd68: aa088186    	orr	x6, x12, x8, lsl #32
10002fd6c: d10283a8    	sub	x8, x29, #0xa0
10002fd70: f90003ea    	str	x10, [sp]
10002fd74: 94006ca3    	bl	0x10004b000 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
10002fd78: a97607a0    	ldp	x0, x1, [x29, #-0xa0]
10002fd7c: f85783a8    	ldur	x8, [x29, #-0x88]
10002fd80: 385703b9    	ldurb	w25, [x29, #-0x90]
10002fd84: b4ff6268    	cbz	x8, 0x10002e9d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
10002fd88: f9400509    	ldr	x9, [x8, #0x8]
10002fd8c: f94017f0    	ldr	x16, [sp, #0x28]
10002fd90: b4ff6229    	cbz	x9, 0x10002e9d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
10002fd94: 14000084    	b	0x10002ffa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f18>
10002fd98: aa1f03e1    	mov	x1, xzr
10002fd9c: 52800400    	mov	w0, #0x20               ; =32
10002fda0: 17fffb0f    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fda4: f9400408    	ldr	x8, [x0, #0x8]
10002fda8: b5fff5c0    	cbnz	x0, 0x10002fc60 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bd4>
10002fdac: 52800020    	mov	w0, #0x1                ; =1
10002fdb0: 9407b8d3    	bl	0x10021e0fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10002fdb4: f94017f0    	ldr	x16, [sp, #0x28]
10002fdb8: aa1f03e1    	mov	x1, xzr
10002fdbc: 17fffb08    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fdc0: aa0003e1    	mov	x1, x0
10002fdc4: 17fffb06    	b	0x10002e9dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10002fdc8: f9400fe8    	ldr	x8, [sp, #0x18]
10002fdcc: aa1503e0    	mov	x0, x21
10002fdd0: b81c8118    	stur	w24, [x8, #-0x38]
10002fdd4: 94000815    	bl	0x100031e28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
10002fdd8: 72001c1f    	tst	w0, #0xff
10002fddc: 54000601    	b.ne	0x10002fe9c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
10002fde0: f94026a8    	ldr	x8, [x21, #0x48]
10002fde4: f100011f    	cmp	x8, #0x0
10002fde8: 54ff170c    	b.gt	0x10002e0c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x3c>
10002fdec: 140000b8    	b	0x1000300cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
10002fdf0: f9400fe8    	ldr	x8, [sp, #0x18]
10002fdf4: aa1503e0    	mov	x0, x21
10002fdf8: b81c8118    	stur	w24, [x8, #-0x38]
10002fdfc: 9400044e    	bl	0x100030f34 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
10002fe00: 17fffff6    	b	0x10002fdd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
10002fe04: f9400fe8    	ldr	x8, [sp, #0x18]
10002fe08: aa1503e0    	mov	x0, x21
10002fe0c: b81c8118    	stur	w24, [x8, #-0x38]
10002fe10: 94000708    	bl	0x100031a30 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
10002fe14: 17fffff1    	b	0x10002fdd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
10002fe18: f9400fe8    	ldr	x8, [sp, #0x18]
10002fe1c: aa1503e0    	mov	x0, x21
10002fe20: b81c8118    	stur	w24, [x8, #-0x38]
10002fe24: 94000352    	bl	0x100030b6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
10002fe28: 12001c08    	and	w8, w0, #0xff
10002fe2c: 3607fda8    	tbz	w8, #0x0, 0x10002fde0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d54>
10002fe30: 52800020    	mov	w0, #0x1                ; =1
10002fe34: 14000051    	b	0x10002ff78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002fe38: 52800020    	mov	w0, #0x1                ; =1
10002fe3c: 9407b8b0    	bl	0x10021e0fc <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10002fe40: aa1f03e0    	mov	x0, xzr
10002fe44: 1400004d    	b	0x10002ff78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002fe48: 52800500    	mov	w0, #0x28               ; =40
10002fe4c: 94080abd    	bl	0x100232940 <dyld_stub_binder+0x100232940>
10002fe50: b4001560    	cbz	x0, 0x1000300fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
10002fe54: aa0003f3    	mov	x19, x0
10002fe58: 52800500    	mov	w0, #0x28               ; =40
10002fe5c: 9407a75b    	bl	0x100219bc8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
10002fe60: f9400728    	ldr	x8, [x25, #0x8]
10002fe64: b0001ce9    	adrp	x9, 0x1003cc000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x3eb>
10002fe68: f00013aa    	adrp	x10, 0x1002a6000 <dyld_stub_binder+0x1002a6000>
10002fe6c: 9127dd4a    	add	x10, x10, #0x9f7
10002fe70: 3dc28520    	ldr	q0, [x9, #0xa10]
10002fe74: d0001661    	adrp	x1, 0x1002fd000 <__llgo_struct$Xqrno4N5NqCKgM5Cq7UFK47fmNdJQnyerNAp-in6Jhs$fields+0x2b0>
10002fe78: 9133a021    	add	x1, x1, #0xce8
10002fe7c: a9012a68    	stp	x8, x10, [x19, #0x10]
10002fe80: 528001c8    	mov	w8, #0xe                ; =14
10002fe84: 3d800260    	str	q0, [x19]
10002fe88: f9001268    	str	x8, [x19, #0x20]
10002fe8c: 14000037    	b	0x10002ff68 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1edc>
10002fe90: aa0003e1    	mov	x1, x0
10002fe94: aa1503e0    	mov	x0, x21
10002fe98: 14000036    	b	0x10002ff70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
10002fe9c: 92401c00    	and	x0, x0, #0xff
10002fea0: 14000036    	b	0x10002ff78 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10002fea4: f9404ff3    	ldr	x19, [sp, #0x98]
10002fea8: 52800100    	mov	w0, #0x8                ; =8
10002feac: 94080aa5    	bl	0x100232940 <dyld_stub_binder+0x100232940>
10002feb0: b4001260    	cbz	x0, 0x1000300fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
10002feb4: aa0003f6    	mov	x22, x0
10002feb8: 52800100    	mov	w0, #0x8                ; =8
10002febc: 9407a743    	bl	0x100219bc8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
10002fec0: b0001582    	adrp	x2, 0x1002e0000 <__llgo_struct$mIZh4b65Spa81d_JMU9wcEdHxy7TDYgI946D_MzvNfY$fields+0x20>
10002fec4: 91338042    	add	x2, x2, #0xce0
10002fec8: aa1903e0    	mov	x0, x25
10002fecc: aa1303e1    	mov	x1, x19
10002fed0: aa1603e3    	mov	x3, x22
10002fed4: 94072580    	bl	0x1001f94d4 <_errors.As>
10002fed8: f94007e9    	ldr	x9, [sp, #0x8]
10002fedc: 36000080    	tbz	w0, #0x0, 0x10002feec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e60>
10002fee0: f94002c8    	ldr	x8, [x22]
10002fee4: b9405129    	ldr	w9, [x9, #0x50]
10002fee8: b9000509    	str	w9, [x8, #0x4]
10002feec: aa1503e0    	mov	x0, x21
10002fef0: aa1903e1    	mov	x1, x25
10002fef4: 1400001e    	b	0x10002ff6c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
10002fef8: 52800079    	mov	w25, #0x3               ; =3
10002fefc: 14000004    	b	0x10002ff0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
10002ff00: 52800039    	mov	w25, #0x1               ; =1
10002ff04: 14000002    	b	0x10002ff0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
10002ff08: 52800139    	mov	w25, #0x9               ; =9
10002ff0c: 52800200    	mov	w0, #0x10               ; =16
10002ff10: 94080a89    	bl	0x100232934 <dyld_stub_binder+0x100232934>
10002ff14: b4000f40    	cbz	x0, 0x1000300fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
10002ff18: aa0003f3    	mov	x19, x0
10002ff1c: 52800200    	mov	w0, #0x10               ; =16
10002ff20: 9407a72a    	bl	0x100219bc8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
10002ff24: f94017e9    	ldr	x9, [sp, #0x28]
10002ff28: a9007e7f    	stp	xzr, xzr, [x19]
10002ff2c: b9400760    	ldr	w0, [x27, #0x4]
10002ff30: f9404121    	ldr	x1, [x9, #0x80]
10002ff34: eb00003f    	cmp	x1, x0
10002ff38: 54000509    	b.ls	0x10002ffd8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ff3c: 52801c08    	mov	w8, #0xe0               ; =224
10002ff40: f9403d29    	ldr	x9, [x9, #0x78]
10002ff44: d0001581    	adrp	x1, 0x1002e1000 <__llgo_struct$wbzekbvhB4cPLJtXU_jsHQ-RJFEUmJu3thiJpPXS01U$fields+0x60>
10002ff48: 91012021    	add	x1, x1, #0x48
10002ff4c: 9ba82408    	umaddl	x8, w0, w8, x9
10002ff50: f94007e9    	ldr	x9, [sp, #0x8]
10002ff54: b9405129    	ldr	w9, [x9, #0x50]
10002ff58: f9400508    	ldr	x8, [x8, #0x8]
10002ff5c: 39000279    	strb	w25, [x19]
10002ff60: b9000669    	str	w9, [x19, #0x4]
10002ff64: f9000668    	str	x8, [x19, #0x8]
10002ff68: aa1503e0    	mov	x0, x21
10002ff6c: aa1303e2    	mov	x2, x19
10002ff70: 97fff4e9    	bl	0x10002d314 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
10002ff74: 52800060    	mov	w0, #0x3                ; =3
10002ff78: aa1403e1    	mov	x1, x20
10002ff7c: 910743ff    	add	sp, sp, #0x1d0
10002ff80: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10002ff84: a9444ff4    	ldp	x20, x19, [sp, #0x40]
10002ff88: a94357f6    	ldp	x22, x21, [sp, #0x30]
10002ff8c: a9425ff8    	ldp	x24, x23, [sp, #0x20]
10002ff90: a94167fa    	ldp	x26, x25, [sp, #0x10]
10002ff94: a8c66ffc    	ldp	x28, x27, [sp], #0x60
10002ff98: d65f03c0    	ret
10002ff9c: f9406be2    	ldr	x2, [sp, #0xd0]
10002ffa0: 14000002    	b	0x10002ffa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f1c>
10002ffa4: f85803a2    	ldur	x2, [x29, #-0x80]
10002ffa8: aa1503e0    	mov	x0, x21
10002ffac: aa0803e1    	mov	x1, x8
10002ffb0: 17fffff0    	b	0x10002ff70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
10002ffb4: aa1803e0    	mov	x0, x24
10002ffb8: aa1603e1    	mov	x1, x22
10002ffbc: 9407acae    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10002ffc0: aa1303e1    	mov	x1, x19
10002ffc4: 9407a73f    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10002ffc8: aa0803e0    	mov	x0, x8
10002ffcc: aa1303e1    	mov	x1, x19
10002ffd0: 9407a73c    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10002ffd4: aa1603e1    	mov	x1, x22
10002ffd8: 9407aca7    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10002ffdc: aa0803e0    	mov	x0, x8
10002ffe0: aa1303e1    	mov	x1, x19
10002ffe4: 9407aca4    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10002ffe8: aa0803e0    	mov	x0, x8
10002ffec: 9407aca2    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10002fff0: aa0a03e0    	mov	x0, x10
10002fff4: aa1303e1    	mov	x1, x19
10002fff8: 9407ac9f    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10002fffc: aa0903e0    	mov	x0, x9
100030000: 52800021    	mov	w1, #0x1                ; =1
100030004: 52800043    	mov	w3, #0x2                ; =2
100030008: 9407aa74    	bl	0x10021a9d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003000c: aa0803e0    	mov	x0, x8
100030010: 52800021    	mov	w1, #0x1                ; =1
100030014: aa0903e2    	mov	x2, x9
100030018: 52800063    	mov	w3, #0x3                ; =3
10003001c: 9407aa6f    	bl	0x10021a9d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100030020: aa0b03e0    	mov	x0, x11
100030024: aa1303e1    	mov	x1, x19
100030028: 9407ac93    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
10003002c: aa0903e0    	mov	x0, x9
100030030: aa1303e1    	mov	x1, x19
100030034: 9407ac90    	bl	0x10021b274 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100030038: 52800020    	mov	w0, #0x1                ; =1
10003003c: 9407a721    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100030040: aa1f03e0    	mov	x0, xzr
100030044: aa1f03e1    	mov	x1, xzr
100030048: 9407a71e    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003004c: aa0803e0    	mov	x0, x8
100030050: 2a1f03e1    	mov	w1, wzr
100030054: aa0a03e2    	mov	x2, x10
100030058: 52800063    	mov	w3, #0x3                ; =3
10003005c: 9407aa5f    	bl	0x10021a9d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100030060: aa0a03e0    	mov	x0, x10
100030064: 2a1f03e1    	mov	w1, wzr
100030068: 52800043    	mov	w3, #0x2                ; =2
10003006c: 9407aa5b    	bl	0x10021a9d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100030070: aa1903e0    	mov	x0, x25
100030074: 2a1f03e1    	mov	w1, wzr
100030078: aa0803e2    	mov	x2, x8
10003007c: 52800063    	mov	w3, #0x3                ; =3
100030080: 9407aa56    	bl	0x10021a9d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100030084: aa0803e0    	mov	x0, x8
100030088: 2a1f03e1    	mov	w1, wzr
10003008c: 52800043    	mov	w3, #0x2                ; =2
100030090: 9407aa52    	bl	0x10021a9d8 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100030094: 52800060    	mov	w0, #0x3                ; =3
100030098: 9407a70a    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
10003009c: 52800040    	mov	w0, #0x2                ; =2
1000300a0: 52800041    	mov	w1, #0x2                ; =2
1000300a4: 9407a707    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000300a8: aa0903e0    	mov	x0, x9
1000300ac: aa1303e1    	mov	x1, x19
1000300b0: 9407a704    	bl	0x100219cc0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000300b4: b0001920    	adrp	x0, 0x100355000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/ffi.Error+0x68>
1000300b8: 9107c000    	add	x0, x0, #0x1f0
1000300bc: b0001921    	adrp	x1, 0x100355000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/ffi.Error+0x68>
1000300c0: 9111c021    	add	x1, x1, #0x470
1000300c4: 9407a63c    	bl	0x1002199b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
1000300c8: d4200020    	brk	#0x1
1000300cc: d0001960    	adrp	x0, 0x10035e000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0x78>
1000300d0: 912ca000    	add	x0, x0, #0xb28
1000300d4: 90001581    	adrp	x1, 0x1002e0000 <__llgo_struct$mIZh4b65Spa81d_JMU9wcEdHxy7TDYgI946D_MzvNfY$fields+0x20>
1000300d8: 9134c021    	add	x1, x1, #0xd30
1000300dc: 9407a636    	bl	0x1002199b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
1000300e0: d4200020    	brk	#0x1
1000300e4: d0001960    	adrp	x0, 0x10035e000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0x78>
1000300e8: 912ca000    	add	x0, x0, #0xb28
1000300ec: 90001581    	adrp	x1, 0x1002e0000 <__llgo_struct$mIZh4b65Spa81d_JMU9wcEdHxy7TDYgI946D_MzvNfY$fields+0x20>
1000300f0: 91350021    	add	x1, x1, #0xd40
1000300f4: 9407a630    	bl	0x1002199b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
1000300f8: d4200020    	brk	#0x1
1000300fc: d0001960    	adrp	x0, 0x10035e000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/runtime.typeAssertionErrorString+0x78>
100030100: 912ca000    	add	x0, x0, #0xb28
100030104: b0001921    	adrp	x1, 0x100355000 <__llgo_github.com/xgo-dev/llgo/runtime/internal/ffi.Error+0x68>
100030108: 91078021    	add	x1, x1, #0x1e0
10003010c: 9407a62a    	bl	0x1002199b4 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100030110: d4200020    	brk	#0x1
