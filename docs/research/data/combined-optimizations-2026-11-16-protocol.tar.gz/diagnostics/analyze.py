from pathlib import Path
import gzip,json,math,random,statistics
p=Path(__file__).resolve().parent
def analyze(folder,n,seed,metrics,roles,cases):
 rows=[json.loads(x)for x in gzip.open(folder/'rows.jsonl.gz','rt')];rng=random.Random(seed);indices=[rng.choices(range(n),k=n)for _ in range(20000)]
 def ratio(v):
  logs=[math.log(x)for x in v];b=sorted(math.exp(sum(logs[i]for i in s)/n)for s in indices);return dict(ratio=math.exp(statistics.mean(logs)),ci95=[b[500],b[19499]])
 out={}
 for case in cases:
  blocks={}
  for r in rows:
   if case is None or r['case']==case:blocks.setdefault(r['block'],{})[r['id']]=r
  assert len(blocks)==n
  result={}
  for numerator,denominator in roles:
   group={}
   for metric in metrics:
    aa={role:ratio([blocks[i][role+'-aa'][metric]/blocks[i][role][metric]for i in range(n)])for role in [numerator,denominator]}
    for v in aa.values():v['resolves2_5Percent']=v['ci95'][0]>=.975 and v['ci95'][1]<=1.025
    v=ratio([math.sqrt(blocks[i][numerator][metric]*blocks[i][numerator+'-aa'][metric])/math.sqrt(blocks[i][denominator][metric]*blocks[i][denominator+'-aa'][metric])for i in range(n)]);v['controlsResolve']=all(x['resolves2_5Percent']for x in aa.values());group[metric]=dict(comparison=v,AA=aa)
   result[numerator+'/'+denominator]=group
  out[case or 'sdk']=result
 return out
sdk=analyze(p/'sdk-no-gc-65536',10,202611169905,['cpuUs','instructions','throughput','allocsPerRequest','bytesPerRequest'],[('head-llgo','old-sdk-head-llgo')],[None])
interp=analyze(p/'interpreter-counters',6,202611169907,['cpuNs','instructions','cycles','cyclesPerInstruction'],[('head-go','base-go'),('head-llgo','base-llgo')],['core/integer-loop','core/memory-load-store','memory/float64-unaligned'])
(p/'analysis.json').write_text(json.dumps(dict(sdkNoGC=sdk,interpreterCounters=interp),indent=2)+'\n');print('Checked separate184 diagnostic processes.')
