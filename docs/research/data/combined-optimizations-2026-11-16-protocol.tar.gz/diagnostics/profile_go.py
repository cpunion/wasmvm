from pathlib import Path
import json,subprocess,os,hashlib
w=Path('/Users/lijie/source/goplus/wasmvm-source-cleanup');d=Path(__file__).resolve().parent
s=(w/'benchmarks/p3io/main.go').read_text().replace('"runtime"','"runtime"\n "runtime/pprof"')
needle='\tfor i := range args.Samples {'
assert s.count(needle)==1
s=s.replace(needle,'\tif path := os.Getenv("WASMVM_DIAGNOSTIC_CPU"); path != "" {\n        f, e := os.Create(path); if e != nil { return out, e }\n        if e = pprof.StartCPUProfile(f); e != nil { _ = f.Close(); return out, e }\n        defer func(){ pprof.StopCPUProfile(); _ = f.Close() }()\n    }\n    if path := os.Getenv("WASMVM_DIAGNOSTIC_ALLOCS"); path != "" {\n        runtime.MemProfileRate = 1\n        defer func(){ runtime.GC(); f, e := os.Create(path); if e != nil { panic(e) }; defer f.Close(); if e = pprof.Lookup("allocs").WriteTo(f, 0); e != nil { panic(e) } }()\n    }\n'+needle)
source=d/'profile-main.go';source.write_text(s);overlay=d/'profile-overlay.json';overlay.write_text(json.dumps({'Replace':{str(w/'benchmarks/p3io/main.go'):str(source)}}));binary=d/'go-p3-profile'
env=dict(os.environ,PATH='/opt/homebrew/Cellar/go/1.27.3/libexec/bin:/opt/homebrew/opt/llvm@22/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',GOTOOLCHAIN='local',GOWORK='off',GOFLAGS='-mod=readonly',GOMAXPROCS='4',CGO_ENABLED='1',CC='/opt/homebrew/opt/llvm@22/bin/clang')
command=['go','build','-overlay',str(overlay),'-o',str(binary),'.']
with (d/'profile-build.log').open('w')as f:subprocess.run(command,cwd=w/'benchmarks/p3io',env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
for kind,samples in [('CPU',512),('ALLOCS',4)]:
 path=d/('go16-'+kind.lower()+'.pb.gz');e=dict(env);e['WASMVM_DIAGNOSTIC_'+kind]=str(path)
 cmd=[str(binary),'--engine','wasmvm','--backend','native','--wasm',str(w/'pkg/wasi/preview3/testdata/world-rust-http.wasm'),'--response-mode','buffered','--request-mode','snapshot','--payload-bytes','16','--expected','1757737011','--workers','4','--clients','16','--requests','32','--samples',str(samples),'--warmups','2']
 with (d/(kind.lower()+'-output.jsonl')).open('w')as f:subprocess.run(cmd,env=e,input='run\n',text=True,stdout=f,stderr=subprocess.PIPE,check=True,timeout=180)
 print('profile completed',kind,flush=True)
(d/'profile-provenance.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'binarySha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'overlaySha256':hashlib.sha256(source.read_bytes()).hexdigest(),'scope':'Diagnostic Go CPU/managed allocation attribution only. Profiled timing is excluded from the frozen campaign.'},indent=2)+'\n')
