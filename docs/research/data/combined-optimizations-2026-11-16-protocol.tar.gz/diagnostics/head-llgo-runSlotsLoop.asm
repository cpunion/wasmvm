
artifacts/combined-optimizations-20261116/head-llgo-phase:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010002f884 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop>:
10002f884: a9ba6ffc    	stp	x28, x27, [sp, #-0x60]!
10002f888: a90167fa    	stp	x26, x25, [sp, #0x10]
10002f88c: a9025ff8    	stp	x24, x23, [sp, #0x20]
10002f890: a90357f6    	stp	x22, x21, [sp, #0x30]
10002f894: a9044ff4    	stp	x20, x19, [sp, #0x40]
10002f898: a9057bfd    	stp	x29, x30, [sp, #0x50]
10002f89c: 910143fd    	add	x29, sp, #0x50
10002f8a0: d10743ff    	sub	sp, sp, #0x1d0
10002f8a4: f9402408    	ldr	x8, [x0, #0x48]
10002f8a8: f100051f    	cmp	x8, #0x1
10002f8ac: 540100cb    	b.lt	0x1000318c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
10002f8b0: 3940801a    	ldrb	w26, [x0, #0x20]
10002f8b4: aa0003f5    	mov	x21, x0
10002f8b8: aa0103f4    	mov	x20, x1
10002f8bc: b90017fa    	str	w26, [sp, #0x14]
10002f8c0: f94022a9    	ldr	x9, [x21, #0x40]
10002f8c4: 8b081928    	add	x8, x9, x8, lsl #6
10002f8c8: f85c010a    	ldur	x10, [x8, #-0x40]
10002f8cc: 381d011f    	sturb	wzr, [x8, #-0x30]
10002f8d0: f9000fe8    	str	x8, [sp, #0x18]
10002f8d4: f85d8108    	ldur	x8, [x8, #-0x28]
10002f8d8: f94046a2    	ldr	x2, [x21, #0x88]
10002f8dc: f9402550    	ldr	x16, [x10, #0x48]
10002f8e0: f9404e13    	ldr	x19, [x16, #0x98]
10002f8e4: 8b080269    	add	x9, x19, x8
10002f8e8: eb02013f    	cmp	x9, x2
10002f8ec: 5400f848    	b.hi	0x1000317f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f70>
10002f8f0: eb09011f    	cmp	x8, x9
10002f8f4: 5400f888    	b.hi	0x100031804 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f80>
10002f8f8: f9400fe9    	ldr	x9, [sp, #0x18]
10002f8fc: f9405e16    	ldr	x22, [x16, #0xb8]
10002f900: b85c8120    	ldur	w0, [x9, #-0x38]
10002f904: cb080049    	sub	x9, x2, x8
10002f908: d37ced08    	lsl	x8, x8, #4
10002f90c: f100013f    	cmp	x9, #0x0
10002f910: 9a9fc108    	csel	x8, x8, xzr, gt
10002f914: eb0002df    	cmp	x22, x0
10002f918: 5400f5a9    	b.ls	0x1000317cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
10002f91c: f9403ea9    	ldr	x9, [x21, #0x78]
10002f920: f9405a1c    	ldr	x28, [x16, #0xb0]
10002f924: 2a0003f8    	mov	w24, w0
10002f928: f90007ea    	str	x10, [sp, #0x8]
10002f92c: f940214a    	ldr	x10, [x10, #0x40]
10002f930: 8b080137    	add	x23, x9, x8
10002f934: a90243ea    	stp	x10, x16, [sp, #0x20]
10002f938: 14000006    	b	0x10002f950 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xcc>
10002f93c: 1100071b    	add	w27, w24, #0x1
10002f940: 2a1b03e0    	mov	w0, w27
10002f944: 2a1b03f8    	mov	w24, w27
10002f948: eb0002df    	cmp	x22, x0
10002f94c: 5400f409    	b.ls	0x1000317cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f48>
10002f950: 8b00179b    	add	x27, x28, x0, lsl #5
10002f954: 3600021a    	tbz	w26, #0x0, 0x10002f994 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x110>
10002f958: f9404201    	ldr	x1, [x16, #0x80]
10002f95c: b9400760    	ldr	w0, [x27, #0x4]
10002f960: eb00003f    	cmp	x1, x0
10002f964: 5400f369    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002f968: 52801c09    	mov	w9, #0xe0               ; =224
10002f96c: f9403e08    	ldr	x8, [x16, #0x78]
10002f970: 9ba92019    	umaddl	x25, w0, w9, x8
10002f974: b9400328    	ldr	w8, [x25]
10002f978: 7100151f    	cmp	w8, #0x5
10002f97c: 7a4b1904    	ccmp	w8, #0xb, #0x4, ne
10002f980: f940aaa8    	ldr	x8, [x21, #0x150]
10002f984: 1a9f07e9    	cset	w9, ne
10002f988: eb090108    	subs	x8, x8, x9
10002f98c: 5400e5a3    	b.lo	0x100031640 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dbc>
10002f990: f900aaa8    	str	x8, [x21, #0x150]
10002f994: 91000694    	add	x20, x20, #0x1
10002f998: f240169f    	tst	x20, #0x3f
10002f99c: 54000441    	b.ne	0x10002fa24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002f9a0: f940b2a8    	ldr	x8, [x21, #0x160]
10002f9a4: b4000088    	cbz	x8, 0x10002f9b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x130>
10002f9a8: b40002b5    	cbz	x21, 0x10002f9fc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x178>
10002f9ac: 88dffd08    	ldar	w8, [x8]
10002f9b0: 34000308    	cbz	w8, 0x10002fa10 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x18c>
10002f9b4: f94006a8    	ldr	x8, [x21, #0x8]
10002f9b8: b400f7a8    	cbz	x8, 0x1000318ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
10002f9bc: f9400509    	ldr	x9, [x8, #0x8]
10002f9c0: f9400aa0    	ldr	x0, [x21, #0x10]
10002f9c4: 39405d29    	ldrb	w9, [x9, #0x17]
10002f9c8: 1200112a    	and	w10, w9, #0x1f
10002f9cc: 121b0129    	and	w9, w9, #0x20
10002f9d0: 7100595f    	cmp	w10, #0x16
10002f9d4: 7a401924    	ccmp	w9, #0x0, #0x4, ne
10002f9d8: 54000060    	b.eq	0x10002f9e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x160>
10002f9dc: f81883a0    	stur	x0, [x29, #-0x78]
10002f9e0: d101e3a0    	sub	x0, x29, #0x78
10002f9e4: f9401508    	ldr	x8, [x8, #0x28]
10002f9e8: d63f0100    	blr	x8
10002f9ec: f94017f0    	ldr	x16, [sp, #0x28]
10002f9f0: aa0103e2    	mov	x2, x1
10002f9f4: b5000140    	cbnz	x0, 0x10002fa1c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
10002f9f8: 1400000b    	b	0x10002fa24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002f9fc: 52800020    	mov	w0, #0x1                ; =1
10002fa00: 9407c05a    	bl	0x10021fb68 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10002fa04: f94017f0    	ldr	x16, [sp, #0x28]
10002fa08: b50000a0    	cbnz	x0, 0x10002fa1c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x198>
10002fa0c: 14000006    	b	0x10002fa24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002fa10: aa1f03e0    	mov	x0, xzr
10002fa14: aa1f03e2    	mov	x2, xzr
10002fa18: 14000003    	b	0x10002fa24 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a0>
10002fa1c: f9400408    	ldr	x8, [x0, #0x8]
10002fa20: b500e348    	cbnz	x8, 0x100031688 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
10002fa24: b9401f68    	ldr	w8, [x27, #0x1c]
10002fa28: 340003e8    	cbz	w8, 0x10002faa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fa2c: 360000fa    	tbz	w26, #0x0, 0x10002fa48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
10002fa30: b9400369    	ldr	w9, [x27]
10002fa34: 7100813f    	cmp	w9, #0x20
10002fa38: 54000360    	b.eq	0x10002faa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fa3c: 7101053f    	cmp	w9, #0x41
10002fa40: 54000320    	b.eq	0x10002faa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fa44: 14000019    	b	0x10002faa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002fa48: b9400369    	ldr	w9, [x27]
10002fa4c: 7100813f    	cmp	w9, #0x20
10002fa50: 54000060    	b.eq	0x10002fa5c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8>
10002fa54: 7101053f    	cmp	w9, #0x41
10002fa58: 54000281    	b.ne	0x10002faa8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x224>
10002fa5c: 2a3403e8    	mvn	w8, w20
10002fa60: f240151f    	tst	x8, #0x3f
10002fa64: 54000200    	b.eq	0x10002faa4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x220>
10002fa68: 7101053f    	cmp	w9, #0x41
10002fa6c: 540000e1    	b.ne	0x10002fa88 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x204>
10002fa70: b9400b60    	ldr	w0, [x27, #0x8]
10002fa74: eb00027f    	cmp	x19, x0
10002fa78: 5400ea09    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fa7c: b9401b68    	ldr	w8, [x27, #0x18]
10002fa80: 8b0012e9    	add	x9, x23, x0, lsl #4
10002fa84: a9007d28    	stp	x8, xzr, [x9]
10002fa88: 11000718    	add	w24, w24, #0x1
10002fa8c: eb1802df    	cmp	x22, x24
10002fa90: 5400e8e9    	b.ls	0x1000317ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f28>
10002fa94: 8b18179b    	add	x27, x28, x24, lsl #5
10002fa98: 91000694    	add	x20, x20, #0x1
10002fa9c: b9401f68    	ldr	w8, [x27, #0x1c]
10002faa0: 35fffd48    	cbnz	w8, 0x10002fa48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c4>
10002faa4: b9400369    	ldr	w9, [x27]
10002faa8: 529fe40a    	mov	w10, #0xff20            ; =65312
10002faac: 51038128    	sub	w8, w9, #0xe0
10002fab0: 72a01fea    	movk	w10, #0xff, lsl #16
10002fab4: 6b0a011f    	cmp	w8, w10
10002fab8: 54000482    	b.hs	0x10002fb48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2c4>
10002fabc: 53107d28    	lsr	w8, w9, #16
10002fac0: 7103ed1f    	cmp	w8, #0xfb
10002fac4: 54000ea0    	b.eq	0x10002fc98 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x414>
10002fac8: 7103f11f    	cmp	w8, #0xfc
10002facc: 540006a0    	b.eq	0x10002fba0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x31c>
10002fad0: 7103f51f    	cmp	w8, #0xfd
10002fad4: 54001361    	b.ne	0x10002fd40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4bc>
10002fad8: b9400f60    	ldr	w0, [x27, #0xc]
10002fadc: 3100041f    	cmn	w0, #0x1
10002fae0: 54002100    	b.eq	0x10002ff00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x67c>
10002fae4: eb00027f    	cmp	x19, x0
10002fae8: 5400e689    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002faec: 8b0012e8    	add	x8, x23, x0, lsl #4
10002faf0: a9402102    	ldp	x2, x8, [x8]
10002faf4: b9401360    	ldr	w0, [x27, #0x10]
10002faf8: 3100041f    	cmn	w0, #0x1
10002fafc: 540020c0    	b.eq	0x10002ff14 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x690>
10002fb00: eb00027f    	cmp	x19, x0
10002fb04: 5400e5a9    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fb08: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fb0c: 3d801be0    	str	q0, [sp, #0x60]
10002fb10: a9461be5    	ldp	x5, x6, [sp, #0x60]
10002fb14: b9401760    	ldr	w0, [x27, #0x14]
10002fb18: 3100041f    	cmn	w0, #0x1
10002fb1c: 54002060    	b.eq	0x10002ff28 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6a4>
10002fb20: eb00027f    	cmp	x19, x0
10002fb24: 5400e4a9    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fb28: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fb2c: 3d801fe0    	str	q0, [sp, #0x70]
10002fb30: a9472fea    	ldp	x10, x11, [sp, #0x70]
10002fb34: f9404201    	ldr	x1, [x16, #0x80]
10002fb38: b9400760    	ldr	w0, [x27, #0x4]
10002fb3c: eb00003f    	cmp	x1, x0
10002fb40: 54002008    	b.hi	0x10002ff40 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6bc>
10002fb44: 14000723    	b	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fb48: 51011528    	sub	w8, w9, #0x45
10002fb4c: 7102011f    	cmp	w8, #0x80
10002fb50: 54000fc2    	b.hs	0x10002fd48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
10002fb54: 7101fd1f    	cmp	w8, #0x7f
10002fb58: 5400bb88    	b.hi	0x1000312c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a44>
10002fb5c: f000102c    	adrp	x12, 0x100236000 <dyld_stub_binder+0x100236000>
10002fb60: 9121818c    	add	x12, x12, #0x860
10002fb64: 1000008a    	adr	x10, 0x10002fb74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
10002fb68: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
10002fb6c: 8b0b094a    	add	x10, x10, x11, lsl #2
10002fb70: d61f0140    	br	x10
10002fb74: b9401360    	ldr	w0, [x27, #0x10]
10002fb78: 3100041f    	cmn	w0, #0x1
10002fb7c: 54003d00    	b.eq	0x10003031c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa98>
10002fb80: eb00027f    	cmp	x19, x0
10002fb84: 5400e2a9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fb88: d37cec08    	lsl	x8, x0, #4
10002fb8c: f8686ae2    	ldr	x2, [x23, x8]
10002fb90: b9400f60    	ldr	w0, [x27, #0xc]
10002fb94: eb00027f    	cmp	x19, x0
10002fb98: 54003ca8    	b.hi	0x10003032c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xaa8>
10002fb9c: 1400070f    	b	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fba0: 529ffda8    	mov	w8, #0xffed             ; =65517
10002fba4: 72bfe068    	movk	w8, #0xff03, lsl #16
10002fba8: 0b08012d    	add	w13, w9, w8
10002fbac: 710011bf    	cmp	w13, #0x4
10002fbb0: 54000cc2    	b.hs	0x10002fd48 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4c4>
10002fbb4: 29430368    	ldp	w8, w0, [x27, #0x18]
10002fbb8: f9406e02    	ldr	x2, [x16, #0xd8]
10002fbbc: 0b00010a    	add	w10, w8, w0
10002fbc0: 1100094a    	add	w10, w10, #0x2
10002fbc4: eb0a005f    	cmp	x2, x10
10002fbc8: 5400e483    	b.lo	0x100031858 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fd4>
10002fbcc: 6b0a011f    	cmp	w8, w10
10002fbd0: 5400e3a8    	b.hi	0x100031844 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fc0>
10002fbd4: cb08004b    	sub	x11, x2, x8
10002fbd8: d37ef50c    	lsl	x12, x8, #2
10002fbdc: f100017f    	cmp	x11, #0x0
10002fbe0: 9a9fc18b    	csel	x11, x12, xzr, gt
10002fbe4: 6b08015f    	cmp	w10, w8
10002fbe8: 5400e280    	b.eq	0x100031838 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fb4>
10002fbec: f940660c    	ldr	x12, [x16, #0xc8]
10002fbf0: 8b0b018c    	add	x12, x12, x11
10002fbf4: b940018b    	ldr	w11, [x12]
10002fbf8: eb0b027f    	cmp	x19, x11
10002fbfc: 5400e0e9    	b.ls	0x100031818 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f94>
10002fc00: cb080141    	sub	x1, x10, x8
10002fc04: f100043f    	cmp	x1, #0x1
10002fc08: 5400e140    	b.eq	0x100031830 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fac>
10002fc0c: b9400588    	ldr	w8, [x12, #0x4]
10002fc10: eb08027f    	cmp	x19, x8
10002fc14: 5400de09    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002fc18: d37ced6a    	lsl	x10, x11, #4
10002fc1c: d37ced08    	lsl	x8, x8, #4
10002fc20: 710009bf    	cmp	w13, #0x2
10002fc24: f86a6aef    	ldr	x15, [x23, x10]
10002fc28: f8686aee    	ldr	x14, [x23, x8]
10002fc2c: 54002062    	b.hs	0x100030038 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7b4>
10002fc30: f1000c3f    	cmp	x1, #0x3
10002fc34: 5400e303    	b.lo	0x100031894 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2010>
10002fc38: b9400988    	ldr	w8, [x12, #0x8]
10002fc3c: eb08027f    	cmp	x19, x8
10002fc40: 5400dca9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002fc44: f1000c3f    	cmp	x1, #0x3
10002fc48: 5400e220    	b.eq	0x10003188c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2008>
10002fc4c: b9400d8a    	ldr	w10, [x12, #0xc]
10002fc50: eb0a027f    	cmp	x19, x10
10002fc54: 5400dca9    	b.ls	0x1000317e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
10002fc58: d37ced08    	lsl	x8, x8, #4
10002fc5c: d37ced4a    	lsl	x10, x10, #4
10002fc60: f8686aeb    	ldr	x11, [x23, x8]
10002fc64: f86a6ae8    	ldr	x8, [x23, x10]
10002fc68: 5280026a    	mov	w10, #0x13              ; =19
10002fc6c: 72a01f8a    	movk	w10, #0xfc, lsl #16
10002fc70: 6b0a013f    	cmp	w9, w10
10002fc74: 54002c01    	b.ne	0x1000301f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x970>
10002fc78: 8b0f016a    	add	x10, x11, x15
10002fc7c: aa0f0169    	orr	x9, x11, x15
10002fc80: 8a0f016b    	and	x11, x11, x15
10002fc84: 8a2a0129    	bic	x9, x9, x10
10002fc88: 8b0e0108    	add	x8, x8, x14
10002fc8c: aa0b0129    	orr	x9, x9, x11
10002fc90: 8b49fd0b    	add	x11, x8, x9, lsr #63
10002fc94: 1400015f    	b	0x100030210 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
10002fc98: 51000928    	sub	w8, w9, #0x2
10002fc9c: 12003d09    	and	w9, w8, #0xffff
10002fca0: 7100853f    	cmp	w9, #0x21
10002fca4: d287c1e9    	mov	x9, #0x3e0f             ; =15887
10002fca8: f2a38009    	movk	x9, #0x1c00, lsl #16
10002fcac: 1a9f27ea    	cset	w10, lo
10002fcb0: f2c00029    	movk	x9, #0x1, lsl #32
10002fcb4: 9ac82529    	lsr	x9, x9, x8
10002fcb8: 0a090149    	and	w9, w10, w9
10002fcbc: 36001129    	tbz	w9, #0x0, 0x10002fee0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x65c>
10002fcc0: b9400f60    	ldr	w0, [x27, #0xc]
10002fcc4: 3100041f    	cmn	w0, #0x1
10002fcc8: 540020e0    	b.eq	0x1000300e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x860>
10002fccc: eb00027f    	cmp	x19, x0
10002fcd0: 5400d749    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fcd4: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fcd8: 3d800fe0    	str	q0, [sp, #0x30]
10002fcdc: a94313e3    	ldp	x3, x4, [sp, #0x30]
10002fce0: b9401360    	ldr	w0, [x27, #0x10]
10002fce4: 3100041f    	cmn	w0, #0x1
10002fce8: 54002080    	b.eq	0x1000300f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x874>
10002fcec: eb00027f    	cmp	x19, x0
10002fcf0: 5400d649    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fcf4: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fcf8: 3d8013e0    	str	q0, [sp, #0x40]
10002fcfc: a9441be5    	ldp	x5, x6, [sp, #0x40]
10002fd00: 12003d08    	and	w8, w8, #0xffff
10002fd04: 7100311f    	cmp	w8, #0xc
10002fd08: 54002021    	b.ne	0x10003010c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x888>
10002fd0c: b9401b68    	ldr	w8, [x27, #0x18]
10002fd10: f9406a01    	ldr	x1, [x16, #0xd0]
10002fd14: 11000900    	add	w0, w8, #0x2
10002fd18: eb00003f    	cmp	x1, x0
10002fd1c: 5400d5a9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fd20: f9406608    	ldr	x8, [x16, #0xc8]
10002fd24: b8607900    	ldr	w0, [x8, x0, lsl #2]
10002fd28: eb00027f    	cmp	x19, x0
10002fd2c: 5400d469    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
10002fd30: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
10002fd34: 3d8017e0    	str	q0, [sp, #0x50]
10002fd38: a94527e7    	ldp	x7, x9, [sp, #0x50]
10002fd3c: 140000f6    	b	0x100030114 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x890>
10002fd40: 71039d3f    	cmp	w9, #0xe7
10002fd44: 5400c3e3    	b.lo	0x1000315c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
10002fd48: 51000528    	sub	w8, w9, #0x1
10002fd4c: 71034d1f    	cmp	w8, #0xd3
10002fd50: 540005c8    	b.hi	0x10002fe08 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x584>
10002fd54: f000102c    	adrp	x12, 0x100236000 <dyld_stub_binder+0x100236000>
10002fd58: 9125818c    	add	x12, x12, #0x960
10002fd5c: aa1f03e0    	mov	x0, xzr
10002fd60: 100000aa    	adr	x10, 0x10002fd74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x4f0>
10002fd64: 7868798b    	ldrh	w11, [x12, x8, lsl #1]
10002fd68: 8b0b094a    	add	x10, x10, x11, lsl #2
10002fd6c: aa1f03e1    	mov	x1, xzr
10002fd70: d61f0140    	br	x10
10002fd74: f9404201    	ldr	x1, [x16, #0x80]
10002fd78: b9400760    	ldr	w0, [x27, #0x4]
10002fd7c: eb00003f    	cmp	x1, x0
10002fd80: 5400d289    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fd84: 52801c0a    	mov	w10, #0xe0              ; =224
10002fd88: f9403e08    	ldr	x8, [x16, #0x78]
10002fd8c: 9baa200a    	umaddl	x10, w0, w10, x8
10002fd90: b400c50a    	cbz	x10, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fd94: f94013e8    	ldr	x8, [sp, #0x20]
10002fd98: b9401940    	ldr	w0, [x10, #0x18]
10002fd9c: f9403d01    	ldr	x1, [x8, #0x78]
10002fda0: eb00003f    	cmp	x1, x0
10002fda4: 5400d169    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fda8: f9403908    	ldr	x8, [x8, #0x70]
10002fdac: ab000d08    	adds	x8, x8, x0, lsl #3
10002fdb0: 5400c400    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fdb4: f940010b    	ldr	x11, [x8]
10002fdb8: b400c3cb    	cbz	x11, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fdbc: b9400f68    	ldr	w8, [x27, #0xc]
10002fdc0: eb08027f    	cmp	x19, x8
10002fdc4: 5400d089    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002fdc8: f9400960    	ldr	x0, [x11, #0x10]
10002fdcc: d37ced08    	lsl	x8, x8, #4
10002fdd0: b940154b    	ldr	w11, [x10, #0x14]
10002fdd4: b9401d4a    	ldr	w10, [x10, #0x1c]
10002fdd8: f940200c    	ldr	x12, [x0, #0x40]
10002fddc: f8686ae2    	ldr	x2, [x23, x8]
10002fde0: aa0a8163    	orr	x3, x11, x10, lsl #32
10002fde4: b400006c    	cbz	x12, 0x10002fdf0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x56c>
10002fde8: f9403008    	ldr	x8, [x0, #0x60]
10002fdec: b4001d28    	cbz	x8, 0x100030190 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x90c>
10002fdf0: d101e3a8    	sub	x8, x29, #0x78
10002fdf4: 2a0903e1    	mov	w1, w9
10002fdf8: 2a1f03e4    	mov	w4, wzr
10002fdfc: aa1f03e5    	mov	x5, xzr
10002fe00: aa1f03e6    	mov	x6, xzr
10002fe04: 14000071    	b	0x10002ffc8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x744>
10002fe08: 517f0128    	sub	w8, w9, #0xfc0, lsl #12 ; =0xfc0000
10002fe0c: 7100211f    	cmp	w8, #0x8
10002fe10: 54000e22    	b.hs	0x10002ffd4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x750>
10002fe14: b9400f60    	ldr	w0, [x27, #0xc]
10002fe18: eb00027f    	cmp	x19, x0
10002fe1c: 5400cde9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10002fe20: d37cec08    	lsl	x8, x0, #4
10002fe24: 2a0903e0    	mov	w0, w9
10002fe28: aa1f03e2    	mov	x2, xzr
10002fe2c: f8686ae1    	ldr	x1, [x23, x8]
10002fe30: 94009887    	bl	0x10005604c <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10002fe34: aa0103f9    	mov	x25, x1
10002fe38: aa1f03e1    	mov	x1, xzr
10002fe3c: 140000e3    	b	0x1000301c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
10002fe40: f9404201    	ldr	x1, [x16, #0x80]
10002fe44: b9400760    	ldr	w0, [x27, #0x4]
10002fe48: eb00003f    	cmp	x1, x0
10002fe4c: 5400cc29    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fe50: 52801c0a    	mov	w10, #0xe0              ; =224
10002fe54: f9403e08    	ldr	x8, [x16, #0x78]
10002fe58: 9baa200b    	umaddl	x11, w0, w10, x8
10002fe5c: b400beab    	cbz	x11, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fe60: f94013e8    	ldr	x8, [sp, #0x20]
10002fe64: b9401960    	ldr	w0, [x11, #0x18]
10002fe68: f9403d01    	ldr	x1, [x8, #0x78]
10002fe6c: eb00003f    	cmp	x1, x0
10002fe70: 5400cb09    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002fe74: f9403908    	ldr	x8, [x8, #0x70]
10002fe78: ab000d08    	adds	x8, x8, x0, lsl #3
10002fe7c: 5400bda0    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fe80: f940010c    	ldr	x12, [x8]
10002fe84: b400bd6c    	cbz	x12, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002fe88: b9400f68    	ldr	w8, [x27, #0xc]
10002fe8c: eb08027f    	cmp	x19, x8
10002fe90: 5400ca29    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10002fe94: b940136a    	ldr	w10, [x27, #0x10]
10002fe98: eb0a027f    	cmp	x19, x10
10002fe9c: 5400ca69    	b.ls	0x1000317e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f64>
10002fea0: f9400980    	ldr	x0, [x12, #0x10]
10002fea4: b940156c    	ldr	w12, [x11, #0x14]
10002fea8: d37ced08    	lsl	x8, x8, #4
10002feac: b9401d6b    	ldr	w11, [x11, #0x1c]
10002feb0: d37ced4a    	lsl	x10, x10, #4
10002feb4: f940200d    	ldr	x13, [x0, #0x40]
10002feb8: f8686ae2    	ldr	x2, [x23, x8]
10002febc: aa0b8183    	orr	x3, x12, x11, lsl #32
10002fec0: f86a6ae5    	ldr	x5, [x23, x10]
10002fec4: b400006d    	cbz	x13, 0x10002fed0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x64c>
10002fec8: f9403008    	ldr	x8, [x0, #0x60]
10002fecc: b4001fa8    	cbz	x8, 0x1000302c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa3c>
10002fed0: 2a0903e1    	mov	w1, w9
10002fed4: 2a1f03e4    	mov	w4, wzr
10002fed8: aa1f03e6    	mov	x6, xzr
10002fedc: 1400007c    	b	0x1000300cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x848>
10002fee0: f9400fe8    	ldr	x8, [sp, #0x18]
10002fee4: aa1503e0    	mov	x0, x21
10002fee8: b81c8118    	stur	w24, [x8, #-0x38]
10002feec: 94000701    	bl	0x100031af0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC>
10002fef0: f94017f0    	ldr	x16, [sp, #0x28]
10002fef4: 72001c1f    	tst	w0, #0xff
10002fef8: 54001420    	b.eq	0x10003017c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
10002fefc: 140005e6    	b	0x100031694 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
10002ff00: aa1f03e8    	mov	x8, xzr
10002ff04: aa1f03e2    	mov	x2, xzr
10002ff08: b9401360    	ldr	w0, [x27, #0x10]
10002ff0c: 3100041f    	cmn	w0, #0x1
10002ff10: 54ffdf81    	b.ne	0x10002fb00 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x27c>
10002ff14: aa1f03e5    	mov	x5, xzr
10002ff18: aa1f03e6    	mov	x6, xzr
10002ff1c: b9401760    	ldr	w0, [x27, #0x14]
10002ff20: 3100041f    	cmn	w0, #0x1
10002ff24: 54ffdfe1    	b.ne	0x10002fb20 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x29c>
10002ff28: aa1f03ea    	mov	x10, xzr
10002ff2c: aa1f03eb    	mov	x11, xzr
10002ff30: f9404201    	ldr	x1, [x16, #0x80]
10002ff34: b9400760    	ldr	w0, [x27, #0x4]
10002ff38: eb00003f    	cmp	x1, x0
10002ff3c: 5400c4a9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
10002ff40: 52801c0d    	mov	w13, #0xe0              ; =224
10002ff44: f9403e0c    	ldr	x12, [x16, #0x78]
10002ff48: 9bad3000    	umaddl	x0, w0, w13, x12
10002ff4c: b400b720    	cbz	x0, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ff50: 121e352c    	and	w12, w9, #0xfffc
10002ff54: 12003d2d    	and	w13, w9, #0xffff
10002ff58: 7101519f    	cmp	w12, #0x54
10002ff5c: 7a4b19a0    	ccmp	w13, #0xb, #0x0, ne
10002ff60: 54000083    	b.lo	0x10002ff70 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x6ec>
10002ff64: 510171ae    	sub	w14, w13, #0x5c
10002ff68: 710009df    	cmp	w14, #0x2
10002ff6c: 540007e2    	b.hs	0x100030068 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7e4>
10002ff70: f94013ea    	ldr	x10, [sp, #0x20]
10002ff74: b9401808    	ldr	w8, [x0, #0x18]
10002ff78: f9403d41    	ldr	x1, [x10, #0x78]
10002ff7c: eb08003f    	cmp	x1, x8
10002ff80: 5400c309    	b.ls	0x1000317e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10002ff84: f940394a    	ldr	x10, [x10, #0x70]
10002ff88: ab080d48    	adds	x8, x10, x8, lsl #3
10002ff8c: 5400b520    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ff90: f9400108    	ldr	x8, [x8]
10002ff94: b400b4e8    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10002ff98: f940090a    	ldr	x10, [x8, #0x10]
10002ff9c: b9401408    	ldr	w8, [x0, #0x14]
10002ffa0: b9401c0b    	ldr	w11, [x0, #0x1c]
10002ffa4: 39410004    	ldrb	w4, [x0, #0x40]
10002ffa8: f940214c    	ldr	x12, [x10, #0x40]
10002ffac: aa0b8103    	orr	x3, x8, x11, lsl #32
10002ffb0: b400006c    	cbz	x12, 0x10002ffbc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x738>
10002ffb4: f9403148    	ldr	x8, [x10, #0x60]
10002ffb8: b4000f88    	cbz	x8, 0x1000301a8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x924>
10002ffbc: d101e3a8    	sub	x8, x29, #0x78
10002ffc0: aa0a03e0    	mov	x0, x10
10002ffc4: 2a0903e1    	mov	w1, w9
10002ffc8: d101e3ba    	sub	x26, x29, #0x78
10002ffcc: 94007846    	bl	0x10004e0e4 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).load>
10002ffd0: 1400007b    	b	0x1000301bc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x938>
10002ffd4: 12a02008    	mov	w8, #-0x1000001         ; =-16777217
10002ffd8: 0b080128    	add	w8, w9, w8
10002ffdc: 7100211f    	cmp	w8, #0x8
10002ffe0: 54003dc8    	b.hi	0x100030798 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf14>
10002ffe4: 528022ea    	mov	w10, #0x117             ; =279
10002ffe8: 1ac8254a    	lsr	w10, w10, w8
10002ffec: 36003cea    	tbz	w10, #0x0, 0x100030788 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf04>
10002fff0: 12001d29    	and	w9, w9, #0xff
10002fff4: 2a1f03e8    	mov	w8, wzr
10002fff8: 7100113f    	cmp	w9, #0x4
10002fffc: 540016ac    	b.gt	0x1000302d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xa4c>
100030000: 7100093f    	cmp	w9, #0x2
100030004: 54001a80    	b.eq	0x100030354 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xad0>
100030008: 71000d3f    	cmp	w9, #0x3
10003000c: 540036e1    	b.ne	0x1000306e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
100030010: b9400f60    	ldr	w0, [x27, #0xc]
100030014: eb00027f    	cmp	x19, x0
100030018: 5400be09    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003001c: d37cec08    	lsl	x8, x0, #4
100030020: b9401f69    	ldr	w9, [x27, #0x1c]
100030024: b8686ae8    	ldr	w8, [x23, x8]
100030028: 51000529    	sub	w9, w9, #0x1
10003002c: 6b08013f    	cmp	w9, w8
100030030: 1a883128    	csel	w8, w9, w8, lo
100030034: 140001ad    	b	0x1000306e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
100030038: 9bcf7dcb    	umulh	x11, x14, x15
10003003c: 52800268    	mov	w8, #0x13               ; =19
100030040: 72a01f88    	movk	w8, #0xfc, lsl #16
100030044: 9b0f7dca    	mul	x10, x14, x15
100030048: 11000908    	add	w8, w8, #0x2
10003004c: 6b08013f    	cmp	w9, w8
100030050: 54000e01    	b.ne	0x100030210 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
100030054: 8a8ffdc8    	and	x8, x14, x15, asr #63
100030058: 8a8efde9    	and	x9, x15, x14, asr #63
10003005c: 8b080128    	add	x8, x9, x8
100030060: cb08016b    	sub	x11, x11, x8
100030064: 1400006b    	b	0x100030210 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x98c>
100030068: 71002dbf    	cmp	w13, #0xb
10003006c: f94013ed    	ldr	x13, [sp, #0x20]
100030070: 54000060    	b.eq	0x10003007c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x7f8>
100030074: 7101619f    	cmp	w12, #0x58
100030078: 54001ca1    	b.ne	0x10003040c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb88>
10003007c: f9403da1    	ldr	x1, [x13, #0x78]
100030080: b9401808    	ldr	w8, [x0, #0x18]
100030084: eb08003f    	cmp	x1, x8
100030088: 5400bac9    	b.ls	0x1000317e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
10003008c: f94039aa    	ldr	x10, [x13, #0x70]
100030090: ab080d48    	adds	x8, x10, x8, lsl #3
100030094: 5400ace0    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030098: f9400108    	ldr	x8, [x8]
10003009c: b400aca8    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000300a0: f9400908    	ldr	x8, [x8, #0x10]
1000300a4: b940140a    	ldr	w10, [x0, #0x14]
1000300a8: b9401c0b    	ldr	w11, [x0, #0x1c]
1000300ac: 39410004    	ldrb	w4, [x0, #0x40]
1000300b0: f940210c    	ldr	x12, [x8, #0x40]
1000300b4: aa0b8143    	orr	x3, x10, x11, lsl #32
1000300b8: b400006c    	cbz	x12, 0x1000300c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x840>
1000300bc: f940310a    	ldr	x10, [x8, #0x60]
1000300c0: b400302a    	cbz	x10, 0x1000306c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe40>
1000300c4: aa0803e0    	mov	x0, x8
1000300c8: 2a0903e1    	mov	w1, w9
1000300cc: 94006e74    	bl	0x10004ba9c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).store>
1000300d0: 2a0003e8    	mov	w8, w0
1000300d4: aa1f03e0    	mov	x0, xzr
1000300d8: aa1f03e1    	mov	x1, xzr
1000300dc: 12001d19    	and	w25, w8, #0xff
1000300e0: 1400003a    	b	0x1000301c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
1000300e4: aa1f03e3    	mov	x3, xzr
1000300e8: aa1f03e4    	mov	x4, xzr
1000300ec: b9401360    	ldr	w0, [x27, #0x10]
1000300f0: 3100041f    	cmn	w0, #0x1
1000300f4: 54ffdfc1    	b.ne	0x10002fcec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x468>
1000300f8: aa1f03e5    	mov	x5, xzr
1000300fc: aa1f03e6    	mov	x6, xzr
100030100: 12003d08    	and	w8, w8, #0xffff
100030104: 7100311f    	cmp	w8, #0xc
100030108: 54ffe020    	b.eq	0x10002fd0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x488>
10003010c: aa1f03e7    	mov	x7, xzr
100030110: aa1f03e9    	mov	x9, xzr
100030114: b400a8f5    	cbz	x21, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030118: f9404201    	ldr	x1, [x16, #0x80]
10003011c: b9400760    	ldr	w0, [x27, #0x4]
100030120: eb00003f    	cmp	x1, x0
100030124: 5400b569    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030128: 52801c0a    	mov	w10, #0xe0              ; =224
10003012c: f9403e08    	ldr	x8, [x16, #0x78]
100030130: 9baa2002    	umaddl	x2, w0, w10, x8
100030134: b400a7e2    	cbz	x2, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030138: f94002a0    	ldr	x0, [x21]
10003013c: f94013e1    	ldr	x1, [sp, #0x20]
100030140: 910203e8    	add	x8, sp, #0x80
100030144: f90003e9    	str	x9, [sp]
100030148: 94002ed0    	bl	0x10003bc88 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess>
10003014c: f9404bf9    	ldr	x25, [sp, #0x90]
100030150: 3dc023e0    	ldr	q0, [sp, #0x80]
100030154: b4000079    	cbz	x25, 0x100030160 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8dc>
100030158: f9400728    	ldr	x8, [x25, #0x8]
10003015c: b500aa08    	cbnz	x8, 0x10003169c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e18>
100030160: b9400b60    	ldr	w0, [x27, #0x8]
100030164: f94017f0    	ldr	x16, [sp, #0x28]
100030168: 3100041f    	cmn	w0, #0x1
10003016c: 54000080    	b.eq	0x10003017c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x8f8>
100030170: eb00027f    	cmp	x19, x0
100030174: 5400b229    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030178: 3ca07ae0    	str	q0, [x23, x0, lsl #4]
10003017c: 1100071b    	add	w27, w24, #0x1
100030180: 14000034    	b	0x100030250 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x9cc>
100030184: f9400f60    	ldr	x0, [x27, #0x18]
100030188: aa1f03e1    	mov	x1, xzr
10003018c: 14000012    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030190: d101e3a8    	sub	x8, x29, #0x78
100030194: 2a0903e1    	mov	w1, w9
100030198: 2a1f03e4    	mov	w4, wzr
10003019c: aa1f03e5    	mov	x5, xzr
1000301a0: aa1f03e6    	mov	x6, xzr
1000301a4: 14000004    	b	0x1000301b4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x930>
1000301a8: d101e3a8    	sub	x8, x29, #0x78
1000301ac: aa0a03e0    	mov	x0, x10
1000301b0: 2a0903e1    	mov	w1, w9
1000301b4: d101e3ba    	sub	x26, x29, #0x78
1000301b8: 94007815    	bl	0x10004e20c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).loadLocked>
1000301bc: a9400740    	ldp	x0, x1, [x26]
1000301c0: 39404359    	ldrb	w25, [x26, #0x10]
1000301c4: b94017fa    	ldr	w26, [sp, #0x14]
1000301c8: f94017f0    	ldr	x16, [sp, #0x28]
1000301cc: 72001f3f    	tst	w25, #0xff
1000301d0: 5400a9a1    	b.ne	0x100031704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
1000301d4: b9400b68    	ldr	w8, [x27, #0x8]
1000301d8: 3100051f    	cmn	w8, #0x1
1000301dc: 54ffbb00    	b.eq	0x10002f93c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
1000301e0: eb08027f    	cmp	x19, x8
1000301e4: 5400aee9    	b.ls	0x1000317c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
1000301e8: 8b0812e8    	add	x8, x23, x8, lsl #4
1000301ec: a9000500    	stp	x0, x1, [x8]
1000301f0: 17fffdd3    	b	0x10002f93c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xb8>
1000301f4: cb0b01ea    	sub	x10, x15, x11
1000301f8: ca2b01e9    	eon	x9, x15, x11
1000301fc: 8a2f016b    	bic	x11, x11, x15
100030200: 8a090149    	and	x9, x10, x9
100030204: aa0b0129    	orr	x9, x9, x11
100030208: 8b49fd08    	add	x8, x8, x9, lsr #63
10003020c: cb0801cb    	sub	x11, x14, x8
100030210: eb00003f    	cmp	x1, x0
100030214: 5400ade9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030218: 11000408    	add	w8, w0, #0x1
10003021c: eb08003f    	cmp	x1, x8
100030220: 5400ae09    	b.ls	0x1000317e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
100030224: b8607989    	ldr	w9, [x12, x0, lsl #2]
100030228: eb09027f    	cmp	x19, x9
10003022c: 5400afc9    	b.ls	0x100031824 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fa0>
100030230: b8687980    	ldr	w0, [x12, x8, lsl #2]
100030234: 8b0912e8    	add	x8, x23, x9, lsl #4
100030238: eb00027f    	cmp	x19, x0
10003023c: a9007d0a    	stp	x10, xzr, [x8]
100030240: 5400acc9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030244: 8b0012e8    	add	x8, x23, x0, lsl #4
100030248: 1100071b    	add	w27, w24, #0x1
10003024c: a9007d0b    	stp	x11, xzr, [x8]
100030250: f9400fe8    	ldr	x8, [sp, #0x18]
100030254: b81c811b    	stur	w27, [x8, #-0x38]
100030258: 17fffdba    	b	0x10002f940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
10003025c: b9400f60    	ldr	w0, [x27, #0xc]
100030260: eb00027f    	cmp	x19, x0
100030264: 5400aaa9    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030268: b9401b68    	ldr	w8, [x27, #0x18]
10003026c: eb08027f    	cmp	x19, x8
100030270: 5400aa89    	b.ls	0x1000317c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
100030274: 8b0012e9    	add	x9, x23, x0, lsl #4
100030278: 3dc00120    	ldr	q0, [x9]
10003027c: f9400521    	ldr	x1, [x9, #0x8]
100030280: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
100030284: 9e660000    	fmov	x0, d0
100030288: 17ffffd3    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003028c: b9401760    	ldr	w0, [x27, #0x14]
100030290: eb00027f    	cmp	x19, x0
100030294: 5400aa29    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030298: d37cec08    	lsl	x8, x0, #4
10003029c: 52800209    	mov	w9, #0x10               ; =16
1000302a0: b8686ae8    	ldr	w8, [x23, x8]
1000302a4: 7100011f    	cmp	w8, #0x0
1000302a8: 52800188    	mov	w8, #0xc                ; =12
1000302ac: 9a880128    	csel	x8, x9, x8, eq
1000302b0: b8686b60    	ldr	w0, [x27, x8]
1000302b4: eb00027f    	cmp	x19, x0
1000302b8: 54001d48    	b.hi	0x100030660 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xddc>
1000302bc: 14000547    	b	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000302c0: 2a0903e1    	mov	w1, w9
1000302c4: 2a1f03e4    	mov	w4, wzr
1000302c8: aa1f03e6    	mov	x6, xzr
1000302cc: 14000100    	b	0x1000306cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe48>
1000302d0: 7100253f    	cmp	w9, #0x9
1000302d4: 54002061    	b.ne	0x1000306e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe5c>
1000302d8: b9400f60    	ldr	w0, [x27, #0xc]
1000302dc: eb00027f    	cmp	x19, x0
1000302e0: 5400a7c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000302e4: d37cec08    	lsl	x8, x0, #4
1000302e8: f8686ae8    	ldr	x8, [x23, x8]
1000302ec: f100011f    	cmp	x8, #0x0
1000302f0: 1a9f07e8    	cset	w8, ne
1000302f4: 140000fd    	b	0x1000306e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
1000302f8: b9400f60    	ldr	w0, [x27, #0xc]
1000302fc: eb00027f    	cmp	x19, x0
100030300: 5400a6c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030304: d37cec08    	lsl	x8, x0, #4
100030308: aa1f03e1    	mov	x1, xzr
10003030c: f8686ae8    	ldr	x8, [x23, x8]
100030310: f100011f    	cmp	x8, #0x0
100030314: 1a9f17e0    	cset	w0, eq
100030318: 17ffffaf    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003031c: aa1f03e2    	mov	x2, xzr
100030320: b9400f60    	ldr	w0, [x27, #0xc]
100030324: eb00027f    	cmp	x19, x0
100030328: 5400a589    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003032c: d37cec08    	lsl	x8, x0, #4
100030330: 2a0903e0    	mov	w0, w9
100030334: f8686ae1    	ldr	x1, [x23, x8]
100030338: 94009745    	bl	0x10005604c <_github.com/cpunion/wasmvm/internal/engine/numeric.Eval>
10003033c: aa0103f9    	mov	x25, x1
100030340: f94017f0    	ldr	x16, [sp, #0x28]
100030344: 72001f3f    	tst	w25, #0xff
100030348: 54009de1    	b.ne	0x100031704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
10003034c: aa1f03e1    	mov	x1, xzr
100030350: 17ffffa1    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030354: b9400f60    	ldr	w0, [x27, #0xc]
100030358: eb00027f    	cmp	x19, x0
10003035c: 5400a3e9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030360: d37cec08    	lsl	x8, x0, #4
100030364: b8686ae8    	ldr	w8, [x23, x8]
100030368: 7100011f    	cmp	w8, #0x0
10003036c: 1a9f17e8    	cset	w8, eq
100030370: 140000de    	b	0x1000306e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xe64>
100030374: b9400f60    	ldr	w0, [x27, #0xc]
100030378: eb00027f    	cmp	x19, x0
10003037c: 5400a2e9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030380: d37cec08    	lsl	x8, x0, #4
100030384: 7101a53f    	cmp	w9, #0x69
100030388: aa1f03e1    	mov	x1, xzr
10003038c: f8686ae8    	ldr	x8, [x23, x8]
100030390: 2a0803e9    	mov	w9, w8
100030394: 9a880128    	csel	x8, x9, x8, eq
100030398: d341fd09    	lsr	x9, x8, #1
10003039c: 9200f108    	and	x8, x8, #0x5555555555555555
1000303a0: 9200f129    	and	x9, x9, #0x5555555555555555
1000303a4: 8b080128    	add	x8, x9, x8
1000303a8: d342fd09    	lsr	x9, x8, #2
1000303ac: 9200e508    	and	x8, x8, #0x3333333333333333
1000303b0: 9200e529    	and	x9, x9, #0x3333333333333333
1000303b4: 8b080128    	add	x8, x9, x8
1000303b8: 8b481108    	add	x8, x8, x8, lsr #4
1000303bc: 9200cd08    	and	x8, x8, #0xf0f0f0f0f0f0f0f
1000303c0: 8b482108    	add	x8, x8, x8, lsr #8
1000303c4: 8b484108    	add	x8, x8, x8, lsr #16
1000303c8: 8b488108    	add	x8, x8, x8, lsr #32
1000303cc: 92401900    	and	x0, x8, #0x7f
1000303d0: 17ffff81    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000303d4: b9400f60    	ldr	w0, [x27, #0xc]
1000303d8: eb00027f    	cmp	x19, x0
1000303dc: 54009fe9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000303e0: d37cec08    	lsl	x8, x0, #4
1000303e4: aa1f03e1    	mov	x1, xzr
1000303e8: b8a86ae0    	ldrsw	x0, [x23, x8]
1000303ec: 17ffff7a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000303f0: b9400f60    	ldr	w0, [x27, #0xc]
1000303f4: eb00027f    	cmp	x19, x0
1000303f8: 54009f09    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000303fc: d37cec08    	lsl	x8, x0, #4
100030400: aa1f03e1    	mov	x1, xzr
100030404: b8686ae0    	ldr	w0, [x23, x8]
100030408: 17ffff73    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003040c: aa0203e1    	mov	x1, x2
100030410: aa0803e2    	mov	x2, x8
100030414: aa0503e3    	mov	x3, x5
100030418: aa0603e4    	mov	x4, x6
10003041c: aa0a03e5    	mov	x5, x10
100030420: aa0b03e6    	mov	x6, x11
100030424: 94009041    	bl	0x100054528 <_github.com/cpunion/wasmvm/internal/engine/simd.Eval>
100030428: f94017f0    	ldr	x16, [sp, #0x28]
10003042c: 17ffff6a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030430: b9400f60    	ldr	w0, [x27, #0xc]
100030434: eb00027f    	cmp	x19, x0
100030438: 54009d09    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003043c: b9401368    	ldr	w8, [x27, #0x10]
100030440: eb08027f    	cmp	x19, x8
100030444: 540061e8    	b.hi	0x100031080 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x17fc>
100030448: 140004e3    	b	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003044c: f94013e8    	ldr	x8, [sp, #0x20]
100030450: b9401b60    	ldr	w0, [x27, #0x18]
100030454: f9403d01    	ldr	x1, [x8, #0x78]
100030458: eb00003f    	cmp	x1, x0
10003045c: 54009ba9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030460: f9403908    	ldr	x8, [x8, #0x70]
100030464: ab000d08    	adds	x8, x8, x0, lsl #3
100030468: 54008e40    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10003046c: b4008e35    	cbz	x21, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030470: f9400119    	ldr	x25, [x8]
100030474: b4008df9    	cbz	x25, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030478: f9400b29    	ldr	x9, [x25, #0x10]
10003047c: b9400f68    	ldr	w8, [x27, #0xc]
100030480: f94002a0    	ldr	x0, [x21]
100030484: 3940c529    	ldrb	w9, [x9, #0x31]
100030488: eb08027f    	cmp	x19, x8
10003048c: 3902bbe9    	strb	w9, [sp, #0xae]
100030490: 54009a29    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030494: d37ced08    	lsl	x8, x8, #4
100030498: 3942bbe9    	ldrb	w9, [sp, #0xae]
10003049c: aa1903e1    	mov	x1, x25
1000304a0: f8686ae8    	ldr	x8, [x23, x8]
1000304a4: 7100013f    	cmp	w9, #0x0
1000304a8: 2a0803ea    	mov	w10, w8
1000304ac: 9a8a1102    	csel	x2, x8, x10, ne
1000304b0: 94006079    	bl	0x100048694 <_github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory>
1000304b4: 36007ba1    	tbz	w1, #0x0, 0x100031428 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ba4>
1000304b8: f94017f0    	ldr	x16, [sp, #0x28]
1000304bc: aa1f03e1    	mov	x1, xzr
1000304c0: 17ffff45    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000304c4: f94013e8    	ldr	x8, [sp, #0x20]
1000304c8: b9401b60    	ldr	w0, [x27, #0x18]
1000304cc: f9403101    	ldr	x1, [x8, #0x60]
1000304d0: eb00003f    	cmp	x1, x0
1000304d4: 540097e9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000304d8: f9402d08    	ldr	x8, [x8, #0x58]
1000304dc: ab000d08    	adds	x8, x8, x0, lsl #3
1000304e0: 54008a80    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000304e4: f9400108    	ldr	x8, [x8]
1000304e8: b4008a48    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000304ec: b9400f60    	ldr	w0, [x27, #0xc]
1000304f0: eb00027f    	cmp	x19, x0
1000304f4: 54009729    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000304f8: d37cec09    	lsl	x9, x0, #4
1000304fc: 3940a50a    	ldrb	w10, [x8, #0x29]
100030500: f8696ae9    	ldr	x9, [x23, x9]
100030504: 7100015f    	cmp	w10, #0x0
100030508: f940210a    	ldr	x10, [x8, #0x40]
10003050c: 2a0903eb    	mov	w11, w9
100030510: 9a8b1129    	csel	x9, x9, x11, ne
100030514: eb0a013f    	cmp	x9, x10
100030518: 54008ec2    	b.hs	0x1000316f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
10003051c: f9401d08    	ldr	x8, [x8, #0x38]
100030520: aa1f03e1    	mov	x1, xzr
100030524: f8697900    	ldr	x0, [x8, x9, lsl #3]
100030528: 17ffff2b    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003052c: f94013e8    	ldr	x8, [sp, #0x20]
100030530: b9401b60    	ldr	w0, [x27, #0x18]
100030534: f9402501    	ldr	x1, [x8, #0x48]
100030538: eb00003f    	cmp	x1, x0
10003053c: 540094a9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030540: f9402108    	ldr	x8, [x8, #0x40]
100030544: aa1f03e1    	mov	x1, xzr
100030548: f8607900    	ldr	x0, [x8, x0, lsl #3]
10003054c: 17ffff22    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030550: b9400f60    	ldr	w0, [x27, #0xc]
100030554: eb00027f    	cmp	x19, x0
100030558: 54009409    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003055c: 8b0012e8    	add	x8, x23, x0, lsl #4
100030560: f9400100    	ldr	x0, [x8]
100030564: b4008ce0    	cbz	x0, 0x100031700 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e7c>
100030568: f9400501    	ldr	x1, [x8, #0x8]
10003056c: 17ffff1a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030570: f94013e8    	ldr	x8, [sp, #0x20]
100030574: f9404901    	ldr	x1, [x8, #0x90]
100030578: b9401b68    	ldr	w8, [x27, #0x18]
10003057c: eb08003f    	cmp	x1, x8
100030580: 54009309    	b.ls	0x1000317e0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f5c>
100030584: b9400f69    	ldr	w9, [x27, #0xc]
100030588: eb09027f    	cmp	x19, x9
10003058c: 540098a9    	b.ls	0x1000318a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x201c>
100030590: f94013ea    	ldr	x10, [sp, #0x20]
100030594: 3ce97ae0    	ldr	q0, [x23, x9, lsl #4]
100030598: aa1f03e0    	mov	x0, xzr
10003059c: aa1f03e1    	mov	x1, xzr
1000305a0: f940454a    	ldr	x10, [x10, #0x88]
1000305a4: f8687948    	ldr	x8, [x10, x8, lsl #3]
1000305a8: 3d800900    	str	q0, [x8, #0x20]
1000305ac: 17ffff0a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000305b0: f94013e8    	ldr	x8, [sp, #0x20]
1000305b4: b9401b60    	ldr	w0, [x27, #0x18]
1000305b8: f9404901    	ldr	x1, [x8, #0x90]
1000305bc: eb00003f    	cmp	x1, x0
1000305c0: 54009089    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000305c4: f9404508    	ldr	x8, [x8, #0x88]
1000305c8: f8607908    	ldr	x8, [x8, x0, lsl #3]
1000305cc: a9420500    	ldp	x0, x1, [x8, #0x20]
1000305d0: 17ffff01    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000305d4: f94013e8    	ldr	x8, [sp, #0x20]
1000305d8: b9401b60    	ldr	w0, [x27, #0x18]
1000305dc: f9403101    	ldr	x1, [x8, #0x60]
1000305e0: eb00003f    	cmp	x1, x0
1000305e4: 54008f69    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000305e8: f9402d08    	ldr	x8, [x8, #0x58]
1000305ec: ab000d08    	adds	x8, x8, x0, lsl #3
1000305f0: 54008200    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000305f4: f9400109    	ldr	x9, [x8]
1000305f8: b40081c9    	cbz	x9, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
1000305fc: b9400f60    	ldr	w0, [x27, #0xc]
100030600: eb00027f    	cmp	x19, x0
100030604: 54008ea9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030608: d37cec08    	lsl	x8, x0, #4
10003060c: 3940a52a    	ldrb	w10, [x9, #0x29]
100030610: f940212c    	ldr	x12, [x9, #0x40]
100030614: f8686ae8    	ldr	x8, [x23, x8]
100030618: 7100015f    	cmp	w10, #0x0
10003061c: 2a0803eb    	mov	w11, w8
100030620: 9a8b110a    	csel	x10, x8, x11, ne
100030624: eb0c015f    	cmp	x10, x12
100030628: 54008642    	b.hs	0x1000316f0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e6c>
10003062c: b9401368    	ldr	w8, [x27, #0x10]
100030630: eb08027f    	cmp	x19, x8
100030634: 54008d09    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030638: d37ced08    	lsl	x8, x8, #4
10003063c: f9401d29    	ldr	x9, [x9, #0x38]
100030640: aa1f03e0    	mov	x0, xzr
100030644: aa1f03e1    	mov	x1, xzr
100030648: f8686ae8    	ldr	x8, [x23, x8]
10003064c: f82a7928    	str	x8, [x9, x10, lsl #3]
100030650: 17fffee1    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030654: b9401b60    	ldr	w0, [x27, #0x18]
100030658: eb00027f    	cmp	x19, x0
10003065c: 54008ae9    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
100030660: 8b0012e8    	add	x8, x23, x0, lsl #4
100030664: a9400500    	ldp	x0, x1, [x8]
100030668: 17fffedb    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003066c: f94013e8    	ldr	x8, [sp, #0x20]
100030670: b9401b60    	ldr	w0, [x27, #0x18]
100030674: f9403d01    	ldr	x1, [x8, #0x78]
100030678: eb00003f    	cmp	x1, x0
10003067c: 54008aa9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100030680: f9403908    	ldr	x8, [x8, #0x70]
100030684: ab000d08    	adds	x8, x8, x0, lsl #3
100030688: 54007d40    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10003068c: f9400108    	ldr	x8, [x8]
100030690: b4007d08    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030694: f9400900    	ldr	x0, [x8, #0x10]
100030698: f9402009    	ldr	x9, [x0, #0x40]
10003069c: f9403008    	ldr	x8, [x0, #0x60]
1000306a0: b4006d69    	cbz	x9, 0x10003144c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bc8>
1000306a4: b5006d68    	cbnz	x8, 0x100031450 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bcc>
1000306a8: 94006b25    	bl	0x10004b33c <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).pagesLocked>
1000306ac: f94017f0    	ldr	x16, [sp, #0x28]
1000306b0: aa1f03e1    	mov	x1, xzr
1000306b4: 17fffec8    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000306b8: b9401b60    	ldr	w0, [x27, #0x18]
1000306bc: aa1f03e1    	mov	x1, xzr
1000306c0: 17fffec5    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000306c4: aa0803e0    	mov	x0, x8
1000306c8: 2a0903e1    	mov	w1, w9
1000306cc: 94006d86    	bl	0x10004bce4 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).storeLocked>
1000306d0: 2a0003f9    	mov	w25, w0
1000306d4: aa1f03e0    	mov	x0, xzr
1000306d8: aa1f03e1    	mov	x1, xzr
1000306dc: 17fffebb    	b	0x1000301c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
1000306e0: 7100153f    	cmp	w9, #0x5
1000306e4: 540080a0    	b.eq	0x1000316f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e74>
1000306e8: b9401b69    	ldr	w9, [x27, #0x18]
1000306ec: f9407601    	ldr	x1, [x16, #0xe8]
1000306f0: 0b080120    	add	w0, w9, w8
1000306f4: eb00003f    	cmp	x1, x0
1000306f8: 540086c9    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
1000306fc: f9407208    	ldr	x8, [x16, #0xe0]
100030700: 52800189    	mov	w9, #0xc                ; =12
100030704: 9ba92008    	umaddl	x8, w0, w9, x8
100030708: 2940651b    	ldp	w27, w25, [x8]
10003070c: b940091a    	ldr	w26, [x8, #0x8]
100030710: 6b18037f    	cmp	w27, w24
100030714: 54006ba8    	b.hi	0x100031488 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100030718: f940b2a8    	ldr	x8, [x21, #0x160]
10003071c: b4000088    	cbz	x8, 0x10003072c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xea8>
100030720: b40002b5    	cbz	x21, 0x100030774 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xef0>
100030724: 88dffd08    	ldar	w8, [x8]
100030728: 34006a68    	cbz	w8, 0x100031474 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bf0>
10003072c: f94006a8    	ldr	x8, [x21, #0x8]
100030730: b4008be8    	cbz	x8, 0x1000318ac <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2028>
100030734: f9400509    	ldr	x9, [x8, #0x8]
100030738: f9400aa0    	ldr	x0, [x21, #0x10]
10003073c: 39405d29    	ldrb	w9, [x9, #0x17]
100030740: 1200112a    	and	w10, w9, #0x1f
100030744: 121b0129    	and	w9, w9, #0x20
100030748: 7100595f    	cmp	w10, #0x16
10003074c: 7a401924    	ccmp	w9, #0x0, #0x4, ne
100030750: 54000060    	b.eq	0x10003075c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xed8>
100030754: f81883a0    	stur	x0, [x29, #-0x78]
100030758: d101e3a0    	sub	x0, x29, #0x78
10003075c: f9401508    	ldr	x8, [x8, #0x28]
100030760: d63f0100    	blr	x8
100030764: f94017f0    	ldr	x16, [sp, #0x28]
100030768: aa0103e2    	mov	x2, x1
10003076c: b50068a0    	cbnz	x0, 0x100031480 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
100030770: 14000346    	b	0x100031488 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100030774: 52800020    	mov	w0, #0x1                ; =1
100030778: 9407bcfc    	bl	0x10021fb68 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
10003077c: f94017f0    	ldr	x16, [sp, #0x28]
100030780: b5006800    	cbnz	x0, 0x100031480 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bfc>
100030784: 14000341    	b	0x100031488 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100030788: 71000d1f    	cmp	w8, #0x3
10003078c: 54007420    	b.eq	0x100031610 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d8c>
100030790: 7100191f    	cmp	w8, #0x6
100030794: 54007160    	b.eq	0x1000315c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d3c>
100030798: 51004928    	sub	w8, w9, #0x12
10003079c: 7100111f    	cmp	w8, #0x4
1000307a0: 54007243    	b.lo	0x1000315e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d64>
1000307a4: b9400f60    	ldr	w0, [x27, #0xc]
1000307a8: 3100041f    	cmn	w0, #0x1
1000307ac: 54005b20    	b.eq	0x100031310 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a8c>
1000307b0: eb00027f    	cmp	x19, x0
1000307b4: 54008129    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000307b8: d37cec08    	lsl	x8, x0, #4
1000307bc: f8686ae5    	ldr	x5, [x23, x8]
1000307c0: b9401360    	ldr	w0, [x27, #0x10]
1000307c4: 3100041f    	cmn	w0, #0x1
1000307c8: 54005ac0    	b.eq	0x100031320 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a9c>
1000307cc: eb00027f    	cmp	x19, x0
1000307d0: 54008049    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000307d4: d37cec08    	lsl	x8, x0, #4
1000307d8: f8686ae7    	ldr	x7, [x23, x8]
1000307dc: b9401760    	ldr	w0, [x27, #0x14]
1000307e0: 3100041f    	cmn	w0, #0x1
1000307e4: 54005a60    	b.eq	0x100031330 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1aac>
1000307e8: eb00027f    	cmp	x19, x0
1000307ec: 54007e69    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
1000307f0: d37cec08    	lsl	x8, x0, #4
1000307f4: f8686aea    	ldr	x10, [x23, x8]
1000307f8: 12103d28    	and	w8, w9, #0xffff0000
1000307fc: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
100030800: 54005a01    	b.ne	0x100031340 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1abc>
100030804: 12003d24    	and	w4, w9, #0xffff
100030808: 71000c9f    	cmp	w4, #0x3
10003080c: 540067a1    	b.ne	0x100031500 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c7c>
100030810: b4007115    	cbz	x21, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100030814: f94002a8    	ldr	x8, [x21]
100030818: b40070c8    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
10003081c: f9400500    	ldr	x0, [x8, #0x8]
100030820: 9400684c    	bl	0x10004a950 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence>
100030824: f94017f0    	ldr	x16, [sp, #0x28]
100030828: aa1f03e0    	mov	x0, xzr
10003082c: aa1f03e1    	mov	x1, xzr
100030830: 17fffe69    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030834: b9400f60    	ldr	w0, [x27, #0xc]
100030838: eb00027f    	cmp	x19, x0
10003083c: 54007ce9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030840: b9401368    	ldr	w8, [x27, #0x10]
100030844: eb08027f    	cmp	x19, x8
100030848: 54007c69    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003084c: d37cec09    	lsl	x9, x0, #4
100030850: d37ced08    	lsl	x8, x8, #4
100030854: aa1f03e1    	mov	x1, xzr
100030858: f8696ae9    	ldr	x9, [x23, x9]
10003085c: f8686ae8    	ldr	x8, [x23, x8]
100030860: ca090100    	eor	x0, x8, x9
100030864: 17fffe5c    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030868: b9400f60    	ldr	w0, [x27, #0xc]
10003086c: eb00027f    	cmp	x19, x0
100030870: 54007b49    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030874: b9401368    	ldr	w8, [x27, #0x10]
100030878: eb08027f    	cmp	x19, x8
10003087c: 54007ac9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030880: d37cec09    	lsl	x9, x0, #4
100030884: d37ced08    	lsl	x8, x8, #4
100030888: aa1f03e1    	mov	x1, xzr
10003088c: f8696ae9    	ldr	x9, [x23, x9]
100030890: f8686ae8    	ldr	x8, [x23, x8]
100030894: 9ac82520    	lsr	x0, x9, x8
100030898: 17fffe4f    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003089c: b9400f60    	ldr	w0, [x27, #0xc]
1000308a0: eb00027f    	cmp	x19, x0
1000308a4: 540079a9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000308a8: b9401368    	ldr	w8, [x27, #0x10]
1000308ac: eb08027f    	cmp	x19, x8
1000308b0: 54007929    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000308b4: d37cec09    	lsl	x9, x0, #4
1000308b8: d37ced08    	lsl	x8, x8, #4
1000308bc: aa1f03e1    	mov	x1, xzr
1000308c0: b8696ae9    	ldr	w9, [x23, x9]
1000308c4: b8686ae8    	ldr	w8, [x23, x8]
1000308c8: 1ac82920    	asr	w0, w9, w8
1000308cc: 17fffe42    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000308d0: b9400f60    	ldr	w0, [x27, #0xc]
1000308d4: eb00027f    	cmp	x19, x0
1000308d8: 54007809    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000308dc: b9401368    	ldr	w8, [x27, #0x10]
1000308e0: eb08027f    	cmp	x19, x8
1000308e4: 54007789    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000308e8: d37cec09    	lsl	x9, x0, #4
1000308ec: d37ced08    	lsl	x8, x8, #4
1000308f0: aa1f03e1    	mov	x1, xzr
1000308f4: f8696ae9    	ldr	x9, [x23, x9]
1000308f8: f8686ae8    	ldr	x8, [x23, x8]
1000308fc: aa090100    	orr	x0, x8, x9
100030900: 17fffe35    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030904: b9400f60    	ldr	w0, [x27, #0xc]
100030908: eb00027f    	cmp	x19, x0
10003090c: 54007669    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030910: b9401368    	ldr	w8, [x27, #0x10]
100030914: eb08027f    	cmp	x19, x8
100030918: 540075e9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003091c: d37cec09    	lsl	x9, x0, #4
100030920: d37ced08    	lsl	x8, x8, #4
100030924: aa1f03e1    	mov	x1, xzr
100030928: b8696ae9    	ldr	w9, [x23, x9]
10003092c: b8686ae8    	ldr	w8, [x23, x8]
100030930: 1ac82120    	lsl	w0, w9, w8
100030934: 17fffe28    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030938: b9400f60    	ldr	w0, [x27, #0xc]
10003093c: eb00027f    	cmp	x19, x0
100030940: 540074c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030944: b9401368    	ldr	w8, [x27, #0x10]
100030948: eb08027f    	cmp	x19, x8
10003094c: 54007449    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030950: d37cec09    	lsl	x9, x0, #4
100030954: d37ced08    	lsl	x8, x8, #4
100030958: aa1f03e1    	mov	x1, xzr
10003095c: b8696ae9    	ldr	w9, [x23, x9]
100030960: b8686ae8    	ldr	w8, [x23, x8]
100030964: 2a090100    	orr	w0, w8, w9
100030968: 17fffe1b    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003096c: b9400f60    	ldr	w0, [x27, #0xc]
100030970: eb00027f    	cmp	x19, x0
100030974: 54007329    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030978: d37cec08    	lsl	x8, x0, #4
10003097c: aa1f03e1    	mov	x1, xzr
100030980: f8686ae8    	ldr	x8, [x23, x8]
100030984: dac00108    	rbit	x8, x8
100030988: dac01100    	clz	x0, x8
10003098c: 17fffe12    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030990: b9400f60    	ldr	w0, [x27, #0xc]
100030994: eb00027f    	cmp	x19, x0
100030998: 54007209    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003099c: b9401368    	ldr	w8, [x27, #0x10]
1000309a0: eb08027f    	cmp	x19, x8
1000309a4: 54007189    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000309a8: d37cec09    	lsl	x9, x0, #4
1000309ac: d37ced08    	lsl	x8, x8, #4
1000309b0: aa1f03e1    	mov	x1, xzr
1000309b4: f8696ae9    	ldr	x9, [x23, x9]
1000309b8: f8686ae8    	ldr	x8, [x23, x8]
1000309bc: eb08013f    	cmp	x9, x8
1000309c0: 1a9f27e0    	cset	w0, lo
1000309c4: 17fffe04    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000309c8: b9400f60    	ldr	w0, [x27, #0xc]
1000309cc: eb00027f    	cmp	x19, x0
1000309d0: 54007049    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000309d4: b9401368    	ldr	w8, [x27, #0x10]
1000309d8: eb08027f    	cmp	x19, x8
1000309dc: 54006fc9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000309e0: d37cec09    	lsl	x9, x0, #4
1000309e4: d37ced08    	lsl	x8, x8, #4
1000309e8: aa1f03e1    	mov	x1, xzr
1000309ec: f8696ae9    	ldr	x9, [x23, x9]
1000309f0: f8686ae8    	ldr	x8, [x23, x8]
1000309f4: eb08013f    	cmp	x9, x8
1000309f8: 1a9f87e0    	cset	w0, ls
1000309fc: 17fffdf6    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030a00: b9400f60    	ldr	w0, [x27, #0xc]
100030a04: eb00027f    	cmp	x19, x0
100030a08: 54006e89    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030a0c: b9401368    	ldr	w8, [x27, #0x10]
100030a10: eb08027f    	cmp	x19, x8
100030a14: 54006e09    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030a18: d37cec09    	lsl	x9, x0, #4
100030a1c: d37ced08    	lsl	x8, x8, #4
100030a20: aa1f03e1    	mov	x1, xzr
100030a24: f8696ae9    	ldr	x9, [x23, x9]
100030a28: f8686ae8    	ldr	x8, [x23, x8]
100030a2c: eb08013f    	cmp	x9, x8
100030a30: 1a9f97e0    	cset	w0, hi
100030a34: 17fffde8    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030a38: b9400f60    	ldr	w0, [x27, #0xc]
100030a3c: eb00027f    	cmp	x19, x0
100030a40: 54006cc9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030a44: b9401368    	ldr	w8, [x27, #0x10]
100030a48: eb08027f    	cmp	x19, x8
100030a4c: 54006c49    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030a50: d37cec09    	lsl	x9, x0, #4
100030a54: d37ced08    	lsl	x8, x8, #4
100030a58: aa1f03e1    	mov	x1, xzr
100030a5c: b8696ae9    	ldr	w9, [x23, x9]
100030a60: b8686ae8    	ldr	w8, [x23, x8]
100030a64: 4b080120    	sub	w0, w9, w8
100030a68: 17fffddb    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030a6c: b9400f60    	ldr	w0, [x27, #0xc]
100030a70: eb00027f    	cmp	x19, x0
100030a74: 54006b29    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030a78: d37cec08    	lsl	x8, x0, #4
100030a7c: 5280040b    	mov	w11, #0x20              ; =32
100030a80: 5280030c    	mov	w12, #0x18              ; =24
100030a84: aa1f03e1    	mov	x1, xzr
100030a88: b8686ae8    	ldr	w8, [x23, x8]
100030a8c: 53107d09    	lsr	w9, w8, #16
100030a90: 7100013f    	cmp	w9, #0x0
100030a94: 1a881128    	csel	w8, w9, w8, ne
100030a98: 928001e9    	mov	x9, #-0x10              ; =-16
100030a9c: 53087d0a    	lsr	w10, w8, #8
100030aa0: 9a9f1129    	csel	x9, x9, xzr, ne
100030aa4: 7103fd1f    	cmp	w8, #0xff
100030aa8: 1a888148    	csel	w8, w10, w8, hi
100030aac: f000148a    	adrp	x10, 0x1002c3000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xcb0>
100030ab0: 912b954a    	add	x10, x10, #0xae5
100030ab4: 92401d08    	and	x8, x8, #0xff
100030ab8: 38686948    	ldrb	w8, [x10, x8]
100030abc: 9a8b818a    	csel	x10, x12, x11, hi
100030ac0: 8b090149    	add	x9, x10, x9
100030ac4: cb080120    	sub	x0, x9, x8
100030ac8: 17fffdc3    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030acc: b9400f60    	ldr	w0, [x27, #0xc]
100030ad0: eb00027f    	cmp	x19, x0
100030ad4: 54006829    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030ad8: b9401368    	ldr	w8, [x27, #0x10]
100030adc: eb08027f    	cmp	x19, x8
100030ae0: 540067a9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030ae4: d37cec09    	lsl	x9, x0, #4
100030ae8: d37ced08    	lsl	x8, x8, #4
100030aec: aa1f03e1    	mov	x1, xzr
100030af0: b8696ae9    	ldr	w9, [x23, x9]
100030af4: b8686ae8    	ldr	w8, [x23, x8]
100030af8: 1ac82520    	lsr	w0, w9, w8
100030afc: 17fffdb6    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030b00: b9400f60    	ldr	w0, [x27, #0xc]
100030b04: eb00027f    	cmp	x19, x0
100030b08: 54006689    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030b0c: b9401368    	ldr	w8, [x27, #0x10]
100030b10: eb08027f    	cmp	x19, x8
100030b14: 54006609    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030b18: d37cec09    	lsl	x9, x0, #4
100030b1c: d37ced08    	lsl	x8, x8, #4
100030b20: aa1f03e1    	mov	x1, xzr
100030b24: f8696ae9    	ldr	x9, [x23, x9]
100030b28: f8686ae8    	ldr	x8, [x23, x8]
100030b2c: eb08013f    	cmp	x9, x8
100030b30: 1a9fd7e0    	cset	w0, gt
100030b34: 17fffda8    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030b38: b9400f60    	ldr	w0, [x27, #0xc]
100030b3c: eb00027f    	cmp	x19, x0
100030b40: 540064c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030b44: b9401368    	ldr	w8, [x27, #0x10]
100030b48: eb08027f    	cmp	x19, x8
100030b4c: 54006449    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030b50: d37cec09    	lsl	x9, x0, #4
100030b54: d37ced08    	lsl	x8, x8, #4
100030b58: aa1f03e1    	mov	x1, xzr
100030b5c: b8696ae9    	ldr	w9, [x23, x9]
100030b60: b8686ae8    	ldr	w8, [x23, x8]
100030b64: 6b08013f    	cmp	w9, w8
100030b68: 1a9fa7e0    	cset	w0, lt
100030b6c: 17fffd9a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030b70: b9400f60    	ldr	w0, [x27, #0xc]
100030b74: eb00027f    	cmp	x19, x0
100030b78: 54006309    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030b7c: b9401368    	ldr	w8, [x27, #0x10]
100030b80: eb08027f    	cmp	x19, x8
100030b84: 54006289    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030b88: d37cec09    	lsl	x9, x0, #4
100030b8c: d37ced08    	lsl	x8, x8, #4
100030b90: aa1f03e1    	mov	x1, xzr
100030b94: f8696ae9    	ldr	x9, [x23, x9]
100030b98: f8686ae8    	ldr	x8, [x23, x8]
100030b9c: eb08013f    	cmp	x9, x8
100030ba0: 1a9f07e0    	cset	w0, ne
100030ba4: 17fffd8c    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ba8: b9400f60    	ldr	w0, [x27, #0xc]
100030bac: eb00027f    	cmp	x19, x0
100030bb0: 54006149    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030bb4: d37cec08    	lsl	x8, x0, #4
100030bb8: b8686ae8    	ldr	w8, [x23, x8]
100030bbc: 34004ea8    	cbz	w8, 0x100031590 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d0c>
100030bc0: 5ac00108    	rbit	w8, w8
100030bc4: aa1f03e1    	mov	x1, xzr
100030bc8: 5ac01100    	clz	w0, w8
100030bcc: 17fffd82    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030bd0: b9400f60    	ldr	w0, [x27, #0xc]
100030bd4: eb00027f    	cmp	x19, x0
100030bd8: 54006009    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030bdc: b9401368    	ldr	w8, [x27, #0x10]
100030be0: eb08027f    	cmp	x19, x8
100030be4: 54005f89    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030be8: d37cec09    	lsl	x9, x0, #4
100030bec: d37ced08    	lsl	x8, x8, #4
100030bf0: aa1f03e1    	mov	x1, xzr
100030bf4: b8696ae9    	ldr	w9, [x23, x9]
100030bf8: b8686ae8    	ldr	w8, [x23, x8]
100030bfc: 6b08013f    	cmp	w9, w8
100030c00: 1a9f07e0    	cset	w0, ne
100030c04: 17fffd74    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030c08: b9400f60    	ldr	w0, [x27, #0xc]
100030c0c: eb00027f    	cmp	x19, x0
100030c10: 54005e49    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030c14: b9401368    	ldr	w8, [x27, #0x10]
100030c18: eb08027f    	cmp	x19, x8
100030c1c: 54005dc9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030c20: d37cec09    	lsl	x9, x0, #4
100030c24: d37ced08    	lsl	x8, x8, #4
100030c28: aa1f03e1    	mov	x1, xzr
100030c2c: f8696ae9    	ldr	x9, [x23, x9]
100030c30: f8686ae8    	ldr	x8, [x23, x8]
100030c34: eb08013f    	cmp	x9, x8
100030c38: 1a9fc7e0    	cset	w0, le
100030c3c: 17fffd66    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030c40: b9400f60    	ldr	w0, [x27, #0xc]
100030c44: eb00027f    	cmp	x19, x0
100030c48: 54005c89    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030c4c: b9401368    	ldr	w8, [x27, #0x10]
100030c50: eb08027f    	cmp	x19, x8
100030c54: 54005c09    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030c58: d37ced08    	lsl	x8, x8, #4
100030c5c: d37cec09    	lsl	x9, x0, #4
100030c60: aa1f03e1    	mov	x1, xzr
100030c64: b8686ae8    	ldr	w8, [x23, x8]
100030c68: b8696ae9    	ldr	w9, [x23, x9]
100030c6c: 4b0803e8    	neg	w8, w8
100030c70: 1ac82d20    	ror	w0, w9, w8
100030c74: 17fffd58    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030c78: b9400f60    	ldr	w0, [x27, #0xc]
100030c7c: eb00027f    	cmp	x19, x0
100030c80: 54005ac9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030c84: b9401368    	ldr	w8, [x27, #0x10]
100030c88: eb08027f    	cmp	x19, x8
100030c8c: 54005a49    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030c90: d37cec09    	lsl	x9, x0, #4
100030c94: d37ced08    	lsl	x8, x8, #4
100030c98: aa1f03e1    	mov	x1, xzr
100030c9c: b8696ae9    	ldr	w9, [x23, x9]
100030ca0: b8686ae8    	ldr	w8, [x23, x8]
100030ca4: 6b08013f    	cmp	w9, w8
100030ca8: 1a9f87e0    	cset	w0, ls
100030cac: 17fffd4a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030cb0: b9400f60    	ldr	w0, [x27, #0xc]
100030cb4: eb00027f    	cmp	x19, x0
100030cb8: 54005909    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030cbc: b9401368    	ldr	w8, [x27, #0x10]
100030cc0: eb08027f    	cmp	x19, x8
100030cc4: 54005889    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030cc8: d37cec09    	lsl	x9, x0, #4
100030ccc: d37ced08    	lsl	x8, x8, #4
100030cd0: aa1f03e1    	mov	x1, xzr
100030cd4: b8696ae9    	ldr	w9, [x23, x9]
100030cd8: b8686ae8    	ldr	w8, [x23, x8]
100030cdc: 6b08013f    	cmp	w9, w8
100030ce0: 1a9fb7e0    	cset	w0, ge
100030ce4: 17fffd3c    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ce8: b9400f60    	ldr	w0, [x27, #0xc]
100030cec: eb00027f    	cmp	x19, x0
100030cf0: 54005749    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030cf4: d37cec08    	lsl	x8, x0, #4
100030cf8: aa1f03e1    	mov	x1, xzr
100030cfc: b8686ae8    	ldr	w8, [x23, x8]
100030d00: 7100011f    	cmp	w8, #0x0
100030d04: 1a9f17e0    	cset	w0, eq
100030d08: 17fffd33    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030d0c: b9400f60    	ldr	w0, [x27, #0xc]
100030d10: eb00027f    	cmp	x19, x0
100030d14: 54005629    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030d18: b9401368    	ldr	w8, [x27, #0x10]
100030d1c: eb08027f    	cmp	x19, x8
100030d20: 540055a9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030d24: d37cec09    	lsl	x9, x0, #4
100030d28: d37ced08    	lsl	x8, x8, #4
100030d2c: aa1f03e1    	mov	x1, xzr
100030d30: b8696ae9    	ldr	w9, [x23, x9]
100030d34: b8686ae8    	ldr	w8, [x23, x8]
100030d38: 6b08013f    	cmp	w9, w8
100030d3c: 1a9f27e0    	cset	w0, lo
100030d40: 17fffd25    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030d44: b9400f60    	ldr	w0, [x27, #0xc]
100030d48: eb00027f    	cmp	x19, x0
100030d4c: 54005469    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030d50: b9401368    	ldr	w8, [x27, #0x10]
100030d54: eb08027f    	cmp	x19, x8
100030d58: 540053e9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030d5c: d37cec09    	lsl	x9, x0, #4
100030d60: d37ced08    	lsl	x8, x8, #4
100030d64: aa1f03e1    	mov	x1, xzr
100030d68: f8696ae9    	ldr	x9, [x23, x9]
100030d6c: f8686ae8    	ldr	x8, [x23, x8]
100030d70: 8b090100    	add	x0, x8, x9
100030d74: 17fffd18    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030d78: b9400f60    	ldr	w0, [x27, #0xc]
100030d7c: eb00027f    	cmp	x19, x0
100030d80: 540052c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030d84: b9401368    	ldr	w8, [x27, #0x10]
100030d88: eb08027f    	cmp	x19, x8
100030d8c: 54005249    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030d90: d37cec09    	lsl	x9, x0, #4
100030d94: d37ced08    	lsl	x8, x8, #4
100030d98: aa1f03e1    	mov	x1, xzr
100030d9c: b8696ae9    	ldr	w9, [x23, x9]
100030da0: b8686ae8    	ldr	w8, [x23, x8]
100030da4: 4a090100    	eor	w0, w8, w9
100030da8: 17fffd0b    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030dac: b9400f60    	ldr	w0, [x27, #0xc]
100030db0: eb00027f    	cmp	x19, x0
100030db4: 54005129    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030db8: b9401368    	ldr	w8, [x27, #0x10]
100030dbc: eb08027f    	cmp	x19, x8
100030dc0: 540050a9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030dc4: d37cec09    	lsl	x9, x0, #4
100030dc8: d37ced08    	lsl	x8, x8, #4
100030dcc: aa1f03e1    	mov	x1, xzr
100030dd0: f8696ae9    	ldr	x9, [x23, x9]
100030dd4: f8686ae8    	ldr	x8, [x23, x8]
100030dd8: 8a090100    	and	x0, x8, x9
100030ddc: 17fffcfe    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030de0: b9400f60    	ldr	w0, [x27, #0xc]
100030de4: eb00027f    	cmp	x19, x0
100030de8: 54004f89    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030dec: b9401368    	ldr	w8, [x27, #0x10]
100030df0: eb08027f    	cmp	x19, x8
100030df4: 54004f09    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030df8: d37cec09    	lsl	x9, x0, #4
100030dfc: d37ced08    	lsl	x8, x8, #4
100030e00: aa1f03e1    	mov	x1, xzr
100030e04: f8696ae9    	ldr	x9, [x23, x9]
100030e08: f8686ae8    	ldr	x8, [x23, x8]
100030e0c: cb080120    	sub	x0, x9, x8
100030e10: 17fffcf1    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030e14: b9400f60    	ldr	w0, [x27, #0xc]
100030e18: eb00027f    	cmp	x19, x0
100030e1c: 54004de9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030e20: b9401368    	ldr	w8, [x27, #0x10]
100030e24: eb08027f    	cmp	x19, x8
100030e28: 54004d69    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030e2c: d37ced08    	lsl	x8, x8, #4
100030e30: d37cec09    	lsl	x9, x0, #4
100030e34: b8686ae8    	ldr	w8, [x23, x8]
100030e38: f8696ae9    	ldr	x9, [x23, x9]
100030e3c: 4b0803e8    	neg	w8, w8
100030e40: 1400006b    	b	0x100030fec <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1768>
100030e44: b9400f60    	ldr	w0, [x27, #0xc]
100030e48: eb00027f    	cmp	x19, x0
100030e4c: 54004c69    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030e50: b9401368    	ldr	w8, [x27, #0x10]
100030e54: eb08027f    	cmp	x19, x8
100030e58: 54004be9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030e5c: d37cec09    	lsl	x9, x0, #4
100030e60: d37ced08    	lsl	x8, x8, #4
100030e64: aa1f03e1    	mov	x1, xzr
100030e68: b8696ae9    	ldr	w9, [x23, x9]
100030e6c: b8686ae8    	ldr	w8, [x23, x8]
100030e70: 6b08013f    	cmp	w9, w8
100030e74: 1a9f17e0    	cset	w0, eq
100030e78: 17fffcd7    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030e7c: b9400f60    	ldr	w0, [x27, #0xc]
100030e80: eb00027f    	cmp	x19, x0
100030e84: 54004aa9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030e88: b9401368    	ldr	w8, [x27, #0x10]
100030e8c: eb08027f    	cmp	x19, x8
100030e90: 54004a29    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030e94: d37cec09    	lsl	x9, x0, #4
100030e98: d37ced08    	lsl	x8, x8, #4
100030e9c: aa1f03e1    	mov	x1, xzr
100030ea0: b8696ae9    	ldr	w9, [x23, x9]
100030ea4: b8686ae8    	ldr	w8, [x23, x8]
100030ea8: 6b08013f    	cmp	w9, w8
100030eac: 1a9f37e0    	cset	w0, hs
100030eb0: 17fffcc9    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030eb4: b9400f60    	ldr	w0, [x27, #0xc]
100030eb8: eb00027f    	cmp	x19, x0
100030ebc: 540048e9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030ec0: b9401368    	ldr	w8, [x27, #0x10]
100030ec4: eb08027f    	cmp	x19, x8
100030ec8: 54004869    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030ecc: d37cec09    	lsl	x9, x0, #4
100030ed0: d37ced08    	lsl	x8, x8, #4
100030ed4: aa1f03e1    	mov	x1, xzr
100030ed8: b8696ae9    	ldr	w9, [x23, x9]
100030edc: b8686ae8    	ldr	w8, [x23, x8]
100030ee0: 1b097d00    	mul	w0, w8, w9
100030ee4: 17fffcbc    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ee8: b9400f60    	ldr	w0, [x27, #0xc]
100030eec: eb00027f    	cmp	x19, x0
100030ef0: 54004749    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030ef4: b9401368    	ldr	w8, [x27, #0x10]
100030ef8: eb08027f    	cmp	x19, x8
100030efc: 540046c9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030f00: d37cec09    	lsl	x9, x0, #4
100030f04: d37ced08    	lsl	x8, x8, #4
100030f08: aa1f03e1    	mov	x1, xzr
100030f0c: b8696ae9    	ldr	w9, [x23, x9]
100030f10: b8686ae8    	ldr	w8, [x23, x8]
100030f14: 6b08013f    	cmp	w9, w8
100030f18: 1a9fc7e0    	cset	w0, le
100030f1c: 17fffcae    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030f20: b9400f60    	ldr	w0, [x27, #0xc]
100030f24: eb00027f    	cmp	x19, x0
100030f28: 54004589    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030f2c: b9401368    	ldr	w8, [x27, #0x10]
100030f30: eb08027f    	cmp	x19, x8
100030f34: 54004509    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030f38: d37cec09    	lsl	x9, x0, #4
100030f3c: d37ced08    	lsl	x8, x8, #4
100030f40: aa1f03e1    	mov	x1, xzr
100030f44: b8696ae9    	ldr	w9, [x23, x9]
100030f48: b8686ae8    	ldr	w8, [x23, x8]
100030f4c: 6b08013f    	cmp	w9, w8
100030f50: 1a9fd7e0    	cset	w0, gt
100030f54: 17fffca0    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030f58: b9400f60    	ldr	w0, [x27, #0xc]
100030f5c: eb00027f    	cmp	x19, x0
100030f60: 540043c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030f64: b9401368    	ldr	w8, [x27, #0x10]
100030f68: eb08027f    	cmp	x19, x8
100030f6c: 54004349    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030f70: d37cec09    	lsl	x9, x0, #4
100030f74: d37ced08    	lsl	x8, x8, #4
100030f78: aa1f03e1    	mov	x1, xzr
100030f7c: b8696ae9    	ldr	w9, [x23, x9]
100030f80: b8686ae8    	ldr	w8, [x23, x8]
100030f84: 1ac82d20    	ror	w0, w9, w8
100030f88: 17fffc93    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030f8c: b9400f60    	ldr	w0, [x27, #0xc]
100030f90: eb00027f    	cmp	x19, x0
100030f94: 54004229    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030f98: b9401368    	ldr	w8, [x27, #0x10]
100030f9c: eb08027f    	cmp	x19, x8
100030fa0: 540041a9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030fa4: d37cec09    	lsl	x9, x0, #4
100030fa8: d37ced08    	lsl	x8, x8, #4
100030fac: aa1f03e1    	mov	x1, xzr
100030fb0: f8696ae9    	ldr	x9, [x23, x9]
100030fb4: f8686ae8    	ldr	x8, [x23, x8]
100030fb8: eb08013f    	cmp	x9, x8
100030fbc: 1a9fa7e0    	cset	w0, lt
100030fc0: 17fffc85    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030fc4: b9400f60    	ldr	w0, [x27, #0xc]
100030fc8: eb00027f    	cmp	x19, x0
100030fcc: 54004069    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100030fd0: b9401368    	ldr	w8, [x27, #0x10]
100030fd4: eb08027f    	cmp	x19, x8
100030fd8: 54003fe9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100030fdc: d37cec09    	lsl	x9, x0, #4
100030fe0: d37ced08    	lsl	x8, x8, #4
100030fe4: f8696ae9    	ldr	x9, [x23, x9]
100030fe8: f8686ae8    	ldr	x8, [x23, x8]
100030fec: 9ac82d20    	ror	x0, x9, x8
100030ff0: aa1f03e1    	mov	x1, xzr
100030ff4: 17fffc78    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100030ff8: b9400f60    	ldr	w0, [x27, #0xc]
100030ffc: eb00027f    	cmp	x19, x0
100031000: 54003ec9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031004: b9401368    	ldr	w8, [x27, #0x10]
100031008: eb08027f    	cmp	x19, x8
10003100c: 54003e49    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031010: d37cec09    	lsl	x9, x0, #4
100031014: d37ced08    	lsl	x8, x8, #4
100031018: aa1f03e1    	mov	x1, xzr
10003101c: b8696ae9    	ldr	w9, [x23, x9]
100031020: b8686ae8    	ldr	w8, [x23, x8]
100031024: 6b08013f    	cmp	w9, w8
100031028: 1a9f97e0    	cset	w0, hi
10003102c: 17fffc6a    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031030: b9400f60    	ldr	w0, [x27, #0xc]
100031034: eb00027f    	cmp	x19, x0
100031038: 54003d09    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003103c: d37cec08    	lsl	x8, x0, #4
100031040: aa1f03e1    	mov	x1, xzr
100031044: 38a86ae0    	ldrsb	x0, [x23, x8]
100031048: 17fffc63    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003104c: b9400f60    	ldr	w0, [x27, #0xc]
100031050: eb00027f    	cmp	x19, x0
100031054: 54003c29    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031058: d37cec08    	lsl	x8, x0, #4
10003105c: aa1f03e1    	mov	x1, xzr
100031060: 78a86ae0    	ldrsh	x0, [x23, x8]
100031064: 17fffc5c    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031068: b9400f60    	ldr	w0, [x27, #0xc]
10003106c: eb00027f    	cmp	x19, x0
100031070: 54003b49    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031074: b9401368    	ldr	w8, [x27, #0x10]
100031078: eb08027f    	cmp	x19, x8
10003107c: 54003ac9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031080: d37cec09    	lsl	x9, x0, #4
100031084: d37ced08    	lsl	x8, x8, #4
100031088: aa1f03e1    	mov	x1, xzr
10003108c: f8696ae9    	ldr	x9, [x23, x9]
100031090: f8686ae8    	ldr	x8, [x23, x8]
100031094: eb08013f    	cmp	x9, x8
100031098: 1a9f17e0    	cset	w0, eq
10003109c: 17fffc4e    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000310a0: b9400f60    	ldr	w0, [x27, #0xc]
1000310a4: eb00027f    	cmp	x19, x0
1000310a8: 54003989    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000310ac: b9401368    	ldr	w8, [x27, #0x10]
1000310b0: eb08027f    	cmp	x19, x8
1000310b4: 54003909    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000310b8: d37cec09    	lsl	x9, x0, #4
1000310bc: d37ced08    	lsl	x8, x8, #4
1000310c0: aa1f03e1    	mov	x1, xzr
1000310c4: f8696ae9    	ldr	x9, [x23, x9]
1000310c8: f8686ae8    	ldr	x8, [x23, x8]
1000310cc: eb08013f    	cmp	x9, x8
1000310d0: 1a9f37e0    	cset	w0, hs
1000310d4: 17fffc40    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000310d8: b9400f60    	ldr	w0, [x27, #0xc]
1000310dc: eb00027f    	cmp	x19, x0
1000310e0: 540037c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000310e4: b9401368    	ldr	w8, [x27, #0x10]
1000310e8: eb08027f    	cmp	x19, x8
1000310ec: 54003749    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000310f0: d37cec09    	lsl	x9, x0, #4
1000310f4: d37ced08    	lsl	x8, x8, #4
1000310f8: aa1f03e1    	mov	x1, xzr
1000310fc: f8696ae9    	ldr	x9, [x23, x9]
100031100: f8686ae8    	ldr	x8, [x23, x8]
100031104: eb08013f    	cmp	x9, x8
100031108: 1a9fb7e0    	cset	w0, ge
10003110c: 17fffc32    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031110: b9400f60    	ldr	w0, [x27, #0xc]
100031114: eb00027f    	cmp	x19, x0
100031118: 54003609    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003111c: b9401368    	ldr	w8, [x27, #0x10]
100031120: eb08027f    	cmp	x19, x8
100031124: 54003589    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031128: d37cec09    	lsl	x9, x0, #4
10003112c: d37ced08    	lsl	x8, x8, #4
100031130: aa1f03e1    	mov	x1, xzr
100031134: f8696ae9    	ldr	x9, [x23, x9]
100031138: f8686ae8    	ldr	x8, [x23, x8]
10003113c: 9ac82920    	asr	x0, x9, x8
100031140: 17fffc25    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031144: b9400f60    	ldr	w0, [x27, #0xc]
100031148: eb00027f    	cmp	x19, x0
10003114c: 54003469    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031150: b9401368    	ldr	w8, [x27, #0x10]
100031154: eb08027f    	cmp	x19, x8
100031158: 540033e9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003115c: d37cec09    	lsl	x9, x0, #4
100031160: d37ced08    	lsl	x8, x8, #4
100031164: aa1f03e1    	mov	x1, xzr
100031168: b8696ae9    	ldr	w9, [x23, x9]
10003116c: b8686ae8    	ldr	w8, [x23, x8]
100031170: 0a080120    	and	w0, w9, w8
100031174: 17fffc18    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031178: b9400f60    	ldr	w0, [x27, #0xc]
10003117c: eb00027f    	cmp	x19, x0
100031180: 540032c9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031184: b9401368    	ldr	w8, [x27, #0x10]
100031188: eb08027f    	cmp	x19, x8
10003118c: 54003249    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
100031190: d37cec09    	lsl	x9, x0, #4
100031194: d37ced08    	lsl	x8, x8, #4
100031198: aa1f03e1    	mov	x1, xzr
10003119c: b8696ae9    	ldr	w9, [x23, x9]
1000311a0: b8686ae8    	ldr	w8, [x23, x8]
1000311a4: 0b090100    	add	w0, w8, w9
1000311a8: 17fffc0b    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000311ac: b9400f60    	ldr	w0, [x27, #0xc]
1000311b0: eb00027f    	cmp	x19, x0
1000311b4: 54003129    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000311b8: b9401368    	ldr	w8, [x27, #0x10]
1000311bc: eb08027f    	cmp	x19, x8
1000311c0: 540030a9    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
1000311c4: d37cec09    	lsl	x9, x0, #4
1000311c8: d37ced08    	lsl	x8, x8, #4
1000311cc: aa1f03e1    	mov	x1, xzr
1000311d0: f8696ae9    	ldr	x9, [x23, x9]
1000311d4: f8686ae8    	ldr	x8, [x23, x8]
1000311d8: 9b097d00    	mul	x0, x8, x9
1000311dc: 17fffbfe    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000311e0: b9400f60    	ldr	w0, [x27, #0xc]
1000311e4: eb00027f    	cmp	x19, x0
1000311e8: 54002f89    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000311ec: d37cec08    	lsl	x8, x0, #4
1000311f0: aa1f03e1    	mov	x1, xzr
1000311f4: 38a86ae8    	ldrsb	x8, [x23, x8]
1000311f8: 2a0803e0    	mov	w0, w8
1000311fc: 17fffbf6    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031200: b9400f60    	ldr	w0, [x27, #0xc]
100031204: eb00027f    	cmp	x19, x0
100031208: 54002e89    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
10003120c: d37cec08    	lsl	x8, x0, #4
100031210: 5280040a    	mov	w10, #0x20              ; =32
100031214: aa1f03e1    	mov	x1, xzr
100031218: f8686ae8    	ldr	x8, [x23, x8]
10003121c: d360fd09    	lsr	x9, x8, #32
100031220: f100013f    	cmp	x9, #0x0
100031224: 9a881128    	csel	x8, x9, x8, ne
100031228: 9a9f114a    	csel	x10, x10, xzr, ne
10003122c: d350fd09    	lsr	x9, x8, #16
100031230: f100013f    	cmp	x9, #0x0
100031234: 9a881128    	csel	x8, x9, x8, ne
100031238: b27c0149    	orr	x9, x10, #0x10
10003123c: d348fd0b    	lsr	x11, x8, #8
100031240: 9a8a1129    	csel	x9, x9, x10, ne
100031244: f103fd1f    	cmp	x8, #0xff
100031248: b27d012a    	orr	x10, x9, #0x8
10003124c: 9a888168    	csel	x8, x11, x8, hi
100031250: d000148b    	adrp	x11, 0x1002c3000 <__llgo_ifacebox$O4qBo0EAyIIrlNtrmtT79e8Z3f5Yx6QzEL2rBxTG5wY+0xcb0>
100031254: 912b956b    	add	x11, x11, #0xae5
100031258: 92401d08    	and	x8, x8, #0xff
10003125c: 9a898149    	csel	x9, x10, x9, hi
100031260: 5280080a    	mov	w10, #0x40              ; =64
100031264: 38686968    	ldrb	w8, [x11, x8]
100031268: cb090149    	sub	x9, x10, x9
10003126c: cb080120    	sub	x0, x9, x8
100031270: 17fffbd9    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031274: b9400f60    	ldr	w0, [x27, #0xc]
100031278: eb00027f    	cmp	x19, x0
10003127c: 54002ae9    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
100031280: b9401368    	ldr	w8, [x27, #0x10]
100031284: eb08027f    	cmp	x19, x8
100031288: 54002a69    	b.ls	0x1000317d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f50>
10003128c: d37cec09    	lsl	x9, x0, #4
100031290: d37ced08    	lsl	x8, x8, #4
100031294: aa1f03e1    	mov	x1, xzr
100031298: f8696ae9    	ldr	x9, [x23, x9]
10003129c: f8686ae8    	ldr	x8, [x23, x8]
1000312a0: 9ac82120    	lsl	x0, x9, x8
1000312a4: 17fffbcc    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000312a8: b9400f60    	ldr	w0, [x27, #0xc]
1000312ac: eb00027f    	cmp	x19, x0
1000312b0: 54002949    	b.ls	0x1000317d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f54>
1000312b4: d37cec08    	lsl	x8, x0, #4
1000312b8: aa1f03e1    	mov	x1, xzr
1000312bc: 78a86ae8    	ldrsh	x8, [x23, x8]
1000312c0: 2a0803e0    	mov	w0, w8
1000312c4: 17fffbc4    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000312c8: 51022d28    	sub	w8, w9, #0x8b
1000312cc: 7100d11f    	cmp	w8, #0x34
1000312d0: 540000c8    	b.hi	0x1000312e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1a64>
1000312d4: 92a2000a    	mov	x10, #-0x10000001       ; =-268435457
1000312d8: f2dfff2a    	movk	x10, #0xfff9, lsl #32
1000312dc: f2e003ea    	movk	x10, #0x1f, lsl #48
1000312e0: 9ac82548    	lsr	x8, x10, x8
1000312e4: 37074488    	tbnz	w8, #0x0, 0x10002fb74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
1000312e8: 51018528    	sub	w8, w9, #0x61
1000312ec: aa1f03e0    	mov	x0, xzr
1000312f0: 7100851f    	cmp	w8, #0x21
1000312f4: 54001628    	b.hi	0x1000315b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d34>
1000312f8: b2620fea    	mov	x10, #0x3c0000000       ; =16106127360
1000312fc: aa0003e1    	mov	x1, x0
100031300: f29e07ea    	movk	x10, #0xf03f
100031304: 9ac82548    	lsr	x8, x10, x8
100031308: 37074368    	tbnz	w8, #0x0, 0x10002fb74 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2f0>
10003130c: 17fffbb2    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031310: aa1f03e5    	mov	x5, xzr
100031314: b9401360    	ldr	w0, [x27, #0x10]
100031318: 3100041f    	cmn	w0, #0x1
10003131c: 54ffa581    	b.ne	0x1000307cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf48>
100031320: aa1f03e7    	mov	x7, xzr
100031324: b9401760    	ldr	w0, [x27, #0x14]
100031328: 3100041f    	cmn	w0, #0x1
10003132c: 54ffa5e1    	b.ne	0x1000307e8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf64>
100031330: aa1f03ea    	mov	x10, xzr
100031334: 12103d28    	and	w8, w9, #0xffff0000
100031338: 717f811f    	cmp	w8, #0xfe0, lsl #12     ; =0xfe0000
10003133c: 54ffa640    	b.eq	0x100030804 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xf80>
100031340: 529ffda8    	mov	w8, #0xffed             ; =65517
100031344: 72bfe068    	movk	w8, #0xff03, lsl #16
100031348: 0b090108    	add	w8, w8, w9
10003134c: 11002d08    	add	w8, w8, #0xb
100031350: 7100291f    	cmp	w8, #0xa
100031354: 54002c42    	b.hs	0x1000318dc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2058>
100031358: f9404201    	ldr	x1, [x16, #0x80]
10003135c: b9400760    	ldr	w0, [x27, #0x4]
100031360: eb00003f    	cmp	x1, x0
100031364: 54002369    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100031368: f9403e08    	ldr	x8, [x16, #0x78]
10003136c: 52801c09    	mov	w9, #0xe0               ; =224
100031370: 9ba92008    	umaddl	x8, w0, w9, x8
100031374: b40015e8    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031378: b9400109    	ldr	w9, [x8]
10003137c: f940050b    	ldr	x11, [x8, #0x8]
100031380: 910363ec    	add	x12, sp, #0xd8
100031384: 3dc00500    	ldr	q0, [x8, #0x10]
100031388: 3cc48101    	ldur	q1, [x8, #0x48]
10003138c: 910363e2    	add	x2, sp, #0xd8
100031390: b900dbe9    	str	w9, [sp, #0xd8]
100031394: 3cc68102    	ldur	q2, [x8, #0x68]
100031398: aa1503e0    	mov	x0, x21
10003139c: f90073eb    	str	x11, [sp, #0xe0]
1000313a0: a9422d09    	ldp	x9, x11, [x8, #0x20]
1000313a4: 3d800580    	str	q0, [x12, #0x10]
1000313a8: aa0503e3    	mov	x3, x5
1000313ac: aa1f03e4    	mov	x4, xzr
1000313b0: 3dc00d00    	ldr	q0, [x8, #0x30]
1000313b4: 3c848181    	stur	q1, [x12, #0x48]
1000313b8: aa0703e5    	mov	x5, x7
1000313bc: a90fafe9    	stp	x9, x11, [sp, #0xf8]
1000313c0: 39410109    	ldrb	w9, [x8, #0x40]
1000313c4: aa1f03e6    	mov	x6, xzr
1000313c8: 3d800d80    	str	q0, [x12, #0x30]
1000313cc: 3cc58100    	ldur	q0, [x8, #0x58]
1000313d0: aa0a03e7    	mov	x7, x10
1000313d4: 390463e9    	strb	w9, [sp, #0x118]
1000313d8: 3cc78101    	ldur	q1, [x8, #0x78]
1000313dc: f94013e1    	ldr	x1, [sp, #0x20]
1000313e0: 3c858180    	stur	q0, [x12, #0x58]
1000313e4: 3cc88100    	ldur	q0, [x8, #0x88]
1000313e8: a949a109    	ldp	x9, x8, [x8, #0x98]
1000313ec: 3c868182    	stur	q2, [x12, #0x68]
1000313f0: 3c878181    	stur	q1, [x12, #0x78]
1000313f4: 3c888180    	stur	q0, [x12, #0x88]
1000313f8: a91723e9    	stp	x9, x8, [sp, #0x170]
1000313fc: 9102c3e8    	add	x8, sp, #0xb0
100031400: f90003ff    	str	xzr, [sp]
100031404: 9400114e    	bl	0x10003593c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk>
100031408: a94b07e0    	ldp	x0, x1, [sp, #0xb0]
10003140c: f94067e8    	ldr	x8, [sp, #0xc8]
100031410: 394303f9    	ldrb	w25, [sp, #0xc0]
100031414: b4ff6da8    	cbz	x8, 0x1000301c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
100031418: f9400509    	ldr	x9, [x8, #0x8]
10003141c: f94017f0    	ldr	x16, [sp, #0x28]
100031420: b4ff6d69    	cbz	x9, 0x1000301cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
100031424: 140000dc    	b	0x100031794 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f10>
100031428: f9400b28    	ldr	x8, [x25, #0x10]
10003142c: f94017f0    	ldr	x16, [sp, #0x28]
100031430: aa1f03e1    	mov	x1, xzr
100031434: 3940c508    	ldrb	w8, [x8, #0x31]
100031438: 7200011f    	tst	w8, #0x1
10003143c: 3902bfe8    	strb	w8, [sp, #0xaf]
100031440: 12800008    	mov	w8, #-0x1               ; =-1
100031444: da9f0100    	csinv	x0, x8, xzr, eq
100031448: 17fffb63    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003144c: b4000a88    	cbz	x8, 0x10003159c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d18>
100031450: c8dffd08    	ldar	x8, [x8]
100031454: b4000a80    	cbz	x0, 0x1000315a4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d20>
100031458: f9401c09    	ldr	x9, [x0, #0x38]
10003145c: 52a0002a    	mov	w10, #0x10000           ; =65536
100031460: aa1f03e1    	mov	x1, xzr
100031464: f100013f    	cmp	x9, #0x0
100031468: 9a890149    	csel	x9, x10, x9, eq
10003146c: 9ac90900    	udiv	x0, x8, x9
100031470: 17fffb59    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
100031474: aa1f03e0    	mov	x0, xzr
100031478: aa1f03e2    	mov	x2, xzr
10003147c: 14000003    	b	0x100031488 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c04>
100031480: f9400408    	ldr	x8, [x0, #0x8]
100031484: b5001028    	cbnz	x8, 0x100031688 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e04>
100031488: f9408602    	ldr	x2, [x16, #0x108]
10003148c: 0b190348    	add	w8, w26, w25
100031490: eb08005f    	cmp	x2, x8
100031494: 54001f43    	b.lo	0x10003187c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ff8>
100031498: 6b08033f    	cmp	w25, w8
10003149c: 54001e68    	b.hi	0x100031868 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1fe4>
1000314a0: cb190049    	sub	x9, x2, x25
1000314a4: d37df32a    	lsl	x10, x25, #3
1000314a8: f100013f    	cmp	x9, #0x0
1000314ac: 9a9fc149    	csel	x9, x10, xzr, gt
1000314b0: 3400025a    	cbz	w26, 0x1000314f8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c74>
1000314b4: f9407e0a    	ldr	x10, [x16, #0xf8]
1000314b8: b94017fa    	ldr	w26, [sp, #0x14]
1000314bc: 8b09014a    	add	x10, x10, x9
1000314c0: cb190109    	sub	x9, x8, x25
1000314c4: 9100114a    	add	x10, x10, #0x4
1000314c8: b9400140    	ldr	w0, [x10]
1000314cc: eb00027f    	cmp	x19, x0
1000314d0: 54001749    	b.ls	0x1000317b8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f34>
1000314d4: b85fc148    	ldur	w8, [x10, #-0x4]
1000314d8: eb08027f    	cmp	x19, x8
1000314dc: 54001729    	b.ls	0x1000317c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f3c>
1000314e0: 3ce07ae0    	ldr	q0, [x23, x0, lsl #4]
1000314e4: f1000529    	subs	x9, x9, #0x1
1000314e8: 9100214a    	add	x10, x10, #0x8
1000314ec: 3ca87ae0    	str	q0, [x23, x8, lsl #4]
1000314f0: 54fffec1    	b.ne	0x1000314c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1c44>
1000314f4: 17fff913    	b	0x10002f940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
1000314f8: b94017fa    	ldr	w26, [sp, #0x14]
1000314fc: 17fff911    	b	0x10002f940 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0xbc>
100031500: f9404201    	ldr	x1, [x16, #0x80]
100031504: b9400760    	ldr	w0, [x27, #0x4]
100031508: eb00003f    	cmp	x1, x0
10003150c: 54001629    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100031510: f9403e08    	ldr	x8, [x16, #0x78]
100031514: 52801c09    	mov	w9, #0xe0               ; =224
100031518: 9ba92008    	umaddl	x8, w0, w9, x8
10003151c: b40008a8    	cbz	x8, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031520: f94013e9    	ldr	x9, [sp, #0x20]
100031524: b9401900    	ldr	w0, [x8, #0x18]
100031528: f9403d21    	ldr	x1, [x9, #0x78]
10003152c: eb00003f    	cmp	x1, x0
100031530: 54001509    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100031534: f9403929    	ldr	x9, [x9, #0x70]
100031538: ab000d29    	adds	x9, x9, x0, lsl #3
10003153c: 540007a0    	b.eq	0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031540: f9400129    	ldr	x9, [x9]
100031544: b4000769    	cbz	x9, 0x100031630 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1dac>
100031548: a94006ab    	ldp	x11, x1, [x21]
10003154c: b940150c    	ldr	w12, [x8, #0x14]
100031550: b9401d08    	ldr	w8, [x8, #0x1c]
100031554: f9400aa2    	ldr	x2, [x21, #0x10]
100031558: f9400920    	ldr	x0, [x9, #0x10]
10003155c: f9400563    	ldr	x3, [x11, #0x8]
100031560: aa088186    	orr	x6, x12, x8, lsl #32
100031564: d10283a8    	sub	x8, x29, #0xa0
100031568: f90003ea    	str	x10, [sp]
10003156c: 94006ca3    	bl	0x10004c7f8 <_github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic>
100031570: a97607a0    	ldp	x0, x1, [x29, #-0xa0]
100031574: f85783a8    	ldur	x8, [x29, #-0x88]
100031578: 385703b9    	ldurb	w25, [x29, #-0x90]
10003157c: b4ff6268    	cbz	x8, 0x1000301c8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x944>
100031580: f9400509    	ldr	x9, [x8, #0x8]
100031584: f94017f0    	ldr	x16, [sp, #0x28]
100031588: b4ff6229    	cbz	x9, 0x1000301cc <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x948>
10003158c: 14000084    	b	0x10003179c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f18>
100031590: aa1f03e1    	mov	x1, xzr
100031594: 52800400    	mov	w0, #0x20               ; =32
100031598: 17fffb0f    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
10003159c: f9400408    	ldr	x8, [x0, #0x8]
1000315a0: b5fff5c0    	cbnz	x0, 0x100031458 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1bd4>
1000315a4: 52800020    	mov	w0, #0x1                ; =1
1000315a8: 9407b970    	bl	0x10021fb68 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
1000315ac: f94017f0    	ldr	x16, [sp, #0x28]
1000315b0: aa1f03e1    	mov	x1, xzr
1000315b4: 17fffb08    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000315b8: aa0003e1    	mov	x1, x0
1000315bc: 17fffb06    	b	0x1000301d4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x950>
1000315c0: f9400fe8    	ldr	x8, [sp, #0x18]
1000315c4: aa1503e0    	mov	x0, x21
1000315c8: b81c8118    	stur	w24, [x8, #-0x38]
1000315cc: 94000815    	bl	0x100033620 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime>
1000315d0: 72001c1f    	tst	w0, #0xff
1000315d4: 54000601    	b.ne	0x100031694 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e10>
1000315d8: f94026a8    	ldr	x8, [x21, #0x48]
1000315dc: f100011f    	cmp	x8, #0x0
1000315e0: 54ff170c    	b.gt	0x10002f8c0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x3c>
1000315e4: 140000b8    	b	0x1000318c4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2040>
1000315e8: f9400fe8    	ldr	x8, [sp, #0x18]
1000315ec: aa1503e0    	mov	x0, x21
1000315f0: b81c8118    	stur	w24, [x8, #-0x38]
1000315f4: 9400044e    	bl	0x10003272c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall>
1000315f8: 17fffff6    	b	0x1000315d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
1000315fc: f9400fe8    	ldr	x8, [sp, #0x18]
100031600: aa1503e0    	mov	x0, x21
100031604: b81c8118    	stur	w24, [x8, #-0x38]
100031608: 94000708    	bl	0x100033228 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow>
10003160c: 17fffff1    	b	0x1000315d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d4c>
100031610: f9400fe8    	ldr	x8, [sp, #0x18]
100031614: aa1503e0    	mov	x0, x21
100031618: b81c8118    	stur	w24, [x8, #-0x38]
10003161c: 94000352    	bl	0x100032364 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame>
100031620: 12001c08    	and	w8, w0, #0xff
100031624: 3607fda8    	tbz	w8, #0x0, 0x1000315d8 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1d54>
100031628: 52800020    	mov	w0, #0x1                ; =1
10003162c: 14000051    	b	0x100031770 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
100031630: 52800020    	mov	w0, #0x1                ; =1
100031634: 9407b94d    	bl	0x10021fb68 <_github.com/xgo-dev/llgo/runtime/internal/runtime.AssertNilDeref>
100031638: aa1f03e0    	mov	x0, xzr
10003163c: 1400004d    	b	0x100031770 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
100031640: 52800500    	mov	w0, #0x28               ; =40
100031644: 94080b5a    	bl	0x1002343ac <dyld_stub_binder+0x1002343ac>
100031648: b4001560    	cbz	x0, 0x1000318f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
10003164c: aa0003f3    	mov	x19, x0
100031650: 52800500    	mov	w0, #0x28               ; =40
100031654: 9407a7f8    	bl	0x10021b634 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
100031658: f9400728    	ldr	x8, [x25, #0x8]
10003165c: f0001ce9    	adrp	x9, 0x1003d0000 <_github.com/xgo-dev/llgo/runtime/internal/runtime.zeroVal+0x3eb>
100031660: f00013aa    	adrp	x10, 0x1002a8000 <dyld_stub_binder+0x1002a8000>
100031664: 9130354a    	add	x10, x10, #0xc0d
100031668: 3dc28520    	ldr	q0, [x9, #0xa10]
10003166c: b0001681    	adrp	x1, 0x100302000 <__llgo_struct$kDADcsfuYnWHKwu6knvjTms7pjj568Ox_PNV-pR6hSQ$fields+0x58>
100031670: 910fa021    	add	x1, x1, #0x3e8
100031674: a9012a68    	stp	x8, x10, [x19, #0x10]
100031678: 528001c8    	mov	w8, #0xe                ; =14
10003167c: 3d800260    	str	q0, [x19]
100031680: f9001268    	str	x8, [x19, #0x20]
100031684: 14000037    	b	0x100031760 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1edc>
100031688: aa0003e1    	mov	x1, x0
10003168c: aa1503e0    	mov	x0, x21
100031690: 14000036    	b	0x100031768 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
100031694: 92401c00    	and	x0, x0, #0xff
100031698: 14000036    	b	0x100031770 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1eec>
10003169c: f9404ff3    	ldr	x19, [sp, #0x98]
1000316a0: 52800100    	mov	w0, #0x8                ; =8
1000316a4: 94080b42    	bl	0x1002343ac <dyld_stub_binder+0x1002343ac>
1000316a8: b4001260    	cbz	x0, 0x1000318f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
1000316ac: aa0003f6    	mov	x22, x0
1000316b0: 52800100    	mov	w0, #0x8                ; =8
1000316b4: 9407a7e0    	bl	0x10021b634 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
1000316b8: 900015a2    	adrp	x2, 0x1002e5000 <_*_llgo_github.com/cpunion/wasmvm/internal/engine/state.ScalarAccess+0x78>
1000316bc: 910f8042    	add	x2, x2, #0x3e0
1000316c0: aa1903e0    	mov	x0, x25
1000316c4: aa1303e1    	mov	x1, x19
1000316c8: aa1603e3    	mov	x3, x22
1000316cc: 9407261d    	bl	0x1001faf40 <_errors.As>
1000316d0: f94007e9    	ldr	x9, [sp, #0x8]
1000316d4: 36000080    	tbz	w0, #0x0, 0x1000316e4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e60>
1000316d8: f94002c8    	ldr	x8, [x22]
1000316dc: b9405129    	ldr	w9, [x9, #0x50]
1000316e0: b9000509    	str	w9, [x8, #0x4]
1000316e4: aa1503e0    	mov	x0, x21
1000316e8: aa1903e1    	mov	x1, x25
1000316ec: 1400001e    	b	0x100031764 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee0>
1000316f0: 52800079    	mov	w25, #0x3               ; =3
1000316f4: 14000004    	b	0x100031704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
1000316f8: 52800039    	mov	w25, #0x1               ; =1
1000316fc: 14000002    	b	0x100031704 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1e80>
100031700: 52800139    	mov	w25, #0x9               ; =9
100031704: 52800200    	mov	w0, #0x10               ; =16
100031708: 94080b26    	bl	0x1002343a0 <dyld_stub_binder+0x1002343a0>
10003170c: b4000f40    	cbz	x0, 0x1000318f4 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x2070>
100031710: aa0003f3    	mov	x19, x0
100031714: 52800200    	mov	w0, #0x10               ; =16
100031718: 9407a7c7    	bl	0x10021b634 <_github.com/xgo-dev/llgo/runtime/internal/runtime.recordMemProfileAlloc>
10003171c: f94017e9    	ldr	x9, [sp, #0x28]
100031720: a9007e7f    	stp	xzr, xzr, [x19]
100031724: b9400760    	ldr	w0, [x27, #0x4]
100031728: f9404121    	ldr	x1, [x9, #0x80]
10003172c: eb00003f    	cmp	x1, x0
100031730: 54000509    	b.ls	0x1000317d0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f4c>
100031734: 52801c08    	mov	w8, #0xe0               ; =224
100031738: f9403d29    	ldr	x9, [x9, #0x78]
10003173c: 900015a1    	adrp	x1, 0x1002e5000 <_*_llgo_github.com/cpunion/wasmvm/internal/engine/state.ScalarAccess+0x78>
100031740: 911d2021    	add	x1, x1, #0x748
100031744: 9ba82408    	umaddl	x8, w0, w8, x9
100031748: f94007e9    	ldr	x9, [sp, #0x8]
10003174c: b9405129    	ldr	w9, [x9, #0x50]
100031750: f9400508    	ldr	x8, [x8, #0x8]
100031754: 39000279    	strb	w25, [x19]
100031758: b9000669    	str	w9, [x19, #0x4]
10003175c: f9000668    	str	x8, [x19, #0x8]
100031760: aa1503e0    	mov	x0, x21
100031764: aa1303e2    	mov	x2, x19
100031768: 97fff4e9    	bl	0x10002eb0c <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail>
10003176c: 52800060    	mov	w0, #0x3                ; =3
100031770: aa1403e1    	mov	x1, x20
100031774: 910743ff    	add	sp, sp, #0x1d0
100031778: a9457bfd    	ldp	x29, x30, [sp, #0x50]
10003177c: a9444ff4    	ldp	x20, x19, [sp, #0x40]
100031780: a94357f6    	ldp	x22, x21, [sp, #0x30]
100031784: a9425ff8    	ldp	x24, x23, [sp, #0x20]
100031788: a94167fa    	ldp	x26, x25, [sp, #0x10]
10003178c: a8c66ffc    	ldp	x28, x27, [sp], #0x60
100031790: d65f03c0    	ret
100031794: f9406be2    	ldr	x2, [sp, #0xd0]
100031798: 14000002    	b	0x1000317a0 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1f1c>
10003179c: f85803a2    	ldur	x2, [x29, #-0x80]
1000317a0: aa1503e0    	mov	x0, x21
1000317a4: aa0803e1    	mov	x1, x8
1000317a8: 17fffff0    	b	0x100031768 <_github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop+0x1ee4>
1000317ac: aa1803e0    	mov	x0, x24
1000317b0: aa1603e1    	mov	x1, x22
1000317b4: 9407ad4b    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000317b8: aa1303e1    	mov	x1, x19
1000317bc: 9407a7dc    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000317c0: aa0803e0    	mov	x0, x8
1000317c4: aa1303e1    	mov	x1, x19
1000317c8: 9407a7d9    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000317cc: aa1603e1    	mov	x1, x22
1000317d0: 9407ad44    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000317d4: aa0803e0    	mov	x0, x8
1000317d8: aa1303e1    	mov	x1, x19
1000317dc: 9407ad41    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000317e0: aa0803e0    	mov	x0, x8
1000317e4: 9407ad3f    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000317e8: aa0a03e0    	mov	x0, x10
1000317ec: aa1303e1    	mov	x1, x19
1000317f0: 9407ad3c    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
1000317f4: aa0903e0    	mov	x0, x9
1000317f8: 52800021    	mov	w1, #0x1                ; =1
1000317fc: 52800043    	mov	w3, #0x2                ; =2
100031800: 9407ab11    	bl	0x10021c444 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031804: aa0803e0    	mov	x0, x8
100031808: 52800021    	mov	w1, #0x1                ; =1
10003180c: aa0903e2    	mov	x2, x9
100031810: 52800063    	mov	w3, #0x3                ; =3
100031814: 9407ab0c    	bl	0x10021c444 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031818: aa0b03e0    	mov	x0, x11
10003181c: aa1303e1    	mov	x1, x19
100031820: 9407ad30    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031824: aa0903e0    	mov	x0, x9
100031828: aa1303e1    	mov	x1, x19
10003182c: 9407ad2d    	bl	0x10021cce0 <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndexU>
100031830: 52800020    	mov	w0, #0x1                ; =1
100031834: 9407a7be    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031838: aa1f03e0    	mov	x0, xzr
10003183c: aa1f03e1    	mov	x1, xzr
100031840: 9407a7bb    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031844: aa0803e0    	mov	x0, x8
100031848: 2a1f03e1    	mov	w1, wzr
10003184c: aa0a03e2    	mov	x2, x10
100031850: 52800063    	mov	w3, #0x3                ; =3
100031854: 9407aafc    	bl	0x10021c444 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031858: aa0a03e0    	mov	x0, x10
10003185c: 2a1f03e1    	mov	w1, wzr
100031860: 52800043    	mov	w3, #0x2                ; =2
100031864: 9407aaf8    	bl	0x10021c444 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
100031868: aa1903e0    	mov	x0, x25
10003186c: 2a1f03e1    	mov	w1, wzr
100031870: aa0803e2    	mov	x2, x8
100031874: 52800063    	mov	w3, #0x3                ; =3
100031878: 9407aaf3    	bl	0x10021c444 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003187c: aa0803e0    	mov	x0, x8
100031880: 2a1f03e1    	mov	w1, wzr
100031884: 52800043    	mov	w3, #0x2                ; =2
100031888: 9407aaef    	bl	0x10021c444 <_github.com/xgo-dev/llgo/runtime/internal/runtime.panicBounds>
10003188c: 52800060    	mov	w0, #0x3                ; =3
100031890: 9407a7a7    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
100031894: 52800040    	mov	w0, #0x2                ; =2
100031898: 52800041    	mov	w1, #0x2                ; =2
10003189c: 9407a7a4    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000318a0: aa0903e0    	mov	x0, x9
1000318a4: aa1303e1    	mov	x1, x19
1000318a8: 9407a7a1    	bl	0x10021b72c <_github.com/xgo-dev/llgo/runtime/internal/runtime.PanicIndex>
1000318ac: 90001940    	adrp	x0, 0x100359000 <__llgo_func$0MAhD-4Wo_spr87bqPaEJkBw5MFRclWcO_B99CB4cG8+0x28>
1000318b0: 9123c000    	add	x0, x0, #0x8f0
1000318b4: 90001941    	adrp	x1, 0x100359000 <__llgo_func$0MAhD-4Wo_spr87bqPaEJkBw5MFRclWcO_B99CB4cG8+0x28>
1000318b8: 912dc021    	add	x1, x1, #0xb70
1000318bc: 9407a6d9    	bl	0x10021b420 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
1000318c0: d4200020    	brk	#0x1
1000318c4: d0001980    	adrp	x0, 0x100363000 <__llgo_iface$O6rEVxIuA5O1E0KWpQBCgGx26X5gYhJ_nnJnHVL8_7U+0x20>
1000318c8: 9108a000    	add	x0, x0, #0x228
1000318cc: 900015a1    	adrp	x1, 0x1002e5000 <_*_llgo_github.com/cpunion/wasmvm/internal/engine/state.ScalarAccess+0x78>
1000318d0: 9110c021    	add	x1, x1, #0x430
1000318d4: 9407a6d3    	bl	0x10021b420 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
1000318d8: d4200020    	brk	#0x1
1000318dc: d0001980    	adrp	x0, 0x100363000 <__llgo_iface$O6rEVxIuA5O1E0KWpQBCgGx26X5gYhJ_nnJnHVL8_7U+0x20>
1000318e0: 9108a000    	add	x0, x0, #0x228
1000318e4: 900015a1    	adrp	x1, 0x1002e5000 <_*_llgo_github.com/cpunion/wasmvm/internal/engine/state.ScalarAccess+0x78>
1000318e8: 91110021    	add	x1, x1, #0x440
1000318ec: 9407a6cd    	bl	0x10021b420 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
1000318f0: d4200020    	brk	#0x1
1000318f4: d0001980    	adrp	x0, 0x100363000 <__llgo_iface$O6rEVxIuA5O1E0KWpQBCgGx26X5gYhJ_nnJnHVL8_7U+0x20>
1000318f8: 9108a000    	add	x0, x0, #0x228
1000318fc: 90001941    	adrp	x1, 0x100359000 <__llgo_func$0MAhD-4Wo_spr87bqPaEJkBw5MFRclWcO_B99CB4cG8+0x28>
100031900: 91238021    	add	x1, x1, #0x8e0
100031904: 9407a6c7    	bl	0x10021b420 <_github.com/xgo-dev/llgo/runtime/internal/runtime.Panic>
100031908: d4200020    	brk	#0x1
