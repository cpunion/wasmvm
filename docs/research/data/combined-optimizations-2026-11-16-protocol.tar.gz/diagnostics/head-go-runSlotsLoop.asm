TEXT github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB) /Users/lijie/source/goplus/wasmvm-source-cleanup/internal/engine/execute/execution.go
  execution.go:325	0x10020f810		f9400b90		MOVD 16(R28), R16									
  execution.go:325	0x10020f814		d10703f1		SUB $448, RSP, R17									
  execution.go:325	0x10020f818		eb10023f		CMP R16, R17										
  execution.go:325	0x10020f81c		54013b09		BLS 2520(PC)										
  execution.go:325	0x10020f820		d10903f4		SUB $576, RSP, R20									
  execution.go:325	0x10020f824		a93ffa9d		STP (R29, R30), -8(R20)									
  execution.go:325	0x10020f828		9100029f		MOVD R20, RSP										
  execution.go:325	0x10020f82c		d10023fd		SUB $8, RSP, R29									
  execution.go:327	0x10020f830		f90127e0		MOVD R0, 584(RSP)									
  execution.go:326	0x10020f834		39408009		MOVBU 32(R0), R9									
  execution.go:326	0x10020f838		3903dfe9		MOVB R9, 247(RSP)									
  execution.go:327	0x10020f83c		14000004		JMP 4(PC)										
  execution.go:327	0x10020f840		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x10020f844		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:328	0x10020f848		f94093e1		MOVD 288(RSP), R1									
  execution.go:327	0x10020f84c		a9442c0a		LDP 64(R0), (R10, R11)									
  execution.go:327	0x10020f850		b40138ab		CBZ R11, 2501(PC)									
  execution.go:328	0x10020f854		d100056b		SUB $1, R11, R11									
  execution.go:329	0x10020f858		8b0b194a		ADD R11<<6, R10, R10									
  execution.go:330	0x10020f85c		3900415f		MOVB ZR, 16(R10)									
  execution.go:331	0x10020f860		f940014b		MOVD (R10), R11										
  execution.go:334	0x10020f864		f9400d4c		MOVD 24(R10), R12									
  execution.go:332	0x10020f868		a944396d		LDP 64(R11), (R13, R14)									
  execution.go:333	0x10020f86c		a94b41cf		LDP 176(R14), (R15, R16)								
  execution.go:337	0x10020f870		f9404411		MOVD 136(R0), R17									
  execution.go:337	0x10020f874		f9404dd3		MOVD 152(R14), R19									
  execution.go:337	0x10020f878		8b130194		ADD R19, R12, R20									
  execution.go:337	0x10020f87c		eb14023f		CMP R20, R17										
  execution.go:337	0x10020f880		540136c3		BCC 2486(PC)										
  execution.go:337	0x10020f884		eb14019f		CMP R20, R12										
  execution.go:337	0x10020f888		54013648		BHI 2482(PC)										
  execution.go:329	0x10020f88c		f900b7ea		MOVD R10, 360(RSP)									
  execution.go:331	0x10020f890		f900b3eb		MOVD R11, 352(RSP)									
  execution.go:332	0x10020f894		f900bfee		MOVD R14, 376(RSP)									
  execution.go:335	0x10020f898		f900abed		MOVD R13, 336(RSP)									
  execution.go:337	0x10020f89c		f90087f3		MOVD R19, 264(RSP)									
  execution.go:333	0x10020f8a0		f9008bf0		MOVD R16, 272(RSP)									
  execution.go:333	0x10020f8a4		f900a7ef		MOVD R15, 328(RSP)									
  execution.go:337	0x10020f8a8		f9403c14		MOVD 120(R0), R20									
  execution.go:337	0x10020f8ac		cb110191		SUB R17, R12, R17									
  execution.go:337	0x10020f8b0		8a91fd8c		AND R17->63, R12, R12									
  execution.go:336	0x10020f8b4		b9400951		MOVWU 8(R10), R17									
  execution.go:337	0x10020f8b8		8b0c128c		ADD R12<<4, R20, R12									
  execution.go:337	0x10020f8bc		f9009bec		MOVD R12, 304(RSP)									
  execution.go:338	0x10020f8c0		14000002		JMP 2(PC)										
  execution.go:341	0x10020f8c4		aa1503e1		MOVD R21, R1										
  execution.go:341	0x10020f8c8		2a1103f4		MOVW R17, R20										
  execution.go:341	0x10020f8cc		eb10029f		CMP R16, R20										
  execution.go:341	0x10020f8d0		540133a2		BCS 2461(PC)										
  execution.go:341	0x10020f8d4		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:342	0x10020f8d8		360002c9		TBZ $0, R9, 22(PC)									
  execution.go:343	0x10020f8dc		a947d9d5		LDP 120(R14), (R21, R22)								
  execution.go:343	0x10020f8e0		b9400697		MOVWU 4(R20), R23									
  execution.go:343	0x10020f8e4		aa1703f8		MOVD R23, R24										
  execution.go:343	0x10020f8e8		eb16031f		CMP R22, R24										
  execution.go:343	0x10020f8ec		54013262		BCS 2451(PC)										
  execution.go:343	0x10020f8f0		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:343	0x10020f8f4		cb1816d6		SUB R24<<5, R22, R22									
  ir.go:27		0x10020f8f8		b8766ab7		MOVWU (R21)(R22), R23									
  execution.go:343	0x10020f8fc		8b1602b5		ADD R22, R21, R21									
  ir.go:27		0x10020f900		710016ff		CMPW $5, R23										
  ir.go:27		0x10020f904		54000060		BEQ 3(PC)										
  ir.go:27		0x10020f908		71002eff		CMPW $11, R23										
  ir.go:27		0x10020f90c		54000061		BNE 3(PC)										
  execution.go:344	0x10020f910		aa1f03e2		MOVD ZR, R2										
  execution.go:344	0x10020f914		14000002		JMP 2(PC)										
  execution.go:344	0x10020f918		b24003e2		ORR $1, ZR, R2										
  execution.go:345	0x10020f91c		f940a816		MOVD 336(R0), R22									
  execution.go:345	0x10020f920		eb16005f		CMP R22, R2										
  execution.go:345	0x10020f924		5400de88		BHI 1780(PC)										
  execution.go:348	0x10020f928		cb0202d5		SUB R2, R22, R21									
  execution.go:348	0x10020f92c		f900a815		MOVD R21, 336(R0)									
  execution.go:350	0x10020f930		91000435		ADD $1, R1, R21										
  execution.go:351	0x10020f934		f24016bf		TST $63, R21										
  execution.go:351	0x10020f938		54000421		BNE 33(PC)										
  execution.go:341	0x10020f93c		f900aff4		MOVD R20, 344(RSP)									
  execution.go:350	0x10020f940		f90097f5		MOVD R21, 296(RSP)									
  execution.go:341	0x10020f944		b900fbf1		MOVW R17, 248(RSP)									
  execution.go:209	0x10020f948		f940b016		MOVD 352(R0), R22									
  execution.go:209	0x10020f94c		b40000d6		CBZ R22, 6(PC)										
  type.go:19		0x10020f950		88dffed6		LDARW (R22), R22									
  execution.go:209	0x10020f954		35000096		CBNZW R22, 4(PC)									
  execution.go:212	0x10020f958		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x10020f95c		aa1f03e2		MOVD ZR, R2										
  execution.go:352	0x10020f960		14000013		JMP 19(PC)										
  execution.go:212	0x10020f964		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x10020f968		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x10020f96c		d63f0020		CALL (R1)										
  execution.go:356	0x10020f970		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x10020f974		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10020f978		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x10020f97c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10020f980		f940abed		MOVD 336(RSP), R13									
  execution.go:434	0x10020f984		f940bfee		MOVD 376(RSP), R14									
  execution.go:364	0x10020f988		f940a7ef		MOVD 328(RSP), R15									
  execution.go:364	0x10020f98c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:360	0x10020f990		b940fbf1		MOVWU 248(RSP), R17									
  execution.go:361	0x10020f994		f94087f3		MOVD 264(RSP), R19									
  execution.go:360	0x10020f998		f940aff4		MOVD 344(RSP), R20									
  execution.go:360	0x10020f99c		f94097f5		MOVD 296(RSP), R21									
  execution.go:212	0x10020f9a0		aa0103e2		MOVD R1, R2										
  execution.go:212	0x10020f9a4		aa0003e1		MOVD R0, R1										
  execution.go:353	0x10020f9a8		f94127e0		MOVD 584(RSP), R0									
  execution.go:352	0x10020f9ac		b4000081		CBZ R1, 4(PC)										
  execution.go:352	0x10020f9b0		140006f2		JMP 1778(PC)										
  execution.go:364	0x10020f9b4		8b1415f4		ADD R20<<5, R15, R20									
  execution.go:365	0x10020f9b8		910006b5		ADD $1, R21, R21									
  execution.go:356	0x10020f9bc		b9401e96		MOVWU 28(R20), R22									
  execution.go:356	0x10020f9c0		340002f6		CBZW R22, 23(PC)									
  execution.go:356	0x10020f9c4		b9400297		MOVWU (R20), R23									
  execution.go:356	0x10020f9c8		710082ff		CMPW $32, R23										
  execution.go:356	0x10020f9cc		54000060		BEQ 3(PC)										
  execution.go:356	0x10020f9d0		710106ff		CMPW $65, R23										
  execution.go:356	0x10020f9d4		54000241		BNE 18(PC)										
  execution.go:356	0x10020f9d8		37000229		TBNZ $0, R9, 17(PC)									
  execution.go:356	0x10020f9dc		924016b8		AND $63, R21, R24									
  execution.go:356	0x10020f9e0		f100ff1f		CMP $63, R24										
  execution.go:356	0x10020f9e4		540001c0		BEQ 14(PC)										
  execution.go:360	0x10020f9e8		710106ff		CMPW $65, R23										
  execution.go:360	0x10020f9ec		540000e1		BNE 7(PC)										
  execution.go:361	0x10020f9f0		b9400a96		MOVWU 8(R20), R22									
  execution.go:361	0x10020f9f4		eb1302df		CMP R19, R22										
  execution.go:361	0x10020f9f8		540129a2		BCS 2381(PC)										
  execution.go:361	0x10020f9fc		8b161196		ADD R22<<4, R12, R22									
  execution.go:361	0x10020fa00		b9401a94		MOVWU 24(R20), R20									
  execution.go:361	0x10020fa04		a9007ed4		STP (R20, ZR), (R22)									
  execution.go:363	0x10020fa08		91000631		ADD $1, R17, R17									
  execution.go:364	0x10020fa0c		2a1103f4		MOVW R17, R20										
  execution.go:364	0x10020fa10		eb10029f		CMP R16, R20										
  execution.go:364	0x10020fa14		54fffd03		BCC -24(PC)										
  execution.go:364	0x10020fa18		14000942		JMP 2370(PC)										
  execution.go:360	0x10020fa1c		b90107f1		MOVW R17, 260(RSP)									
  execution.go:360	0x10020fa20		f90093f5		MOVD R21, 288(RSP)									
  execution.go:360	0x10020fa24		f900c3f4		MOVD R20, 384(RSP)									
  execution.go:371	0x10020fa28		b9400281		MOVWU (R20), R1										
  execution.go:371	0x10020fa2c		d1038037		SUB $224, R1, R23									
  execution.go:371	0x10020fa30		d29fe418		MOVD $65312, R24									
  execution.go:371	0x10020fa34		f2a01ff8		MOVK $(255<<16), R24									
  execution.go:371	0x10020fa38		6b1802ff		CMPW R24, R23										
  execution.go:371	0x10020fa3c		54002822		BCS 321(PC)										
  execution.go:372	0x10020fa40		d3507c37		UBFX $16, R1, $16, R23									
  execution.go:396	0x10020fa44		7103eeff		CMPW $251, R23										
  execution.go:396	0x10020fa48		540019e0		BEQ 207(PC)										
  execution.go:432	0x10020fa4c		7103f2ff		CMPW $252, R23										
  execution.go:432	0x10020fa50		54000ba1		BNE 93(PC)										
  wide.go:3		0x10020fa54		d2800277		MOVD $19, R23										
  wide.go:3		0x10020fa58		f2a01f97		MOVK $(252<<16), R23									
  wide.go:3		0x10020fa5c		cb170038		SUB R23, R1, R24									
  wide.go:3		0x10020fa60		71000f1f		CMPW $3, R24										
  execution.go:433	0x10020fa64		540026e8		BHI 311(PC)										
  execution.go:434	0x10020fa68		f9406dd8		MOVD 216(R14), R24									
  execution.go:434	0x10020fa6c		b9401a94		MOVWU 24(R20), R20									
  execution.go:434	0x10020fa70		8b160299		ADD R22, R20, R25									
  execution.go:434	0x10020fa74		91000b39		ADD $2, R25, R25									
  execution.go:434	0x10020fa78		2a1903f9		MOVW R25, R25										
  execution.go:434	0x10020fa7c		eb18033f		CMP R24, R25										
  execution.go:434	0x10020fa80		540124a8		BHI 2341(PC)										
  execution.go:434	0x10020fa84		eb19029f		CMP R25, R20										
  execution.go:434	0x10020fa88		54012408		BHI 2336(PC)										
  execution.go:434	0x10020fa8c		f94065da		MOVD 200(R14), R26									
  execution.go:434	0x10020fa90		cb180298		SUB R24, R20, R24									
  execution.go:434	0x10020fa94		8a98fe98		AND R24->63, R20, R24									
  execution.go:434	0x10020fa98		8b180b5e		ADD R24<<2, R26, R30									
  execution.go:434	0x10020fa9c		cb140334		SUB R20, R25, R20									
  execution.go:435	0x10020faa0		b4012334		CBZ R20, 2329(PC)									
  execution.go:435	0x10020faa4		b8787b58		MOVWU (R26)(R24<<2), R24								
  execution.go:435	0x10020faa8		eb13031f		CMP R19, R24										
  execution.go:435	0x10020faac		54012262		BCS 2323(PC)										
  execution.go:435	0x10020fab0		8b181198		ADD R24<<4, R12, R24									
  execution.go:435	0x10020fab4		f100069f		CMP $1, R20										
  execution.go:435	0x10020fab8		540121e9		BLS 2319(PC)										
  execution.go:435	0x10020fabc		b94007d9		MOVWU 4(R30), R25									
  execution.go:435	0x10020fac0		eb13033f		CMP R19, R25										
  execution.go:435	0x10020fac4		54012122		BCS 2313(PC)										
  execution.go:435	0x10020fac8		8b191199		ADD R25<<4, R12, R25									
  execution.go:435	0x10020facc		f9400318		MOVD (R24), R24										
  execution.go:435	0x10020fad0		f9400339		MOVD (R25), R25										
  execution.go:438	0x10020fad4		d280029a		MOVD $20, R26										
  execution.go:438	0x10020fad8		f2a01f9a		MOVK $(252<<16), R26									
  execution.go:438	0x10020fadc		6b1a003f		CMPW R26, R1										
  execution.go:438	0x10020fae0		540002e8		BHI 23(PC)										
  execution.go:439	0x10020fae4		f1000a9f		CMP $2, R20										
  execution.go:439	0x10020fae8		54011fe9		BLS 2303(PC)										
  execution.go:439	0x10020faec		b9400bda		MOVWU 8(R30), R26									
  execution.go:439	0x10020faf0		eb13035f		CMP R19, R26										
  execution.go:439	0x10020faf4		54011f22		BCS 2297(PC)										
  execution.go:439	0x10020faf8		8b1a119a		ADD R26<<4, R12, R26									
  execution.go:439	0x10020fafc		f1000e9f		CMP $3, R20										
  execution.go:439	0x10020fb00		54011ea9		BLS 2293(PC)										
  execution.go:439	0x10020fb04		b9400fc2		MOVWU 12(R30), R2									
  execution.go:439	0x10020fb08		eb13005f		CMP R19, R2										
  execution.go:439	0x10020fb0c		54011e02		BCS 2288(PC)										
  execution.go:439	0x10020fb10		8b021182		ADD R2<<4, R12, R2									
  execution.go:439	0x10020fb14		f940035a		MOVD (R26), R26										
  execution.go:439	0x10020fb18		f9400042		MOVD (R2), R2										
  execution.go:441	0x10020fb1c		6b17003f		CMPW R23, R1										
  execution.go:441	0x10020fb20		54000081		BNE 4(PC)										
  execution.go:442	0x10020fb24		ab180357		ADDS R24, R26, R23									
  execution.go:443	0x10020fb28		ba020338		ADCS R2, R25, R24									
  <autogenerated>:1	0x10020fb2c		14000013		JMP 19(PC)										
  execution.go:445	0x10020fb30		eb1a0317		SUBS R26, R24, R23									
  execution.go:446	0x10020fb34		fa020338		SBCS R2, R25, R24									
  <autogenerated>:1	0x10020fb38		14000010		JMP 16(PC)										
  execution.go:449	0x10020fb3c		9b187f37		MUL R24, R25, R23									
  execution.go:449	0x10020fb40		9bd97f1a		UMULH R25, R24, R26									
  execution.go:331	0x10020fb44		aa0b03e2		MOVD R11, R2										
  execution.go:450	0x10020fb48		d28002ab		MOVD $21, R11										
  execution.go:450	0x10020fb4c		f2a01f8b		MOVK $(252<<16), R11									
  execution.go:450	0x10020fb50		6b0b003f		CMPW R11, R1										
  execution.go:450	0x10020fb54		540000e1		BNE 7(PC)										
  execution.go:452	0x10020fb58		cb19034b		SUB R25, R26, R11									
  execution.go:451	0x10020fb5c		f100031f		CMP $0, R24										
  execution.go:452	0x10020fb60		9a9ab16b		CSEL LT, R11, R26, R11									
  execution.go:455	0x10020fb64		cb180178		SUB R24, R11, R24									
  execution.go:454	0x10020fb68		f100033f		CMP $0, R25										
  execution.go:455	0x10020fb6c		9a8bb31a		CSEL LT, R24, R11, R26									
  execution.go:786	0x10020fb70		aa0203eb		MOVD R2, R11										
  execution.go:441	0x10020fb74		aa1a03f8		MOVD R26, R24										
  execution.go:459	0x10020fb78		910006d9		ADD $1, R22, R25									
  execution.go:459	0x10020fb7c		2a1903f9		MOVW R25, R25										
  execution.go:459	0x10020fb80		eb14033f		CMP R20, R25										
  execution.go:459	0x10020fb84		540119e2		BCS 2255(PC)										
  execution.go:459	0x10020fb88		b8797bd9		MOVWU (R30)(R25<<2), R25								
  execution.go:459	0x10020fb8c		eb1402df		CMP R20, R22										
  execution.go:459	0x10020fb90		54011922		BCS 2249(PC)										
  execution.go:459	0x10020fb94		b8767bd4		MOVWU (R30)(R22<<2), R20								
  execution.go:459	0x10020fb98		eb13029f		CMP R19, R20										
  execution.go:459	0x10020fb9c		54011862		BCS 2243(PC)										
  execution.go:459	0x10020fba0		8b141194		ADD R20<<4, R12, R20									
  execution.go:459	0x10020fba4		a9007e97		STP (R23, ZR), (R20)									
  execution.go:459	0x10020fba8		eb13033f		CMP R19, R25										
  execution.go:459	0x10020fbac		54011782		BCS 2236(PC)										
  execution.go:459	0x10020fbb0		8b191194		ADD R25<<4, R12, R20									
  execution.go:459	0x10020fbb4		a9007e98		STP (R24, ZR), (R20)									
  execution.go:460	0x10020fbb8		91000631		ADD $1, R17, R17									
  execution.go:461	0x10020fbbc		b9000951		MOVW R17, 8(R10)									
  execution.go:462	0x10020fbc0		17ffff41		JMP -191(PC)										
  execution.go:373	0x10020fbc4		7103f6ff		CMPW $253, R23										
  execution.go:373	0x10020fbc8		54000080		BEQ 4(PC)										
  execution.go:465	0x10020fbcc		7103983f		CMPW $230, R1										
  execution.go:465	0x10020fbd0		54001b88		BHI 220(PC)										
  execution.go:465	0x10020fbd4		1400062f		JMP 1583(PC)										
  execution.go:375	0x10020fbd8		b9400e87		MOVWU 12(R20), R7									
  execution.go:375	0x10020fbdc		310004ff		CMNW $1, R7										
  execution.go:375	0x10020fbe0		540000c0		BEQ 6(PC)										
  execution.go:376	0x10020fbe4		eb1300ff		CMP R19, R7										
  execution.go:376	0x10020fbe8		54011562		BCS 2219(PC)										
  execution.go:376	0x10020fbec		8b071187		ADD R7<<4, R12, R7									
  execution.go:376	0x10020fbf0		a9401ce2		LDP (R7), (R2, R7)									
  execution.go:376	0x10020fbf4		14000003		JMP 3(PC)										
  execution.go:376	0x10020fbf8		aa1f03e2		MOVD ZR, R2										
  execution.go:376	0x10020fbfc		aa1f03e7		MOVD ZR, R7										
  execution.go:378	0x10020fc00		b9401288		MOVWU 16(R20), R8									
  execution.go:378	0x10020fc04		3100051f		CMNW $1, R8										
  execution.go:378	0x10020fc08		540000c0		BEQ 6(PC)										
  execution.go:379	0x10020fc0c		eb13011f		CMP R19, R8										
  execution.go:379	0x10020fc10		540113e2		BCS 2207(PC)										
  execution.go:379	0x10020fc14		8b081188		ADD R8<<4, R12, R8									
  execution.go:379	0x10020fc18		a9401103		LDP (R8), (R3, R4)									
  execution.go:379	0x10020fc1c		14000003		JMP 3(PC)										
  execution.go:379	0x10020fc20		aa1f03e4		MOVD ZR, R4										
  execution.go:379	0x10020fc24		aa1f03e3		MOVD ZR, R3										
  execution.go:382	0x10020fc28		b9401688		MOVWU 20(R20), R8									
  execution.go:382	0x10020fc2c		3100051f		CMNW $1, R8										
  execution.go:382	0x10020fc30		540000c0		BEQ 6(PC)										
  execution.go:383	0x10020fc34		eb13011f		CMP R19, R8										
  execution.go:383	0x10020fc38		54011262		BCS 2195(PC)										
  execution.go:383	0x10020fc3c		8b081188		ADD R8<<4, R12, R8									
  execution.go:383	0x10020fc40		a9401905		LDP (R8), (R5, R6)									
  execution.go:383	0x10020fc44		14000003		JMP 3(PC)										
  execution.go:383	0x10020fc48		aa1f03e6		MOVD ZR, R6										
  execution.go:383	0x10020fc4c		aa1f03e5		MOVD ZR, R5										
  execution.go:385	0x10020fc50		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:385	0x10020fc54		b9400697		MOVWU 4(R20), R23									
  execution.go:385	0x10020fc58		aa1703f8		MOVD R23, R24										
  execution.go:385	0x10020fc5c		eb16031f		CMP R22, R24										
  execution.go:385	0x10020fc60		540110c2		BCS 2182(PC)										
  execution.go:385	0x10020fc64		d3787ef6		UBFIZ $8, R23, $32, R22									
  execution.go:385	0x10020fc68		cb1816d6		SUB R24<<5, R22, R22									
  execution.go:386	0x10020fc6c		d3403c37		UBFX $0, R1, $16, R23									
  execution.go:385	0x10020fc70		8b160108		ADD R22, R8, R8										
  execution.go:388	0x10020fc74		71002aff		CMPW $10, R23										
  execution.go:388	0x10020fc78		540000e9		BLS 7(PC)										
  execution.go:388	0x10020fc7c		d10152f6		SUB $84, R23, R22									
  execution.go:388	0x10020fc80		71000edf		CMPW $3, R22										
  execution.go:388	0x10020fc84		54000089		BLS 4(PC)										
  execution.go:388	0x10020fc88		b24002f6		ORR $1, R23, R22									
  execution.go:388	0x10020fc8c		710176df		CMPW $93, R22										
  execution.go:388	0x10020fc90		54000201		BNE 16(PC)										
  execution.go:389	0x10020fc94		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x10020fc98		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x10020fc9c		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x10020fca0		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:389	0x10020fca4		eb16031f		CMP R22, R24										
  execution.go:389	0x10020fca8		54010e22		BCS 2161(PC)										
  execution.go:389	0x10020fcac		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:389	0x10020fcb0		f94008e0		MOVD 16(R7), R0										
  execution.go:389	0x10020fcb4		39410107		MOVBU 64(R8), R7									
  execution.go:389	0x10020fcb8		aa0303e5		MOVD R3, R5										
  execution.go:389	0x10020fcbc		aa0403e6		MOVD R4, R6										
  execution.go:389	0x10020fcc0		aa1703e3		MOVD R23, R3										
  execution.go:389	0x10020fcc4		aa0703e4		MOVD R7, R4										
  execution.go:389	0x10020fcc8		97ffa312		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:389	0x10020fccc		1400001d		JMP 29(PC)										
  execution.go:390	0x10020fcd0		71002eff		CMPW $11, R23										
  execution.go:390	0x10020fcd4		54000080		BEQ 4(PC)										
  execution.go:390	0x10020fcd8		d10162f6		SUB $88, R23, R22									
  execution.go:390	0x10020fcdc		71000edf		CMPW $3, R22										
  execution.go:390	0x10020fce0		54000268		BHI 19(PC)										
  execution.go:391	0x10020fce4		a94759a7		LDP 112(R13), (R7, R22)									
  module.go:178		0x10020fce8		2942e117		LDPW 20(R8), (R23, R24)									
  module.go:178		0x10020fcec		b9401d19		MOVWU 28(R8), R25									
  module.go:178		0x10020fcf0		aa1982f7		ORR R25<<32, R23, R23									
  execution.go:391	0x10020fcf4		eb16031f		CMP R22, R24										
  execution.go:391	0x10020fcf8		54010b42		BCS 2138(PC)										
  execution.go:391	0x10020fcfc		f87878e7		MOVD (R7)(R24<<3), R7									
  execution.go:391	0x10020fd00		f94008e0		MOVD 16(R7), R0										
  execution.go:391	0x10020fd04		39410107		MOVBU 64(R8), R7									
  execution.go:391	0x10020fd08		aa0303e5		MOVD R3, R5										
  execution.go:391	0x10020fd0c		aa0403e6		MOVD R4, R6										
  execution.go:391	0x10020fd10		aa1703e3		MOVD R23, R3										
  execution.go:391	0x10020fd14		aa0703e4		MOVD R7, R4										
  execution.go:391	0x10020fd18		97ffa376		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:391	0x10020fd1c		aa0003e2		MOVD R0, R2										
  execution.go:393	0x10020fd20		aa1f03e1		MOVD ZR, R1										
  execution.go:393	0x10020fd24		aa1f03e0		MOVD ZR, R0										
  execution.go:391	0x10020fd28		14000006		JMP 6(PC)										
  execution.go:393	0x10020fd2c		aa0803e0		MOVD R8, R0										
  execution.go:393	0x10020fd30		aa0203e1		MOVD R2, R1										
  execution.go:393	0x10020fd34		aa0703e2		MOVD R7, R2										
  execution.go:393	0x10020fd38		97ffb362		CALL github.com/cpunion/wasmvm/internal/engine/simd.Eval(SB)				
  execution.go:391	0x10020fd3c		aa1f03e2		MOVD ZR, R2										
  execution.go:342	0x10020fd40		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x10020fd44		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10020fd48		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10020fd4c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10020fd50		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x10020fd54		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10020fd58		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10020fd5c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x10020fd60		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x10020fd64		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x10020fd68		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10020fd6c		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x10020fd70		aa0103f7		MOVD R1, R23										
  execution.go:395	0x10020fd74		aa0003f6		MOVD R0, R22										
  execution.go:209	0x10020fd78		f94127e0		MOVD 584(RSP), R0									
  execution.go:395	0x10020fd7c		aa0203e1		MOVD R2, R1										
  execution.go:395	0x10020fd80		140005b9		JMP 1465(PC)										
  gc_access.go:11	0x10020fd84		d3403c36		UBFX $0, R1, $16, R22									
  gc_access.go:11	0x10020fd88		710036df		CMPW $13, R22										
  gc_access.go:14	0x10020fd8c		54000148		BHI 10(PC)										
  gc_access.go:12	0x10020fd90		d1000ad7		SUB $2, R22, R23									
  gc_access.go:12	0x10020fd94		71000aff		CMPW $2, R23										
  gc_access.go:12	0x10020fd98		54000249		BLS 18(PC)										
  gc_access.go:14	0x10020fd9c		710016df		CMPW $5, R22										
  gc_access.go:14	0x10020fda0		54000060		BEQ 3(PC)										
  gc_access.go:14	0x10020fda4		71002edf		CMPW $11, R22										
  gc_access.go:14	0x10020fda8		54000203		BCC 16(PC)										
  gc_access.go:14	0x10020fdac		b27f03e1		ORR $2, ZR, R1										
  execution.go:400	0x10020fdb0		1400000f		JMP 15(PC)										
  gc_access.go:11	0x10020fdb4		71003edf		CMPW $15, R22										
  gc_access.go:12	0x10020fdb8		540000a8		BHI 5(PC)										
  gc_access.go:16	0x10020fdbc		71003adf		CMPW $14, R22										
  gc_access.go:16	0x10020fdc0		54000101		BNE 8(PC)										
  gc_access.go:16	0x10020fdc4		b24007e1		ORR $3, ZR, R1										
  execution.go:400	0x10020fdc8		14000009		JMP 9(PC)										
  gc_access.go:12	0x10020fdcc		d10072d7		SUB $28, R22, R23									
  gc_access.go:12	0x10020fdd0		71000aff		CMPW $2, R23										
  gc_access.go:12	0x10020fdd4		54000069		BLS 3(PC)										
  gc_access.go:12	0x10020fdd8		71008adf		CMPW $34, R22										
  gc_access.go:12	0x10020fddc		54000061		BNE 3(PC)										
  gc_access.go:12	0x10020fde0		b24003e1		ORR $1, ZR, R1										
  execution.go:400	0x10020fde4		14000002		JMP 2(PC)										
  execution.go:400	0x10020fde8		aa1f03e1		MOVD ZR, R1										
  execution.go:400	0x10020fdec		b40007e1		CBZ R1, 63(PC)										
  execution.go:402	0x10020fdf0		b9400e96		MOVWU 12(R20), R22									
  execution.go:402	0x10020fdf4		310006df		CMNW $1, R22										
  execution.go:402	0x10020fdf8		540000c0		BEQ 6(PC)										
  execution.go:403	0x10020fdfc		eb1302df		CMP R19, R22										
  execution.go:403	0x10020fe00		540102a2		BCS 2069(PC)										
  execution.go:403	0x10020fe04		8b161196		ADD R22<<4, R12, R22									
  execution.go:403	0x10020fe08		a94012c3		LDP (R22), (R3, R4)									
  execution.go:403	0x10020fe0c		14000003		JMP 3(PC)										
  execution.go:403	0x10020fe10		aa1f03e4		MOVD ZR, R4										
  execution.go:403	0x10020fe14		aa1f03e3		MOVD ZR, R3										
  execution.go:405	0x10020fe18		b9401296		MOVWU 16(R20), R22									
  execution.go:405	0x10020fe1c		310006df		CMNW $1, R22										
  execution.go:405	0x10020fe20		540000c0		BEQ 6(PC)										
  execution.go:406	0x10020fe24		eb1302df		CMP R19, R22										
  execution.go:406	0x10020fe28		54010102		BCS 2056(PC)										
  execution.go:406	0x10020fe2c		8b161196		ADD R22<<4, R12, R22									
  execution.go:406	0x10020fe30		a9401ac5		LDP (R22), (R5, R6)									
  execution.go:406	0x10020fe34		14000003		JMP 3(PC)										
  execution.go:406	0x10020fe38		aa1f03e6		MOVD ZR, R6										
  execution.go:406	0x10020fe3c		aa1f03e5		MOVD ZR, R5										
  execution.go:408	0x10020fe40		f100083f		CMP $2, R1										
  execution.go:408	0x10020fe44		540001ad		BLE 13(PC)										
  execution.go:409	0x10020fe48		a94cddd6		LDP 200(R14), (R22, R23)								
  execution.go:409	0x10020fe4c		b9401a98		MOVWU 24(R20), R24									
  execution.go:409	0x10020fe50		91000b18		ADD $2, R24, R24									
  execution.go:409	0x10020fe54		2a1803f8		MOVW R24, R24										
  execution.go:409	0x10020fe58		eb17031f		CMP R23, R24										
  execution.go:409	0x10020fe5c		5400ff02		BCS 2040(PC)										
  execution.go:409	0x10020fe60		b8787ad6		MOVWU (R22)(R24<<2), R22								
  execution.go:409	0x10020fe64		eb1302df		CMP R19, R22										
  execution.go:409	0x10020fe68		5400fe42		BCS 2034(PC)										
  execution.go:409	0x10020fe6c		8b161196		ADD R22<<4, R12, R22									
  execution.go:409	0x10020fe70		a94022c7		LDP (R22), (R7, R8)									
  execution.go:409	0x10020fe74		14000003		JMP 3(PC)										
  execution.go:409	0x10020fe78		aa1f03e7		MOVD ZR, R7										
  execution.go:409	0x10020fe7c		aa1f03e8		MOVD ZR, R8										
  execution.go:412	0x10020fe80		a947ddd6		LDP 120(R14), (R22, R23)								
  execution.go:412	0x10020fe84		b9400698		MOVWU 4(R20), R24									
  execution.go:412	0x10020fe88		aa1803f9		MOVD R24, R25										
  execution.go:412	0x10020fe8c		eb17033f		CMP R23, R25										
  execution.go:412	0x10020fe90		5400fca2		BCS 2021(PC)										
  execution.go:412	0x10020fe94		f9400000		MOVD (R0), R0										
  execution.go:412	0x10020fe98		d3787f09		UBFIZ $8, R24, $32, R9									
  execution.go:412	0x10020fe9c		cb191529		SUB R25<<5, R9, R9									
  execution.go:412	0x10020fea0		8b0902c2		ADD R9, R22, R2										
  execution.go:412	0x10020fea4		aa0d03e1		MOVD R13, R1										
  execution.go:412	0x10020fea8		97ffc37a		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GCAccess(SB)		
  execution.go:413	0x10020feac		b500b782		CBNZ R2, 1468(PC)									
  execution.go:420	0x10020feb0		f940c3e9		MOVD 384(RSP), R9									
  execution.go:420	0x10020feb4		b9400929		MOVWU 8(R9), R9										
  execution.go:420	0x10020feb8		3100053f		CMNW $1, R9										
  execution.go:420	0x10020febc		54000100		BEQ 8(PC)										
  execution.go:421	0x10020fec0		f94087ea		MOVD 264(RSP), R10									
  execution.go:421	0x10020fec4		eb0a013f		CMP R10, R9										
  execution.go:421	0x10020fec8		5400fac2		BCS 2006(PC)										
  execution.go:421	0x10020fecc		f9409beb		MOVD 304(RSP), R11									
  execution.go:421	0x10020fed0		8b091169		ADD R9<<4, R11, R9									
  execution.go:421	0x10020fed4		a9000520		STP (R0, R1), (R9)									
  execution.go:421	0x10020fed8		1400000a		JMP 10(PC)										
  execution.go:361	0x10020fedc		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x10020fee0		f9409beb		MOVD 304(RSP), R11									
  execution.go:420	0x10020fee4		14000007		JMP 7(PC)										
  execution.go:424	0x10020fee8		b9000951		MOVW R17, 8(R10)									
  execution.go:425	0x10020feec		9400091d		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runGC(SB)		
  execution.go:425	0x10020fef0		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:425	0x10020fef4		3500b8c1		CBNZW R1, 1478(PC)									
  execution.go:361	0x10020fef8		f94087ea		MOVD 264(RSP), R10									
  execution.go:361	0x10020fefc		f9409beb		MOVD 304(RSP), R11									
  execution.go:429	0x10020ff00		b94107e9		MOVWU 260(RSP), R9									
  execution.go:429	0x10020ff04		91000531		ADD $1, R9, R17										
  execution.go:430	0x10020ff08		f940b7e9		MOVD 360(RSP), R9									
  execution.go:430	0x10020ff0c		b9000931		MOVW R17, 8(R9)										
  execution.go:209	0x10020ff10		f94127e0		MOVD 584(RSP), R0									
  execution.go:342	0x10020ff14		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x10020ff18		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10020ff1c		f940b3eb		MOVD 352(RSP), R11									
  execution.go:361	0x10020ff20		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10020ff24		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x10020ff28		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10020ff2c		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10020ff30		f9408bf0		MOVD 272(RSP), R16									
  execution.go:361	0x10020ff34		f94087f3		MOVD 264(RSP), R19									
  execution.go:341	0x10020ff38		f94093f5		MOVD 288(RSP), R21									
  execution.go:431	0x10020ff3c		17fffe62		JMP -414(PC)										
  execution.go:479	0x10020ff40		d1011437		SUB $69, R1, R23									
  execution.go:479	0x10020ff44		7101feff		CMPW $127, R23										
  execution.go:479	0x10020ff48		54005468		BHI 675(PC)										
  execution.go:480	0x10020ff4c		aa0103f6		MOVD R1, R22										
  execution.go:480	0x10020ff50		d10116d6		SUB $69, R22, R22									
  execution.go:480	0x10020ff54		d0000fc2		ADRP 2072576(PC), R2									
  execution.go:480	0x10020ff58		91360042		ADD $3456, R2, R2									
  execution.go:480	0x10020ff5c		f876785b		MOVD (R2)(R22<<3), R27									
  execution.go:480	0x10020ff60		d61f0360		JMP (R27)										
  execution.go:482	0x10020ff64		b9400e96		MOVWU 12(R20), R22									
  execution.go:482	0x10020ff68		eb1302df		CMP R19, R22										
  execution.go:482	0x10020ff6c		5400f542		BCS 1962(PC)										
  execution.go:482	0x10020ff70		8b161196		ADD R22<<4, R12, R22									
  execution.go:482	0x10020ff74		f94002d6		MOVD (R22), R22										
  integer.go:9		0x10020ff78		710002df		CMPW $0, R22										
  integer.go:9		0x10020ff7c		9a9f17f6		CSET EQ, R22										
  execution.go:482	0x10020ff80		14000293		JMP 659(PC)										
  execution.go:484	0x10020ff84		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:484	0x10020ff88		eb1302df		CMP R19, R22										
  execution.go:484	0x10020ff8c		5400f3e2		BCS 1951(PC)										
  execution.go:484	0x10020ff90		8b161196		ADD R22<<4, R12, R22									
  execution.go:484	0x10020ff94		eb1302ff		CMP R19, R23										
  execution.go:484	0x10020ff98		5400f322		BCS 1945(PC)										
  execution.go:484	0x10020ff9c		f94002d8		MOVD (R22), R24										
  execution.go:484	0x10020ffa0		8b171197		ADD R23<<4, R12, R23									
  execution.go:484	0x10020ffa4		f94002f7		MOVD (R23), R23										
  integer.go:10		0x10020ffa8		6b1802ff		CMPW R24, R23										
  integer.go:10		0x10020ffac		9a9f17f6		CSET EQ, R22										
  execution.go:484	0x10020ffb0		14000287		JMP 647(PC)										
  execution.go:486	0x10020ffb4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:486	0x10020ffb8		eb1302df		CMP R19, R22										
  execution.go:486	0x10020ffbc		5400f1a2		BCS 1933(PC)										
  execution.go:486	0x10020ffc0		8b161196		ADD R22<<4, R12, R22									
  execution.go:486	0x10020ffc4		eb1302ff		CMP R19, R23										
  execution.go:486	0x10020ffc8		5400f0e2		BCS 1927(PC)										
  execution.go:486	0x10020ffcc		f94002d8		MOVD (R22), R24										
  execution.go:486	0x10020ffd0		8b171197		ADD R23<<4, R12, R23									
  execution.go:486	0x10020ffd4		f94002f7		MOVD (R23), R23										
  integer.go:11		0x10020ffd8		6b1802ff		CMPW R24, R23										
  integer.go:11		0x10020ffdc		9a9f07f6		CSET NE, R22										
  execution.go:486	0x10020ffe0		1400027b		JMP 635(PC)										
  execution.go:488	0x10020ffe4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:488	0x10020ffe8		eb1302df		CMP R19, R22										
  execution.go:488	0x10020ffec		5400ef62		BCS 1915(PC)										
  execution.go:488	0x10020fff0		8b161196		ADD R22<<4, R12, R22									
  execution.go:488	0x10020fff4		eb1302ff		CMP R19, R23										
  execution.go:488	0x10020fff8		5400eea2		BCS 1909(PC)										
  execution.go:488	0x10020fffc		f94002d8		MOVD (R22), R24										
  execution.go:488	0x100210000		8b171197		ADD R23<<4, R12, R23									
  execution.go:488	0x100210004		f94002f7		MOVD (R23), R23										
  integer.go:12		0x100210008		6b1802ff		CMPW R24, R23										
  integer.go:12		0x10021000c		9a9fd7f6		CSET GT, R22										
  execution.go:488	0x100210010		1400026f		JMP 623(PC)										
  execution.go:490	0x100210014		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:490	0x100210018		eb1302df		CMP R19, R22										
  execution.go:490	0x10021001c		5400ed22		BCS 1897(PC)										
  execution.go:490	0x100210020		8b161196		ADD R22<<4, R12, R22									
  execution.go:490	0x100210024		eb1302ff		CMP R19, R23										
  execution.go:490	0x100210028		5400ec62		BCS 1891(PC)										
  execution.go:490	0x10021002c		f94002d8		MOVD (R22), R24										
  execution.go:490	0x100210030		8b171197		ADD R23<<4, R12, R23									
  execution.go:490	0x100210034		f94002f7		MOVD (R23), R23										
  integer.go:13		0x100210038		6b1802ff		CMPW R24, R23										
  integer.go:13		0x10021003c		9a9f97f6		CSET HI, R22										
  execution.go:490	0x100210040		14000263		JMP 611(PC)										
  execution.go:492	0x100210044		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:492	0x100210048		eb1302df		CMP R19, R22										
  execution.go:492	0x10021004c		5400eae2		BCS 1879(PC)										
  execution.go:492	0x100210050		8b161196		ADD R22<<4, R12, R22									
  execution.go:492	0x100210054		eb1302ff		CMP R19, R23										
  execution.go:492	0x100210058		5400ea22		BCS 1873(PC)										
  execution.go:492	0x10021005c		f94002d8		MOVD (R22), R24										
  execution.go:492	0x100210060		8b171197		ADD R23<<4, R12, R23									
  execution.go:492	0x100210064		f94002f7		MOVD (R23), R23										
  integer.go:14		0x100210068		6b1802ff		CMPW R24, R23										
  integer.go:14		0x10021006c		9a9fa7f6		CSET LT, R22										
  execution.go:492	0x100210070		14000257		JMP 599(PC)										
  execution.go:494	0x100210074		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:494	0x100210078		eb1302df		CMP R19, R22										
  execution.go:494	0x10021007c		5400e8a2		BCS 1861(PC)										
  execution.go:494	0x100210080		8b161196		ADD R22<<4, R12, R22									
  execution.go:494	0x100210084		eb1302ff		CMP R19, R23										
  execution.go:494	0x100210088		5400e7e2		BCS 1855(PC)										
  execution.go:494	0x10021008c		f94002d8		MOVD (R22), R24										
  execution.go:494	0x100210090		8b171197		ADD R23<<4, R12, R23									
  execution.go:494	0x100210094		f94002f7		MOVD (R23), R23										
  integer.go:15		0x100210098		6b1802ff		CMPW R24, R23										
  integer.go:15		0x10021009c		9a9f27f6		CSET LO, R22										
  execution.go:494	0x1002100a0		1400024b		JMP 587(PC)										
  execution.go:496	0x1002100a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:496	0x1002100a8		eb1302df		CMP R19, R22										
  execution.go:496	0x1002100ac		5400e662		BCS 1843(PC)										
  execution.go:496	0x1002100b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:496	0x1002100b4		eb1302ff		CMP R19, R23										
  execution.go:496	0x1002100b8		5400e5a2		BCS 1837(PC)										
  execution.go:496	0x1002100bc		f94002d8		MOVD (R22), R24										
  execution.go:496	0x1002100c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:496	0x1002100c4		f94002f7		MOVD (R23), R23										
  integer.go:16		0x1002100c8		6b1802ff		CMPW R24, R23										
  integer.go:16		0x1002100cc		9a9fb7f6		CSET GE, R22										
  execution.go:496	0x1002100d0		1400023f		JMP 575(PC)										
  execution.go:498	0x1002100d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:498	0x1002100d8		eb1302df		CMP R19, R22										
  execution.go:498	0x1002100dc		5400e422		BCS 1825(PC)										
  execution.go:498	0x1002100e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:498	0x1002100e4		eb1302ff		CMP R19, R23										
  execution.go:498	0x1002100e8		5400e362		BCS 1819(PC)										
  execution.go:498	0x1002100ec		f94002d8		MOVD (R22), R24										
  execution.go:498	0x1002100f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:498	0x1002100f4		f94002f7		MOVD (R23), R23										
  integer.go:17		0x1002100f8		6b1802ff		CMPW R24, R23										
  integer.go:17		0x1002100fc		9a9f37f6		CSET HS, R22										
  execution.go:498	0x100210100		14000233		JMP 563(PC)										
  execution.go:500	0x100210104		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:500	0x100210108		eb1302df		CMP R19, R22										
  execution.go:500	0x10021010c		5400e1e2		BCS 1807(PC)										
  execution.go:500	0x100210110		8b161196		ADD R22<<4, R12, R22									
  execution.go:500	0x100210114		eb1302ff		CMP R19, R23										
  execution.go:500	0x100210118		5400e122		BCS 1801(PC)										
  execution.go:500	0x10021011c		f94002d8		MOVD (R22), R24										
  execution.go:500	0x100210120		8b171197		ADD R23<<4, R12, R23									
  execution.go:500	0x100210124		f94002f7		MOVD (R23), R23										
  integer.go:18		0x100210128		6b1802ff		CMPW R24, R23										
  integer.go:18		0x10021012c		9a9fc7f6		CSET LE, R22										
  execution.go:500	0x100210130		14000227		JMP 551(PC)										
  execution.go:502	0x100210134		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:502	0x100210138		eb1302df		CMP R19, R22										
  execution.go:502	0x10021013c		5400dfa2		BCS 1789(PC)										
  execution.go:502	0x100210140		8b161196		ADD R22<<4, R12, R22									
  execution.go:502	0x100210144		eb1302ff		CMP R19, R23										
  execution.go:502	0x100210148		5400dee2		BCS 1783(PC)										
  execution.go:502	0x10021014c		f94002d8		MOVD (R22), R24										
  execution.go:502	0x100210150		8b171197		ADD R23<<4, R12, R23									
  execution.go:502	0x100210154		f94002f7		MOVD (R23), R23										
  integer.go:19		0x100210158		6b1802ff		CMPW R24, R23										
  integer.go:19		0x10021015c		9a9f87f6		CSET LS, R22										
  execution.go:502	0x100210160		1400021b		JMP 539(PC)										
  execution.go:504	0x100210164		b9400e96		MOVWU 12(R20), R22									
  execution.go:504	0x100210168		eb1302df		CMP R19, R22										
  execution.go:504	0x10021016c		5400dd62		BCS 1771(PC)										
  execution.go:504	0x100210170		8b161197		ADD R22<<4, R12, R23									
  execution.go:504	0x100210174		f94002f7		MOVD (R23), R23										
  integer.go:20		0x100210178		f10002ff		CMP $0, R23										
  integer.go:20		0x10021017c		9a9f17f6		CSET EQ, R22										
  execution.go:504	0x100210180		14000213		JMP 531(PC)										
  execution.go:506	0x100210184		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:506	0x100210188		eb1302df		CMP R19, R22										
  execution.go:506	0x10021018c		5400dc02		BCS 1760(PC)										
  execution.go:506	0x100210190		8b161196		ADD R22<<4, R12, R22									
  execution.go:506	0x100210194		eb1302ff		CMP R19, R23										
  execution.go:506	0x100210198		5400db42		BCS 1754(PC)										
  execution.go:506	0x10021019c		f94002d8		MOVD (R22), R24										
  execution.go:506	0x1002101a0		8b171197		ADD R23<<4, R12, R23									
  execution.go:506	0x1002101a4		f94002f7		MOVD (R23), R23										
  integer.go:21		0x1002101a8		eb1802ff		CMP R24, R23										
  integer.go:21		0x1002101ac		9a9f17f6		CSET EQ, R22										
  execution.go:506	0x1002101b0		14000207		JMP 519(PC)										
  execution.go:508	0x1002101b4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:508	0x1002101b8		eb1302df		CMP R19, R22										
  execution.go:508	0x1002101bc		5400d9c2		BCS 1742(PC)										
  execution.go:508	0x1002101c0		8b161196		ADD R22<<4, R12, R22									
  execution.go:508	0x1002101c4		eb1302ff		CMP R19, R23										
  execution.go:508	0x1002101c8		5400d902		BCS 1736(PC)										
  execution.go:508	0x1002101cc		f94002d8		MOVD (R22), R24										
  execution.go:508	0x1002101d0		8b171197		ADD R23<<4, R12, R23									
  execution.go:508	0x1002101d4		f94002f7		MOVD (R23), R23										
  integer.go:22		0x1002101d8		eb1802ff		CMP R24, R23										
  integer.go:22		0x1002101dc		9a9f07f6		CSET NE, R22										
  execution.go:508	0x1002101e0		140001fb		JMP 507(PC)										
  execution.go:510	0x1002101e4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:510	0x1002101e8		eb1302df		CMP R19, R22										
  execution.go:510	0x1002101ec		5400d782		BCS 1724(PC)										
  execution.go:510	0x1002101f0		8b161196		ADD R22<<4, R12, R22									
  execution.go:510	0x1002101f4		eb1302ff		CMP R19, R23										
  execution.go:510	0x1002101f8		5400d6c2		BCS 1718(PC)										
  execution.go:510	0x1002101fc		f94002d8		MOVD (R22), R24										
  execution.go:510	0x100210200		8b171197		ADD R23<<4, R12, R23									
  execution.go:510	0x100210204		f94002f7		MOVD (R23), R23										
  integer.go:23		0x100210208		eb1802ff		CMP R24, R23										
  integer.go:23		0x10021020c		9a9fd7f6		CSET GT, R22										
  execution.go:510	0x100210210		140001ef		JMP 495(PC)										
  execution.go:512	0x100210214		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:512	0x100210218		eb1302df		CMP R19, R22										
  execution.go:512	0x10021021c		5400d542		BCS 1706(PC)										
  execution.go:512	0x100210220		8b161196		ADD R22<<4, R12, R22									
  execution.go:512	0x100210224		eb1302ff		CMP R19, R23										
  execution.go:512	0x100210228		5400d482		BCS 1700(PC)										
  execution.go:512	0x10021022c		f94002d8		MOVD (R22), R24										
  execution.go:512	0x100210230		8b171197		ADD R23<<4, R12, R23									
  execution.go:512	0x100210234		f94002f7		MOVD (R23), R23										
  integer.go:24		0x100210238		eb1802ff		CMP R24, R23										
  integer.go:24		0x10021023c		9a9f97f6		CSET HI, R22										
  execution.go:512	0x100210240		140001e3		JMP 483(PC)										
  execution.go:514	0x100210244		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:514	0x100210248		eb1302df		CMP R19, R22										
  execution.go:514	0x10021024c		5400d302		BCS 1688(PC)										
  execution.go:514	0x100210250		8b161196		ADD R22<<4, R12, R22									
  execution.go:514	0x100210254		eb1302ff		CMP R19, R23										
  execution.go:514	0x100210258		5400d242		BCS 1682(PC)										
  execution.go:514	0x10021025c		f94002d8		MOVD (R22), R24										
  execution.go:514	0x100210260		8b171197		ADD R23<<4, R12, R23									
  execution.go:514	0x100210264		f94002f7		MOVD (R23), R23										
  integer.go:25		0x100210268		eb1802ff		CMP R24, R23										
  integer.go:25		0x10021026c		9a9fa7f6		CSET LT, R22										
  execution.go:514	0x100210270		140001d7		JMP 471(PC)										
  execution.go:516	0x100210274		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:516	0x100210278		eb1302df		CMP R19, R22										
  execution.go:516	0x10021027c		5400d0c2		BCS 1670(PC)										
  execution.go:516	0x100210280		8b161196		ADD R22<<4, R12, R22									
  execution.go:516	0x100210284		eb1302ff		CMP R19, R23										
  execution.go:516	0x100210288		5400d002		BCS 1664(PC)										
  execution.go:516	0x10021028c		f94002d8		MOVD (R22), R24										
  execution.go:516	0x100210290		8b171197		ADD R23<<4, R12, R23									
  execution.go:516	0x100210294		f94002f7		MOVD (R23), R23										
  integer.go:26		0x100210298		eb1802ff		CMP R24, R23										
  integer.go:26		0x10021029c		9a9f27f6		CSET LO, R22										
  execution.go:516	0x1002102a0		140001cb		JMP 459(PC)										
  execution.go:518	0x1002102a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:518	0x1002102a8		eb1302df		CMP R19, R22										
  execution.go:518	0x1002102ac		5400ce82		BCS 1652(PC)										
  execution.go:518	0x1002102b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:518	0x1002102b4		eb1302ff		CMP R19, R23										
  execution.go:518	0x1002102b8		5400cdc2		BCS 1646(PC)										
  execution.go:518	0x1002102bc		f94002d8		MOVD (R22), R24										
  execution.go:518	0x1002102c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:518	0x1002102c4		f94002f7		MOVD (R23), R23										
  integer.go:27		0x1002102c8		eb1802ff		CMP R24, R23										
  integer.go:27		0x1002102cc		9a9fb7f6		CSET GE, R22										
  execution.go:518	0x1002102d0		140001bf		JMP 447(PC)										
  execution.go:520	0x1002102d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:520	0x1002102d8		eb1302df		CMP R19, R22										
  execution.go:520	0x1002102dc		5400cc42		BCS 1634(PC)										
  execution.go:520	0x1002102e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:520	0x1002102e4		eb1302ff		CMP R19, R23										
  execution.go:520	0x1002102e8		5400cb82		BCS 1628(PC)										
  execution.go:520	0x1002102ec		f94002d8		MOVD (R22), R24										
  execution.go:520	0x1002102f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:520	0x1002102f4		f94002f7		MOVD (R23), R23										
  integer.go:28		0x1002102f8		eb1802ff		CMP R24, R23										
  integer.go:28		0x1002102fc		9a9f37f6		CSET HS, R22										
  execution.go:520	0x100210300		140001b3		JMP 435(PC)										
  execution.go:522	0x100210304		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:522	0x100210308		eb1302df		CMP R19, R22										
  execution.go:522	0x10021030c		5400ca02		BCS 1616(PC)										
  execution.go:522	0x100210310		8b161196		ADD R22<<4, R12, R22									
  execution.go:522	0x100210314		eb1302ff		CMP R19, R23										
  execution.go:522	0x100210318		5400c942		BCS 1610(PC)										
  execution.go:522	0x10021031c		f94002d8		MOVD (R22), R24										
  execution.go:522	0x100210320		8b171197		ADD R23<<4, R12, R23									
  execution.go:522	0x100210324		f94002f7		MOVD (R23), R23										
  integer.go:29		0x100210328		eb1802ff		CMP R24, R23										
  integer.go:29		0x10021032c		9a9fc7f6		CSET LE, R22										
  execution.go:522	0x100210330		140001a7		JMP 423(PC)										
  execution.go:524	0x100210334		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:524	0x100210338		eb1302df		CMP R19, R22										
  execution.go:524	0x10021033c		5400c7c2		BCS 1598(PC)										
  execution.go:524	0x100210340		8b161196		ADD R22<<4, R12, R22									
  execution.go:524	0x100210344		eb1302ff		CMP R19, R23										
  execution.go:524	0x100210348		5400c702		BCS 1592(PC)										
  execution.go:524	0x10021034c		f94002d8		MOVD (R22), R24										
  execution.go:524	0x100210350		8b171197		ADD R23<<4, R12, R23									
  execution.go:524	0x100210354		f94002f7		MOVD (R23), R23										
  integer.go:30		0x100210358		eb1802ff		CMP R24, R23										
  integer.go:30		0x10021035c		9a9f87f6		CSET LS, R22										
  execution.go:524	0x100210360		1400019b		JMP 411(PC)										
  execution.go:526	0x100210364		b9400e96		MOVWU 12(R20), R22									
  execution.go:526	0x100210368		eb1302df		CMP R19, R22										
  execution.go:526	0x10021036c		5400c582		BCS 1580(PC)										
  execution.go:526	0x100210370		8b161197		ADD R22<<4, R12, R23									
  execution.go:526	0x100210374		f94002f7		MOVD (R23), R23										
  integer.go:31		0x100210378		d503201f		NOOP											
  bits.go:34		0x10021037c		5ac012f6		CLZW R23, R22										
  execution.go:526	0x100210380		14000193		JMP 403(PC)										
  execution.go:528	0x100210384		b9400e96		MOVWU 12(R20), R22									
  execution.go:528	0x100210388		eb1302df		CMP R19, R22										
  execution.go:528	0x10021038c		5400c422		BCS 1569(PC)										
  execution.go:528	0x100210390		8b161197		ADD R22<<4, R12, R23									
  execution.go:528	0x100210394		f94002f7		MOVD (R23), R23										
  integer.go:32		0x100210398		5ac002f7		RBITW R23, R23										
  integer.go:32		0x10021039c		5ac012f6		CLZW R23, R22										
  execution.go:528	0x1002103a0		1400018b		JMP 395(PC)										
  execution.go:538	0x1002103a4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:538	0x1002103a8		eb1302df		CMP R19, R22										
  execution.go:538	0x1002103ac		5400c2c2		BCS 1558(PC)										
  execution.go:538	0x1002103b0		8b161196		ADD R22<<4, R12, R22									
  execution.go:538	0x1002103b4		eb1302ff		CMP R19, R23										
  execution.go:538	0x1002103b8		5400c202		BCS 1552(PC)										
  execution.go:538	0x1002103bc		f94002d8		MOVD (R22), R24										
  execution.go:538	0x1002103c0		8b171197		ADD R23<<4, R12, R23									
  execution.go:538	0x1002103c4		f94002f7		MOVD (R23), R23										
  integer.go:34		0x1002103c8		8b170317		ADD R23, R24, R23									
  integer.go:34		0x1002103cc		2a1703f6		MOVW R23, R22										
  execution.go:538	0x1002103d0		1400017f		JMP 383(PC)										
  execution.go:540	0x1002103d4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:540	0x1002103d8		eb1302df		CMP R19, R22										
  execution.go:540	0x1002103dc		5400c082		BCS 1540(PC)										
  execution.go:540	0x1002103e0		8b161196		ADD R22<<4, R12, R22									
  execution.go:540	0x1002103e4		eb1302ff		CMP R19, R23										
  execution.go:540	0x1002103e8		5400bfc2		BCS 1534(PC)										
  execution.go:540	0x1002103ec		f94002d8		MOVD (R22), R24										
  execution.go:540	0x1002103f0		8b171197		ADD R23<<4, R12, R23									
  execution.go:540	0x1002103f4		f94002f7		MOVD (R23), R23										
  integer.go:35		0x1002103f8		cb170317		SUB R23, R24, R23									
  integer.go:35		0x1002103fc		2a1703f6		MOVW R23, R22										
  execution.go:540	0x100210400		14000173		JMP 371(PC)										
  execution.go:542	0x100210404		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:542	0x100210408		eb1302df		CMP R19, R22										
  execution.go:542	0x10021040c		5400be42		BCS 1522(PC)										
  execution.go:542	0x100210410		8b161196		ADD R22<<4, R12, R22									
  execution.go:542	0x100210414		eb1302ff		CMP R19, R23										
  execution.go:542	0x100210418		5400bd82		BCS 1516(PC)										
  execution.go:542	0x10021041c		f94002d8		MOVD (R22), R24										
  execution.go:542	0x100210420		8b171197		ADD R23<<4, R12, R23									
  execution.go:542	0x100210424		f94002f7		MOVD (R23), R23										
  integer.go:36		0x100210428		1b177f16		MULW R23, R24, R22									
  execution.go:542	0x10021042c		14000168		JMP 360(PC)										
  execution.go:544	0x100210430		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:544	0x100210434		eb1302df		CMP R19, R22										
  execution.go:544	0x100210438		5400bc22		BCS 1505(PC)										
  execution.go:544	0x10021043c		8b161196		ADD R22<<4, R12, R22									
  execution.go:544	0x100210440		eb1302ff		CMP R19, R23										
  execution.go:544	0x100210444		5400bb62		BCS 1499(PC)										
  execution.go:544	0x100210448		f94002d8		MOVD (R22), R24										
  execution.go:544	0x10021044c		8b171197		ADD R23<<4, R12, R23									
  execution.go:544	0x100210450		f94002f7		MOVD (R23), R23										
  integer.go:37		0x100210454		8a170317		AND R23, R24, R23									
  integer.go:37		0x100210458		2a1703f6		MOVW R23, R22										
  execution.go:544	0x10021045c		1400015c		JMP 348(PC)										
  execution.go:546	0x100210460		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:546	0x100210464		eb1302df		CMP R19, R22										
  execution.go:546	0x100210468		5400b9e2		BCS 1487(PC)										
  execution.go:546	0x10021046c		8b161196		ADD R22<<4, R12, R22									
  execution.go:546	0x100210470		eb1302ff		CMP R19, R23										
  execution.go:546	0x100210474		5400b922		BCS 1481(PC)										
  execution.go:546	0x100210478		f94002d8		MOVD (R22), R24										
  execution.go:546	0x10021047c		8b171197		ADD R23<<4, R12, R23									
  execution.go:546	0x100210480		f94002f7		MOVD (R23), R23										
  integer.go:38		0x100210484		aa170317		ORR R23, R24, R23									
  integer.go:38		0x100210488		2a1703f6		MOVW R23, R22										
  execution.go:546	0x10021048c		14000150		JMP 336(PC)										
  execution.go:548	0x100210490		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:548	0x100210494		eb1302df		CMP R19, R22										
  execution.go:548	0x100210498		5400b7a2		BCS 1469(PC)										
  execution.go:548	0x10021049c		8b161196		ADD R22<<4, R12, R22									
  execution.go:548	0x1002104a0		eb1302ff		CMP R19, R23										
  execution.go:548	0x1002104a4		5400b6e2		BCS 1463(PC)										
  execution.go:548	0x1002104a8		f94002d8		MOVD (R22), R24										
  execution.go:548	0x1002104ac		8b171197		ADD R23<<4, R12, R23									
  execution.go:548	0x1002104b0		f94002f7		MOVD (R23), R23										
  integer.go:39		0x1002104b4		ca170317		EOR R23, R24, R23									
  integer.go:39		0x1002104b8		2a1703f6		MOVW R23, R22										
  execution.go:548	0x1002104bc		14000144		JMP 324(PC)										
  execution.go:550	0x1002104c0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:550	0x1002104c4		eb1302df		CMP R19, R22										
  execution.go:550	0x1002104c8		5400b562		BCS 1451(PC)										
  execution.go:550	0x1002104cc		8b161196		ADD R22<<4, R12, R22									
  execution.go:550	0x1002104d0		eb1302ff		CMP R19, R23										
  execution.go:550	0x1002104d4		5400b4a2		BCS 1445(PC)										
  execution.go:550	0x1002104d8		f94002d8		MOVD (R22), R24										
  execution.go:550	0x1002104dc		8b171197		ADD R23<<4, R12, R23									
  execution.go:550	0x1002104e0		f94002f7		MOVD (R23), R23										
  integer.go:40		0x1002104e4		924012f7		AND $31, R23, R23									
  integer.go:40		0x1002104e8		9ad72317		LSL R23, R24, R23									
  integer.go:40		0x1002104ec		2a1703f6		MOVW R23, R22										
  execution.go:550	0x1002104f0		14000137		JMP 311(PC)										
  execution.go:552	0x1002104f4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:552	0x1002104f8		eb1302df		CMP R19, R22										
  execution.go:552	0x1002104fc		5400b302		BCS 1432(PC)										
  execution.go:552	0x100210500		8b161196		ADD R22<<4, R12, R22									
  execution.go:552	0x100210504		eb1302ff		CMP R19, R23										
  execution.go:552	0x100210508		5400b242		BCS 1426(PC)										
  execution.go:552	0x10021050c		f94002d8		MOVD (R22), R24										
  execution.go:552	0x100210510		8b171197		ADD R23<<4, R12, R23									
  execution.go:552	0x100210514		f94002f7		MOVD (R23), R23										
  integer.go:41		0x100210518		93407f18		SXTW R24, R24										
  integer.go:41		0x10021051c		924012f7		AND $31, R23, R23									
  integer.go:41		0x100210520		9ad72b17		ASR R23, R24, R23									
  integer.go:41		0x100210524		2a1703f6		MOVW R23, R22										
  execution.go:552	0x100210528		14000129		JMP 297(PC)										
  execution.go:554	0x10021052c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:554	0x100210530		eb1302df		CMP R19, R22										
  execution.go:554	0x100210534		5400b082		BCS 1412(PC)										
  execution.go:554	0x100210538		8b161196		ADD R22<<4, R12, R22									
  execution.go:554	0x10021053c		eb1302ff		CMP R19, R23										
  execution.go:554	0x100210540		5400afc2		BCS 1406(PC)										
  execution.go:554	0x100210544		f94002d8		MOVD (R22), R24										
  execution.go:554	0x100210548		8b171197		ADD R23<<4, R12, R23									
  execution.go:554	0x10021054c		f94002f7		MOVD (R23), R23										
  integer.go:42		0x100210550		2a1803f8		MOVW R24, R24										
  integer.go:42		0x100210554		924012f7		AND $31, R23, R23									
  integer.go:42		0x100210558		9ad72717		LSR R23, R24, R23									
  integer.go:42		0x10021055c		2a1703f6		MOVW R23, R22										
  execution.go:554	0x100210560		1400011b		JMP 283(PC)										
  execution.go:556	0x100210564		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:556	0x100210568		eb1302df		CMP R19, R22										
  execution.go:556	0x10021056c		5400ae02		BCS 1392(PC)										
  execution.go:556	0x100210570		8b161196		ADD R22<<4, R12, R22									
  execution.go:556	0x100210574		eb1302ff		CMP R19, R23										
  execution.go:556	0x100210578		5400ad42		BCS 1386(PC)										
  execution.go:556	0x10021057c		f94002d8		MOVD (R22), R24										
  execution.go:556	0x100210580		8b171197		ADD R23<<4, R12, R23									
  execution.go:556	0x100210584		f94002f7		MOVD (R23), R23										
  integer.go:43		0x100210588		cb1703f7		NEG R23, R23										
  integer.go:43		0x10021058c		1ad72f16		RORW R23, R24, R22									
  execution.go:556	0x100210590		1400010f		JMP 271(PC)										
  execution.go:558	0x100210594		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:558	0x100210598		eb1302df		CMP R19, R22										
  execution.go:558	0x10021059c		5400abc2		BCS 1374(PC)										
  execution.go:558	0x1002105a0		8b161196		ADD R22<<4, R12, R22									
  execution.go:558	0x1002105a4		eb1302ff		CMP R19, R23										
  execution.go:558	0x1002105a8		5400ab02		BCS 1368(PC)										
  execution.go:558	0x1002105ac		f94002d8		MOVD (R22), R24										
  execution.go:558	0x1002105b0		8b171197		ADD R23<<4, R12, R23									
  execution.go:558	0x1002105b4		f94002f7		MOVD (R23), R23										
  integer.go:44		0x1002105b8		1ad72f16		RORW R23, R24, R22									
  execution.go:558	0x1002105bc		14000104		JMP 260(PC)										
  execution.go:560	0x1002105c0		b9400e96		MOVWU 12(R20), R22									
  execution.go:560	0x1002105c4		eb1302df		CMP R19, R22										
  execution.go:560	0x1002105c8		5400a9a2		BCS 1357(PC)										
  execution.go:560	0x1002105cc		8b161197		ADD R22<<4, R12, R23									
  execution.go:560	0x1002105d0		f94002f7		MOVD (R23), R23										
  integer.go:45		0x1002105d4		d503201f		NOOP											
  bits.go:37		0x1002105d8		dac012f6		CLZ R23, R22										
  execution.go:560	0x1002105dc		140000fc		JMP 252(PC)										
  execution.go:562	0x1002105e0		b9400e96		MOVWU 12(R20), R22									
  execution.go:562	0x1002105e4		eb1302df		CMP R19, R22										
  execution.go:562	0x1002105e8		5400a842		BCS 1346(PC)										
  execution.go:562	0x1002105ec		8b161197		ADD R22<<4, R12, R23									
  execution.go:562	0x1002105f0		f94002f7		MOVD (R23), R23										
  integer.go:46		0x1002105f4		dac002f7		RBIT R23, R23										
  integer.go:46		0x1002105f8		dac012f6		CLZ R23, R22										
  execution.go:562	0x1002105fc		140000f4		JMP 244(PC)										
  execution.go:532	0x100210600		b9400e96		MOVWU 12(R20), R22									
  execution.go:532	0x100210604		eb1302df		CMP R19, R22										
  execution.go:532	0x100210608		5400a6e2		BCS 1335(PC)										
  execution.go:532	0x10021060c		8b161197		ADD R22<<4, R12, R23									
  execution.go:532	0x100210610		f94002f7		MOVD (R23), R23										
  execution.go:534	0x100210614		2a1703f8		MOVW R23, R24										
  execution.go:536	0x100210618		d503201f		NOOP											
  execution.go:533	0x10021061c		7101a43f		CMPW $105, R1										
  execution.go:534	0x100210620		9a970317		CSEL EQ, R24, R23, R23									
  integer.go:47		0x100210624		9e6702e0		FMOVD R23, F0										
  integer.go:47		0x100210628		0e205800		VCNT V0.B8, V0.B8									
  integer.go:47		0x10021062c		2e303800		VUADDLV V0.B8, V0									
  integer.go:47		0x100210630		9e660016		FMOVD F0, R22										
  execution.go:533	0x100210634		140000e6		JMP 230(PC)										
  execution.go:564	0x100210638		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:564	0x10021063c		eb1302df		CMP R19, R22										
  execution.go:564	0x100210640		5400a4c2		BCS 1318(PC)										
  execution.go:564	0x100210644		8b161196		ADD R22<<4, R12, R22									
  execution.go:564	0x100210648		eb1302ff		CMP R19, R23										
  execution.go:564	0x10021064c		5400a402		BCS 1312(PC)										
  execution.go:564	0x100210650		f94002d8		MOVD (R22), R24										
  execution.go:564	0x100210654		8b171197		ADD R23<<4, R12, R23									
  execution.go:564	0x100210658		f94002f7		MOVD (R23), R23										
  integer.go:48		0x10021065c		8b170316		ADD R23, R24, R22									
  execution.go:564	0x100210660		140000db		JMP 219(PC)										
  execution.go:566	0x100210664		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:566	0x100210668		eb1302df		CMP R19, R22										
  execution.go:566	0x10021066c		5400a2a2		BCS 1301(PC)										
  execution.go:566	0x100210670		8b161196		ADD R22<<4, R12, R22									
  execution.go:566	0x100210674		eb1302ff		CMP R19, R23										
  execution.go:566	0x100210678		5400a1e2		BCS 1295(PC)										
  execution.go:566	0x10021067c		f94002d8		MOVD (R22), R24										
  execution.go:566	0x100210680		8b171197		ADD R23<<4, R12, R23									
  execution.go:566	0x100210684		f94002f7		MOVD (R23), R23										
  integer.go:49		0x100210688		cb170316		SUB R23, R24, R22									
  execution.go:566	0x10021068c		140000d0		JMP 208(PC)										
  execution.go:568	0x100210690		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:568	0x100210694		eb1302df		CMP R19, R22										
  execution.go:568	0x100210698		5400a082		BCS 1284(PC)										
  execution.go:568	0x10021069c		8b161196		ADD R22<<4, R12, R22									
  execution.go:568	0x1002106a0		eb1302ff		CMP R19, R23										
  execution.go:568	0x1002106a4		54009fc2		BCS 1278(PC)										
  execution.go:568	0x1002106a8		f94002d8		MOVD (R22), R24										
  execution.go:568	0x1002106ac		8b171197		ADD R23<<4, R12, R23									
  execution.go:568	0x1002106b0		f94002f7		MOVD (R23), R23										
  integer.go:50		0x1002106b4		9b187ef6		MUL R24, R23, R22									
  execution.go:568	0x1002106b8		140000c5		JMP 197(PC)										
  execution.go:570	0x1002106bc		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:570	0x1002106c0		eb1302df		CMP R19, R22										
  execution.go:570	0x1002106c4		54009e62		BCS 1267(PC)										
  execution.go:570	0x1002106c8		8b161196		ADD R22<<4, R12, R22									
  execution.go:570	0x1002106cc		eb1302ff		CMP R19, R23										
  execution.go:570	0x1002106d0		54009da2		BCS 1261(PC)										
  execution.go:570	0x1002106d4		f94002d8		MOVD (R22), R24										
  execution.go:570	0x1002106d8		8b171197		ADD R23<<4, R12, R23									
  execution.go:570	0x1002106dc		f94002f7		MOVD (R23), R23										
  integer.go:51		0x1002106e0		8a170316		AND R23, R24, R22									
  execution.go:570	0x1002106e4		140000ba		JMP 186(PC)										
  execution.go:572	0x1002106e8		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:572	0x1002106ec		eb1302df		CMP R19, R22										
  execution.go:572	0x1002106f0		54009c42		BCS 1250(PC)										
  execution.go:572	0x1002106f4		8b161196		ADD R22<<4, R12, R22									
  execution.go:572	0x1002106f8		eb1302ff		CMP R19, R23										
  execution.go:572	0x1002106fc		54009b82		BCS 1244(PC)										
  execution.go:572	0x100210700		f94002d8		MOVD (R22), R24										
  execution.go:572	0x100210704		8b171197		ADD R23<<4, R12, R23									
  execution.go:572	0x100210708		f94002f7		MOVD (R23), R23										
  integer.go:52		0x10021070c		aa170316		ORR R23, R24, R22									
  execution.go:572	0x100210710		140000af		JMP 175(PC)										
  execution.go:574	0x100210714		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:574	0x100210718		eb1302df		CMP R19, R22										
  execution.go:574	0x10021071c		54009a22		BCS 1233(PC)										
  execution.go:574	0x100210720		8b161196		ADD R22<<4, R12, R22									
  execution.go:574	0x100210724		eb1302ff		CMP R19, R23										
  execution.go:574	0x100210728		54009962		BCS 1227(PC)										
  execution.go:574	0x10021072c		f94002d8		MOVD (R22), R24										
  execution.go:574	0x100210730		8b171197		ADD R23<<4, R12, R23									
  execution.go:574	0x100210734		f94002f7		MOVD (R23), R23										
  integer.go:53		0x100210738		ca170316		EOR R23, R24, R22									
  execution.go:574	0x10021073c		140000a4		JMP 164(PC)										
  execution.go:576	0x100210740		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:576	0x100210744		eb1302df		CMP R19, R22										
  execution.go:576	0x100210748		54009802		BCS 1216(PC)										
  execution.go:576	0x10021074c		8b161196		ADD R22<<4, R12, R22									
  execution.go:576	0x100210750		eb1302ff		CMP R19, R23										
  execution.go:576	0x100210754		54009742		BCS 1210(PC)										
  execution.go:576	0x100210758		f94002d8		MOVD (R22), R24										
  execution.go:576	0x10021075c		8b171197		ADD R23<<4, R12, R23									
  execution.go:576	0x100210760		f94002f7		MOVD (R23), R23										
  integer.go:54		0x100210764		9ad72316		LSL R23, R24, R22									
  execution.go:576	0x100210768		14000099		JMP 153(PC)										
  execution.go:578	0x10021076c		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:578	0x100210770		eb1302df		CMP R19, R22										
  execution.go:578	0x100210774		540095e2		BCS 1199(PC)										
  execution.go:578	0x100210778		8b161196		ADD R22<<4, R12, R22									
  execution.go:578	0x10021077c		eb1302ff		CMP R19, R23										
  execution.go:578	0x100210780		54009522		BCS 1193(PC)										
  execution.go:578	0x100210784		f94002d8		MOVD (R22), R24										
  execution.go:578	0x100210788		8b171197		ADD R23<<4, R12, R23									
  execution.go:578	0x10021078c		f94002f7		MOVD (R23), R23										
  integer.go:55		0x100210790		9ad72b16		ASR R23, R24, R22									
  execution.go:578	0x100210794		1400008e		JMP 142(PC)										
  execution.go:580	0x100210798		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:580	0x10021079c		eb1302df		CMP R19, R22										
  execution.go:580	0x1002107a0		540093c2		BCS 1182(PC)										
  execution.go:580	0x1002107a4		8b161196		ADD R22<<4, R12, R22									
  execution.go:580	0x1002107a8		eb1302ff		CMP R19, R23										
  execution.go:580	0x1002107ac		54009302		BCS 1176(PC)										
  execution.go:580	0x1002107b0		f94002d8		MOVD (R22), R24										
  execution.go:580	0x1002107b4		8b171197		ADD R23<<4, R12, R23									
  execution.go:580	0x1002107b8		f94002f7		MOVD (R23), R23										
  integer.go:56		0x1002107bc		9ad72716		LSR R23, R24, R22									
  execution.go:580	0x1002107c0		14000083		JMP 131(PC)										
  execution.go:582	0x1002107c4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:582	0x1002107c8		eb1302df		CMP R19, R22										
  execution.go:582	0x1002107cc		540091a2		BCS 1165(PC)										
  execution.go:582	0x1002107d0		8b161196		ADD R22<<4, R12, R22									
  execution.go:582	0x1002107d4		eb1302ff		CMP R19, R23										
  execution.go:582	0x1002107d8		540090e2		BCS 1159(PC)										
  execution.go:582	0x1002107dc		f94002d8		MOVD (R22), R24										
  execution.go:582	0x1002107e0		8b171197		ADD R23<<4, R12, R23									
  execution.go:582	0x1002107e4		f94002f7		MOVD (R23), R23										
  integer.go:57		0x1002107e8		cb1703f7		NEG R23, R23										
  integer.go:57		0x1002107ec		9ad72f16		ROR R23, R24, R22									
  execution.go:582	0x1002107f0		14000077		JMP 119(PC)										
  execution.go:584	0x1002107f4		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:584	0x1002107f8		eb1302df		CMP R19, R22										
  execution.go:584	0x1002107fc		54008f62		BCS 1147(PC)										
  execution.go:584	0x100210800		8b161196		ADD R22<<4, R12, R22									
  execution.go:584	0x100210804		eb1302ff		CMP R19, R23										
  execution.go:584	0x100210808		54008ea2		BCS 1141(PC)										
  execution.go:584	0x10021080c		f94002d8		MOVD (R22), R24										
  execution.go:584	0x100210810		8b171197		ADD R23<<4, R12, R23									
  execution.go:584	0x100210814		f94002f7		MOVD (R23), R23										
  integer.go:58		0x100210818		9ad72f16		ROR R23, R24, R22									
  execution.go:584	0x10021081c		1400006c		JMP 108(PC)										
  execution.go:586	0x100210820		b9400e96		MOVWU 12(R20), R22									
  execution.go:586	0x100210824		eb1302df		CMP R19, R22										
  execution.go:586	0x100210828		54008d42		BCS 1130(PC)										
  execution.go:586	0x10021082c		8b161197		ADD R22<<4, R12, R23									
  execution.go:586	0x100210830		f94002f7		MOVD (R23), R23										
  integer.go:59		0x100210834		2a1703f6		MOVW R23, R22										
  execution.go:586	0x100210838		14000065		JMP 101(PC)										
  execution.go:588	0x10021083c		b9400e96		MOVWU 12(R20), R22									
  execution.go:588	0x100210840		eb1302df		CMP R19, R22										
  execution.go:588	0x100210844		54008c02		BCS 1120(PC)										
  execution.go:588	0x100210848		8b161197		ADD R22<<4, R12, R23									
  execution.go:588	0x10021084c		f94002f7		MOVD (R23), R23										
  integer.go:60		0x100210850		93407ef6		SXTW R23, R22										
  execution.go:588	0x100210854		1400005e		JMP 94(PC)										
  execution.go:590	0x100210858		b9400e96		MOVWU 12(R20), R22									
  execution.go:590	0x10021085c		eb1302df		CMP R19, R22										
  execution.go:590	0x100210860		54008ac2		BCS 1110(PC)										
  execution.go:590	0x100210864		8b161197		ADD R22<<4, R12, R23									
  execution.go:590	0x100210868		f94002f7		MOVD (R23), R23										
  integer.go:61		0x10021086c		2a1703f6		MOVW R23, R22										
  execution.go:590	0x100210870		14000057		JMP 87(PC)										
  execution.go:611	0x100210874		b9401283		MOVWU 16(R20), R3									
  execution.go:611	0x100210878		3100047f		CMNW $1, R3										
  execution.go:611	0x10021087c		540000c0		BEQ 6(PC)										
  execution.go:612	0x100210880		eb13007f		CMP R19, R3										
  execution.go:612	0x100210884		54008962		BCS 1099(PC)										
  execution.go:612	0x100210888		8b031183		ADD R3<<4, R12, R3									
  execution.go:612	0x10021088c		f9400062		MOVD (R3), R2										
  execution.go:612	0x100210890		14000002		JMP 2(PC)										
  execution.go:612	0x100210894		aa1f03e2		MOVD ZR, R2										
  execution.go:614	0x100210898		b9400e83		MOVWU 12(R20), R3									
  execution.go:614	0x10021089c		eb13007f		CMP R19, R3										
  execution.go:614	0x1002108a0		54008842		BCS 1090(PC)										
  execution.go:614	0x1002108a4		8b031183		ADD R3<<4, R12, R3									
  execution.go:614	0x1002108a8		f9400063		MOVD (R3), R3										
  execution.go:614	0x1002108ac		aa0103e0		MOVD R1, R0										
  execution.go:614	0x1002108b0		aa0303e1		MOVD R3, R1										
  execution.go:614	0x1002108b4		97ffa8c3		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:615	0x1002108b8		d3401c23		UBFX $0, R1, $8, R3									
  execution.go:615	0x1002108bc		34000223		CBZW R3, 17(PC)										
  execution.go:342	0x1002108c0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002108c4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002108c8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x1002108cc		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002108d0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x1002108d4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002108d8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002108dc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x1002108e0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x1002108e4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x1002108e8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x1002108ec		f94093f5		MOVD 288(RSP), R21									
  execution.go:395	0x1002108f0		aa1f03f7		MOVD ZR, R23										
  execution.go:395	0x1002108f4		aa0003f6		MOVD R0, R22										
  execution.go:209	0x1002108f8		f94127e0		MOVD 584(RSP), R0									
  execution.go:616	0x1002108fc		140002da		JMP 730(PC)										
  execution.go:342	0x100210900		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210904		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210908		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x10021090c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210910		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210914		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210918		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x10021091c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210920		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210924		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210928		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x10021092c		f94093f5		MOVD 288(RSP), R21									
  execution.go:488	0x100210930		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100210934		f94127e0		MOVD 584(RSP), R0									
  execution.go:615	0x100210938		14000025		JMP 37(PC)										
  execution.go:592	0x10021093c		b9400e96		MOVWU 12(R20), R22									
  execution.go:592	0x100210940		eb1302df		CMP R19, R22										
  execution.go:592	0x100210944		540082c2		BCS 1046(PC)										
  execution.go:592	0x100210948		8b161196		ADD R22<<4, R12, R22									
  execution.go:592	0x10021094c		f94002d6		MOVD (R22), R22										
  integer.go:62		0x100210950		93401ed6		SXTB R22, R22										
  integer.go:62		0x100210954		2a1603f6		MOVW R22, R22										
  execution.go:592	0x100210958		1400001d		JMP 29(PC)										
  execution.go:594	0x10021095c		b9400e96		MOVWU 12(R20), R22									
  execution.go:594	0x100210960		eb1302df		CMP R19, R22										
  execution.go:594	0x100210964		54008162		BCS 1035(PC)										
  execution.go:594	0x100210968		8b161196		ADD R22<<4, R12, R22									
  execution.go:594	0x10021096c		f94002d6		MOVD (R22), R22										
  integer.go:63		0x100210970		93403ed6		SXTH R22, R22										
  integer.go:63		0x100210974		2a1603f6		MOVW R22, R22										
  execution.go:594	0x100210978		14000015		JMP 21(PC)										
  execution.go:596	0x10021097c		b9400e96		MOVWU 12(R20), R22									
  execution.go:596	0x100210980		eb1302df		CMP R19, R22										
  execution.go:596	0x100210984		54008002		BCS 1024(PC)										
  execution.go:596	0x100210988		8b161196		ADD R22<<4, R12, R22									
  execution.go:596	0x10021098c		f94002d6		MOVD (R22), R22										
  integer.go:64		0x100210990		93401ed6		SXTB R22, R22										
  execution.go:596	0x100210994		1400000e		JMP 14(PC)										
  execution.go:598	0x100210998		b9400e96		MOVWU 12(R20), R22									
  execution.go:598	0x10021099c		eb1302df		CMP R19, R22										
  execution.go:598	0x1002109a0		54007ec2		BCS 1014(PC)										
  execution.go:598	0x1002109a4		8b161196		ADD R22<<4, R12, R22									
  execution.go:598	0x1002109a8		f94002d6		MOVD (R22), R22										
  integer.go:65		0x1002109ac		93403ed6		SXTH R22, R22										
  execution.go:598	0x1002109b0		14000007		JMP 7(PC)										
  execution.go:600	0x1002109b4		b9400e96		MOVWU 12(R20), R22									
  execution.go:600	0x1002109b8		eb1302df		CMP R19, R22										
  execution.go:600	0x1002109bc		54007d82		BCS 1004(PC)										
  execution.go:600	0x1002109c0		8b161196		ADD R22<<4, R12, R22									
  execution.go:600	0x1002109c4		f94002d6		MOVD (R22), R22										
  integer.go:66		0x1002109c8		93407ed6		SXTW R22, R22										
  execution.go:619	0x1002109cc		aa1f03f7		MOVD ZR, R23										
  execution.go:619	0x1002109d0		140002a7		JMP 679(PC)										
  execution.go:621	0x1002109d4		7100f83f		CMPW $62, R1										
  execution.go:706	0x1002109d8		54001e68		BHI 243(PC)										
  execution.go:621	0x1002109dc		7100803f		CMPW $32, R1										
  execution.go:676	0x1002109e0		540005c8		BHI 46(PC)										
  execution.go:621	0x1002109e4		7100283f		CMPW $10, R1										
  execution.go:663	0x1002109e8		54000108		BHI 8(PC)										
  execution.go:669	0x1002109ec		7100043f		CMPW $1, R1										
  execution.go:669	0x1002109f0		540001a0		BEQ 13(PC)										
  execution.go:663	0x1002109f4		7100203f		CMPW $8, R1										
  execution.go:663	0x1002109f8		54005560		BEQ 683(PC)										
  execution.go:621	0x1002109fc		7100283f		CMPW $10, R1										
  execution.go:663	0x100210a00		540042e1		BNE 535(PC)										
  execution.go:663	0x100210a04		140002a8		JMP 680(PC)										
  execution.go:621	0x100210a08		7100683f		CMPW $26, R1										
  execution.go:669	0x100210a0c		54000148		BHI 10(PC)										
  execution.go:743	0x100210a10		d1004036		SUB $16, R1, R22									
  execution.go:743	0x100210a14		710016df		CMPW $5, R22										
  execution.go:743	0x100210a18		54005509		BLS 680(PC)										
  execution.go:621	0x100210a1c		7100683f		CMPW $26, R1										
  execution.go:669	0x100210a20		540041e1		BNE 527(PC)										
  execution.go:704	0x100210a24		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210a28		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100210a2c		aa1f03e1		MOVD ZR, R1										
  execution.go:669	0x100210a30		1400028d		JMP 653(PC)										
  execution.go:670	0x100210a34		7100703f		CMPW $28, R1										
  execution.go:670	0x100210a38		540001e8		BHI 15(PC)										
  execution.go:671	0x100210a3c		29425e96		LDPW 16(R20), (R22, R23)								
  execution.go:672	0x100210a40		eb1302ff		CMP R19, R23										
  execution.go:672	0x100210a44		540078e2		BCS 967(PC)										
  execution.go:672	0x100210a48		8b171197		ADD R23<<4, R12, R23									
  execution.go:672	0x100210a4c		f94002f7		MOVD (R23), R23										
  execution.go:672	0x100210a50		34000057		CBZW R23, 2(PC)										
  execution.go:673	0x100210a54		b9400e96		MOVWU 12(R20), R22									
  execution.go:675	0x100210a58		2a1603f6		MOVW R22, R22										
  execution.go:675	0x100210a5c		eb1302df		CMP R19, R22										
  execution.go:675	0x100210a60		540077a2		BCS 957(PC)										
  execution.go:675	0x100210a64		8b161196		ADD R22<<4, R12, R22									
  execution.go:675	0x100210a68		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x100210a6c		aa1f03e1		MOVD ZR, R1										
  execution.go:675	0x100210a70		1400027d		JMP 637(PC)										
  execution.go:621	0x100210a74		7100803f		CMPW $32, R1										
  execution.go:676	0x100210a78		54003f21		BNE 505(PC)										
  execution.go:677	0x100210a7c		b9401a96		MOVWU 24(R20), R22									
  execution.go:677	0x100210a80		eb1302df		CMP R19, R22										
  execution.go:677	0x100210a84		54007622		BCS 945(PC)										
  execution.go:677	0x100210a88		8b161196		ADD R22<<4, R12, R22									
  execution.go:677	0x100210a8c		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:708	0x100210a90		aa1f03e1		MOVD ZR, R1										
  execution.go:677	0x100210a94		14000274		JMP 628(PC)										
  execution.go:621	0x100210a98		7100903f		CMPW $36, R1										
  execution.go:683	0x100210a9c		54000548		BHI 42(PC)										
  execution.go:678	0x100210aa0		7100883f		CMPW $34, R1										
  execution.go:678	0x100210aa4		540001a8		BHI 13(PC)										
  execution.go:679	0x100210aa8		b9400e96		MOVWU 12(R20), R22									
  execution.go:679	0x100210aac		eb1302df		CMP R19, R22										
  execution.go:679	0x100210ab0		54007462		BCS 931(PC)										
  execution.go:679	0x100210ab4		8b161196		ADD R22<<4, R12, R22									
  execution.go:679	0x100210ab8		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:680	0x100210abc		b9401a98		MOVWU 24(R20), R24									
  execution.go:680	0x100210ac0		eb13031f		CMP R19, R24										
  execution.go:680	0x100210ac4		54007362		BCS 923(PC)										
  execution.go:680	0x100210ac8		8b181198		ADD R24<<4, R12, R24									
  execution.go:680	0x100210acc		a9005f16		STP (R22, R23), (R24)									
  execution.go:708	0x100210ad0		aa1f03e1		MOVD ZR, R1										
  execution.go:680	0x100210ad4		14000264		JMP 612(PC)										
  execution.go:681	0x100210ad8		71008c3f		CMPW $35, R1										
  execution.go:681	0x100210adc		54000121		BNE 9(PC)										
  execution.go:682	0x100210ae0		a948ddb6		LDP 136(R13), (R22, R23)								
  execution.go:682	0x100210ae4		b9401a98		MOVWU 24(R20), R24									
  execution.go:682	0x100210ae8		eb17031f		CMP R23, R24										
  execution.go:682	0x100210aec		540071c2		BCS 910(PC)										
  execution.go:682	0x100210af0		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:682	0x100210af4		a9425ed6		LDP 32(R22), (R22, R23)									
  execution.go:708	0x100210af8		aa1f03e1		MOVD ZR, R1										
  execution.go:682	0x100210afc		1400025a		JMP 602(PC)										
  execution.go:621	0x100210b00		7100903f		CMPW $36, R1										
  execution.go:683	0x100210b04		54003ac1		BNE 470(PC)										
  execution.go:684	0x100210b08		b9400e96		MOVWU 12(R20), R22									
  execution.go:684	0x100210b0c		eb1302df		CMP R19, R22										
  execution.go:684	0x100210b10		54007042		BCS 898(PC)										
  execution.go:684	0x100210b14		a948e1b7		LDP 136(R13), (R23, R24)								
  execution.go:684	0x100210b18		b9401a99		MOVWU 24(R20), R25									
  execution.go:684	0x100210b1c		8b161196		ADD R22<<4, R12, R22									
  execution.go:684	0x100210b20		a9406ad6		LDP (R22), (R22, R26)									
  execution.go:684	0x100210b24		eb18033f		CMP R24, R25										
  execution.go:684	0x100210b28		54006f22		BCS 889(PC)										
  execution.go:684	0x100210b2c		f8797af7		MOVD (R23)(R25<<3), R23									
  execution.go:684	0x100210b30		a9026af6		STP (R22, R26), 32(R23)									
  execution.go:704	0x100210b34		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210b38		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100210b3c		aa1f03e1		MOVD ZR, R1										
  execution.go:684	0x100210b40		14000249		JMP 585(PC)										
  execution.go:621	0x100210b44		7100983f		CMPW $38, R1										
  execution.go:693	0x100210b48		54000708		BHI 56(PC)										
  execution.go:685	0x100210b4c		7100943f		CMPW $37, R1										
  execution.go:685	0x100210b50		54000321		BNE 25(PC)										
  execution.go:686	0x100210b54		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:686	0x100210b58		b9401a98		MOVWU 24(R20), R24									
  execution.go:686	0x100210b5c		eb17031f		CMP R23, R24										
  execution.go:686	0x100210b60		54006d02		BCS 872(PC)										
  execution.go:686	0x100210b64		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:687	0x100210b68		398002db		MOVB (R22), R27										
  execution.go:687	0x100210b6c		b9400e97		MOVWU 12(R20), R23									
  execution.go:687	0x100210b70		eb1302ff		CMP R19, R23										
  execution.go:687	0x100210b74		54006c02		BCS 864(PC)										
  execution.go:687	0x100210b78		8b171197		ADD R23<<4, R12, R23									
  execution.go:687	0x100210b7c		f94002f7		MOVD (R23), R23										
  module.go:70		0x100210b80		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x100210b84		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x100210b88		2a1703f7		MOVW R23, R23										
  execution.go:688	0x100210b8c		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:688	0x100210b90		eb1802ff		CMP R24, R23										
  execution.go:688	0x100210b94		54000083		BCC 4(PC)										
  execution.go:688	0x100210b98		b24007e1		ORR $3, ZR, R1										
  execution.go:691	0x100210b9c		aa1f03f6		MOVD ZR, R22										
  execution.go:688	0x100210ba0		14000003		JMP 3(PC)										
  execution.go:691	0x100210ba4		f8777ad6		MOVD (R22)(R23<<3), R22									
  execution.go:689	0x100210ba8		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x100210bac		aa1f03f7		MOVD ZR, R23										
  execution.go:688	0x100210bb0		1400022d		JMP 557(PC)										
  execution.go:694	0x100210bb4		a945ddb6		LDP 88(R13), (R22, R23)									
  execution.go:694	0x100210bb8		b9401a98		MOVWU 24(R20), R24									
  execution.go:694	0x100210bbc		eb17031f		CMP R23, R24										
  execution.go:694	0x100210bc0		54006942		BCS 842(PC)										
  execution.go:694	0x100210bc4		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:695	0x100210bc8		398002db		MOVB (R22), R27										
  execution.go:695	0x100210bcc		b9400e97		MOVWU 12(R20), R23									
  execution.go:695	0x100210bd0		eb1302ff		CMP R19, R23										
  execution.go:695	0x100210bd4		54006842		BCS 834(PC)										
  execution.go:695	0x100210bd8		8b171197		ADD R23<<4, R12, R23									
  execution.go:695	0x100210bdc		f94002f7		MOVD (R23), R23										
  module.go:70		0x100210be0		3940a6d8		MOVBU 41(R22), R24									
  module.go:70		0x100210be4		37000058		TBNZ $0, R24, 2(PC)									
  module.go:73		0x100210be8		2a1703f7		MOVW R23, R23										
  execution.go:696	0x100210bec		a943e2d6		LDP 56(R22), (R22, R24)									
  execution.go:696	0x100210bf0		eb1802ff		CMP R24, R23										
  execution.go:696	0x100210bf4		54000063		BCC 3(PC)										
  execution.go:696	0x100210bf8		b24007e1		ORR $3, ZR, R1										
  execution.go:696	0x100210bfc		14000008		JMP 8(PC)										
  execution.go:699	0x100210c00		b9401298		MOVWU 16(R20), R24									
  execution.go:699	0x100210c04		eb13031f		CMP R19, R24										
  execution.go:699	0x100210c08		54006642		BCS 818(PC)										
  execution.go:699	0x100210c0c		8b181198		ADD R24<<4, R12, R24									
  execution.go:699	0x100210c10		f9400318		MOVD (R24), R24										
  execution.go:699	0x100210c14		f8377ad8		MOVD R24, (R22)(R23<<3)									
  execution.go:697	0x100210c18		aa1f03e1		MOVD ZR, R1										
  execution.go:704	0x100210c1c		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210c20		aa1f03f6		MOVD ZR, R22										
  execution.go:696	0x100210c24		14000210		JMP 528(PC)										
  execution.go:701	0x100210c28		d100a036		SUB $40, R1, R22									
  execution.go:701	0x100210c2c		710036df		CMPW $13, R22										
  execution.go:702	0x100210c30		54000588		BHI 44(PC)										
  execution.go:703	0x100210c34		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:703	0x100210c38		b9400696		MOVWU 4(R20), R22									
  execution.go:703	0x100210c3c		aa1603f7		MOVD R22, R23										
  execution.go:703	0x100210c40		eb0802ff		CMP R8, R23										
  execution.go:703	0x100210c44		54006422		BCS 801(PC)										
  execution.go:703	0x100210c48		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:703	0x100210c4c		cb171508		SUB R23<<5, R8, R8									
  execution.go:703	0x100210c50		8b0800e7		ADD R8, R7, R7										
  execution.go:704	0x100210c54		a94759a8		LDP 112(R13), (R8, R22)									
  module.go:178		0x100210c58		2942e0f7		LDPW 20(R7), (R23, R24)									
  module.go:178		0x100210c5c		b9401ce7		MOVWU 28(R7), R7									
  module.go:178		0x100210c60		aa0782e3		ORR R7<<32, R23, R3									
  execution.go:704	0x100210c64		eb16031f		CMP R22, R24										
  execution.go:704	0x100210c68		540062a2		BCS 789(PC)										
  execution.go:704	0x100210c6c		f8787907		MOVD (R8)(R24<<3), R7									
  execution.go:704	0x100210c70		398000fb		MOVB (R7), R27										
  execution.go:704	0x100210c74		b9400e88		MOVWU 12(R20), R8									
  execution.go:704	0x100210c78		eb13011f		CMP R19, R8										
  execution.go:704	0x100210c7c		540061c2		BCS 782(PC)										
  execution.go:704	0x100210c80		f94008e0		MOVD 16(R7), R0										
  execution.go:704	0x100210c84		8b081187		ADD R8<<4, R12, R7									
  execution.go:704	0x100210c88		f94000e2		MOVD (R7), R2										
  execution.go:704	0x100210c8c		aa1f03e4		MOVD ZR, R4										
  execution.go:704	0x100210c90		aa1f03e5		MOVD ZR, R5										
  execution.go:704	0x100210c94		aa1f03e6		MOVD ZR, R6										
  execution.go:704	0x100210c98		97ff9f1e		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Load(SB)		
  execution.go:342	0x100210c9c		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210ca0		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210ca4		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210ca8		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210cac		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210cb0		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210cb4		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210cb8		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210cbc		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210cc0		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210cc4		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210cc8		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210ccc		aa0103f7		MOVD R1, R23										
  execution.go:704	0x100210cd0		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100210cd4		aa0203e1		MOVD R2, R1										
  execution.go:209	0x100210cd8		f94127e0		MOVD 584(RSP), R0									
  execution.go:704	0x100210cdc		140001e2		JMP 482(PC)										
  execution.go:705	0x100210ce0		7100d83f		CMPW $54, R1										
  execution.go:705	0x100210ce4		54002bc3		BCC 350(PC)										
  execution.go:707	0x100210ce8		a947a1c7		LDP 120(R14), (R7, R8)									
  execution.go:707	0x100210cec		b9400696		MOVWU 4(R20), R22									
  execution.go:707	0x100210cf0		aa1603f7		MOVD R22, R23										
  execution.go:707	0x100210cf4		eb0802ff		CMP R8, R23										
  execution.go:707	0x100210cf8		54005da2		BCS 749(PC)										
  execution.go:707	0x100210cfc		d3787ec8		UBFIZ $8, R22, $32, R8									
  execution.go:707	0x100210d00		cb171508		SUB R23<<5, R8, R8									
  execution.go:707	0x100210d04		8b0800e7		ADD R8, R7, R7										
  execution.go:708	0x100210d08		b9401288		MOVWU 16(R20), R8									
  module.go:178		0x100210d0c		b94014f6		MOVWU 20(R7), R22									
  module.go:178		0x100210d10		29435ce7		LDPW 24(R7), (R7, R23)									
  module.go:178		0x100210d14		aa1782c3		ORR R23<<32, R22, R3									
  execution.go:708	0x100210d18		eb13011f		CMP R19, R8										
  execution.go:708	0x100210d1c		54005c42		BCS 738(PC)										
  execution.go:708	0x100210d20		a9475db6		LDP 112(R13), (R22, R23)								
  execution.go:708	0x100210d24		8b081188		ADD R8<<4, R12, R8									
  execution.go:708	0x100210d28		eb1700ff		CMP R23, R7										
  execution.go:708	0x100210d2c		54005b82		BCS 732(PC)										
  execution.go:708	0x100210d30		f8677ac7		MOVD (R22)(R7<<3), R7									
  execution.go:708	0x100210d34		398000fb		MOVB (R7), R27										
  execution.go:708	0x100210d38		b9400e96		MOVWU 12(R20), R22									
  execution.go:708	0x100210d3c		eb1302df		CMP R19, R22										
  execution.go:708	0x100210d40		54005a82		BCS 724(PC)										
  execution.go:708	0x100210d44		f94008e0		MOVD 16(R7), R0										
  execution.go:708	0x100210d48		8b161187		ADD R22<<4, R12, R7									
  execution.go:708	0x100210d4c		f94000e2		MOVD (R7), R2										
  execution.go:708	0x100210d50		f9400105		MOVD (R8), R5										
  execution.go:708	0x100210d54		aa1f03e4		MOVD ZR, R4										
  execution.go:708	0x100210d58		aa1f03e6		MOVD ZR, R6										
  execution.go:708	0x100210d5c		97ff9f65		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Store(SB)		
  execution.go:342	0x100210d60		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210d64		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210d68		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210d6c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210d70		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210d74		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210d78		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210d7c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210d80		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210d84		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210d88		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210d8c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210d90		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210d94		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100210d98		aa0003e1		MOVD R0, R1										
  execution.go:209	0x100210d9c		f94127e0		MOVD 584(RSP), R0									
  execution.go:708	0x100210da0		140001b1		JMP 433(PC)										
  execution.go:621	0x100210da4		7103483f		CMPW $210, R1										
  execution.go:741	0x100210da8		54000ec8		BHI 118(PC)										
  execution.go:621	0x100210dac		7101043f		CMPW $65, R1										
  execution.go:718	0x100210db0		54000a28		BHI 81(PC)										
  execution.go:709	0x100210db4		7100fc3f		CMPW $63, R1										
  execution.go:709	0x100210db8		540006e0		BEQ 55(PC)										
  execution.go:711	0x100210dbc		7101003f		CMPW $64, R1										
  execution.go:711	0x100210dc0		540000a0		BEQ 5(PC)										
  execution.go:719	0x100210dc4		b9401a96		MOVWU 24(R20), R22									
  execution.go:704	0x100210dc8		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210dcc		aa1f03e1		MOVD ZR, R1										
  execution.go:719	0x100210dd0		140001a5		JMP 421(PC)										
  execution.go:712	0x100210dd4		a94711a3		LDP 112(R13), (R3, R4)									
  execution.go:712	0x100210dd8		b9401a85		MOVWU 24(R20), R5									
  execution.go:712	0x100210ddc		eb0400bf		CMP R4, R5										
  execution.go:712	0x100210de0		54005562		BCS 683(PC)										
  execution.go:712	0x100210de4		f8657861		MOVD (R3)(R5<<3), R1									
  execution.go:713	0x100210de8		f9400823		MOVD 16(R1), R3										
  memory.go:127		0x100210dec		ad410460		FLDPQ 32(R3), (F0, F1)									
  execution.go:713	0x100210df0		910623fb		ADD $392, RSP, R27									
  execution.go:713	0x100210df4		ad000760		FSTPQ (F0, F1), (R27)									
  execution.go:713	0x100210df8		b9400e83		MOVWU 12(R20), R3									
  execution.go:713	0x100210dfc		eb13007f		CMP R19, R3										
  execution.go:713	0x100210e00		54005422		BCS 673(PC)										
  execution.go:713	0x100210e04		8b031183		ADD R3<<4, R12, R3									
  execution.go:713	0x100210e08		f9400062		MOVD (R3), R2										
  module.go:70		0x100210e0c		394667e3		MOVBU 409(RSP), R3									
  module.go:70		0x100210e10		37000043		TBNZ $0, R3, 2(PC)									
  module.go:73		0x100210e14		2a0203e2		MOVW R2, R2										
  execution.go:712	0x100210e18		f900a3e1		MOVD R1, 320(RSP)									
  execution.go:713	0x100210e1c		f9400000		MOVD (R0), R0										
  execution.go:713	0x100210e20		97ffe548		CALL github.com/cpunion/wasmvm/internal/engine/state.(*Store).GrowMemory(SB)		
  execution.go:715	0x100210e24		37000161		TBNZ $0, R1, 11(PC)									
  execution.go:716	0x100210e28		f940a3e9		MOVD 320(RSP), R9									
  execution.go:716	0x100210e2c		f9400929		MOVD 16(R9), R9										
  memory.go:127		0x100210e30		ad410520		FLDPQ 32(R9), (F0, F1)									
  execution.go:716	0x100210e34		910623fb		ADD $392, RSP, R27									
  execution.go:716	0x100210e38		ad000760		FSTPQ (F0, F1), (R27)									
  module.go:77		0x100210e3c		394667e9		MOVBU 409(RSP), R9									
  execution.go:716	0x100210e40		7200013f		TSTW $1, R9										
  execution.go:716	0x100210e44		92800009		MOVD $-1, R9										
  execution.go:716	0x100210e48		b2407fea		MOVD $4294967295, R10									
  execution.go:716	0x100210e4c		9a8a1120		CSEL NE, R9, R10, R0									
  execution.go:342	0x100210e50		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210e54		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210e58		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210e5c		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210e60		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210e64		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210e68		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210e6c		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210e70		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210e74		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210e78		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210e7c		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210e80		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210e84		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100210e88		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x100210e8c		f94127e0		MOVD 584(RSP), R0									
  execution.go:715	0x100210e90		14000175		JMP 373(PC)										
  execution.go:710	0x100210e94		a94709a1		LDP 112(R13), (R1, R2)									
  execution.go:710	0x100210e98		b9401a83		MOVWU 24(R20), R3									
  execution.go:710	0x100210e9c		eb02007f		CMP R2, R3										
  execution.go:710	0x100210ea0		54004f02		BCS 632(PC)										
  execution.go:710	0x100210ea4		f8637821		MOVD (R1)(R3<<3), R1									
  execution.go:710	0x100210ea8		f9400820		MOVD 16(R1), R0										
  execution.go:710	0x100210eac		97ff9c19		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Pages(SB)		
  execution.go:342	0x100210eb0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100210eb4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100210eb8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100210ebc		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100210ec0		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100210ec4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100210ec8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100210ecc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100210ed0		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100210ed4		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100210ed8		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100210edc		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100210ee0		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210ee4		aa0003f6		MOVD R0, R22										
  execution.go:708	0x100210ee8		aa1f03e1		MOVD ZR, R1										
  execution.go:209	0x100210eec		f94127e0		MOVD 584(RSP), R0									
  execution.go:710	0x100210ef0		1400015d		JMP 349(PC)										
  execution.go:621	0x100210ef4		7103403f		CMPW $208, R1										
  execution.go:730	0x100210ef8		540001c8		BHI 14(PC)										
  execution.go:721	0x100210efc		7101103f		CMPW $68, R1										
  execution.go:721	0x100210f00		540000c8		BHI 6(PC)										
  execution.go:722	0x100210f04		b9401a97		MOVWU 24(R20), R23									
  execution.go:722	0x100210f08		aa1682f6		ORR R22<<32, R23, R22									
  execution.go:704	0x100210f0c		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210f10		aa1f03e1		MOVD ZR, R1										
  execution.go:722	0x100210f14		14000154		JMP 340(PC)										
  execution.go:621	0x100210f18		7103403f		CMPW $208, R1										
  execution.go:730	0x100210f1c		54001a01		BNE 208(PC)										
  execution.go:704	0x100210f20		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100210f24		aa1f03f6		MOVD ZR, R22										
  execution.go:708	0x100210f28		aa1f03e1		MOVD ZR, R1										
  execution.go:730	0x100210f2c		1400014e		JMP 334(PC)										
  execution.go:737	0x100210f30		7103443f		CMPW $209, R1										
  execution.go:737	0x100210f34		54000161		BNE 11(PC)										
  execution.go:738	0x100210f38		b9400e96		MOVWU 12(R20), R22									
  execution.go:738	0x100210f3c		eb1302df		CMP R19, R22										
  execution.go:738	0x100210f40		540049a2		BCS 589(PC)										
  execution.go:738	0x100210f44		8b161196		ADD R22<<4, R12, R22									
  execution.go:738	0x100210f48		f94002d6		MOVD (R22), R22										
  execution.go:738	0x100210f4c		f10002df		CMP $0, R22										
  execution.go:738	0x100210f50		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x100210f54		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210f58		aa1f03e1		MOVD ZR, R1										
  execution.go:738	0x100210f5c		14000142		JMP 322(PC)										
  execution.go:742	0x100210f60		a9445db6		LDP 64(R13), (R22, R23)									
  execution.go:742	0x100210f64		b9401a98		MOVWU 24(R20), R24									
  execution.go:742	0x100210f68		eb17031f		CMP R23, R24										
  execution.go:742	0x100210f6c		540047e2		BCS 575(PC)										
  execution.go:742	0x100210f70		f8787ad6		MOVD (R22)(R24<<3), R22									
  execution.go:704	0x100210f74		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210f78		aa1f03e1		MOVD ZR, R1										
  execution.go:742	0x100210f7c		1400013a		JMP 314(PC)										
  execution.go:621	0x100210f80		d2800077		MOVD $3, R23										
  execution.go:621	0x100210f84		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x100210f88		6b17003f		CMPW R23, R1										
  execution.go:634	0x100210f8c		54000808		BHI 64(PC)										
  execution.go:621	0x100210f90		7103503f		CMPW $212, R1										
  execution.go:731	0x100210f94		540003a8		BHI 29(PC)										
  execution.go:726	0x100210f98		71034c3f		CMPW $211, R1										
  execution.go:726	0x100210f9c		540001e1		BNE 15(PC)										
  execution.go:727	0x100210fa0		2941de96		LDPW 12(R20), (R22, R23)								
  execution.go:727	0x100210fa4		eb1302df		CMP R19, R22										
  execution.go:727	0x100210fa8		540045a2		BCS 557(PC)										
  execution.go:727	0x100210fac		8b161196		ADD R22<<4, R12, R22									
  execution.go:727	0x100210fb0		eb1302ff		CMP R19, R23										
  execution.go:727	0x100210fb4		540044e2		BCS 551(PC)										
  execution.go:727	0x100210fb8		f94002d6		MOVD (R22), R22										
  execution.go:727	0x100210fbc		8b171197		ADD R23<<4, R12, R23									
  execution.go:727	0x100210fc0		f94002f7		MOVD (R23), R23										
  execution.go:727	0x100210fc4		eb1602ff		CMP R22, R23										
  execution.go:727	0x100210fc8		9a9f17f6		CSET EQ, R22										
  execution.go:704	0x100210fcc		aa1f03f7		MOVD ZR, R23										
  execution.go:708	0x100210fd0		aa1f03e1		MOVD ZR, R1										
  execution.go:727	0x100210fd4		14000124		JMP 292(PC)										
  execution.go:732	0x100210fd8		b9400e96		MOVWU 12(R20), R22									
  execution.go:732	0x100210fdc		eb1302df		CMP R19, R22										
  execution.go:732	0x100210fe0		54004322		BCS 537(PC)										
  execution.go:732	0x100210fe4		8b161196		ADD R22<<4, R12, R22									
  execution.go:732	0x100210fe8		a9405ed6		LDP (R22), (R22, R23)									
  execution.go:732	0x100210fec		b50000b6		CBNZ R22, 5(PC)										
  execution.go:732	0x100210ff0		d2800121		MOVD $9, R1										
  execution.go:735	0x100210ff4		aa1f03f7		MOVD ZR, R23										
  execution.go:735	0x100210ff8		aa1f03f6		MOVD ZR, R22										
  execution.go:732	0x100210ffc		1400011a		JMP 282(PC)										
  execution.go:733	0x100211000		aa1f03e1		MOVD ZR, R1										
  execution.go:735	0x100211004		14000118		JMP 280(PC)										
  execution.go:723	0x100211008		d17f0037		SUB $(4032<<12), R1, R23								
  execution.go:723	0x10021100c		71001eff		CMPW $7, R23										
  execution.go:724	0x100211010		540000c9		BLS 6(PC)										
  execution.go:634	0x100211014		d2800037		MOVD $1, R23										
  execution.go:634	0x100211018		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x10021101c		6b17003f		CMPW R23, R1										
  execution.go:634	0x100211020		54000582		BCS 44(PC)										
  execution.go:634	0x100211024		1400008e		JMP 142(PC)										
  execution.go:725	0x100211028		b9400e83		MOVWU 12(R20), R3									
  execution.go:725	0x10021102c		eb13007f		CMP R19, R3										
  execution.go:725	0x100211030		54004062		BCS 515(PC)										
  execution.go:725	0x100211034		8b031183		ADD R3<<4, R12, R3									
  execution.go:725	0x100211038		f9400063		MOVD (R3), R3										
  execution.go:725	0x10021103c		aa0103e0		MOVD R1, R0										
  execution.go:725	0x100211040		aa0303e1		MOVD R3, R1										
  execution.go:725	0x100211044		aa1f03e2		MOVD ZR, R2										
  execution.go:725	0x100211048		97ffa6de		CALL github.com/cpunion/wasmvm/internal/engine/numeric.Eval(SB)				
  execution.go:342	0x10021104c		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100211050		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x100211054		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100211058		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x10021105c		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100211060		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x100211064		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100211068		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x10021106c		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100211070		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x100211074		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100211078		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x10021107c		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x100211080		aa0003f6		MOVD R0, R22										
  execution.go:209	0x100211084		f94127e0		MOVD 584(RSP), R0									
  execution.go:725	0x100211088		140000f7		JMP 247(PC)										
  execution.go:621	0x10021108c		d28000b7		MOVD $5, R23										
  execution.go:621	0x100211090		f2a02017		MOVK $(256<<16), R23									
  execution.go:621	0x100211094		6b17003f		CMPW R23, R1										
  execution.go:634	0x100211098		540000c8		BHI 6(PC)										
  execution.go:622	0x10021109c		d2800097		MOVD $4, R23										
  execution.go:622	0x1002110a0		f2a02017		MOVK $(256<<16), R23									
  execution.go:622	0x1002110a4		6b17003f		CMPW R23, R1										
  execution.go:622	0x1002110a8		54000141		BNE 10(PC)										
  execution.go:622	0x1002110ac		14000108		JMP 264(PC)										
  execution.go:628	0x1002110b0		d28000f7		MOVD $7, R23										
  execution.go:628	0x1002110b4		f2a02017		MOVK $(256<<16), R23									
  execution.go:628	0x1002110b8		6b17003f		CMPW R23, R1										
  execution.go:628	0x1002110bc		54002120		BEQ 265(PC)										
  execution.go:634	0x1002110c0		d2800137		MOVD $9, R23										
  execution.go:634	0x1002110c4		f2a02017		MOVK $(256<<16), R23									
  execution.go:634	0x1002110c8		6b17003f		CMPW R23, R1										
  execution.go:634	0x1002110cc		54000c81		BNE 100(PC)										
  execution.go:635	0x1002110d0		d2a02017		MOVD $16777216, R23									
  execution.go:635	0x1002110d4		cb170037		SUB R23, R1, R23									
  execution.go:636	0x1002110d8		d3401ef7		UBFX $0, R23, $8, R23									
  execution.go:636	0x1002110dc		710016ff		CMPW $5, R23										
  execution.go:636	0x1002110e0		540000a1		BNE 5(PC)										
  execution.go:704	0x1002110e4		aa1f03f7		MOVD ZR, R23										
  execution.go:704	0x1002110e8		aa1f03f6		MOVD ZR, R22										
  execution.go:704	0x1002110ec		b24003e1		ORR $1, ZR, R1										
  execution.go:638	0x1002110f0		140000dd		JMP 221(PC)										
  execution.go:641	0x1002110f4		710026ff		CMPW $9, R23										
  execution.go:641	0x1002110f8		54000121		BNE 9(PC)										
  execution.go:641	0x1002110fc		b9400e98		MOVWU 12(R20), R24									
  execution.go:641	0x100211100		eb13031f		CMP R19, R24										
  execution.go:641	0x100211104		54003962		BCS 459(PC)										
  execution.go:641	0x100211108		8b181198		ADD R24<<4, R12, R24									
  execution.go:641	0x10021110c		f9400318		MOVD (R24), R24										
  execution.go:641	0x100211110		b4000078		CBZ R24, 3(PC)										
  execution.go:641	0x100211114		b24003f6		ORR $1, ZR, R22										
  execution.go:641	0x100211118		14000018		JMP 24(PC)										
  execution.go:643	0x10021111c		71000aff		CMPW $2, R23										
  execution.go:643	0x100211120		54000121		BNE 9(PC)										
  execution.go:643	0x100211124		b9400e98		MOVWU 12(R20), R24									
  execution.go:643	0x100211128		eb13031f		CMP R19, R24										
  execution.go:643	0x10021112c		540037c2		BCS 446(PC)										
  execution.go:643	0x100211130		8b181198		ADD R24<<4, R12, R24									
  execution.go:643	0x100211134		f9400318		MOVD (R24), R24										
  execution.go:643	0x100211138		35000078		CBNZW R24, 3(PC)									
  execution.go:643	0x10021113c		b24003f6		ORR $1, ZR, R22										
  execution.go:643	0x100211140		1400000e		JMP 14(PC)										
  execution.go:645	0x100211144		71000eff		CMPW $3, R23										
  execution.go:645	0x100211148		54000161		BNE 11(PC)										
  execution.go:646	0x10021114c		b9400e97		MOVWU 12(R20), R23									
  execution.go:646	0x100211150		eb1302ff		CMP R19, R23										
  execution.go:646	0x100211154		54003622		BCS 433(PC)										
  execution.go:646	0x100211158		8b171197		ADD R23<<4, R12, R23									
  execution.go:646	0x10021115c		f94002f7		MOVD (R23), R23										
  execution.go:647	0x100211160		d10006d6		SUB $1, R22, R22									
  execution.go:647	0x100211164		6b1602ff		CMPW R22, R23										
  execution.go:647	0x100211168		54000082		BCS 4(PC)										
  execution.go:648	0x10021116c		aa1703f6		MOVD R23, R22										
  execution.go:647	0x100211170		14000002		JMP 2(PC)										
  execution.go:647	0x100211174		aa1f03f6		MOVD ZR, R22										
  execution.go:651	0x100211178		a94e61d7		LDP 224(R14), (R23, R24)								
  execution.go:651	0x10021117c		b9401a94		MOVWU 24(R20), R20									
  execution.go:651	0x100211180		8b1402d4		ADD R20, R22, R20									
  execution.go:651	0x100211184		2a1403f6		MOVW R20, R22										
  execution.go:651	0x100211188		eb1802df		CMP R24, R22										
  execution.go:651	0x10021118c		54003402		BCS 416(PC)										
  execution.go:651	0x100211190		d37e7e94		UBFIZ $2, R20, $32, R20									
  execution.go:651	0x100211194		8b140694		ADD R20<<1, R20, R20									
  execution.go:651	0x100211198		b8746af6		MOVWU (R23)(R20), R22									
  execution.go:651	0x10021119c		8b1402f4		ADD R20, R23, R20									
  execution.go:651	0x1002111a0		2940de94		LDPW 4(R20), (R20, R23)									
  execution.go:652	0x1002111a4		6b16023f		CMPW R22, R17										
  execution.go:652	0x1002111a8		540003e3		BCC 31(PC)										
  execution.go:651	0x1002111ac		b90107f7		MOVW R23, 260(RSP)									
  execution.go:651	0x1002111b0		b90103f4		MOVW R20, 256(RSP)									
  execution.go:651	0x1002111b4		b900fff6		MOVW R22, 252(RSP)									
  execution.go:209	0x1002111b8		f940b011		MOVD 352(R0), R17									
  execution.go:209	0x1002111bc		b40000d1		CBZ R17, 6(PC)										
  type.go:19		0x1002111c0		88dffe31		LDARW (R17), R17									
  execution.go:209	0x1002111c4		35000091		CBNZW R17, 4(PC)									
  execution.go:212	0x1002111c8		aa1f03e1		MOVD ZR, R1										
  execution.go:212	0x1002111cc		aa1f03e2		MOVD ZR, R2										
  execution.go:653	0x1002111d0		14000014		JMP 20(PC)										
  execution.go:212	0x1002111d4		a9408001		LDP 8(R0), (R1, R0)									
  execution.go:212	0x1002111d8		f9401421		MOVD 40(R1), R1										
  execution.go:212	0x1002111dc		d63f0020		CALL (R1)										
  execution.go:342	0x1002111e0		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x1002111e4		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x1002111e8		f940b3eb		MOVD 352(RSP), R11									
  execution.go:658	0x1002111ec		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x1002111f0		f940abed		MOVD 336(RSP), R13									
  execution.go:657	0x1002111f4		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x1002111f8		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x1002111fc		f9408bf0		MOVD 272(RSP), R16									
  execution.go:658	0x100211200		f94087f3		MOVD 264(RSP), R19									
  execution.go:657	0x100211204		b94103f4		MOVWU 256(RSP), R20									
  execution.go:341	0x100211208		f94093f5		MOVD 288(RSP), R21									
  execution.go:460	0x10021120c		b940fff6		MOVWU 252(RSP), R22									
  execution.go:657	0x100211210		b94107f7		MOVWU 260(RSP), R23									
  execution.go:212	0x100211214		aa0103e2		MOVD R1, R2										
  execution.go:212	0x100211218		aa0003e1		MOVD R0, R1										
  execution.go:654	0x10021121c		f94127e0		MOVD 584(RSP), R0									
  execution.go:653	0x100211220		b5002161		CBNZ R1, 267(PC)									
  execution.go:657	0x100211224		f94085d1		MOVD 264(R14), R17									
  execution.go:657	0x100211228		8b170297		ADD R23, R20, R23									
  execution.go:657	0x10021122c		2a1703f7		MOVW R23, R23										
  execution.go:657	0x100211230		eb1102ff		CMP R17, R23										
  execution.go:657	0x100211234		54002e68		BHI 371(PC)										
  execution.go:657	0x100211238		eb17029f		CMP R23, R20										
  execution.go:657	0x10021123c		54002dc8		BHI 366(PC)										
  execution.go:657	0x100211240		f9407dd8		MOVD 248(R14), R24									
  execution.go:657	0x100211244		cb110291		SUB R17, R20, R17									
  execution.go:657	0x100211248		8a91fe91		AND R17->63, R20, R17									
  execution.go:657	0x10021124c		cb1402f4		SUB R20, R23, R20									
  execution.go:657	0x100211250		8b110f11		ADD R17<<3, R24, R17									
  execution.go:657	0x100211254		aa1f03f7		MOVD ZR, R23										
  execution.go:657	0x100211258		14000154		JMP 340(PC)										
  execution.go:751	0x10021125c		b9400e96		MOVWU 12(R20), R22									
  execution.go:751	0x100211260		310006df		CMNW $1, R22										
  execution.go:751	0x100211264		540000c0		BEQ 6(PC)										
  execution.go:752	0x100211268		eb1302df		CMP R19, R22										
  execution.go:752	0x10021126c		54002922		BCS 329(PC)										
  execution.go:752	0x100211270		8b161196		ADD R22<<4, R12, R22									
  execution.go:752	0x100211274		f94002c2		MOVD (R22), R2										
  execution.go:752	0x100211278		14000002		JMP 2(PC)										
  execution.go:752	0x10021127c		aa1f03e2		MOVD ZR, R2										
  execution.go:754	0x100211280		b9401296		MOVWU 16(R20), R22									
  execution.go:754	0x100211284		310006df		CMNW $1, R22										
  execution.go:754	0x100211288		540000c0		BEQ 6(PC)										
  execution.go:755	0x10021128c		eb1302df		CMP R19, R22										
  execution.go:755	0x100211290		540027a2		BCS 317(PC)										
  execution.go:755	0x100211294		8b161196		ADD R22<<4, R12, R22									
  execution.go:755	0x100211298		f94002c4		MOVD (R22), R4										
  execution.go:755	0x10021129c		14000002		JMP 2(PC)										
  execution.go:755	0x1002112a0		aa1f03e4		MOVD ZR, R4										
  execution.go:757	0x1002112a4		b9401696		MOVWU 20(R20), R22									
  execution.go:757	0x1002112a8		310006df		CMNW $1, R22										
  execution.go:757	0x1002112ac		540000c0		BEQ 6(PC)										
  execution.go:758	0x1002112b0		eb1302df		CMP R19, R22										
  execution.go:758	0x1002112b4		54002622		BCS 305(PC)										
  execution.go:758	0x1002112b8		8b161196		ADD R22<<4, R12, R22									
  execution.go:758	0x1002112bc		f94002c6		MOVD (R22), R6										
  execution.go:758	0x1002112c0		14000002		JMP 2(PC)										
  execution.go:758	0x1002112c4		aa1f03e6		MOVD ZR, R6										
  execution.go:762	0x1002112c8		d3507c36		UBFX $16, R1, $16, R22									
  execution.go:762	0x1002112cc		7103fadf		CMPW $254, R22										
  execution.go:762	0x1002112d0		54000501		BNE 40(PC)										
  execution.go:763	0x1002112d4		d3403c36		UBFX $0, R1, $16, R22									
  execution.go:763	0x1002112d8		71000edf		CMPW $3, R22										
  execution.go:763	0x1002112dc		54000101		BNE 8(PC)										
  execution.go:764	0x1002112e0		f9400001		MOVD (R0), R1										
  execution.go:764	0x1002112e4		f9400420		MOVD 8(R1), R0										
  execution.go:764	0x1002112e8		97ff9a36		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Domain).Fence(SB)		
  execution.go:770	0x1002112ec		aa1f03e2		MOVD ZR, R2										
  execution.go:770	0x1002112f0		aa1f03e1		MOVD ZR, R1										
  execution.go:770	0x1002112f4		aa1f03e0		MOVD ZR, R0										
  execution.go:765	0x1002112f8		1400004b		JMP 75(PC)										
  execution.go:767	0x1002112fc		a947e1d7		LDP 120(R14), (R23, R24)								
  execution.go:767	0x100211300		b9400699		MOVWU 4(R20), R25									
  execution.go:767	0x100211304		aa1903fa		MOVD R25, R26										
  execution.go:767	0x100211308		eb18035f		CMP R24, R26										
  execution.go:767	0x10021130c		54002302		BCS 280(PC)										
  execution.go:767	0x100211310		d3787f38		UBFIZ $8, R25, $32, R24									
  execution.go:767	0x100211314		cb1a1718		SUB R26<<5, R24, R24									
  execution.go:767	0x100211318		8b1802f7		ADD R24, R23, R23									
  execution.go:769	0x10021131c		a94765b8		LDP 112(R13), (R24, R25)								
  module.go:178		0x100211320		2942fafa		LDPW 20(R23), (R26, R30)								
  module.go:178		0x100211324		b9401ef7		MOVWU 28(R23), R23									
  module.go:178		0x100211328		aa178357		ORR R23<<32, R26, R23									
  execution.go:769	0x10021132c		eb1903df		CMP R25, R30										
  execution.go:769	0x100211330		54002182		BCS 268(PC)										
  execution.go:769	0x100211334		f87e7b09		MOVD (R24)(R30<<3), R9									
  execution.go:769	0x100211338		f9400929		MOVD 16(R9), R9										
  execution.go:769	0x10021133c		f940080a		MOVD 16(R0), R10									
  execution.go:769	0x100211340		a940040b		LDP (R0), (R11, R1)									
  execution.go:769	0x100211344		f9400563		MOVD 8(R11), R3										
  execution.go:769	0x100211348		aa0903e0		MOVD R9, R0										
  execution.go:769	0x10021134c		aa0203e5		MOVD R2, R5										
  execution.go:769	0x100211350		aa0403e7		MOVD R4, R7										
  execution.go:769	0x100211354		aa0603e8		MOVD R6, R8										
  execution.go:769	0x100211358		aa0a03e2		MOVD R10, R2										
  execution.go:769	0x10021135c		aa1603e4		MOVD R22, R4										
  execution.go:769	0x100211360		aa1703e6		MOVD R23, R6										
  execution.go:769	0x100211364		97ff9e57		CALL github.com/cpunion/wasmvm/internal/engine/memory.(*Memory).Atomic(SB)		
  execution.go:770	0x100211368		b40005e3		CBZ R3, 47(PC)										
  execution.go:770	0x10021136c		140000bd		JMP 189(PC)										
  execution.go:773	0x100211370		d2800108		MOVD $8, R8										
  execution.go:773	0x100211374		f2a01f88		MOVK $(252<<16), R8									
  execution.go:773	0x100211378		cb080028		SUB R8, R1, R8										
  execution.go:773	0x10021137c		7100251f		CMPW $9, R8										
  execution.go:773	0x100211380		54001e68		BHI 243(PC)										
  execution.go:774	0x100211384		a947d9c8		LDP 120(R14), (R8, R22)									
  execution.go:774	0x100211388		b9400697		MOVWU 4(R20), R23									
  execution.go:774	0x10021138c		aa1703f8		MOVD R23, R24										
  execution.go:774	0x100211390		eb16031f		CMP R22, R24										
  execution.go:774	0x100211394		54001d62		BCS 235(PC)										
  execution.go:774	0x100211398		d3787ee9		UBFIZ $8, R23, $32, R9									
  execution.go:774	0x10021139c		cb181529		SUB R24<<5, R9, R9									
  execution.go:774	0x1002113a0		8b090108		ADD R9, R8, R8										
  execution.go:776	0x1002113a4		910623e9		ADD $392, RSP, R9									
  execution.go:776	0x1002113a8		ad404510		FLDPQ (R8), (F16, F17)									
  execution.go:776	0x1002113ac		ad004530		FSTPQ (F16, F17), (R9)									
  execution.go:776	0x1002113b0		ad414510		FLDPQ 32(R8), (F16, F17)								
  execution.go:776	0x1002113b4		ad014530		FSTPQ (F16, F17), 32(R9)								
  execution.go:776	0x1002113b8		ad424510		FLDPQ 64(R8), (F16, F17)								
  execution.go:776	0x1002113bc		ad024530		FSTPQ (F16, F17), 64(R9)								
  execution.go:776	0x1002113c0		ad434510		FLDPQ 96(R8), (F16, F17)								
  execution.go:776	0x1002113c4		ad034530		FSTPQ (F16, F17), 96(R9)								
  execution.go:776	0x1002113c8		ad444510		FLDPQ 128(R8), (F16, F17)								
  execution.go:776	0x1002113cc		ad044530		FSTPQ (F16, F17), 128(R9)								
  execution.go:776	0x1002113d0		f9405119		MOVD 160(R8), R25									
  execution.go:776	0x1002113d4		f9005139		MOVD R25, 160(R9)									
  execution.go:776	0x1002113d8		910023e8		ADD $8, RSP, R8										
  execution.go:776	0x1002113dc		ad404530		FLDPQ (R9), (F16, F17)									
  execution.go:776	0x1002113e0		ad004510		FSTPQ (F16, F17), (R8)									
  execution.go:776	0x1002113e4		ad414530		FLDPQ 32(R9), (F16, F17)								
  execution.go:776	0x1002113e8		ad014510		FSTPQ (F16, F17), 32(R8)								
  execution.go:776	0x1002113ec		ad424530		FLDPQ 64(R9), (F16, F17)								
  execution.go:776	0x1002113f0		ad024510		FSTPQ (F16, F17), 64(R8)								
  execution.go:776	0x1002113f4		ad434530		FLDPQ 96(R9), (F16, F17)								
  execution.go:776	0x1002113f8		ad034510		FSTPQ (F16, F17), 96(R8)								
  execution.go:776	0x1002113fc		ad444530		FLDPQ 128(R9), (F16, F17)								
  execution.go:776	0x100211400		ad044510		FSTPQ (F16, F17), 128(R8)								
  execution.go:776	0x100211404		f9405139		MOVD 160(R9), R25									
  execution.go:776	0x100211408		f9005119		MOVD R25, 160(R8)									
  execution.go:776	0x10021140c		aa0d03e1		MOVD R13, R1										
  execution.go:776	0x100211410		aa1f03e3		MOVD ZR, R3										
  execution.go:776	0x100211414		aa1f03e5		MOVD ZR, R5										
  execution.go:776	0x100211418		aa1f03e7		MOVD ZR, R7										
  execution.go:776	0x10021141c		97fff0c1		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).bulk(SB)		
  execution.go:777	0x100211420		b5001703		CBNZ R3, 184(PC)									
  execution.go:342	0x100211424		3943dfe9		MOVBU 247(RSP), R9									
  execution.go:466	0x100211428		f940b7ea		MOVD 360(RSP), R10									
  execution.go:786	0x10021142c		f940b3eb		MOVD 352(RSP), R11									
  execution.go:790	0x100211430		f9409bec		MOVD 304(RSP), R12									
  execution.go:686	0x100211434		f940abed		MOVD 336(RSP), R13									
  execution.go:343	0x100211438		f940bfee		MOVD 376(RSP), R14									
  execution.go:341	0x10021143c		f940a7ef		MOVD 328(RSP), R15									
  execution.go:341	0x100211440		f9408bf0		MOVD 272(RSP), R16									
  execution.go:792	0x100211444		b94107f1		MOVWU 260(RSP), R17									
  execution.go:790	0x100211448		f94087f3		MOVD 264(RSP), R19									
  execution.go:789	0x10021144c		f940c3f4		MOVD 384(RSP), R20									
  execution.go:341	0x100211450		f94093f5		MOVD 288(RSP), R21									
  execution.go:704	0x100211454		aa0103f7		MOVD R1, R23										
  execution.go:704	0x100211458		aa0003f6		MOVD R0, R22										
  execution.go:708	0x10021145c		aa0203e1		MOVD R2, R1										
  execution.go:209	0x100211460		f94127e0		MOVD 584(RSP), R0									
  execution.go:785	0x100211464		d3401c38		UBFX $0, R1, $8, R24									
  execution.go:785	0x100211468		350010d8		CBNZW R24, 134(PC)									
  execution.go:789	0x10021146c		b9400a94		MOVWU 8(R20), R20									
  execution.go:789	0x100211470		3100069f		CMNW $1, R20										
  execution.go:789	0x100211474		540000a0		BEQ 5(PC)										
  execution.go:790	0x100211478		eb13029f		CMP R19, R20										
  execution.go:790	0x10021147c		540015c2		BCS 174(PC)										
  execution.go:790	0x100211480		8b141194		ADD R20<<4, R12, R20									
  execution.go:790	0x100211484		a9005e96		STP (R22, R23), (R20)									
  execution.go:792	0x100211488		91000631		ADD $1, R17, R17									
  execution.go:793	0x10021148c		17fff90e		JMP -1778(PC)										
  execution.go:466	0x100211490		b9000951		MOVW R17, 8(R10)									
  execution.go:467	0x100211494		94000827		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:467	0x100211498		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:467	0x10021149c		34ff1d21		CBZW R1, -1815(PC)									
  execution.go:467	0x1002114a0		1400003b		JMP 59(PC)										
  execution.go:664	0x1002114a4		b9000951		MOVW R17, 8(R10)									
  execution.go:665	0x1002114a8		94000dde		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runThrow(SB)	
  execution.go:665	0x1002114ac		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:665	0x1002114b0		34ff1c81		CBZW R1, -1820(PC)									
  execution.go:665	0x1002114b4		1400005a		JMP 90(PC)										
  execution.go:744	0x1002114b8		b9000951		MOVW R17, 8(R10)									
  execution.go:745	0x1002114bc		94000abd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runCall(SB)		
  execution.go:745	0x1002114c0		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:745	0x1002114c4		34ff1be1		CBZW R1, -1825(PC)									
  execution.go:745	0x1002114c8		14000059		JMP 89(PC)										
  execution.go:623	0x1002114cc		b9000951		MOVW R17, 8(R10)									
  execution.go:624	0x1002114d0		94000eb0		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).returnFrame(SB)	
  execution.go:624	0x1002114d4		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:624	0x1002114d8		34ff1b41		CBZW R1, -1830(PC)									
  execution.go:624	0x1002114dc		14000058		JMP 88(PC)										
  execution.go:629	0x1002114e0		b9000951		MOVW R17, 8(R10)									
  execution.go:630	0x1002114e4		94000813		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runRuntime(SB)	
  execution.go:630	0x1002114e8		d3401c01		UBFX $0, R0, $8, R1									
  execution.go:630	0x1002114ec		34ff1aa1		CBZW R1, -1835(PC)									
  execution.go:630	0x1002114f0		1400008c		JMP 140(PC)										
  execution.go:343	0x1002114f4		f9009ff5		MOVD R21, 312(RSP)									
  execution.go:341	0x1002114f8		f90097e1		MOVD R1, 296(RSP)									
  execution.go:346	0x1002114fc		d2800500		MOVD $40, R0										
  execution.go:346	0x100211500		d0001221		ADRP 2383872(PC), R1									
  execution.go:346	0x100211504		910b0021		ADD $704, R1, R1									
  execution.go:346	0x100211508		b24003e2		ORR $1, ZR, R2										
  execution.go:346	0x10021150c		97f82dbd		CALL runtime.mallocgcSmallScanNoHeaderSC5(SB)						
  execution.go:346	0x100211510		d000137b		ADRP 2547712(PC), R27									
  execution.go:346	0x100211514		9104437b		ADD $272, R27, R27									
  execution.go:346	0x100211518		a9401363		LDP (R27), (R3, R4)									
  execution.go:346	0x10021151c		f9000003		MOVD R3, (R0)										
  execution.go:346	0x100211520		f00014db		ADRP 2732032(PC), R27									
  execution.go:346	0x100211524		b94ef363		MOVWU 3824(R27), R3									
  execution.go:346	0x100211528		34000063		CBZW R3, 3(PC)										
  execution.go:346	0x10021152c		97f9c74d		CALL runtime.gcWriteBarrier1(SB)							
  execution.go:346	0x100211530		f9000324		MOVD R4, (R25)										
  execution.go:346	0x100211534		f9000404		MOVD R4, 8(R0)										
  execution.go:346	0x100211538		f9409fe3		MOVD 312(RSP), R3									
  execution.go:346	0x10021153c		f9400463		MOVD 8(R3), R3										
  execution.go:346	0x100211540		f00000e4		ADRP 126976(PC), R4									
  execution.go:346	0x100211544		91243c84		ADD $2319, R4, R4									
  execution.go:346	0x100211548		a9011003		STP (R3, R4), 16(R0)									
  execution.go:346	0x10021154c		b27f0be3		ORR $14, ZR, R3										
  execution.go:346	0x100211550		f9001003		MOVD R3, 32(R0)										
  execution.go:346	0x100211554		f00012e1		ADRP 2486272(PC), R1									
  execution.go:346	0x100211558		9116e021		ADD $1464, R1, R1									
  execution.go:346	0x10021155c		aa0003e2		MOVD R0, R2										
  execution.go:346	0x100211560		f94127e0		MOVD 584(RSP), R0									
  execution.go:346	0x100211564		97fff63f		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:346	0x100211568		f94097e1		MOVD 296(RSP), R1									
  execution.go:346	0x10021156c		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:346	0x100211570		910903ff		ADD $576, RSP, RSP									
  execution.go:346	0x100211574		d65f03c0		RET											
  execution.go:353	0x100211578		97fff63a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:353	0x10021157c		f94097e1		MOVD 296(RSP), R1									
  execution.go:353	0x100211580		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:353	0x100211584		910903ff		ADD $576, RSP, RSP									
  execution.go:353	0x100211588		d65f03c0		RET											
  execution.go:468	0x10021158c		f94093e1		MOVD 288(RSP), R1									
  execution.go:468	0x100211590		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:468	0x100211594		910903ff		ADD $576, RSP, RSP									
  execution.go:468	0x100211598		d65f03c0		RET											
  execution.go:412	0x10021159c		f900bbe3		MOVD R3, 368(RSP)									
  execution.go:412	0x1002115a0		f9008fe2		MOVD R2, 280(RSP)									
  execution.go:414	0x1002115a4		b27d03e0		ORR $8, ZR, R0										
  execution.go:414	0x1002115a8		90001081		ADRP 2162688(PC), R1									
  execution.go:414	0x1002115ac		91026021		ADD $152, R1, R1									
  execution.go:414	0x1002115b0		b24003e2		ORR $1, ZR, R2										
  execution.go:414	0x1002115b4		97f82a5f		CALL runtime.mallocgcSmallScanNoHeaderSC1(SB)						
  execution.go:414	0x1002115b8		f9011be0		MOVD R0, 560(RSP)									
  execution.go:415	0x1002115bc		f940bbe1		MOVD 368(RSP), R1									
  execution.go:415	0x1002115c0		b0000fc2		ADRP 2068480(PC), R2									
  execution.go:415	0x1002115c4		91246042		ADD $2328, R2, R2									
  execution.go:415	0x1002115c8		aa0003e3		MOVD R0, R3										
  execution.go:415	0x1002115cc		f9408fe0		MOVD 280(RSP), R0									
  execution.go:415	0x1002115d0		97f9db08		CALL errors.As(SB)									
  execution.go:415	0x1002115d4		360000c0		TBZ $0, R0, 6(PC)									
  execution.go:416	0x1002115d8		f9411be3		MOVD 560(RSP), R3									
  execution.go:416	0x1002115dc		f9400063		MOVD (R3), R3										
  execution.go:416	0x1002115e0		f940b3e4		MOVD 352(RSP), R4									
  execution.go:416	0x1002115e4		b9405084		MOVWU 80(R4), R4									
  execution.go:416	0x1002115e8		b9000464		MOVW R4, 4(R3)										
  execution.go:418	0x1002115ec		f94127e0		MOVD 584(RSP), R0									
  execution.go:418	0x1002115f0		f9408fe1		MOVD 280(RSP), R1									
  execution.go:418	0x1002115f4		f940bbe2		MOVD 368(RSP), R2									
  execution.go:418	0x1002115f8		97fff61a		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:418	0x1002115fc		f94093e1		MOVD 288(RSP), R1									
  execution.go:418	0x100211600		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:418	0x100211604		910903ff		ADD $576, RSP, RSP									
  execution.go:418	0x100211608		d65f03c0		RET											
  execution.go:426	0x10021160c		f94093e1		MOVD 288(RSP), R1									
  execution.go:426	0x100211610		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:426	0x100211614		910903ff		ADD $576, RSP, RSP									
  execution.go:426	0x100211618		d65f03c0		RET											
  execution.go:666	0x10021161c		f94093e1		MOVD 288(RSP), R1									
  execution.go:666	0x100211620		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:666	0x100211624		910903ff		ADD $576, RSP, RSP									
  execution.go:666	0x100211628		d65f03c0		RET											
  execution.go:746	0x10021162c		f94093e1		MOVD 288(RSP), R1									
  execution.go:746	0x100211630		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:746	0x100211634		910903ff		ADD $576, RSP, RSP									
  execution.go:746	0x100211638		d65f03c0		RET											
  execution.go:625	0x10021163c		f94093e1		MOVD 288(RSP), R1									
  execution.go:625	0x100211640		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:625	0x100211644		910903ff		ADD $576, RSP, RSP									
  execution.go:625	0x100211648		d65f03c0		RET											
  execution.go:654	0x10021164c		97fff605		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:654	0x100211650		f94093e1		MOVD 288(RSP), R1									
  execution.go:654	0x100211654		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:654	0x100211658		910903ff		ADD $576, RSP, RSP									
  execution.go:654	0x10021165c		d65f03c0		RET											
  execution.go:771	0x100211660		f94127e0		MOVD 584(RSP), R0									
  execution.go:771	0x100211664		aa0303e1		MOVD R3, R1										
  execution.go:771	0x100211668		aa0403e2		MOVD R4, R2										
  execution.go:771	0x10021166c		97fff5fd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:771	0x100211670		f94093e1		MOVD 288(RSP), R1									
  execution.go:771	0x100211674		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:771	0x100211678		910903ff		ADD $576, RSP, RSP									
  execution.go:771	0x10021167c		d65f03c0		RET											
  execution.go:395	0x100211680		3903dbe1		MOVB R1, 246(RSP)									
  execution.go:786	0x100211684		b27c03e0		ORR $16, ZR, R0										
  execution.go:786	0x100211688		d0001221		ADRP 2383872(PC), R1									
  execution.go:786	0x10021168c		910da021		ADD $872, R1, R1									
  execution.go:786	0x100211690		b24003e2		ORR $1, ZR, R2										
  execution.go:786	0x100211694		97f830df		CALL runtime.mallocgcSmallNoScanSC2(SB)							
  execution.go:786	0x100211698		3943dbe3		MOVBU 246(RSP), R3									
  execution.go:786	0x10021169c		39000003		MOVB R3, (R0)										
  execution.go:786	0x1002116a0		f940b3e3		MOVD 352(RSP), R3									
  execution.go:786	0x1002116a4		b9405063		MOVWU 80(R3), R3									
  execution.go:786	0x1002116a8		b9000403		MOVW R3, 4(R0)										
  execution.go:786	0x1002116ac		f940bfe3		MOVD 376(RSP), R3									
  execution.go:786	0x1002116b0		a9479063		LDP 120(R3), (R3, R4)									
  execution.go:786	0x1002116b4		f940c3e5		MOVD 384(RSP), R5									
  execution.go:786	0x1002116b8		b94004a5		MOVWU 4(R5), R5										
  execution.go:786	0x1002116bc		aa0503e6		MOVD R5, R6										
  execution.go:786	0x1002116c0		eb0400df		CMP R4, R6										
  execution.go:786	0x1002116c4		54000362		BCS 27(PC)										
  execution.go:786	0x1002116c8		d3787ca4		UBFIZ $8, R5, $32, R4									
  execution.go:786	0x1002116cc		cb061484		SUB R6<<5, R4, R4									
  execution.go:786	0x1002116d0		8b040063		ADD R4, R3, R3										
  execution.go:786	0x1002116d4		f9400463		MOVD 8(R3), R3										
  execution.go:786	0x1002116d8		f9000403		MOVD R3, 8(R0)										
  execution.go:786	0x1002116dc		f00012e1		ADRP 2486272(PC), R1									
  execution.go:786	0x1002116e0		9117e021		ADD $1528, R1, R1									
  execution.go:786	0x1002116e4		aa0003e2		MOVD R0, R2										
  execution.go:786	0x1002116e8		f94127e0		MOVD 584(RSP), R0									
  execution.go:786	0x1002116ec		97fff5dd		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:786	0x1002116f0		f94093e1		MOVD 288(RSP), R1									
  execution.go:786	0x1002116f4		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:786	0x1002116f8		910903ff		ADD $576, RSP, RSP									
  execution.go:786	0x1002116fc		d65f03c0		RET											
  execution.go:778	0x100211700		f94127e0		MOVD 584(RSP), R0									
  execution.go:778	0x100211704		aa0303e1		MOVD R3, R1										
  execution.go:778	0x100211708		aa0403e2		MOVD R4, R2										
  execution.go:778	0x10021170c		97fff5d5		CALL github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).fail(SB)		
  execution.go:778	0x100211710		f94093e1		MOVD 288(RSP), R1									
  execution.go:778	0x100211714		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:778	0x100211718		910903ff		ADD $576, RSP, RSP									
  execution.go:778	0x10021171c		d65f03c0		RET											
  execution.go:631	0x100211720		f94093e1		MOVD 288(RSP), R1									
  execution.go:631	0x100211724		a97ffbfd		LDP -8(RSP), (R29, R30)									
  execution.go:631	0x100211728		910903ff		ADD $576, RSP, RSP									
  execution.go:631	0x10021172c		d65f03c0		RET											
  execution.go:786	0x100211730		97f9c784		CALL runtime.panicBounds(SB)								
  execution.go:790	0x100211734		aa1403e0		MOVD R20, R0										
  execution.go:790	0x100211738		aa1303e1		MOVD R19, R1										
  execution.go:790	0x10021173c		97f9c781		CALL runtime.panicBounds(SB)								
  execution.go:774	0x100211740		aa1803e0		MOVD R24, R0										
  execution.go:774	0x100211744		aa1603e1		MOVD R22, R1										
  execution.go:774	0x100211748		97f9c77e		CALL runtime.panicBounds(SB)								
  execution.go:781	0x10021174c		f0001160		ADRP 2289664(PC), R0									
  execution.go:781	0x100211750		9126c000		ADD $2480, R0, R0									
  execution.go:781	0x100211754		f0000f81		ADRP 2043904(PC), R1									
  execution.go:781	0x100211758		91294021		ADD $2640, R1, R1									
  execution.go:781	0x10021175c		97f9ac0d		CALL runtime.gopanic(SB)								
  execution.go:769	0x100211760		aa1e03e0		MOVD R30, R0										
  execution.go:769	0x100211764		aa1903e1		MOVD R25, R1										
  execution.go:769	0x100211768		97f9c776		CALL runtime.panicBounds(SB)								
  execution.go:767	0x10021176c		aa1a03e0		MOVD R26, R0										
  execution.go:767	0x100211770		aa1803e1		MOVD R24, R1										
  execution.go:767	0x100211774		97f9c773		CALL runtime.panicBounds(SB)								
  execution.go:758	0x100211778		aa1603e0		MOVD R22, R0										
  execution.go:758	0x10021177c		aa1303e1		MOVD R19, R1										
  execution.go:758	0x100211780		97f9c770		CALL runtime.panicBounds(SB)								
  execution.go:755	0x100211784		aa1603e0		MOVD R22, R0										
  execution.go:755	0x100211788		aa1303e1		MOVD R19, R1										
  execution.go:755	0x10021178c		97f9c76d		CALL runtime.panicBounds(SB)								
  execution.go:752	0x100211790		aa1603e0		MOVD R22, R0										
  execution.go:752	0x100211794		aa1303e1		MOVD R19, R1										
  execution.go:752	0x100211798		97f9c76a		CALL runtime.panicBounds(SB)								
  execution.go:658	0x10021179c		8b181198		ADD R24<<4, R12, R24									
  execution.go:658	0x1002117a0		a9006b19		STP (R25, R26), (R24)									
  execution.go:657	0x1002117a4		910006f7		ADD $1, R23, R23									
  execution.go:657	0x1002117a8		eb1402ff		CMP R20, R23										
  execution.go:657	0x1002117ac		5400014a		BGE 10(PC)										
  execution.go:657	0x1002117b0		8b170e38		ADD R23<<3, R17, R24									
  execution.go:657	0x1002117b4		29406718		LDPW (R24), (R24, R25)									
  execution.go:658	0x1002117b8		eb13033f		CMP R19, R25										
  execution.go:658	0x1002117bc		54000162		BCS 11(PC)										
  execution.go:658	0x1002117c0		8b191199		ADD R25<<4, R12, R25									
  execution.go:658	0x1002117c4		a9406b39		LDP (R25), (R25, R26)									
  execution.go:658	0x1002117c8		eb13031f		CMP R19, R24										
  execution.go:658	0x1002117cc		54fffe83		BCC -12(PC)										
  execution.go:658	0x1002117d0		14000003		JMP 3(PC)										
  execution.go:460	0x1002117d4		aa1603f1		MOVD R22, R17										
  execution.go:661	0x1002117d8		17fff83b		JMP -1989(PC)										
  execution.go:658	0x1002117dc		aa1803e0		MOVD R24, R0										
  execution.go:658	0x1002117e0		aa1303e1		MOVD R19, R1										
  execution.go:658	0x1002117e4		97f9c757		CALL runtime.panicBounds(SB)								
  execution.go:658	0x1002117e8		aa1903e0		MOVD R25, R0										
  execution.go:658	0x1002117ec		aa1303e1		MOVD R19, R1										
  execution.go:658	0x1002117f0		97f9c754		CALL runtime.panicBounds(SB)								
  execution.go:657	0x1002117f4		aa1403e0		MOVD R20, R0										
  execution.go:657	0x1002117f8		aa1703e1		MOVD R23, R1										
  execution.go:657	0x1002117fc		97f9c751		CALL runtime.panicBounds(SB)								
  execution.go:657	0x100211800		aa1703e0		MOVD R23, R0										
  execution.go:657	0x100211804		aa1103e1		MOVD R17, R1										
  execution.go:657	0x100211808		97f9c74e		CALL runtime.panicBounds(SB)								
  execution.go:651	0x10021180c		aa1603e0		MOVD R22, R0										
  execution.go:651	0x100211810		aa1803e1		MOVD R24, R1										
  execution.go:651	0x100211814		97f9c74b		CALL runtime.panicBounds(SB)								
  execution.go:646	0x100211818		aa1703e0		MOVD R23, R0										
  execution.go:646	0x10021181c		aa1303e1		MOVD R19, R1										
  execution.go:646	0x100211820		97f9c748		CALL runtime.panicBounds(SB)								
  execution.go:643	0x100211824		aa1803e0		MOVD R24, R0										
  execution.go:643	0x100211828		aa1303e1		MOVD R19, R1										
  execution.go:643	0x10021182c		97f9c745		CALL runtime.panicBounds(SB)								
  execution.go:641	0x100211830		aa1803e0		MOVD R24, R0										
  execution.go:641	0x100211834		aa1303e1		MOVD R19, R1										
  execution.go:641	0x100211838		97f9c742		CALL runtime.panicBounds(SB)								
  execution.go:725	0x10021183c		aa1303e0		MOVD R19, R0										
  execution.go:725	0x100211840		97f9c740		CALL runtime.panicBounds(SB)								
  execution.go:732	0x100211844		aa1603e0		MOVD R22, R0										
  execution.go:732	0x100211848		aa1303e1		MOVD R19, R1										
  execution.go:732	0x10021184c		97f9c73d		CALL runtime.panicBounds(SB)								
  execution.go:727	0x100211850		aa1703e0		MOVD R23, R0										
  execution.go:727	0x100211854		aa1303e1		MOVD R19, R1										
  execution.go:727	0x100211858		97f9c73a		CALL runtime.panicBounds(SB)								
  execution.go:727	0x10021185c		aa1603e0		MOVD R22, R0										
  execution.go:727	0x100211860		aa1303e1		MOVD R19, R1										
  execution.go:727	0x100211864		97f9c737		CALL runtime.panicBounds(SB)								
  execution.go:742	0x100211868		aa1803e0		MOVD R24, R0										
  execution.go:742	0x10021186c		aa1703e1		MOVD R23, R1										
  execution.go:742	0x100211870		97f9c734		CALL runtime.panicBounds(SB)								
  execution.go:738	0x100211874		aa1603e0		MOVD R22, R0										
  execution.go:738	0x100211878		aa1303e1		MOVD R19, R1										
  execution.go:738	0x10021187c		97f9c731		CALL runtime.panicBounds(SB)								
  execution.go:710	0x100211880		97f9c730		CALL runtime.panicBounds(SB)								
  execution.go:713	0x100211884		aa1303e0		MOVD R19, R0										
  execution.go:713	0x100211888		97f9c72e		CALL runtime.panicBounds(SB)								
  execution.go:712	0x10021188c		97f9c72d		CALL runtime.panicBounds(SB)								
  execution.go:708	0x100211890		aa1603e0		MOVD R22, R0										
  execution.go:708	0x100211894		aa1303e1		MOVD R19, R1										
  execution.go:708	0x100211898		97f9c72a		CALL runtime.panicBounds(SB)								
  execution.go:708	0x10021189c		aa1703e0		MOVD R23, R0										
  execution.go:708	0x1002118a0		97f9c728		CALL runtime.panicBounds(SB)								
  execution.go:708	0x1002118a4		aa1303e0		MOVD R19, R0										
  execution.go:708	0x1002118a8		97f9c726		CALL runtime.panicBounds(SB)								
  execution.go:707	0x1002118ac		aa1703e0		MOVD R23, R0										
  execution.go:707	0x1002118b0		97f9c724		CALL runtime.panicBounds(SB)								
  execution.go:704	0x1002118b4		aa1303e0		MOVD R19, R0										
  execution.go:704	0x1002118b8		97f9c722		CALL runtime.panicBounds(SB)								
  execution.go:704	0x1002118bc		aa1803e0		MOVD R24, R0										
  execution.go:704	0x1002118c0		aa1603e1		MOVD R22, R1										
  execution.go:704	0x1002118c4		97f9c71f		CALL runtime.panicBounds(SB)								
  execution.go:703	0x1002118c8		aa1703e0		MOVD R23, R0										
  execution.go:703	0x1002118cc		97f9c71d		CALL runtime.panicBounds(SB)								
  execution.go:699	0x1002118d0		aa1803e0		MOVD R24, R0										
  execution.go:699	0x1002118d4		aa1303e1		MOVD R19, R1										
  execution.go:699	0x1002118d8		97f9c71a		CALL runtime.panicBounds(SB)								
  execution.go:695	0x1002118dc		aa1703e0		MOVD R23, R0										
  execution.go:695	0x1002118e0		aa1303e1		MOVD R19, R1										
  execution.go:695	0x1002118e4		97f9c717		CALL runtime.panicBounds(SB)								
  execution.go:694	0x1002118e8		aa1803e0		MOVD R24, R0										
  execution.go:694	0x1002118ec		aa1703e1		MOVD R23, R1										
  execution.go:694	0x1002118f0		97f9c714		CALL runtime.panicBounds(SB)								
  execution.go:687	0x1002118f4		aa1703e0		MOVD R23, R0										
  execution.go:687	0x1002118f8		aa1303e1		MOVD R19, R1										
  execution.go:687	0x1002118fc		97f9c711		CALL runtime.panicBounds(SB)								
  execution.go:686	0x100211900		aa1803e0		MOVD R24, R0										
  execution.go:686	0x100211904		aa1703e1		MOVD R23, R1										
  execution.go:686	0x100211908		97f9c70e		CALL runtime.panicBounds(SB)								
  execution.go:684	0x10021190c		aa1903e0		MOVD R25, R0										
  execution.go:684	0x100211910		aa1803e1		MOVD R24, R1										
  execution.go:684	0x100211914		97f9c70b		CALL runtime.panicBounds(SB)								
  execution.go:684	0x100211918		aa1603e0		MOVD R22, R0										
  execution.go:684	0x10021191c		aa1303e1		MOVD R19, R1										
  execution.go:684	0x100211920		97f9c708		CALL runtime.panicBounds(SB)								
  execution.go:682	0x100211924		aa1803e0		MOVD R24, R0										
  execution.go:682	0x100211928		aa1703e1		MOVD R23, R1										
  execution.go:682	0x10021192c		97f9c705		CALL runtime.panicBounds(SB)								
  execution.go:680	0x100211930		aa1803e0		MOVD R24, R0										
  execution.go:680	0x100211934		aa1303e1		MOVD R19, R1										
  execution.go:680	0x100211938		97f9c702		CALL runtime.panicBounds(SB)								
  execution.go:679	0x10021193c		aa1603e0		MOVD R22, R0										
  execution.go:679	0x100211940		aa1303e1		MOVD R19, R1										
  execution.go:679	0x100211944		97f9c6ff		CALL runtime.panicBounds(SB)								
  execution.go:677	0x100211948		aa1603e0		MOVD R22, R0										
  execution.go:677	0x10021194c		aa1303e1		MOVD R19, R1										
  execution.go:677	0x100211950		97f9c6fc		CALL runtime.panicBounds(SB)								
  execution.go:675	0x100211954		aa1603e0		MOVD R22, R0										
  execution.go:675	0x100211958		aa1303e1		MOVD R19, R1										
  execution.go:675	0x10021195c		97f9c6f9		CALL runtime.panicBounds(SB)								
  execution.go:672	0x100211960		aa1703e0		MOVD R23, R0										
  execution.go:672	0x100211964		aa1303e1		MOVD R19, R1										
  execution.go:672	0x100211968		97f9c6f6		CALL runtime.panicBounds(SB)								
  execution.go:600	0x10021196c		aa1603e0		MOVD R22, R0										
  execution.go:600	0x100211970		aa1303e1		MOVD R19, R1										
  execution.go:600	0x100211974		97f9c6f3		CALL runtime.panicBounds(SB)								
  execution.go:598	0x100211978		aa1603e0		MOVD R22, R0										
  execution.go:598	0x10021197c		aa1303e1		MOVD R19, R1										
  execution.go:598	0x100211980		97f9c6f0		CALL runtime.panicBounds(SB)								
  execution.go:596	0x100211984		aa1603e0		MOVD R22, R0										
  execution.go:596	0x100211988		aa1303e1		MOVD R19, R1										
  execution.go:596	0x10021198c		97f9c6ed		CALL runtime.panicBounds(SB)								
  execution.go:594	0x100211990		aa1603e0		MOVD R22, R0										
  execution.go:594	0x100211994		aa1303e1		MOVD R19, R1										
  execution.go:594	0x100211998		97f9c6ea		CALL runtime.panicBounds(SB)								
  execution.go:592	0x10021199c		aa1603e0		MOVD R22, R0										
  execution.go:592	0x1002119a0		aa1303e1		MOVD R19, R1										
  execution.go:592	0x1002119a4		97f9c6e7		CALL runtime.panicBounds(SB)								
  execution.go:614	0x1002119a8		aa1303e0		MOVD R19, R0										
  execution.go:614	0x1002119ac		97f9c6e5		CALL runtime.panicBounds(SB)								
  execution.go:612	0x1002119b0		aa1303e0		MOVD R19, R0										
  execution.go:612	0x1002119b4		97f9c6e3		CALL runtime.panicBounds(SB)								
  execution.go:590	0x1002119b8		aa1603e0		MOVD R22, R0										
  execution.go:590	0x1002119bc		aa1303e1		MOVD R19, R1										
  execution.go:590	0x1002119c0		97f9c6e0		CALL runtime.panicBounds(SB)								
  execution.go:588	0x1002119c4		aa1603e0		MOVD R22, R0										
  execution.go:588	0x1002119c8		aa1303e1		MOVD R19, R1										
  execution.go:588	0x1002119cc		97f9c6dd		CALL runtime.panicBounds(SB)								
  execution.go:586	0x1002119d0		aa1603e0		MOVD R22, R0										
  execution.go:586	0x1002119d4		aa1303e1		MOVD R19, R1										
  execution.go:586	0x1002119d8		97f9c6da		CALL runtime.panicBounds(SB)								
  execution.go:584	0x1002119dc		aa1703e0		MOVD R23, R0										
  execution.go:584	0x1002119e0		aa1303e1		MOVD R19, R1										
  execution.go:584	0x1002119e4		97f9c6d7		CALL runtime.panicBounds(SB)								
  execution.go:584	0x1002119e8		aa1603e0		MOVD R22, R0										
  execution.go:584	0x1002119ec		aa1303e1		MOVD R19, R1										
  execution.go:584	0x1002119f0		97f9c6d4		CALL runtime.panicBounds(SB)								
  execution.go:582	0x1002119f4		aa1703e0		MOVD R23, R0										
  execution.go:582	0x1002119f8		aa1303e1		MOVD R19, R1										
  execution.go:582	0x1002119fc		97f9c6d1		CALL runtime.panicBounds(SB)								
  execution.go:582	0x100211a00		aa1603e0		MOVD R22, R0										
  execution.go:582	0x100211a04		aa1303e1		MOVD R19, R1										
  execution.go:582	0x100211a08		97f9c6ce		CALL runtime.panicBounds(SB)								
  execution.go:580	0x100211a0c		aa1703e0		MOVD R23, R0										
  execution.go:580	0x100211a10		aa1303e1		MOVD R19, R1										
  execution.go:580	0x100211a14		97f9c6cb		CALL runtime.panicBounds(SB)								
  execution.go:580	0x100211a18		aa1603e0		MOVD R22, R0										
  execution.go:580	0x100211a1c		aa1303e1		MOVD R19, R1										
  execution.go:580	0x100211a20		97f9c6c8		CALL runtime.panicBounds(SB)								
  execution.go:578	0x100211a24		aa1703e0		MOVD R23, R0										
  execution.go:578	0x100211a28		aa1303e1		MOVD R19, R1										
  execution.go:578	0x100211a2c		97f9c6c5		CALL runtime.panicBounds(SB)								
  execution.go:578	0x100211a30		aa1603e0		MOVD R22, R0										
  execution.go:578	0x100211a34		aa1303e1		MOVD R19, R1										
  execution.go:578	0x100211a38		97f9c6c2		CALL runtime.panicBounds(SB)								
  execution.go:576	0x100211a3c		aa1703e0		MOVD R23, R0										
  execution.go:576	0x100211a40		aa1303e1		MOVD R19, R1										
  execution.go:576	0x100211a44		97f9c6bf		CALL runtime.panicBounds(SB)								
  execution.go:576	0x100211a48		aa1603e0		MOVD R22, R0										
  execution.go:576	0x100211a4c		aa1303e1		MOVD R19, R1										
  execution.go:576	0x100211a50		97f9c6bc		CALL runtime.panicBounds(SB)								
  execution.go:574	0x100211a54		aa1703e0		MOVD R23, R0										
  execution.go:574	0x100211a58		aa1303e1		MOVD R19, R1										
  execution.go:574	0x100211a5c		97f9c6b9		CALL runtime.panicBounds(SB)								
  execution.go:574	0x100211a60		aa1603e0		MOVD R22, R0										
  execution.go:574	0x100211a64		aa1303e1		MOVD R19, R1										
  execution.go:574	0x100211a68		97f9c6b6		CALL runtime.panicBounds(SB)								
  execution.go:572	0x100211a6c		aa1703e0		MOVD R23, R0										
  execution.go:572	0x100211a70		aa1303e1		MOVD R19, R1										
  execution.go:572	0x100211a74		97f9c6b3		CALL runtime.panicBounds(SB)								
  execution.go:572	0x100211a78		aa1603e0		MOVD R22, R0										
  execution.go:572	0x100211a7c		aa1303e1		MOVD R19, R1										
  execution.go:572	0x100211a80		97f9c6b0		CALL runtime.panicBounds(SB)								
  execution.go:570	0x100211a84		aa1703e0		MOVD R23, R0										
  execution.go:570	0x100211a88		aa1303e1		MOVD R19, R1										
  execution.go:570	0x100211a8c		97f9c6ad		CALL runtime.panicBounds(SB)								
  execution.go:570	0x100211a90		aa1603e0		MOVD R22, R0										
  execution.go:570	0x100211a94		aa1303e1		MOVD R19, R1										
  execution.go:570	0x100211a98		97f9c6aa		CALL runtime.panicBounds(SB)								
  execution.go:568	0x100211a9c		aa1703e0		MOVD R23, R0										
  execution.go:568	0x100211aa0		aa1303e1		MOVD R19, R1										
  execution.go:568	0x100211aa4		97f9c6a7		CALL runtime.panicBounds(SB)								
  execution.go:568	0x100211aa8		aa1603e0		MOVD R22, R0										
  execution.go:568	0x100211aac		aa1303e1		MOVD R19, R1										
  execution.go:568	0x100211ab0		97f9c6a4		CALL runtime.panicBounds(SB)								
  execution.go:566	0x100211ab4		aa1703e0		MOVD R23, R0										
  execution.go:566	0x100211ab8		aa1303e1		MOVD R19, R1										
  execution.go:566	0x100211abc		97f9c6a1		CALL runtime.panicBounds(SB)								
  execution.go:566	0x100211ac0		aa1603e0		MOVD R22, R0										
  execution.go:566	0x100211ac4		aa1303e1		MOVD R19, R1										
  execution.go:566	0x100211ac8		97f9c69e		CALL runtime.panicBounds(SB)								
  execution.go:564	0x100211acc		aa1703e0		MOVD R23, R0										
  execution.go:564	0x100211ad0		aa1303e1		MOVD R19, R1										
  execution.go:564	0x100211ad4		97f9c69b		CALL runtime.panicBounds(SB)								
  execution.go:564	0x100211ad8		aa1603e0		MOVD R22, R0										
  execution.go:564	0x100211adc		aa1303e1		MOVD R19, R1										
  execution.go:564	0x100211ae0		97f9c698		CALL runtime.panicBounds(SB)								
  execution.go:532	0x100211ae4		aa1603e0		MOVD R22, R0										
  execution.go:532	0x100211ae8		aa1303e1		MOVD R19, R1										
  execution.go:532	0x100211aec		97f9c695		CALL runtime.panicBounds(SB)								
  execution.go:562	0x100211af0		aa1603e0		MOVD R22, R0										
  execution.go:562	0x100211af4		aa1303e1		MOVD R19, R1										
  execution.go:562	0x100211af8		97f9c692		CALL runtime.panicBounds(SB)								
  execution.go:560	0x100211afc		aa1603e0		MOVD R22, R0										
  execution.go:560	0x100211b00		aa1303e1		MOVD R19, R1										
  execution.go:560	0x100211b04		97f9c68f		CALL runtime.panicBounds(SB)								
  execution.go:558	0x100211b08		aa1703e0		MOVD R23, R0										
  execution.go:558	0x100211b0c		aa1303e1		MOVD R19, R1										
  execution.go:558	0x100211b10		97f9c68c		CALL runtime.panicBounds(SB)								
  execution.go:558	0x100211b14		aa1603e0		MOVD R22, R0										
  execution.go:558	0x100211b18		aa1303e1		MOVD R19, R1										
  execution.go:558	0x100211b1c		97f9c689		CALL runtime.panicBounds(SB)								
  execution.go:556	0x100211b20		aa1703e0		MOVD R23, R0										
  execution.go:556	0x100211b24		aa1303e1		MOVD R19, R1										
  execution.go:556	0x100211b28		97f9c686		CALL runtime.panicBounds(SB)								
  execution.go:556	0x100211b2c		aa1603e0		MOVD R22, R0										
  execution.go:556	0x100211b30		aa1303e1		MOVD R19, R1										
  execution.go:556	0x100211b34		97f9c683		CALL runtime.panicBounds(SB)								
  execution.go:554	0x100211b38		aa1703e0		MOVD R23, R0										
  execution.go:554	0x100211b3c		aa1303e1		MOVD R19, R1										
  execution.go:554	0x100211b40		97f9c680		CALL runtime.panicBounds(SB)								
  execution.go:554	0x100211b44		aa1603e0		MOVD R22, R0										
  execution.go:554	0x100211b48		aa1303e1		MOVD R19, R1										
  execution.go:554	0x100211b4c		97f9c67d		CALL runtime.panicBounds(SB)								
  execution.go:552	0x100211b50		aa1703e0		MOVD R23, R0										
  execution.go:552	0x100211b54		aa1303e1		MOVD R19, R1										
  execution.go:552	0x100211b58		97f9c67a		CALL runtime.panicBounds(SB)								
  execution.go:552	0x100211b5c		aa1603e0		MOVD R22, R0										
  execution.go:552	0x100211b60		aa1303e1		MOVD R19, R1										
  execution.go:552	0x100211b64		97f9c677		CALL runtime.panicBounds(SB)								
  execution.go:550	0x100211b68		aa1703e0		MOVD R23, R0										
  execution.go:550	0x100211b6c		aa1303e1		MOVD R19, R1										
  execution.go:550	0x100211b70		97f9c674		CALL runtime.panicBounds(SB)								
  execution.go:550	0x100211b74		aa1603e0		MOVD R22, R0										
  execution.go:550	0x100211b78		aa1303e1		MOVD R19, R1										
  execution.go:550	0x100211b7c		97f9c671		CALL runtime.panicBounds(SB)								
  execution.go:548	0x100211b80		aa1703e0		MOVD R23, R0										
  execution.go:548	0x100211b84		aa1303e1		MOVD R19, R1										
  execution.go:548	0x100211b88		97f9c66e		CALL runtime.panicBounds(SB)								
  execution.go:548	0x100211b8c		aa1603e0		MOVD R22, R0										
  execution.go:548	0x100211b90		aa1303e1		MOVD R19, R1										
  execution.go:548	0x100211b94		97f9c66b		CALL runtime.panicBounds(SB)								
  execution.go:546	0x100211b98		aa1703e0		MOVD R23, R0										
  execution.go:546	0x100211b9c		aa1303e1		MOVD R19, R1										
  execution.go:546	0x100211ba0		97f9c668		CALL runtime.panicBounds(SB)								
  execution.go:546	0x100211ba4		aa1603e0		MOVD R22, R0										
  execution.go:546	0x100211ba8		aa1303e1		MOVD R19, R1										
  execution.go:546	0x100211bac		97f9c665		CALL runtime.panicBounds(SB)								
  execution.go:544	0x100211bb0		aa1703e0		MOVD R23, R0										
  execution.go:544	0x100211bb4		aa1303e1		MOVD R19, R1										
  execution.go:544	0x100211bb8		97f9c662		CALL runtime.panicBounds(SB)								
  execution.go:544	0x100211bbc		aa1603e0		MOVD R22, R0										
  execution.go:544	0x100211bc0		aa1303e1		MOVD R19, R1										
  execution.go:544	0x100211bc4		97f9c65f		CALL runtime.panicBounds(SB)								
  execution.go:542	0x100211bc8		aa1703e0		MOVD R23, R0										
  execution.go:542	0x100211bcc		aa1303e1		MOVD R19, R1										
  execution.go:542	0x100211bd0		97f9c65c		CALL runtime.panicBounds(SB)								
  execution.go:542	0x100211bd4		aa1603e0		MOVD R22, R0										
  execution.go:542	0x100211bd8		aa1303e1		MOVD R19, R1										
  execution.go:542	0x100211bdc		97f9c659		CALL runtime.panicBounds(SB)								
  execution.go:540	0x100211be0		aa1703e0		MOVD R23, R0										
  execution.go:540	0x100211be4		aa1303e1		MOVD R19, R1										
  execution.go:540	0x100211be8		97f9c656		CALL runtime.panicBounds(SB)								
  execution.go:540	0x100211bec		aa1603e0		MOVD R22, R0										
  execution.go:540	0x100211bf0		aa1303e1		MOVD R19, R1										
  execution.go:540	0x100211bf4		97f9c653		CALL runtime.panicBounds(SB)								
  execution.go:538	0x100211bf8		aa1703e0		MOVD R23, R0										
  execution.go:538	0x100211bfc		aa1303e1		MOVD R19, R1										
  execution.go:538	0x100211c00		97f9c650		CALL runtime.panicBounds(SB)								
  execution.go:538	0x100211c04		aa1603e0		MOVD R22, R0										
  execution.go:538	0x100211c08		aa1303e1		MOVD R19, R1										
  execution.go:538	0x100211c0c		97f9c64d		CALL runtime.panicBounds(SB)								
  execution.go:528	0x100211c10		aa1603e0		MOVD R22, R0										
  execution.go:528	0x100211c14		aa1303e1		MOVD R19, R1										
  execution.go:528	0x100211c18		97f9c64a		CALL runtime.panicBounds(SB)								
  execution.go:526	0x100211c1c		aa1603e0		MOVD R22, R0										
  execution.go:526	0x100211c20		aa1303e1		MOVD R19, R1										
  execution.go:526	0x100211c24		97f9c647		CALL runtime.panicBounds(SB)								
  execution.go:524	0x100211c28		aa1703e0		MOVD R23, R0										
  execution.go:524	0x100211c2c		aa1303e1		MOVD R19, R1										
  execution.go:524	0x100211c30		97f9c644		CALL runtime.panicBounds(SB)								
  execution.go:524	0x100211c34		aa1603e0		MOVD R22, R0										
  execution.go:524	0x100211c38		aa1303e1		MOVD R19, R1										
  execution.go:524	0x100211c3c		97f9c641		CALL runtime.panicBounds(SB)								
  execution.go:522	0x100211c40		aa1703e0		MOVD R23, R0										
  execution.go:522	0x100211c44		aa1303e1		MOVD R19, R1										
  execution.go:522	0x100211c48		97f9c63e		CALL runtime.panicBounds(SB)								
  execution.go:522	0x100211c4c		aa1603e0		MOVD R22, R0										
  execution.go:522	0x100211c50		aa1303e1		MOVD R19, R1										
  execution.go:522	0x100211c54		97f9c63b		CALL runtime.panicBounds(SB)								
  execution.go:520	0x100211c58		aa1703e0		MOVD R23, R0										
  execution.go:520	0x100211c5c		aa1303e1		MOVD R19, R1										
  execution.go:520	0x100211c60		97f9c638		CALL runtime.panicBounds(SB)								
  execution.go:520	0x100211c64		aa1603e0		MOVD R22, R0										
  execution.go:520	0x100211c68		aa1303e1		MOVD R19, R1										
  execution.go:520	0x100211c6c		97f9c635		CALL runtime.panicBounds(SB)								
  execution.go:518	0x100211c70		aa1703e0		MOVD R23, R0										
  execution.go:518	0x100211c74		aa1303e1		MOVD R19, R1										
  execution.go:518	0x100211c78		97f9c632		CALL runtime.panicBounds(SB)								
  execution.go:518	0x100211c7c		aa1603e0		MOVD R22, R0										
  execution.go:518	0x100211c80		aa1303e1		MOVD R19, R1										
  execution.go:518	0x100211c84		97f9c62f		CALL runtime.panicBounds(SB)								
  execution.go:516	0x100211c88		aa1703e0		MOVD R23, R0										
  execution.go:516	0x100211c8c		aa1303e1		MOVD R19, R1										
  execution.go:516	0x100211c90		97f9c62c		CALL runtime.panicBounds(SB)								
  execution.go:516	0x100211c94		aa1603e0		MOVD R22, R0										
  execution.go:516	0x100211c98		aa1303e1		MOVD R19, R1										
  execution.go:516	0x100211c9c		97f9c629		CALL runtime.panicBounds(SB)								
  execution.go:514	0x100211ca0		aa1703e0		MOVD R23, R0										
  execution.go:514	0x100211ca4		aa1303e1		MOVD R19, R1										
  execution.go:514	0x100211ca8		97f9c626		CALL runtime.panicBounds(SB)								
  execution.go:514	0x100211cac		aa1603e0		MOVD R22, R0										
  execution.go:514	0x100211cb0		aa1303e1		MOVD R19, R1										
  execution.go:514	0x100211cb4		97f9c623		CALL runtime.panicBounds(SB)								
  execution.go:512	0x100211cb8		aa1703e0		MOVD R23, R0										
  execution.go:512	0x100211cbc		aa1303e1		MOVD R19, R1										
  execution.go:512	0x100211cc0		97f9c620		CALL runtime.panicBounds(SB)								
  execution.go:512	0x100211cc4		aa1603e0		MOVD R22, R0										
  execution.go:512	0x100211cc8		aa1303e1		MOVD R19, R1										
  execution.go:512	0x100211ccc		97f9c61d		CALL runtime.panicBounds(SB)								
  execution.go:510	0x100211cd0		aa1703e0		MOVD R23, R0										
  execution.go:510	0x100211cd4		aa1303e1		MOVD R19, R1										
  execution.go:510	0x100211cd8		97f9c61a		CALL runtime.panicBounds(SB)								
  execution.go:510	0x100211cdc		aa1603e0		MOVD R22, R0										
  execution.go:510	0x100211ce0		aa1303e1		MOVD R19, R1										
  execution.go:510	0x100211ce4		97f9c617		CALL runtime.panicBounds(SB)								
  execution.go:508	0x100211ce8		aa1703e0		MOVD R23, R0										
  execution.go:508	0x100211cec		aa1303e1		MOVD R19, R1										
  execution.go:508	0x100211cf0		97f9c614		CALL runtime.panicBounds(SB)								
  execution.go:508	0x100211cf4		aa1603e0		MOVD R22, R0										
  execution.go:508	0x100211cf8		aa1303e1		MOVD R19, R1										
  execution.go:508	0x100211cfc		97f9c611		CALL runtime.panicBounds(SB)								
  execution.go:506	0x100211d00		aa1703e0		MOVD R23, R0										
  execution.go:506	0x100211d04		aa1303e1		MOVD R19, R1										
  execution.go:506	0x100211d08		97f9c60e		CALL runtime.panicBounds(SB)								
  execution.go:506	0x100211d0c		aa1603e0		MOVD R22, R0										
  execution.go:506	0x100211d10		aa1303e1		MOVD R19, R1										
  execution.go:506	0x100211d14		97f9c60b		CALL runtime.panicBounds(SB)								
  execution.go:504	0x100211d18		aa1603e0		MOVD R22, R0										
  execution.go:504	0x100211d1c		aa1303e1		MOVD R19, R1										
  execution.go:504	0x100211d20		97f9c608		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100211d24		aa1703e0		MOVD R23, R0										
  execution.go:502	0x100211d28		aa1303e1		MOVD R19, R1										
  execution.go:502	0x100211d2c		97f9c605		CALL runtime.panicBounds(SB)								
  execution.go:502	0x100211d30		aa1603e0		MOVD R22, R0										
  execution.go:502	0x100211d34		aa1303e1		MOVD R19, R1										
  execution.go:502	0x100211d38		97f9c602		CALL runtime.panicBounds(SB)								
  execution.go:500	0x100211d3c		aa1703e0		MOVD R23, R0										
  execution.go:500	0x100211d40		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100211d44		97f9c5ff		CALL runtime.panicBounds(SB)								
  execution.go:500	0x100211d48		aa1603e0		MOVD R22, R0										
  execution.go:500	0x100211d4c		aa1303e1		MOVD R19, R1										
  execution.go:500	0x100211d50		97f9c5fc		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100211d54		aa1703e0		MOVD R23, R0										
  execution.go:498	0x100211d58		aa1303e1		MOVD R19, R1										
  execution.go:498	0x100211d5c		97f9c5f9		CALL runtime.panicBounds(SB)								
  execution.go:498	0x100211d60		aa1603e0		MOVD R22, R0										
  execution.go:498	0x100211d64		aa1303e1		MOVD R19, R1										
  execution.go:498	0x100211d68		97f9c5f6		CALL runtime.panicBounds(SB)								
  execution.go:496	0x100211d6c		aa1703e0		MOVD R23, R0										
  execution.go:496	0x100211d70		aa1303e1		MOVD R19, R1										
  execution.go:496	0x100211d74		97f9c5f3		CALL runtime.panicBounds(SB)								
  execution.go:496	0x100211d78		aa1603e0		MOVD R22, R0										
  execution.go:496	0x100211d7c		aa1303e1		MOVD R19, R1										
  execution.go:496	0x100211d80		97f9c5f0		CALL runtime.panicBounds(SB)								
  execution.go:494	0x100211d84		aa1703e0		MOVD R23, R0										
  execution.go:494	0x100211d88		aa1303e1		MOVD R19, R1										
  execution.go:494	0x100211d8c		97f9c5ed		CALL runtime.panicBounds(SB)								
  execution.go:494	0x100211d90		aa1603e0		MOVD R22, R0										
  execution.go:494	0x100211d94		aa1303e1		MOVD R19, R1										
  execution.go:494	0x100211d98		97f9c5ea		CALL runtime.panicBounds(SB)								
  execution.go:492	0x100211d9c		aa1703e0		MOVD R23, R0										
  execution.go:492	0x100211da0		aa1303e1		MOVD R19, R1										
  execution.go:492	0x100211da4		97f9c5e7		CALL runtime.panicBounds(SB)								
  execution.go:492	0x100211da8		aa1603e0		MOVD R22, R0										
  execution.go:492	0x100211dac		aa1303e1		MOVD R19, R1										
  execution.go:492	0x100211db0		97f9c5e4		CALL runtime.panicBounds(SB)								
  execution.go:490	0x100211db4		aa1703e0		MOVD R23, R0										
  execution.go:490	0x100211db8		aa1303e1		MOVD R19, R1										
  execution.go:490	0x100211dbc		97f9c5e1		CALL runtime.panicBounds(SB)								
  execution.go:490	0x100211dc0		aa1603e0		MOVD R22, R0										
  execution.go:490	0x100211dc4		aa1303e1		MOVD R19, R1										
  execution.go:490	0x100211dc8		97f9c5de		CALL runtime.panicBounds(SB)								
  execution.go:488	0x100211dcc		aa1703e0		MOVD R23, R0										
  execution.go:488	0x100211dd0		aa1303e1		MOVD R19, R1										
  execution.go:488	0x100211dd4		97f9c5db		CALL runtime.panicBounds(SB)								
  execution.go:488	0x100211dd8		aa1603e0		MOVD R22, R0										
  execution.go:488	0x100211ddc		aa1303e1		MOVD R19, R1										
  execution.go:488	0x100211de0		97f9c5d8		CALL runtime.panicBounds(SB)								
  execution.go:486	0x100211de4		aa1703e0		MOVD R23, R0										
  execution.go:486	0x100211de8		aa1303e1		MOVD R19, R1										
  execution.go:486	0x100211dec		97f9c5d5		CALL runtime.panicBounds(SB)								
  execution.go:486	0x100211df0		aa1603e0		MOVD R22, R0										
  execution.go:486	0x100211df4		aa1303e1		MOVD R19, R1										
  execution.go:486	0x100211df8		97f9c5d2		CALL runtime.panicBounds(SB)								
  execution.go:484	0x100211dfc		aa1703e0		MOVD R23, R0										
  execution.go:484	0x100211e00		aa1303e1		MOVD R19, R1										
  execution.go:484	0x100211e04		97f9c5cf		CALL runtime.panicBounds(SB)								
  execution.go:484	0x100211e08		aa1603e0		MOVD R22, R0										
  execution.go:484	0x100211e0c		aa1303e1		MOVD R19, R1										
  execution.go:484	0x100211e10		97f9c5cc		CALL runtime.panicBounds(SB)								
  execution.go:482	0x100211e14		aa1603e0		MOVD R22, R0										
  execution.go:482	0x100211e18		aa1303e1		MOVD R19, R1										
  execution.go:482	0x100211e1c		97f9c5c9		CALL runtime.panicBounds(SB)								
  execution.go:421	0x100211e20		97f9c5c8		CALL runtime.panicBounds(SB)								
  execution.go:412	0x100211e24		aa1903e0		MOVD R25, R0										
  execution.go:412	0x100211e28		aa1703e1		MOVD R23, R1										
  execution.go:412	0x100211e2c		97f9c5c5		CALL runtime.panicBounds(SB)								
  execution.go:409	0x100211e30		aa1603e0		MOVD R22, R0										
  execution.go:409	0x100211e34		aa1303e1		MOVD R19, R1										
  execution.go:409	0x100211e38		97f9c5c2		CALL runtime.panicBounds(SB)								
  execution.go:409	0x100211e3c		aa1803e0		MOVD R24, R0										
  execution.go:409	0x100211e40		aa1703e1		MOVD R23, R1										
  execution.go:409	0x100211e44		97f9c5bf		CALL runtime.panicBounds(SB)								
  execution.go:406	0x100211e48		aa1603e0		MOVD R22, R0										
  execution.go:406	0x100211e4c		aa1303e1		MOVD R19, R1										
  execution.go:406	0x100211e50		97f9c5bc		CALL runtime.panicBounds(SB)								
  execution.go:403	0x100211e54		aa1603e0		MOVD R22, R0										
  execution.go:403	0x100211e58		aa1303e1		MOVD R19, R1										
  execution.go:403	0x100211e5c		97f9c5b9		CALL runtime.panicBounds(SB)								
  execution.go:391	0x100211e60		aa1803e0		MOVD R24, R0										
  execution.go:391	0x100211e64		aa1603e1		MOVD R22, R1										
  execution.go:391	0x100211e68		97f9c5b6		CALL runtime.panicBounds(SB)								
  execution.go:389	0x100211e6c		aa1803e0		MOVD R24, R0										
  execution.go:389	0x100211e70		aa1603e1		MOVD R22, R1										
  execution.go:389	0x100211e74		97f9c5b3		CALL runtime.panicBounds(SB)								
  execution.go:385	0x100211e78		aa1803e0		MOVD R24, R0										
  execution.go:385	0x100211e7c		aa1603e1		MOVD R22, R1										
  execution.go:385	0x100211e80		97f9c5b0		CALL runtime.panicBounds(SB)								
  execution.go:383	0x100211e84		aa1303e0		MOVD R19, R0										
  execution.go:383	0x100211e88		97f9c5ae		CALL runtime.panicBounds(SB)								
  execution.go:379	0x100211e8c		aa1303e0		MOVD R19, R0										
  execution.go:379	0x100211e90		97f9c5ac		CALL runtime.panicBounds(SB)								
  execution.go:376	0x100211e94		aa1303e0		MOVD R19, R0										
  execution.go:376	0x100211e98		97f9c5aa		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211e9c		aa1903e0		MOVD R25, R0										
  execution.go:459	0x100211ea0		aa1303e1		MOVD R19, R1										
  execution.go:459	0x100211ea4		97f9c5a7		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211ea8		aa1403e0		MOVD R20, R0										
  execution.go:459	0x100211eac		aa1303e1		MOVD R19, R1										
  execution.go:459	0x100211eb0		97f9c5a4		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211eb4		aa1603e0		MOVD R22, R0										
  execution.go:459	0x100211eb8		aa1403e1		MOVD R20, R1										
  execution.go:459	0x100211ebc		97f9c5a1		CALL runtime.panicBounds(SB)								
  execution.go:459	0x100211ec0		aa1903e0		MOVD R25, R0										
  execution.go:459	0x100211ec4		aa1403e1		MOVD R20, R1										
  execution.go:459	0x100211ec8		97f9c59e		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211ecc		aa1303e0		MOVD R19, R0										
  execution.go:439	0x100211ed0		97f9c59c		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211ed4		97f9c59b		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211ed8		aa1a03e0		MOVD R26, R0										
  execution.go:439	0x100211edc		aa1303e1		MOVD R19, R1										
  execution.go:439	0x100211ee0		97f9c598		CALL runtime.panicBounds(SB)								
  execution.go:439	0x100211ee4		97f9c597		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211ee8		aa1903e0		MOVD R25, R0										
  execution.go:435	0x100211eec		aa1303e1		MOVD R19, R1										
  execution.go:435	0x100211ef0		97f9c594		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211ef4		97f9c593		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211ef8		aa1803e0		MOVD R24, R0										
  execution.go:435	0x100211efc		aa1303e1		MOVD R19, R1										
  execution.go:435	0x100211f00		97f9c590		CALL runtime.panicBounds(SB)								
  execution.go:435	0x100211f04		97f9c58f		CALL runtime.panicBounds(SB)								
  execution.go:434	0x100211f08		aa1403e0		MOVD R20, R0										
  execution.go:434	0x100211f0c		aa1903e1		MOVD R25, R1										
  execution.go:434	0x100211f10		97f9c58c		CALL runtime.panicBounds(SB)								
  execution.go:434	0x100211f14		aa1903e0		MOVD R25, R0										
  execution.go:434	0x100211f18		aa1803e1		MOVD R24, R1										
  execution.go:434	0x100211f1c		97f9c589		CALL runtime.panicBounds(SB)								
  execution.go:364	0x100211f20		aa1403e0		MOVD R20, R0										
  execution.go:364	0x100211f24		aa1003e1		MOVD R16, R1										
  execution.go:364	0x100211f28		97f9c586		CALL runtime.panicBounds(SB)								
  execution.go:361	0x100211f2c		aa1603e0		MOVD R22, R0										
  execution.go:361	0x100211f30		aa1303e1		MOVD R19, R1										
  execution.go:361	0x100211f34		97f9c583		CALL runtime.panicBounds(SB)								
  execution.go:343	0x100211f38		aa1803e0		MOVD R24, R0										
  execution.go:343	0x100211f3c		aa1603e1		MOVD R22, R1										
  execution.go:343	0x100211f40		97f9c580		CALL runtime.panicBounds(SB)								
  execution.go:341	0x100211f44		aa1403e0		MOVD R20, R0										
  execution.go:341	0x100211f48		aa1003e1		MOVD R16, R1										
  execution.go:341	0x100211f4c		97f9c57d		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100211f50		aa1403e0		MOVD R20, R0										
  execution.go:337	0x100211f54		97f9c57b		CALL runtime.panicBounds(SB)								
  execution.go:337	0x100211f58		aa1403e0		MOVD R20, R0										
  execution.go:337	0x100211f5c		aa1103e1		MOVD R17, R1										
  execution.go:337	0x100211f60		97f9c578		CALL runtime.panicBounds(SB)								
  execution.go:797	0x100211f64		f0001160		ADRP 2289664(PC), R0									
  execution.go:797	0x100211f68		9126c000		ADD $2480, R0, R0									
  execution.go:797	0x100211f6c		f0000f81		ADRP 2043904(PC), R1									
  execution.go:797	0x100211f70		91298021		ADD $2656, R1, R1									
  execution.go:797	0x100211f74		97f9aa07		CALL runtime.gopanic(SB)								
  execution.go:797	0x100211f78		d503201f		NOOP											
  execution.go:325	0x100211f7c		a90087e0		STP (R0, R1), 8(RSP)									
  execution.go:325	0x100211f80		aa1e03e3		MOVD R30, R3										
  execution.go:325	0x100211f84		97f9bcd7		CALL runtime.morestack_noctxt.abi0(SB)							
  execution.go:325	0x100211f88		a94087e0		LDP 8(RSP), (R0, R1)									
  execution.go:325	0x100211f8c		17fff621		JMP github.com/cpunion/wasmvm/internal/engine/execute.(*Execution).runSlotsLoop(SB)	
